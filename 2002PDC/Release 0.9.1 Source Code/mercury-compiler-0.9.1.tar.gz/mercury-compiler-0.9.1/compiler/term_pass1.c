/*
** Automatically generated from `term_pass1.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__term_pass1__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury__term_pass1__IntroducedFrom__pred__init_output_suppliers__123__1__ua0_2_0);
Declare_static(mercury__term_pass1__IntroducedFrom__pred__convert_equations_2__338__3_4_0);
Declare_label(mercury__term_pass1__IntroducedFrom__pred__convert_equations_2__338__3_4_0_i3);
Declare_label(mercury__term_pass1__IntroducedFrom__pred__convert_equations_2__338__3_4_0_i2);
Declare_label(mercury__term_pass1__IntroducedFrom__pred__convert_equations_2__338__3_4_0_i5);
Declare_label(mercury__term_pass1__IntroducedFrom__pred__convert_equations_2__338__3_4_0_i1003);
Declare_static(mercury__term_pass1__IntroducedFrom__pred__convert_equations__319__2_2_0);
Declare_static(mercury__term_pass1__IntroducedFrom__pred__init_output_suppliers__123__1_2_0);
Define_extern_entry(mercury__term_pass1__find_arg_sizes_in_scc_7_0);
Declare_label(mercury__term_pass1__find_arg_sizes_in_scc_7_0_i2);
Declare_label(mercury__term_pass1__find_arg_sizes_in_scc_7_0_i3);
Declare_label(mercury__term_pass1__find_arg_sizes_in_scc_7_0_i6);
Declare_label(mercury__term_pass1__find_arg_sizes_in_scc_7_0_i10);
Declare_label(mercury__term_pass1__find_arg_sizes_in_scc_7_0_i8);
Declare_label(mercury__term_pass1__find_arg_sizes_in_scc_7_0_i11);
Declare_label(mercury__term_pass1__find_arg_sizes_in_scc_7_0_i14);
Declare_label(mercury__term_pass1__find_arg_sizes_in_scc_7_0_i13);
Declare_label(mercury__term_pass1__find_arg_sizes_in_scc_7_0_i5);
Declare_static(mercury__term_pass1__init_output_suppliers_3_0);
Declare_label(mercury__term_pass1__init_output_suppliers_3_0_i4);
Declare_label(mercury__term_pass1__init_output_suppliers_3_0_i5);
Declare_label(mercury__term_pass1__init_output_suppliers_3_0_i6);
Declare_label(mercury__term_pass1__init_output_suppliers_3_0_i7);
Declare_label(mercury__term_pass1__init_output_suppliers_3_0_i3);
Declare_static(mercury__term_pass1__find_arg_sizes_in_scc_fixpoint_6_0);
Declare_label(mercury__term_pass1__find_arg_sizes_in_scc_fixpoint_6_0_i1002);
Declare_label(mercury__term_pass1__find_arg_sizes_in_scc_fixpoint_6_0_i2);
Declare_label(mercury__term_pass1__find_arg_sizes_in_scc_fixpoint_6_0_i6);
Declare_label(mercury__term_pass1__find_arg_sizes_in_scc_fixpoint_6_0_i5);
Declare_label(mercury__term_pass1__find_arg_sizes_in_scc_fixpoint_6_0_i3);
Declare_static(mercury__term_pass1__find_arg_sizes_in_scc_pass_9_0);
Declare_label(mercury__term_pass1__find_arg_sizes_in_scc_pass_9_0_i1002);
Declare_label(mercury__term_pass1__find_arg_sizes_in_scc_pass_9_0_i3);
Declare_label(mercury__term_pass1__find_arg_sizes_in_scc_pass_9_0_i4);
Declare_label(mercury__term_pass1__find_arg_sizes_in_scc_pass_9_0_i5);
Declare_label(mercury__term_pass1__find_arg_sizes_in_scc_pass_9_0_i6);
Declare_label(mercury__term_pass1__find_arg_sizes_in_scc_pass_9_0_i9);
Declare_label(mercury__term_pass1__find_arg_sizes_in_scc_pass_9_0_i10);
Declare_label(mercury__term_pass1__find_arg_sizes_in_scc_pass_9_0_i8);
Declare_static(mercury__term_pass1__find_arg_sizes_pred_6_0);
Declare_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i2);
Declare_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i3);
Declare_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i4);
Declare_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i5);
Declare_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i6);
Declare_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i7);
Declare_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i8);
Declare_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i9);
Declare_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i10);
Declare_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i11);
Declare_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i12);
Declare_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i15);
Declare_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i16);
Declare_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i17);
Declare_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i18);
Declare_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i19);
Declare_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i21);
Declare_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i1009);
Declare_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i14);
Declare_static(mercury__term_pass1__update_output_suppliers_4_0);
Declare_label(mercury__term_pass1__update_output_suppliers_4_0_i3);
Declare_label(mercury__term_pass1__update_output_suppliers_4_0_i10);
Declare_label(mercury__term_pass1__update_output_suppliers_4_0_i9);
Declare_label(mercury__term_pass1__update_output_suppliers_4_0_i13);
Declare_label(mercury__term_pass1__update_output_suppliers_4_0_i8);
Declare_static(mercury__term_pass1__solve_equations_5_0);
Declare_label(mercury__term_pass1__solve_equations_5_0_i3);
Declare_label(mercury__term_pass1__solve_equations_5_0_i4);
Declare_label(mercury__term_pass1__solve_equations_5_0_i5);
Declare_label(mercury__term_pass1__solve_equations_5_0_i6);
Declare_label(mercury__term_pass1__solve_equations_5_0_i8);
Declare_label(mercury__term_pass1__solve_equations_5_0_i9);
Declare_label(mercury__term_pass1__solve_equations_5_0_i10);
Declare_label(mercury__term_pass1__solve_equations_5_0_i11);
Declare_label(mercury__term_pass1__solve_equations_5_0_i12);
Declare_label(mercury__term_pass1__solve_equations_5_0_i13);
Declare_label(mercury__term_pass1__solve_equations_5_0_i15);
Declare_label(mercury__term_pass1__solve_equations_5_0_i16);
Declare_label(mercury__term_pass1__solve_equations_5_0_i2);
Declare_static(mercury__term_pass1__convert_equations_2_7_0);
Declare_label(mercury__term_pass1__convert_equations_2_7_0_i1002);
Declare_label(mercury__term_pass1__convert_equations_2_7_0_i4);
Declare_label(mercury__term_pass1__convert_equations_2_7_0_i6);
Declare_label(mercury__term_pass1__convert_equations_2_7_0_i5);
Declare_label(mercury__term_pass1__convert_equations_2_7_0_i8);
Declare_label(mercury__term_pass1__convert_equations_2_7_0_i9);
Declare_label(mercury__term_pass1__convert_equations_2_7_0_i11);
Declare_label(mercury__term_pass1__convert_equations_2_7_0_i12);
Declare_label(mercury__term_pass1__convert_equations_2_7_0_i2);
Declare_static(mercury__term_pass1__lookup_coeff_4_0);
Declare_label(mercury__term_pass1__lookup_coeff_4_0_i2);
Declare_label(mercury__term_pass1__lookup_coeff_4_0_i3);
Declare_label(mercury__term_pass1__lookup_coeff_4_0_i4);
Define_extern_entry(mercury____Unify___term_pass1__arg_size_result_0_0);
Declare_label(mercury____Unify___term_pass1__arg_size_result_0_0_i5);
Declare_label(mercury____Unify___term_pass1__arg_size_result_0_0_i1005);
Declare_label(mercury____Unify___term_pass1__arg_size_result_0_0_i1006);
Declare_label(mercury____Unify___term_pass1__arg_size_result_0_0_i1);
Define_extern_entry(mercury____Index___term_pass1__arg_size_result_0_0);
Declare_label(mercury____Index___term_pass1__arg_size_result_0_0_i3);
Define_extern_entry(mercury____Compare___term_pass1__arg_size_result_0_0);
Declare_label(mercury____Compare___term_pass1__arg_size_result_0_0_i3);
Declare_label(mercury____Compare___term_pass1__arg_size_result_0_0_i2);
Declare_label(mercury____Compare___term_pass1__arg_size_result_0_0_i5);
Declare_label(mercury____Compare___term_pass1__arg_size_result_0_0_i4);
Declare_label(mercury____Compare___term_pass1__arg_size_result_0_0_i6);
Declare_label(mercury____Compare___term_pass1__arg_size_result_0_0_i7);
Declare_label(mercury____Compare___term_pass1__arg_size_result_0_0_i14);
Declare_label(mercury____Compare___term_pass1__arg_size_result_0_0_i11);
Declare_label(mercury____Compare___term_pass1__arg_size_result_0_0_i1015);
Declare_label(mercury____Compare___term_pass1__arg_size_result_0_0_i24);
Declare_static(mercury____Unify___term_pass1__pass1_result_0_0);
Declare_label(mercury____Unify___term_pass1__pass1_result_0_0_i5);
Declare_label(mercury____Unify___term_pass1__pass1_result_0_0_i7);
Declare_label(mercury____Unify___term_pass1__pass1_result_0_0_i1006);
Declare_label(mercury____Unify___term_pass1__pass1_result_0_0_i1007);
Declare_label(mercury____Unify___term_pass1__pass1_result_0_0_i1);
Declare_static(mercury____Index___term_pass1__pass1_result_0_0);
Declare_label(mercury____Index___term_pass1__pass1_result_0_0_i3);
Declare_static(mercury____Compare___term_pass1__pass1_result_0_0);
Declare_label(mercury____Compare___term_pass1__pass1_result_0_0_i3);
Declare_label(mercury____Compare___term_pass1__pass1_result_0_0_i2);
Declare_label(mercury____Compare___term_pass1__pass1_result_0_0_i5);
Declare_label(mercury____Compare___term_pass1__pass1_result_0_0_i4);
Declare_label(mercury____Compare___term_pass1__pass1_result_0_0_i6);
Declare_label(mercury____Compare___term_pass1__pass1_result_0_0_i7);
Declare_label(mercury____Compare___term_pass1__pass1_result_0_0_i14);
Declare_label(mercury____Compare___term_pass1__pass1_result_0_0_i18);
Declare_label(mercury____Compare___term_pass1__pass1_result_0_0_i11);
Declare_label(mercury____Compare___term_pass1__pass1_result_0_0_i1016);
Declare_label(mercury____Compare___term_pass1__pass1_result_0_0_i29);

const struct MR_TypeCtorInfo_struct mercury_data_term_pass1__type_ctor_info_arg_size_result_0;

const struct MR_TypeCtorInfo_struct mercury_data_term_pass1__type_ctor_info_pass1_result_0;

static const struct mercury_data_term_pass1__common_0_struct {
	Word * f1;
	Word * f2;
}  mercury_data_term_pass1__common_0;

static const struct mercury_data_term_pass1__common_1_struct {
	Word * f1;
	Word * f2;
}  mercury_data_term_pass1__common_1;

static const struct mercury_data_term_pass1__common_2_struct {
	Word * f1;
}  mercury_data_term_pass1__common_2;

static const struct mercury_data_term_pass1__common_3_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_term_pass1__common_3;

static const struct mercury_data_term_pass1__common_4_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_term_pass1__common_4;

static const struct mercury_data_term_pass1__common_5_struct {
	Word * f1;
	Word * f2;
}  mercury_data_term_pass1__common_5;

static const struct mercury_data_term_pass1__common_6_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_term_pass1__common_6;

static const struct mercury_data_term_pass1__common_7_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_term_pass1__common_7;

static const struct mercury_data_term_pass1__common_8_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_term_pass1__common_8;

static const struct mercury_data_term_pass1__common_9_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_term_pass1__common_9;

static const struct mercury_data_term_pass1__common_10_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_term_pass1__common_10;

static const struct mercury_data_term_pass1__common_11_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_term_pass1__common_11;

static const struct mercury_data_term_pass1__common_12_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_term_pass1__common_12;

static const struct mercury_data_term_pass1__common_13_struct {
	Word * f1;
}  mercury_data_term_pass1__common_13;

static const struct mercury_data_term_pass1__common_14_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
}  mercury_data_term_pass1__common_14;

static const struct mercury_data_term_pass1__common_15_struct {
	Word * f1;
	Word * f2;
}  mercury_data_term_pass1__common_15;

static const struct mercury_data_term_pass1__common_16_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_term_pass1__common_16;

static const struct mercury_data_term_pass1__common_17_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
}  mercury_data_term_pass1__common_17;

static const struct mercury_data_term_pass1__common_18_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_term_pass1__common_18;

static const struct mercury_data_term_pass1__common_19_struct {
	Word * f1;
	Word * f2;
}  mercury_data_term_pass1__common_19;

static const struct mercury_data_term_pass1__common_20_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_term_pass1__common_20;

static const struct mercury_data_term_pass1__common_21_struct {
	Word * f1;
	Word * f2;
}  mercury_data_term_pass1__common_21;

static const struct mercury_data_term_pass1__common_22_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_term_pass1__common_22;

static const struct mercury_data_term_pass1__common_23_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	String f5;
	Word * f6;
	Integer f7;
	Integer f8;
}  mercury_data_term_pass1__common_23;

static const struct mercury_data_term_pass1__common_24_struct {
	Word * f1;
	Word * f2;
}  mercury_data_term_pass1__common_24;

static const struct mercury_data_term_pass1__common_25_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	String f4;
	Word * f5;
	Integer f6;
	Integer f7;
}  mercury_data_term_pass1__common_25;

static const struct mercury_data_term_pass1__type_ctor_functors_pass1_result_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
	Word * f4;
}  mercury_data_term_pass1__type_ctor_functors_pass1_result_0;

static const struct mercury_data_term_pass1__type_ctor_layout_pass1_result_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_term_pass1__type_ctor_layout_pass1_result_0;

static const struct mercury_data_term_pass1__type_ctor_functors_arg_size_result_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
	Word * f4;
}  mercury_data_term_pass1__type_ctor_functors_arg_size_result_0;

static const struct mercury_data_term_pass1__type_ctor_layout_arg_size_result_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_term_pass1__type_ctor_layout_arg_size_result_0;

const struct MR_TypeCtorInfo_struct mercury_data_term_pass1__type_ctor_info_arg_size_result_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___term_pass1__arg_size_result_0_0),
	ENTRY(mercury____Index___term_pass1__arg_size_result_0_0),
	ENTRY(mercury____Compare___term_pass1__arg_size_result_0_0),
	(Integer) 2,
	(Word *) &mercury_data_term_pass1__type_ctor_functors_arg_size_result_0,
	(Word *) &mercury_data_term_pass1__type_ctor_layout_arg_size_result_0,
	MR_string_const("term_pass1", 10),
	MR_string_const("arg_size_result", 15),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_term_pass1__type_ctor_info_pass1_result_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___term_pass1__pass1_result_0_0),
	STATIC(mercury____Index___term_pass1__pass1_result_0_0),
	STATIC(mercury____Compare___term_pass1__pass1_result_0_0),
	(Integer) 2,
	(Word *) &mercury_data_term_pass1__type_ctor_functors_pass1_result_0,
	(Word *) &mercury_data_term_pass1__type_ctor_layout_pass1_result_0,
	MR_string_const("term_pass1", 10),
	MR_string_const("pass1_result", 12),
	(Integer) 3
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_var_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_generic_0;
static const struct mercury_data_term_pass1__common_0_struct mercury_data_term_pass1__common_0 = {
	(Word *) &mercury_data_term__type_ctor_info_var_1,
	(Word *) &mercury_data_term__type_ctor_info_generic_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_prog_var_type_0;
static const struct mercury_data_term_pass1__common_1_struct mercury_data_term_pass1__common_1 = {
	(Word *) &mercury_data_term__type_ctor_info_var_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_bool__type_ctor_info_bool_0;
static const struct mercury_data_term_pass1__common_2_struct mercury_data_term_pass1__common_2 = {
	(Word *) &mercury_data_bool__type_ctor_info_bool_0
};

static const struct mercury_data_term_pass1__common_3_struct mercury_data_term_pass1__common_3 = {
	(Integer) 0,
	MR_string_const("term_pass1", 10),
	MR_string_const("term_pass1", 10),
	MR_string_const("IntroducedFrom__pred__init_output_suppliers__123__1", 51),
	2,
	0,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_1),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_2)
};

static const struct mercury_data_term_pass1__common_4_struct mercury_data_term_pass1__common_4 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_3),
	STATIC(mercury__term_pass1__IntroducedFrom__pred__init_output_suppliers__123__1_2_0),
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_list__type_ctor_info_list_1;
static const struct mercury_data_term_pass1__common_5_struct mercury_data_term_pass1__common_5 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data_bool__type_ctor_info_bool_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_pair_2;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_context_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_term_errors__type_ctor_info_termination_error_0;
static const struct mercury_data_term_pass1__common_6_struct mercury_data_term_pass1__common_6 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_term__type_ctor_info_context_0,
	(Word *) &mercury_data_term_errors__type_ctor_info_termination_error_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_float_0;
static const struct mercury_data_term_pass1__common_7_struct mercury_data_term_pass1__common_7 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_0),
	(Word *) &mercury_data___type_ctor_info_float_0
};

static const struct mercury_data_term_pass1__common_8_struct mercury_data_term_pass1__common_8 = {
	(Integer) 0,
	MR_string_const("term_pass1", 10),
	MR_string_const("term_pass1", 10),
	MR_string_const("IntroducedFrom__pred__convert_equations__319__2", 47),
	2,
	0,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_0),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_7)
};

static const struct mercury_data_term_pass1__common_9_struct mercury_data_term_pass1__common_9 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_8),
	STATIC(mercury__term_pass1__IntroducedFrom__pred__convert_equations__319__2_2_0),
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_int_0;
static const struct mercury_data_term_pass1__common_10_struct mercury_data_term_pass1__common_10 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0,
	(Word *) &mercury_data___type_ctor_info_int_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_tree234__type_ctor_info_tree234_2;
static const struct mercury_data_term_pass1__common_11_struct mercury_data_term_pass1__common_11 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_0)
};

static const struct mercury_data_term_pass1__common_12_struct mercury_data_term_pass1__common_12 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_0),
	(Word *) &mercury_data___type_ctor_info_float_0
};

static const struct mercury_data_term_pass1__common_13_struct mercury_data_term_pass1__common_13 = {
	(Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0
};

static const struct mercury_data_term_pass1__common_14_struct mercury_data_term_pass1__common_14 = {
	(Integer) 0,
	MR_string_const("term_pass1", 10),
	MR_string_const("term_pass1", 10),
	MR_string_const("lookup_coeff", 12),
	4,
	0,
	0,
	4,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_11),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_12),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_13),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_10)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_varset__type_ctor_info_varset_1;
static const struct mercury_data_term_pass1__common_15_struct mercury_data_term_pass1__common_15 = {
	(Word *) &mercury_data_varset__type_ctor_info_varset_1,
	(Word *) &mercury_data_term__type_ctor_info_generic_0
};

static const struct mercury_data_term_pass1__common_16_struct mercury_data_term_pass1__common_16 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_15),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_11)
};

static const struct mercury_data_term_pass1__common_17_struct mercury_data_term_pass1__common_17 = {
	(Integer) 0,
	MR_string_const("term_pass1", 10),
	MR_string_const("term_pass1", 10),
	MR_string_const("IntroducedFrom__pred__convert_equations_2__338__3", 49),
	4,
	0,
	0,
	4,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_13),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_7),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_16),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_16)
};

static const struct mercury_data_term_pass1__common_18_struct mercury_data_term_pass1__common_18 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_17),
	STATIC(mercury__term_pass1__IntroducedFrom__pred__convert_equations_2__338__3_4_0),
	(Integer) 0
};

static const struct mercury_data_term_pass1__common_19_struct mercury_data_term_pass1__common_19 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_6)
};

static const struct mercury_data_term_pass1__common_20_struct mercury_data_term_pass1__common_20 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_19),
	MR_string_const("error", 5),
	MR_mkword(MR_mktag(1), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term_traversal__type_ctor_info_path_info_0;
static const struct mercury_data_term_pass1__common_21_struct mercury_data_term_pass1__common_21 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data_term_traversal__type_ctor_info_path_info_0
};

static const struct mercury_data_term_pass1__common_22_struct mercury_data_term_pass1__common_22 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_5)
};

static const struct mercury_data_term_pass1__common_23_struct mercury_data_term_pass1__common_23 = {
	(Integer) 3,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_21),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_22),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_19),
	MR_string_const("ok", 2),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_term_pass1__common_24_struct mercury_data_term_pass1__common_24 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_10)
};

static const struct mercury_data_term_pass1__common_25_struct mercury_data_term_pass1__common_25 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_24),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_22),
	MR_string_const("ok", 2),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_term_pass1__type_ctor_functors_pass1_result_0_struct mercury_data_term_pass1__type_ctor_functors_pass1_result_0 = {
	(Integer) 0,
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_20),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_23)
};

static const struct mercury_data_term_pass1__type_ctor_layout_pass1_result_0_struct mercury_data_term_pass1__type_ctor_layout_pass1_result_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_pass1__common_23),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_pass1__common_20),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_term_pass1__type_ctor_functors_arg_size_result_0_struct mercury_data_term_pass1__type_ctor_functors_arg_size_result_0 = {
	(Integer) 0,
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_20),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_25)
};

static const struct mercury_data_term_pass1__type_ctor_layout_arg_size_result_0_struct mercury_data_term_pass1__type_ctor_layout_arg_size_result_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_pass1__common_25),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_pass1__common_20),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};


BEGIN_MODULE(term_pass1_module0)
	init_entry(mercury__term_pass1__IntroducedFrom__pred__init_output_suppliers__123__1__ua0_2_0);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__init_output_suppliers__123__1__ua0'/2 in mode 0 */
Define_static(mercury__term_pass1__IntroducedFrom__pred__init_output_suppliers__123__1__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE

Declare_entry(mercury__map__search_3_1);
static const Float mercury_float_const_neg1pt00000000000000 = -1.00000000000000;
Declare_entry(mercury__varset__new_var_3_0);
Declare_entry(mercury__map__det_insert_4_0);

BEGIN_MODULE(term_pass1_module1)
	init_entry(mercury__term_pass1__IntroducedFrom__pred__convert_equations_2__338__3_4_0);
	init_label(mercury__term_pass1__IntroducedFrom__pred__convert_equations_2__338__3_4_0_i3);
	init_label(mercury__term_pass1__IntroducedFrom__pred__convert_equations_2__338__3_4_0_i2);
	init_label(mercury__term_pass1__IntroducedFrom__pred__convert_equations_2__338__3_4_0_i5);
	init_label(mercury__term_pass1__IntroducedFrom__pred__convert_equations_2__338__3_4_0_i1003);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__convert_equations_2__338__3'/4 in mode 0 */
Define_static(mercury__term_pass1__IntroducedFrom__pred__convert_equations_2__338__3_4_0);
	MR_incr_sp_push_msg(5, "term_pass1:IntroducedFrom__pred__convert_equations_2__338__3/4");
	MR_stackvar(5) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(2) = r3;
	r4 = r1;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(3) = r2;
	MR_stackvar(4) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_0);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__term_pass1__IntroducedFrom__pred__convert_equations_2__338__3_4_0_i3,
		STATIC(mercury__term_pass1__IntroducedFrom__pred__convert_equations_2__338__3_4_0));
Define_label(mercury__term_pass1__IntroducedFrom__pred__convert_equations_2__338__3_4_0_i3);
	update_prof_current_proc(LABEL(mercury__term_pass1__IntroducedFrom__pred__convert_equations_2__338__3_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__term_pass1__IntroducedFrom__pred__convert_equations_2__338__3_4_0_i2);
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__term_pass1__IntroducedFrom__pred__convert_equations_2__338__3_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r1, (Integer) 0) = r2;
	r2 = MR_stackvar(3);
	MR_field(MR_mktag(0), r1, (Integer) 1) = (Word) &mercury_float_const_neg1pt00000000000000;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__term_pass1__IntroducedFrom__pred__convert_equations_2__338__3_4_0_i2);
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__varset__new_var_3_0),
		mercury__term_pass1__IntroducedFrom__pred__convert_equations_2__338__3_4_0_i5,
		STATIC(mercury__term_pass1__IntroducedFrom__pred__convert_equations_2__338__3_4_0));
Define_label(mercury__term_pass1__IntroducedFrom__pred__convert_equations_2__338__3_4_0_i5);
	update_prof_current_proc(LABEL(mercury__term_pass1__IntroducedFrom__pred__convert_equations_2__338__3_4_0));
	r3 = MR_stackvar(2);
	r5 = r1;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_0);
	r4 = MR_stackvar(4);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__term_pass1__IntroducedFrom__pred__convert_equations_2__338__3_4_0_i1003,
		STATIC(mercury__term_pass1__IntroducedFrom__pred__convert_equations_2__338__3_4_0));
Define_label(mercury__term_pass1__IntroducedFrom__pred__convert_equations_2__338__3_4_0_i1003);
	update_prof_current_proc(LABEL(mercury__term_pass1__IntroducedFrom__pred__convert_equations_2__338__3_4_0));
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__term_pass1__IntroducedFrom__pred__convert_equations_2__338__3_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 1) = r1;
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__term_pass1__IntroducedFrom__pred__convert_equations_2__338__3_4_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), r1, (Integer) 1) = (Word) &mercury_float_const_neg1pt00000000000000;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE

static const Float mercury_float_const_1pt00000000000000 = 1.00000000000000;

BEGIN_MODULE(term_pass1_module2)
	init_entry(mercury__term_pass1__IntroducedFrom__pred__convert_equations__319__2_2_0);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__convert_equations__319__2'/2 in mode 0 */
Define_static(mercury__term_pass1__IntroducedFrom__pred__convert_equations__319__2_2_0);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__term_pass1__IntroducedFrom__pred__convert_equations__319__2_2_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 1) = (Word) &mercury_float_const_1pt00000000000000;
	proceed();
END_MODULE


BEGIN_MODULE(term_pass1_module3)
	init_entry(mercury__term_pass1__IntroducedFrom__pred__init_output_suppliers__123__1_2_0);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__init_output_suppliers__123__1'/2 in mode 0 */
Define_static(mercury__term_pass1__IntroducedFrom__pred__init_output_suppliers__123__1_2_0);
	tailcall(STATIC(mercury__term_pass1__IntroducedFrom__pred__init_output_suppliers__123__1__ua0_2_0),
		STATIC(mercury__term_pass1__IntroducedFrom__pred__init_output_suppliers__123__1_2_0));
END_MODULE

Declare_entry(mercury__term_util__get_context_from_scc_3_0);

BEGIN_MODULE(term_pass1_module4)
	init_entry(mercury__term_pass1__find_arg_sizes_in_scc_7_0);
	init_label(mercury__term_pass1__find_arg_sizes_in_scc_7_0_i2);
	init_label(mercury__term_pass1__find_arg_sizes_in_scc_7_0_i3);
	init_label(mercury__term_pass1__find_arg_sizes_in_scc_7_0_i6);
	init_label(mercury__term_pass1__find_arg_sizes_in_scc_7_0_i10);
	init_label(mercury__term_pass1__find_arg_sizes_in_scc_7_0_i8);
	init_label(mercury__term_pass1__find_arg_sizes_in_scc_7_0_i11);
	init_label(mercury__term_pass1__find_arg_sizes_in_scc_7_0_i14);
	init_label(mercury__term_pass1__find_arg_sizes_in_scc_7_0_i13);
	init_label(mercury__term_pass1__find_arg_sizes_in_scc_7_0_i5);
BEGIN_CODE

/* code for predicate 'find_arg_sizes_in_scc'/7 in mode 0 */
Define_entry(mercury__term_pass1__find_arg_sizes_in_scc_7_0);
	MR_incr_sp_push_msg(5, "term_pass1:find_arg_sizes_in_scc/7");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	call_localret(STATIC(mercury__term_pass1__init_output_suppliers_3_0),
		mercury__term_pass1__find_arg_sizes_in_scc_7_0_i2,
		ENTRY(mercury__term_pass1__find_arg_sizes_in_scc_7_0));
Define_label(mercury__term_pass1__find_arg_sizes_in_scc_7_0_i2);
	update_prof_current_proc(LABEL(mercury__term_pass1__find_arg_sizes_in_scc_7_0));
	r4 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	call_localret(STATIC(mercury__term_pass1__find_arg_sizes_in_scc_fixpoint_6_0),
		mercury__term_pass1__find_arg_sizes_in_scc_7_0_i3,
		ENTRY(mercury__term_pass1__find_arg_sizes_in_scc_7_0));
Define_label(mercury__term_pass1__find_arg_sizes_in_scc_7_0_i3);
	update_prof_current_proc(LABEL(mercury__term_pass1__find_arg_sizes_in_scc_7_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__term_pass1__find_arg_sizes_in_scc_7_0_i5);
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r4 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	if (((Integer) MR_const_field(MR_mktag(0), r1, (Integer) 2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_pass1__find_arg_sizes_in_scc_7_0_i6);
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__term_pass1__find_arg_sizes_in_scc_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 2);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
	}
Define_label(mercury__term_pass1__find_arg_sizes_in_scc_7_0_i6);
	if (((Integer) r4 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_pass1__find_arg_sizes_in_scc_7_0_i8);
	MR_stackvar(3) = r2;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__term_util__get_context_from_scc_3_0),
		mercury__term_pass1__find_arg_sizes_in_scc_7_0_i10,
		ENTRY(mercury__term_pass1__find_arg_sizes_in_scc_7_0));
Define_label(mercury__term_pass1__find_arg_sizes_in_scc_7_0_i10);
	update_prof_current_proc(LABEL(mercury__term_pass1__find_arg_sizes_in_scc_7_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__term_pass1__find_arg_sizes_in_scc_7_0, "term_pass1:arg_size_result/0");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__term_pass1__find_arg_sizes_in_scc_7_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__term_pass1__find_arg_sizes_in_scc_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 3));
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(5);
	r2 = MR_stackvar(3);
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_tempr1;
	r3 = MR_stackvar(4);
	MR_decr_sp_pop_msg(5);
	proceed();
	}
Define_label(mercury__term_pass1__find_arg_sizes_in_scc_7_0_i8);
	{
	Word MR_tempr1;
	MR_tempr1 = r3;
	r3 = MR_stackvar(4);
	MR_stackvar(4) = MR_tempr1;
	MR_stackvar(3) = r2;
	r1 = r4;
	r2 = MR_stackvar(1);
	call_localret(STATIC(mercury__term_pass1__solve_equations_5_0),
		mercury__term_pass1__find_arg_sizes_in_scc_7_0_i11,
		ENTRY(mercury__term_pass1__find_arg_sizes_in_scc_7_0));
	}
Define_label(mercury__term_pass1__find_arg_sizes_in_scc_7_0_i11);
	update_prof_current_proc(LABEL(mercury__term_pass1__find_arg_sizes_in_scc_7_0));
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_pass1__find_arg_sizes_in_scc_7_0_i13);
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__term_util__get_context_from_scc_3_0),
		mercury__term_pass1__find_arg_sizes_in_scc_7_0_i14,
		ENTRY(mercury__term_pass1__find_arg_sizes_in_scc_7_0));
Define_label(mercury__term_pass1__find_arg_sizes_in_scc_7_0_i14);
	update_prof_current_proc(LABEL(mercury__term_pass1__find_arg_sizes_in_scc_7_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__term_pass1__find_arg_sizes_in_scc_7_0, "term_pass1:arg_size_result/0");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__term_pass1__find_arg_sizes_in_scc_7_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__term_pass1__find_arg_sizes_in_scc_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 5));
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(5);
	r2 = MR_stackvar(3);
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_tempr1;
	r3 = MR_stackvar(1);
	MR_decr_sp_pop_msg(5);
	proceed();
	}
Define_label(mercury__term_pass1__find_arg_sizes_in_scc_7_0_i13);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__term_pass1__find_arg_sizes_in_scc_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	r3 = r2;
	r2 = MR_stackvar(3);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__term_pass1__find_arg_sizes_in_scc_7_0_i5);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__term_pass1__find_arg_sizes_in_scc_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_module__module_info_pred_proc_info_5_0);
Declare_entry(mercury__hlds_pred__proc_info_headvars_2_0);
Declare_entry(mercury__list__map_3_0);
Declare_entry(mercury__map__init_1_0);

BEGIN_MODULE(term_pass1_module5)
	init_entry(mercury__term_pass1__init_output_suppliers_3_0);
	init_label(mercury__term_pass1__init_output_suppliers_3_0_i4);
	init_label(mercury__term_pass1__init_output_suppliers_3_0_i5);
	init_label(mercury__term_pass1__init_output_suppliers_3_0_i6);
	init_label(mercury__term_pass1__init_output_suppliers_3_0_i7);
	init_label(mercury__term_pass1__init_output_suppliers_3_0_i3);
BEGIN_CODE

/* code for predicate 'init_output_suppliers'/3 in mode 0 */
Define_static(mercury__term_pass1__init_output_suppliers_3_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_pass1__init_output_suppliers_3_0_i3);
	MR_incr_sp_push_msg(3, "term_pass1:init_output_suppliers/3");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(1) = r2;
	localcall(mercury__term_pass1__init_output_suppliers_3_0,
		LABEL(mercury__term_pass1__init_output_suppliers_3_0_i4),
		STATIC(mercury__term_pass1__init_output_suppliers_3_0));
Define_label(mercury__term_pass1__init_output_suppliers_3_0_i4);
	update_prof_current_proc(LABEL(mercury__term_pass1__init_output_suppliers_3_0));
	{
	Word MR_tempr1, MR_tempr2;
	MR_tempr1 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	MR_tempr2 = MR_stackvar(2);
	r3 = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 1);
	r2 = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 0);
	call_localret(ENTRY(mercury__hlds_module__module_info_pred_proc_info_5_0),
		mercury__term_pass1__init_output_suppliers_3_0_i5,
		STATIC(mercury__term_pass1__init_output_suppliers_3_0));
	}
Define_label(mercury__term_pass1__init_output_suppliers_3_0_i5);
	update_prof_current_proc(LABEL(mercury__term_pass1__init_output_suppliers_3_0));
	r1 = r2;
	call_localret(ENTRY(mercury__hlds_pred__proc_info_headvars_2_0),
		mercury__term_pass1__init_output_suppliers_3_0_i6,
		STATIC(mercury__term_pass1__init_output_suppliers_3_0));
Define_label(mercury__term_pass1__init_output_suppliers_3_0_i6);
	update_prof_current_proc(LABEL(mercury__term_pass1__init_output_suppliers_3_0));
	r4 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_1);
	r2 = (Word) (Word *) &mercury_data_bool__type_ctor_info_bool_0;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_4);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__term_pass1__init_output_suppliers_3_0_i7,
		STATIC(mercury__term_pass1__init_output_suppliers_3_0));
Define_label(mercury__term_pass1__init_output_suppliers_3_0_i7);
	update_prof_current_proc(LABEL(mercury__term_pass1__init_output_suppliers_3_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_5);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__map__det_insert_4_0),
		STATIC(mercury__term_pass1__init_output_suppliers_3_0));
Define_label(mercury__term_pass1__init_output_suppliers_3_0_i3);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_5);
	tailcall(ENTRY(mercury__map__init_1_0),
		STATIC(mercury__term_pass1__init_output_suppliers_3_0));
END_MODULE

Declare_entry(mercury____Unify___tree234__tree234_2_0);

BEGIN_MODULE(term_pass1_module6)
	init_entry(mercury__term_pass1__find_arg_sizes_in_scc_fixpoint_6_0);
	init_label(mercury__term_pass1__find_arg_sizes_in_scc_fixpoint_6_0_i1002);
	init_label(mercury__term_pass1__find_arg_sizes_in_scc_fixpoint_6_0_i2);
	init_label(mercury__term_pass1__find_arg_sizes_in_scc_fixpoint_6_0_i6);
	init_label(mercury__term_pass1__find_arg_sizes_in_scc_fixpoint_6_0_i5);
	init_label(mercury__term_pass1__find_arg_sizes_in_scc_fixpoint_6_0_i3);
BEGIN_CODE

/* code for predicate 'find_arg_sizes_in_scc_fixpoint'/6 in mode 0 */
Define_static(mercury__term_pass1__find_arg_sizes_in_scc_fixpoint_6_0);
	MR_incr_sp_push_msg(7, "term_pass1:find_arg_sizes_in_scc_fixpoint/6");
	MR_stackvar(7) = (Word) MR_succip;
Define_label(mercury__term_pass1__find_arg_sizes_in_scc_fixpoint_6_0_i1002);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r6 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r7 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(STATIC(mercury__term_pass1__find_arg_sizes_in_scc_pass_9_0),
		mercury__term_pass1__find_arg_sizes_in_scc_fixpoint_6_0_i2,
		STATIC(mercury__term_pass1__find_arg_sizes_in_scc_fixpoint_6_0));
Define_label(mercury__term_pass1__find_arg_sizes_in_scc_fixpoint_6_0_i2);
	update_prof_current_proc(LABEL(mercury__term_pass1__find_arg_sizes_in_scc_fixpoint_6_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__term_pass1__find_arg_sizes_in_scc_fixpoint_6_0_i3);
	r4 = MR_stackvar(4);
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(6) = r3;
	MR_stackvar(4) = r1;
	MR_stackvar(5) = r2;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_5);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury__term_pass1__find_arg_sizes_in_scc_fixpoint_6_0_i6,
		STATIC(mercury__term_pass1__find_arg_sizes_in_scc_fixpoint_6_0));
Define_label(mercury__term_pass1__find_arg_sizes_in_scc_fixpoint_6_0_i6);
	update_prof_current_proc(LABEL(mercury__term_pass1__find_arg_sizes_in_scc_fixpoint_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__term_pass1__find_arg_sizes_in_scc_fixpoint_6_0_i5);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__term_pass1__find_arg_sizes_in_scc_fixpoint_6_0_i5);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(7);
	GOTO_LABEL(mercury__term_pass1__find_arg_sizes_in_scc_fixpoint_6_0_i1002);
Define_label(mercury__term_pass1__find_arg_sizes_in_scc_fixpoint_6_0_i3);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE

Declare_entry(mercury__list__append_3_1);
Declare_entry(mercury__list__take_upto_3_0);

BEGIN_MODULE(term_pass1_module7)
	init_entry(mercury__term_pass1__find_arg_sizes_in_scc_pass_9_0);
	init_label(mercury__term_pass1__find_arg_sizes_in_scc_pass_9_0_i1002);
	init_label(mercury__term_pass1__find_arg_sizes_in_scc_pass_9_0_i3);
	init_label(mercury__term_pass1__find_arg_sizes_in_scc_pass_9_0_i4);
	init_label(mercury__term_pass1__find_arg_sizes_in_scc_pass_9_0_i5);
	init_label(mercury__term_pass1__find_arg_sizes_in_scc_pass_9_0_i6);
	init_label(mercury__term_pass1__find_arg_sizes_in_scc_pass_9_0_i9);
	init_label(mercury__term_pass1__find_arg_sizes_in_scc_pass_9_0_i10);
	init_label(mercury__term_pass1__find_arg_sizes_in_scc_pass_9_0_i8);
BEGIN_CODE

/* code for predicate 'find_arg_sizes_in_scc_pass'/9 in mode 0 */
Define_static(mercury__term_pass1__find_arg_sizes_in_scc_pass_9_0);
	MR_incr_sp_push_msg(8, "term_pass1:find_arg_sizes_in_scc_pass/9");
	MR_stackvar(8) = (Word) MR_succip;
Define_label(mercury__term_pass1__find_arg_sizes_in_scc_pass_9_0_i1002);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_pass1__find_arg_sizes_in_scc_pass_9_0_i3);
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 3, mercury__term_pass1__find_arg_sizes_in_scc_pass_9_0, "term_pass1:pass1_result/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = r5;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r4;
	MR_field(MR_mktag(0), r1, (Integer) 2) = r6;
	r2 = r7;
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__term_pass1__find_arg_sizes_in_scc_pass_9_0_i3);
	MR_stackvar(6) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r5;
	MR_stackvar(4) = r6;
	MR_stackvar(5) = r7;
	call_localret(STATIC(mercury__term_pass1__find_arg_sizes_pred_6_0),
		mercury__term_pass1__find_arg_sizes_in_scc_pass_9_0_i4,
		STATIC(mercury__term_pass1__find_arg_sizes_in_scc_pass_9_0));
Define_label(mercury__term_pass1__find_arg_sizes_in_scc_pass_9_0_i4);
	update_prof_current_proc(LABEL(mercury__term_pass1__find_arg_sizes_in_scc_pass_9_0));
	r3 = r2;
	r2 = MR_stackvar(5);
	MR_stackvar(5) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_6);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__term_pass1__find_arg_sizes_in_scc_pass_9_0_i5,
		STATIC(mercury__term_pass1__find_arg_sizes_in_scc_pass_9_0));
Define_label(mercury__term_pass1__find_arg_sizes_in_scc_pass_9_0_i5);
	update_prof_current_proc(LABEL(mercury__term_pass1__find_arg_sizes_in_scc_pass_9_0));
	r3 = r1;
	r2 = MR_const_field(MR_mktag(0), MR_stackvar(2), (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_6);
	call_localret(ENTRY(mercury__list__take_upto_3_0),
		mercury__term_pass1__find_arg_sizes_in_scc_pass_9_0_i6,
		STATIC(mercury__term_pass1__find_arg_sizes_in_scc_pass_9_0));
Define_label(mercury__term_pass1__find_arg_sizes_in_scc_pass_9_0_i6);
	update_prof_current_proc(LABEL(mercury__term_pass1__find_arg_sizes_in_scc_pass_9_0));
	if ((MR_tag(MR_stackvar(5)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__term_pass1__find_arg_sizes_in_scc_pass_9_0_i8);
	r2 = MR_stackvar(3);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(5);
	r3 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	MR_stackvar(3) = r1;
	MR_stackvar(7) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 2);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_term_traversal__type_ctor_info_path_info_0;
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__term_pass1__find_arg_sizes_in_scc_pass_9_0_i9,
		STATIC(mercury__term_pass1__find_arg_sizes_in_scc_pass_9_0));
	}
Define_label(mercury__term_pass1__find_arg_sizes_in_scc_pass_9_0_i9);
	update_prof_current_proc(LABEL(mercury__term_pass1__find_arg_sizes_in_scc_pass_9_0));
	r2 = MR_stackvar(4);
	MR_stackvar(4) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_6);
	r3 = MR_stackvar(7);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__term_pass1__find_arg_sizes_in_scc_pass_9_0_i10,
		STATIC(mercury__term_pass1__find_arg_sizes_in_scc_pass_9_0));
Define_label(mercury__term_pass1__find_arg_sizes_in_scc_pass_9_0_i10);
	update_prof_current_proc(LABEL(mercury__term_pass1__find_arg_sizes_in_scc_pass_9_0));
	r6 = r1;
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(5);
	r5 = MR_stackvar(4);
	r7 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(8);
	GOTO_LABEL(mercury__term_pass1__find_arg_sizes_in_scc_pass_9_0_i1002);
Define_label(mercury__term_pass1__find_arg_sizes_in_scc_pass_9_0_i8);
	r2 = r1;
	r1 = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_pred__pred_info_context_2_0);
Declare_entry(mercury__hlds_pred__proc_info_argmodes_2_0);
Declare_entry(mercury__hlds_pred__proc_info_vartypes_2_0);
Declare_entry(mercury__hlds_pred__proc_info_goal_2_0);
Declare_entry(mercury__term_traversal__init_traversal_params_10_0);
Declare_entry(mercury__term_util__partition_call_args_5_0);
Declare_entry(mercury__set__singleton_set_2_1);
Declare_entry(mercury__term_traversal__traverse_goal_4_0);
Declare_entry(mercury__set__to_sorted_list_2_0);
Declare_entry(mercury__term_traversal__upper_bound_active_vars_2_0);
Declare_entry(mercury__map__lookup_3_0);
Declare_entry(mercury__map__det_update_4_0);
Declare_entry(mercury__bag__is_subbag_2_0);

BEGIN_MODULE(term_pass1_module8)
	init_entry(mercury__term_pass1__find_arg_sizes_pred_6_0);
	init_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i2);
	init_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i3);
	init_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i4);
	init_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i5);
	init_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i6);
	init_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i7);
	init_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i8);
	init_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i9);
	init_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i10);
	init_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i11);
	init_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i12);
	init_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i15);
	init_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i16);
	init_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i17);
	init_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i18);
	init_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i19);
	init_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i21);
	init_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i1009);
	init_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i14);
BEGIN_CODE

/* code for predicate 'find_arg_sizes_pred'/6 in mode 0 */
Define_static(mercury__term_pass1__find_arg_sizes_pred_6_0);
	MR_incr_sp_push_msg(10, "term_pass1:find_arg_sizes_pred/6");
	MR_stackvar(10) = (Word) MR_succip;
	MR_stackvar(3) = r3;
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = r2;
	r2 = MR_const_field(MR_mktag(0), MR_stackvar(1), (Integer) 0);
	MR_stackvar(4) = r4;
	call_localret(ENTRY(mercury__hlds_module__module_info_pred_proc_info_5_0),
		mercury__term_pass1__find_arg_sizes_pred_6_0_i2,
		STATIC(mercury__term_pass1__find_arg_sizes_pred_6_0));
Define_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i2);
	update_prof_current_proc(LABEL(mercury__term_pass1__find_arg_sizes_pred_6_0));
	MR_stackvar(5) = r2;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_context_2_0),
		mercury__term_pass1__find_arg_sizes_pred_6_0_i3,
		STATIC(mercury__term_pass1__find_arg_sizes_pred_6_0));
Define_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i3);
	update_prof_current_proc(LABEL(mercury__term_pass1__find_arg_sizes_pred_6_0));
	MR_stackvar(6) = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_headvars_2_0),
		mercury__term_pass1__find_arg_sizes_pred_6_0_i4,
		STATIC(mercury__term_pass1__find_arg_sizes_pred_6_0));
Define_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i4);
	update_prof_current_proc(LABEL(mercury__term_pass1__find_arg_sizes_pred_6_0));
	MR_stackvar(7) = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_argmodes_2_0),
		mercury__term_pass1__find_arg_sizes_pred_6_0_i5,
		STATIC(mercury__term_pass1__find_arg_sizes_pred_6_0));
Define_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i5);
	update_prof_current_proc(LABEL(mercury__term_pass1__find_arg_sizes_pred_6_0));
	MR_stackvar(8) = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_vartypes_2_0),
		mercury__term_pass1__find_arg_sizes_pred_6_0_i6,
		STATIC(mercury__term_pass1__find_arg_sizes_pred_6_0));
Define_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i6);
	update_prof_current_proc(LABEL(mercury__term_pass1__find_arg_sizes_pred_6_0));
	r2 = r1;
	r1 = MR_stackvar(5);
	MR_stackvar(5) = r2;
	call_localret(ENTRY(mercury__hlds_pred__proc_info_goal_2_0),
		mercury__term_pass1__find_arg_sizes_pred_6_0_i7,
		STATIC(mercury__term_pass1__find_arg_sizes_pred_6_0));
Define_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i7);
	update_prof_current_proc(LABEL(mercury__term_pass1__find_arg_sizes_pred_6_0));
	MR_stackvar(9) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_5);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__term_pass1__find_arg_sizes_pred_6_0_i8,
		STATIC(mercury__term_pass1__find_arg_sizes_pred_6_0));
Define_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i8);
	update_prof_current_proc(LABEL(mercury__term_pass1__find_arg_sizes_pred_6_0));
	r7 = r1;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(3);
	r9 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 2);
	r8 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r1 = MR_stackvar(2);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(6);
	r5 = MR_stackvar(5);
	r6 = MR_stackvar(4);
	call_localret(ENTRY(mercury__term_traversal__init_traversal_params_10_0),
		mercury__term_pass1__find_arg_sizes_pred_6_0_i9,
		STATIC(mercury__term_pass1__find_arg_sizes_pred_6_0));
	}
Define_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i9);
	update_prof_current_proc(LABEL(mercury__term_pass1__find_arg_sizes_pred_6_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = MR_tempr1;
	r2 = MR_stackvar(8);
	r3 = MR_stackvar(7);
	call_localret(ENTRY(mercury__term_util__partition_call_args_5_0),
		mercury__term_pass1__find_arg_sizes_pred_6_0_i10,
		STATIC(mercury__term_pass1__find_arg_sizes_pred_6_0));
	}
Define_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i10);
	update_prof_current_proc(LABEL(mercury__term_pass1__find_arg_sizes_pred_6_0));
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 5, mercury__term_pass1__find_arg_sizes_pred_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 4) = r2;
	r2 = r3;
	MR_stackvar(3) = r1;
	r1 = (Word) (Word *) &mercury_data_term_traversal__type_ctor_info_path_info_0;
	MR_field(MR_mktag(0), r3, (Integer) 3) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 0;
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(1);
	call_localret(ENTRY(mercury__set__singleton_set_2_1),
		mercury__term_pass1__find_arg_sizes_pred_6_0_i11,
		STATIC(mercury__term_pass1__find_arg_sizes_pred_6_0));
Define_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i11);
	update_prof_current_proc(LABEL(mercury__term_pass1__find_arg_sizes_pred_6_0));
	r4 = r1;
	r1 = MR_stackvar(9);
	r2 = MR_stackvar(2);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__term_pass1__find_arg_sizes_pred_6_0, "term_traversal:traversal_info/0");
	MR_field(MR_mktag(0), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__term_traversal__traverse_goal_4_0),
		mercury__term_pass1__find_arg_sizes_pred_6_0_i12,
		STATIC(mercury__term_pass1__find_arg_sizes_pred_6_0));
Define_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i12);
	update_prof_current_proc(LABEL(mercury__term_pass1__find_arg_sizes_pred_6_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__term_pass1__find_arg_sizes_pred_6_0_i14);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_term_traversal__type_ctor_info_path_info_0;
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__term_pass1__find_arg_sizes_pred_6_0_i15,
		STATIC(mercury__term_pass1__find_arg_sizes_pred_6_0));
Define_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i15);
	update_prof_current_proc(LABEL(mercury__term_pass1__find_arg_sizes_pred_6_0));
	MR_stackvar(5) = r1;
	call_localret(ENTRY(mercury__term_traversal__upper_bound_active_vars_2_0),
		mercury__term_pass1__find_arg_sizes_pred_6_0_i16,
		STATIC(mercury__term_pass1__find_arg_sizes_pred_6_0));
Define_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i16);
	update_prof_current_proc(LABEL(mercury__term_pass1__find_arg_sizes_pred_6_0));
	MR_stackvar(8) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_5);
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__term_pass1__find_arg_sizes_pred_6_0_i17,
		STATIC(mercury__term_pass1__find_arg_sizes_pred_6_0));
Define_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i17);
	update_prof_current_proc(LABEL(mercury__term_pass1__find_arg_sizes_pred_6_0));
	r3 = r1;
	r1 = MR_stackvar(7);
	r2 = MR_stackvar(8);
	call_localret(STATIC(mercury__term_pass1__update_output_suppliers_4_0),
		mercury__term_pass1__find_arg_sizes_pred_6_0_i18,
		STATIC(mercury__term_pass1__find_arg_sizes_pred_6_0));
Define_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i18);
	update_prof_current_proc(LABEL(mercury__term_pass1__find_arg_sizes_pred_6_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_5);
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__term_pass1__find_arg_sizes_pred_6_0_i19,
		STATIC(mercury__term_pass1__find_arg_sizes_pred_6_0));
Define_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i19);
	update_prof_current_proc(LABEL(mercury__term_pass1__find_arg_sizes_pred_6_0));
	MR_stackvar(4) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_1);
	r2 = MR_stackvar(8);
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury__bag__is_subbag_2_0),
		mercury__term_pass1__find_arg_sizes_pred_6_0_i21,
		STATIC(mercury__term_pass1__find_arg_sizes_pred_6_0));
Define_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i21);
	update_prof_current_proc(LABEL(mercury__term_pass1__find_arg_sizes_pred_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__term_pass1__find_arg_sizes_pred_6_0_i1009);
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 3, mercury__term_pass1__find_arg_sizes_pred_6_0, "term_pass1:pass1_result/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(5);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(4);
	MR_field(MR_mktag(0), r1, (Integer) 2) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
Define_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i1009);
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 3, mercury__term_pass1__find_arg_sizes_pred_6_0, "term_pass1:pass1_result/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(5);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(4);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__term_pass1__find_arg_sizes_pred_6_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__term_pass1__find_arg_sizes_pred_6_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(6);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 4, mercury__term_pass1__find_arg_sizes_pred_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 3) = MR_stackvar(3);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_stackvar(8);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(10);
	MR_field(MR_mktag(1), r2, (Integer) 0) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 2) = r2;
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_tempr1;
	r2 = MR_stackvar(2);
	MR_decr_sp_pop_msg(10);
	proceed();
	}
Define_label(mercury__term_pass1__find_arg_sizes_pred_6_0_i14);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__term_pass1__find_arg_sizes_pred_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
END_MODULE

Declare_entry(mercury__bag__contains_2_0);
Declare_entry(mercury__require__error_1_0);

BEGIN_MODULE(term_pass1_module9)
	init_entry(mercury__term_pass1__update_output_suppliers_4_0);
	init_label(mercury__term_pass1__update_output_suppliers_4_0_i3);
	init_label(mercury__term_pass1__update_output_suppliers_4_0_i10);
	init_label(mercury__term_pass1__update_output_suppliers_4_0_i9);
	init_label(mercury__term_pass1__update_output_suppliers_4_0_i13);
	init_label(mercury__term_pass1__update_output_suppliers_4_0_i8);
BEGIN_CODE

/* code for predicate 'update_output_suppliers'/4 in mode 0 */
Define_static(mercury__term_pass1__update_output_suppliers_4_0);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_pass1__update_output_suppliers_4_0_i3);
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_pass1__update_output_suppliers_4_0_i8);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
Define_label(mercury__term_pass1__update_output_suppliers_4_0_i3);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_pass1__update_output_suppliers_4_0_i8);
	MR_incr_sp_push_msg(6, "term_pass1:update_output_suppliers/4");
	MR_stackvar(6) = (Word) MR_succip;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__bag__contains_2_0),
		mercury__term_pass1__update_output_suppliers_4_0_i10,
		STATIC(mercury__term_pass1__update_output_suppliers_4_0));
Define_label(mercury__term_pass1__update_output_suppliers_4_0_i10);
	update_prof_current_proc(LABEL(mercury__term_pass1__update_output_suppliers_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__term_pass1__update_output_suppliers_4_0_i9);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(3);
	MR_stackvar(4) = (Integer) 1;
	r1 = MR_stackvar(5);
	localcall(mercury__term_pass1__update_output_suppliers_4_0,
		LABEL(mercury__term_pass1__update_output_suppliers_4_0_i13),
		STATIC(mercury__term_pass1__update_output_suppliers_4_0));
Define_label(mercury__term_pass1__update_output_suppliers_4_0_i9);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(3);
	MR_stackvar(4) = MR_stackvar(2);
	r1 = MR_stackvar(5);
	localcall(mercury__term_pass1__update_output_suppliers_4_0,
		LABEL(mercury__term_pass1__update_output_suppliers_4_0_i13),
		STATIC(mercury__term_pass1__update_output_suppliers_4_0));
Define_label(mercury__term_pass1__update_output_suppliers_4_0_i13);
	update_prof_current_proc(LABEL(mercury__term_pass1__update_output_suppliers_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__term_pass1__update_output_suppliers_4_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__term_pass1__update_output_suppliers_4_0_i8);
	r1 = (Word) MR_string_const("update_output_suppliers: Unmatched variables", 44);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__term_pass1__update_output_suppliers_4_0));
END_MODULE

Declare_entry(mercury__varset__init_1_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_lp__type_ctor_info_equation_0;
Declare_entry(mercury__set__init_1_0);
Declare_entry(mercury__map__values_2_0);
Declare_entry(mercury__list__sort_and_remove_dups_2_0);
Declare_entry(mercury__lp__lp_solve_8_0);

BEGIN_MODULE(term_pass1_module10)
	init_entry(mercury__term_pass1__solve_equations_5_0);
	init_label(mercury__term_pass1__solve_equations_5_0_i3);
	init_label(mercury__term_pass1__solve_equations_5_0_i4);
	init_label(mercury__term_pass1__solve_equations_5_0_i5);
	init_label(mercury__term_pass1__solve_equations_5_0_i6);
	init_label(mercury__term_pass1__solve_equations_5_0_i8);
	init_label(mercury__term_pass1__solve_equations_5_0_i9);
	init_label(mercury__term_pass1__solve_equations_5_0_i10);
	init_label(mercury__term_pass1__solve_equations_5_0_i11);
	init_label(mercury__term_pass1__solve_equations_5_0_i12);
	init_label(mercury__term_pass1__solve_equations_5_0_i13);
	init_label(mercury__term_pass1__solve_equations_5_0_i15);
	init_label(mercury__term_pass1__solve_equations_5_0_i16);
	init_label(mercury__term_pass1__solve_equations_5_0_i2);
BEGIN_CODE

/* code for predicate 'solve_equations'/5 in mode 0 */
Define_static(mercury__term_pass1__solve_equations_5_0);
	MR_incr_sp_push_msg(7, "term_pass1:solve_equations/5");
	MR_stackvar(7) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__varset__init_1_0),
		mercury__term_pass1__solve_equations_5_0_i3,
		STATIC(mercury__term_pass1__solve_equations_5_0));
Define_label(mercury__term_pass1__solve_equations_5_0_i3);
	update_prof_current_proc(LABEL(mercury__term_pass1__solve_equations_5_0));
	MR_stackvar(4) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__term_pass1__solve_equations_5_0_i4,
		STATIC(mercury__term_pass1__solve_equations_5_0));
Define_label(mercury__term_pass1__solve_equations_5_0_i4);
	update_prof_current_proc(LABEL(mercury__term_pass1__solve_equations_5_0));
	MR_stackvar(5) = r1;
	r1 = (Word) (Word *) &mercury_data_lp__type_ctor_info_equation_0;
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__term_pass1__solve_equations_5_0_i5,
		STATIC(mercury__term_pass1__solve_equations_5_0));
Define_label(mercury__term_pass1__solve_equations_5_0_i5);
	update_prof_current_proc(LABEL(mercury__term_pass1__solve_equations_5_0));
	r4 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(4);
	call_localret(STATIC(mercury__term_pass1__convert_equations_2_7_0),
		mercury__term_pass1__solve_equations_5_0_i6,
		STATIC(mercury__term_pass1__solve_equations_5_0));
Define_label(mercury__term_pass1__solve_equations_5_0_i6);
	update_prof_current_proc(LABEL(mercury__term_pass1__solve_equations_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__term_pass1__solve_equations_5_0_i2);
	MR_stackvar(6) = r2;
	r1 = (Word) (Word *) &mercury_data_lp__type_ctor_info_equation_0;
	r2 = r4;
	MR_stackvar(1) = r3;
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__term_pass1__solve_equations_5_0_i8,
		STATIC(mercury__term_pass1__solve_equations_5_0));
Define_label(mercury__term_pass1__solve_equations_5_0_i8);
	update_prof_current_proc(LABEL(mercury__term_pass1__solve_equations_5_0));
	MR_stackvar(4) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_0);
	r3 = MR_stackvar(6);
	call_localret(ENTRY(mercury__map__values_2_0),
		mercury__term_pass1__solve_equations_5_0_i9,
		STATIC(mercury__term_pass1__solve_equations_5_0));
Define_label(mercury__term_pass1__solve_equations_5_0_i9);
	update_prof_current_proc(LABEL(mercury__term_pass1__solve_equations_5_0));
	r4 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_7);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_9);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__term_pass1__solve_equations_5_0_i10,
		STATIC(mercury__term_pass1__solve_equations_5_0));
Define_label(mercury__term_pass1__solve_equations_5_0_i10);
	update_prof_current_proc(LABEL(mercury__term_pass1__solve_equations_5_0));
	MR_stackvar(5) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_0);
	r3 = MR_stackvar(6);
	call_localret(ENTRY(mercury__map__values_2_0),
		mercury__term_pass1__solve_equations_5_0_i11,
		STATIC(mercury__term_pass1__solve_equations_5_0));
Define_label(mercury__term_pass1__solve_equations_5_0_i11);
	update_prof_current_proc(LABEL(mercury__term_pass1__solve_equations_5_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_0);
	call_localret(ENTRY(mercury__list__sort_and_remove_dups_2_0),
		mercury__term_pass1__solve_equations_5_0_i12,
		STATIC(mercury__term_pass1__solve_equations_5_0));
Define_label(mercury__term_pass1__solve_equations_5_0_i12);
	update_prof_current_proc(LABEL(mercury__term_pass1__solve_equations_5_0));
	r5 = r1;
	r1 = MR_stackvar(4);
	r2 = (Integer) 1;
	r3 = MR_stackvar(5);
	r4 = MR_stackvar(1);
	r6 = MR_stackvar(3);
	call_localret(ENTRY(mercury__lp__lp_solve_8_0),
		mercury__term_pass1__solve_equations_5_0_i13,
		STATIC(mercury__term_pass1__solve_equations_5_0));
Define_label(mercury__term_pass1__solve_equations_5_0_i13);
	update_prof_current_proc(LABEL(mercury__term_pass1__solve_equations_5_0));
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_pass1__solve_equations_5_0_i15);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__term_pass1__solve_equations_5_0_i15);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 5, mercury__term_pass1__solve_equations_5_0, "origin_lost_in_value_number");
	MR_stackvar(1) = r2;
	MR_field(MR_mktag(0), r3, (Integer) 4) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_10);
	r4 = MR_stackvar(2);
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(6);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 2;
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__term_pass1__lookup_coeff_4_0);
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_14);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__term_pass1__solve_equations_5_0_i16,
		STATIC(mercury__term_pass1__solve_equations_5_0));
Define_label(mercury__term_pass1__solve_equations_5_0_i16);
	update_prof_current_proc(LABEL(mercury__term_pass1__solve_equations_5_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__term_pass1__solve_equations_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__term_pass1__solve_equations_5_0_i2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE

Declare_entry(mercury__int__to_float_2_0);
Declare_entry(mercury__list__map_foldl_5_1);
Declare_entry(mercury__set__insert_3_1);

BEGIN_MODULE(term_pass1_module11)
	init_entry(mercury__term_pass1__convert_equations_2_7_0);
	init_label(mercury__term_pass1__convert_equations_2_7_0_i1002);
	init_label(mercury__term_pass1__convert_equations_2_7_0_i4);
	init_label(mercury__term_pass1__convert_equations_2_7_0_i6);
	init_label(mercury__term_pass1__convert_equations_2_7_0_i5);
	init_label(mercury__term_pass1__convert_equations_2_7_0_i8);
	init_label(mercury__term_pass1__convert_equations_2_7_0_i9);
	init_label(mercury__term_pass1__convert_equations_2_7_0_i11);
	init_label(mercury__term_pass1__convert_equations_2_7_0_i12);
	init_label(mercury__term_pass1__convert_equations_2_7_0_i2);
BEGIN_CODE

/* code for predicate 'convert_equations_2'/7 in mode 0 */
Define_static(mercury__term_pass1__convert_equations_2_7_0);
	MR_incr_sp_push_msg(10, "term_pass1:convert_equations_2/7");
	MR_stackvar(10) = (Word) MR_succip;
Define_label(mercury__term_pass1__convert_equations_2_7_0_i1002);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_pass1__convert_equations_2_7_0_i2);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 2);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 3);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	call_localret(ENTRY(mercury__int__to_float_2_0),
		mercury__term_pass1__convert_equations_2_7_0_i4,
		STATIC(mercury__term_pass1__convert_equations_2_7_0));
	}
Define_label(mercury__term_pass1__convert_equations_2_7_0_i4);
	update_prof_current_proc(LABEL(mercury__term_pass1__convert_equations_2_7_0));
	MR_stackvar(7) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_0);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(5);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__term_pass1__convert_equations_2_7_0_i6,
		STATIC(mercury__term_pass1__convert_equations_2_7_0));
Define_label(mercury__term_pass1__convert_equations_2_7_0_i6);
	update_prof_current_proc(LABEL(mercury__term_pass1__convert_equations_2_7_0));
	if (!(r1))
		GOTO_LABEL(mercury__term_pass1__convert_equations_2_7_0_i5);
	r5 = MR_stackvar(6);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_18);
	tag_incr_hp_msg(r6, MR_mktag(0), (Integer) 2, mercury__term_pass1__convert_equations_2_7_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r6, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(0), r6, (Integer) 1) = MR_stackvar(1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__term_pass1__convert_equations_2_7_0, "origin_lost_in_value_number");
	MR_stackvar(8) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r2;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_7);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_16);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = (Word) &mercury_float_const_1pt00000000000000;
	call_localret(ENTRY(mercury__list__map_foldl_5_1),
		mercury__term_pass1__convert_equations_2_7_0_i11,
		STATIC(mercury__term_pass1__convert_equations_2_7_0));
	}
Define_label(mercury__term_pass1__convert_equations_2_7_0_i5);
	r1 = (Word) (Word *) &mercury_data_term__type_ctor_info_generic_0;
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__varset__new_var_3_0),
		mercury__term_pass1__convert_equations_2_7_0_i8,
		STATIC(mercury__term_pass1__convert_equations_2_7_0));
Define_label(mercury__term_pass1__convert_equations_2_7_0_i8);
	update_prof_current_proc(LABEL(mercury__term_pass1__convert_equations_2_7_0));
	r3 = MR_stackvar(1);
	r5 = r1;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_0);
	r4 = MR_stackvar(5);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__term_pass1__convert_equations_2_7_0_i9,
		STATIC(mercury__term_pass1__convert_equations_2_7_0));
Define_label(mercury__term_pass1__convert_equations_2_7_0_i9);
	update_prof_current_proc(LABEL(mercury__term_pass1__convert_equations_2_7_0));
	r5 = MR_stackvar(6);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_18);
	tag_incr_hp_msg(r6, MR_mktag(0), (Integer) 2, mercury__term_pass1__convert_equations_2_7_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r6, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(0), r6, (Integer) 1) = r1;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__term_pass1__convert_equations_2_7_0, "origin_lost_in_value_number");
	MR_stackvar(8) = MR_tempr1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_7);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_16);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = (Word) &mercury_float_const_1pt00000000000000;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(1);
	call_localret(ENTRY(mercury__list__map_foldl_5_1),
		mercury__term_pass1__convert_equations_2_7_0_i11,
		STATIC(mercury__term_pass1__convert_equations_2_7_0));
	}
Define_label(mercury__term_pass1__convert_equations_2_7_0_i11);
	update_prof_current_proc(LABEL(mercury__term_pass1__convert_equations_2_7_0));
	r4 = r1;
	r6 = MR_stackvar(8);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_lp__type_ctor_info_equation_0;
	r2 = MR_stackvar(3);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 3, mercury__term_pass1__convert_equations_2_7_0, "lp:equation/0");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__term_pass1__convert_equations_2_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = r4;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r6;
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Integer) 2;
	MR_field(MR_mktag(0), r3, (Integer) 2) = MR_stackvar(7);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__term_pass1__convert_equations_2_7_0_i12,
		STATIC(mercury__term_pass1__convert_equations_2_7_0));
	}
Define_label(mercury__term_pass1__convert_equations_2_7_0_i12);
	update_prof_current_proc(LABEL(mercury__term_pass1__convert_equations_2_7_0));
	r4 = r1;
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(9);
	r3 = MR_stackvar(8);
	MR_succip = (Code *) MR_stackvar(10);
	GOTO_LABEL(mercury__term_pass1__convert_equations_2_7_0_i1002);
Define_label(mercury__term_pass1__convert_equations_2_7_0_i2);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
END_MODULE

Declare_entry(mercury__fn__float__ceiling_to_int_1_0);

BEGIN_MODULE(term_pass1_module12)
	init_entry(mercury__term_pass1__lookup_coeff_4_0);
	init_label(mercury__term_pass1__lookup_coeff_4_0_i2);
	init_label(mercury__term_pass1__lookup_coeff_4_0_i3);
	init_label(mercury__term_pass1__lookup_coeff_4_0_i4);
BEGIN_CODE

/* code for predicate 'lookup_coeff'/4 in mode 0 */
Define_static(mercury__term_pass1__lookup_coeff_4_0);
	MR_incr_sp_push_msg(3, "term_pass1:lookup_coeff/4");
	MR_stackvar(3) = (Word) MR_succip;
	r4 = r3;
	MR_stackvar(2) = r3;
	r3 = r1;
	MR_stackvar(1) = r2;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_0);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__term_pass1__lookup_coeff_4_0_i2,
		STATIC(mercury__term_pass1__lookup_coeff_4_0));
Define_label(mercury__term_pass1__lookup_coeff_4_0_i2);
	update_prof_current_proc(LABEL(mercury__term_pass1__lookup_coeff_4_0));
	r4 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_0);
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_float_0;
	r3 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__term_pass1__lookup_coeff_4_0_i3,
		STATIC(mercury__term_pass1__lookup_coeff_4_0));
Define_label(mercury__term_pass1__lookup_coeff_4_0_i3);
	update_prof_current_proc(LABEL(mercury__term_pass1__lookup_coeff_4_0));
	call_localret(ENTRY(mercury__fn__float__ceiling_to_int_1_0),
		mercury__term_pass1__lookup_coeff_4_0_i4,
		STATIC(mercury__term_pass1__lookup_coeff_4_0));
Define_label(mercury__term_pass1__lookup_coeff_4_0_i4);
	update_prof_current_proc(LABEL(mercury__term_pass1__lookup_coeff_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__term_pass1__lookup_coeff_4_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(0), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE

Declare_entry(mercury____Unify___list__list_1_0);

BEGIN_MODULE(term_pass1_module13)
	init_entry(mercury____Unify___term_pass1__arg_size_result_0_0);
	init_label(mercury____Unify___term_pass1__arg_size_result_0_0_i5);
	init_label(mercury____Unify___term_pass1__arg_size_result_0_0_i1005);
	init_label(mercury____Unify___term_pass1__arg_size_result_0_0_i1006);
	init_label(mercury____Unify___term_pass1__arg_size_result_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___term_pass1__arg_size_result_0_0);
	MR_incr_sp_push_msg(3, "term_pass1:__Unify__/2");
	MR_stackvar(3) = (Word) MR_succip;
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Unify___term_pass1__arg_size_result_0_0_i1005);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Unify___term_pass1__arg_size_result_0_0_i1006);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_10);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury____Unify___term_pass1__arg_size_result_0_0_i5,
		ENTRY(mercury____Unify___term_pass1__arg_size_result_0_0));
Define_label(mercury____Unify___term_pass1__arg_size_result_0_0_i5);
	update_prof_current_proc(LABEL(mercury____Unify___term_pass1__arg_size_result_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___term_pass1__arg_size_result_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_5);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___term_pass1__arg_size_result_0_0));
Define_label(mercury____Unify___term_pass1__arg_size_result_0_0_i1005);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Unify___term_pass1__arg_size_result_0_0_i1);
	r3 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_6);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury____Unify___list__list_1_0),
		ENTRY(mercury____Unify___term_pass1__arg_size_result_0_0));
Define_label(mercury____Unify___term_pass1__arg_size_result_0_0_i1006);
	r1 = FALSE;
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury____Unify___term_pass1__arg_size_result_0_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(term_pass1_module14)
	init_entry(mercury____Index___term_pass1__arg_size_result_0_0);
	init_label(mercury____Index___term_pass1__arg_size_result_0_0_i3);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___term_pass1__arg_size_result_0_0);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Index___term_pass1__arg_size_result_0_0_i3);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Index___term_pass1__arg_size_result_0_0_i3);
	r1 = (Integer) 1;
	proceed();
END_MODULE

Declare_entry(mercury____Compare___list__list_1_0);
Declare_entry(mercury____Compare___tree234__tree234_2_0);
Declare_entry(mercury__compare_error_0_0);

BEGIN_MODULE(term_pass1_module15)
	init_entry(mercury____Compare___term_pass1__arg_size_result_0_0);
	init_label(mercury____Compare___term_pass1__arg_size_result_0_0_i3);
	init_label(mercury____Compare___term_pass1__arg_size_result_0_0_i2);
	init_label(mercury____Compare___term_pass1__arg_size_result_0_0_i5);
	init_label(mercury____Compare___term_pass1__arg_size_result_0_0_i4);
	init_label(mercury____Compare___term_pass1__arg_size_result_0_0_i6);
	init_label(mercury____Compare___term_pass1__arg_size_result_0_0_i7);
	init_label(mercury____Compare___term_pass1__arg_size_result_0_0_i14);
	init_label(mercury____Compare___term_pass1__arg_size_result_0_0_i11);
	init_label(mercury____Compare___term_pass1__arg_size_result_0_0_i1015);
	init_label(mercury____Compare___term_pass1__arg_size_result_0_0_i24);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___term_pass1__arg_size_result_0_0);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___term_pass1__arg_size_result_0_0_i3);
	r3 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___term_pass1__arg_size_result_0_0_i2);
Define_label(mercury____Compare___term_pass1__arg_size_result_0_0_i3);
	r3 = (Integer) 1;
Define_label(mercury____Compare___term_pass1__arg_size_result_0_0_i2);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___term_pass1__arg_size_result_0_0_i5);
	r4 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___term_pass1__arg_size_result_0_0_i4);
Define_label(mercury____Compare___term_pass1__arg_size_result_0_0_i5);
	r4 = (Integer) 1;
Define_label(mercury____Compare___term_pass1__arg_size_result_0_0_i4);
	if (((Integer) r3 >= (Integer) r4))
		GOTO_LABEL(mercury____Compare___term_pass1__arg_size_result_0_0_i6);
	r1 = (Integer) 1;
	proceed();
Define_label(mercury____Compare___term_pass1__arg_size_result_0_0_i6);
	if (((Integer) r3 <= (Integer) r4))
		GOTO_LABEL(mercury____Compare___term_pass1__arg_size_result_0_0_i7);
	r1 = (Integer) 2;
	proceed();
Define_label(mercury____Compare___term_pass1__arg_size_result_0_0_i7);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___term_pass1__arg_size_result_0_0_i11);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___term_pass1__arg_size_result_0_0_i1015);
	MR_incr_sp_push_msg(3, "term_pass1:__Compare__/3");
	MR_stackvar(3) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_10);
	call_localret(ENTRY(mercury____Compare___list__list_1_0),
		mercury____Compare___term_pass1__arg_size_result_0_0_i14,
		ENTRY(mercury____Compare___term_pass1__arg_size_result_0_0));
Define_label(mercury____Compare___term_pass1__arg_size_result_0_0_i14);
	update_prof_current_proc(LABEL(mercury____Compare___term_pass1__arg_size_result_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___term_pass1__arg_size_result_0_0_i24);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_5);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___term_pass1__arg_size_result_0_0));
Define_label(mercury____Compare___term_pass1__arg_size_result_0_0_i11);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___term_pass1__arg_size_result_0_0_i1015);
	r3 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_6);
	tailcall(ENTRY(mercury____Compare___list__list_1_0),
		ENTRY(mercury____Compare___term_pass1__arg_size_result_0_0));
Define_label(mercury____Compare___term_pass1__arg_size_result_0_0_i1015);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___term_pass1__arg_size_result_0_0));
Define_label(mercury____Compare___term_pass1__arg_size_result_0_0_i24);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(term_pass1_module16)
	init_entry(mercury____Unify___term_pass1__pass1_result_0_0);
	init_label(mercury____Unify___term_pass1__pass1_result_0_0_i5);
	init_label(mercury____Unify___term_pass1__pass1_result_0_0_i7);
	init_label(mercury____Unify___term_pass1__pass1_result_0_0_i1006);
	init_label(mercury____Unify___term_pass1__pass1_result_0_0_i1007);
	init_label(mercury____Unify___term_pass1__pass1_result_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___term_pass1__pass1_result_0_0);
	MR_incr_sp_push_msg(5, "term_pass1:__Unify__/2");
	MR_stackvar(5) = (Word) MR_succip;
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Unify___term_pass1__pass1_result_0_0_i1006);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Unify___term_pass1__pass1_result_0_0_i1007);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	r1 = (Word) (Word *) &mercury_data_term_traversal__type_ctor_info_path_info_0;
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury____Unify___term_pass1__pass1_result_0_0_i5,
		STATIC(mercury____Unify___term_pass1__pass1_result_0_0));
Define_label(mercury____Unify___term_pass1__pass1_result_0_0_i5);
	update_prof_current_proc(LABEL(mercury____Unify___term_pass1__pass1_result_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___term_pass1__pass1_result_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_5);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(3);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___term_pass1__pass1_result_0_0_i7,
		STATIC(mercury____Unify___term_pass1__pass1_result_0_0));
Define_label(mercury____Unify___term_pass1__pass1_result_0_0_i7);
	update_prof_current_proc(LABEL(mercury____Unify___term_pass1__pass1_result_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___term_pass1__pass1_result_0_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_6);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury____Unify___list__list_1_0),
		STATIC(mercury____Unify___term_pass1__pass1_result_0_0));
Define_label(mercury____Unify___term_pass1__pass1_result_0_0_i1006);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Unify___term_pass1__pass1_result_0_0_i1);
	r3 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_6);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury____Unify___list__list_1_0),
		STATIC(mercury____Unify___term_pass1__pass1_result_0_0));
Define_label(mercury____Unify___term_pass1__pass1_result_0_0_i1007);
	r1 = FALSE;
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury____Unify___term_pass1__pass1_result_0_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE


BEGIN_MODULE(term_pass1_module17)
	init_entry(mercury____Index___term_pass1__pass1_result_0_0);
	init_label(mercury____Index___term_pass1__pass1_result_0_0_i3);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___term_pass1__pass1_result_0_0);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Index___term_pass1__pass1_result_0_0_i3);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Index___term_pass1__pass1_result_0_0_i3);
	r1 = (Integer) 1;
	proceed();
END_MODULE


BEGIN_MODULE(term_pass1_module18)
	init_entry(mercury____Compare___term_pass1__pass1_result_0_0);
	init_label(mercury____Compare___term_pass1__pass1_result_0_0_i3);
	init_label(mercury____Compare___term_pass1__pass1_result_0_0_i2);
	init_label(mercury____Compare___term_pass1__pass1_result_0_0_i5);
	init_label(mercury____Compare___term_pass1__pass1_result_0_0_i4);
	init_label(mercury____Compare___term_pass1__pass1_result_0_0_i6);
	init_label(mercury____Compare___term_pass1__pass1_result_0_0_i7);
	init_label(mercury____Compare___term_pass1__pass1_result_0_0_i14);
	init_label(mercury____Compare___term_pass1__pass1_result_0_0_i18);
	init_label(mercury____Compare___term_pass1__pass1_result_0_0_i11);
	init_label(mercury____Compare___term_pass1__pass1_result_0_0_i1016);
	init_label(mercury____Compare___term_pass1__pass1_result_0_0_i29);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___term_pass1__pass1_result_0_0);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___term_pass1__pass1_result_0_0_i3);
	r3 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___term_pass1__pass1_result_0_0_i2);
Define_label(mercury____Compare___term_pass1__pass1_result_0_0_i3);
	r3 = (Integer) 1;
Define_label(mercury____Compare___term_pass1__pass1_result_0_0_i2);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___term_pass1__pass1_result_0_0_i5);
	r4 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___term_pass1__pass1_result_0_0_i4);
Define_label(mercury____Compare___term_pass1__pass1_result_0_0_i5);
	r4 = (Integer) 1;
Define_label(mercury____Compare___term_pass1__pass1_result_0_0_i4);
	if (((Integer) r3 >= (Integer) r4))
		GOTO_LABEL(mercury____Compare___term_pass1__pass1_result_0_0_i6);
	r1 = (Integer) 1;
	proceed();
Define_label(mercury____Compare___term_pass1__pass1_result_0_0_i6);
	if (((Integer) r3 <= (Integer) r4))
		GOTO_LABEL(mercury____Compare___term_pass1__pass1_result_0_0_i7);
	r1 = (Integer) 2;
	proceed();
Define_label(mercury____Compare___term_pass1__pass1_result_0_0_i7);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___term_pass1__pass1_result_0_0_i11);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___term_pass1__pass1_result_0_0_i1016);
	MR_incr_sp_push_msg(5, "term_pass1:__Compare__/3");
	MR_stackvar(5) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	r1 = (Word) (Word *) &mercury_data_term_traversal__type_ctor_info_path_info_0;
	call_localret(ENTRY(mercury____Compare___list__list_1_0),
		mercury____Compare___term_pass1__pass1_result_0_0_i14,
		STATIC(mercury____Compare___term_pass1__pass1_result_0_0));
Define_label(mercury____Compare___term_pass1__pass1_result_0_0_i14);
	update_prof_current_proc(LABEL(mercury____Compare___term_pass1__pass1_result_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___term_pass1__pass1_result_0_0_i29);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_5);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(3);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___term_pass1__pass1_result_0_0_i18,
		STATIC(mercury____Compare___term_pass1__pass1_result_0_0));
Define_label(mercury____Compare___term_pass1__pass1_result_0_0_i18);
	update_prof_current_proc(LABEL(mercury____Compare___term_pass1__pass1_result_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___term_pass1__pass1_result_0_0_i29);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_6);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury____Compare___list__list_1_0),
		STATIC(mercury____Compare___term_pass1__pass1_result_0_0));
Define_label(mercury____Compare___term_pass1__pass1_result_0_0_i11);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___term_pass1__pass1_result_0_0_i1016);
	r3 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_pass1__common_6);
	tailcall(ENTRY(mercury____Compare___list__list_1_0),
		STATIC(mercury____Compare___term_pass1__pass1_result_0_0));
Define_label(mercury____Compare___term_pass1__pass1_result_0_0_i1016);
	tailcall(ENTRY(mercury__compare_error_0_0),
		STATIC(mercury____Compare___term_pass1__pass1_result_0_0));
Define_label(mercury____Compare___term_pass1__pass1_result_0_0_i29);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__term_pass1_maybe_bunch_0(void)
{
	term_pass1_module0();
	term_pass1_module1();
	term_pass1_module2();
	term_pass1_module3();
	term_pass1_module4();
	term_pass1_module5();
	term_pass1_module6();
	term_pass1_module7();
	term_pass1_module8();
	term_pass1_module9();
	term_pass1_module10();
	term_pass1_module11();
	term_pass1_module12();
	term_pass1_module13();
	term_pass1_module14();
	term_pass1_module15();
	term_pass1_module16();
	term_pass1_module17();
	term_pass1_module18();
}

#endif

void mercury__term_pass1__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__term_pass1__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__term_pass1_maybe_bunch_0();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_term_pass1__type_ctor_info_arg_size_result_0,
			term_pass1__arg_size_result_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_term_pass1__type_ctor_info_pass1_result_0,
			term_pass1__pass1_result_0_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
