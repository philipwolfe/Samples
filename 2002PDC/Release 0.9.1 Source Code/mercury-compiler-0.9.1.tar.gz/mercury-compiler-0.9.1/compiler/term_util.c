/*
** Automatically generated from `term_util.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__term_util__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury____Index___term_util__pass_info_0__ua0_2_0);
Declare_static(mercury____Index___term_util__weight_info_0__ua0_2_0);
Declare_static(mercury__term_util__make_bool_list_2__ua0_3_0);
Declare_label(mercury__term_util__make_bool_list_2__ua0_3_0_i4);
Declare_label(mercury__term_util__make_bool_list_2__ua0_3_0_i5);
Declare_label(mercury__term_util__make_bool_list_2__ua0_3_0_i2);
Declare_static(mercury__term_util__functor_norm__ua0_9_0);
Declare_label(mercury__term_util__functor_norm__ua0_9_0_i1013);
Declare_label(mercury__term_util__functor_norm__ua0_9_0_i1015);
Declare_label(mercury__term_util__functor_norm__ua0_9_0_i27);
Declare_label(mercury__term_util__functor_norm__ua0_9_0_i9);
Declare_label(mercury__term_util__functor_norm__ua0_9_0_i11);
Declare_label(mercury__term_util__functor_norm__ua0_9_0_i15);
Declare_label(mercury__term_util__functor_norm__ua0_9_0_i13);
Declare_label(mercury__term_util__functor_norm__ua0_9_0_i17);
Declare_label(mercury__term_util__functor_norm__ua0_9_0_i10);
Declare_label(mercury__term_util__functor_norm__ua0_9_0_i4);
Declare_label(mercury__term_util__functor_norm__ua0_9_0_i6);
Declare_label(mercury__term_util__functor_norm__ua0_9_0_i5);
Define_extern_entry(mercury__term_util__find_weights_2_0);
Declare_label(mercury__term_util__find_weights_2_0_i2);
Declare_label(mercury__term_util__find_weights_2_0_i3);
Declare_label(mercury__term_util__find_weights_2_0_i4);
Define_extern_entry(mercury__term_util__functor_norm_9_0);
Define_extern_entry(mercury__term_util__partition_call_args_5_0);
Declare_label(mercury__term_util__partition_call_args_5_0_i2);
Declare_label(mercury__term_util__partition_call_args_5_0_i3);
Declare_label(mercury__term_util__partition_call_args_5_0_i4);
Define_extern_entry(mercury__term_util__split_unification_vars_5_0);
Declare_label(mercury__term_util__split_unification_vars_5_0_i4);
Declare_label(mercury__term_util__split_unification_vars_5_0_i7);
Declare_label(mercury__term_util__split_unification_vars_5_0_i3);
Declare_label(mercury__term_util__split_unification_vars_5_0_i11);
Declare_label(mercury__term_util__split_unification_vars_5_0_i14);
Declare_label(mercury__term_util__split_unification_vars_5_0_i16);
Declare_label(mercury__term_util__split_unification_vars_5_0_i12);
Declare_label(mercury__term_util__split_unification_vars_5_0_i18);
Declare_label(mercury__term_util__split_unification_vars_5_0_i20);
Declare_label(mercury__term_util__split_unification_vars_5_0_i22);
Declare_label(mercury__term_util__split_unification_vars_5_0_i17);
Declare_label(mercury__term_util__split_unification_vars_5_0_i9);
Declare_label(mercury__term_util__split_unification_vars_5_0_i25);
Declare_label(mercury__term_util__split_unification_vars_5_0_i2);
Define_extern_entry(mercury__term_util__make_bool_list_3_0);
Declare_label(mercury__term_util__make_bool_list_3_0_i2);
Declare_label(mercury__term_util__make_bool_list_3_0_i5);
Declare_label(mercury__term_util__make_bool_list_3_0_i4);
Declare_label(mercury__term_util__make_bool_list_3_0_i7);
Define_extern_entry(mercury__term_util__remove_unused_args_4_0);
Declare_label(mercury__term_util__remove_unused_args_4_0_i1004);
Declare_label(mercury__term_util__remove_unused_args_4_0_i6);
Declare_label(mercury__term_util__remove_unused_args_4_0_i3);
Declare_label(mercury__term_util__remove_unused_args_4_0_i9);
Declare_label(mercury__term_util__remove_unused_args_4_0_i12);
Declare_label(mercury__term_util__remove_unused_args_4_0_i8);
Declare_label(mercury__term_util__remove_unused_args_4_0_i15);
Declare_label(mercury__term_util__remove_unused_args_4_0_i2);
Define_extern_entry(mercury__term_util__set_pred_proc_ids_arg_size_info_4_0);
Declare_label(mercury__term_util__set_pred_proc_ids_arg_size_info_4_0_i1001);
Declare_label(mercury__term_util__set_pred_proc_ids_arg_size_info_4_0_i4);
Declare_label(mercury__term_util__set_pred_proc_ids_arg_size_info_4_0_i5);
Declare_label(mercury__term_util__set_pred_proc_ids_arg_size_info_4_0_i6);
Declare_label(mercury__term_util__set_pred_proc_ids_arg_size_info_4_0_i7);
Declare_label(mercury__term_util__set_pred_proc_ids_arg_size_info_4_0_i8);
Declare_label(mercury__term_util__set_pred_proc_ids_arg_size_info_4_0_i9);
Declare_label(mercury__term_util__set_pred_proc_ids_arg_size_info_4_0_i10);
Declare_label(mercury__term_util__set_pred_proc_ids_arg_size_info_4_0_i11);
Declare_label(mercury__term_util__set_pred_proc_ids_arg_size_info_4_0_i12);
Declare_label(mercury__term_util__set_pred_proc_ids_arg_size_info_4_0_i3);
Define_extern_entry(mercury__term_util__set_pred_proc_ids_termination_info_4_0);
Declare_label(mercury__term_util__set_pred_proc_ids_termination_info_4_0_i1001);
Declare_label(mercury__term_util__set_pred_proc_ids_termination_info_4_0_i4);
Declare_label(mercury__term_util__set_pred_proc_ids_termination_info_4_0_i5);
Declare_label(mercury__term_util__set_pred_proc_ids_termination_info_4_0_i6);
Declare_label(mercury__term_util__set_pred_proc_ids_termination_info_4_0_i7);
Declare_label(mercury__term_util__set_pred_proc_ids_termination_info_4_0_i8);
Declare_label(mercury__term_util__set_pred_proc_ids_termination_info_4_0_i9);
Declare_label(mercury__term_util__set_pred_proc_ids_termination_info_4_0_i10);
Declare_label(mercury__term_util__set_pred_proc_ids_termination_info_4_0_i11);
Declare_label(mercury__term_util__set_pred_proc_ids_termination_info_4_0_i12);
Declare_label(mercury__term_util__set_pred_proc_ids_termination_info_4_0_i3);
Define_extern_entry(mercury__term_util__lookup_proc_termination_info_3_0);
Declare_label(mercury__term_util__lookup_proc_termination_info_3_0_i2);
Define_extern_entry(mercury__term_util__lookup_proc_arg_size_info_3_0);
Declare_label(mercury__term_util__lookup_proc_arg_size_info_3_0_i2);
Define_extern_entry(mercury__term_util__horder_vars_2_0);
Declare_label(mercury__term_util__horder_vars_2_0_i1002);
Declare_label(mercury__term_util__horder_vars_2_0_i5);
Declare_label(mercury__term_util__horder_vars_2_0_i6);
Declare_label(mercury__term_util__horder_vars_2_0_i3);
Declare_label(mercury__term_util__horder_vars_2_0_i1);
Define_extern_entry(mercury__term_util__zero_size_type_2_0);
Declare_label(mercury__term_util__zero_size_type_2_0_i2);
Declare_label(mercury__term_util__zero_size_type_2_0_i1);
Define_extern_entry(mercury__term_util__get_context_from_scc_3_0);
Declare_label(mercury__term_util__get_context_from_scc_3_0_i4);
Declare_label(mercury__term_util__get_context_from_scc_3_0_i2);
Define_extern_entry(mercury__term_util__add_context_to_termination_info_3_0);
Declare_label(mercury__term_util__add_context_to_termination_info_3_0_i3);
Declare_label(mercury__term_util__add_context_to_termination_info_3_0_i5);
Define_extern_entry(mercury__term_util__add_context_to_arg_size_info_3_0);
Declare_label(mercury__term_util__add_context_to_arg_size_info_3_0_i3);
Declare_label(mercury__term_util__add_context_to_arg_size_info_3_0_i5);
Declare_static(mercury__term_util__find_weights_for_type_list_3_0);
Declare_label(mercury__term_util__find_weights_for_type_list_3_0_i1001);
Declare_label(mercury__term_util__find_weights_for_type_list_3_0_i4);
Declare_label(mercury__term_util__find_weights_for_type_list_3_0_i8);
Declare_label(mercury__term_util__find_weights_for_type_list_3_0_i9);
Declare_label(mercury__term_util__find_weights_for_type_list_3_0_i11);
Declare_label(mercury__term_util__find_weights_for_type_list_3_0_i12);
Declare_label(mercury__term_util__find_weights_for_type_list_3_0_i13);
Declare_label(mercury__term_util__find_weights_for_type_list_3_0_i3);
Declare_static(mercury__term_util__find_weights_for_cons_list_5_0);
Declare_label(mercury__term_util__find_weights_for_cons_list_5_0_i1003);
Declare_label(mercury__term_util__find_weights_for_cons_list_5_0_i4);
Declare_label(mercury__term_util__find_weights_for_cons_list_5_0_i6);
Declare_label(mercury__term_util__find_weights_for_cons_list_5_0_i9);
Declare_label(mercury__term_util__find_weights_for_cons_list_5_0_i7);
Declare_label(mercury__term_util__find_weights_for_cons_list_5_0_i5);
Declare_label(mercury__term_util__find_weights_for_cons_list_5_0_i12);
Declare_label(mercury__term_util__find_weights_for_cons_list_5_0_i3);
Declare_static(mercury__term_util__find_and_count_nonrec_args_5_0);
Declare_label(mercury__term_util__find_and_count_nonrec_args_5_0_i4);
Declare_label(mercury__term_util__find_and_count_nonrec_args_5_0_i6);
Declare_label(mercury__term_util__find_and_count_nonrec_args_5_0_i8);
Declare_label(mercury__term_util__find_and_count_nonrec_args_5_0_i11);
Declare_label(mercury__term_util__find_and_count_nonrec_args_5_0_i1017);
Declare_label(mercury__term_util__find_and_count_nonrec_args_5_0_i1023);
Declare_label(mercury__term_util__find_and_count_nonrec_args_5_0_i14);
Declare_label(mercury__term_util__find_and_count_nonrec_args_5_0_i5);
Declare_label(mercury__term_util__find_and_count_nonrec_args_5_0_i3);
Declare_static(mercury__term_util__functor_norm_filter_args_5_0);
Declare_label(mercury__term_util__functor_norm_filter_args_5_0_i1007);
Declare_label(mercury__term_util__functor_norm_filter_args_5_0_i3);
Declare_label(mercury__term_util__functor_norm_filter_args_5_0_i9);
Declare_label(mercury__term_util__functor_norm_filter_args_5_0_i12);
Declare_label(mercury__term_util__functor_norm_filter_args_5_0_i1);
Declare_static(mercury__term_util__partition_call_args_2_5_0);
Declare_label(mercury__term_util__partition_call_args_2_5_0_i5);
Declare_label(mercury__term_util__partition_call_args_2_5_0_i3);
Declare_label(mercury__term_util__partition_call_args_2_5_0_i9);
Declare_label(mercury__term_util__partition_call_args_2_5_0_i12);
Declare_label(mercury__term_util__partition_call_args_2_5_0_i10);
Declare_label(mercury__term_util__partition_call_args_2_5_0_i16);
Declare_label(mercury__term_util__partition_call_args_2_5_0_i14);
Declare_label(mercury__term_util__partition_call_args_2_5_0_i8);
Define_extern_entry(mercury____Unify___term_util__arg_size_info_0_0);
Declare_label(mercury____Unify___term_util__arg_size_info_0_0_i3);
Declare_label(mercury____Unify___term_util__arg_size_info_0_0_i1);
Define_extern_entry(mercury____Index___term_util__arg_size_info_0_0);
Declare_label(mercury____Index___term_util__arg_size_info_0_0_i3);
Define_extern_entry(mercury____Compare___term_util__arg_size_info_0_0);
Declare_label(mercury____Compare___term_util__arg_size_info_0_0_i3);
Declare_label(mercury____Compare___term_util__arg_size_info_0_0_i2);
Declare_label(mercury____Compare___term_util__arg_size_info_0_0_i5);
Declare_label(mercury____Compare___term_util__arg_size_info_0_0_i4);
Declare_label(mercury____Compare___term_util__arg_size_info_0_0_i6);
Declare_label(mercury____Compare___term_util__arg_size_info_0_0_i7);
Declare_label(mercury____Compare___term_util__arg_size_info_0_0_i14);
Declare_label(mercury____Compare___term_util__arg_size_info_0_0_i11);
Declare_label(mercury____Compare___term_util__arg_size_info_0_0_i1015);
Declare_label(mercury____Compare___term_util__arg_size_info_0_0_i24);
Define_extern_entry(mercury____Unify___term_util__termination_info_0_0);
Declare_label(mercury____Unify___term_util__termination_info_0_0_i3);
Declare_label(mercury____Unify___term_util__termination_info_0_0_i1);
Define_extern_entry(mercury____Index___term_util__termination_info_0_0);
Declare_label(mercury____Index___term_util__termination_info_0_0_i3);
Define_extern_entry(mercury____Compare___term_util__termination_info_0_0);
Declare_label(mercury____Compare___term_util__termination_info_0_0_i3);
Declare_label(mercury____Compare___term_util__termination_info_0_0_i2);
Declare_label(mercury____Compare___term_util__termination_info_0_0_i5);
Declare_label(mercury____Compare___term_util__termination_info_0_0_i4);
Declare_label(mercury____Compare___term_util__termination_info_0_0_i6);
Declare_label(mercury____Compare___term_util__termination_info_0_0_i7);
Declare_label(mercury____Compare___term_util__termination_info_0_0_i11);
Declare_label(mercury____Compare___term_util__termination_info_0_0_i1014);
Define_extern_entry(mercury____Unify___term_util__used_args_0_0);
Define_extern_entry(mercury____Index___term_util__used_args_0_0);
Define_extern_entry(mercury____Compare___term_util__used_args_0_0);
Define_extern_entry(mercury____Unify___term_util__functor_info_0_0);
Declare_label(mercury____Unify___term_util__functor_info_0_0_i12);
Declare_label(mercury____Unify___term_util__functor_info_0_0_i8);
Declare_label(mercury____Unify___term_util__functor_info_0_0_i4);
Declare_label(mercury____Unify___term_util__functor_info_0_0_i1);
Define_extern_entry(mercury____Index___term_util__functor_info_0_0);
Declare_label(mercury____Index___term_util__functor_info_0_0_i6);
Declare_label(mercury____Index___term_util__functor_info_0_0_i5);
Declare_label(mercury____Index___term_util__functor_info_0_0_i4);
Define_extern_entry(mercury____Compare___term_util__functor_info_0_0);
Declare_label(mercury____Compare___term_util__functor_info_0_0_i6);
Declare_label(mercury____Compare___term_util__functor_info_0_0_i5);
Declare_label(mercury____Compare___term_util__functor_info_0_0_i4);
Declare_label(mercury____Compare___term_util__functor_info_0_0_i2);
Declare_label(mercury____Compare___term_util__functor_info_0_0_i11);
Declare_label(mercury____Compare___term_util__functor_info_0_0_i10);
Declare_label(mercury____Compare___term_util__functor_info_0_0_i9);
Declare_label(mercury____Compare___term_util__functor_info_0_0_i7);
Declare_label(mercury____Compare___term_util__functor_info_0_0_i12);
Declare_label(mercury____Compare___term_util__functor_info_0_0_i13);
Declare_label(mercury____Compare___term_util__functor_info_0_0_i24);
Declare_label(mercury____Compare___term_util__functor_info_0_0_i21);
Declare_label(mercury____Compare___term_util__functor_info_0_0_i18);
Declare_label(mercury____Compare___term_util__functor_info_0_0_i1024);
Define_extern_entry(mercury____Unify___term_util__unify_info_0_0);
Define_extern_entry(mercury____Index___term_util__unify_info_0_0);
Define_extern_entry(mercury____Compare___term_util__unify_info_0_0);
Define_extern_entry(mercury____Unify___term_util__weight_info_0_0);
Declare_label(mercury____Unify___term_util__weight_info_0_0_i1);
Define_extern_entry(mercury____Index___term_util__weight_info_0_0);
Define_extern_entry(mercury____Compare___term_util__weight_info_0_0);
Declare_label(mercury____Compare___term_util__weight_info_0_0_i3);
Declare_label(mercury____Compare___term_util__weight_info_0_0_i7);
Define_extern_entry(mercury____Unify___term_util__weight_table_0_0);
Define_extern_entry(mercury____Index___term_util__weight_table_0_0);
Define_extern_entry(mercury____Compare___term_util__weight_table_0_0);
Define_extern_entry(mercury____Unify___term_util__pass_info_0_0);
Declare_label(mercury____Unify___term_util__pass_info_0_0_i2);
Declare_label(mercury____Unify___term_util__pass_info_0_0_i1);
Define_extern_entry(mercury____Index___term_util__pass_info_0_0);
Define_extern_entry(mercury____Compare___term_util__pass_info_0_0);
Declare_label(mercury____Compare___term_util__pass_info_0_0_i3);
Declare_label(mercury____Compare___term_util__pass_info_0_0_i7);
Declare_label(mercury____Compare___term_util__pass_info_0_0_i12);

const struct MR_TypeCtorInfo_struct mercury_data_term_util__type_ctor_info_arg_size_info_0;

const struct MR_TypeCtorInfo_struct mercury_data_term_util__type_ctor_info_functor_info_0;

const struct MR_TypeCtorInfo_struct mercury_data_term_util__type_ctor_info_pass_info_0;

const struct MR_TypeCtorInfo_struct mercury_data_term_util__type_ctor_info_termination_info_0;

const struct MR_TypeCtorInfo_struct mercury_data_term_util__type_ctor_info_unify_info_0;

const struct MR_TypeCtorInfo_struct mercury_data_term_util__type_ctor_info_used_args_0;

const struct MR_TypeCtorInfo_struct mercury_data_term_util__type_ctor_info_weight_info_0;

const struct MR_TypeCtorInfo_struct mercury_data_term_util__type_ctor_info_weight_table_0;

static const struct mercury_data_term_util__common_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_term_util__common_0;

static const struct mercury_data_term_util__common_1_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_term_util__common_1;

static const struct mercury_data_term_util__common_2_struct {
	Word * f1;
	Word * f2;
}  mercury_data_term_util__common_2;

static const struct mercury_data_term_util__common_3_struct {
	Word * f1;
	Word * f2;
}  mercury_data_term_util__common_3;

static const struct mercury_data_term_util__common_4_struct {
	Word * f1;
}  mercury_data_term_util__common_4;

static const struct mercury_data_term_util__common_5_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_term_util__common_5;

static const struct mercury_data_term_util__common_6_struct {
	Integer f1;
	Word * f2;
}  mercury_data_term_util__common_6;

static const struct mercury_data_term_util__common_7_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_term_util__common_7;

static const struct mercury_data_term_util__common_8_struct {
	Word * f1;
	Word * f2;
}  mercury_data_term_util__common_8;

static const struct mercury_data_term_util__common_9_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_term_util__common_9;

static const struct mercury_data_term_util__common_10_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_term_util__common_10;

static const struct mercury_data_term_util__common_11_struct {
	Integer f1;
	Word * f2;
}  mercury_data_term_util__common_11;

static const struct mercury_data_term_util__common_12_struct {
	Word * f1;
}  mercury_data_term_util__common_12;

static const struct mercury_data_term_util__common_13_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	String f4;
	Word * f5;
	Integer f6;
	Integer f7;
}  mercury_data_term_util__common_13;

static const struct mercury_data_term_util__common_14_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_term_util__common_14;

static const struct mercury_data_term_util__common_15_struct {
	Integer f1;
	Word * f2;
}  mercury_data_term_util__common_15;

static const struct mercury_data_term_util__common_16_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_term_util__common_16;

static const struct mercury_data_term_util__common_17_struct {
	Integer f1;
	Word * f2;
}  mercury_data_term_util__common_17;

static const struct mercury_data_term_util__common_18_struct {
	Word * f1;
	Word * f2;
}  mercury_data_term_util__common_18;

static const struct mercury_data_term_util__common_19_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_term_util__common_19;

static const struct mercury_data_term_util__common_20_struct {
	Integer f1;
	String f2;
	Word * f3;
	Integer f4;
	Integer f5;
}  mercury_data_term_util__common_20;

static const struct mercury_data_term_util__common_21_struct {
	Integer f1;
	Integer f2;
	String f3;
}  mercury_data_term_util__common_21;

static const struct mercury_data_term_util__common_22_struct {
	Word * f1;
}  mercury_data_term_util__common_22;

static const struct mercury_data_term_util__common_23_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	String f5;
	Word * f6;
	Integer f7;
	Integer f8;
}  mercury_data_term_util__common_23;

static const struct mercury_data_term_util__common_24_struct {
	Integer f1;
	String f2;
	Word * f3;
	Integer f4;
	Integer f5;
}  mercury_data_term_util__common_24;

static const struct mercury_data_term_util__common_25_struct {
	Integer f1;
	String f2;
	Word * f3;
	Integer f4;
	Integer f5;
}  mercury_data_term_util__common_25;

static const struct mercury_data_term_util__common_26_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_term_util__common_26;

static const struct mercury_data_term_util__common_27_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_term_util__common_27;

static const struct mercury_data_term_util__common_28_struct {
	Integer f1;
	Integer f2;
	String f3;
	String f4;
}  mercury_data_term_util__common_28;

static const struct mercury_data_term_util__common_29_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	String f4;
	Word * f5;
	Integer f6;
	Integer f7;
}  mercury_data_term_util__common_29;

static const struct mercury_data_term_util__common_30_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_term_util__common_30;

static const struct mercury_data_term_util__type_ctor_functors_weight_table_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_term_util__type_ctor_functors_weight_table_0;

static const struct mercury_data_term_util__type_ctor_layout_weight_table_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_term_util__type_ctor_layout_weight_table_0;

static const struct mercury_data_term_util__type_ctor_functors_weight_info_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_term_util__type_ctor_functors_weight_info_0;

static const struct mercury_data_term_util__type_ctor_layout_weight_info_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_term_util__type_ctor_layout_weight_info_0;

static const struct mercury_data_term_util__type_ctor_functors_used_args_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_term_util__type_ctor_functors_used_args_0;

static const struct mercury_data_term_util__type_ctor_layout_used_args_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_term_util__type_ctor_layout_used_args_0;

static const struct mercury_data_term_util__type_ctor_functors_unify_info_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_term_util__type_ctor_functors_unify_info_0;

static const struct mercury_data_term_util__type_ctor_layout_unify_info_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_term_util__type_ctor_layout_unify_info_0;

static const struct mercury_data_term_util__type_ctor_functors_termination_info_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
	Word * f4;
}  mercury_data_term_util__type_ctor_functors_termination_info_0;

static const struct mercury_data_term_util__type_ctor_layout_termination_info_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_term_util__type_ctor_layout_termination_info_0;

static const struct mercury_data_term_util__type_ctor_functors_pass_info_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_term_util__type_ctor_functors_pass_info_0;

static const struct mercury_data_term_util__type_ctor_layout_pass_info_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_term_util__type_ctor_layout_pass_info_0;

static const struct mercury_data_term_util__type_ctor_functors_functor_info_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
	Word * f4;
	Word * f5;
	Word * f6;
}  mercury_data_term_util__type_ctor_functors_functor_info_0;

static const struct mercury_data_term_util__type_ctor_layout_functor_info_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_term_util__type_ctor_layout_functor_info_0;

static const struct mercury_data_term_util__type_ctor_functors_arg_size_info_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
	Word * f4;
}  mercury_data_term_util__type_ctor_functors_arg_size_info_0;

static const struct mercury_data_term_util__type_ctor_layout_arg_size_info_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_term_util__type_ctor_layout_arg_size_info_0;

const struct MR_TypeCtorInfo_struct mercury_data_term_util__type_ctor_info_arg_size_info_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___term_util__arg_size_info_0_0),
	ENTRY(mercury____Index___term_util__arg_size_info_0_0),
	ENTRY(mercury____Compare___term_util__arg_size_info_0_0),
	(Integer) 2,
	(Word *) &mercury_data_term_util__type_ctor_functors_arg_size_info_0,
	(Word *) &mercury_data_term_util__type_ctor_layout_arg_size_info_0,
	MR_string_const("term_util", 9),
	MR_string_const("arg_size_info", 13),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_term_util__type_ctor_info_functor_info_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___term_util__functor_info_0_0),
	ENTRY(mercury____Index___term_util__functor_info_0_0),
	ENTRY(mercury____Compare___term_util__functor_info_0_0),
	(Integer) 2,
	(Word *) &mercury_data_term_util__type_ctor_functors_functor_info_0,
	(Word *) &mercury_data_term_util__type_ctor_layout_functor_info_0,
	MR_string_const("term_util", 9),
	MR_string_const("functor_info", 12),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_term_util__type_ctor_info_pass_info_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___term_util__pass_info_0_0),
	ENTRY(mercury____Index___term_util__pass_info_0_0),
	ENTRY(mercury____Compare___term_util__pass_info_0_0),
	(Integer) 2,
	(Word *) &mercury_data_term_util__type_ctor_functors_pass_info_0,
	(Word *) &mercury_data_term_util__type_ctor_layout_pass_info_0,
	MR_string_const("term_util", 9),
	MR_string_const("pass_info", 9),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_term_util__type_ctor_info_termination_info_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___term_util__termination_info_0_0),
	ENTRY(mercury____Index___term_util__termination_info_0_0),
	ENTRY(mercury____Compare___term_util__termination_info_0_0),
	(Integer) 2,
	(Word *) &mercury_data_term_util__type_ctor_functors_termination_info_0,
	(Word *) &mercury_data_term_util__type_ctor_layout_termination_info_0,
	MR_string_const("term_util", 9),
	MR_string_const("termination_info", 16),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_term_util__type_ctor_info_unify_info_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___term_util__unify_info_0_0),
	ENTRY(mercury____Index___term_util__unify_info_0_0),
	ENTRY(mercury____Compare___term_util__unify_info_0_0),
	(Integer) 6,
	(Word *) &mercury_data_term_util__type_ctor_functors_unify_info_0,
	(Word *) &mercury_data_term_util__type_ctor_layout_unify_info_0,
	MR_string_const("term_util", 9),
	MR_string_const("unify_info", 10),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_term_util__type_ctor_info_used_args_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___term_util__used_args_0_0),
	ENTRY(mercury____Index___term_util__used_args_0_0),
	ENTRY(mercury____Compare___term_util__used_args_0_0),
	(Integer) 6,
	(Word *) &mercury_data_term_util__type_ctor_functors_used_args_0,
	(Word *) &mercury_data_term_util__type_ctor_layout_used_args_0,
	MR_string_const("term_util", 9),
	MR_string_const("used_args", 9),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_term_util__type_ctor_info_weight_info_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___term_util__weight_info_0_0),
	ENTRY(mercury____Index___term_util__weight_info_0_0),
	ENTRY(mercury____Compare___term_util__weight_info_0_0),
	(Integer) 2,
	(Word *) &mercury_data_term_util__type_ctor_functors_weight_info_0,
	(Word *) &mercury_data_term_util__type_ctor_layout_weight_info_0,
	MR_string_const("term_util", 9),
	MR_string_const("weight_info", 11),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_term_util__type_ctor_info_weight_table_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___term_util__weight_table_0_0),
	ENTRY(mercury____Index___term_util__weight_table_0_0),
	ENTRY(mercury____Compare___term_util__weight_table_0_0),
	(Integer) 6,
	(Word *) &mercury_data_term_util__type_ctor_functors_weight_table_0,
	(Word *) &mercury_data_term_util__type_ctor_layout_weight_table_0,
	MR_string_const("term_util", 9),
	MR_string_const("weight_table", 12),
	(Integer) 3
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_pair_2;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_sym_name_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_int_0;
static const struct mercury_data_term_util__common_0_struct mercury_data_term_util__common_0 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_prog_data__type_ctor_info_sym_name_0,
	(Word *) &mercury_data___type_ctor_info_int_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_data__type_ctor_info_cons_id_0;
static const struct mercury_data_term_util__common_1_struct mercury_data_term_util__common_1 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_0),
	(Word *) &mercury_data_hlds_data__type_ctor_info_cons_id_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_var_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_prog_var_type_0;
static const struct mercury_data_term_util__common_2_struct mercury_data_term_util__common_2 = {
	(Word *) &mercury_data_term__type_ctor_info_var_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_term_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_tvar_type_0;
static const struct mercury_data_term_util__common_3_struct mercury_data_term_util__common_3 = {
	(Word *) &mercury_data_term__type_ctor_info_term_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0
};

static const struct mercury_data_term_util__common_4_struct mercury_data_term_util__common_4 = {
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_string_0;
static const struct mercury_data_term_util__common_5_struct mercury_data_term_util__common_5 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data___type_ctor_info_string_0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_3)
};

static const struct mercury_data_term_util__common_6_struct mercury_data_term_util__common_6 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_context_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_term_errors__type_ctor_info_termination_error_0;
static const struct mercury_data_term_util__common_7_struct mercury_data_term_util__common_7 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_term__type_ctor_info_context_0,
	(Word *) &mercury_data_term_errors__type_ctor_info_termination_error_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_list__type_ctor_info_list_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_bool__type_ctor_info_bool_0;
static const struct mercury_data_term_util__common_8_struct mercury_data_term_util__common_8 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data_bool__type_ctor_info_bool_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_tree234__type_ctor_info_tree234_2;
static const struct mercury_data_term_util__common_9_struct mercury_data_term_util__common_9 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_2),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_3)
};

static const struct mercury_data_term_util__common_10_struct mercury_data_term_util__common_10 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_1),
	(Word *) &mercury_data_term_util__type_ctor_info_weight_info_0
};

static const struct mercury_data_term_util__common_11_struct mercury_data_term_util__common_11 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_10)
};

static const struct mercury_data_term_util__common_12_struct mercury_data_term_util__common_12 = {
	(Word *) &mercury_data___type_ctor_info_int_0
};

static const struct mercury_data_term_util__common_13_struct mercury_data_term_util__common_13 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_12),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_8),
	MR_string_const("weight", 6),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
static const struct mercury_data_term_util__common_14_struct mercury_data_term_util__common_14 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_8)
};

static const struct mercury_data_term_util__common_15_struct mercury_data_term_util__common_15 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_14)
};

static const struct mercury_data_term_util__common_16_struct mercury_data_term_util__common_16 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_9),
	(Word *) &mercury_data_term_util__type_ctor_info_functor_info_0
};

static const struct mercury_data_term_util__common_17_struct mercury_data_term_util__common_17 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_16)
};

static const struct mercury_data_term_util__common_18_struct mercury_data_term_util__common_18 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_7)
};

static const struct mercury_data_term_util__common_19_struct mercury_data_term_util__common_19 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_18),
	MR_string_const("can_loop", 8),
	MR_mkword(MR_mktag(1), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_term_util__common_20_struct mercury_data_term_util__common_20 = {
	(Integer) 0,
	MR_string_const("cannot_loop", 11),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_term_util__common_21_struct mercury_data_term_util__common_21 = {
	(Integer) 0,
	(Integer) 1,
	MR_string_const("cannot_loop", 11)
};

static const struct mercury_data_term_util__common_22_struct mercury_data_term_util__common_22 = {
	(Word *) &mercury_data_term_util__type_ctor_info_functor_info_0
};

static const struct mercury_data_term_util__common_23_struct mercury_data_term_util__common_23 = {
	(Integer) 3,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_22),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_12),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_12),
	MR_string_const("pass_info", 9),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_term_util__common_24_struct mercury_data_term_util__common_24 = {
	(Integer) 0,
	MR_string_const("simple", 6),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_term_util__common_25_struct mercury_data_term_util__common_25 = {
	(Integer) 0,
	MR_string_const("total", 5),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_term_util__common_26_struct mercury_data_term_util__common_26 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_10),
	MR_string_const("use_map", 7),
	MR_mkword(MR_mktag(1), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_term_util__common_27_struct mercury_data_term_util__common_27 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_10),
	MR_string_const("use_map_and_args", 16),
	MR_mkword(MR_mktag(2), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_term_util__common_28_struct mercury_data_term_util__common_28 = {
	(Integer) 0,
	(Integer) 2,
	MR_string_const("simple", 6),
	MR_string_const("total", 5)
};

static const struct mercury_data_term_util__common_29_struct mercury_data_term_util__common_29 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_12),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_8),
	MR_string_const("finite", 6),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_term_util__common_30_struct mercury_data_term_util__common_30 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_18),
	MR_string_const("infinite", 8),
	MR_mkword(MR_mktag(1), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_term_util__type_ctor_functors_weight_table_0_struct mercury_data_term_util__type_ctor_functors_weight_table_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_10)
};

static const struct mercury_data_term_util__type_ctor_layout_weight_table_0_struct mercury_data_term_util__type_ctor_layout_weight_table_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_term_util__common_11),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_term_util__common_11),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_term_util__common_11),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_term_util__common_11)
};

static const struct mercury_data_term_util__type_ctor_functors_weight_info_0_struct mercury_data_term_util__type_ctor_functors_weight_info_0 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_13)
};

static const struct mercury_data_term_util__type_ctor_layout_weight_info_0_struct mercury_data_term_util__type_ctor_layout_weight_info_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_util__common_13),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_term_util__type_ctor_functors_used_args_0_struct mercury_data_term_util__type_ctor_functors_used_args_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_14)
};

static const struct mercury_data_term_util__type_ctor_layout_used_args_0_struct mercury_data_term_util__type_ctor_layout_used_args_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_term_util__common_15),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_term_util__common_15),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_term_util__common_15),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_term_util__common_15)
};

static const struct mercury_data_term_util__type_ctor_functors_unify_info_0_struct mercury_data_term_util__type_ctor_functors_unify_info_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_16)
};

static const struct mercury_data_term_util__type_ctor_layout_unify_info_0_struct mercury_data_term_util__type_ctor_layout_unify_info_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_term_util__common_17),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_term_util__common_17),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_term_util__common_17),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_term_util__common_17)
};

static const struct mercury_data_term_util__type_ctor_functors_termination_info_0_struct mercury_data_term_util__type_ctor_functors_termination_info_0 = {
	(Integer) 0,
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_19),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_20)
};

static const struct mercury_data_term_util__type_ctor_layout_termination_info_0_struct mercury_data_term_util__type_ctor_layout_termination_info_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_21),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_util__common_19),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_term_util__type_ctor_functors_pass_info_0_struct mercury_data_term_util__type_ctor_functors_pass_info_0 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_23)
};

static const struct mercury_data_term_util__type_ctor_layout_pass_info_0_struct mercury_data_term_util__type_ctor_layout_pass_info_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_util__common_23),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_term_util__type_ctor_functors_functor_info_0_struct mercury_data_term_util__type_ctor_functors_functor_info_0 = {
	(Integer) 0,
	(Integer) 4,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_24),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_25),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_26),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_27)
};

static const struct mercury_data_term_util__type_ctor_layout_functor_info_0_struct mercury_data_term_util__type_ctor_layout_functor_info_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_28),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_util__common_26),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_util__common_27),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_term_util__type_ctor_functors_arg_size_info_0_struct mercury_data_term_util__type_ctor_functors_arg_size_info_0 = {
	(Integer) 0,
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_29),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_30)
};

static const struct mercury_data_term_util__type_ctor_layout_arg_size_info_0_struct mercury_data_term_util__type_ctor_layout_arg_size_info_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_util__common_29),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_util__common_30),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};


BEGIN_MODULE(term_util_module0)
	init_entry(mercury____Index___term_util__pass_info_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___term_util__pass_info_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___term_util__pass_info_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE


BEGIN_MODULE(term_util_module1)
	init_entry(mercury____Index___term_util__weight_info_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___term_util__weight_info_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___term_util__weight_info_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE


BEGIN_MODULE(term_util_module2)
	init_entry(mercury__term_util__make_bool_list_2__ua0_3_0);
	init_label(mercury__term_util__make_bool_list_2__ua0_3_0_i4);
	init_label(mercury__term_util__make_bool_list_2__ua0_3_0_i5);
	init_label(mercury__term_util__make_bool_list_2__ua0_3_0_i2);
BEGIN_CODE

/* code for predicate 'make_bool_list_2__ua0'/3 in mode 0 */
Define_static(mercury__term_util__make_bool_list_2__ua0_3_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_util__make_bool_list_2__ua0_3_0_i2);
	r4 = (Integer) 0;
Define_label(mercury__term_util__make_bool_list_2__ua0_3_0_i4);
	while (1) {
	r4 = ((Integer) r4 + (Integer) 1);
	r3 = r1;
	r1 = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		continue;
	r1 = r2;
	break; } /* end while */
Define_label(mercury__term_util__make_bool_list_2__ua0_3_0_i5);
	while (1) {
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__term_util__make_bool_list_2__ua0_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	r4 = ((Integer) r4 - (Integer) 1);
	if (((Integer) r4 > (Integer) 0))
		continue;
	proceed();
	break; } /* end while */
Define_label(mercury__term_util__make_bool_list_2__ua0_3_0_i2);
	r1 = r2;
	proceed();
END_MODULE

Declare_entry(mercury__map__search_3_1);
Declare_entry(mercury__require__error_1_0);

BEGIN_MODULE(term_util_module3)
	init_entry(mercury__term_util__functor_norm__ua0_9_0);
	init_label(mercury__term_util__functor_norm__ua0_9_0_i1013);
	init_label(mercury__term_util__functor_norm__ua0_9_0_i1015);
	init_label(mercury__term_util__functor_norm__ua0_9_0_i27);
	init_label(mercury__term_util__functor_norm__ua0_9_0_i9);
	init_label(mercury__term_util__functor_norm__ua0_9_0_i11);
	init_label(mercury__term_util__functor_norm__ua0_9_0_i15);
	init_label(mercury__term_util__functor_norm__ua0_9_0_i13);
	init_label(mercury__term_util__functor_norm__ua0_9_0_i17);
	init_label(mercury__term_util__functor_norm__ua0_9_0_i10);
	init_label(mercury__term_util__functor_norm__ua0_9_0_i4);
	init_label(mercury__term_util__functor_norm__ua0_9_0_i6);
	init_label(mercury__term_util__functor_norm__ua0_9_0_i5);
BEGIN_CODE

/* code for predicate 'functor_norm__ua0'/9 in mode 0 */
Define_static(mercury__term_util__functor_norm__ua0_9_0);
	MR_incr_sp_push_msg(4, "term_util:functor_norm__ua0/9");
	MR_stackvar(4) = (Word) MR_succip;
	if ((MR_tag(r1) == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__term_util__functor_norm__ua0_9_0_i4);
	if ((MR_tag(r1) == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__term_util__functor_norm__ua0_9_0_i9);
	if (((Integer) MR_unmkbody(r1) != (Integer) 0))
		GOTO_LABEL(mercury__term_util__functor_norm__ua0_9_0_i1013);
	if ((MR_tag(r3) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__term_util__functor_norm__ua0_9_0_i1015);
	if (((Integer) MR_const_field(MR_mktag(0), r3, (Integer) 1) == (Integer) 0))
		GOTO_LABEL(mercury__term_util__functor_norm__ua0_9_0_i1015);
	r1 = (Integer) 1;
	r2 = r4;
	r3 = r5;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__term_util__functor_norm__ua0_9_0_i1013);
	if ((MR_tag(r3) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__term_util__functor_norm__ua0_9_0_i27);
	r1 = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	r2 = r4;
	r3 = r5;
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__term_util__functor_norm__ua0_9_0_i1015);
	r1 = (Integer) 0;
	r2 = r4;
	r3 = r5;
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__term_util__functor_norm__ua0_9_0_i27);
	r1 = (Integer) 0;
	r2 = r4;
	r3 = r5;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__term_util__functor_norm__ua0_9_0_i9);
	MR_stackvar(2) = r4;
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 2, mercury__term_util__functor_norm__ua0_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r4, (Integer) 1) = r3;
	r3 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	MR_field(MR_mktag(0), r4, (Integer) 0) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_1);
	r2 = (Word) (Word *) &mercury_data_term_util__type_ctor_info_weight_info_0;
	MR_stackvar(3) = r5;
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__term_util__functor_norm__ua0_9_0_i11,
		STATIC(mercury__term_util__functor_norm__ua0_9_0));
Define_label(mercury__term_util__functor_norm__ua0_9_0_i11);
	update_prof_current_proc(LABEL(mercury__term_util__functor_norm__ua0_9_0));
	if (!(r1))
		GOTO_LABEL(mercury__term_util__functor_norm__ua0_9_0_i10);
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	call_localret(STATIC(mercury__term_util__functor_norm_filter_args_5_0),
		mercury__term_util__functor_norm__ua0_9_0_i15,
		STATIC(mercury__term_util__functor_norm__ua0_9_0));
Define_label(mercury__term_util__functor_norm__ua0_9_0_i15);
	update_prof_current_proc(LABEL(mercury__term_util__functor_norm__ua0_9_0));
	if (!(r1))
		GOTO_LABEL(mercury__term_util__functor_norm__ua0_9_0_i13);
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__term_util__functor_norm__ua0_9_0_i13);
	r1 = (Word) MR_string_const("Unmatched lists in functor_norm_filter_args.", 44);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__term_util__functor_norm__ua0_9_0_i17,
		STATIC(mercury__term_util__functor_norm__ua0_9_0));
Define_label(mercury__term_util__functor_norm__ua0_9_0_i17);
	update_prof_current_proc(LABEL(mercury__term_util__functor_norm__ua0_9_0));
	r2 = MR_stackvar(1);
	r1 = r2;
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__term_util__functor_norm__ua0_9_0_i10);
	r1 = (Integer) 0;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__term_util__functor_norm__ua0_9_0_i4);
	r7 = r2;
	r8 = r3;
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_1);
	r2 = (Word) (Word *) &mercury_data_term_util__type_ctor_info_weight_info_0;
	MR_stackvar(1) = r4;
	MR_stackvar(2) = r5;
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 2, mercury__term_util__functor_norm__ua0_9_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r4, (Integer) 0) = r7;
	MR_field(MR_mktag(0), r4, (Integer) 1) = r8;
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__term_util__functor_norm__ua0_9_0_i6,
		STATIC(mercury__term_util__functor_norm__ua0_9_0));
Define_label(mercury__term_util__functor_norm__ua0_9_0_i6);
	update_prof_current_proc(LABEL(mercury__term_util__functor_norm__ua0_9_0));
	if (!(r1))
		GOTO_LABEL(mercury__term_util__functor_norm__ua0_9_0_i5);
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__term_util__functor_norm__ua0_9_0_i5);
	r1 = (Integer) 0;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_module__module_info_types_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_data__type_ctor_info_hlds_type_defn_0;
Declare_entry(mercury__map__to_assoc_list_2_0);
Declare_entry(mercury__map__init_1_0);

BEGIN_MODULE(term_util_module4)
	init_entry(mercury__term_util__find_weights_2_0);
	init_label(mercury__term_util__find_weights_2_0_i2);
	init_label(mercury__term_util__find_weights_2_0_i3);
	init_label(mercury__term_util__find_weights_2_0_i4);
BEGIN_CODE

/* code for predicate 'find_weights'/2 in mode 0 */
Define_entry(mercury__term_util__find_weights_2_0);
	MR_incr_sp_push_msg(2, "term_util:find_weights/2");
	MR_stackvar(2) = (Word) MR_succip;
	call_localret(ENTRY(mercury__hlds_module__module_info_types_2_0),
		mercury__term_util__find_weights_2_0_i2,
		ENTRY(mercury__term_util__find_weights_2_0));
Define_label(mercury__term_util__find_weights_2_0_i2);
	update_prof_current_proc(LABEL(mercury__term_util__find_weights_2_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_0);
	r2 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_hlds_type_defn_0;
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__term_util__find_weights_2_0_i3,
		ENTRY(mercury__term_util__find_weights_2_0));
Define_label(mercury__term_util__find_weights_2_0_i3);
	update_prof_current_proc(LABEL(mercury__term_util__find_weights_2_0));
	MR_stackvar(1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_1);
	r2 = (Word) (Word *) &mercury_data_term_util__type_ctor_info_weight_info_0;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__term_util__find_weights_2_0_i4,
		ENTRY(mercury__term_util__find_weights_2_0));
Define_label(mercury__term_util__find_weights_2_0_i4);
	update_prof_current_proc(LABEL(mercury__term_util__find_weights_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__term_util__find_weights_for_type_list_3_0),
		ENTRY(mercury__term_util__find_weights_2_0));
END_MODULE


BEGIN_MODULE(term_util_module5)
	init_entry(mercury__term_util__functor_norm_9_0);
BEGIN_CODE

/* code for predicate 'functor_norm'/9 in mode 0 */
Define_entry(mercury__term_util__functor_norm_9_0);
	r4 = r5;
	r5 = r6;
	tailcall(STATIC(mercury__term_util__functor_norm__ua0_9_0),
		ENTRY(mercury__term_util__functor_norm_9_0));
END_MODULE

Declare_entry(mercury__bag__from_list_2_0);

BEGIN_MODULE(term_util_module6)
	init_entry(mercury__term_util__partition_call_args_5_0);
	init_label(mercury__term_util__partition_call_args_5_0_i2);
	init_label(mercury__term_util__partition_call_args_5_0_i3);
	init_label(mercury__term_util__partition_call_args_5_0_i4);
BEGIN_CODE

/* code for predicate 'partition_call_args'/5 in mode 0 */
Define_entry(mercury__term_util__partition_call_args_5_0);
	MR_incr_sp_push_msg(2, "term_util:partition_call_args/5");
	MR_stackvar(2) = (Word) MR_succip;
	call_localret(STATIC(mercury__term_util__partition_call_args_2_5_0),
		mercury__term_util__partition_call_args_5_0_i2,
		ENTRY(mercury__term_util__partition_call_args_5_0));
Define_label(mercury__term_util__partition_call_args_5_0_i2);
	update_prof_current_proc(LABEL(mercury__term_util__partition_call_args_5_0));
	MR_stackvar(1) = r2;
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_2);
	call_localret(ENTRY(mercury__bag__from_list_2_0),
		mercury__term_util__partition_call_args_5_0_i3,
		ENTRY(mercury__term_util__partition_call_args_5_0));
Define_label(mercury__term_util__partition_call_args_5_0_i3);
	update_prof_current_proc(LABEL(mercury__term_util__partition_call_args_5_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_2);
	call_localret(ENTRY(mercury__bag__from_list_2_0),
		mercury__term_util__partition_call_args_5_0_i4,
		ENTRY(mercury__term_util__partition_call_args_5_0));
Define_label(mercury__term_util__partition_call_args_5_0_i4);
	update_prof_current_proc(LABEL(mercury__term_util__partition_call_args_5_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE

Declare_entry(mercury__bag__init_1_0);
Declare_entry(mercury__inst_match__inst_is_bound_2_0);
Declare_entry(mercury__bag__insert_3_0);
Declare_entry(mercury__inst_match__inst_is_free_2_0);

BEGIN_MODULE(term_util_module7)
	init_entry(mercury__term_util__split_unification_vars_5_0);
	init_label(mercury__term_util__split_unification_vars_5_0_i4);
	init_label(mercury__term_util__split_unification_vars_5_0_i7);
	init_label(mercury__term_util__split_unification_vars_5_0_i3);
	init_label(mercury__term_util__split_unification_vars_5_0_i11);
	init_label(mercury__term_util__split_unification_vars_5_0_i14);
	init_label(mercury__term_util__split_unification_vars_5_0_i16);
	init_label(mercury__term_util__split_unification_vars_5_0_i12);
	init_label(mercury__term_util__split_unification_vars_5_0_i18);
	init_label(mercury__term_util__split_unification_vars_5_0_i20);
	init_label(mercury__term_util__split_unification_vars_5_0_i22);
	init_label(mercury__term_util__split_unification_vars_5_0_i17);
	init_label(mercury__term_util__split_unification_vars_5_0_i9);
	init_label(mercury__term_util__split_unification_vars_5_0_i25);
	init_label(mercury__term_util__split_unification_vars_5_0_i2);
BEGIN_CODE

/* code for predicate 'split_unification_vars'/5 in mode 0 */
Define_entry(mercury__term_util__split_unification_vars_5_0);
	MR_incr_sp_push_msg(7, "term_util:split_unification_vars/5");
	MR_stackvar(7) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_util__split_unification_vars_5_0_i3);
	MR_stackvar(1) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_2);
	call_localret(ENTRY(mercury__bag__init_1_0),
		mercury__term_util__split_unification_vars_5_0_i4,
		ENTRY(mercury__term_util__split_unification_vars_5_0));
Define_label(mercury__term_util__split_unification_vars_5_0_i4);
	update_prof_current_proc(LABEL(mercury__term_util__split_unification_vars_5_0));
	r2 = r1;
	if (((Integer) MR_stackvar(1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_util__split_unification_vars_5_0_i2);
	MR_stackvar(1) = r1;
	r1 = (Word) MR_string_const("term_util:split_unification_vars: Unmatched Variables", 53);
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__term_util__split_unification_vars_5_0_i7,
		ENTRY(mercury__term_util__split_unification_vars_5_0));
Define_label(mercury__term_util__split_unification_vars_5_0_i7);
	update_prof_current_proc(LABEL(mercury__term_util__split_unification_vars_5_0));
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__term_util__split_unification_vars_5_0_i3);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_util__split_unification_vars_5_0_i9);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	MR_stackvar(1) = r3;
	localcall(mercury__term_util__split_unification_vars_5_0,
		LABEL(mercury__term_util__split_unification_vars_5_0_i11),
		ENTRY(mercury__term_util__split_unification_vars_5_0));
Define_label(mercury__term_util__split_unification_vars_5_0_i11);
	update_prof_current_proc(LABEL(mercury__term_util__split_unification_vars_5_0));
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(3);
	r3 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0), (Integer) 1);
	MR_stackvar(4) = r2;
	r2 = r3;
	MR_stackvar(5) = r3;
	MR_stackvar(6) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1), (Integer) 1);
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__inst_match__inst_is_bound_2_0),
		mercury__term_util__split_unification_vars_5_0_i14,
		ENTRY(mercury__term_util__split_unification_vars_5_0));
	}
Define_label(mercury__term_util__split_unification_vars_5_0_i14);
	update_prof_current_proc(LABEL(mercury__term_util__split_unification_vars_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__term_util__split_unification_vars_5_0_i12);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_2);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__bag__insert_3_0),
		mercury__term_util__split_unification_vars_5_0_i16,
		ENTRY(mercury__term_util__split_unification_vars_5_0));
Define_label(mercury__term_util__split_unification_vars_5_0_i16);
	update_prof_current_proc(LABEL(mercury__term_util__split_unification_vars_5_0));
	r2 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__term_util__split_unification_vars_5_0_i12);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(5);
	call_localret(ENTRY(mercury__inst_match__inst_is_free_2_0),
		mercury__term_util__split_unification_vars_5_0_i18,
		ENTRY(mercury__term_util__split_unification_vars_5_0));
Define_label(mercury__term_util__split_unification_vars_5_0_i18);
	update_prof_current_proc(LABEL(mercury__term_util__split_unification_vars_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__term_util__split_unification_vars_5_0_i17);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(6);
	call_localret(ENTRY(mercury__inst_match__inst_is_bound_2_0),
		mercury__term_util__split_unification_vars_5_0_i20,
		ENTRY(mercury__term_util__split_unification_vars_5_0));
Define_label(mercury__term_util__split_unification_vars_5_0_i20);
	update_prof_current_proc(LABEL(mercury__term_util__split_unification_vars_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__term_util__split_unification_vars_5_0_i17);
	MR_stackvar(1) = MR_stackvar(3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_2);
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__bag__insert_3_0),
		mercury__term_util__split_unification_vars_5_0_i22,
		ENTRY(mercury__term_util__split_unification_vars_5_0));
Define_label(mercury__term_util__split_unification_vars_5_0_i22);
	update_prof_current_proc(LABEL(mercury__term_util__split_unification_vars_5_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__term_util__split_unification_vars_5_0_i17);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__term_util__split_unification_vars_5_0_i9);
	r1 = (Word) MR_string_const("term_util__split_unification_vars: Unmatched Variables", 54);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__term_util__split_unification_vars_5_0_i25,
		ENTRY(mercury__term_util__split_unification_vars_5_0));
Define_label(mercury__term_util__split_unification_vars_5_0_i25);
	update_prof_current_proc(LABEL(mercury__term_util__split_unification_vars_5_0));
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
Define_label(mercury__term_util__split_unification_vars_5_0_i2);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE

Declare_entry(mercury__list__length_2_0);
Declare_entry(mercury__list__drop_3_0);

BEGIN_MODULE(term_util_module8)
	init_entry(mercury__term_util__make_bool_list_3_0);
	init_label(mercury__term_util__make_bool_list_3_0_i2);
	init_label(mercury__term_util__make_bool_list_3_0_i5);
	init_label(mercury__term_util__make_bool_list_3_0_i4);
	init_label(mercury__term_util__make_bool_list_3_0_i7);
BEGIN_CODE

/* code for predicate 'make_bool_list'/3 in mode 0 */
Define_entry(mercury__term_util__make_bool_list_3_0);
	MR_incr_sp_push_msg(4, "term_util:make_bool_list/3");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r2;
	MR_stackvar(3) = r1;
	r1 = (Word) (Word *) &mercury_data_bool__type_ctor_info_bool_0;
	r2 = r3;
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__term_util__make_bool_list_3_0_i2,
		ENTRY(mercury__term_util__make_bool_list_3_0));
Define_label(mercury__term_util__make_bool_list_3_0_i2);
	update_prof_current_proc(LABEL(mercury__term_util__make_bool_list_3_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	r3 = MR_stackvar(1);
	call_localret(ENTRY(mercury__list__drop_3_0),
		mercury__term_util__make_bool_list_3_0_i5,
		ENTRY(mercury__term_util__make_bool_list_3_0));
Define_label(mercury__term_util__make_bool_list_3_0_i5);
	update_prof_current_proc(LABEL(mercury__term_util__make_bool_list_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__term_util__make_bool_list_3_0_i4);
	r1 = r2;
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__term_util__make_bool_list_2__ua0_3_0),
		ENTRY(mercury__term_util__make_bool_list_3_0));
Define_label(mercury__term_util__make_bool_list_3_0_i4);
	r1 = (Word) MR_string_const("Unmatched variables in term_util:make_bool_list", 47);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__term_util__make_bool_list_3_0_i7,
		ENTRY(mercury__term_util__make_bool_list_3_0));
Define_label(mercury__term_util__make_bool_list_3_0_i7);
	update_prof_current_proc(LABEL(mercury__term_util__make_bool_list_3_0));
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__term_util__make_bool_list_2__ua0_3_0),
		ENTRY(mercury__term_util__make_bool_list_3_0));
END_MODULE

Declare_entry(mercury__bag__delete_3_0);

BEGIN_MODULE(term_util_module9)
	init_entry(mercury__term_util__remove_unused_args_4_0);
	init_label(mercury__term_util__remove_unused_args_4_0_i1004);
	init_label(mercury__term_util__remove_unused_args_4_0_i6);
	init_label(mercury__term_util__remove_unused_args_4_0_i3);
	init_label(mercury__term_util__remove_unused_args_4_0_i9);
	init_label(mercury__term_util__remove_unused_args_4_0_i12);
	init_label(mercury__term_util__remove_unused_args_4_0_i8);
	init_label(mercury__term_util__remove_unused_args_4_0_i15);
	init_label(mercury__term_util__remove_unused_args_4_0_i2);
BEGIN_CODE

/* code for predicate 'remove_unused_args'/4 in mode 0 */
Define_entry(mercury__term_util__remove_unused_args_4_0);
	MR_incr_sp_push_msg(3, "term_util:remove_unused_args/4");
	MR_stackvar(3) = (Word) MR_succip;
Define_label(mercury__term_util__remove_unused_args_4_0_i1004);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_util__remove_unused_args_4_0_i3);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_util__remove_unused_args_4_0_i2);
	MR_stackvar(1) = r1;
	r1 = (Word) MR_string_const("Unmatched variables in term_util:remove_unused_args", 51);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__term_util__remove_unused_args_4_0_i6,
		ENTRY(mercury__term_util__remove_unused_args_4_0));
Define_label(mercury__term_util__remove_unused_args_4_0_i6);
	update_prof_current_proc(LABEL(mercury__term_util__remove_unused_args_4_0));
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__term_util__remove_unused_args_4_0_i3);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_util__remove_unused_args_4_0_i8);
	r4 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r5 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r6 = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	if (((Integer) MR_const_field(MR_mktag(1), r3, (Integer) 0) != (Integer) 1))
		GOTO_LABEL(mercury__term_util__remove_unused_args_4_0_i9);
	r2 = r5;
	r3 = r6;
	MR_succip = (Code *) MR_stackvar(3);
	GOTO_LABEL(mercury__term_util__remove_unused_args_4_0_i1004);
Define_label(mercury__term_util__remove_unused_args_4_0_i9);
	MR_stackvar(1) = r6;
	MR_stackvar(2) = r5;
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_2);
	r3 = r4;
	call_localret(ENTRY(mercury__bag__delete_3_0),
		mercury__term_util__remove_unused_args_4_0_i12,
		ENTRY(mercury__term_util__remove_unused_args_4_0));
Define_label(mercury__term_util__remove_unused_args_4_0_i12);
	update_prof_current_proc(LABEL(mercury__term_util__remove_unused_args_4_0));
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	GOTO_LABEL(mercury__term_util__remove_unused_args_4_0_i1004);
Define_label(mercury__term_util__remove_unused_args_4_0_i8);
	MR_stackvar(1) = r1;
	r1 = (Word) MR_string_const("Unmatched variables in term_util__remove_unused_args", 52);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__term_util__remove_unused_args_4_0_i15,
		ENTRY(mercury__term_util__remove_unused_args_4_0));
Define_label(mercury__term_util__remove_unused_args_4_0_i15);
	update_prof_current_proc(LABEL(mercury__term_util__remove_unused_args_4_0));
	r1 = MR_stackvar(1);
Define_label(mercury__term_util__remove_unused_args_4_0_i2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_module__module_info_preds_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_id_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_info_0;
Declare_entry(mercury__map__lookup_3_0);
Declare_entry(mercury__hlds_pred__pred_info_procedures_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_proc_id_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_proc_info_0;
Declare_entry(mercury__hlds_pred__proc_info_set_maybe_arg_size_info_3_0);
Declare_entry(mercury__map__det_update_4_0);
Declare_entry(mercury__hlds_pred__pred_info_set_procedures_3_0);
Declare_entry(mercury__hlds_module__module_info_set_preds_3_0);

BEGIN_MODULE(term_util_module10)
	init_entry(mercury__term_util__set_pred_proc_ids_arg_size_info_4_0);
	init_label(mercury__term_util__set_pred_proc_ids_arg_size_info_4_0_i1001);
	init_label(mercury__term_util__set_pred_proc_ids_arg_size_info_4_0_i4);
	init_label(mercury__term_util__set_pred_proc_ids_arg_size_info_4_0_i5);
	init_label(mercury__term_util__set_pred_proc_ids_arg_size_info_4_0_i6);
	init_label(mercury__term_util__set_pred_proc_ids_arg_size_info_4_0_i7);
	init_label(mercury__term_util__set_pred_proc_ids_arg_size_info_4_0_i8);
	init_label(mercury__term_util__set_pred_proc_ids_arg_size_info_4_0_i9);
	init_label(mercury__term_util__set_pred_proc_ids_arg_size_info_4_0_i10);
	init_label(mercury__term_util__set_pred_proc_ids_arg_size_info_4_0_i11);
	init_label(mercury__term_util__set_pred_proc_ids_arg_size_info_4_0_i12);
	init_label(mercury__term_util__set_pred_proc_ids_arg_size_info_4_0_i3);
BEGIN_CODE

/* code for predicate 'set_pred_proc_ids_arg_size_info'/4 in mode 0 */
Define_entry(mercury__term_util__set_pred_proc_ids_arg_size_info_4_0);
	MR_incr_sp_push_msg(9, "term_util:set_pred_proc_ids_arg_size_info/4");
	MR_stackvar(9) = (Word) MR_succip;
Define_label(mercury__term_util__set_pred_proc_ids_arg_size_info_4_0_i1001);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_util__set_pred_proc_ids_arg_size_info_4_0_i3);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r1 = r3;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__term_util__set_pred_proc_ids_arg_size_info_4_0_i4,
		ENTRY(mercury__term_util__set_pred_proc_ids_arg_size_info_4_0));
	}
Define_label(mercury__term_util__set_pred_proc_ids_arg_size_info_4_0_i4);
	update_prof_current_proc(LABEL(mercury__term_util__set_pred_proc_ids_arg_size_info_4_0));
	r3 = r1;
	MR_stackvar(6) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	r4 = MR_stackvar(4);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__term_util__set_pred_proc_ids_arg_size_info_4_0_i5,
		ENTRY(mercury__term_util__set_pred_proc_ids_arg_size_info_4_0));
Define_label(mercury__term_util__set_pred_proc_ids_arg_size_info_4_0_i5);
	update_prof_current_proc(LABEL(mercury__term_util__set_pred_proc_ids_arg_size_info_4_0));
	MR_stackvar(7) = r1;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procedures_2_0),
		mercury__term_util__set_pred_proc_ids_arg_size_info_4_0_i6,
		ENTRY(mercury__term_util__set_pred_proc_ids_arg_size_info_4_0));
Define_label(mercury__term_util__set_pred_proc_ids_arg_size_info_4_0_i6);
	update_prof_current_proc(LABEL(mercury__term_util__set_pred_proc_ids_arg_size_info_4_0));
	r3 = r1;
	MR_stackvar(8) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0;
	r4 = MR_stackvar(5);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__term_util__set_pred_proc_ids_arg_size_info_4_0_i7,
		ENTRY(mercury__term_util__set_pred_proc_ids_arg_size_info_4_0));
Define_label(mercury__term_util__set_pred_proc_ids_arg_size_info_4_0_i7);
	update_prof_current_proc(LABEL(mercury__term_util__set_pred_proc_ids_arg_size_info_4_0));
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__term_util__set_pred_proc_ids_arg_size_info_4_0, "std_util:maybe/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_set_maybe_arg_size_info_3_0),
		mercury__term_util__set_pred_proc_ids_arg_size_info_4_0_i8,
		ENTRY(mercury__term_util__set_pred_proc_ids_arg_size_info_4_0));
Define_label(mercury__term_util__set_pred_proc_ids_arg_size_info_4_0_i8);
	update_prof_current_proc(LABEL(mercury__term_util__set_pred_proc_ids_arg_size_info_4_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0;
	r3 = MR_stackvar(8);
	r4 = MR_stackvar(5);
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__term_util__set_pred_proc_ids_arg_size_info_4_0_i9,
		ENTRY(mercury__term_util__set_pred_proc_ids_arg_size_info_4_0));
Define_label(mercury__term_util__set_pred_proc_ids_arg_size_info_4_0_i9);
	update_prof_current_proc(LABEL(mercury__term_util__set_pred_proc_ids_arg_size_info_4_0));
	r2 = r1;
	r1 = MR_stackvar(7);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_set_procedures_3_0),
		mercury__term_util__set_pred_proc_ids_arg_size_info_4_0_i10,
		ENTRY(mercury__term_util__set_pred_proc_ids_arg_size_info_4_0));
Define_label(mercury__term_util__set_pred_proc_ids_arg_size_info_4_0_i10);
	update_prof_current_proc(LABEL(mercury__term_util__set_pred_proc_ids_arg_size_info_4_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	r3 = MR_stackvar(6);
	r4 = MR_stackvar(4);
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__term_util__set_pred_proc_ids_arg_size_info_4_0_i11,
		ENTRY(mercury__term_util__set_pred_proc_ids_arg_size_info_4_0));
Define_label(mercury__term_util__set_pred_proc_ids_arg_size_info_4_0_i11);
	update_prof_current_proc(LABEL(mercury__term_util__set_pred_proc_ids_arg_size_info_4_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__hlds_module__module_info_set_preds_3_0),
		mercury__term_util__set_pred_proc_ids_arg_size_info_4_0_i12,
		ENTRY(mercury__term_util__set_pred_proc_ids_arg_size_info_4_0));
Define_label(mercury__term_util__set_pred_proc_ids_arg_size_info_4_0_i12);
	update_prof_current_proc(LABEL(mercury__term_util__set_pred_proc_ids_arg_size_info_4_0));
	r3 = r1;
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(9);
	GOTO_LABEL(mercury__term_util__set_pred_proc_ids_arg_size_info_4_0_i1001);
Define_label(mercury__term_util__set_pred_proc_ids_arg_size_info_4_0_i3);
	r1 = r3;
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_pred__proc_info_set_maybe_termination_info_3_0);

BEGIN_MODULE(term_util_module11)
	init_entry(mercury__term_util__set_pred_proc_ids_termination_info_4_0);
	init_label(mercury__term_util__set_pred_proc_ids_termination_info_4_0_i1001);
	init_label(mercury__term_util__set_pred_proc_ids_termination_info_4_0_i4);
	init_label(mercury__term_util__set_pred_proc_ids_termination_info_4_0_i5);
	init_label(mercury__term_util__set_pred_proc_ids_termination_info_4_0_i6);
	init_label(mercury__term_util__set_pred_proc_ids_termination_info_4_0_i7);
	init_label(mercury__term_util__set_pred_proc_ids_termination_info_4_0_i8);
	init_label(mercury__term_util__set_pred_proc_ids_termination_info_4_0_i9);
	init_label(mercury__term_util__set_pred_proc_ids_termination_info_4_0_i10);
	init_label(mercury__term_util__set_pred_proc_ids_termination_info_4_0_i11);
	init_label(mercury__term_util__set_pred_proc_ids_termination_info_4_0_i12);
	init_label(mercury__term_util__set_pred_proc_ids_termination_info_4_0_i3);
BEGIN_CODE

/* code for predicate 'set_pred_proc_ids_termination_info'/4 in mode 0 */
Define_entry(mercury__term_util__set_pred_proc_ids_termination_info_4_0);
	MR_incr_sp_push_msg(9, "term_util:set_pred_proc_ids_termination_info/4");
	MR_stackvar(9) = (Word) MR_succip;
Define_label(mercury__term_util__set_pred_proc_ids_termination_info_4_0_i1001);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_util__set_pred_proc_ids_termination_info_4_0_i3);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r1 = r3;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__term_util__set_pred_proc_ids_termination_info_4_0_i4,
		ENTRY(mercury__term_util__set_pred_proc_ids_termination_info_4_0));
	}
Define_label(mercury__term_util__set_pred_proc_ids_termination_info_4_0_i4);
	update_prof_current_proc(LABEL(mercury__term_util__set_pred_proc_ids_termination_info_4_0));
	r3 = r1;
	MR_stackvar(6) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	r4 = MR_stackvar(4);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__term_util__set_pred_proc_ids_termination_info_4_0_i5,
		ENTRY(mercury__term_util__set_pred_proc_ids_termination_info_4_0));
Define_label(mercury__term_util__set_pred_proc_ids_termination_info_4_0_i5);
	update_prof_current_proc(LABEL(mercury__term_util__set_pred_proc_ids_termination_info_4_0));
	MR_stackvar(7) = r1;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procedures_2_0),
		mercury__term_util__set_pred_proc_ids_termination_info_4_0_i6,
		ENTRY(mercury__term_util__set_pred_proc_ids_termination_info_4_0));
Define_label(mercury__term_util__set_pred_proc_ids_termination_info_4_0_i6);
	update_prof_current_proc(LABEL(mercury__term_util__set_pred_proc_ids_termination_info_4_0));
	r3 = r1;
	MR_stackvar(8) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0;
	r4 = MR_stackvar(5);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__term_util__set_pred_proc_ids_termination_info_4_0_i7,
		ENTRY(mercury__term_util__set_pred_proc_ids_termination_info_4_0));
Define_label(mercury__term_util__set_pred_proc_ids_termination_info_4_0_i7);
	update_prof_current_proc(LABEL(mercury__term_util__set_pred_proc_ids_termination_info_4_0));
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__term_util__set_pred_proc_ids_termination_info_4_0, "std_util:maybe/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_set_maybe_termination_info_3_0),
		mercury__term_util__set_pred_proc_ids_termination_info_4_0_i8,
		ENTRY(mercury__term_util__set_pred_proc_ids_termination_info_4_0));
Define_label(mercury__term_util__set_pred_proc_ids_termination_info_4_0_i8);
	update_prof_current_proc(LABEL(mercury__term_util__set_pred_proc_ids_termination_info_4_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0;
	r3 = MR_stackvar(8);
	r4 = MR_stackvar(5);
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__term_util__set_pred_proc_ids_termination_info_4_0_i9,
		ENTRY(mercury__term_util__set_pred_proc_ids_termination_info_4_0));
Define_label(mercury__term_util__set_pred_proc_ids_termination_info_4_0_i9);
	update_prof_current_proc(LABEL(mercury__term_util__set_pred_proc_ids_termination_info_4_0));
	r2 = r1;
	r1 = MR_stackvar(7);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_set_procedures_3_0),
		mercury__term_util__set_pred_proc_ids_termination_info_4_0_i10,
		ENTRY(mercury__term_util__set_pred_proc_ids_termination_info_4_0));
Define_label(mercury__term_util__set_pred_proc_ids_termination_info_4_0_i10);
	update_prof_current_proc(LABEL(mercury__term_util__set_pred_proc_ids_termination_info_4_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	r3 = MR_stackvar(6);
	r4 = MR_stackvar(4);
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__term_util__set_pred_proc_ids_termination_info_4_0_i11,
		ENTRY(mercury__term_util__set_pred_proc_ids_termination_info_4_0));
Define_label(mercury__term_util__set_pred_proc_ids_termination_info_4_0_i11);
	update_prof_current_proc(LABEL(mercury__term_util__set_pred_proc_ids_termination_info_4_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__hlds_module__module_info_set_preds_3_0),
		mercury__term_util__set_pred_proc_ids_termination_info_4_0_i12,
		ENTRY(mercury__term_util__set_pred_proc_ids_termination_info_4_0));
Define_label(mercury__term_util__set_pred_proc_ids_termination_info_4_0_i12);
	update_prof_current_proc(LABEL(mercury__term_util__set_pred_proc_ids_termination_info_4_0));
	r3 = r1;
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(9);
	GOTO_LABEL(mercury__term_util__set_pred_proc_ids_termination_info_4_0_i1001);
Define_label(mercury__term_util__set_pred_proc_ids_termination_info_4_0_i3);
	r1 = r3;
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_module__module_info_pred_proc_info_5_0);
Declare_entry(mercury__hlds_pred__proc_info_get_maybe_termination_info_2_0);

BEGIN_MODULE(term_util_module12)
	init_entry(mercury__term_util__lookup_proc_termination_info_3_0);
	init_label(mercury__term_util__lookup_proc_termination_info_3_0_i2);
BEGIN_CODE

/* code for predicate 'lookup_proc_termination_info'/3 in mode 0 */
Define_entry(mercury__term_util__lookup_proc_termination_info_3_0);
	MR_incr_sp_push_msg(1, "term_util:lookup_proc_termination_info/3");
	MR_stackvar(1) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(ENTRY(mercury__hlds_module__module_info_pred_proc_info_5_0),
		mercury__term_util__lookup_proc_termination_info_3_0_i2,
		ENTRY(mercury__term_util__lookup_proc_termination_info_3_0));
Define_label(mercury__term_util__lookup_proc_termination_info_3_0_i2);
	update_prof_current_proc(LABEL(mercury__term_util__lookup_proc_termination_info_3_0));
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__hlds_pred__proc_info_get_maybe_termination_info_2_0),
		ENTRY(mercury__term_util__lookup_proc_termination_info_3_0));
END_MODULE

Declare_entry(mercury__hlds_pred__proc_info_get_maybe_arg_size_info_2_0);

BEGIN_MODULE(term_util_module13)
	init_entry(mercury__term_util__lookup_proc_arg_size_info_3_0);
	init_label(mercury__term_util__lookup_proc_arg_size_info_3_0_i2);
BEGIN_CODE

/* code for predicate 'lookup_proc_arg_size_info'/3 in mode 0 */
Define_entry(mercury__term_util__lookup_proc_arg_size_info_3_0);
	MR_incr_sp_push_msg(1, "term_util:lookup_proc_arg_size_info/3");
	MR_stackvar(1) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(ENTRY(mercury__hlds_module__module_info_pred_proc_info_5_0),
		mercury__term_util__lookup_proc_arg_size_info_3_0_i2,
		ENTRY(mercury__term_util__lookup_proc_arg_size_info_3_0));
Define_label(mercury__term_util__lookup_proc_arg_size_info_3_0_i2);
	update_prof_current_proc(LABEL(mercury__term_util__lookup_proc_arg_size_info_3_0));
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__hlds_pred__proc_info_get_maybe_arg_size_info_2_0),
		ENTRY(mercury__term_util__lookup_proc_arg_size_info_3_0));
END_MODULE

Declare_entry(mercury__type_util__type_is_higher_order_4_0);

BEGIN_MODULE(term_util_module14)
	init_entry(mercury__term_util__horder_vars_2_0);
	init_label(mercury__term_util__horder_vars_2_0_i1002);
	init_label(mercury__term_util__horder_vars_2_0_i5);
	init_label(mercury__term_util__horder_vars_2_0_i6);
	init_label(mercury__term_util__horder_vars_2_0_i3);
	init_label(mercury__term_util__horder_vars_2_0_i1);
BEGIN_CODE

/* code for predicate 'horder_vars'/2 in mode 0 */
Define_entry(mercury__term_util__horder_vars_2_0);
	MR_incr_sp_push_msg(3, "term_util:horder_vars/2");
	MR_stackvar(3) = (Word) MR_succip;
Define_label(mercury__term_util__horder_vars_2_0_i1002);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_util__horder_vars_2_0_i1);
	r3 = r2;
	r4 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_2);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_3);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__term_util__horder_vars_2_0_i5,
		ENTRY(mercury__term_util__horder_vars_2_0));
Define_label(mercury__term_util__horder_vars_2_0_i5);
	update_prof_current_proc(LABEL(mercury__term_util__horder_vars_2_0));
	call_localret(ENTRY(mercury__type_util__type_is_higher_order_4_0),
		mercury__term_util__horder_vars_2_0_i6,
		ENTRY(mercury__term_util__horder_vars_2_0));
Define_label(mercury__term_util__horder_vars_2_0_i6);
	update_prof_current_proc(LABEL(mercury__term_util__horder_vars_2_0));
	if (r1)
		GOTO_LABEL(mercury__term_util__horder_vars_2_0_i3);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	GOTO_LABEL(mercury__term_util__horder_vars_2_0_i1002);
Define_label(mercury__term_util__horder_vars_2_0_i3);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__term_util__horder_vars_2_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE

Declare_entry(mercury__type_util__classify_type_3_0);
static const struct mercury_const_21_struct {
	Integer f1;
	Integer f2;
	Integer f3;
	Integer f4;
	Integer f5;
	Integer f6;
	Integer f7;
	Integer f8;
}  mercury_const_21 = {
	(Integer) 1,
	(Integer) 1,
	(Integer) 1,
	(Integer) 1,
	(Integer) 0,
	(Integer) 1,
	(Integer) 0,
	(Integer) 0
};

BEGIN_MODULE(term_util_module15)
	init_entry(mercury__term_util__zero_size_type_2_0);
	init_label(mercury__term_util__zero_size_type_2_0_i2);
	init_label(mercury__term_util__zero_size_type_2_0_i1);
BEGIN_CODE

/* code for predicate 'zero_size_type'/2 in mode 0 */
Define_entry(mercury__term_util__zero_size_type_2_0);
	MR_incr_sp_push_msg(1, "term_util:zero_size_type/2");
	MR_stackvar(1) = (Word) MR_succip;
	call_localret(ENTRY(mercury__type_util__classify_type_3_0),
		mercury__term_util__zero_size_type_2_0_i2,
		ENTRY(mercury__term_util__zero_size_type_2_0));
Define_label(mercury__term_util__zero_size_type_2_0_i2);
	update_prof_current_proc(LABEL(mercury__term_util__zero_size_type_2_0));
	r2 = MR_const_field(MR_mktag(0), MR_mkword(MR_mktag(0), &mercury_const_21), r1);
	if (((Integer) 1 != (Integer) r2))
		GOTO_LABEL(mercury__term_util__zero_size_type_2_0_i1);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__term_util__zero_size_type_2_0_i1);
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	r1 = FALSE;
	proceed();
END_MODULE

Declare_entry(mercury__hlds_module__module_info_pred_info_3_0);
Declare_entry(mercury__hlds_pred__pred_info_context_2_0);

BEGIN_MODULE(term_util_module16)
	init_entry(mercury__term_util__get_context_from_scc_3_0);
	init_label(mercury__term_util__get_context_from_scc_3_0_i4);
	init_label(mercury__term_util__get_context_from_scc_3_0_i2);
BEGIN_CODE

/* code for predicate 'get_context_from_scc'/3 in mode 0 */
Define_entry(mercury__term_util__get_context_from_scc_3_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_util__get_context_from_scc_3_0_i2);
	MR_incr_sp_push_msg(1, "term_util:get_context_from_scc/3");
	MR_stackvar(1) = (Word) MR_succip;
	r3 = r1;
	r1 = r2;
	r2 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r3, (Integer) 0), (Integer) 0);
	call_localret(ENTRY(mercury__hlds_module__module_info_pred_info_3_0),
		mercury__term_util__get_context_from_scc_3_0_i4,
		ENTRY(mercury__term_util__get_context_from_scc_3_0));
Define_label(mercury__term_util__get_context_from_scc_3_0_i4);
	update_prof_current_proc(LABEL(mercury__term_util__get_context_from_scc_3_0));
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__hlds_pred__pred_info_context_2_0),
		ENTRY(mercury__term_util__get_context_from_scc_3_0));
Define_label(mercury__term_util__get_context_from_scc_3_0_i2);
	r1 = (Word) MR_string_const("Empty SCC in pass 2 of termination analysis", 43);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__term_util__get_context_from_scc_3_0));
END_MODULE


BEGIN_MODULE(term_util_module17)
	init_entry(mercury__term_util__add_context_to_termination_info_3_0);
	init_label(mercury__term_util__add_context_to_termination_info_3_0_i3);
	init_label(mercury__term_util__add_context_to_termination_info_3_0_i5);
BEGIN_CODE

/* code for predicate 'add_context_to_termination_info'/3 in mode 0 */
Define_entry(mercury__term_util__add_context_to_termination_info_3_0);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_util__add_context_to_termination_info_3_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
Define_label(mercury__term_util__add_context_to_termination_info_3_0_i3);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__term_util__add_context_to_termination_info_3_0_i5);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_term_util__common_4);
	proceed();
Define_label(mercury__term_util__add_context_to_termination_info_3_0_i5);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__term_util__add_context_to_termination_info_3_0, "std_util:maybe/1");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__term_util__add_context_to_termination_info_3_0, "term_util:termination_info/0");
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__term_util__add_context_to_termination_info_3_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__term_util__add_context_to_termination_info_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1));
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r2;
	proceed();
	}
END_MODULE


BEGIN_MODULE(term_util_module18)
	init_entry(mercury__term_util__add_context_to_arg_size_info_3_0);
	init_label(mercury__term_util__add_context_to_arg_size_info_3_0_i3);
	init_label(mercury__term_util__add_context_to_arg_size_info_3_0_i5);
BEGIN_CODE

/* code for predicate 'add_context_to_arg_size_info'/3 in mode 0 */
Define_entry(mercury__term_util__add_context_to_arg_size_info_3_0);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_util__add_context_to_arg_size_info_3_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
Define_label(mercury__term_util__add_context_to_arg_size_info_3_0_i3);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 0) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_util__add_context_to_arg_size_info_3_0_i5);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__term_util__add_context_to_arg_size_info_3_0, "std_util:maybe/1");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__term_util__add_context_to_arg_size_info_3_0, "term_util:arg_size_info/0");
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__term_util__add_context_to_arg_size_info_3_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__term_util__add_context_to_arg_size_info_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1));
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r2;
	proceed();
	}
Define_label(mercury__term_util__add_context_to_arg_size_info_3_0_i5);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__term_util__add_context_to_arg_size_info_3_0, "std_util:maybe/1");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__term_util__add_context_to_arg_size_info_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 1);
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	proceed();
	}
END_MODULE

Declare_entry(mercury__hlds_data__get_type_defn_body_2_0);
Declare_entry(mercury__hlds_data__get_type_defn_tparams_2_0);

BEGIN_MODULE(term_util_module19)
	init_entry(mercury__term_util__find_weights_for_type_list_3_0);
	init_label(mercury__term_util__find_weights_for_type_list_3_0_i1001);
	init_label(mercury__term_util__find_weights_for_type_list_3_0_i4);
	init_label(mercury__term_util__find_weights_for_type_list_3_0_i8);
	init_label(mercury__term_util__find_weights_for_type_list_3_0_i9);
	init_label(mercury__term_util__find_weights_for_type_list_3_0_i11);
	init_label(mercury__term_util__find_weights_for_type_list_3_0_i12);
	init_label(mercury__term_util__find_weights_for_type_list_3_0_i13);
	init_label(mercury__term_util__find_weights_for_type_list_3_0_i3);
BEGIN_CODE

/* code for predicate 'find_weights_for_type_list'/3 in mode 0 */
Define_static(mercury__term_util__find_weights_for_type_list_3_0);
	MR_incr_sp_push_msg(5, "term_util:find_weights_for_type_list/3");
	MR_stackvar(5) = (Word) MR_succip;
Define_label(mercury__term_util__find_weights_for_type_list_3_0_i1001);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_util__find_weights_for_type_list_3_0_i3);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_stackvar(3) = r1;
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__hlds_data__get_type_defn_body_2_0),
		mercury__term_util__find_weights_for_type_list_3_0_i4,
		STATIC(mercury__term_util__find_weights_for_type_list_3_0));
Define_label(mercury__term_util__find_weights_for_type_list_3_0_i4);
	update_prof_current_proc(LABEL(mercury__term_util__find_weights_for_type_list_3_0));
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__term_util__find_weights_for_type_list_3_0_i13) AND
		LABEL(mercury__term_util__find_weights_for_type_list_3_0_i8) AND
		LABEL(mercury__term_util__find_weights_for_type_list_3_0_i11) AND
		LABEL(mercury__term_util__find_weights_for_type_list_3_0_i13));
Define_label(mercury__term_util__find_weights_for_type_list_3_0_i8);
	r2 = r1;
	r1 = MR_stackvar(3);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	call_localret(ENTRY(mercury__hlds_data__get_type_defn_tparams_2_0),
		mercury__term_util__find_weights_for_type_list_3_0_i9,
		STATIC(mercury__term_util__find_weights_for_type_list_3_0));
Define_label(mercury__term_util__find_weights_for_type_list_3_0_i9);
	update_prof_current_proc(LABEL(mercury__term_util__find_weights_for_type_list_3_0));
	r3 = r1;
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(2);
	r4 = MR_stackvar(1);
	call_localret(STATIC(mercury__term_util__find_weights_for_cons_list_5_0),
		mercury__term_util__find_weights_for_type_list_3_0_i12,
		STATIC(mercury__term_util__find_weights_for_type_list_3_0));
Define_label(mercury__term_util__find_weights_for_type_list_3_0_i11);
	r1 = (Word) MR_string_const("undiscriminated union types not yet implemented", 47);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__term_util__find_weights_for_type_list_3_0_i12,
		STATIC(mercury__term_util__find_weights_for_type_list_3_0));
Define_label(mercury__term_util__find_weights_for_type_list_3_0_i12);
	update_prof_current_proc(LABEL(mercury__term_util__find_weights_for_type_list_3_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	GOTO_LABEL(mercury__term_util__find_weights_for_type_list_3_0_i1001);
Define_label(mercury__term_util__find_weights_for_type_list_3_0_i13);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(5);
	GOTO_LABEL(mercury__term_util__find_weights_for_type_list_3_0_i1001);
Define_label(mercury__term_util__find_weights_for_type_list_3_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE

Declare_entry(mercury__list__duplicate_3_0);
Declare_entry(mercury__map__det_insert_4_0);

BEGIN_MODULE(term_util_module20)
	init_entry(mercury__term_util__find_weights_for_cons_list_5_0);
	init_label(mercury__term_util__find_weights_for_cons_list_5_0_i1003);
	init_label(mercury__term_util__find_weights_for_cons_list_5_0_i4);
	init_label(mercury__term_util__find_weights_for_cons_list_5_0_i6);
	init_label(mercury__term_util__find_weights_for_cons_list_5_0_i9);
	init_label(mercury__term_util__find_weights_for_cons_list_5_0_i7);
	init_label(mercury__term_util__find_weights_for_cons_list_5_0_i5);
	init_label(mercury__term_util__find_weights_for_cons_list_5_0_i12);
	init_label(mercury__term_util__find_weights_for_cons_list_5_0_i3);
BEGIN_CODE

/* code for predicate 'find_weights_for_cons_list'/5 in mode 0 */
Define_static(mercury__term_util__find_weights_for_cons_list_5_0);
	MR_incr_sp_push_msg(7, "term_util:find_weights_for_cons_list/5");
	MR_stackvar(7) = (Word) MR_succip;
Define_label(mercury__term_util__find_weights_for_cons_list_5_0_i1003);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_util__find_weights_for_cons_list_5_0_i3);
	MR_stackvar(1) = r2;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 3);
	MR_stackvar(6) = r2;
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_5);
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__term_util__find_weights_for_cons_list_5_0_i4,
		STATIC(mercury__term_util__find_weights_for_cons_list_5_0));
	}
Define_label(mercury__term_util__find_weights_for_cons_list_5_0_i4);
	update_prof_current_proc(LABEL(mercury__term_util__find_weights_for_cons_list_5_0));
	if (((Integer) r1 <= (Integer) 0))
		GOTO_LABEL(mercury__term_util__find_weights_for_cons_list_5_0_i5);
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(6);
	MR_stackvar(6) = MR_tempr1;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	call_localret(STATIC(mercury__term_util__find_and_count_nonrec_args_5_0),
		mercury__term_util__find_weights_for_cons_list_5_0_i6,
		STATIC(mercury__term_util__find_weights_for_cons_list_5_0));
	}
Define_label(mercury__term_util__find_weights_for_cons_list_5_0_i6);
	update_prof_current_proc(LABEL(mercury__term_util__find_weights_for_cons_list_5_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__term_util__find_weights_for_cons_list_5_0_i7);
	r1 = (Word) (Word *) &mercury_data_bool__type_ctor_info_bool_0;
	r2 = MR_stackvar(6);
	r3 = (Integer) 1;
	call_localret(ENTRY(mercury__list__duplicate_3_0),
		mercury__term_util__find_weights_for_cons_list_5_0_i9,
		STATIC(mercury__term_util__find_weights_for_cons_list_5_0));
Define_label(mercury__term_util__find_weights_for_cons_list_5_0_i9);
	update_prof_current_proc(LABEL(mercury__term_util__find_weights_for_cons_list_5_0));
	r3 = MR_stackvar(3);
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__term_util__find_weights_for_cons_list_5_0, "term_util:weight_info/0");
	MR_field(MR_mktag(0), r5, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(0), r5, (Integer) 1) = r1;
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 2, mercury__term_util__find_weights_for_cons_list_5_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r4, (Integer) 0) = MR_stackvar(1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__term_util__find_weights_for_cons_list_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r4, (Integer) 1) = MR_tempr1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_1);
	r2 = (Word) (Word *) &mercury_data_term_util__type_ctor_info_weight_info_0;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = MR_stackvar(6);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(5);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__term_util__find_weights_for_cons_list_5_0_i12,
		STATIC(mercury__term_util__find_weights_for_cons_list_5_0));
	}
Define_label(mercury__term_util__find_weights_for_cons_list_5_0_i7);
	r3 = MR_stackvar(3);
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__term_util__find_weights_for_cons_list_5_0, "term_util:weight_info/0");
	MR_field(MR_mktag(0), r5, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r5, (Integer) 1) = r2;
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 2, mercury__term_util__find_weights_for_cons_list_5_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r4, (Integer) 0) = MR_stackvar(1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__term_util__find_weights_for_cons_list_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r4, (Integer) 1) = MR_tempr1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_1);
	r2 = (Word) (Word *) &mercury_data_term_util__type_ctor_info_weight_info_0;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = MR_stackvar(6);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(5);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__term_util__find_weights_for_cons_list_5_0_i12,
		STATIC(mercury__term_util__find_weights_for_cons_list_5_0));
	}
Define_label(mercury__term_util__find_weights_for_cons_list_5_0_i5);
	r3 = MR_stackvar(3);
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_6);
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 2, mercury__term_util__find_weights_for_cons_list_5_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r4, (Integer) 0) = MR_stackvar(1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__term_util__find_weights_for_cons_list_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r4, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_1);
	r2 = (Word) (Word *) &mercury_data_term_util__type_ctor_info_weight_info_0;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(5);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__term_util__find_weights_for_cons_list_5_0_i12,
		STATIC(mercury__term_util__find_weights_for_cons_list_5_0));
	}
Define_label(mercury__term_util__find_weights_for_cons_list_5_0_i12);
	update_prof_current_proc(LABEL(mercury__term_util__find_weights_for_cons_list_5_0));
	r4 = r1;
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(7);
	GOTO_LABEL(mercury__term_util__find_weights_for_cons_list_5_0_i1003);
Define_label(mercury__term_util__find_weights_for_cons_list_5_0_i3);
	r1 = r4;
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE

Declare_entry(mercury__type_util__type_to_type_id_3_0);
Declare_entry(mercury____Unify___std_util__pair_2_0);
Declare_entry(mercury__list__perm_2_0);
Declare_entry(mercury____Unify___list__list_1_0);
Declare_entry(do_redo);

BEGIN_MODULE(term_util_module21)
	init_entry(mercury__term_util__find_and_count_nonrec_args_5_0);
	init_label(mercury__term_util__find_and_count_nonrec_args_5_0_i4);
	init_label(mercury__term_util__find_and_count_nonrec_args_5_0_i6);
	init_label(mercury__term_util__find_and_count_nonrec_args_5_0_i8);
	init_label(mercury__term_util__find_and_count_nonrec_args_5_0_i11);
	init_label(mercury__term_util__find_and_count_nonrec_args_5_0_i1017);
	init_label(mercury__term_util__find_and_count_nonrec_args_5_0_i1023);
	init_label(mercury__term_util__find_and_count_nonrec_args_5_0_i14);
	init_label(mercury__term_util__find_and_count_nonrec_args_5_0_i5);
	init_label(mercury__term_util__find_and_count_nonrec_args_5_0_i3);
BEGIN_CODE

/* code for predicate 'find_and_count_nonrec_args'/5 in mode 0 */
Define_static(mercury__term_util__find_and_count_nonrec_args_5_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_util__find_and_count_nonrec_args_5_0_i3);
	MR_incr_sp_push_msg(8, "term_util:find_and_count_nonrec_args/5");
	MR_stackvar(8) = (Word) MR_succip;
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	localcall(mercury__term_util__find_and_count_nonrec_args_5_0,
		LABEL(mercury__term_util__find_and_count_nonrec_args_5_0_i4),
		STATIC(mercury__term_util__find_and_count_nonrec_args_5_0));
Define_label(mercury__term_util__find_and_count_nonrec_args_5_0_i4);
	update_prof_current_proc(LABEL(mercury__term_util__find_and_count_nonrec_args_5_0));
	r3 = r1;
	r1 = MR_const_field(MR_mktag(0), MR_stackvar(3), (Integer) 1);
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r2;
	call_localret(ENTRY(mercury__type_util__type_to_type_id_3_0),
		mercury__term_util__find_and_count_nonrec_args_5_0_i6,
		STATIC(mercury__term_util__find_and_count_nonrec_args_5_0));
Define_label(mercury__term_util__find_and_count_nonrec_args_5_0_i6);
	update_prof_current_proc(LABEL(mercury__term_util__find_and_count_nonrec_args_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__term_util__find_and_count_nonrec_args_5_0_i5);
	{
	Word MR_tempr1;
	MR_tempr1 = r3;
	r3 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	r4 = r2;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_sym_name_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury____Unify___std_util__pair_2_0),
		mercury__term_util__find_and_count_nonrec_args_5_0_i8,
		STATIC(mercury__term_util__find_and_count_nonrec_args_5_0));
	}
Define_label(mercury__term_util__find_and_count_nonrec_args_5_0_i8);
	update_prof_current_proc(LABEL(mercury__term_util__find_and_count_nonrec_args_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__term_util__find_and_count_nonrec_args_5_0_i5);
	MR_stackvar(5) = (Word) MR_redoip_slot(MR_maxfr);
	MR_stackvar(6) = (Word) MR_redofr_slot(MR_maxfr);
	MR_stackvar(7) = (Word) MR_maxfr;
	MR_redofr_slot(MR_maxfr) = MR_curfr;
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__term_util__find_and_count_nonrec_args_5_0_i1023);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_3);
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__list__perm_2_0),
		mercury__term_util__find_and_count_nonrec_args_5_0_i11,
		STATIC(mercury__term_util__find_and_count_nonrec_args_5_0));
Define_label(mercury__term_util__find_and_count_nonrec_args_5_0_i11);
	update_prof_current_proc(LABEL(mercury__term_util__find_and_count_nonrec_args_5_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_3);
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury__term_util__find_and_count_nonrec_args_5_0_i1017,
		STATIC(mercury__term_util__find_and_count_nonrec_args_5_0));
Define_label(mercury__term_util__find_and_count_nonrec_args_5_0_i1017);
	update_prof_current_proc(LABEL(mercury__term_util__find_and_count_nonrec_args_5_0));
	if (!(r1))
		GOTO(ENTRY(do_redo));
	MR_maxfr = (Word *) MR_stackvar(7);
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(5);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(6);
	GOTO_LABEL(mercury__term_util__find_and_count_nonrec_args_5_0_i14);
Define_label(mercury__term_util__find_and_count_nonrec_args_5_0_i1023);
	update_prof_current_proc(LABEL(mercury__term_util__find_and_count_nonrec_args_5_0));
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(5);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(6);
	GOTO_LABEL(mercury__term_util__find_and_count_nonrec_args_5_0_i5);
Define_label(mercury__term_util__find_and_count_nonrec_args_5_0_i14);
	r1 = MR_stackvar(3);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__term_util__find_and_count_nonrec_args_5_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__term_util__find_and_count_nonrec_args_5_0_i5);
	r1 = ((Integer) MR_stackvar(3) + (Integer) 1);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__term_util__find_and_count_nonrec_args_5_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__term_util__find_and_count_nonrec_args_5_0_i3);
	r1 = (Integer) 0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE


BEGIN_MODULE(term_util_module22)
	init_entry(mercury__term_util__functor_norm_filter_args_5_0);
	init_label(mercury__term_util__functor_norm_filter_args_5_0_i1007);
	init_label(mercury__term_util__functor_norm_filter_args_5_0_i3);
	init_label(mercury__term_util__functor_norm_filter_args_5_0_i9);
	init_label(mercury__term_util__functor_norm_filter_args_5_0_i12);
	init_label(mercury__term_util__functor_norm_filter_args_5_0_i1);
BEGIN_CODE

/* code for predicate 'functor_norm_filter_args'/5 in mode 0 */
Define_static(mercury__term_util__functor_norm_filter_args_5_0);
	MR_incr_sp_push_msg(3, "term_util:functor_norm_filter_args/5");
	MR_stackvar(3) = (Word) MR_succip;
Define_label(mercury__term_util__functor_norm_filter_args_5_0_i1007);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_util__functor_norm_filter_args_5_0_i3);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_util__functor_norm_filter_args_5_0_i1);
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_util__functor_norm_filter_args_5_0_i1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__term_util__functor_norm_filter_args_5_0_i3);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_util__functor_norm_filter_args_5_0_i1);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_util__functor_norm_filter_args_5_0_i1);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__term_util__functor_norm_filter_args_5_0_i9);
	r3 = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(3);
	GOTO_LABEL(mercury__term_util__functor_norm_filter_args_5_0_i1007);
Define_label(mercury__term_util__functor_norm_filter_args_5_0_i9);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r3 = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	localcall(mercury__term_util__functor_norm_filter_args_5_0,
		LABEL(mercury__term_util__functor_norm_filter_args_5_0_i12),
		STATIC(mercury__term_util__functor_norm_filter_args_5_0));
Define_label(mercury__term_util__functor_norm_filter_args_5_0_i12);
	update_prof_current_proc(LABEL(mercury__term_util__functor_norm_filter_args_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__term_util__functor_norm_filter_args_5_0_i1);
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__term_util__functor_norm_filter_args_5_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r2, (Integer) 1) = r1;
	r4 = r3;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__term_util__functor_norm_filter_args_5_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__term_util__functor_norm_filter_args_5_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE

Declare_entry(mercury__mode_util__mode_is_input_2_0);
Declare_entry(mercury__mode_util__mode_is_output_2_0);

BEGIN_MODULE(term_util_module23)
	init_entry(mercury__term_util__partition_call_args_2_5_0);
	init_label(mercury__term_util__partition_call_args_2_5_0_i5);
	init_label(mercury__term_util__partition_call_args_2_5_0_i3);
	init_label(mercury__term_util__partition_call_args_2_5_0_i9);
	init_label(mercury__term_util__partition_call_args_2_5_0_i12);
	init_label(mercury__term_util__partition_call_args_2_5_0_i10);
	init_label(mercury__term_util__partition_call_args_2_5_0_i16);
	init_label(mercury__term_util__partition_call_args_2_5_0_i14);
	init_label(mercury__term_util__partition_call_args_2_5_0_i8);
BEGIN_CODE

/* code for predicate 'partition_call_args_2'/5 in mode 0 */
Define_static(mercury__term_util__partition_call_args_2_5_0);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_util__partition_call_args_2_5_0_i3);
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_util__partition_call_args_2_5_0_i5);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
Define_label(mercury__term_util__partition_call_args_2_5_0_i5);
	r1 = (Word) MR_string_const("Unmatched variables in term_util:partition_call_args", 52);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__term_util__partition_call_args_2_5_0));
Define_label(mercury__term_util__partition_call_args_2_5_0_i3);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__term_util__partition_call_args_2_5_0_i8);
	MR_incr_sp_push_msg(6, "term_util:partition_call_args_2/5");
	MR_stackvar(6) = (Word) MR_succip;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r3 = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	MR_stackvar(1) = r1;
	localcall(mercury__term_util__partition_call_args_2_5_0,
		LABEL(mercury__term_util__partition_call_args_2_5_0_i9),
		STATIC(mercury__term_util__partition_call_args_2_5_0));
Define_label(mercury__term_util__partition_call_args_2_5_0_i9);
	update_prof_current_proc(LABEL(mercury__term_util__partition_call_args_2_5_0));
	MR_stackvar(3) = r1;
	MR_stackvar(4) = r2;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(5);
	call_localret(ENTRY(mercury__mode_util__mode_is_input_2_0),
		mercury__term_util__partition_call_args_2_5_0_i12,
		STATIC(mercury__term_util__partition_call_args_2_5_0));
Define_label(mercury__term_util__partition_call_args_2_5_0_i12);
	update_prof_current_proc(LABEL(mercury__term_util__partition_call_args_2_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__term_util__partition_call_args_2_5_0_i10);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__term_util__partition_call_args_2_5_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_stackvar(3);
	r2 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__term_util__partition_call_args_2_5_0_i10);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(5);
	call_localret(ENTRY(mercury__mode_util__mode_is_output_2_0),
		mercury__term_util__partition_call_args_2_5_0_i16,
		STATIC(mercury__term_util__partition_call_args_2_5_0));
Define_label(mercury__term_util__partition_call_args_2_5_0_i16);
	update_prof_current_proc(LABEL(mercury__term_util__partition_call_args_2_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__term_util__partition_call_args_2_5_0_i14);
	r1 = MR_stackvar(3);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__term_util__partition_call_args_2_5_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__term_util__partition_call_args_2_5_0_i14);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__term_util__partition_call_args_2_5_0_i8);
	r1 = (Word) MR_string_const("Unmatched variables in term_util__partition_call_args", 53);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__term_util__partition_call_args_2_5_0));
END_MODULE


BEGIN_MODULE(term_util_module24)
	init_entry(mercury____Unify___term_util__arg_size_info_0_0);
	init_label(mercury____Unify___term_util__arg_size_info_0_0_i3);
	init_label(mercury____Unify___term_util__arg_size_info_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___term_util__arg_size_info_0_0);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Unify___term_util__arg_size_info_0_0_i3);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Unify___term_util__arg_size_info_0_0_i1);
	if ((MR_const_field(MR_mktag(0), r1, (Integer) 0) != MR_const_field(MR_mktag(0), r2, (Integer) 0)))
		GOTO_LABEL(mercury____Unify___term_util__arg_size_info_0_0_i1);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_bool__type_ctor_info_bool_0;
	tailcall(ENTRY(mercury____Unify___list__list_1_0),
		ENTRY(mercury____Unify___term_util__arg_size_info_0_0));
Define_label(mercury____Unify___term_util__arg_size_info_0_0_i3);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Unify___term_util__arg_size_info_0_0_i1);
	r3 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_7);
	tailcall(ENTRY(mercury____Unify___list__list_1_0),
		ENTRY(mercury____Unify___term_util__arg_size_info_0_0));
Define_label(mercury____Unify___term_util__arg_size_info_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(term_util_module25)
	init_entry(mercury____Index___term_util__arg_size_info_0_0);
	init_label(mercury____Index___term_util__arg_size_info_0_0_i3);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___term_util__arg_size_info_0_0);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Index___term_util__arg_size_info_0_0_i3);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Index___term_util__arg_size_info_0_0_i3);
	r1 = (Integer) 1;
	proceed();
END_MODULE

Declare_entry(mercury__builtin_compare_int_3_0);
Declare_entry(mercury____Compare___list__list_1_0);
Declare_entry(mercury__compare_error_0_0);

BEGIN_MODULE(term_util_module26)
	init_entry(mercury____Compare___term_util__arg_size_info_0_0);
	init_label(mercury____Compare___term_util__arg_size_info_0_0_i3);
	init_label(mercury____Compare___term_util__arg_size_info_0_0_i2);
	init_label(mercury____Compare___term_util__arg_size_info_0_0_i5);
	init_label(mercury____Compare___term_util__arg_size_info_0_0_i4);
	init_label(mercury____Compare___term_util__arg_size_info_0_0_i6);
	init_label(mercury____Compare___term_util__arg_size_info_0_0_i7);
	init_label(mercury____Compare___term_util__arg_size_info_0_0_i14);
	init_label(mercury____Compare___term_util__arg_size_info_0_0_i11);
	init_label(mercury____Compare___term_util__arg_size_info_0_0_i1015);
	init_label(mercury____Compare___term_util__arg_size_info_0_0_i24);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___term_util__arg_size_info_0_0);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___term_util__arg_size_info_0_0_i3);
	r3 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___term_util__arg_size_info_0_0_i2);
Define_label(mercury____Compare___term_util__arg_size_info_0_0_i3);
	r3 = (Integer) 1;
Define_label(mercury____Compare___term_util__arg_size_info_0_0_i2);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___term_util__arg_size_info_0_0_i5);
	r4 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___term_util__arg_size_info_0_0_i4);
Define_label(mercury____Compare___term_util__arg_size_info_0_0_i5);
	r4 = (Integer) 1;
Define_label(mercury____Compare___term_util__arg_size_info_0_0_i4);
	if (((Integer) r3 >= (Integer) r4))
		GOTO_LABEL(mercury____Compare___term_util__arg_size_info_0_0_i6);
	r1 = (Integer) 1;
	proceed();
Define_label(mercury____Compare___term_util__arg_size_info_0_0_i6);
	if (((Integer) r3 <= (Integer) r4))
		GOTO_LABEL(mercury____Compare___term_util__arg_size_info_0_0_i7);
	r1 = (Integer) 2;
	proceed();
Define_label(mercury____Compare___term_util__arg_size_info_0_0_i7);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___term_util__arg_size_info_0_0_i11);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___term_util__arg_size_info_0_0_i1015);
	MR_incr_sp_push_msg(3, "term_util:__Compare__/3");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___term_util__arg_size_info_0_0_i14,
		ENTRY(mercury____Compare___term_util__arg_size_info_0_0));
Define_label(mercury____Compare___term_util__arg_size_info_0_0_i14);
	update_prof_current_proc(LABEL(mercury____Compare___term_util__arg_size_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___term_util__arg_size_info_0_0_i24);
	r1 = (Word) (Word *) &mercury_data_bool__type_ctor_info_bool_0;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury____Compare___list__list_1_0),
		ENTRY(mercury____Compare___term_util__arg_size_info_0_0));
Define_label(mercury____Compare___term_util__arg_size_info_0_0_i11);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___term_util__arg_size_info_0_0_i1015);
	r3 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_7);
	tailcall(ENTRY(mercury____Compare___list__list_1_0),
		ENTRY(mercury____Compare___term_util__arg_size_info_0_0));
Define_label(mercury____Compare___term_util__arg_size_info_0_0_i1015);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___term_util__arg_size_info_0_0));
Define_label(mercury____Compare___term_util__arg_size_info_0_0_i24);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(term_util_module27)
	init_entry(mercury____Unify___term_util__termination_info_0_0);
	init_label(mercury____Unify___term_util__termination_info_0_0_i3);
	init_label(mercury____Unify___term_util__termination_info_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___term_util__termination_info_0_0);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Unify___term_util__termination_info_0_0_i3);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Unify___term_util__termination_info_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___term_util__termination_info_0_0_i3);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Unify___term_util__termination_info_0_0_i1);
	r3 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_7);
	tailcall(ENTRY(mercury____Unify___list__list_1_0),
		ENTRY(mercury____Unify___term_util__termination_info_0_0));
Define_label(mercury____Unify___term_util__termination_info_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(term_util_module28)
	init_entry(mercury____Index___term_util__termination_info_0_0);
	init_label(mercury____Index___term_util__termination_info_0_0_i3);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___term_util__termination_info_0_0);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Index___term_util__termination_info_0_0_i3);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Index___term_util__termination_info_0_0_i3);
	r1 = (Integer) 1;
	proceed();
END_MODULE


BEGIN_MODULE(term_util_module29)
	init_entry(mercury____Compare___term_util__termination_info_0_0);
	init_label(mercury____Compare___term_util__termination_info_0_0_i3);
	init_label(mercury____Compare___term_util__termination_info_0_0_i2);
	init_label(mercury____Compare___term_util__termination_info_0_0_i5);
	init_label(mercury____Compare___term_util__termination_info_0_0_i4);
	init_label(mercury____Compare___term_util__termination_info_0_0_i6);
	init_label(mercury____Compare___term_util__termination_info_0_0_i7);
	init_label(mercury____Compare___term_util__termination_info_0_0_i11);
	init_label(mercury____Compare___term_util__termination_info_0_0_i1014);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___term_util__termination_info_0_0);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___term_util__termination_info_0_0_i3);
	r3 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___term_util__termination_info_0_0_i2);
Define_label(mercury____Compare___term_util__termination_info_0_0_i3);
	r3 = (Integer) 1;
Define_label(mercury____Compare___term_util__termination_info_0_0_i2);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___term_util__termination_info_0_0_i5);
	r4 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___term_util__termination_info_0_0_i4);
Define_label(mercury____Compare___term_util__termination_info_0_0_i5);
	r4 = (Integer) 1;
Define_label(mercury____Compare___term_util__termination_info_0_0_i4);
	if (((Integer) r3 >= (Integer) r4))
		GOTO_LABEL(mercury____Compare___term_util__termination_info_0_0_i6);
	r1 = (Integer) 1;
	proceed();
Define_label(mercury____Compare___term_util__termination_info_0_0_i6);
	if (((Integer) r3 <= (Integer) r4))
		GOTO_LABEL(mercury____Compare___term_util__termination_info_0_0_i7);
	r1 = (Integer) 2;
	proceed();
Define_label(mercury____Compare___term_util__termination_info_0_0_i7);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___term_util__termination_info_0_0_i11);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___term_util__termination_info_0_0_i1014);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Compare___term_util__termination_info_0_0_i11);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___term_util__termination_info_0_0_i1014);
	r3 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_7);
	tailcall(ENTRY(mercury____Compare___list__list_1_0),
		ENTRY(mercury____Compare___term_util__termination_info_0_0));
Define_label(mercury____Compare___term_util__termination_info_0_0_i1014);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___term_util__termination_info_0_0));
END_MODULE

Declare_entry(mercury____Unify___tree234__tree234_2_0);

BEGIN_MODULE(term_util_module30)
	init_entry(mercury____Unify___term_util__used_args_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___term_util__used_args_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_8);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___term_util__used_args_0_0));
END_MODULE

Declare_entry(mercury____Index___tree234__tree234_2_0);

BEGIN_MODULE(term_util_module31)
	init_entry(mercury____Index___term_util__used_args_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___term_util__used_args_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_8);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		ENTRY(mercury____Index___term_util__used_args_0_0));
END_MODULE

Declare_entry(mercury____Compare___tree234__tree234_2_0);

BEGIN_MODULE(term_util_module32)
	init_entry(mercury____Compare___term_util__used_args_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___term_util__used_args_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_8);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___term_util__used_args_0_0));
END_MODULE


BEGIN_MODULE(term_util_module33)
	init_entry(mercury____Unify___term_util__functor_info_0_0);
	init_label(mercury____Unify___term_util__functor_info_0_0_i12);
	init_label(mercury____Unify___term_util__functor_info_0_0_i8);
	init_label(mercury____Unify___term_util__functor_info_0_0_i4);
	init_label(mercury____Unify___term_util__functor_info_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___term_util__functor_info_0_0);
	r3 = MR_tag(r1);
	if ((r3 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Unify___term_util__functor_info_0_0_i4);
	if ((r3 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Unify___term_util__functor_info_0_0_i8);
	if (((Integer) MR_unmkbody(r1) != (Integer) 0))
		GOTO_LABEL(mercury____Unify___term_util__functor_info_0_0_i12);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Unify___term_util__functor_info_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___term_util__functor_info_0_0_i12);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))))
		GOTO_LABEL(mercury____Unify___term_util__functor_info_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___term_util__functor_info_0_0_i8);
	if ((MR_tag(r2) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Unify___term_util__functor_info_0_0_i1);
	r3 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	r4 = MR_const_field(MR_mktag(2), r2, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_1);
	r2 = (Word) (Word *) &mercury_data_term_util__type_ctor_info_weight_info_0;
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___term_util__functor_info_0_0));
Define_label(mercury____Unify___term_util__functor_info_0_0_i4);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Unify___term_util__functor_info_0_0_i1);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r4 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_1);
	r2 = (Word) (Word *) &mercury_data_term_util__type_ctor_info_weight_info_0;
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___term_util__functor_info_0_0));
Define_label(mercury____Unify___term_util__functor_info_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(term_util_module34)
	init_entry(mercury____Index___term_util__functor_info_0_0);
	init_label(mercury____Index___term_util__functor_info_0_0_i6);
	init_label(mercury____Index___term_util__functor_info_0_0_i5);
	init_label(mercury____Index___term_util__functor_info_0_0_i4);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___term_util__functor_info_0_0);
	r2 = MR_tag(r1);
	if ((r2 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Index___term_util__functor_info_0_0_i4);
	if ((r2 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Index___term_util__functor_info_0_0_i5);
	if (((Integer) MR_unmkbody(r1) != (Integer) 0))
		GOTO_LABEL(mercury____Index___term_util__functor_info_0_0_i6);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Index___term_util__functor_info_0_0_i6);
	r1 = (Integer) 1;
	proceed();
Define_label(mercury____Index___term_util__functor_info_0_0_i5);
	r1 = (Integer) 3;
	proceed();
Define_label(mercury____Index___term_util__functor_info_0_0_i4);
	r1 = (Integer) 2;
	proceed();
END_MODULE


BEGIN_MODULE(term_util_module35)
	init_entry(mercury____Compare___term_util__functor_info_0_0);
	init_label(mercury____Compare___term_util__functor_info_0_0_i6);
	init_label(mercury____Compare___term_util__functor_info_0_0_i5);
	init_label(mercury____Compare___term_util__functor_info_0_0_i4);
	init_label(mercury____Compare___term_util__functor_info_0_0_i2);
	init_label(mercury____Compare___term_util__functor_info_0_0_i11);
	init_label(mercury____Compare___term_util__functor_info_0_0_i10);
	init_label(mercury____Compare___term_util__functor_info_0_0_i9);
	init_label(mercury____Compare___term_util__functor_info_0_0_i7);
	init_label(mercury____Compare___term_util__functor_info_0_0_i12);
	init_label(mercury____Compare___term_util__functor_info_0_0_i13);
	init_label(mercury____Compare___term_util__functor_info_0_0_i24);
	init_label(mercury____Compare___term_util__functor_info_0_0_i21);
	init_label(mercury____Compare___term_util__functor_info_0_0_i18);
	init_label(mercury____Compare___term_util__functor_info_0_0_i1024);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___term_util__functor_info_0_0);
	r3 = MR_tag(r1);
	if ((r3 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___term_util__functor_info_0_0_i4);
	if ((r3 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Compare___term_util__functor_info_0_0_i5);
	if (((Integer) MR_unmkbody(r1) != (Integer) 0))
		GOTO_LABEL(mercury____Compare___term_util__functor_info_0_0_i6);
	r3 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___term_util__functor_info_0_0_i2);
Define_label(mercury____Compare___term_util__functor_info_0_0_i6);
	r3 = (Integer) 1;
	GOTO_LABEL(mercury____Compare___term_util__functor_info_0_0_i2);
Define_label(mercury____Compare___term_util__functor_info_0_0_i5);
	r3 = (Integer) 3;
	GOTO_LABEL(mercury____Compare___term_util__functor_info_0_0_i2);
Define_label(mercury____Compare___term_util__functor_info_0_0_i4);
	r3 = (Integer) 2;
Define_label(mercury____Compare___term_util__functor_info_0_0_i2);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_tag(r2);
	if ((MR_tempr1 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___term_util__functor_info_0_0_i9);
	if ((MR_tempr1 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Compare___term_util__functor_info_0_0_i10);
	if (((Integer) MR_unmkbody(r2) != (Integer) 0))
		GOTO_LABEL(mercury____Compare___term_util__functor_info_0_0_i11);
	r4 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___term_util__functor_info_0_0_i7);
	}
Define_label(mercury____Compare___term_util__functor_info_0_0_i11);
	r4 = (Integer) 1;
	GOTO_LABEL(mercury____Compare___term_util__functor_info_0_0_i7);
Define_label(mercury____Compare___term_util__functor_info_0_0_i10);
	r4 = (Integer) 3;
	GOTO_LABEL(mercury____Compare___term_util__functor_info_0_0_i7);
Define_label(mercury____Compare___term_util__functor_info_0_0_i9);
	r4 = (Integer) 2;
Define_label(mercury____Compare___term_util__functor_info_0_0_i7);
	if (((Integer) r3 >= (Integer) r4))
		GOTO_LABEL(mercury____Compare___term_util__functor_info_0_0_i12);
	r1 = (Integer) 1;
	proceed();
Define_label(mercury____Compare___term_util__functor_info_0_0_i12);
	if (((Integer) r3 <= (Integer) r4))
		GOTO_LABEL(mercury____Compare___term_util__functor_info_0_0_i13);
	r1 = (Integer) 2;
	proceed();
Define_label(mercury____Compare___term_util__functor_info_0_0_i13);
	r3 = MR_tag(r1);
	if ((r3 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___term_util__functor_info_0_0_i18);
	if ((r3 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Compare___term_util__functor_info_0_0_i21);
	if (((Integer) MR_unmkbody(r1) != (Integer) 0))
		GOTO_LABEL(mercury____Compare___term_util__functor_info_0_0_i24);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___term_util__functor_info_0_0_i1024);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Compare___term_util__functor_info_0_0_i24);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))))
		GOTO_LABEL(mercury____Compare___term_util__functor_info_0_0_i1024);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Compare___term_util__functor_info_0_0_i21);
	if ((MR_tag(r2) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Compare___term_util__functor_info_0_0_i1024);
	r3 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	r4 = MR_const_field(MR_mktag(2), r2, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_1);
	r2 = (Word) (Word *) &mercury_data_term_util__type_ctor_info_weight_info_0;
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___term_util__functor_info_0_0));
Define_label(mercury____Compare___term_util__functor_info_0_0_i18);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___term_util__functor_info_0_0_i1024);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r4 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_1);
	r2 = (Word) (Word *) &mercury_data_term_util__type_ctor_info_weight_info_0;
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___term_util__functor_info_0_0));
Define_label(mercury____Compare___term_util__functor_info_0_0_i1024);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___term_util__functor_info_0_0));
END_MODULE


BEGIN_MODULE(term_util_module36)
	init_entry(mercury____Unify___term_util__unify_info_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___term_util__unify_info_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_9);
	r4 = r2;
	r2 = (Word) (Word *) &mercury_data_term_util__type_ctor_info_functor_info_0;
	tailcall(ENTRY(mercury____Unify___std_util__pair_2_0),
		ENTRY(mercury____Unify___term_util__unify_info_0_0));
END_MODULE

Declare_entry(mercury____Index___std_util__pair_2_0);

BEGIN_MODULE(term_util_module37)
	init_entry(mercury____Index___term_util__unify_info_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___term_util__unify_info_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_9);
	r2 = (Word) (Word *) &mercury_data_term_util__type_ctor_info_functor_info_0;
	tailcall(ENTRY(mercury____Index___std_util__pair_2_0),
		ENTRY(mercury____Index___term_util__unify_info_0_0));
END_MODULE

Declare_entry(mercury____Compare___std_util__pair_2_0);

BEGIN_MODULE(term_util_module38)
	init_entry(mercury____Compare___term_util__unify_info_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___term_util__unify_info_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_9);
	r4 = r2;
	r2 = (Word) (Word *) &mercury_data_term_util__type_ctor_info_functor_info_0;
	tailcall(ENTRY(mercury____Compare___std_util__pair_2_0),
		ENTRY(mercury____Compare___term_util__unify_info_0_0));
END_MODULE


BEGIN_MODULE(term_util_module39)
	init_entry(mercury____Unify___term_util__weight_info_0_0);
	init_label(mercury____Unify___term_util__weight_info_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___term_util__weight_info_0_0);
	if ((MR_const_field(MR_mktag(0), r1, (Integer) 0) != MR_const_field(MR_mktag(0), r2, (Integer) 0)))
		GOTO_LABEL(mercury____Unify___term_util__weight_info_0_0_i1);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_bool__type_ctor_info_bool_0;
	tailcall(ENTRY(mercury____Unify___list__list_1_0),
		ENTRY(mercury____Unify___term_util__weight_info_0_0));
Define_label(mercury____Unify___term_util__weight_info_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(term_util_module40)
	init_entry(mercury____Index___term_util__weight_info_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___term_util__weight_info_0_0);
	tailcall(STATIC(mercury____Index___term_util__weight_info_0__ua0_2_0),
		ENTRY(mercury____Index___term_util__weight_info_0_0));
END_MODULE


BEGIN_MODULE(term_util_module41)
	init_entry(mercury____Compare___term_util__weight_info_0_0);
	init_label(mercury____Compare___term_util__weight_info_0_0_i3);
	init_label(mercury____Compare___term_util__weight_info_0_0_i7);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___term_util__weight_info_0_0);
	MR_incr_sp_push_msg(3, "term_util:__Compare__/3");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___term_util__weight_info_0_0_i3,
		ENTRY(mercury____Compare___term_util__weight_info_0_0));
Define_label(mercury____Compare___term_util__weight_info_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___term_util__weight_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___term_util__weight_info_0_0_i7);
	r1 = (Word) (Word *) &mercury_data_bool__type_ctor_info_bool_0;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury____Compare___list__list_1_0),
		ENTRY(mercury____Compare___term_util__weight_info_0_0));
Define_label(mercury____Compare___term_util__weight_info_0_0_i7);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(term_util_module42)
	init_entry(mercury____Unify___term_util__weight_table_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___term_util__weight_table_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_1);
	r4 = r2;
	r2 = (Word) (Word *) &mercury_data_term_util__type_ctor_info_weight_info_0;
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___term_util__weight_table_0_0));
END_MODULE


BEGIN_MODULE(term_util_module43)
	init_entry(mercury____Index___term_util__weight_table_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___term_util__weight_table_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_1);
	r2 = (Word) (Word *) &mercury_data_term_util__type_ctor_info_weight_info_0;
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		ENTRY(mercury____Index___term_util__weight_table_0_0));
END_MODULE


BEGIN_MODULE(term_util_module44)
	init_entry(mercury____Compare___term_util__weight_table_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___term_util__weight_table_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_term_util__common_1);
	r4 = r2;
	r2 = (Word) (Word *) &mercury_data_term_util__type_ctor_info_weight_info_0;
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___term_util__weight_table_0_0));
END_MODULE


BEGIN_MODULE(term_util_module45)
	init_entry(mercury____Unify___term_util__pass_info_0_0);
	init_label(mercury____Unify___term_util__pass_info_0_0_i2);
	init_label(mercury____Unify___term_util__pass_info_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___term_util__pass_info_0_0);
	MR_incr_sp_push_msg(5, "term_util:__Unify__/2");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	call_localret(STATIC(mercury____Unify___term_util__functor_info_0_0),
		mercury____Unify___term_util__pass_info_0_0_i2,
		ENTRY(mercury____Unify___term_util__pass_info_0_0));
Define_label(mercury____Unify___term_util__pass_info_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___term_util__pass_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___term_util__pass_info_0_0_i1);
	if ((MR_stackvar(1) != MR_stackvar(3)))
		GOTO_LABEL(mercury____Unify___term_util__pass_info_0_0_i1);
	if ((MR_stackvar(2) != MR_stackvar(4)))
		GOTO_LABEL(mercury____Unify___term_util__pass_info_0_0_i1);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___term_util__pass_info_0_0_i1);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(term_util_module46)
	init_entry(mercury____Index___term_util__pass_info_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___term_util__pass_info_0_0);
	tailcall(STATIC(mercury____Index___term_util__pass_info_0__ua0_2_0),
		ENTRY(mercury____Index___term_util__pass_info_0_0));
END_MODULE


BEGIN_MODULE(term_util_module47)
	init_entry(mercury____Compare___term_util__pass_info_0_0);
	init_label(mercury____Compare___term_util__pass_info_0_0_i3);
	init_label(mercury____Compare___term_util__pass_info_0_0_i7);
	init_label(mercury____Compare___term_util__pass_info_0_0_i12);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___term_util__pass_info_0_0);
	MR_incr_sp_push_msg(5, "term_util:__Compare__/3");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(STATIC(mercury____Compare___term_util__functor_info_0_0),
		mercury____Compare___term_util__pass_info_0_0_i3,
		ENTRY(mercury____Compare___term_util__pass_info_0_0));
Define_label(mercury____Compare___term_util__pass_info_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___term_util__pass_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___term_util__pass_info_0_0_i12);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___term_util__pass_info_0_0_i7,
		ENTRY(mercury____Compare___term_util__pass_info_0_0));
Define_label(mercury____Compare___term_util__pass_info_0_0_i7);
	update_prof_current_proc(LABEL(mercury____Compare___term_util__pass_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___term_util__pass_info_0_0_i12);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___term_util__pass_info_0_0));
Define_label(mercury____Compare___term_util__pass_info_0_0_i12);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__term_util_maybe_bunch_0(void)
{
	term_util_module0();
	term_util_module1();
	term_util_module2();
	term_util_module3();
	term_util_module4();
	term_util_module5();
	term_util_module6();
	term_util_module7();
	term_util_module8();
	term_util_module9();
	term_util_module10();
	term_util_module11();
	term_util_module12();
	term_util_module13();
	term_util_module14();
	term_util_module15();
	term_util_module16();
	term_util_module17();
	term_util_module18();
	term_util_module19();
	term_util_module20();
	term_util_module21();
	term_util_module22();
	term_util_module23();
	term_util_module24();
	term_util_module25();
	term_util_module26();
	term_util_module27();
	term_util_module28();
	term_util_module29();
	term_util_module30();
	term_util_module31();
	term_util_module32();
	term_util_module33();
	term_util_module34();
	term_util_module35();
	term_util_module36();
	term_util_module37();
	term_util_module38();
	term_util_module39();
}

static void mercury__term_util_maybe_bunch_1(void)
{
	term_util_module40();
	term_util_module41();
	term_util_module42();
	term_util_module43();
	term_util_module44();
	term_util_module45();
	term_util_module46();
	term_util_module47();
}

#endif

void mercury__term_util__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__term_util__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__term_util_maybe_bunch_0();
		mercury__term_util_maybe_bunch_1();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_term_util__type_ctor_info_arg_size_info_0,
			term_util__arg_size_info_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_term_util__type_ctor_info_functor_info_0,
			term_util__functor_info_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_term_util__type_ctor_info_pass_info_0,
			term_util__pass_info_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_term_util__type_ctor_info_termination_info_0,
			term_util__termination_info_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_term_util__type_ctor_info_unify_info_0,
			term_util__unify_info_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_term_util__type_ctor_info_used_args_0,
			term_util__used_args_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_term_util__type_ctor_info_weight_info_0,
			term_util__weight_info_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_term_util__type_ctor_info_weight_table_0,
			term_util__weight_table_0_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
