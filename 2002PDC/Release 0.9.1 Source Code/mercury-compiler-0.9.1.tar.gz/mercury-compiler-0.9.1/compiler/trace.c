/*
** Automatically generated from `trace.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__trace__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury____Index___trace__trace_slot_info_0__ua0_2_0);
Declare_static(mercury____Index___trace__trace_info_0__ua0_2_0);
Declare_static(mercury__trace__IntroducedFrom__pred__maybe_setup_redo_event__665__1_2_0);
Define_extern_entry(mercury__trace__fail_vars_3_0);
Declare_label(mercury__trace__fail_vars_3_0_i2);
Declare_label(mercury__trace__fail_vars_3_0_i3);
Declare_label(mercury__trace__fail_vars_3_0_i4);
Declare_label(mercury__trace__fail_vars_3_0_i5);
Declare_label(mercury__trace__fail_vars_3_0_i8);
Declare_label(mercury__trace__fail_vars_3_0_i7);
Define_extern_entry(mercury__trace__reserved_slots_3_0);
Declare_label(mercury__trace__reserved_slots_3_0_i2);
Declare_label(mercury__trace__reserved_slots_3_0_i3);
Declare_label(mercury__trace__reserved_slots_3_0_i6);
Declare_label(mercury__trace__reserved_slots_3_0_i8);
Declare_label(mercury__trace__reserved_slots_3_0_i5);
Declare_label(mercury__trace__reserved_slots_3_0_i9);
Declare_label(mercury__trace__reserved_slots_3_0_i10);
Declare_label(mercury__trace__reserved_slots_3_0_i12);
Declare_label(mercury__trace__reserved_slots_3_0_i13);
Declare_label(mercury__trace__reserved_slots_3_0_i14);
Declare_label(mercury__trace__reserved_slots_3_0_i17);
Declare_label(mercury__trace__reserved_slots_3_0_i18);
Define_extern_entry(mercury__trace__setup_5_0);
Declare_label(mercury__trace__setup_5_0_i2);
Declare_label(mercury__trace__setup_5_0_i3);
Declare_label(mercury__trace__setup_5_0_i4);
Declare_label(mercury__trace__setup_5_0_i8);
Declare_label(mercury__trace__setup_5_0_i5);
Declare_label(mercury__trace__setup_5_0_i9);
Declare_label(mercury__trace__setup_5_0_i11);
Declare_label(mercury__trace__setup_5_0_i12);
Declare_label(mercury__trace__setup_5_0_i1030);
Declare_label(mercury__trace__setup_5_0_i13);
Declare_label(mercury__trace__setup_5_0_i16);
Declare_label(mercury__trace__setup_5_0_i18);
Declare_label(mercury__trace__setup_5_0_i17);
Declare_label(mercury__trace__setup_5_0_i20);
Declare_label(mercury__trace__setup_5_0_i22);
Declare_label(mercury__trace__setup_5_0_i24);
Declare_label(mercury__trace__setup_5_0_i1053);
Define_extern_entry(mercury__trace__generate_slot_fill_code_4_0);
Declare_label(mercury__trace__generate_slot_fill_code_4_0_i2);
Declare_label(mercury__trace__generate_slot_fill_code_4_0_i3);
Declare_label(mercury__trace__generate_slot_fill_code_4_0_i4);
Declare_label(mercury__trace__generate_slot_fill_code_4_0_i5);
Declare_label(mercury__trace__generate_slot_fill_code_4_0_i6);
Declare_label(mercury__trace__generate_slot_fill_code_4_0_i7);
Declare_label(mercury__trace__generate_slot_fill_code_4_0_i8);
Declare_label(mercury__trace__generate_slot_fill_code_4_0_i9);
Declare_label(mercury__trace__generate_slot_fill_code_4_0_i10);
Declare_label(mercury__trace__generate_slot_fill_code_4_0_i11);
Declare_label(mercury__trace__generate_slot_fill_code_4_0_i12);
Declare_label(mercury__trace__generate_slot_fill_code_4_0_i15);
Declare_label(mercury__trace__generate_slot_fill_code_4_0_i16);
Declare_label(mercury__trace__generate_slot_fill_code_4_0_i17);
Declare_label(mercury__trace__generate_slot_fill_code_4_0_i13);
Declare_label(mercury__trace__generate_slot_fill_code_4_0_i22);
Declare_label(mercury__trace__generate_slot_fill_code_4_0_i23);
Declare_label(mercury__trace__generate_slot_fill_code_4_0_i24);
Declare_label(mercury__trace__generate_slot_fill_code_4_0_i20);
Declare_label(mercury__trace__generate_slot_fill_code_4_0_i26);
Declare_label(mercury__trace__generate_slot_fill_code_4_0_i27);
Declare_label(mercury__trace__generate_slot_fill_code_4_0_i28);
Define_extern_entry(mercury__trace__prepare_for_call_3_0);
Declare_label(mercury__trace__prepare_for_call_3_0_i2);
Declare_label(mercury__trace__prepare_for_call_3_0_i3);
Declare_label(mercury__trace__prepare_for_call_3_0_i6);
Declare_label(mercury__trace__prepare_for_call_3_0_i9);
Declare_label(mercury__trace__prepare_for_call_3_0_i10);
Declare_label(mercury__trace__prepare_for_call_3_0_i12);
Declare_label(mercury__trace__prepare_for_call_3_0_i4);
Define_extern_entry(mercury__trace__maybe_generate_internal_event_code_4_0);
Declare_label(mercury__trace__maybe_generate_internal_event_code_4_0_i2);
Declare_label(mercury__trace__maybe_generate_internal_event_code_4_0_i5);
Declare_label(mercury__trace__maybe_generate_internal_event_code_4_0_i15);
Declare_label(mercury__trace__maybe_generate_internal_event_code_4_0_i10);
Declare_label(mercury__trace__maybe_generate_internal_event_code_4_0_i11);
Declare_label(mercury__trace__maybe_generate_internal_event_code_4_0_i12);
Declare_label(mercury__trace__maybe_generate_internal_event_code_4_0_i13);
Declare_label(mercury__trace__maybe_generate_internal_event_code_4_0_i14);
Declare_label(mercury__trace__maybe_generate_internal_event_code_4_0_i8);
Declare_label(mercury__trace__maybe_generate_internal_event_code_4_0_i6);
Declare_label(mercury__trace__maybe_generate_internal_event_code_4_0_i17);
Declare_label(mercury__trace__maybe_generate_internal_event_code_4_0_i1016);
Declare_label(mercury__trace__maybe_generate_internal_event_code_4_0_i18);
Declare_label(mercury__trace__maybe_generate_internal_event_code_4_0_i20);
Declare_label(mercury__trace__maybe_generate_internal_event_code_4_0_i1007);
Declare_label(mercury__trace__maybe_generate_internal_event_code_4_0_i19);
Declare_label(mercury__trace__maybe_generate_internal_event_code_4_0_i23);
Declare_label(mercury__trace__maybe_generate_internal_event_code_4_0_i24);
Declare_label(mercury__trace__maybe_generate_internal_event_code_4_0_i25);
Define_extern_entry(mercury__trace__maybe_generate_negated_event_code_5_0);
Declare_label(mercury__trace__maybe_generate_negated_event_code_5_0_i2);
Declare_label(mercury__trace__maybe_generate_negated_event_code_5_0_i6);
Declare_label(mercury__trace__maybe_generate_negated_event_code_5_0_i5);
Declare_label(mercury__trace__maybe_generate_negated_event_code_5_0_i7);
Declare_label(mercury__trace__maybe_generate_negated_event_code_5_0_i8);
Declare_label(mercury__trace__maybe_generate_negated_event_code_5_0_i9);
Declare_label(mercury__trace__maybe_generate_negated_event_code_5_0_i3);
Define_extern_entry(mercury__trace__maybe_generate_pragma_event_code_5_0);
Declare_label(mercury__trace__maybe_generate_pragma_event_code_5_0_i2);
Declare_label(mercury__trace__maybe_generate_pragma_event_code_5_0_i6);
Declare_label(mercury__trace__maybe_generate_pragma_event_code_5_0_i7);
Declare_label(mercury__trace__maybe_generate_pragma_event_code_5_0_i3);
Define_extern_entry(mercury__trace__generate_external_event_code_8_0);
Declare_label(mercury__trace__generate_external_event_code_8_0_i3);
Declare_label(mercury__trace__generate_external_event_code_8_0_i4);
Define_extern_entry(mercury__trace__maybe_setup_redo_event_2_0);
Declare_label(mercury__trace__maybe_setup_redo_event_2_0_i5);
Declare_label(mercury__trace__maybe_setup_redo_event_2_0_i6);
Declare_label(mercury__trace__maybe_setup_redo_event_2_0_i2);
Define_extern_entry(mercury__trace__path_to_string_2_0);
Declare_label(mercury__trace__path_to_string_2_0_i2);
Declare_label(mercury__trace__path_to_string_2_0_i3);
Declare_static(mercury__trace__generate_event_code_9_0);
Declare_label(mercury__trace__generate_event_code_9_0_i2);
Declare_label(mercury__trace__generate_event_code_9_0_i3);
Declare_label(mercury__trace__generate_event_code_9_0_i4);
Declare_label(mercury__trace__generate_event_code_9_0_i20);
Declare_label(mercury__trace__generate_event_code_9_0_i21);
Declare_label(mercury__trace__generate_event_code_9_0_i22);
Declare_label(mercury__trace__generate_event_code_9_0_i19);
Declare_label(mercury__trace__generate_event_code_9_0_i23);
Declare_label(mercury__trace__generate_event_code_9_0_i25);
Declare_label(mercury__trace__generate_event_code_9_0_i27);
Declare_label(mercury__trace__generate_event_code_9_0_i30);
Declare_label(mercury__trace__generate_event_code_9_0_i31);
Declare_label(mercury__trace__generate_event_code_9_0_i15);
Declare_label(mercury__trace__generate_event_code_9_0_i16);
Declare_label(mercury__trace__generate_event_code_9_0_i17);
Declare_label(mercury__trace__generate_event_code_9_0_i7);
Declare_label(mercury__trace__generate_event_code_9_0_i8);
Declare_label(mercury__trace__generate_event_code_9_0_i9);
Declare_label(mercury__trace__generate_event_code_9_0_i10);
Declare_label(mercury__trace__generate_event_code_9_0_i11);
Declare_label(mercury__trace__generate_event_code_9_0_i12);
Declare_label(mercury__trace__generate_event_code_9_0_i13);
Declare_label(mercury__trace__generate_event_code_9_0_i14);
Declare_label(mercury__trace__generate_event_code_9_0_i32);
Declare_label(mercury__trace__generate_event_code_9_0_i33);
Declare_label(mercury__trace__generate_event_code_9_0_i34);
Declare_label(mercury__trace__generate_event_code_9_0_i36);
Declare_label(mercury__trace__generate_event_code_9_0_i37);
Declare_label(mercury__trace__generate_event_code_9_0_i38);
Declare_label(mercury__trace__generate_event_code_9_0_i39);
Declare_label(mercury__trace__generate_event_code_9_0_i40);
Declare_label(mercury__trace__generate_event_code_9_0_i41);
Declare_label(mercury__trace__generate_event_code_9_0_i42);
Declare_label(mercury__trace__generate_event_code_9_0_i43);
Declare_label(mercury__trace__generate_event_code_9_0_i44);
Declare_label(mercury__trace__generate_event_code_9_0_i48);
Declare_label(mercury__trace__generate_event_code_9_0_i50);
Declare_label(mercury__trace__generate_event_code_9_0_i45);
Declare_label(mercury__trace__generate_event_code_9_0_i46);
Declare_label(mercury__trace__generate_event_code_9_0_i52);
Declare_static(mercury__trace__produce_vars_9_0);
Declare_label(mercury__trace__produce_vars_9_0_i4);
Declare_label(mercury__trace__produce_vars_9_0_i5);
Declare_label(mercury__trace__produce_vars_9_0_i6);
Declare_label(mercury__trace__produce_vars_9_0_i7);
Declare_label(mercury__trace__produce_vars_9_0_i9);
Declare_label(mercury__trace__produce_vars_9_0_i10);
Declare_label(mercury__trace__produce_vars_9_0_i12);
Declare_label(mercury__trace__produce_vars_9_0_i11);
Declare_label(mercury__trace__produce_vars_9_0_i14);
Declare_label(mercury__trace__produce_vars_9_0_i15);
Declare_label(mercury__trace__produce_vars_9_0_i18);
Declare_label(mercury__trace__produce_vars_9_0_i16);
Declare_label(mercury__trace__produce_vars_9_0_i21);
Declare_label(mercury__trace__produce_vars_9_0_i22);
Declare_label(mercury__trace__produce_vars_9_0_i23);
Declare_label(mercury__trace__produce_vars_9_0_i3);
Declare_static(mercury__trace__build_fail_vars_5_0);
Declare_label(mercury__trace__build_fail_vars_5_0_i3);
Declare_label(mercury__trace__build_fail_vars_5_0_i8);
Declare_label(mercury__trace__build_fail_vars_5_0_i15);
Declare_label(mercury__trace__build_fail_vars_5_0_i10);
Declare_label(mercury__trace__build_fail_vars_5_0_i2);
Declare_label(mercury__trace__build_fail_vars_5_0_i1011);
Declare_label(mercury__trace__build_fail_vars_5_0_i1);
Declare_static(mercury__trace__stackref_to_string_2_0);
Declare_label(mercury__trace__stackref_to_string_2_0_i4);
Declare_label(mercury__trace__stackref_to_string_2_0_i2);
Declare_label(mercury__trace__stackref_to_string_2_0_i8);
Declare_label(mercury__trace__stackref_to_string_2_0_i6);
Declare_static(mercury__trace__path_steps_to_strings_2_0);
Declare_label(mercury__trace__path_steps_to_strings_2_0_i6);
Declare_label(mercury__trace__path_steps_to_strings_2_0_i7);
Declare_label(mercury__trace__path_steps_to_strings_2_0_i8);
Declare_label(mercury__trace__path_steps_to_strings_2_0_i9);
Declare_label(mercury__trace__path_steps_to_strings_2_0_i10);
Declare_label(mercury__trace__path_steps_to_strings_2_0_i11);
Declare_label(mercury__trace__path_steps_to_strings_2_0_i12);
Declare_label(mercury__trace__path_steps_to_strings_2_0_i13);
Declare_label(mercury__trace__path_steps_to_strings_2_0_i14);
Declare_label(mercury__trace__path_steps_to_strings_2_0_i15);
Declare_label(mercury__trace__path_steps_to_strings_2_0_i17);
Declare_label(mercury__trace__path_steps_to_strings_2_0_i18);
Declare_label(mercury__trace__path_steps_to_strings_2_0_i20);
Declare_label(mercury__trace__path_steps_to_strings_2_0_i21);
Declare_label(mercury__trace__path_steps_to_strings_2_0_i22);
Declare_label(mercury__trace__path_steps_to_strings_2_0_i23);
Declare_label(mercury__trace__path_steps_to_strings_2_0_i3);
Declare_static(mercury__trace__event_num_slot_2_0);
Declare_label(mercury__trace__event_num_slot_2_0_i2);
Declare_static(mercury__trace__call_num_slot_2_0);
Declare_label(mercury__trace__call_num_slot_2_0_i2);
Declare_static(mercury__trace__call_depth_slot_2_0);
Declare_label(mercury__trace__call_depth_slot_2_0_i2);
Declare_static(mercury__trace__redo_layout_slot_2_0);
Declare_label(mercury__trace__redo_layout_slot_2_0_i2);
Declare_static(mercury__trace__trace_info_get_trace_type_2_0);
Declare_static(mercury__trace__trace_info_get_maybe_trail_slots_2_0);
Declare_static(mercury__trace__trace_info_get_maybe_redo_layout_slot_2_0);
Define_extern_entry(mercury____Unify___trace__external_trace_port_0_0);
Declare_label(mercury____Unify___trace__external_trace_port_0_0_i1);
Define_extern_entry(mercury____Index___trace__external_trace_port_0_0);
Define_extern_entry(mercury____Compare___trace__external_trace_port_0_0);
Define_extern_entry(mercury____Unify___trace__negation_end_port_0_0);
Declare_label(mercury____Unify___trace__negation_end_port_0_0_i1);
Define_extern_entry(mercury____Index___trace__negation_end_port_0_0);
Define_extern_entry(mercury____Compare___trace__negation_end_port_0_0);
Define_extern_entry(mercury____Unify___trace__nondet_pragma_trace_port_0_0);
Declare_label(mercury____Unify___trace__nondet_pragma_trace_port_0_0_i1);
Define_extern_entry(mercury____Index___trace__nondet_pragma_trace_port_0_0);
Define_extern_entry(mercury____Compare___trace__nondet_pragma_trace_port_0_0);
Define_extern_entry(mercury____Unify___trace__trace_info_0_0);
Declare_label(mercury____Unify___trace__trace_info_0_0_i3);
Declare_label(mercury____Unify___trace__trace_info_0_0_i6);
Declare_label(mercury____Unify___trace__trace_info_0_0_i8);
Declare_label(mercury____Unify___trace__trace_info_0_0_i1013);
Declare_label(mercury____Unify___trace__trace_info_0_0_i1);
Define_extern_entry(mercury____Index___trace__trace_info_0_0);
Define_extern_entry(mercury____Compare___trace__trace_info_0_0);
Declare_label(mercury____Compare___trace__trace_info_0_0_i3);
Declare_label(mercury____Compare___trace__trace_info_0_0_i7);
Declare_label(mercury____Compare___trace__trace_info_0_0_i11);
Declare_label(mercury____Compare___trace__trace_info_0_0_i15);
Declare_label(mercury____Compare___trace__trace_info_0_0_i22);
Define_extern_entry(mercury____Unify___trace__trace_slot_info_0_0);
Declare_label(mercury____Unify___trace__trace_slot_info_0_0_i2);
Declare_label(mercury____Unify___trace__trace_slot_info_0_0_i4);
Declare_label(mercury____Unify___trace__trace_slot_info_0_0_i1);
Define_extern_entry(mercury____Index___trace__trace_slot_info_0_0);
Define_extern_entry(mercury____Compare___trace__trace_slot_info_0_0);
Declare_label(mercury____Compare___trace__trace_slot_info_0_0_i3);
Declare_label(mercury____Compare___trace__trace_slot_info_0_0_i7);
Declare_label(mercury____Compare___trace__trace_slot_info_0_0_i12);
Declare_static(mercury____Unify___trace__trace_port_info_0_0);
Declare_label(mercury____Unify___trace__trace_port_info_0_0_i1011);
Declare_label(mercury____Unify___trace__trace_port_info_0_0_i1010);
Declare_label(mercury____Unify___trace__trace_port_info_0_0_i4);
Declare_label(mercury____Unify___trace__trace_port_info_0_0_i6);
Declare_label(mercury____Unify___trace__trace_port_info_0_0_i1012);
Declare_label(mercury____Unify___trace__trace_port_info_0_0_i1);
Declare_static(mercury____Index___trace__trace_port_info_0_0);
Declare_label(mercury____Index___trace__trace_port_info_0_0_i6);
Declare_label(mercury____Index___trace__trace_port_info_0_0_i5);
Declare_label(mercury____Index___trace__trace_port_info_0_0_i4);
Declare_static(mercury____Compare___trace__trace_port_info_0_0);
Declare_label(mercury____Compare___trace__trace_port_info_0_0_i6);
Declare_label(mercury____Compare___trace__trace_port_info_0_0_i5);
Declare_label(mercury____Compare___trace__trace_port_info_0_0_i4);
Declare_label(mercury____Compare___trace__trace_port_info_0_0_i2);
Declare_label(mercury____Compare___trace__trace_port_info_0_0_i11);
Declare_label(mercury____Compare___trace__trace_port_info_0_0_i10);
Declare_label(mercury____Compare___trace__trace_port_info_0_0_i9);
Declare_label(mercury____Compare___trace__trace_port_info_0_0_i7);
Declare_label(mercury____Compare___trace__trace_port_info_0_0_i12);
Declare_label(mercury____Compare___trace__trace_port_info_0_0_i13);
Declare_label(mercury____Compare___trace__trace_port_info_0_0_i29);
Declare_label(mercury____Compare___trace__trace_port_info_0_0_i26);
Declare_label(mercury____Compare___trace__trace_port_info_0_0_i18);
Declare_label(mercury____Compare___trace__trace_port_info_0_0_i21);
Declare_label(mercury____Compare___trace__trace_port_info_0_0_i1025);
Declare_label(mercury____Compare___trace__trace_port_info_0_0_i35);
Declare_static(mercury____Unify___trace__trace_type_0_0);
Declare_label(mercury____Unify___trace__trace_type_0_0_i3);
Declare_label(mercury____Unify___trace__trace_type_0_0_i1);
Declare_static(mercury____Index___trace__trace_type_0_0);
Declare_label(mercury____Index___trace__trace_type_0_0_i3);
Declare_static(mercury____Compare___trace__trace_type_0_0);
Declare_label(mercury____Compare___trace__trace_type_0_0_i3);
Declare_label(mercury____Compare___trace__trace_type_0_0_i2);
Declare_label(mercury____Compare___trace__trace_type_0_0_i5);
Declare_label(mercury____Compare___trace__trace_type_0_0_i4);
Declare_label(mercury____Compare___trace__trace_type_0_0_i6);
Declare_label(mercury____Compare___trace__trace_type_0_0_i7);
Declare_label(mercury____Compare___trace__trace_type_0_0_i11);
Declare_label(mercury____Compare___trace__trace_type_0_0_i1014);

const struct MR_TypeCtorInfo_struct mercury_data_trace__type_ctor_info_external_trace_port_0;

const struct MR_TypeCtorInfo_struct mercury_data_trace__type_ctor_info_negation_end_port_0;

const struct MR_TypeCtorInfo_struct mercury_data_trace__type_ctor_info_nondet_pragma_trace_port_0;

const struct MR_TypeCtorInfo_struct mercury_data_trace__type_ctor_info_trace_info_0;

const struct MR_TypeCtorInfo_struct mercury_data_trace__type_ctor_info_trace_port_info_0;

const struct MR_TypeCtorInfo_struct mercury_data_trace__type_ctor_info_trace_slot_info_0;

const struct MR_TypeCtorInfo_struct mercury_data_trace__type_ctor_info_trace_type_0;

static const struct mercury_data_trace__common_0_struct {
	Word * f1;
	Word * f2;
}  mercury_data_trace__common_0;

static const struct mercury_data_trace__common_1_struct {
	String f1;
	Word * f2;
}  mercury_data_trace__common_1;

static const struct mercury_data_trace__common_2_struct {
	String f1;
	Word * f2;
}  mercury_data_trace__common_2;

static const struct mercury_data_trace__common_3_struct {
	String f1;
	Word * f2;
}  mercury_data_trace__common_3;

static const struct mercury_data_trace__common_4_struct {
	String f1;
	Word * f2;
}  mercury_data_trace__common_4;

static const struct mercury_data_trace__common_5_struct {
	String f1;
	Word * f2;
}  mercury_data_trace__common_5;

static const struct mercury_data_trace__common_6_struct {
	Integer f1;
	Integer f2;
}  mercury_data_trace__common_6;

static const struct mercury_data_trace__common_7_struct {
	Integer f1;
	Integer f2;
}  mercury_data_trace__common_7;

static const struct mercury_data_trace__common_8_struct {
	String f1;
	Word * f2;
}  mercury_data_trace__common_8;

static const struct mercury_data_trace__common_9_struct {
	Integer f1;
	String f2;
}  mercury_data_trace__common_9;

static const struct mercury_data_trace__common_10_struct {
	Word * f1;
	String f2;
}  mercury_data_trace__common_10;

static const struct mercury_data_trace__common_11_struct {
	Integer f1;
	String f2;
}  mercury_data_trace__common_11;

static const struct mercury_data_trace__common_12_struct {
	Word * f1;
	String f2;
}  mercury_data_trace__common_12;

static const struct mercury_data_trace__common_13_struct {
	Integer f1;
}  mercury_data_trace__common_13;

static const struct mercury_data_trace__common_14_struct {
	Integer f1;
	Word * f2;
	Word * f3;
}  mercury_data_trace__common_14;

static const struct mercury_data_trace__common_15_struct {
	Word * f1;
	String f2;
}  mercury_data_trace__common_15;

static const struct mercury_data_trace__common_16_struct {
	Word * f1;
	Word * f2;
}  mercury_data_trace__common_16;

static const struct mercury_data_trace__common_17_struct {
	Word * f1;
}  mercury_data_trace__common_17;

static const struct mercury_data_trace__common_18_struct {
	Word * f1;
}  mercury_data_trace__common_18;

static const struct mercury_data_trace__common_19_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_trace__common_19;

static const struct mercury_data_trace__common_20_struct {
	Integer f1;
	Integer f2;
}  mercury_data_trace__common_20;

static const struct mercury_data_trace__common_21_struct {
	Integer f1;
	Word * f2;
	Word * f3;
}  mercury_data_trace__common_21;

static const struct mercury_data_trace__common_22_struct {
	Word * f1;
	String f2;
}  mercury_data_trace__common_22;

static const struct mercury_data_trace__common_23_struct {
	Word * f1;
	Word * f2;
}  mercury_data_trace__common_23;

static const struct mercury_data_trace__common_24_struct {
	Word * f1;
}  mercury_data_trace__common_24;

static const struct mercury_data_trace__common_25_struct {
	Word * f1;
	Word * f2;
}  mercury_data_trace__common_25;

static const struct mercury_data_trace__common_26_struct {
	Word * f1;
	Word * f2;
}  mercury_data_trace__common_26;

static const struct mercury_data_trace__common_27_struct {
	Word * f1;
	Word * f2;
}  mercury_data_trace__common_27;

static const struct mercury_data_trace__common_28_struct {
	String f1;
	Word * f2;
}  mercury_data_trace__common_28;

static const struct mercury_data_trace__common_29_struct {
	String f1;
	Word * f2;
}  mercury_data_trace__common_29;

static const struct mercury_data_trace__common_30_struct {
	String f1;
	Word * f2;
}  mercury_data_trace__common_30;

static const struct mercury_data_trace__common_31_struct {
	Integer f1;
	Integer f2;
}  mercury_data_trace__common_31;

static const struct mercury_data_trace__common_32_struct {
	Integer f1;
	Integer f2;
}  mercury_data_trace__common_32;

static const struct mercury_data_trace__common_33_struct {
	Integer f1;
	Integer f2;
}  mercury_data_trace__common_33;

static const struct mercury_data_trace__common_34_struct {
	Integer f1;
	Integer f2;
}  mercury_data_trace__common_34;

static const struct mercury_data_trace__common_35_struct {
	Integer f1;
	Integer f2;
}  mercury_data_trace__common_35;

static const struct mercury_data_trace__common_36_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_trace__common_36;

static const struct mercury_data_trace__common_37_struct {
	Integer f1;
	String f2;
	Word * f3;
	Integer f4;
	Integer f5;
}  mercury_data_trace__common_37;

static const struct mercury_data_trace__common_38_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_trace__common_38;

static const struct mercury_data_trace__common_39_struct {
	Integer f1;
	Integer f2;
	String f3;
}  mercury_data_trace__common_39;

static const struct mercury_data_trace__common_40_struct {
	Word * f1;
	Word * f2;
}  mercury_data_trace__common_40;

static const struct mercury_data_trace__common_41_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	String f5;
	Word * f6;
	Integer f7;
	Integer f8;
}  mercury_data_trace__common_41;

static const struct mercury_data_trace__common_42_struct {
	Integer f1;
	String f2;
	Word * f3;
	Integer f4;
	Integer f5;
}  mercury_data_trace__common_42;

static const struct mercury_data_trace__common_43_struct {
	Word * f1;
	Word * f2;
}  mercury_data_trace__common_43;

static const struct mercury_data_trace__common_44_struct {
	Word * f1;
	Word * f2;
}  mercury_data_trace__common_44;

static const struct mercury_data_trace__common_45_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	String f4;
	Word * f5;
	Integer f6;
	Integer f7;
}  mercury_data_trace__common_45;

static const struct mercury_data_trace__common_46_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_trace__common_46;

static const struct mercury_data_trace__common_47_struct {
	Integer f1;
	String f2;
	Word * f3;
	Integer f4;
	Integer f5;
}  mercury_data_trace__common_47;

static const struct mercury_data_trace__common_48_struct {
	Integer f1;
	Integer f2;
	String f3;
	String f4;
}  mercury_data_trace__common_48;

static const struct mercury_data_trace__common_49_struct {
	Word * f1;
}  mercury_data_trace__common_49;

static const struct mercury_data_trace__common_50_struct {
	Word * f1;
}  mercury_data_trace__common_50;

static const struct mercury_data_trace__common_51_struct {
	Word * f1;
	Word * f2;
}  mercury_data_trace__common_51;

static const struct mercury_data_trace__common_52_struct {
	Word * f1;
	Word * f2;
}  mercury_data_trace__common_52;

static const struct mercury_data_trace__common_53_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	Word * f5;
	Word * f6;
	String f7;
	Word * f8;
	Integer f9;
	Integer f10;
}  mercury_data_trace__common_53;

static const struct mercury_data_trace__common_54_struct {
	Integer f1;
	Integer f2;
	String f3;
	String f4;
}  mercury_data_trace__common_54;

static const struct mercury_data_trace__common_55_struct {
	Integer f1;
	Integer f2;
	String f3;
	String f4;
}  mercury_data_trace__common_55;

static const struct mercury_data_trace__common_56_struct {
	Integer f1;
	Integer f2;
	String f3;
	String f4;
	String f5;
}  mercury_data_trace__common_56;

static const struct mercury_data_trace__type_ctor_functors_trace_type_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
	Word * f4;
}  mercury_data_trace__type_ctor_functors_trace_type_0;

static const struct mercury_data_trace__type_ctor_layout_trace_type_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_trace__type_ctor_layout_trace_type_0;

static const struct mercury_data_trace__type_ctor_functors_trace_slot_info_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_trace__type_ctor_functors_trace_slot_info_0;

static const struct mercury_data_trace__type_ctor_layout_trace_slot_info_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_trace__type_ctor_layout_trace_slot_info_0;

static const struct mercury_data_trace__type_ctor_functors_trace_port_info_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
	Word * f4;
	Word * f5;
	Word * f6;
}  mercury_data_trace__type_ctor_functors_trace_port_info_0;

static const struct mercury_data_trace__type_ctor_layout_trace_port_info_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_trace__type_ctor_layout_trace_port_info_0;

static const struct mercury_data_trace__type_ctor_functors_trace_info_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_trace__type_ctor_functors_trace_info_0;

static const struct mercury_data_trace__type_ctor_layout_trace_info_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_trace__type_ctor_layout_trace_info_0;

static const struct mercury_data_trace__type_ctor_functors_nondet_pragma_trace_port_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_trace__type_ctor_functors_nondet_pragma_trace_port_0;

static const struct mercury_data_trace__type_ctor_layout_nondet_pragma_trace_port_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_trace__type_ctor_layout_nondet_pragma_trace_port_0;

static const struct mercury_data_trace__type_ctor_functors_negation_end_port_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_trace__type_ctor_functors_negation_end_port_0;

static const struct mercury_data_trace__type_ctor_layout_negation_end_port_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_trace__type_ctor_layout_negation_end_port_0;

static const struct mercury_data_trace__type_ctor_functors_external_trace_port_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_trace__type_ctor_functors_external_trace_port_0;

static const struct mercury_data_trace__type_ctor_layout_external_trace_port_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_trace__type_ctor_layout_external_trace_port_0;

const struct MR_TypeCtorInfo_struct mercury_data_trace__type_ctor_info_external_trace_port_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___trace__external_trace_port_0_0),
	ENTRY(mercury____Index___trace__external_trace_port_0_0),
	ENTRY(mercury____Compare___trace__external_trace_port_0_0),
	(Integer) 0,
	(Word *) &mercury_data_trace__type_ctor_functors_external_trace_port_0,
	(Word *) &mercury_data_trace__type_ctor_layout_external_trace_port_0,
	MR_string_const("trace", 5),
	MR_string_const("external_trace_port", 19),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_trace__type_ctor_info_negation_end_port_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___trace__negation_end_port_0_0),
	ENTRY(mercury____Index___trace__negation_end_port_0_0),
	ENTRY(mercury____Compare___trace__negation_end_port_0_0),
	(Integer) 0,
	(Word *) &mercury_data_trace__type_ctor_functors_negation_end_port_0,
	(Word *) &mercury_data_trace__type_ctor_layout_negation_end_port_0,
	MR_string_const("trace", 5),
	MR_string_const("negation_end_port", 17),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_trace__type_ctor_info_nondet_pragma_trace_port_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___trace__nondet_pragma_trace_port_0_0),
	ENTRY(mercury____Index___trace__nondet_pragma_trace_port_0_0),
	ENTRY(mercury____Compare___trace__nondet_pragma_trace_port_0_0),
	(Integer) 0,
	(Word *) &mercury_data_trace__type_ctor_functors_nondet_pragma_trace_port_0,
	(Word *) &mercury_data_trace__type_ctor_layout_nondet_pragma_trace_port_0,
	MR_string_const("trace", 5),
	MR_string_const("nondet_pragma_trace_port", 24),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_trace__type_ctor_info_trace_info_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___trace__trace_info_0_0),
	ENTRY(mercury____Index___trace__trace_info_0_0),
	ENTRY(mercury____Compare___trace__trace_info_0_0),
	(Integer) 2,
	(Word *) &mercury_data_trace__type_ctor_functors_trace_info_0,
	(Word *) &mercury_data_trace__type_ctor_layout_trace_info_0,
	MR_string_const("trace", 5),
	MR_string_const("trace_info", 10),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_trace__type_ctor_info_trace_port_info_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___trace__trace_port_info_0_0),
	STATIC(mercury____Index___trace__trace_port_info_0_0),
	STATIC(mercury____Compare___trace__trace_port_info_0_0),
	(Integer) 2,
	(Word *) &mercury_data_trace__type_ctor_functors_trace_port_info_0,
	(Word *) &mercury_data_trace__type_ctor_layout_trace_port_info_0,
	MR_string_const("trace", 5),
	MR_string_const("trace_port_info", 15),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_trace__type_ctor_info_trace_slot_info_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___trace__trace_slot_info_0_0),
	ENTRY(mercury____Index___trace__trace_slot_info_0_0),
	ENTRY(mercury____Compare___trace__trace_slot_info_0_0),
	(Integer) 2,
	(Word *) &mercury_data_trace__type_ctor_functors_trace_slot_info_0,
	(Word *) &mercury_data_trace__type_ctor_layout_trace_slot_info_0,
	MR_string_const("trace", 5),
	MR_string_const("trace_slot_info", 15),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_trace__type_ctor_info_trace_type_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___trace__trace_type_0_0),
	STATIC(mercury____Index___trace__trace_type_0_0),
	STATIC(mercury____Compare___trace__trace_type_0_0),
	(Integer) 2,
	(Word *) &mercury_data_trace__type_ctor_functors_trace_type_0,
	(Word *) &mercury_data_trace__type_ctor_layout_trace_type_0,
	MR_string_const("trace", 5),
	MR_string_const("trace_type", 10),
	(Integer) 3
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_var_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_prog_var_type_0;
static const struct mercury_data_trace__common_0_struct mercury_data_trace__common_0 = {
	(Word *) &mercury_data_term__type_ctor_info_var_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0
};

static const struct mercury_data_trace__common_1_struct mercury_data_trace__common_1 = {
	MR_string_const(" = MR_trace_incr_depth();", 25),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_trace__common_2_struct mercury_data_trace__common_2 = {
	MR_string_const(";", 1),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_trace__common_3_struct mercury_data_trace__common_3 = {
	MR_string_const(");", 2),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_trace__common_4_struct mercury_data_trace__common_4 = {
	MR_string_const("\t\t}", 3),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_trace__common_5_struct mercury_data_trace__common_5 = {
	MR_string_const(" = MR_trace_call_depth;\n", 24),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_trace__common_4)
};

static const struct mercury_data_trace__common_6_struct mercury_data_trace__common_6 = {
	(Integer) 1,
	(Integer) 3
};

static const struct mercury_data_trace__common_7_struct mercury_data_trace__common_7 = {
	(Integer) 0,
	(Integer) 3
};

static const struct mercury_data_trace__common_8_struct mercury_data_trace__common_8 = {
	MR_string_const(");\n", 3),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_trace__common_9_struct mercury_data_trace__common_9 = {
	(Integer) 7,
	MR_string_const("MR_trace_from_full = TRUE;\n", 27)
};

static const struct mercury_data_trace__common_10_struct mercury_data_trace__common_10 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_trace__common_9),
	MR_string_const("", 0)
};

static const struct mercury_data_trace__common_11_struct mercury_data_trace__common_11 = {
	(Integer) 7,
	MR_string_const("MR_trace_from_full = FALSE;\n", 28)
};

static const struct mercury_data_trace__common_12_struct mercury_data_trace__common_12 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_trace__common_11),
	MR_string_const("", 0)
};

static const struct mercury_data_trace__common_13_struct mercury_data_trace__common_13 = {
	(Integer) 1
};

static const struct mercury_data_trace__common_14_struct mercury_data_trace__common_14 = {
	(Integer) 3,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_13),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 4))
};

static const struct mercury_data_trace__common_15_struct mercury_data_trace__common_15 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_trace__common_14),
	MR_string_const("set up deep redo event", 22)
};

static const struct mercury_data_trace__common_16_struct mercury_data_trace__common_16 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_15),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_trace__common_17_struct mercury_data_trace__common_17 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_trace__common_16)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_llds__type_ctor_info_lval_0;
static const struct mercury_data_trace__common_18_struct mercury_data_trace__common_18 = {
	(Word *) &mercury_data_llds__type_ctor_info_lval_0
};

static const struct mercury_data_trace__common_19_struct mercury_data_trace__common_19 = {
	(Integer) 0,
	MR_string_const("trace", 5),
	MR_string_const("trace", 5),
	MR_string_const("IntroducedFrom__pred__maybe_setup_redo_event__665__1", 52),
	2,
	0,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_18),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_18)
};

static const struct mercury_data_trace__common_20_struct mercury_data_trace__common_20 = {
	(Integer) 1,
	(Integer) 5
};

static const struct mercury_data_trace__common_21_struct mercury_data_trace__common_21 = {
	(Integer) 3,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_13),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 3))
};

static const struct mercury_data_trace__common_22_struct mercury_data_trace__common_22 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_trace__common_21),
	MR_string_const("set up shallow redo event", 25)
};

static const struct mercury_data_trace__common_23_struct mercury_data_trace__common_23 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_22),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_trace__common_24_struct mercury_data_trace__common_24 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_trace__common_23)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_tvar_type_0;
static const struct mercury_data_trace__common_25_struct mercury_data_trace__common_25 = {
	(Word *) &mercury_data_term__type_ctor_info_var_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0
};

static const struct mercury_data_trace__common_26_struct mercury_data_trace__common_26 = {
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 5)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_trace__common_27_struct mercury_data_trace__common_27 = {
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 6)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_trace__common_28_struct mercury_data_trace__common_28 = {
	MR_string_const("\t\tif (MR_jumpaddr != NULL) GOTO(MR_jumpaddr);", 45),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_trace__common_29_struct mercury_data_trace__common_29 = {
	MR_string_const("\t\trestore_transient_registers();\n", 33),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_trace__common_28)
};

static const struct mercury_data_trace__common_30_struct mercury_data_trace__common_30 = {
	MR_string_const(")", 1),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_trace__common_31_struct mercury_data_trace__common_31 = {
	(Integer) 1,
	(Integer) 1
};

static const struct mercury_data_trace__common_32_struct mercury_data_trace__common_32 = {
	(Integer) 0,
	(Integer) 1
};

static const struct mercury_data_trace__common_33_struct mercury_data_trace__common_33 = {
	(Integer) 1,
	(Integer) 2
};

static const struct mercury_data_trace__common_34_struct mercury_data_trace__common_34 = {
	(Integer) 0,
	(Integer) 2
};

static const struct mercury_data_trace__common_35_struct mercury_data_trace__common_35 = {
	(Integer) 1,
	(Integer) 4
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_pair_2;
static const struct mercury_data_trace__common_36_struct mercury_data_trace__common_36 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_llds__type_ctor_info_lval_0,
	(Word *) &mercury_data_llds__type_ctor_info_lval_0
};

static const struct mercury_data_trace__common_37_struct mercury_data_trace__common_37 = {
	(Integer) 0,
	MR_string_const("deep_trace", 10),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_trace__common_38_struct mercury_data_trace__common_38 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_18),
	MR_string_const("shallow_trace", 13),
	MR_mkword(MR_mktag(1), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_trace__common_39_struct mercury_data_trace__common_39 = {
	(Integer) 0,
	(Integer) 1,
	MR_string_const("deep_trace", 10)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_maybe_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_int_0;
static const struct mercury_data_trace__common_40_struct mercury_data_trace__common_40 = {
	(Word *) &mercury_data_std_util__type_ctor_info_maybe_1,
	(Word *) &mercury_data___type_ctor_info_int_0
};

static const struct mercury_data_trace__common_41_struct mercury_data_trace__common_41 = {
	(Integer) 3,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_40),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_40),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_40),
	MR_string_const("trace_slot_info", 15),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_trace__common_42_struct mercury_data_trace__common_42 = {
	(Integer) 0,
	MR_string_const("external", 8),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_list__type_ctor_info_list_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_goal__type_ctor_info_goal_path_step_0;
static const struct mercury_data_trace__common_43_struct mercury_data_trace__common_43 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data_hlds_goal__type_ctor_info_goal_path_step_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_set__type_ctor_info_set_1;
static const struct mercury_data_trace__common_44_struct mercury_data_trace__common_44 = {
	(Word *) &mercury_data_set__type_ctor_info_set_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_0)
};

static const struct mercury_data_trace__common_45_struct mercury_data_trace__common_45 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_43),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_44),
	MR_string_const("internal", 8),
	MR_mkword(MR_mktag(1), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_trace__common_46_struct mercury_data_trace__common_46 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_43),
	MR_string_const("negation_end", 12),
	MR_mkword(MR_mktag(2), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_trace__common_47_struct mercury_data_trace__common_47 = {
	(Integer) 0,
	MR_string_const("nondet_pragma", 13),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_trace__common_48_struct mercury_data_trace__common_48 = {
	(Integer) 0,
	(Integer) 2,
	MR_string_const("external", 8),
	MR_string_const("nondet_pragma", 13)
};

static const struct mercury_data_trace__common_49_struct mercury_data_trace__common_49 = {
	(Word *) &mercury_data_trace__type_ctor_info_trace_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_bool__type_ctor_info_bool_0;
static const struct mercury_data_trace__common_50_struct mercury_data_trace__common_50 = {
	(Word *) &mercury_data_bool__type_ctor_info_bool_0
};

static const struct mercury_data_trace__common_51_struct mercury_data_trace__common_51 = {
	(Word *) &mercury_data_std_util__type_ctor_info_maybe_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_36)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_llds__type_ctor_info_label_0;
static const struct mercury_data_trace__common_52_struct mercury_data_trace__common_52 = {
	(Word *) &mercury_data_std_util__type_ctor_info_maybe_1,
	(Word *) &mercury_data_llds__type_ctor_info_label_0
};

static const struct mercury_data_trace__common_53_struct mercury_data_trace__common_53 = {
	(Integer) 5,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_49),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_50),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_50),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_51),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_52),
	MR_string_const("trace_info", 10),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_trace__common_54_struct mercury_data_trace__common_54 = {
	(Integer) 1,
	(Integer) 2,
	MR_string_const("nondet_pragma_first", 19),
	MR_string_const("nondet_pragma_later", 19)
};

static const struct mercury_data_trace__common_55_struct mercury_data_trace__common_55 = {
	(Integer) 1,
	(Integer) 2,
	MR_string_const("neg_success", 11),
	MR_string_const("neg_failure", 11)
};

static const struct mercury_data_trace__common_56_struct mercury_data_trace__common_56 = {
	(Integer) 1,
	(Integer) 3,
	MR_string_const("call", 4),
	MR_string_const("exit", 4),
	MR_string_const("fail", 4)
};

static const struct mercury_data_trace__type_ctor_functors_trace_type_0_struct mercury_data_trace__type_ctor_functors_trace_type_0 = {
	(Integer) 0,
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_37),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_38)
};

static const struct mercury_data_trace__type_ctor_layout_trace_type_0_struct mercury_data_trace__type_ctor_layout_trace_type_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_39),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_trace__common_38),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_trace__type_ctor_functors_trace_slot_info_0_struct mercury_data_trace__type_ctor_functors_trace_slot_info_0 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_41)
};

static const struct mercury_data_trace__type_ctor_layout_trace_slot_info_0_struct mercury_data_trace__type_ctor_layout_trace_slot_info_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_trace__common_41),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_trace__type_ctor_functors_trace_port_info_0_struct mercury_data_trace__type_ctor_functors_trace_port_info_0 = {
	(Integer) 0,
	(Integer) 4,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_42),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_45),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_46),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_47)
};

static const struct mercury_data_trace__type_ctor_layout_trace_port_info_0_struct mercury_data_trace__type_ctor_layout_trace_port_info_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_48),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_trace__common_45),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_trace__common_46),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_trace__type_ctor_functors_trace_info_0_struct mercury_data_trace__type_ctor_functors_trace_info_0 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_53)
};

static const struct mercury_data_trace__type_ctor_layout_trace_info_0_struct mercury_data_trace__type_ctor_layout_trace_info_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_trace__common_53),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_trace__type_ctor_functors_nondet_pragma_trace_port_0_struct mercury_data_trace__type_ctor_functors_nondet_pragma_trace_port_0 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_54)
};

static const struct mercury_data_trace__type_ctor_layout_nondet_pragma_trace_port_0_struct mercury_data_trace__type_ctor_layout_nondet_pragma_trace_port_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_54),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_54),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_54),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_54)
};

static const struct mercury_data_trace__type_ctor_functors_negation_end_port_0_struct mercury_data_trace__type_ctor_functors_negation_end_port_0 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_55)
};

static const struct mercury_data_trace__type_ctor_layout_negation_end_port_0_struct mercury_data_trace__type_ctor_layout_negation_end_port_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_55),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_55),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_55),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_55)
};

static const struct mercury_data_trace__type_ctor_functors_external_trace_port_0_struct mercury_data_trace__type_ctor_functors_external_trace_port_0 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_56)
};

static const struct mercury_data_trace__type_ctor_layout_external_trace_port_0_struct mercury_data_trace__type_ctor_layout_external_trace_port_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_56),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_56),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_56),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_56)
};


BEGIN_MODULE(trace_module0)
	init_entry(mercury____Index___trace__trace_slot_info_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___trace__trace_slot_info_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___trace__trace_slot_info_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE


BEGIN_MODULE(trace_module1)
	init_entry(mercury____Index___trace__trace_info_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___trace__trace_info_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___trace__trace_info_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE

Declare_entry(mercury____Unify___llds__lval_0_0);

BEGIN_MODULE(trace_module2)
	init_entry(mercury__trace__IntroducedFrom__pred__maybe_setup_redo_event__665__1_2_0);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__maybe_setup_redo_event__665__1'/2 in mode 0 */
Define_static(mercury__trace__IntroducedFrom__pred__maybe_setup_redo_event__665__1_2_0);
	tailcall(ENTRY(mercury____Unify___llds__lval_0_0),
		STATIC(mercury__trace__IntroducedFrom__pred__maybe_setup_redo_event__665__1_2_0));
END_MODULE

Declare_entry(mercury__hlds_pred__proc_info_headvars_2_0);
Declare_entry(mercury__hlds_pred__proc_info_argmodes_2_0);
Declare_entry(mercury__hlds_pred__proc_info_arg_info_2_0);
Declare_entry(mercury__mode_util__mode_list_get_final_insts_3_0);
Declare_entry(mercury__set__list_to_set_2_0);
Declare_entry(mercury__require__error_1_0);

BEGIN_MODULE(trace_module3)
	init_entry(mercury__trace__fail_vars_3_0);
	init_label(mercury__trace__fail_vars_3_0_i2);
	init_label(mercury__trace__fail_vars_3_0_i3);
	init_label(mercury__trace__fail_vars_3_0_i4);
	init_label(mercury__trace__fail_vars_3_0_i5);
	init_label(mercury__trace__fail_vars_3_0_i8);
	init_label(mercury__trace__fail_vars_3_0_i7);
BEGIN_CODE

/* code for predicate 'fail_vars'/3 in mode 0 */
Define_entry(mercury__trace__fail_vars_3_0);
	MR_incr_sp_push_msg(4, "trace:fail_vars/3");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r2;
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__hlds_pred__proc_info_headvars_2_0),
		mercury__trace__fail_vars_3_0_i2,
		ENTRY(mercury__trace__fail_vars_3_0));
Define_label(mercury__trace__fail_vars_3_0_i2);
	update_prof_current_proc(LABEL(mercury__trace__fail_vars_3_0));
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_argmodes_2_0),
		mercury__trace__fail_vars_3_0_i3,
		ENTRY(mercury__trace__fail_vars_3_0));
Define_label(mercury__trace__fail_vars_3_0_i3);
	update_prof_current_proc(LABEL(mercury__trace__fail_vars_3_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__hlds_pred__proc_info_arg_info_2_0),
		mercury__trace__fail_vars_3_0_i4,
		ENTRY(mercury__trace__fail_vars_3_0));
Define_label(mercury__trace__fail_vars_3_0_i4);
	update_prof_current_proc(LABEL(mercury__trace__fail_vars_3_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r3;
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__mode_util__mode_list_get_final_insts_3_0),
		mercury__trace__fail_vars_3_0_i5,
		ENTRY(mercury__trace__fail_vars_3_0));
Define_label(mercury__trace__fail_vars_3_0_i5);
	update_prof_current_proc(LABEL(mercury__trace__fail_vars_3_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(1);
	call_localret(STATIC(mercury__trace__build_fail_vars_5_0),
		mercury__trace__fail_vars_3_0_i8,
		ENTRY(mercury__trace__fail_vars_3_0));
Define_label(mercury__trace__fail_vars_3_0_i8);
	update_prof_current_proc(LABEL(mercury__trace__fail_vars_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__trace__fail_vars_3_0_i7);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_0);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__set__list_to_set_2_0),
		ENTRY(mercury__trace__fail_vars_3_0));
Define_label(mercury__trace__fail_vars_3_0_i7);
	r1 = (Word) MR_string_const("length mismatch in trace__fail_vars", 35);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__trace__fail_vars_3_0));
END_MODULE

Declare_entry(mercury__globals__get_trace_level_2_0);
Declare_entry(mercury__globals__lookup_bool_option_3_1);
Declare_entry(mercury__hlds_pred__proc_info_interface_code_model_2_0);
Declare_entry(mercury__globals__lookup_bool_option_3_0);

BEGIN_MODULE(trace_module4)
	init_entry(mercury__trace__reserved_slots_3_0);
	init_label(mercury__trace__reserved_slots_3_0_i2);
	init_label(mercury__trace__reserved_slots_3_0_i3);
	init_label(mercury__trace__reserved_slots_3_0_i6);
	init_label(mercury__trace__reserved_slots_3_0_i8);
	init_label(mercury__trace__reserved_slots_3_0_i5);
	init_label(mercury__trace__reserved_slots_3_0_i9);
	init_label(mercury__trace__reserved_slots_3_0_i10);
	init_label(mercury__trace__reserved_slots_3_0_i12);
	init_label(mercury__trace__reserved_slots_3_0_i13);
	init_label(mercury__trace__reserved_slots_3_0_i14);
	init_label(mercury__trace__reserved_slots_3_0_i17);
	init_label(mercury__trace__reserved_slots_3_0_i18);
BEGIN_CODE

/* code for predicate 'reserved_slots'/3 in mode 0 */
Define_entry(mercury__trace__reserved_slots_3_0);
	MR_incr_sp_push_msg(6, "trace:reserved_slots/3");
	MR_stackvar(6) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r2;
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__globals__get_trace_level_2_0),
		mercury__trace__reserved_slots_3_0_i2,
		ENTRY(mercury__trace__reserved_slots_3_0));
Define_label(mercury__trace__reserved_slots_3_0_i2);
	update_prof_current_proc(LABEL(mercury__trace__reserved_slots_3_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__trace__reserved_slots_3_0_i3);
	r1 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__trace__reserved_slots_3_0_i3);
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(2);
	r2 = (Integer) 48;
	r3 = (Integer) 1;
	call_localret(ENTRY(mercury__globals__lookup_bool_option_3_1),
		mercury__trace__reserved_slots_3_0_i6,
		ENTRY(mercury__trace__reserved_slots_3_0));
Define_label(mercury__trace__reserved_slots_3_0_i6);
	update_prof_current_proc(LABEL(mercury__trace__reserved_slots_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__trace__reserved_slots_3_0_i5);
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_interface_code_model_2_0),
		mercury__trace__reserved_slots_3_0_i8,
		ENTRY(mercury__trace__reserved_slots_3_0));
Define_label(mercury__trace__reserved_slots_3_0_i8);
	update_prof_current_proc(LABEL(mercury__trace__reserved_slots_3_0));
	if (((Integer) 2 != (Integer) r1))
		GOTO_LABEL(mercury__trace__reserved_slots_3_0_i5);
	r1 = MR_stackvar(2);
	MR_stackvar(1) = (Integer) 1;
	GOTO_LABEL(mercury__trace__reserved_slots_3_0_i9);
Define_label(mercury__trace__reserved_slots_3_0_i5);
	r1 = MR_stackvar(2);
	MR_stackvar(1) = (Integer) 0;
Define_label(mercury__trace__reserved_slots_3_0_i9);
	if (((Integer) MR_stackvar(3) != (Integer) 2))
		GOTO_LABEL(mercury__trace__reserved_slots_3_0_i10);
	MR_stackvar(4) = (Integer) 0;
	r2 = (Integer) 50;
	GOTO_LABEL(mercury__trace__reserved_slots_3_0_i12);
Define_label(mercury__trace__reserved_slots_3_0_i10);
	MR_stackvar(4) = (Integer) 1;
	r2 = (Integer) 50;
Define_label(mercury__trace__reserved_slots_3_0_i12);
	MR_stackvar(2) = r1;
	call_localret(ENTRY(mercury__globals__lookup_bool_option_3_0),
		mercury__trace__reserved_slots_3_0_i13,
		ENTRY(mercury__trace__reserved_slots_3_0));
Define_label(mercury__trace__reserved_slots_3_0_i13);
	update_prof_current_proc(LABEL(mercury__trace__reserved_slots_3_0));
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__trace__reserved_slots_3_0_i14);
	r1 = MR_stackvar(2);
	MR_stackvar(5) = (Integer) 2;
	r2 = (Integer) 92;
	call_localret(ENTRY(mercury__globals__lookup_bool_option_3_0),
		mercury__trace__reserved_slots_3_0_i17,
		ENTRY(mercury__trace__reserved_slots_3_0));
Define_label(mercury__trace__reserved_slots_3_0_i14);
	r1 = MR_stackvar(2);
	MR_stackvar(5) = (Integer) 0;
	r2 = (Integer) 92;
	call_localret(ENTRY(mercury__globals__lookup_bool_option_3_0),
		mercury__trace__reserved_slots_3_0_i17,
		ENTRY(mercury__trace__reserved_slots_3_0));
Define_label(mercury__trace__reserved_slots_3_0_i17);
	update_prof_current_proc(LABEL(mercury__trace__reserved_slots_3_0));
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__trace__reserved_slots_3_0_i18);
	r1 = (((((Integer) 3 + (Integer) MR_stackvar(1)) + (Integer) MR_stackvar(4)) + (Integer) MR_stackvar(5)) + (Integer) 2);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__trace__reserved_slots_3_0_i18);
	r1 = ((((Integer) 3 + (Integer) MR_stackvar(1)) + (Integer) MR_stackvar(4)) + (Integer) MR_stackvar(5));
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE

Declare_entry(mercury__code_info__get_proc_model_3_0);
Declare_entry(mercury__code_info__get_next_label_3_0);

BEGIN_MODULE(trace_module5)
	init_entry(mercury__trace__setup_5_0);
	init_label(mercury__trace__setup_5_0_i2);
	init_label(mercury__trace__setup_5_0_i3);
	init_label(mercury__trace__setup_5_0_i4);
	init_label(mercury__trace__setup_5_0_i8);
	init_label(mercury__trace__setup_5_0_i5);
	init_label(mercury__trace__setup_5_0_i9);
	init_label(mercury__trace__setup_5_0_i11);
	init_label(mercury__trace__setup_5_0_i12);
	init_label(mercury__trace__setup_5_0_i1030);
	init_label(mercury__trace__setup_5_0_i13);
	init_label(mercury__trace__setup_5_0_i16);
	init_label(mercury__trace__setup_5_0_i18);
	init_label(mercury__trace__setup_5_0_i17);
	init_label(mercury__trace__setup_5_0_i20);
	init_label(mercury__trace__setup_5_0_i22);
	init_label(mercury__trace__setup_5_0_i24);
	init_label(mercury__trace__setup_5_0_i1053);
BEGIN_CODE

/* code for predicate 'setup'/5 in mode 0 */
Define_entry(mercury__trace__setup_5_0);
	MR_incr_sp_push_msg(13, "trace:setup/5");
	MR_stackvar(13) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_proc_model_3_0),
		mercury__trace__setup_5_0_i2,
		ENTRY(mercury__trace__setup_5_0));
Define_label(mercury__trace__setup_5_0_i2);
	update_prof_current_proc(LABEL(mercury__trace__setup_5_0));
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(1);
	r2 = (Integer) 50;
	call_localret(ENTRY(mercury__globals__lookup_bool_option_3_0),
		mercury__trace__setup_5_0_i3,
		ENTRY(mercury__trace__setup_5_0));
Define_label(mercury__trace__setup_5_0_i3);
	update_prof_current_proc(LABEL(mercury__trace__setup_5_0));
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(1);
	r2 = (Integer) 48;
	call_localret(ENTRY(mercury__globals__lookup_bool_option_3_0),
		mercury__trace__setup_5_0_i4,
		ENTRY(mercury__trace__setup_5_0));
Define_label(mercury__trace__setup_5_0_i4);
	update_prof_current_proc(LABEL(mercury__trace__setup_5_0));
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__trace__setup_5_0_i5);
	if (((Integer) MR_stackvar(3) != (Integer) 2))
		GOTO_LABEL(mercury__trace__setup_5_0_i5);
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__code_info__get_next_label_3_0),
		mercury__trace__setup_5_0_i8,
		ENTRY(mercury__trace__setup_5_0));
Define_label(mercury__trace__setup_5_0_i8);
	update_prof_current_proc(LABEL(mercury__trace__setup_5_0));
	MR_stackvar(2) = r2;
	MR_stackvar(6) = (Integer) 5;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__trace__setup_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(5) = r3;
	GOTO_LABEL(mercury__trace__setup_5_0_i9);
Define_label(mercury__trace__setup_5_0_i5);
	r1 = MR_stackvar(1);
	MR_stackvar(5) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_stackvar(6) = (Integer) 4;
Define_label(mercury__trace__setup_5_0_i9);
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__globals__get_trace_level_2_0),
		mercury__trace__setup_5_0_i11,
		ENTRY(mercury__trace__setup_5_0));
Define_label(mercury__trace__setup_5_0_i11);
	update_prof_current_proc(LABEL(mercury__trace__setup_5_0));
	if (((Integer) 2 != (Integer) r1))
		GOTO_LABEL(mercury__trace__setup_5_0_i1030);
	MR_stackvar(9) = MR_stackvar(6);
	r1 = MR_stackvar(1);
	r2 = (Integer) 46;
	call_localret(ENTRY(mercury__globals__lookup_bool_option_3_0),
		mercury__trace__setup_5_0_i12,
		ENTRY(mercury__trace__setup_5_0));
Define_label(mercury__trace__setup_5_0_i12);
	update_prof_current_proc(LABEL(mercury__trace__setup_5_0));
	MR_stackvar(10) = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(7) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_stackvar(8) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	GOTO_LABEL(mercury__trace__setup_5_0_i16);
Define_label(mercury__trace__setup_5_0_i1030);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__trace__setup_5_0, "std_util:maybe/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(6);
	if (((Integer) MR_stackvar(3) != (Integer) 2))
		GOTO_LABEL(mercury__trace__setup_5_0_i13);
	r2 = r1;
	r1 = MR_stackvar(1);
	tag_incr_hp_msg(MR_stackvar(7), MR_mktag(1), (Integer) 1, mercury__trace__setup_5_0, "trace:trace_type/0");
	MR_stackvar(8) = r2;
	MR_stackvar(10) = (Integer) 0;
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 2, mercury__trace__setup_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 1;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(6);
	MR_stackvar(9) = ((Integer) MR_tempr1 + (Integer) 1);
	MR_field(MR_mktag(3), r3, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), MR_stackvar(7), (Integer) 0) = r3;
	GOTO_LABEL(mercury__trace__setup_5_0_i16);
	}
Define_label(mercury__trace__setup_5_0_i13);
	r2 = r1;
	r1 = MR_stackvar(1);
	tag_incr_hp_msg(MR_stackvar(7), MR_mktag(1), (Integer) 1, mercury__trace__setup_5_0, "trace:trace_type/0");
	MR_stackvar(8) = r2;
	MR_stackvar(10) = (Integer) 0;
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 2, mercury__trace__setup_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 0;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(6);
	MR_stackvar(9) = ((Integer) MR_tempr1 + (Integer) 1);
	MR_field(MR_mktag(3), r3, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), MR_stackvar(7), (Integer) 0) = r3;
	}
Define_label(mercury__trace__setup_5_0_i16);
	MR_stackvar(1) = r1;
	r2 = (Integer) 50;
	r3 = (Integer) 1;
	call_localret(ENTRY(mercury__globals__lookup_bool_option_3_1),
		mercury__trace__setup_5_0_i18,
		ENTRY(mercury__trace__setup_5_0));
Define_label(mercury__trace__setup_5_0_i18);
	update_prof_current_proc(LABEL(mercury__trace__setup_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__trace__setup_5_0_i17);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(9);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__trace__setup_5_0, "origin_lost_in_value_number");
	MR_stackvar(11) = r3;
	MR_stackvar(12) = ((Integer) r2 + (Integer) 2);
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	GOTO_LABEL(mercury__trace__setup_5_0_i20);
Define_label(mercury__trace__setup_5_0_i17);
	r1 = MR_stackvar(1);
	MR_stackvar(11) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_stackvar(12) = MR_stackvar(9);
Define_label(mercury__trace__setup_5_0_i20);
	r2 = (Integer) 92;
	r3 = (Integer) 1;
	call_localret(ENTRY(mercury__globals__lookup_bool_option_3_1),
		mercury__trace__setup_5_0_i22,
		ENTRY(mercury__trace__setup_5_0));
Define_label(mercury__trace__setup_5_0_i22);
	update_prof_current_proc(LABEL(mercury__trace__setup_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__trace__setup_5_0_i1053);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__trace__setup_5_0, "std_util:maybe/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(12);
	if (((Integer) MR_stackvar(3) != (Integer) 2))
		GOTO_LABEL(mercury__trace__setup_5_0_i24);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 3, mercury__trace__setup_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r1, (Integer) 2) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(11);
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(8);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 5, mercury__trace__setup_5_0, "trace:trace_info/0");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(7);
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_stackvar(10);
	MR_field(MR_mktag(0), r2, (Integer) 2) = MR_stackvar(4);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 1, mercury__trace__setup_5_0, "std_util:maybe/1");
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__trace__setup_5_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__trace__setup_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(12);
	MR_field(MR_mktag(0), r5, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__trace__setup_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r5, (Integer) 1) = MR_tempr1;
	r3 = MR_stackvar(2);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = ((Integer) MR_stackvar(12) + (Integer) 1);
	MR_field(MR_mktag(1), r4, (Integer) 0) = r5;
	MR_field(MR_mktag(0), r2, (Integer) 4) = MR_stackvar(5);
	MR_field(MR_mktag(0), r2, (Integer) 3) = r4;
	MR_succip = (Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	proceed();
	}
Define_label(mercury__trace__setup_5_0_i24);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 3, mercury__trace__setup_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r1, (Integer) 2) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(11);
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(8);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 5, mercury__trace__setup_5_0, "trace:trace_info/0");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(7);
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_stackvar(10);
	MR_field(MR_mktag(0), r2, (Integer) 2) = MR_stackvar(4);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 1, mercury__trace__setup_5_0, "std_util:maybe/1");
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__trace__setup_5_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__trace__setup_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(12);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(0), r5, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__trace__setup_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r5, (Integer) 1) = MR_tempr1;
	r3 = MR_stackvar(2);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = ((Integer) MR_stackvar(12) + (Integer) 1);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(1), r4, (Integer) 0) = r5;
	MR_field(MR_mktag(0), r2, (Integer) 4) = MR_stackvar(5);
	MR_field(MR_mktag(0), r2, (Integer) 3) = r4;
	MR_succip = (Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	proceed();
	}
Define_label(mercury__trace__setup_5_0_i1053);
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 3, mercury__trace__setup_5_0, "trace:trace_slot_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(8);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(11);
	MR_field(MR_mktag(0), r1, (Integer) 2) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 5, mercury__trace__setup_5_0, "trace:trace_info/0");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(7);
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_stackvar(10);
	MR_field(MR_mktag(0), r2, (Integer) 2) = MR_stackvar(4);
	MR_field(MR_mktag(0), r2, (Integer) 3) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r2, (Integer) 4) = MR_stackvar(5);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	proceed();
END_MODULE

Declare_entry(mercury__string__append_list_2_0);
Declare_entry(mercury__llds_out__make_stack_layout_name_2_0);

BEGIN_MODULE(trace_module6)
	init_entry(mercury__trace__generate_slot_fill_code_4_0);
	init_label(mercury__trace__generate_slot_fill_code_4_0_i2);
	init_label(mercury__trace__generate_slot_fill_code_4_0_i3);
	init_label(mercury__trace__generate_slot_fill_code_4_0_i4);
	init_label(mercury__trace__generate_slot_fill_code_4_0_i5);
	init_label(mercury__trace__generate_slot_fill_code_4_0_i6);
	init_label(mercury__trace__generate_slot_fill_code_4_0_i7);
	init_label(mercury__trace__generate_slot_fill_code_4_0_i8);
	init_label(mercury__trace__generate_slot_fill_code_4_0_i9);
	init_label(mercury__trace__generate_slot_fill_code_4_0_i10);
	init_label(mercury__trace__generate_slot_fill_code_4_0_i11);
	init_label(mercury__trace__generate_slot_fill_code_4_0_i12);
	init_label(mercury__trace__generate_slot_fill_code_4_0_i15);
	init_label(mercury__trace__generate_slot_fill_code_4_0_i16);
	init_label(mercury__trace__generate_slot_fill_code_4_0_i17);
	init_label(mercury__trace__generate_slot_fill_code_4_0_i13);
	init_label(mercury__trace__generate_slot_fill_code_4_0_i22);
	init_label(mercury__trace__generate_slot_fill_code_4_0_i23);
	init_label(mercury__trace__generate_slot_fill_code_4_0_i24);
	init_label(mercury__trace__generate_slot_fill_code_4_0_i20);
	init_label(mercury__trace__generate_slot_fill_code_4_0_i26);
	init_label(mercury__trace__generate_slot_fill_code_4_0_i27);
	init_label(mercury__trace__generate_slot_fill_code_4_0_i28);
BEGIN_CODE

/* code for predicate 'generate_slot_fill_code'/4 in mode 0 */
Define_entry(mercury__trace__generate_slot_fill_code_4_0);
	MR_incr_sp_push_msg(8, "trace:generate_slot_fill_code/4");
	MR_stackvar(8) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_proc_model_3_0),
		mercury__trace__generate_slot_fill_code_4_0_i2,
		ENTRY(mercury__trace__generate_slot_fill_code_4_0));
Define_label(mercury__trace__generate_slot_fill_code_4_0_i2);
	update_prof_current_proc(LABEL(mercury__trace__generate_slot_fill_code_4_0));
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(2) = r2;
	call_localret(STATIC(mercury__trace__trace_info_get_trace_type_2_0),
		mercury__trace__generate_slot_fill_code_4_0_i3,
		ENTRY(mercury__trace__generate_slot_fill_code_4_0));
Define_label(mercury__trace__generate_slot_fill_code_4_0_i3);
	update_prof_current_proc(LABEL(mercury__trace__generate_slot_fill_code_4_0));
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(1);
	call_localret(STATIC(mercury__trace__trace_info_get_maybe_redo_layout_slot_2_0),
		mercury__trace__generate_slot_fill_code_4_0_i4,
		ENTRY(mercury__trace__generate_slot_fill_code_4_0));
Define_label(mercury__trace__generate_slot_fill_code_4_0_i4);
	update_prof_current_proc(LABEL(mercury__trace__generate_slot_fill_code_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__trace__trace_info_get_maybe_trail_slots_2_0),
		mercury__trace__generate_slot_fill_code_4_0_i5,
		ENTRY(mercury__trace__generate_slot_fill_code_4_0));
Define_label(mercury__trace__generate_slot_fill_code_4_0_i5);
	update_prof_current_proc(LABEL(mercury__trace__generate_slot_fill_code_4_0));
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(3);
	call_localret(STATIC(mercury__trace__event_num_slot_2_0),
		mercury__trace__generate_slot_fill_code_4_0_i6,
		ENTRY(mercury__trace__generate_slot_fill_code_4_0));
Define_label(mercury__trace__generate_slot_fill_code_4_0_i6);
	update_prof_current_proc(LABEL(mercury__trace__generate_slot_fill_code_4_0));
	MR_stackvar(6) = r1;
	r1 = MR_stackvar(3);
	call_localret(STATIC(mercury__trace__call_num_slot_2_0),
		mercury__trace__generate_slot_fill_code_4_0_i7,
		ENTRY(mercury__trace__generate_slot_fill_code_4_0));
Define_label(mercury__trace__generate_slot_fill_code_4_0_i7);
	update_prof_current_proc(LABEL(mercury__trace__generate_slot_fill_code_4_0));
	MR_stackvar(7) = r1;
	r1 = MR_stackvar(3);
	call_localret(STATIC(mercury__trace__call_depth_slot_2_0),
		mercury__trace__generate_slot_fill_code_4_0_i8,
		ENTRY(mercury__trace__generate_slot_fill_code_4_0));
Define_label(mercury__trace__generate_slot_fill_code_4_0_i8);
	update_prof_current_proc(LABEL(mercury__trace__generate_slot_fill_code_4_0));
	r2 = r1;
	r1 = MR_stackvar(6);
	MR_stackvar(6) = r2;
	call_localret(STATIC(mercury__trace__stackref_to_string_2_0),
		mercury__trace__generate_slot_fill_code_4_0_i9,
		ENTRY(mercury__trace__generate_slot_fill_code_4_0));
Define_label(mercury__trace__generate_slot_fill_code_4_0_i9);
	update_prof_current_proc(LABEL(mercury__trace__generate_slot_fill_code_4_0));
	r2 = r1;
	r1 = MR_stackvar(7);
	MR_stackvar(7) = r2;
	call_localret(STATIC(mercury__trace__stackref_to_string_2_0),
		mercury__trace__generate_slot_fill_code_4_0_i10,
		ENTRY(mercury__trace__generate_slot_fill_code_4_0));
Define_label(mercury__trace__generate_slot_fill_code_4_0_i10);
	update_prof_current_proc(LABEL(mercury__trace__generate_slot_fill_code_4_0));
	r2 = r1;
	r1 = MR_stackvar(6);
	MR_stackvar(6) = r2;
	call_localret(STATIC(mercury__trace__stackref_to_string_2_0),
		mercury__trace__generate_slot_fill_code_4_0_i11,
		ENTRY(mercury__trace__generate_slot_fill_code_4_0));
Define_label(mercury__trace__generate_slot_fill_code_4_0_i11);
	update_prof_current_proc(LABEL(mercury__trace__generate_slot_fill_code_4_0));
	r2 = MR_stackvar(6);
	MR_stackvar(6) = r1;
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__trace__generate_slot_fill_code_4_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("\t\t", 2);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__trace__generate_slot_fill_code_4_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_stackvar(7);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__trace__generate_slot_fill_code_4_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = (Word) MR_string_const(" = MR_trace_event_number;\n", 26);
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__trace__generate_slot_fill_code_4_0, "list:list/1");
	MR_field(MR_mktag(1), r6, (Integer) 0) = (Word) MR_string_const("\t\t", 2);
	tag_incr_hp_msg(r7, MR_mktag(1), (Integer) 2, mercury__trace__generate_slot_fill_code_4_0, "list:list/1");
	MR_field(MR_mktag(1), r7, (Integer) 0) = r2;
	tag_incr_hp_msg(r8, MR_mktag(1), (Integer) 2, mercury__trace__generate_slot_fill_code_4_0, "list:list/1");
	MR_field(MR_mktag(1), r8, (Integer) 0) = (Word) MR_string_const(" = MR_trace_incr_seq();\n", 24);
	tag_incr_hp_msg(r9, MR_mktag(1), (Integer) 2, mercury__trace__generate_slot_fill_code_4_0, "list:list/1");
	MR_field(MR_mktag(1), r9, (Integer) 0) = (Word) MR_string_const("\t\t", 2);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__trace__generate_slot_fill_code_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r9, (Integer) 1) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 1) = r7;
	MR_field(MR_mktag(1), r7, (Integer) 1) = r8;
	MR_field(MR_mktag(1), r8, (Integer) 1) = r9;
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_trace__common_1);
	MR_field(MR_mktag(1), r2, (Integer) 0) = r3;
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__trace__generate_slot_fill_code_4_0_i12,
		ENTRY(mercury__trace__generate_slot_fill_code_4_0));
Define_label(mercury__trace__generate_slot_fill_code_4_0_i12);
	update_prof_current_proc(LABEL(mercury__trace__generate_slot_fill_code_4_0));
	if (((Integer) MR_stackvar(1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__trace__generate_slot_fill_code_4_0_i13);
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(3);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	call_localret(STATIC(mercury__trace__redo_layout_slot_2_0),
		mercury__trace__generate_slot_fill_code_4_0_i15,
		ENTRY(mercury__trace__generate_slot_fill_code_4_0));
Define_label(mercury__trace__generate_slot_fill_code_4_0_i15);
	update_prof_current_proc(LABEL(mercury__trace__generate_slot_fill_code_4_0));
	call_localret(STATIC(mercury__trace__stackref_to_string_2_0),
		mercury__trace__generate_slot_fill_code_4_0_i16,
		ENTRY(mercury__trace__generate_slot_fill_code_4_0));
Define_label(mercury__trace__generate_slot_fill_code_4_0_i16);
	update_prof_current_proc(LABEL(mercury__trace__generate_slot_fill_code_4_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	MR_stackvar(3) = r2;
	call_localret(ENTRY(mercury__llds_out__make_stack_layout_name_2_0),
		mercury__trace__generate_slot_fill_code_4_0_i17,
		ENTRY(mercury__trace__generate_slot_fill_code_4_0));
Define_label(mercury__trace__generate_slot_fill_code_4_0_i17);
	update_prof_current_proc(LABEL(mercury__trace__generate_slot_fill_code_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__trace__generate_slot_fill_code_4_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__trace__generate_slot_fill_code_4_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const("\n", 1);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__trace__generate_slot_fill_code_4_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_string_const("\t\t", 2);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__trace__generate_slot_fill_code_4_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_stackvar(3);
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__trace__generate_slot_fill_code_4_0, "list:list/1");
	MR_field(MR_mktag(1), r6, (Integer) 0) = (Word) MR_string_const(" = (Word) (const Word *) &", 26);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__trace__generate_slot_fill_code_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r6, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_trace__common_2);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__trace__generate_slot_fill_code_4_0_i13,
		ENTRY(mercury__trace__generate_slot_fill_code_4_0));
	}
Define_label(mercury__trace__generate_slot_fill_code_4_0_i13);
	update_prof_current_proc(LABEL(mercury__trace__generate_slot_fill_code_4_0));
	r2 = MR_stackvar(2);
	MR_stackvar(1) = r1;
	r3 = MR_stackvar(5);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__trace__generate_slot_fill_code_4_0_i20);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	call_localret(STATIC(mercury__trace__stackref_to_string_2_0),
		mercury__trace__generate_slot_fill_code_4_0_i22,
		ENTRY(mercury__trace__generate_slot_fill_code_4_0));
	}
Define_label(mercury__trace__generate_slot_fill_code_4_0_i22);
	update_prof_current_proc(LABEL(mercury__trace__generate_slot_fill_code_4_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	MR_stackvar(3) = r2;
	call_localret(STATIC(mercury__trace__stackref_to_string_2_0),
		mercury__trace__generate_slot_fill_code_4_0_i23,
		ENTRY(mercury__trace__generate_slot_fill_code_4_0));
Define_label(mercury__trace__generate_slot_fill_code_4_0_i23);
	update_prof_current_proc(LABEL(mercury__trace__generate_slot_fill_code_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__trace__generate_slot_fill_code_4_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__trace__generate_slot_fill_code_4_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const("\n", 1);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__trace__generate_slot_fill_code_4_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_string_const("\t\tMR_mark_ticket_stack(", 23);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__trace__generate_slot_fill_code_4_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = r2;
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__trace__generate_slot_fill_code_4_0, "list:list/1");
	MR_field(MR_mktag(1), r6, (Integer) 0) = (Word) MR_string_const(");\n", 3);
	tag_incr_hp_msg(r7, MR_mktag(1), (Integer) 2, mercury__trace__generate_slot_fill_code_4_0, "list:list/1");
	MR_field(MR_mktag(1), r7, (Integer) 0) = (Word) MR_string_const("\t\tMR_store_ticket(", 18);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__trace__generate_slot_fill_code_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r7, (Integer) 1) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 1) = r7;
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_trace__common_3);
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(3);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__trace__generate_slot_fill_code_4_0_i24,
		ENTRY(mercury__trace__generate_slot_fill_code_4_0));
Define_label(mercury__trace__generate_slot_fill_code_4_0_i24);
	update_prof_current_proc(LABEL(mercury__trace__generate_slot_fill_code_4_0));
	r2 = MR_stackvar(2);
	MR_stackvar(1) = r1;
Define_label(mercury__trace__generate_slot_fill_code_4_0_i20);
	if (((Integer) MR_stackvar(4) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__trace__generate_slot_fill_code_4_0_i26);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__trace__generate_slot_fill_code_4_0, "tree:tree/1");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__trace__generate_slot_fill_code_4_0, "list:list/1");
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 2, mercury__trace__generate_slot_fill_code_4_0, "std_util:pair/2");
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 7, mercury__trace__generate_slot_fill_code_4_0, "llds:instr/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 18;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__trace__generate_slot_fill_code_4_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__trace__generate_slot_fill_code_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r6, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(3), r5, (Integer) 6) = (Integer) 1;
	MR_field(MR_mktag(3), r5, (Integer) 5) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(3), r5, (Integer) 4) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(3), r5, (Integer) 3) = (Integer) 1;
	MR_field(MR_mktag(3), r5, (Integer) 2) = r6;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r6, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r4, (Integer) 0) = r5;
	MR_field(MR_mktag(0), r4, (Integer) 1) = (Word) MR_string_const("", 0);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
	}
Define_label(mercury__trace__generate_slot_fill_code_4_0_i26);
	MR_stackvar(2) = r2;
	r1 = MR_const_field(MR_mktag(1), MR_stackvar(4), (Integer) 0);
	call_localret(STATIC(mercury__trace__stackref_to_string_2_0),
		mercury__trace__generate_slot_fill_code_4_0_i27,
		ENTRY(mercury__trace__generate_slot_fill_code_4_0));
Define_label(mercury__trace__generate_slot_fill_code_4_0_i27);
	update_prof_current_proc(LABEL(mercury__trace__generate_slot_fill_code_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__trace__generate_slot_fill_code_4_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("\t\t", 2);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__trace__generate_slot_fill_code_4_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__trace__generate_slot_fill_code_4_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_string_const(" = MR_trace_from_full;\n", 23);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__trace__generate_slot_fill_code_4_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = (Word) MR_string_const("\t\tif (MR_trace_from_full) {\n", 28);
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__trace__generate_slot_fill_code_4_0, "list:list/1");
	MR_field(MR_mktag(1), r6, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r7, MR_mktag(1), (Integer) 2, mercury__trace__generate_slot_fill_code_4_0, "list:list/1");
	MR_field(MR_mktag(1), r7, (Integer) 0) = (Word) MR_string_const("\n", 1);
	tag_incr_hp_msg(r8, MR_mktag(1), (Integer) 2, mercury__trace__generate_slot_fill_code_4_0, "list:list/1");
	MR_field(MR_mktag(1), r8, (Integer) 0) = (Word) MR_string_const("\t\t} else {\n", 11);
	tag_incr_hp_msg(r9, MR_mktag(1), (Integer) 2, mercury__trace__generate_slot_fill_code_4_0, "list:list/1");
	MR_field(MR_mktag(1), r9, (Integer) 0) = (Word) MR_string_const("\t\t\t", 3);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__trace__generate_slot_fill_code_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r9, (Integer) 1) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 1) = r7;
	MR_field(MR_mktag(1), r7, (Integer) 1) = r8;
	MR_field(MR_mktag(1), r8, (Integer) 1) = r9;
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_trace__common_5);
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(6);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__trace__generate_slot_fill_code_4_0_i28,
		ENTRY(mercury__trace__generate_slot_fill_code_4_0));
Define_label(mercury__trace__generate_slot_fill_code_4_0_i28);
	update_prof_current_proc(LABEL(mercury__trace__generate_slot_fill_code_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__trace__generate_slot_fill_code_4_0, "tree:tree/1");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__trace__generate_slot_fill_code_4_0, "list:list/1");
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 2, mercury__trace__generate_slot_fill_code_4_0, "std_util:pair/2");
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 7, mercury__trace__generate_slot_fill_code_4_0, "llds:instr/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 18;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__trace__generate_slot_fill_code_4_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__trace__generate_slot_fill_code_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r2;
	MR_field(MR_mktag(1), r6, (Integer) 0) = MR_tempr1;
	r2 = MR_stackvar(2);
	MR_field(MR_mktag(3), r5, (Integer) 6) = (Integer) 1;
	MR_field(MR_mktag(3), r5, (Integer) 5) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(3), r5, (Integer) 4) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(3), r5, (Integer) 3) = (Integer) 1;
	MR_field(MR_mktag(3), r5, (Integer) 2) = r6;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r6, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r4, (Integer) 0) = r5;
	MR_field(MR_mktag(0), r4, (Integer) 1) = (Word) MR_string_const("", 0);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
	}
END_MODULE

Declare_entry(mercury__code_info__get_maybe_trace_info_3_0);

BEGIN_MODULE(trace_module7)
	init_entry(mercury__trace__prepare_for_call_3_0);
	init_label(mercury__trace__prepare_for_call_3_0_i2);
	init_label(mercury__trace__prepare_for_call_3_0_i3);
	init_label(mercury__trace__prepare_for_call_3_0_i6);
	init_label(mercury__trace__prepare_for_call_3_0_i9);
	init_label(mercury__trace__prepare_for_call_3_0_i10);
	init_label(mercury__trace__prepare_for_call_3_0_i12);
	init_label(mercury__trace__prepare_for_call_3_0_i4);
BEGIN_CODE

/* code for predicate 'prepare_for_call'/3 in mode 0 */
Define_entry(mercury__trace__prepare_for_call_3_0);
	MR_incr_sp_push_msg(3, "trace:prepare_for_call/3");
	MR_stackvar(3) = (Word) MR_succip;
	call_localret(ENTRY(mercury__code_info__get_maybe_trace_info_3_0),
		mercury__trace__prepare_for_call_3_0_i2,
		ENTRY(mercury__trace__prepare_for_call_3_0));
Define_label(mercury__trace__prepare_for_call_3_0_i2);
	update_prof_current_proc(LABEL(mercury__trace__prepare_for_call_3_0));
	MR_stackvar(1) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_proc_model_3_0),
		mercury__trace__prepare_for_call_3_0_i3,
		ENTRY(mercury__trace__prepare_for_call_3_0));
Define_label(mercury__trace__prepare_for_call_3_0_i3);
	update_prof_current_proc(LABEL(mercury__trace__prepare_for_call_3_0));
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(1);
	if (((Integer) MR_tempr1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__trace__prepare_for_call_3_0_i4);
	r3 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0), (Integer) 0);
	if (((Integer) r1 != (Integer) 2))
		GOTO_LABEL(mercury__trace__prepare_for_call_3_0_i6);
	MR_stackvar(2) = r3;
	r1 = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_trace__common_6);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__trace__stackref_to_string_2_0),
		mercury__trace__prepare_for_call_3_0_i9,
		ENTRY(mercury__trace__prepare_for_call_3_0));
	}
Define_label(mercury__trace__prepare_for_call_3_0_i6);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	r1 = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_trace__common_7);
	call_localret(STATIC(mercury__trace__stackref_to_string_2_0),
		mercury__trace__prepare_for_call_3_0_i9,
		ENTRY(mercury__trace__prepare_for_call_3_0));
Define_label(mercury__trace__prepare_for_call_3_0_i9);
	update_prof_current_proc(LABEL(mercury__trace__prepare_for_call_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__trace__prepare_for_call_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("MR_trace_reset_depth(", 21);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__trace__prepare_for_call_3_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_trace__common_8);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__trace__prepare_for_call_3_0_i10,
		ENTRY(mercury__trace__prepare_for_call_3_0));
Define_label(mercury__trace__prepare_for_call_3_0_i10);
	update_prof_current_proc(LABEL(mercury__trace__prepare_for_call_3_0));
	if (((Integer) MR_stackvar(2) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__trace__prepare_for_call_3_0_i12);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__trace__prepare_for_call_3_0, "tree:tree/1");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__trace__prepare_for_call_3_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_10);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__trace__prepare_for_call_3_0, "list:list/1");
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__trace__prepare_for_call_3_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__trace__prepare_for_call_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r2;
	MR_field(MR_mktag(0), r5, (Integer) 0) = MR_tempr1;
	r2 = MR_stackvar(1);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 7;
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r4, (Integer) 0) = r5;
	MR_field(MR_mktag(0), r5, (Integer) 1) = (Word) MR_string_const("", 0);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
	}
Define_label(mercury__trace__prepare_for_call_3_0_i12);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__trace__prepare_for_call_3_0, "tree:tree/1");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__trace__prepare_for_call_3_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_12);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__trace__prepare_for_call_3_0, "list:list/1");
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__trace__prepare_for_call_3_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__trace__prepare_for_call_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r2;
	MR_field(MR_mktag(0), r5, (Integer) 0) = MR_tempr1;
	r2 = MR_stackvar(1);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 7;
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r4, (Integer) 0) = r5;
	MR_field(MR_mktag(0), r5, (Integer) 1) = (Word) MR_string_const("", 0);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
	}
Define_label(mercury__trace__prepare_for_call_3_0_i4);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_goal__goal_info_get_goal_path_2_0);
Declare_entry(mercury__hlds_goal__goal_info_get_pre_deaths_2_0);
Declare_entry(mercury__hlds_goal__goal_info_get_context_2_0);

BEGIN_MODULE(trace_module8)
	init_entry(mercury__trace__maybe_generate_internal_event_code_4_0);
	init_label(mercury__trace__maybe_generate_internal_event_code_4_0_i2);
	init_label(mercury__trace__maybe_generate_internal_event_code_4_0_i5);
	init_label(mercury__trace__maybe_generate_internal_event_code_4_0_i15);
	init_label(mercury__trace__maybe_generate_internal_event_code_4_0_i10);
	init_label(mercury__trace__maybe_generate_internal_event_code_4_0_i11);
	init_label(mercury__trace__maybe_generate_internal_event_code_4_0_i12);
	init_label(mercury__trace__maybe_generate_internal_event_code_4_0_i13);
	init_label(mercury__trace__maybe_generate_internal_event_code_4_0_i14);
	init_label(mercury__trace__maybe_generate_internal_event_code_4_0_i8);
	init_label(mercury__trace__maybe_generate_internal_event_code_4_0_i6);
	init_label(mercury__trace__maybe_generate_internal_event_code_4_0_i17);
	init_label(mercury__trace__maybe_generate_internal_event_code_4_0_i1016);
	init_label(mercury__trace__maybe_generate_internal_event_code_4_0_i18);
	init_label(mercury__trace__maybe_generate_internal_event_code_4_0_i20);
	init_label(mercury__trace__maybe_generate_internal_event_code_4_0_i1007);
	init_label(mercury__trace__maybe_generate_internal_event_code_4_0_i19);
	init_label(mercury__trace__maybe_generate_internal_event_code_4_0_i23);
	init_label(mercury__trace__maybe_generate_internal_event_code_4_0_i24);
	init_label(mercury__trace__maybe_generate_internal_event_code_4_0_i25);
BEGIN_CODE

/* code for predicate 'maybe_generate_internal_event_code'/4 in mode 0 */
Define_entry(mercury__trace__maybe_generate_internal_event_code_4_0);
	MR_incr_sp_push_msg(6, "trace:maybe_generate_internal_event_code/4");
	MR_stackvar(6) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_maybe_trace_info_3_0),
		mercury__trace__maybe_generate_internal_event_code_4_0_i2,
		ENTRY(mercury__trace__maybe_generate_internal_event_code_4_0));
Define_label(mercury__trace__maybe_generate_internal_event_code_4_0_i2);
	update_prof_current_proc(LABEL(mercury__trace__maybe_generate_internal_event_code_4_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__trace__maybe_generate_internal_event_code_4_0_i1007);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	if (((Integer) 1 != (Integer) MR_const_field(MR_mktag(0), r3, (Integer) 1)))
		GOTO_LABEL(mercury__trace__maybe_generate_internal_event_code_4_0_i1007);
	r1 = MR_const_field(MR_mktag(0), MR_stackvar(1), (Integer) 1);
	MR_stackvar(2) = r1;
	MR_stackvar(1) = r3;
	MR_stackvar(5) = r2;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_goal_path_2_0),
		mercury__trace__maybe_generate_internal_event_code_4_0_i5,
		ENTRY(mercury__trace__maybe_generate_internal_event_code_4_0));
Define_label(mercury__trace__maybe_generate_internal_event_code_4_0_i5);
	update_prof_current_proc(LABEL(mercury__trace__maybe_generate_internal_event_code_4_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__trace__maybe_generate_internal_event_code_4_0_i6);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r3 = MR_tag(r2);
	if ((r3 == MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__trace__maybe_generate_internal_event_code_4_0_i10);
	if ((r3 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__trace__maybe_generate_internal_event_code_4_0_i15);
	if ((r3 != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__trace__maybe_generate_internal_event_code_4_0_i6);
	MR_stackvar(3) = r1;
	r1 = (Integer) 11;
	r2 = MR_stackvar(5);
	GOTO_LABEL(mercury__trace__maybe_generate_internal_event_code_4_0_i8);
Define_label(mercury__trace__maybe_generate_internal_event_code_4_0_i15);
	MR_stackvar(3) = r1;
	r1 = (Integer) 12;
	r2 = MR_stackvar(5);
	GOTO_LABEL(mercury__trace__maybe_generate_internal_event_code_4_0_i8);
Define_label(mercury__trace__maybe_generate_internal_event_code_4_0_i10);
	COMPUTED_GOTO((Unsigned) MR_unmkbody(r2),
		LABEL(mercury__trace__maybe_generate_internal_event_code_4_0_i11) AND
		LABEL(mercury__trace__maybe_generate_internal_event_code_4_0_i12) AND
		LABEL(mercury__trace__maybe_generate_internal_event_code_4_0_i13) AND
		LABEL(mercury__trace__maybe_generate_internal_event_code_4_0_i14) AND
		LABEL(mercury__trace__maybe_generate_internal_event_code_4_0_i6) AND
		LABEL(mercury__trace__maybe_generate_internal_event_code_4_0_i6) AND
		LABEL(mercury__trace__maybe_generate_internal_event_code_4_0_i6));
Define_label(mercury__trace__maybe_generate_internal_event_code_4_0_i11);
	MR_stackvar(3) = r1;
	r1 = (Integer) 5;
	r2 = MR_stackvar(5);
	GOTO_LABEL(mercury__trace__maybe_generate_internal_event_code_4_0_i8);
Define_label(mercury__trace__maybe_generate_internal_event_code_4_0_i12);
	MR_stackvar(3) = r1;
	r1 = (Integer) 6;
	r2 = MR_stackvar(5);
	GOTO_LABEL(mercury__trace__maybe_generate_internal_event_code_4_0_i8);
Define_label(mercury__trace__maybe_generate_internal_event_code_4_0_i13);
	MR_stackvar(3) = r1;
	r1 = (Integer) 7;
	r2 = MR_stackvar(5);
	GOTO_LABEL(mercury__trace__maybe_generate_internal_event_code_4_0_i8);
Define_label(mercury__trace__maybe_generate_internal_event_code_4_0_i14);
	MR_stackvar(3) = r1;
	r1 = (Integer) 8;
	r2 = MR_stackvar(5);
Define_label(mercury__trace__maybe_generate_internal_event_code_4_0_i8);
	MR_stackvar(4) = r1;
	GOTO_LABEL(mercury__trace__maybe_generate_internal_event_code_4_0_i1016);
Define_label(mercury__trace__maybe_generate_internal_event_code_4_0_i6);
	MR_stackvar(3) = r1;
	r1 = (Word) MR_string_const("trace__generate_internal_event_code: bad path", 45);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__trace__maybe_generate_internal_event_code_4_0_i17,
		ENTRY(mercury__trace__maybe_generate_internal_event_code_4_0));
Define_label(mercury__trace__maybe_generate_internal_event_code_4_0_i17);
	update_prof_current_proc(LABEL(mercury__trace__maybe_generate_internal_event_code_4_0));
	r2 = MR_stackvar(5);
	GOTO_LABEL(mercury__trace__maybe_generate_internal_event_code_4_0_i18);
Define_label(mercury__trace__maybe_generate_internal_event_code_4_0_i1016);
	if (((Integer) r1 == (Integer) 5))
		GOTO_LABEL(mercury__trace__maybe_generate_internal_event_code_4_0_i20);
	if (((Integer) r1 != (Integer) 8))
		GOTO_LABEL(mercury__trace__maybe_generate_internal_event_code_4_0_i19);
	GOTO_LABEL(mercury__trace__maybe_generate_internal_event_code_4_0_i20);
Define_label(mercury__trace__maybe_generate_internal_event_code_4_0_i18);
	r1 = MR_stackvar(4);
	if (((Integer) r1 == (Integer) 5))
		GOTO_LABEL(mercury__trace__maybe_generate_internal_event_code_4_0_i20);
	if (((Integer) r1 != (Integer) 8))
		GOTO_LABEL(mercury__trace__maybe_generate_internal_event_code_4_0_i19);
Define_label(mercury__trace__maybe_generate_internal_event_code_4_0_i20);
	r1 = MR_const_field(MR_mktag(0), MR_stackvar(1), (Integer) 2);
	if (((Integer) 0 != (Integer) r1))
		GOTO_LABEL(mercury__trace__maybe_generate_internal_event_code_4_0_i19);
Define_label(mercury__trace__maybe_generate_internal_event_code_4_0_i1007);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__trace__maybe_generate_internal_event_code_4_0_i19);
	MR_stackvar(5) = r2;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_pre_deaths_2_0),
		mercury__trace__maybe_generate_internal_event_code_4_0_i23,
		ENTRY(mercury__trace__maybe_generate_internal_event_code_4_0));
Define_label(mercury__trace__maybe_generate_internal_event_code_4_0_i23);
	update_prof_current_proc(LABEL(mercury__trace__maybe_generate_internal_event_code_4_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_context_2_0),
		mercury__trace__maybe_generate_internal_event_code_4_0_i24,
		ENTRY(mercury__trace__maybe_generate_internal_event_code_4_0));
Define_label(mercury__trace__maybe_generate_internal_event_code_4_0_i24);
	update_prof_current_proc(LABEL(mercury__trace__maybe_generate_internal_event_code_4_0));
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__trace__maybe_generate_internal_event_code_4_0, "origin_lost_in_value_number");
	r4 = r1;
	r1 = MR_stackvar(4);
	r3 = MR_stackvar(1);
	r5 = MR_stackvar(5);
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(3);
	call_localret(STATIC(mercury__trace__generate_event_code_9_0),
		mercury__trace__maybe_generate_internal_event_code_4_0_i25,
		ENTRY(mercury__trace__maybe_generate_internal_event_code_4_0));
Define_label(mercury__trace__maybe_generate_internal_event_code_4_0_i25);
	update_prof_current_proc(LABEL(mercury__trace__maybe_generate_internal_event_code_4_0));
	r1 = r3;
	r2 = r4;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE


BEGIN_MODULE(trace_module9)
	init_entry(mercury__trace__maybe_generate_negated_event_code_5_0);
	init_label(mercury__trace__maybe_generate_negated_event_code_5_0_i2);
	init_label(mercury__trace__maybe_generate_negated_event_code_5_0_i6);
	init_label(mercury__trace__maybe_generate_negated_event_code_5_0_i5);
	init_label(mercury__trace__maybe_generate_negated_event_code_5_0_i7);
	init_label(mercury__trace__maybe_generate_negated_event_code_5_0_i8);
	init_label(mercury__trace__maybe_generate_negated_event_code_5_0_i9);
	init_label(mercury__trace__maybe_generate_negated_event_code_5_0_i3);
BEGIN_CODE

/* code for predicate 'maybe_generate_negated_event_code'/5 in mode 0 */
Define_entry(mercury__trace__maybe_generate_negated_event_code_5_0);
	MR_incr_sp_push_msg(5, "trace:maybe_generate_negated_event_code/5");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r3;
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__code_info__get_maybe_trace_info_3_0),
		mercury__trace__maybe_generate_negated_event_code_5_0_i2,
		ENTRY(mercury__trace__maybe_generate_negated_event_code_5_0));
Define_label(mercury__trace__maybe_generate_negated_event_code_5_0_i2);
	update_prof_current_proc(LABEL(mercury__trace__maybe_generate_negated_event_code_5_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__trace__maybe_generate_negated_event_code_5_0_i3);
	r3 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 1);
	if (((Integer) 1 != (Integer) r3))
		GOTO_LABEL(mercury__trace__maybe_generate_negated_event_code_5_0_i3);
	r3 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 2);
	if (((Integer) 1 != (Integer) r3))
		GOTO_LABEL(mercury__trace__maybe_generate_negated_event_code_5_0_i3);
	if (((Integer) MR_stackvar(2) != (Integer) 0))
		GOTO_LABEL(mercury__trace__maybe_generate_negated_event_code_5_0_i6);
	r3 = r1;
	r1 = MR_const_field(MR_mktag(0), MR_stackvar(1), (Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_stackvar(2) = (Integer) 9;
	MR_stackvar(4) = r2;
	GOTO_LABEL(mercury__trace__maybe_generate_negated_event_code_5_0_i5);
Define_label(mercury__trace__maybe_generate_negated_event_code_5_0_i6);
	r3 = r1;
	r1 = MR_const_field(MR_mktag(0), MR_stackvar(1), (Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_stackvar(2) = (Integer) 10;
	MR_stackvar(4) = r2;
Define_label(mercury__trace__maybe_generate_negated_event_code_5_0_i5);
	MR_stackvar(3) = r1;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_goal_path_2_0),
		mercury__trace__maybe_generate_negated_event_code_5_0_i7,
		ENTRY(mercury__trace__maybe_generate_negated_event_code_5_0));
Define_label(mercury__trace__maybe_generate_negated_event_code_5_0_i7);
	update_prof_current_proc(LABEL(mercury__trace__maybe_generate_negated_event_code_5_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	MR_stackvar(3) = r2;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_context_2_0),
		mercury__trace__maybe_generate_negated_event_code_5_0_i8,
		ENTRY(mercury__trace__maybe_generate_negated_event_code_5_0));
Define_label(mercury__trace__maybe_generate_negated_event_code_5_0_i8);
	update_prof_current_proc(LABEL(mercury__trace__maybe_generate_negated_event_code_5_0));
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 1, mercury__trace__maybe_generate_negated_event_code_5_0, "origin_lost_in_value_number");
	r4 = r1;
	r1 = MR_stackvar(2);
	r3 = MR_stackvar(1);
	r5 = MR_stackvar(4);
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_stackvar(3);
	call_localret(STATIC(mercury__trace__generate_event_code_9_0),
		mercury__trace__maybe_generate_negated_event_code_5_0_i9,
		ENTRY(mercury__trace__maybe_generate_negated_event_code_5_0));
Define_label(mercury__trace__maybe_generate_negated_event_code_5_0_i9);
	update_prof_current_proc(LABEL(mercury__trace__maybe_generate_negated_event_code_5_0));
	r1 = r3;
	r2 = r4;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__trace__maybe_generate_negated_event_code_5_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE


BEGIN_MODULE(trace_module10)
	init_entry(mercury__trace__maybe_generate_pragma_event_code_5_0);
	init_label(mercury__trace__maybe_generate_pragma_event_code_5_0_i2);
	init_label(mercury__trace__maybe_generate_pragma_event_code_5_0_i6);
	init_label(mercury__trace__maybe_generate_pragma_event_code_5_0_i7);
	init_label(mercury__trace__maybe_generate_pragma_event_code_5_0_i3);
BEGIN_CODE

/* code for predicate 'maybe_generate_pragma_event_code'/5 in mode 0 */
Define_entry(mercury__trace__maybe_generate_pragma_event_code_5_0);
	MR_incr_sp_push_msg(3, "trace:maybe_generate_pragma_event_code/5");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r3;
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__code_info__get_maybe_trace_info_3_0),
		mercury__trace__maybe_generate_pragma_event_code_5_0_i2,
		ENTRY(mercury__trace__maybe_generate_pragma_event_code_5_0));
Define_label(mercury__trace__maybe_generate_pragma_event_code_5_0_i2);
	update_prof_current_proc(LABEL(mercury__trace__maybe_generate_pragma_event_code_5_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__trace__maybe_generate_pragma_event_code_5_0_i3);
	r3 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 1);
	if (((Integer) 1 != (Integer) r3))
		GOTO_LABEL(mercury__trace__maybe_generate_pragma_event_code_5_0_i3);
	if (((Integer) MR_stackvar(1) != (Integer) 0))
		GOTO_LABEL(mercury__trace__maybe_generate_pragma_event_code_5_0_i6);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r5 = r2;
	r1 = (Integer) 13;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1));
	r4 = MR_stackvar(2);
	call_localret(STATIC(mercury__trace__generate_event_code_9_0),
		mercury__trace__maybe_generate_pragma_event_code_5_0_i7,
		ENTRY(mercury__trace__maybe_generate_pragma_event_code_5_0));
Define_label(mercury__trace__maybe_generate_pragma_event_code_5_0_i6);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r5 = r2;
	r1 = (Integer) 14;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1));
	r4 = MR_stackvar(2);
	call_localret(STATIC(mercury__trace__generate_event_code_9_0),
		mercury__trace__maybe_generate_pragma_event_code_5_0_i7,
		ENTRY(mercury__trace__maybe_generate_pragma_event_code_5_0));
Define_label(mercury__trace__maybe_generate_pragma_event_code_5_0_i7);
	update_prof_current_proc(LABEL(mercury__trace__maybe_generate_pragma_event_code_5_0));
	r1 = r3;
	r2 = r4;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__trace__maybe_generate_pragma_event_code_5_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(trace_module11)
	init_entry(mercury__trace__generate_external_event_code_8_0);
	init_label(mercury__trace__generate_external_event_code_8_0_i3);
	init_label(mercury__trace__generate_external_event_code_8_0_i4);
BEGIN_CODE

/* code for predicate 'generate_external_event_code'/8 in mode 0 */
Define_entry(mercury__trace__generate_external_event_code_8_0);
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__trace__generate_external_event_code_8_0_i3);
	r5 = r4;
	r4 = r3;
	r3 = r2;
	r1 = (Integer) 0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tailcall(STATIC(mercury__trace__generate_event_code_9_0),
		ENTRY(mercury__trace__generate_external_event_code_8_0));
Define_label(mercury__trace__generate_external_event_code_8_0_i3);
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__trace__generate_external_event_code_8_0_i4);
	r5 = r4;
	r4 = r3;
	r3 = r2;
	r1 = (Integer) 1;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tailcall(STATIC(mercury__trace__generate_event_code_9_0),
		ENTRY(mercury__trace__generate_external_event_code_8_0));
Define_label(mercury__trace__generate_external_event_code_8_0_i4);
	r5 = r4;
	r4 = r3;
	r3 = r2;
	r1 = (Integer) 2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tailcall(STATIC(mercury__trace__generate_event_code_9_0),
		ENTRY(mercury__trace__generate_external_event_code_8_0));
END_MODULE

Declare_entry(mercury__require__require_2_0);

BEGIN_MODULE(trace_module12)
	init_entry(mercury__trace__maybe_setup_redo_event_2_0);
	init_label(mercury__trace__maybe_setup_redo_event_2_0_i5);
	init_label(mercury__trace__maybe_setup_redo_event_2_0_i6);
	init_label(mercury__trace__maybe_setup_redo_event_2_0_i2);
BEGIN_CODE

/* code for predicate 'maybe_setup_redo_event'/2 in mode 0 */
Define_entry(mercury__trace__maybe_setup_redo_event_2_0);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__trace__maybe_setup_redo_event_2_0_i2);
	MR_incr_sp_push_msg(1, "trace:maybe_setup_redo_event/2");
	MR_stackvar(1) = (Word) MR_succip;
	if (((Integer) MR_const_field(MR_mktag(0), r1, (Integer) 0) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__trace__maybe_setup_redo_event_2_0_i5);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_trace__common_17);
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__trace__maybe_setup_redo_event_2_0_i5);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 5, mercury__trace__maybe_setup_redo_event_2_0, "closure");
	MR_field(MR_mktag(0), r1, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_19);
	MR_field(MR_mktag(0), r1, (Integer) 1) = (Word) STATIC(mercury__trace__IntroducedFrom__pred__maybe_setup_redo_event__665__1_2_0);
	MR_field(MR_mktag(0), r1, (Integer) 2) = (Integer) 2;
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r2, (Integer) 0), (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 4) = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_trace__common_20);
	r2 = (Word) MR_string_const("from-full flag not stored in expected slot", 42);
	call_localret(ENTRY(mercury__require__require_2_0),
		mercury__trace__maybe_setup_redo_event_2_0_i6,
		ENTRY(mercury__trace__maybe_setup_redo_event_2_0));
Define_label(mercury__trace__maybe_setup_redo_event_2_0_i6);
	update_prof_current_proc(LABEL(mercury__trace__maybe_setup_redo_event_2_0));
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_trace__common_24);
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__trace__maybe_setup_redo_event_2_0_i2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE

extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_string_0;
Declare_entry(mercury__list__reverse_2_0);

BEGIN_MODULE(trace_module13)
	init_entry(mercury__trace__path_to_string_2_0);
	init_label(mercury__trace__path_to_string_2_0_i2);
	init_label(mercury__trace__path_to_string_2_0_i3);
BEGIN_CODE

/* code for predicate 'path_to_string'/2 in mode 0 */
Define_entry(mercury__trace__path_to_string_2_0);
	MR_incr_sp_push_msg(1, "trace:path_to_string/2");
	MR_stackvar(1) = (Word) MR_succip;
	call_localret(STATIC(mercury__trace__path_steps_to_strings_2_0),
		mercury__trace__path_to_string_2_0_i2,
		ENTRY(mercury__trace__path_to_string_2_0));
Define_label(mercury__trace__path_to_string_2_0_i2);
	update_prof_current_proc(LABEL(mercury__trace__path_to_string_2_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	call_localret(ENTRY(mercury__list__reverse_2_0),
		mercury__trace__path_to_string_2_0_i3,
		ENTRY(mercury__trace__path_to_string_2_0));
Define_label(mercury__trace__path_to_string_2_0_i3);
	update_prof_current_proc(LABEL(mercury__trace__path_to_string_2_0));
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		ENTRY(mercury__trace__path_to_string_2_0));
END_MODULE

Declare_entry(mercury__code_info__get_known_variables_3_0);
Declare_entry(mercury__set__init_1_0);
Declare_entry(mercury__code_info__get_varset_3_0);
Declare_entry(mercury__code_info__get_instmap_3_0);
Declare_entry(mercury__code_info__max_reg_in_use_3_0);
Declare_entry(mercury__code_info__current_resume_point_vars_3_0);
Declare_entry(mercury__set__difference_3_0);
Declare_entry(mercury__set__to_sorted_list_2_0);
Declare_entry(mercury__list__delete_elems_3_0);
Declare_entry(mercury__code_info__get_max_reg_in_use_at_trace_3_0);
Declare_entry(mercury__code_info__set_max_reg_in_use_at_trace_3_0);
Declare_entry(mercury__code_info__variable_locations_3_0);
Declare_entry(mercury__code_info__get_proc_info_3_0);
Declare_entry(mercury__continuation_info__find_typeinfos_for_tvars_4_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_continuation_info__type_ctor_info_var_info_0;
Declare_entry(mercury__llds_out__get_label_3_0);
Declare_entry(mercury__code_info__add_trace_layout_for_label_7_0);

BEGIN_MODULE(trace_module14)
	init_entry(mercury__trace__generate_event_code_9_0);
	init_label(mercury__trace__generate_event_code_9_0_i2);
	init_label(mercury__trace__generate_event_code_9_0_i3);
	init_label(mercury__trace__generate_event_code_9_0_i4);
	init_label(mercury__trace__generate_event_code_9_0_i20);
	init_label(mercury__trace__generate_event_code_9_0_i21);
	init_label(mercury__trace__generate_event_code_9_0_i22);
	init_label(mercury__trace__generate_event_code_9_0_i19);
	init_label(mercury__trace__generate_event_code_9_0_i23);
	init_label(mercury__trace__generate_event_code_9_0_i25);
	init_label(mercury__trace__generate_event_code_9_0_i27);
	init_label(mercury__trace__generate_event_code_9_0_i30);
	init_label(mercury__trace__generate_event_code_9_0_i31);
	init_label(mercury__trace__generate_event_code_9_0_i15);
	init_label(mercury__trace__generate_event_code_9_0_i16);
	init_label(mercury__trace__generate_event_code_9_0_i17);
	init_label(mercury__trace__generate_event_code_9_0_i7);
	init_label(mercury__trace__generate_event_code_9_0_i8);
	init_label(mercury__trace__generate_event_code_9_0_i9);
	init_label(mercury__trace__generate_event_code_9_0_i10);
	init_label(mercury__trace__generate_event_code_9_0_i11);
	init_label(mercury__trace__generate_event_code_9_0_i12);
	init_label(mercury__trace__generate_event_code_9_0_i13);
	init_label(mercury__trace__generate_event_code_9_0_i14);
	init_label(mercury__trace__generate_event_code_9_0_i32);
	init_label(mercury__trace__generate_event_code_9_0_i33);
	init_label(mercury__trace__generate_event_code_9_0_i34);
	init_label(mercury__trace__generate_event_code_9_0_i36);
	init_label(mercury__trace__generate_event_code_9_0_i37);
	init_label(mercury__trace__generate_event_code_9_0_i38);
	init_label(mercury__trace__generate_event_code_9_0_i39);
	init_label(mercury__trace__generate_event_code_9_0_i40);
	init_label(mercury__trace__generate_event_code_9_0_i41);
	init_label(mercury__trace__generate_event_code_9_0_i42);
	init_label(mercury__trace__generate_event_code_9_0_i43);
	init_label(mercury__trace__generate_event_code_9_0_i44);
	init_label(mercury__trace__generate_event_code_9_0_i48);
	init_label(mercury__trace__generate_event_code_9_0_i50);
	init_label(mercury__trace__generate_event_code_9_0_i45);
	init_label(mercury__trace__generate_event_code_9_0_i46);
	init_label(mercury__trace__generate_event_code_9_0_i52);
BEGIN_CODE

/* code for predicate 'generate_event_code'/9 in mode 0 */
Define_static(mercury__trace__generate_event_code_9_0);
	MR_incr_sp_push_msg(11, "trace:generate_event_code/9");
	MR_stackvar(11) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r5;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	call_localret(ENTRY(mercury__code_info__get_next_label_3_0),
		mercury__trace__generate_event_code_9_0_i2,
		STATIC(mercury__trace__generate_event_code_9_0));
Define_label(mercury__trace__generate_event_code_9_0_i2);
	update_prof_current_proc(LABEL(mercury__trace__generate_event_code_9_0));
	MR_stackvar(5) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_known_variables_3_0),
		mercury__trace__generate_event_code_9_0_i3,
		STATIC(mercury__trace__generate_event_code_9_0));
Define_label(mercury__trace__generate_event_code_9_0_i3);
	update_prof_current_proc(LABEL(mercury__trace__generate_event_code_9_0));
	MR_stackvar(6) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_25);
	MR_stackvar(7) = r2;
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__trace__generate_event_code_9_0_i4,
		STATIC(mercury__trace__generate_event_code_9_0));
Define_label(mercury__trace__generate_event_code_9_0_i4);
	update_prof_current_proc(LABEL(mercury__trace__generate_event_code_9_0));
	r2 = MR_stackvar(2);
	r3 = MR_tag(r2);
	if ((r3 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__trace__generate_event_code_9_0_i7);
	if ((r3 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__trace__generate_event_code_9_0_i15);
	if (((Integer) MR_unmkbody(r2) != (Integer) 0))
		GOTO_LABEL(mercury__trace__generate_event_code_9_0_i19);
	MR_stackvar(8) = r1;
	r1 = MR_stackvar(7);
	call_localret(ENTRY(mercury__code_info__get_varset_3_0),
		mercury__trace__generate_event_code_9_0_i20,
		STATIC(mercury__trace__generate_event_code_9_0));
Define_label(mercury__trace__generate_event_code_9_0_i20);
	update_prof_current_proc(LABEL(mercury__trace__generate_event_code_9_0));
	MR_stackvar(2) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_instmap_3_0),
		mercury__trace__generate_event_code_9_0_i21,
		STATIC(mercury__trace__generate_event_code_9_0));
Define_label(mercury__trace__generate_event_code_9_0_i21);
	update_prof_current_proc(LABEL(mercury__trace__generate_event_code_9_0));
	r3 = r1;
	r5 = r2;
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(2);
	r4 = MR_stackvar(8);
	call_localret(STATIC(mercury__trace__produce_vars_9_0),
		mercury__trace__generate_event_code_9_0_i22,
		STATIC(mercury__trace__generate_event_code_9_0));
Define_label(mercury__trace__generate_event_code_9_0_i22);
	update_prof_current_proc(LABEL(mercury__trace__generate_event_code_9_0));
	MR_stackvar(2) = r1;
	r1 = r4;
	MR_stackvar(6) = r2;
	MR_stackvar(7) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_stackvar(8) = r3;
	call_localret(ENTRY(mercury__code_info__max_reg_in_use_3_0),
		mercury__trace__generate_event_code_9_0_i32,
		STATIC(mercury__trace__generate_event_code_9_0));
Define_label(mercury__trace__generate_event_code_9_0_i19);
	if (((Integer) MR_stackvar(1) != (Integer) 13))
		GOTO_LABEL(mercury__trace__generate_event_code_9_0_i23);
	MR_stackvar(8) = r1;
	r1 = MR_stackvar(7);
	MR_stackvar(7) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_trace__common_26);
	call_localret(ENTRY(mercury__code_info__get_varset_3_0),
		mercury__trace__generate_event_code_9_0_i30,
		STATIC(mercury__trace__generate_event_code_9_0));
Define_label(mercury__trace__generate_event_code_9_0_i23);
	if (((Integer) MR_stackvar(1) != (Integer) 14))
		GOTO_LABEL(mercury__trace__generate_event_code_9_0_i25);
	MR_stackvar(8) = r1;
	r1 = MR_stackvar(7);
	MR_stackvar(7) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_trace__common_27);
	call_localret(ENTRY(mercury__code_info__get_varset_3_0),
		mercury__trace__generate_event_code_9_0_i30,
		STATIC(mercury__trace__generate_event_code_9_0));
Define_label(mercury__trace__generate_event_code_9_0_i25);
	MR_stackvar(8) = r1;
	r1 = (Word) MR_string_const("bad nondet pragma port", 22);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__trace__generate_event_code_9_0_i27,
		STATIC(mercury__trace__generate_event_code_9_0));
Define_label(mercury__trace__generate_event_code_9_0_i27);
	update_prof_current_proc(LABEL(mercury__trace__generate_event_code_9_0));
	r1 = MR_stackvar(7);
	call_localret(ENTRY(mercury__code_info__get_varset_3_0),
		mercury__trace__generate_event_code_9_0_i30,
		STATIC(mercury__trace__generate_event_code_9_0));
Define_label(mercury__trace__generate_event_code_9_0_i30);
	update_prof_current_proc(LABEL(mercury__trace__generate_event_code_9_0));
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_instmap_3_0),
		mercury__trace__generate_event_code_9_0_i31,
		STATIC(mercury__trace__generate_event_code_9_0));
Define_label(mercury__trace__generate_event_code_9_0_i31);
	update_prof_current_proc(LABEL(mercury__trace__generate_event_code_9_0));
	MR_stackvar(2) = MR_stackvar(8);
	r1 = r2;
	MR_stackvar(6) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_stackvar(8) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__code_info__max_reg_in_use_3_0),
		mercury__trace__generate_event_code_9_0_i32,
		STATIC(mercury__trace__generate_event_code_9_0));
Define_label(mercury__trace__generate_event_code_9_0_i15);
	MR_stackvar(8) = r1;
	r1 = MR_stackvar(7);
	MR_stackvar(7) = MR_const_field(MR_mktag(2), r2, (Integer) 0);
	call_localret(ENTRY(mercury__code_info__get_varset_3_0),
		mercury__trace__generate_event_code_9_0_i16,
		STATIC(mercury__trace__generate_event_code_9_0));
Define_label(mercury__trace__generate_event_code_9_0_i16);
	update_prof_current_proc(LABEL(mercury__trace__generate_event_code_9_0));
	MR_stackvar(2) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_instmap_3_0),
		mercury__trace__generate_event_code_9_0_i17,
		STATIC(mercury__trace__generate_event_code_9_0));
Define_label(mercury__trace__generate_event_code_9_0_i17);
	update_prof_current_proc(LABEL(mercury__trace__generate_event_code_9_0));
	r3 = r1;
	r5 = r2;
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(2);
	r4 = MR_stackvar(8);
	call_localret(STATIC(mercury__trace__produce_vars_9_0),
		mercury__trace__generate_event_code_9_0_i14,
		STATIC(mercury__trace__generate_event_code_9_0));
Define_label(mercury__trace__generate_event_code_9_0_i7);
	MR_stackvar(8) = r1;
	r1 = MR_stackvar(7);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	MR_stackvar(7) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	call_localret(ENTRY(mercury__code_info__current_resume_point_vars_3_0),
		mercury__trace__generate_event_code_9_0_i8,
		STATIC(mercury__trace__generate_event_code_9_0));
Define_label(mercury__trace__generate_event_code_9_0_i8);
	update_prof_current_proc(LABEL(mercury__trace__generate_event_code_9_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r2;
	r2 = MR_stackvar(2);
	MR_stackvar(2) = MR_tempr1;
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_0);
	call_localret(ENTRY(mercury__set__difference_3_0),
		mercury__trace__generate_event_code_9_0_i9,
		STATIC(mercury__trace__generate_event_code_9_0));
	}
Define_label(mercury__trace__generate_event_code_9_0_i9);
	update_prof_current_proc(LABEL(mercury__trace__generate_event_code_9_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__trace__generate_event_code_9_0_i10,
		STATIC(mercury__trace__generate_event_code_9_0));
Define_label(mercury__trace__generate_event_code_9_0_i10);
	update_prof_current_proc(LABEL(mercury__trace__generate_event_code_9_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_0);
	r2 = MR_stackvar(6);
	call_localret(ENTRY(mercury__list__delete_elems_3_0),
		mercury__trace__generate_event_code_9_0_i11,
		STATIC(mercury__trace__generate_event_code_9_0));
Define_label(mercury__trace__generate_event_code_9_0_i11);
	update_prof_current_proc(LABEL(mercury__trace__generate_event_code_9_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__code_info__get_varset_3_0),
		mercury__trace__generate_event_code_9_0_i12,
		STATIC(mercury__trace__generate_event_code_9_0));
Define_label(mercury__trace__generate_event_code_9_0_i12);
	update_prof_current_proc(LABEL(mercury__trace__generate_event_code_9_0));
	MR_stackvar(6) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_instmap_3_0),
		mercury__trace__generate_event_code_9_0_i13,
		STATIC(mercury__trace__generate_event_code_9_0));
Define_label(mercury__trace__generate_event_code_9_0_i13);
	update_prof_current_proc(LABEL(mercury__trace__generate_event_code_9_0));
	r3 = r1;
	r5 = r2;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(6);
	r4 = MR_stackvar(8);
	call_localret(STATIC(mercury__trace__produce_vars_9_0),
		mercury__trace__generate_event_code_9_0_i14,
		STATIC(mercury__trace__generate_event_code_9_0));
Define_label(mercury__trace__generate_event_code_9_0_i14);
	update_prof_current_proc(LABEL(mercury__trace__generate_event_code_9_0));
	MR_stackvar(2) = r1;
	r1 = r4;
	MR_stackvar(6) = r2;
	MR_stackvar(8) = r3;
	call_localret(ENTRY(mercury__code_info__max_reg_in_use_3_0),
		mercury__trace__generate_event_code_9_0_i32,
		STATIC(mercury__trace__generate_event_code_9_0));
Define_label(mercury__trace__generate_event_code_9_0_i32);
	update_prof_current_proc(LABEL(mercury__trace__generate_event_code_9_0));
	MR_stackvar(9) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_max_reg_in_use_at_trace_3_0),
		mercury__trace__generate_event_code_9_0_i33,
		STATIC(mercury__trace__generate_event_code_9_0));
Define_label(mercury__trace__generate_event_code_9_0_i33);
	update_prof_current_proc(LABEL(mercury__trace__generate_event_code_9_0));
	if (((Integer) r1 >= (Integer) MR_stackvar(9)))
		GOTO_LABEL(mercury__trace__generate_event_code_9_0_i34);
	r1 = MR_stackvar(9);
	call_localret(ENTRY(mercury__code_info__set_max_reg_in_use_at_trace_3_0),
		mercury__trace__generate_event_code_9_0_i36,
		STATIC(mercury__trace__generate_event_code_9_0));
Define_label(mercury__trace__generate_event_code_9_0_i34);
	r1 = r2;
Define_label(mercury__trace__generate_event_code_9_0_i36);
	update_prof_current_proc(LABEL(mercury__trace__generate_event_code_9_0));
	call_localret(ENTRY(mercury__code_info__variable_locations_3_0),
		mercury__trace__generate_event_code_9_0_i37,
		STATIC(mercury__trace__generate_event_code_9_0));
Define_label(mercury__trace__generate_event_code_9_0_i37);
	update_prof_current_proc(LABEL(mercury__trace__generate_event_code_9_0));
	MR_stackvar(9) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_proc_info_3_0),
		mercury__trace__generate_event_code_9_0_i38,
		STATIC(mercury__trace__generate_event_code_9_0));
Define_label(mercury__trace__generate_event_code_9_0_i38);
	update_prof_current_proc(LABEL(mercury__trace__generate_event_code_9_0));
	MR_stackvar(10) = r2;
	r2 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_25);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__trace__generate_event_code_9_0_i39,
		STATIC(mercury__trace__generate_event_code_9_0));
Define_label(mercury__trace__generate_event_code_9_0_i39);
	update_prof_current_proc(LABEL(mercury__trace__generate_event_code_9_0));
	r2 = MR_stackvar(9);
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__continuation_info__find_typeinfos_for_tvars_4_0),
		mercury__trace__generate_event_code_9_0_i40,
		STATIC(mercury__trace__generate_event_code_9_0));
Define_label(mercury__trace__generate_event_code_9_0_i40);
	update_prof_current_proc(LABEL(mercury__trace__generate_event_code_9_0));
	MR_stackvar(2) = r1;
	r1 = (Word) (Word *) &mercury_data_continuation_info__type_ctor_info_var_info_0;
	r2 = MR_stackvar(6);
	call_localret(ENTRY(mercury__set__list_to_set_2_0),
		mercury__trace__generate_event_code_9_0_i41,
		STATIC(mercury__trace__generate_event_code_9_0));
Define_label(mercury__trace__generate_event_code_9_0_i41);
	update_prof_current_proc(LABEL(mercury__trace__generate_event_code_9_0));
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__trace__generate_event_code_9_0, "origin_lost_in_value_number");
	MR_stackvar(6) = r3;
	MR_field(MR_mktag(0), r3, (Integer) 0) = r1;
	r1 = MR_stackvar(5);
	r2 = (Integer) 1;
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(2);
	call_localret(ENTRY(mercury__llds_out__get_label_3_0),
		mercury__trace__generate_event_code_9_0_i42,
		STATIC(mercury__trace__generate_event_code_9_0));
Define_label(mercury__trace__generate_event_code_9_0_i42);
	update_prof_current_proc(LABEL(mercury__trace__generate_event_code_9_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__trace__generate_event_code_9_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("\t\tMR_jumpaddr = MR_trace(\n", 26);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__trace__generate_event_code_9_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const("\t\t\t(const MR_Stack_Layout_Label *)\n", 35);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__trace__generate_event_code_9_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_string_const("\t\t\t&mercury_data__layout__", 26);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__trace__generate_event_code_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_trace__common_8);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__trace__generate_event_code_9_0_i43,
		STATIC(mercury__trace__generate_event_code_9_0));
	}
Define_label(mercury__trace__generate_event_code_9_0_i43);
	update_prof_current_proc(LABEL(mercury__trace__generate_event_code_9_0));
	MR_stackvar(9) = r1;
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(7);
	r5 = MR_stackvar(6);
	r6 = MR_stackvar(10);
	call_localret(ENTRY(mercury__code_info__add_trace_layout_for_label_7_0),
		mercury__trace__generate_event_code_9_0_i44,
		STATIC(mercury__trace__generate_event_code_9_0));
Define_label(mercury__trace__generate_event_code_9_0_i44);
	update_prof_current_proc(LABEL(mercury__trace__generate_event_code_9_0));
	if (((Integer) MR_stackvar(1) != (Integer) 2))
		GOTO_LABEL(mercury__trace__generate_event_code_9_0_i46);
	r2 = r1;
	r1 = MR_stackvar(3);
	MR_stackvar(3) = r2;
	call_localret(STATIC(mercury__trace__trace_info_get_maybe_redo_layout_slot_2_0),
		mercury__trace__generate_event_code_9_0_i48,
		STATIC(mercury__trace__generate_event_code_9_0));
Define_label(mercury__trace__generate_event_code_9_0_i48);
	update_prof_current_proc(LABEL(mercury__trace__generate_event_code_9_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__trace__generate_event_code_9_0_i45);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_stackvar(4);
	r3 = (Integer) 3;
	r4 = MR_stackvar(7);
	r5 = MR_stackvar(6);
	r6 = MR_stackvar(3);
	call_localret(ENTRY(mercury__code_info__add_trace_layout_for_label_7_0),
		mercury__trace__generate_event_code_9_0_i50,
		STATIC(mercury__trace__generate_event_code_9_0));
Define_label(mercury__trace__generate_event_code_9_0_i50);
	update_prof_current_proc(LABEL(mercury__trace__generate_event_code_9_0));
	MR_stackvar(1) = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__trace__generate_event_code_9_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("\t\tCode *MR_jumpaddr;\n", 21);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__trace__generate_event_code_9_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const("\t\tsave_transient_registers();\n", 30);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__trace__generate_event_code_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_trace__common_29);
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(9);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__trace__generate_event_code_9_0_i52,
		STATIC(mercury__trace__generate_event_code_9_0));
Define_label(mercury__trace__generate_event_code_9_0_i45);
	r1 = MR_stackvar(3);
Define_label(mercury__trace__generate_event_code_9_0_i46);
	MR_stackvar(1) = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__trace__generate_event_code_9_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("\t\tCode *MR_jumpaddr;\n", 21);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__trace__generate_event_code_9_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const("\t\tsave_transient_registers();\n", 30);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__trace__generate_event_code_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_trace__common_29);
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(9);
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__trace__generate_event_code_9_0_i52,
		STATIC(mercury__trace__generate_event_code_9_0));
Define_label(mercury__trace__generate_event_code_9_0_i52);
	update_prof_current_proc(LABEL(mercury__trace__generate_event_code_9_0));
	r4 = r1;
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(2);
	tag_incr_hp_msg(r3, MR_mktag(2), (Integer) 2, mercury__trace__generate_event_code_9_0, "tree:tree/1");
	MR_field(MR_mktag(2), r3, (Integer) 0) = MR_stackvar(8);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 1, mercury__trace__generate_event_code_9_0, "tree:tree/1");
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__trace__generate_event_code_9_0, "list:list/1");
	tag_incr_hp_msg(r7, MR_mktag(0), (Integer) 2, mercury__trace__generate_event_code_9_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__trace__generate_event_code_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(0), r7, (Integer) 1) = (Word) MR_string_const("A label to hang trace liveness on", 33);
	MR_field(MR_mktag(1), r6, (Integer) 0) = r7;
	MR_field(MR_mktag(0), r7, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r7, MR_mktag(1), (Integer) 2, mercury__trace__generate_event_code_9_0, "list:list/1");
	tag_incr_hp_msg(r8, MR_mktag(0), (Integer) 2, mercury__trace__generate_event_code_9_0, "std_util:pair/2");
	tag_incr_hp_msg(r9, MR_mktag(3), (Integer) 7, mercury__trace__generate_event_code_9_0, "llds:instr/0");
	MR_field(MR_mktag(3), r9, (Integer) 0) = (Integer) 18;
	MR_field(MR_mktag(3), r9, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r10, MR_mktag(1), (Integer) 2, mercury__trace__generate_event_code_9_0, "list:list/1");
	MR_field(MR_mktag(3), r9, (Integer) 3) = (Integer) 0;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__trace__generate_event_code_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r10, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(3), r9, (Integer) 2) = r10;
	MR_field(MR_mktag(1), r10, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__trace__generate_event_code_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r9, (Integer) 4) = MR_tempr1;
	r4 = MR_stackvar(1);
	MR_field(MR_mktag(3), r9, (Integer) 6) = (Integer) 1;
	MR_field(MR_mktag(3), r9, (Integer) 5) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(2), r3, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 0) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 1) = r7;
	MR_field(MR_mktag(1), r7, (Integer) 0) = r8;
	MR_field(MR_mktag(1), r7, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r8, (Integer) 0) = r9;
	MR_field(MR_mktag(0), r8, (Integer) 1) = (Word) MR_string_const("", 0);
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	proceed();
	}
END_MODULE

Declare_entry(mercury__code_info__produce_variable_in_reg_or_stack_5_0);
Declare_entry(mercury__code_info__variable_type_4_0);
Declare_entry(mercury__code_info__get_module_info_3_0);
Declare_entry(mercury__varset__search_name_3_0);
Declare_entry(mercury__instmap__lookup_var_3_0);
Declare_entry(mercury__inst_match__inst_is_ground_2_0);
Declare_entry(mercury__type_util__vars_2_0);
Declare_entry(mercury__set__insert_list_3_0);

BEGIN_MODULE(trace_module15)
	init_entry(mercury__trace__produce_vars_9_0);
	init_label(mercury__trace__produce_vars_9_0_i4);
	init_label(mercury__trace__produce_vars_9_0_i5);
	init_label(mercury__trace__produce_vars_9_0_i6);
	init_label(mercury__trace__produce_vars_9_0_i7);
	init_label(mercury__trace__produce_vars_9_0_i9);
	init_label(mercury__trace__produce_vars_9_0_i10);
	init_label(mercury__trace__produce_vars_9_0_i12);
	init_label(mercury__trace__produce_vars_9_0_i11);
	init_label(mercury__trace__produce_vars_9_0_i14);
	init_label(mercury__trace__produce_vars_9_0_i15);
	init_label(mercury__trace__produce_vars_9_0_i18);
	init_label(mercury__trace__produce_vars_9_0_i16);
	init_label(mercury__trace__produce_vars_9_0_i21);
	init_label(mercury__trace__produce_vars_9_0_i22);
	init_label(mercury__trace__produce_vars_9_0_i23);
	init_label(mercury__trace__produce_vars_9_0_i3);
BEGIN_CODE

/* code for predicate 'produce_vars'/9 in mode 0 */
Define_static(mercury__trace__produce_vars_9_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__trace__produce_vars_9_0_i3);
	MR_incr_sp_push_msg(14, "trace:produce_vars/9");
	MR_stackvar(14) = (Word) MR_succip;
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(1) = r2;
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(4) = r1;
	r2 = r5;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	call_localret(ENTRY(mercury__code_info__produce_variable_in_reg_or_stack_5_0),
		mercury__trace__produce_vars_9_0_i4,
		STATIC(mercury__trace__produce_vars_9_0));
Define_label(mercury__trace__produce_vars_9_0_i4);
	update_prof_current_proc(LABEL(mercury__trace__produce_vars_9_0));
	MR_stackvar(6) = r2;
	MR_stackvar(7) = r1;
	r1 = MR_stackvar(4);
	r2 = r3;
	call_localret(ENTRY(mercury__code_info__variable_type_4_0),
		mercury__trace__produce_vars_9_0_i5,
		STATIC(mercury__trace__produce_vars_9_0));
Define_label(mercury__trace__produce_vars_9_0_i5);
	update_prof_current_proc(LABEL(mercury__trace__produce_vars_9_0));
	MR_stackvar(8) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_module_info_3_0),
		mercury__trace__produce_vars_9_0_i6,
		STATIC(mercury__trace__produce_vars_9_0));
Define_label(mercury__trace__produce_vars_9_0_i6);
	update_prof_current_proc(LABEL(mercury__trace__produce_vars_9_0));
	if ((MR_tag(MR_stackvar(6)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__trace__produce_vars_9_0_i7);
	MR_stackvar(13) = r2;
	MR_stackvar(10) = MR_const_field(MR_mktag(0), MR_stackvar(6), (Integer) 0);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(4);
	MR_stackvar(9) = r1;
	GOTO_LABEL(mercury__trace__produce_vars_9_0_i10);
Define_label(mercury__trace__produce_vars_9_0_i7);
	MR_stackvar(9) = r1;
	r1 = (Word) MR_string_const("var not an lval in trace__produce_vars", 38);
	MR_stackvar(13) = r2;
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__trace__produce_vars_9_0_i9,
		STATIC(mercury__trace__produce_vars_9_0));
Define_label(mercury__trace__produce_vars_9_0_i9);
	update_prof_current_proc(LABEL(mercury__trace__produce_vars_9_0));
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(4);
Define_label(mercury__trace__produce_vars_9_0_i10);
	MR_stackvar(1) = r2;
	MR_stackvar(4) = r3;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	call_localret(ENTRY(mercury__varset__search_name_3_0),
		mercury__trace__produce_vars_9_0_i12,
		STATIC(mercury__trace__produce_vars_9_0));
Define_label(mercury__trace__produce_vars_9_0_i12);
	update_prof_current_proc(LABEL(mercury__trace__produce_vars_9_0));
	if (!(r1))
		GOTO_LABEL(mercury__trace__produce_vars_9_0_i11);
	MR_stackvar(11) = r2;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(4);
	GOTO_LABEL(mercury__trace__produce_vars_9_0_i14);
Define_label(mercury__trace__produce_vars_9_0_i11);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(4);
	MR_stackvar(11) = (Word) MR_string_const("", 0);
Define_label(mercury__trace__produce_vars_9_0_i14);
	MR_stackvar(2) = r1;
	MR_stackvar(4) = r2;
	call_localret(ENTRY(mercury__instmap__lookup_var_3_0),
		mercury__trace__produce_vars_9_0_i15,
		STATIC(mercury__trace__produce_vars_9_0));
Define_label(mercury__trace__produce_vars_9_0_i15);
	update_prof_current_proc(LABEL(mercury__trace__produce_vars_9_0));
	MR_stackvar(12) = r1;
	r2 = r1;
	r1 = MR_stackvar(9);
	call_localret(ENTRY(mercury__inst_match__inst_is_ground_2_0),
		mercury__trace__produce_vars_9_0_i18,
		STATIC(mercury__trace__produce_vars_9_0));
Define_label(mercury__trace__produce_vars_9_0_i18);
	update_prof_current_proc(LABEL(mercury__trace__produce_vars_9_0));
	if (!(r1))
		GOTO_LABEL(mercury__trace__produce_vars_9_0_i16);
	tag_incr_hp_msg(MR_stackvar(6), MR_mktag(0), (Integer) 2, mercury__trace__produce_vars_9_0, "continuation_info:var_info/0");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 1, mercury__trace__produce_vars_9_0, "llds:layout_locn/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(10);
	MR_field(MR_mktag(0), MR_stackvar(6), (Integer) 0) = r1;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 4, mercury__trace__produce_vars_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_stackvar(6), (Integer) 1) = r2;
	r1 = MR_stackvar(8);
	MR_field(MR_mktag(1), r2, (Integer) 3) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r2, (Integer) 2) = r1;
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_stackvar(11);
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(4);
	call_localret(ENTRY(mercury__type_util__vars_2_0),
		mercury__trace__produce_vars_9_0_i21,
		STATIC(mercury__trace__produce_vars_9_0));
Define_label(mercury__trace__produce_vars_9_0_i16);
	r1 = MR_stackvar(12);
	tag_incr_hp_msg(MR_stackvar(6), MR_mktag(0), (Integer) 2, mercury__trace__produce_vars_9_0, "continuation_info:var_info/0");
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 1, mercury__trace__produce_vars_9_0, "llds:layout_locn/0");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(10);
	MR_field(MR_mktag(0), MR_stackvar(6), (Integer) 0) = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 4, mercury__trace__produce_vars_9_0, "llds:live_value_type/0");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_stackvar(11);
	MR_field(MR_mktag(1), r2, (Integer) 2) = MR_stackvar(8);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__trace__produce_vars_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r2, (Integer) 3) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	r1 = MR_stackvar(8);
	MR_field(MR_mktag(0), MR_stackvar(6), (Integer) 1) = r2;
	call_localret(ENTRY(mercury__type_util__vars_2_0),
		mercury__trace__produce_vars_9_0_i21,
		STATIC(mercury__trace__produce_vars_9_0));
Define_label(mercury__trace__produce_vars_9_0_i21);
	update_prof_current_proc(LABEL(mercury__trace__produce_vars_9_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_25);
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__set__insert_list_3_0),
		mercury__trace__produce_vars_9_0_i22,
		STATIC(mercury__trace__produce_vars_9_0));
Define_label(mercury__trace__produce_vars_9_0_i22);
	update_prof_current_proc(LABEL(mercury__trace__produce_vars_9_0));
	r4 = r1;
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r5 = MR_stackvar(13);
	localcall(mercury__trace__produce_vars_9_0,
		LABEL(mercury__trace__produce_vars_9_0_i23),
		STATIC(mercury__trace__produce_vars_9_0));
Define_label(mercury__trace__produce_vars_9_0_i23);
	update_prof_current_proc(LABEL(mercury__trace__produce_vars_9_0));
	r5 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__trace__produce_vars_9_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(6);
	MR_field(MR_mktag(1), r2, (Integer) 1) = r5;
	r6 = r3;
	tag_incr_hp_msg(r3, MR_mktag(2), (Integer) 2, mercury__trace__produce_vars_9_0, "tree:tree/1");
	MR_field(MR_mktag(2), r3, (Integer) 0) = MR_stackvar(7);
	MR_field(MR_mktag(2), r3, (Integer) 1) = r6;
	MR_succip = (Code *) MR_stackvar(14);
	MR_decr_sp_pop_msg(14);
	proceed();
Define_label(mercury__trace__produce_vars_9_0_i3);
	r1 = r4;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r4 = r5;
	proceed();
END_MODULE

Declare_entry(mercury__inst_match__inst_is_clobbered_2_0);

BEGIN_MODULE(trace_module16)
	init_entry(mercury__trace__build_fail_vars_5_0);
	init_label(mercury__trace__build_fail_vars_5_0_i3);
	init_label(mercury__trace__build_fail_vars_5_0_i8);
	init_label(mercury__trace__build_fail_vars_5_0_i15);
	init_label(mercury__trace__build_fail_vars_5_0_i10);
	init_label(mercury__trace__build_fail_vars_5_0_i2);
	init_label(mercury__trace__build_fail_vars_5_0_i1011);
	init_label(mercury__trace__build_fail_vars_5_0_i1);
BEGIN_CODE

/* code for predicate 'build_fail_vars'/5 in mode 0 */
Define_static(mercury__trace__build_fail_vars_5_0);
	MR_incr_sp_push_msg(5, "trace:build_fail_vars/5");
	MR_stackvar(5) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__trace__build_fail_vars_5_0_i3);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__trace__build_fail_vars_5_0_i1011);
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__trace__build_fail_vars_5_0_i1011);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__trace__build_fail_vars_5_0_i3);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__trace__build_fail_vars_5_0_i1);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__trace__build_fail_vars_5_0_i1);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r3 = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	MR_stackvar(1) = r4;
	localcall(mercury__trace__build_fail_vars_5_0,
		LABEL(mercury__trace__build_fail_vars_5_0_i8),
		STATIC(mercury__trace__build_fail_vars_5_0));
Define_label(mercury__trace__build_fail_vars_5_0_i8);
	update_prof_current_proc(LABEL(mercury__trace__build_fail_vars_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__trace__build_fail_vars_5_0_i1);
	if (((Integer) MR_const_field(MR_mktag(0), MR_stackvar(4), (Integer) 1) != (Integer) 0))
		GOTO_LABEL(mercury__trace__build_fail_vars_5_0_i2);
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__inst_match__inst_is_clobbered_2_0),
		mercury__trace__build_fail_vars_5_0_i15,
		STATIC(mercury__trace__build_fail_vars_5_0));
Define_label(mercury__trace__build_fail_vars_5_0_i15);
	update_prof_current_proc(LABEL(mercury__trace__build_fail_vars_5_0));
	if (r1)
		GOTO_LABEL(mercury__trace__build_fail_vars_5_0_i10);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__trace__build_fail_vars_5_0, "origin_lost_in_value_number");
	r1 = TRUE;
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__trace__build_fail_vars_5_0_i10);
	r2 = MR_stackvar(1);
Define_label(mercury__trace__build_fail_vars_5_0_i2);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__trace__build_fail_vars_5_0_i1011);
	r1 = FALSE;
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__trace__build_fail_vars_5_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE

Declare_entry(mercury__string__int_to_string_2_0);

BEGIN_MODULE(trace_module17)
	init_entry(mercury__trace__stackref_to_string_2_0);
	init_label(mercury__trace__stackref_to_string_2_0_i4);
	init_label(mercury__trace__stackref_to_string_2_0_i2);
	init_label(mercury__trace__stackref_to_string_2_0_i8);
	init_label(mercury__trace__stackref_to_string_2_0_i6);
BEGIN_CODE

/* code for predicate 'stackref_to_string'/2 in mode 0 */
Define_static(mercury__trace__stackref_to_string_2_0);
	if ((MR_tag(r1) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__trace__stackref_to_string_2_0_i2);
	if (((Integer) MR_const_field(MR_mktag(3), r1, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__trace__stackref_to_string_2_0_i2);
	MR_incr_sp_push_msg(1, "trace:stackref_to_string/2");
	MR_stackvar(1) = (Word) MR_succip;
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__trace__stackref_to_string_2_0_i4,
		STATIC(mercury__trace__stackref_to_string_2_0));
Define_label(mercury__trace__stackref_to_string_2_0_i4);
	update_prof_current_proc(LABEL(mercury__trace__stackref_to_string_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__trace__stackref_to_string_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("MR_stackvar(", 12);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__trace__stackref_to_string_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_trace__common_30);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		STATIC(mercury__trace__stackref_to_string_2_0));
Define_label(mercury__trace__stackref_to_string_2_0_i2);
	if ((MR_tag(r1) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__trace__stackref_to_string_2_0_i6);
	if (((Integer) MR_const_field(MR_mktag(3), r1, (Integer) 0) != (Integer) 1))
		GOTO_LABEL(mercury__trace__stackref_to_string_2_0_i6);
	MR_incr_sp_push_msg(1, "trace:stackref_to_string/2");
	MR_stackvar(1) = (Word) MR_succip;
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__trace__stackref_to_string_2_0_i8,
		STATIC(mercury__trace__stackref_to_string_2_0));
Define_label(mercury__trace__stackref_to_string_2_0_i8);
	update_prof_current_proc(LABEL(mercury__trace__stackref_to_string_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__trace__stackref_to_string_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("MR_framevar(", 12);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__trace__stackref_to_string_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_trace__common_30);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		STATIC(mercury__trace__stackref_to_string_2_0));
Define_label(mercury__trace__stackref_to_string_2_0_i6);
	r1 = (Word) MR_string_const("non-stack lval in stackref_to_string", 36);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__trace__stackref_to_string_2_0));
END_MODULE


BEGIN_MODULE(trace_module18)
	init_entry(mercury__trace__path_steps_to_strings_2_0);
	init_label(mercury__trace__path_steps_to_strings_2_0_i6);
	init_label(mercury__trace__path_steps_to_strings_2_0_i7);
	init_label(mercury__trace__path_steps_to_strings_2_0_i8);
	init_label(mercury__trace__path_steps_to_strings_2_0_i9);
	init_label(mercury__trace__path_steps_to_strings_2_0_i10);
	init_label(mercury__trace__path_steps_to_strings_2_0_i11);
	init_label(mercury__trace__path_steps_to_strings_2_0_i12);
	init_label(mercury__trace__path_steps_to_strings_2_0_i13);
	init_label(mercury__trace__path_steps_to_strings_2_0_i14);
	init_label(mercury__trace__path_steps_to_strings_2_0_i15);
	init_label(mercury__trace__path_steps_to_strings_2_0_i17);
	init_label(mercury__trace__path_steps_to_strings_2_0_i18);
	init_label(mercury__trace__path_steps_to_strings_2_0_i20);
	init_label(mercury__trace__path_steps_to_strings_2_0_i21);
	init_label(mercury__trace__path_steps_to_strings_2_0_i22);
	init_label(mercury__trace__path_steps_to_strings_2_0_i23);
	init_label(mercury__trace__path_steps_to_strings_2_0_i3);
BEGIN_CODE

/* code for predicate 'path_steps_to_strings'/2 in mode 0 */
Define_static(mercury__trace__path_steps_to_strings_2_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__trace__path_steps_to_strings_2_0_i3);
	MR_incr_sp_push_msg(2, "trace:path_steps_to_strings/2");
	MR_stackvar(2) = (Word) MR_succip;
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	COMPUTED_GOTO((Unsigned) MR_tag(r2),
		LABEL(mercury__trace__path_steps_to_strings_2_0_i6) AND
		LABEL(mercury__trace__path_steps_to_strings_2_0_i14) AND
		LABEL(mercury__trace__path_steps_to_strings_2_0_i17) AND
		LABEL(mercury__trace__path_steps_to_strings_2_0_i20));
Define_label(mercury__trace__path_steps_to_strings_2_0_i6);
	COMPUTED_GOTO((Unsigned) MR_unmkbody(r2),
		LABEL(mercury__trace__path_steps_to_strings_2_0_i7) AND
		LABEL(mercury__trace__path_steps_to_strings_2_0_i8) AND
		LABEL(mercury__trace__path_steps_to_strings_2_0_i9) AND
		LABEL(mercury__trace__path_steps_to_strings_2_0_i10) AND
		LABEL(mercury__trace__path_steps_to_strings_2_0_i11) AND
		LABEL(mercury__trace__path_steps_to_strings_2_0_i12) AND
		LABEL(mercury__trace__path_steps_to_strings_2_0_i13));
Define_label(mercury__trace__path_steps_to_strings_2_0_i7);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(1) = (Word) MR_string_const("?;", 2);
	localcall(mercury__trace__path_steps_to_strings_2_0,
		LABEL(mercury__trace__path_steps_to_strings_2_0_i23),
		STATIC(mercury__trace__path_steps_to_strings_2_0));
Define_label(mercury__trace__path_steps_to_strings_2_0_i8);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(1) = (Word) MR_string_const("t;", 2);
	localcall(mercury__trace__path_steps_to_strings_2_0,
		LABEL(mercury__trace__path_steps_to_strings_2_0_i23),
		STATIC(mercury__trace__path_steps_to_strings_2_0));
Define_label(mercury__trace__path_steps_to_strings_2_0_i9);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(1) = (Word) MR_string_const("e;", 2);
	localcall(mercury__trace__path_steps_to_strings_2_0,
		LABEL(mercury__trace__path_steps_to_strings_2_0_i23),
		STATIC(mercury__trace__path_steps_to_strings_2_0));
Define_label(mercury__trace__path_steps_to_strings_2_0_i10);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(1) = (Word) MR_string_const("~;", 2);
	localcall(mercury__trace__path_steps_to_strings_2_0,
		LABEL(mercury__trace__path_steps_to_strings_2_0_i23),
		STATIC(mercury__trace__path_steps_to_strings_2_0));
Define_label(mercury__trace__path_steps_to_strings_2_0_i11);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(1) = (Word) MR_string_const("q;", 2);
	localcall(mercury__trace__path_steps_to_strings_2_0,
		LABEL(mercury__trace__path_steps_to_strings_2_0_i23),
		STATIC(mercury__trace__path_steps_to_strings_2_0));
Define_label(mercury__trace__path_steps_to_strings_2_0_i12);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(1) = (Word) MR_string_const("f;", 2);
	localcall(mercury__trace__path_steps_to_strings_2_0,
		LABEL(mercury__trace__path_steps_to_strings_2_0_i23),
		STATIC(mercury__trace__path_steps_to_strings_2_0));
Define_label(mercury__trace__path_steps_to_strings_2_0_i13);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(1) = (Word) MR_string_const("l;", 2);
	localcall(mercury__trace__path_steps_to_strings_2_0,
		LABEL(mercury__trace__path_steps_to_strings_2_0_i23),
		STATIC(mercury__trace__path_steps_to_strings_2_0));
Define_label(mercury__trace__path_steps_to_strings_2_0_i14);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__trace__path_steps_to_strings_2_0_i15,
		STATIC(mercury__trace__path_steps_to_strings_2_0));
Define_label(mercury__trace__path_steps_to_strings_2_0_i15);
	update_prof_current_proc(LABEL(mercury__trace__path_steps_to_strings_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__trace__path_steps_to_strings_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("c", 1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__trace__path_steps_to_strings_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_trace__common_2);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__trace__path_steps_to_strings_2_0_i22,
		STATIC(mercury__trace__path_steps_to_strings_2_0));
Define_label(mercury__trace__path_steps_to_strings_2_0_i17);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(2), r2, (Integer) 0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__trace__path_steps_to_strings_2_0_i18,
		STATIC(mercury__trace__path_steps_to_strings_2_0));
Define_label(mercury__trace__path_steps_to_strings_2_0_i18);
	update_prof_current_proc(LABEL(mercury__trace__path_steps_to_strings_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__trace__path_steps_to_strings_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("d", 1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__trace__path_steps_to_strings_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_trace__common_2);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__trace__path_steps_to_strings_2_0_i22,
		STATIC(mercury__trace__path_steps_to_strings_2_0));
Define_label(mercury__trace__path_steps_to_strings_2_0_i20);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(3), r2, (Integer) 0);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__trace__path_steps_to_strings_2_0_i21,
		STATIC(mercury__trace__path_steps_to_strings_2_0));
Define_label(mercury__trace__path_steps_to_strings_2_0_i21);
	update_prof_current_proc(LABEL(mercury__trace__path_steps_to_strings_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__trace__path_steps_to_strings_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("s", 1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__trace__path_steps_to_strings_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_trace__common_2);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__trace__path_steps_to_strings_2_0_i22,
		STATIC(mercury__trace__path_steps_to_strings_2_0));
Define_label(mercury__trace__path_steps_to_strings_2_0_i22);
	update_prof_current_proc(LABEL(mercury__trace__path_steps_to_strings_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	localcall(mercury__trace__path_steps_to_strings_2_0,
		LABEL(mercury__trace__path_steps_to_strings_2_0_i23),
		STATIC(mercury__trace__path_steps_to_strings_2_0));
Define_label(mercury__trace__path_steps_to_strings_2_0_i23);
	update_prof_current_proc(LABEL(mercury__trace__path_steps_to_strings_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__trace__path_steps_to_strings_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__trace__path_steps_to_strings_2_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE


BEGIN_MODULE(trace_module19)
	init_entry(mercury__trace__event_num_slot_2_0);
	init_label(mercury__trace__event_num_slot_2_0_i2);
BEGIN_CODE

/* code for predicate 'event_num_slot'/2 in mode 0 */
Define_static(mercury__trace__event_num_slot_2_0);
	if (((Integer) r1 != (Integer) 2))
		GOTO_LABEL(mercury__trace__event_num_slot_2_0_i2);
	r1 = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_trace__common_31);
	proceed();
Define_label(mercury__trace__event_num_slot_2_0_i2);
	r1 = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_trace__common_32);
	proceed();
END_MODULE


BEGIN_MODULE(trace_module20)
	init_entry(mercury__trace__call_num_slot_2_0);
	init_label(mercury__trace__call_num_slot_2_0_i2);
BEGIN_CODE

/* code for predicate 'call_num_slot'/2 in mode 0 */
Define_static(mercury__trace__call_num_slot_2_0);
	if (((Integer) r1 != (Integer) 2))
		GOTO_LABEL(mercury__trace__call_num_slot_2_0_i2);
	r1 = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_trace__common_33);
	proceed();
Define_label(mercury__trace__call_num_slot_2_0_i2);
	r1 = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_trace__common_34);
	proceed();
END_MODULE


BEGIN_MODULE(trace_module21)
	init_entry(mercury__trace__call_depth_slot_2_0);
	init_label(mercury__trace__call_depth_slot_2_0_i2);
BEGIN_CODE

/* code for predicate 'call_depth_slot'/2 in mode 0 */
Define_static(mercury__trace__call_depth_slot_2_0);
	if (((Integer) r1 != (Integer) 2))
		GOTO_LABEL(mercury__trace__call_depth_slot_2_0_i2);
	r1 = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_trace__common_6);
	proceed();
Define_label(mercury__trace__call_depth_slot_2_0_i2);
	r1 = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_trace__common_7);
	proceed();
END_MODULE


BEGIN_MODULE(trace_module22)
	init_entry(mercury__trace__redo_layout_slot_2_0);
	init_label(mercury__trace__redo_layout_slot_2_0_i2);
BEGIN_CODE

/* code for predicate 'redo_layout_slot'/2 in mode 0 */
Define_static(mercury__trace__redo_layout_slot_2_0);
	if (((Integer) r1 != (Integer) 2))
		GOTO_LABEL(mercury__trace__redo_layout_slot_2_0_i2);
	r1 = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_trace__common_35);
	proceed();
Define_label(mercury__trace__redo_layout_slot_2_0_i2);
	r1 = (Word) MR_string_const("attempt to access redo layout slot for det or semi procedure", 60);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__trace__redo_layout_slot_2_0));
END_MODULE


BEGIN_MODULE(trace_module23)
	init_entry(mercury__trace__trace_info_get_trace_type_2_0);
BEGIN_CODE

/* code for predicate 'trace_info_get_trace_type'/2 in mode 0 */
Define_static(mercury__trace__trace_info_get_trace_type_2_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	proceed();
END_MODULE


BEGIN_MODULE(trace_module24)
	init_entry(mercury__trace__trace_info_get_maybe_trail_slots_2_0);
BEGIN_CODE

/* code for predicate 'trace_info_get_maybe_trail_slots'/2 in mode 0 */
Define_static(mercury__trace__trace_info_get_maybe_trail_slots_2_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	proceed();
END_MODULE


BEGIN_MODULE(trace_module25)
	init_entry(mercury__trace__trace_info_get_maybe_redo_layout_slot_2_0);
BEGIN_CODE

/* code for predicate 'trace_info_get_maybe_redo_layout_slot'/2 in mode 0 */
Define_static(mercury__trace__trace_info_get_maybe_redo_layout_slot_2_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	proceed();
END_MODULE


BEGIN_MODULE(trace_module26)
	init_entry(mercury____Unify___trace__external_trace_port_0_0);
	init_label(mercury____Unify___trace__external_trace_port_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___trace__external_trace_port_0_0);
	if ((r1 != r2))
		GOTO_LABEL(mercury____Unify___trace__external_trace_port_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___trace__external_trace_port_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(trace_module27)
	init_entry(mercury____Index___trace__external_trace_port_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___trace__external_trace_port_0_0);
	proceed();
END_MODULE

Declare_entry(mercury__builtin_compare_int_3_0);

BEGIN_MODULE(trace_module28)
	init_entry(mercury____Compare___trace__external_trace_port_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___trace__external_trace_port_0_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___trace__external_trace_port_0_0));
END_MODULE


BEGIN_MODULE(trace_module29)
	init_entry(mercury____Unify___trace__negation_end_port_0_0);
	init_label(mercury____Unify___trace__negation_end_port_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___trace__negation_end_port_0_0);
	if ((r1 != r2))
		GOTO_LABEL(mercury____Unify___trace__negation_end_port_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___trace__negation_end_port_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(trace_module30)
	init_entry(mercury____Index___trace__negation_end_port_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___trace__negation_end_port_0_0);
	proceed();
END_MODULE


BEGIN_MODULE(trace_module31)
	init_entry(mercury____Compare___trace__negation_end_port_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___trace__negation_end_port_0_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___trace__negation_end_port_0_0));
END_MODULE


BEGIN_MODULE(trace_module32)
	init_entry(mercury____Unify___trace__nondet_pragma_trace_port_0_0);
	init_label(mercury____Unify___trace__nondet_pragma_trace_port_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___trace__nondet_pragma_trace_port_0_0);
	if ((r1 != r2))
		GOTO_LABEL(mercury____Unify___trace__nondet_pragma_trace_port_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___trace__nondet_pragma_trace_port_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(trace_module33)
	init_entry(mercury____Index___trace__nondet_pragma_trace_port_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___trace__nondet_pragma_trace_port_0_0);
	proceed();
END_MODULE


BEGIN_MODULE(trace_module34)
	init_entry(mercury____Compare___trace__nondet_pragma_trace_port_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___trace__nondet_pragma_trace_port_0_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___trace__nondet_pragma_trace_port_0_0));
END_MODULE

Declare_entry(mercury____Unify___std_util__maybe_1_0);

BEGIN_MODULE(trace_module35)
	init_entry(mercury____Unify___trace__trace_info_0_0);
	init_label(mercury____Unify___trace__trace_info_0_0_i3);
	init_label(mercury____Unify___trace__trace_info_0_0_i6);
	init_label(mercury____Unify___trace__trace_info_0_0_i8);
	init_label(mercury____Unify___trace__trace_info_0_0_i1013);
	init_label(mercury____Unify___trace__trace_info_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___trace__trace_info_0_0);
	MR_incr_sp_push_msg(9, "trace:__Unify__/2");
	MR_stackvar(9) = (Word) MR_succip;
	if (((Integer) MR_const_field(MR_mktag(0), r1, (Integer) 0) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Unify___trace__trace_info_0_0_i3);
	if (((Integer) MR_const_field(MR_mktag(0), r2, (Integer) 0) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Unify___trace__trace_info_0_0_i1013);
	if ((MR_const_field(MR_mktag(0), r1, (Integer) 1) != MR_const_field(MR_mktag(0), r2, (Integer) 1)))
		GOTO_LABEL(mercury____Unify___trace__trace_info_0_0_i1013);
	if ((MR_const_field(MR_mktag(0), r1, (Integer) 2) != MR_const_field(MR_mktag(0), r2, (Integer) 2)))
		GOTO_LABEL(mercury____Unify___trace__trace_info_0_0_i1013);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_36);
	call_localret(ENTRY(mercury____Unify___std_util__maybe_1_0),
		mercury____Unify___trace__trace_info_0_0_i8,
		ENTRY(mercury____Unify___trace__trace_info_0_0));
Define_label(mercury____Unify___trace__trace_info_0_0_i3);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Unify___trace__trace_info_0_0_i1);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	r1 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 0), (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	call_localret(ENTRY(mercury____Unify___llds__lval_0_0),
		mercury____Unify___trace__trace_info_0_0_i6,
		ENTRY(mercury____Unify___trace__trace_info_0_0));
Define_label(mercury____Unify___trace__trace_info_0_0_i6);
	update_prof_current_proc(LABEL(mercury____Unify___trace__trace_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___trace__trace_info_0_0_i1);
	if ((MR_stackvar(1) != MR_stackvar(5)))
		GOTO_LABEL(mercury____Unify___trace__trace_info_0_0_i1);
	if ((MR_stackvar(2) != MR_stackvar(6)))
		GOTO_LABEL(mercury____Unify___trace__trace_info_0_0_i1);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(7);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_36);
	call_localret(ENTRY(mercury____Unify___std_util__maybe_1_0),
		mercury____Unify___trace__trace_info_0_0_i8,
		ENTRY(mercury____Unify___trace__trace_info_0_0));
Define_label(mercury____Unify___trace__trace_info_0_0_i8);
	update_prof_current_proc(LABEL(mercury____Unify___trace__trace_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___trace__trace_info_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(8);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	tailcall(ENTRY(mercury____Unify___std_util__maybe_1_0),
		ENTRY(mercury____Unify___trace__trace_info_0_0));
Define_label(mercury____Unify___trace__trace_info_0_0_i1013);
	r1 = FALSE;
	MR_decr_sp_pop_msg(9);
	proceed();
Define_label(mercury____Unify___trace__trace_info_0_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE


BEGIN_MODULE(trace_module36)
	init_entry(mercury____Index___trace__trace_info_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___trace__trace_info_0_0);
	tailcall(STATIC(mercury____Index___trace__trace_info_0__ua0_2_0),
		ENTRY(mercury____Index___trace__trace_info_0_0));
END_MODULE

Declare_entry(mercury____Compare___std_util__maybe_1_0);

BEGIN_MODULE(trace_module37)
	init_entry(mercury____Compare___trace__trace_info_0_0);
	init_label(mercury____Compare___trace__trace_info_0_0_i3);
	init_label(mercury____Compare___trace__trace_info_0_0_i7);
	init_label(mercury____Compare___trace__trace_info_0_0_i11);
	init_label(mercury____Compare___trace__trace_info_0_0_i15);
	init_label(mercury____Compare___trace__trace_info_0_0_i22);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___trace__trace_info_0_0);
	MR_incr_sp_push_msg(9, "trace:__Compare__/3");
	MR_stackvar(9) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(STATIC(mercury____Compare___trace__trace_type_0_0),
		mercury____Compare___trace__trace_info_0_0_i3,
		ENTRY(mercury____Compare___trace__trace_info_0_0));
Define_label(mercury____Compare___trace__trace_info_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___trace__trace_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___trace__trace_info_0_0_i22);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(5);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___trace__trace_info_0_0_i7,
		ENTRY(mercury____Compare___trace__trace_info_0_0));
Define_label(mercury____Compare___trace__trace_info_0_0_i7);
	update_prof_current_proc(LABEL(mercury____Compare___trace__trace_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___trace__trace_info_0_0_i22);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(6);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___trace__trace_info_0_0_i11,
		ENTRY(mercury____Compare___trace__trace_info_0_0));
Define_label(mercury____Compare___trace__trace_info_0_0_i11);
	update_prof_current_proc(LABEL(mercury____Compare___trace__trace_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___trace__trace_info_0_0_i22);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_36);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(7);
	call_localret(ENTRY(mercury____Compare___std_util__maybe_1_0),
		mercury____Compare___trace__trace_info_0_0_i15,
		ENTRY(mercury____Compare___trace__trace_info_0_0));
Define_label(mercury____Compare___trace__trace_info_0_0_i15);
	update_prof_current_proc(LABEL(mercury____Compare___trace__trace_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___trace__trace_info_0_0_i22);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(8);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	tailcall(ENTRY(mercury____Compare___std_util__maybe_1_0),
		ENTRY(mercury____Compare___trace__trace_info_0_0));
Define_label(mercury____Compare___trace__trace_info_0_0_i22);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE


BEGIN_MODULE(trace_module38)
	init_entry(mercury____Unify___trace__trace_slot_info_0_0);
	init_label(mercury____Unify___trace__trace_slot_info_0_0_i2);
	init_label(mercury____Unify___trace__trace_slot_info_0_0_i4);
	init_label(mercury____Unify___trace__trace_slot_info_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___trace__trace_slot_info_0_0);
	MR_incr_sp_push_msg(5, "trace:__Unify__/2");
	MR_stackvar(5) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury____Unify___std_util__maybe_1_0),
		mercury____Unify___trace__trace_slot_info_0_0_i2,
		ENTRY(mercury____Unify___trace__trace_slot_info_0_0));
Define_label(mercury____Unify___trace__trace_slot_info_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___trace__trace_slot_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___trace__trace_slot_info_0_0_i1);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury____Unify___std_util__maybe_1_0),
		mercury____Unify___trace__trace_slot_info_0_0_i4,
		ENTRY(mercury____Unify___trace__trace_slot_info_0_0));
Define_label(mercury____Unify___trace__trace_slot_info_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___trace__trace_slot_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___trace__trace_slot_info_0_0_i1);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury____Unify___std_util__maybe_1_0),
		ENTRY(mercury____Unify___trace__trace_slot_info_0_0));
Define_label(mercury____Unify___trace__trace_slot_info_0_0_i1);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(trace_module39)
	init_entry(mercury____Index___trace__trace_slot_info_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___trace__trace_slot_info_0_0);
	tailcall(STATIC(mercury____Index___trace__trace_slot_info_0__ua0_2_0),
		ENTRY(mercury____Index___trace__trace_slot_info_0_0));
END_MODULE


BEGIN_MODULE(trace_module40)
	init_entry(mercury____Compare___trace__trace_slot_info_0_0);
	init_label(mercury____Compare___trace__trace_slot_info_0_0_i3);
	init_label(mercury____Compare___trace__trace_slot_info_0_0_i7);
	init_label(mercury____Compare___trace__trace_slot_info_0_0_i12);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___trace__trace_slot_info_0_0);
	MR_incr_sp_push_msg(5, "trace:__Compare__/3");
	MR_stackvar(5) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury____Compare___std_util__maybe_1_0),
		mercury____Compare___trace__trace_slot_info_0_0_i3,
		ENTRY(mercury____Compare___trace__trace_slot_info_0_0));
Define_label(mercury____Compare___trace__trace_slot_info_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___trace__trace_slot_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___trace__trace_slot_info_0_0_i12);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury____Compare___std_util__maybe_1_0),
		mercury____Compare___trace__trace_slot_info_0_0_i7,
		ENTRY(mercury____Compare___trace__trace_slot_info_0_0));
Define_label(mercury____Compare___trace__trace_slot_info_0_0_i7);
	update_prof_current_proc(LABEL(mercury____Compare___trace__trace_slot_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___trace__trace_slot_info_0_0_i12);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury____Compare___std_util__maybe_1_0),
		ENTRY(mercury____Compare___trace__trace_slot_info_0_0));
Define_label(mercury____Compare___trace__trace_slot_info_0_0_i12);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE

Declare_entry(mercury____Unify___list__list_1_0);
Declare_entry(mercury____Unify___set__set_1_0);

BEGIN_MODULE(trace_module41)
	init_entry(mercury____Unify___trace__trace_port_info_0_0);
	init_label(mercury____Unify___trace__trace_port_info_0_0_i1011);
	init_label(mercury____Unify___trace__trace_port_info_0_0_i1010);
	init_label(mercury____Unify___trace__trace_port_info_0_0_i4);
	init_label(mercury____Unify___trace__trace_port_info_0_0_i6);
	init_label(mercury____Unify___trace__trace_port_info_0_0_i1012);
	init_label(mercury____Unify___trace__trace_port_info_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___trace__trace_port_info_0_0);
	MR_incr_sp_push_msg(3, "trace:__Unify__/2");
	MR_stackvar(3) = (Word) MR_succip;
	r3 = MR_tag(r1);
	if ((r3 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Unify___trace__trace_port_info_0_0_i4);
	if ((r3 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Unify___trace__trace_port_info_0_0_i1010);
	if (((Integer) MR_unmkbody(r1) != (Integer) 0))
		GOTO_LABEL(mercury____Unify___trace__trace_port_info_0_0_i1011);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Unify___trace__trace_port_info_0_0_i1012);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury____Unify___trace__trace_port_info_0_0_i1011);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))))
		GOTO_LABEL(mercury____Unify___trace__trace_port_info_0_0_i1);
	r1 = TRUE;
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury____Unify___trace__trace_port_info_0_0_i1010);
	if ((MR_tag(r2) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Unify___trace__trace_port_info_0_0_i1);
	r3 = MR_const_field(MR_mktag(2), r2, (Integer) 0);
	r2 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_hlds_goal__type_ctor_info_goal_path_step_0;
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury____Unify___list__list_1_0),
		STATIC(mercury____Unify___trace__trace_port_info_0_0));
Define_label(mercury____Unify___trace__trace_port_info_0_0_i4);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Unify___trace__trace_port_info_0_0_i1);
	r3 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_hlds_goal__type_ctor_info_goal_path_step_0;
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury____Unify___trace__trace_port_info_0_0_i6,
		STATIC(mercury____Unify___trace__trace_port_info_0_0));
Define_label(mercury____Unify___trace__trace_port_info_0_0_i6);
	update_prof_current_proc(LABEL(mercury____Unify___trace__trace_port_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___trace__trace_port_info_0_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_0);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury____Unify___set__set_1_0),
		STATIC(mercury____Unify___trace__trace_port_info_0_0));
Define_label(mercury____Unify___trace__trace_port_info_0_0_i1012);
	r1 = FALSE;
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury____Unify___trace__trace_port_info_0_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(trace_module42)
	init_entry(mercury____Index___trace__trace_port_info_0_0);
	init_label(mercury____Index___trace__trace_port_info_0_0_i6);
	init_label(mercury____Index___trace__trace_port_info_0_0_i5);
	init_label(mercury____Index___trace__trace_port_info_0_0_i4);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___trace__trace_port_info_0_0);
	r2 = MR_tag(r1);
	if ((r2 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Index___trace__trace_port_info_0_0_i4);
	if ((r2 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Index___trace__trace_port_info_0_0_i5);
	if (((Integer) MR_unmkbody(r1) != (Integer) 0))
		GOTO_LABEL(mercury____Index___trace__trace_port_info_0_0_i6);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Index___trace__trace_port_info_0_0_i6);
	r1 = (Integer) 3;
	proceed();
Define_label(mercury____Index___trace__trace_port_info_0_0_i5);
	r1 = (Integer) 2;
	proceed();
Define_label(mercury____Index___trace__trace_port_info_0_0_i4);
	r1 = (Integer) 1;
	proceed();
END_MODULE

Declare_entry(mercury____Compare___list__list_1_0);
Declare_entry(mercury____Compare___set__set_1_0);
Declare_entry(mercury__compare_error_0_0);

BEGIN_MODULE(trace_module43)
	init_entry(mercury____Compare___trace__trace_port_info_0_0);
	init_label(mercury____Compare___trace__trace_port_info_0_0_i6);
	init_label(mercury____Compare___trace__trace_port_info_0_0_i5);
	init_label(mercury____Compare___trace__trace_port_info_0_0_i4);
	init_label(mercury____Compare___trace__trace_port_info_0_0_i2);
	init_label(mercury____Compare___trace__trace_port_info_0_0_i11);
	init_label(mercury____Compare___trace__trace_port_info_0_0_i10);
	init_label(mercury____Compare___trace__trace_port_info_0_0_i9);
	init_label(mercury____Compare___trace__trace_port_info_0_0_i7);
	init_label(mercury____Compare___trace__trace_port_info_0_0_i12);
	init_label(mercury____Compare___trace__trace_port_info_0_0_i13);
	init_label(mercury____Compare___trace__trace_port_info_0_0_i29);
	init_label(mercury____Compare___trace__trace_port_info_0_0_i26);
	init_label(mercury____Compare___trace__trace_port_info_0_0_i18);
	init_label(mercury____Compare___trace__trace_port_info_0_0_i21);
	init_label(mercury____Compare___trace__trace_port_info_0_0_i1025);
	init_label(mercury____Compare___trace__trace_port_info_0_0_i35);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___trace__trace_port_info_0_0);
	r3 = MR_tag(r1);
	if ((r3 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___trace__trace_port_info_0_0_i4);
	if ((r3 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Compare___trace__trace_port_info_0_0_i5);
	if (((Integer) MR_unmkbody(r1) != (Integer) 0))
		GOTO_LABEL(mercury____Compare___trace__trace_port_info_0_0_i6);
	r3 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___trace__trace_port_info_0_0_i2);
Define_label(mercury____Compare___trace__trace_port_info_0_0_i6);
	r3 = (Integer) 3;
	GOTO_LABEL(mercury____Compare___trace__trace_port_info_0_0_i2);
Define_label(mercury____Compare___trace__trace_port_info_0_0_i5);
	r3 = (Integer) 2;
	GOTO_LABEL(mercury____Compare___trace__trace_port_info_0_0_i2);
Define_label(mercury____Compare___trace__trace_port_info_0_0_i4);
	r3 = (Integer) 1;
Define_label(mercury____Compare___trace__trace_port_info_0_0_i2);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_tag(r2);
	if ((MR_tempr1 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___trace__trace_port_info_0_0_i9);
	if ((MR_tempr1 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Compare___trace__trace_port_info_0_0_i10);
	if (((Integer) MR_unmkbody(r2) != (Integer) 0))
		GOTO_LABEL(mercury____Compare___trace__trace_port_info_0_0_i11);
	r4 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___trace__trace_port_info_0_0_i7);
	}
Define_label(mercury____Compare___trace__trace_port_info_0_0_i11);
	r4 = (Integer) 3;
	GOTO_LABEL(mercury____Compare___trace__trace_port_info_0_0_i7);
Define_label(mercury____Compare___trace__trace_port_info_0_0_i10);
	r4 = (Integer) 2;
	GOTO_LABEL(mercury____Compare___trace__trace_port_info_0_0_i7);
Define_label(mercury____Compare___trace__trace_port_info_0_0_i9);
	r4 = (Integer) 1;
Define_label(mercury____Compare___trace__trace_port_info_0_0_i7);
	if (((Integer) r3 >= (Integer) r4))
		GOTO_LABEL(mercury____Compare___trace__trace_port_info_0_0_i12);
	r1 = (Integer) 1;
	proceed();
Define_label(mercury____Compare___trace__trace_port_info_0_0_i12);
	if (((Integer) r3 <= (Integer) r4))
		GOTO_LABEL(mercury____Compare___trace__trace_port_info_0_0_i13);
	r1 = (Integer) 2;
	proceed();
Define_label(mercury____Compare___trace__trace_port_info_0_0_i13);
	r3 = MR_tag(r1);
	if ((r3 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___trace__trace_port_info_0_0_i18);
	if ((r3 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Compare___trace__trace_port_info_0_0_i26);
	if (((Integer) MR_unmkbody(r1) != (Integer) 0))
		GOTO_LABEL(mercury____Compare___trace__trace_port_info_0_0_i29);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___trace__trace_port_info_0_0_i1025);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Compare___trace__trace_port_info_0_0_i29);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))))
		GOTO_LABEL(mercury____Compare___trace__trace_port_info_0_0_i1025);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Compare___trace__trace_port_info_0_0_i26);
	if ((MR_tag(r2) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Compare___trace__trace_port_info_0_0_i1025);
	r3 = MR_const_field(MR_mktag(2), r2, (Integer) 0);
	r2 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_hlds_goal__type_ctor_info_goal_path_step_0;
	tailcall(ENTRY(mercury____Compare___list__list_1_0),
		STATIC(mercury____Compare___trace__trace_port_info_0_0));
Define_label(mercury____Compare___trace__trace_port_info_0_0_i18);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___trace__trace_port_info_0_0_i1025);
	MR_incr_sp_push_msg(3, "trace:__Compare__/3");
	MR_stackvar(3) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_hlds_goal__type_ctor_info_goal_path_step_0;
	call_localret(ENTRY(mercury____Compare___list__list_1_0),
		mercury____Compare___trace__trace_port_info_0_0_i21,
		STATIC(mercury____Compare___trace__trace_port_info_0_0));
Define_label(mercury____Compare___trace__trace_port_info_0_0_i21);
	update_prof_current_proc(LABEL(mercury____Compare___trace__trace_port_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___trace__trace_port_info_0_0_i35);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_trace__common_0);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury____Compare___set__set_1_0),
		STATIC(mercury____Compare___trace__trace_port_info_0_0));
Define_label(mercury____Compare___trace__trace_port_info_0_0_i1025);
	tailcall(ENTRY(mercury__compare_error_0_0),
		STATIC(mercury____Compare___trace__trace_port_info_0_0));
Define_label(mercury____Compare___trace__trace_port_info_0_0_i35);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(trace_module44)
	init_entry(mercury____Unify___trace__trace_type_0_0);
	init_label(mercury____Unify___trace__trace_type_0_0_i3);
	init_label(mercury____Unify___trace__trace_type_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___trace__trace_type_0_0);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Unify___trace__trace_type_0_0_i3);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Unify___trace__trace_type_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___trace__trace_type_0_0_i3);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Unify___trace__trace_type_0_0_i1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	tailcall(ENTRY(mercury____Unify___llds__lval_0_0),
		STATIC(mercury____Unify___trace__trace_type_0_0));
Define_label(mercury____Unify___trace__trace_type_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(trace_module45)
	init_entry(mercury____Index___trace__trace_type_0_0);
	init_label(mercury____Index___trace__trace_type_0_0_i3);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___trace__trace_type_0_0);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Index___trace__trace_type_0_0_i3);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Index___trace__trace_type_0_0_i3);
	r1 = (Integer) 1;
	proceed();
END_MODULE

Declare_entry(mercury____Compare___llds__lval_0_0);

BEGIN_MODULE(trace_module46)
	init_entry(mercury____Compare___trace__trace_type_0_0);
	init_label(mercury____Compare___trace__trace_type_0_0_i3);
	init_label(mercury____Compare___trace__trace_type_0_0_i2);
	init_label(mercury____Compare___trace__trace_type_0_0_i5);
	init_label(mercury____Compare___trace__trace_type_0_0_i4);
	init_label(mercury____Compare___trace__trace_type_0_0_i6);
	init_label(mercury____Compare___trace__trace_type_0_0_i7);
	init_label(mercury____Compare___trace__trace_type_0_0_i11);
	init_label(mercury____Compare___trace__trace_type_0_0_i1014);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___trace__trace_type_0_0);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___trace__trace_type_0_0_i3);
	r3 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___trace__trace_type_0_0_i2);
Define_label(mercury____Compare___trace__trace_type_0_0_i3);
	r3 = (Integer) 1;
Define_label(mercury____Compare___trace__trace_type_0_0_i2);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___trace__trace_type_0_0_i5);
	r4 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___trace__trace_type_0_0_i4);
Define_label(mercury____Compare___trace__trace_type_0_0_i5);
	r4 = (Integer) 1;
Define_label(mercury____Compare___trace__trace_type_0_0_i4);
	if (((Integer) r3 >= (Integer) r4))
		GOTO_LABEL(mercury____Compare___trace__trace_type_0_0_i6);
	r1 = (Integer) 1;
	proceed();
Define_label(mercury____Compare___trace__trace_type_0_0_i6);
	if (((Integer) r3 <= (Integer) r4))
		GOTO_LABEL(mercury____Compare___trace__trace_type_0_0_i7);
	r1 = (Integer) 2;
	proceed();
Define_label(mercury____Compare___trace__trace_type_0_0_i7);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___trace__trace_type_0_0_i11);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___trace__trace_type_0_0_i1014);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Compare___trace__trace_type_0_0_i11);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___trace__trace_type_0_0_i1014);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	tailcall(ENTRY(mercury____Compare___llds__lval_0_0),
		STATIC(mercury____Compare___trace__trace_type_0_0));
Define_label(mercury____Compare___trace__trace_type_0_0_i1014);
	tailcall(ENTRY(mercury__compare_error_0_0),
		STATIC(mercury____Compare___trace__trace_type_0_0));
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__trace_maybe_bunch_0(void)
{
	trace_module0();
	trace_module1();
	trace_module2();
	trace_module3();
	trace_module4();
	trace_module5();
	trace_module6();
	trace_module7();
	trace_module8();
	trace_module9();
	trace_module10();
	trace_module11();
	trace_module12();
	trace_module13();
	trace_module14();
	trace_module15();
	trace_module16();
	trace_module17();
	trace_module18();
	trace_module19();
	trace_module20();
	trace_module21();
	trace_module22();
	trace_module23();
	trace_module24();
	trace_module25();
	trace_module26();
	trace_module27();
	trace_module28();
	trace_module29();
	trace_module30();
	trace_module31();
	trace_module32();
	trace_module33();
	trace_module34();
	trace_module35();
	trace_module36();
	trace_module37();
	trace_module38();
	trace_module39();
}

static void mercury__trace_maybe_bunch_1(void)
{
	trace_module40();
	trace_module41();
	trace_module42();
	trace_module43();
	trace_module44();
	trace_module45();
	trace_module46();
}

#endif

void mercury__trace__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__trace__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__trace_maybe_bunch_0();
		mercury__trace_maybe_bunch_1();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_trace__type_ctor_info_external_trace_port_0,
			trace__external_trace_port_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_trace__type_ctor_info_negation_end_port_0,
			trace__negation_end_port_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_trace__type_ctor_info_nondet_pragma_trace_port_0,
			trace__nondet_pragma_trace_port_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_trace__type_ctor_info_trace_info_0,
			trace__trace_info_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_trace__type_ctor_info_trace_port_info_0,
			trace__trace_port_info_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_trace__type_ctor_info_trace_slot_info_0,
			trace__trace_slot_info_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_trace__type_ctor_info_trace_type_0,
			trace__trace_type_0_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
