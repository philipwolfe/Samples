/*
** Automatically generated from `trans_opt.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__trans_opt__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury__trans_opt__write_procs__ua0_5_0);
Declare_label(mercury__trans_opt__write_procs__ua0_5_0_i1001);
Declare_label(mercury__trans_opt__write_procs__ua0_5_0_i4);
Declare_label(mercury__trans_opt__write_procs__ua0_5_0_i5);
Declare_label(mercury__trans_opt__write_procs__ua0_5_0_i6);
Declare_label(mercury__trans_opt__write_procs__ua0_5_0_i7);
Declare_label(mercury__trans_opt__write_procs__ua0_5_0_i8);
Declare_label(mercury__trans_opt__write_procs__ua0_5_0_i9);
Declare_label(mercury__trans_opt__write_procs__ua0_5_0_i10);
Declare_label(mercury__trans_opt__write_procs__ua0_5_0_i11);
Declare_label(mercury__trans_opt__write_procs__ua0_5_0_i12);
Declare_label(mercury__trans_opt__write_procs__ua0_5_0_i13);
Declare_label(mercury__trans_opt__write_procs__ua0_5_0_i3);
Define_extern_entry(mercury__trans_opt__write_optfile_3_0);
Declare_label(mercury__trans_opt__write_optfile_3_0_i2);
Declare_label(mercury__trans_opt__write_optfile_3_0_i3);
Declare_label(mercury__trans_opt__write_optfile_3_0_i4);
Declare_label(mercury__trans_opt__write_optfile_3_0_i7);
Declare_label(mercury__trans_opt__write_optfile_3_0_i8);
Declare_label(mercury__trans_opt__write_optfile_3_0_i9);
Declare_label(mercury__trans_opt__write_optfile_3_0_i10);
Declare_label(mercury__trans_opt__write_optfile_3_0_i11);
Declare_label(mercury__trans_opt__write_optfile_3_0_i12);
Declare_label(mercury__trans_opt__write_optfile_3_0_i13);
Declare_label(mercury__trans_opt__write_optfile_3_0_i14);
Declare_label(mercury__trans_opt__write_optfile_3_0_i15);
Declare_label(mercury__trans_opt__write_optfile_3_0_i16);
Declare_label(mercury__trans_opt__write_optfile_3_0_i17);
Declare_label(mercury__trans_opt__write_optfile_3_0_i6);
Declare_label(mercury__trans_opt__write_optfile_3_0_i19);
Declare_label(mercury__trans_opt__write_optfile_3_0_i20);
Declare_label(mercury__trans_opt__write_optfile_3_0_i21);
Declare_label(mercury__trans_opt__write_optfile_3_0_i22);
Declare_label(mercury__trans_opt__write_optfile_3_0_i23);
Declare_label(mercury__trans_opt__write_optfile_3_0_i24);
Declare_label(mercury__trans_opt__write_optfile_3_0_i25);
Declare_label(mercury__trans_opt__write_optfile_3_0_i26);
Declare_label(mercury__trans_opt__write_optfile_3_0_i27);
Declare_label(mercury__trans_opt__write_optfile_3_0_i28);
Define_extern_entry(mercury__trans_opt__grab_optfiles_6_0);
Declare_label(mercury__trans_opt__grab_optfiles_6_0_i2);
Declare_label(mercury__trans_opt__grab_optfiles_6_0_i3);
Declare_label(mercury__trans_opt__grab_optfiles_6_0_i4);
Declare_label(mercury__trans_opt__grab_optfiles_6_0_i5);
Declare_label(mercury__trans_opt__grab_optfiles_6_0_i6);
Declare_label(mercury__trans_opt__grab_optfiles_6_0_i7);
Declare_label(mercury__trans_opt__grab_optfiles_6_0_i8);
Declare_label(mercury__trans_opt__grab_optfiles_6_0_i9);
Declare_label(mercury__trans_opt__grab_optfiles_6_0_i10);
Declare_label(mercury__trans_opt__grab_optfiles_6_0_i11);
Declare_static(mercury__trans_opt__write_preds_4_0);
Declare_label(mercury__trans_opt__write_preds_4_0_i1005);
Declare_label(mercury__trans_opt__write_preds_4_0_i4);
Declare_label(mercury__trans_opt__write_preds_4_0_i5);
Declare_label(mercury__trans_opt__write_preds_4_0_i6);
Declare_label(mercury__trans_opt__write_preds_4_0_i8);
Declare_label(mercury__trans_opt__write_preds_4_0_i12);
Declare_label(mercury__trans_opt__write_preds_4_0_i16);
Declare_label(mercury__trans_opt__write_preds_4_0_i19);
Declare_label(mercury__trans_opt__write_preds_4_0_i21);
Declare_label(mercury__trans_opt__write_preds_4_0_i22);
Declare_label(mercury__trans_opt__write_preds_4_0_i23);
Declare_label(mercury__trans_opt__write_preds_4_0_i7);
Declare_label(mercury__trans_opt__write_preds_4_0_i3);
Declare_static(mercury__trans_opt__read_trans_opt_files_7_0);
Declare_label(mercury__trans_opt__read_trans_opt_files_7_0_i1001);
Declare_label(mercury__trans_opt__read_trans_opt_files_7_0_i4);
Declare_label(mercury__trans_opt__read_trans_opt_files_7_0_i5);
Declare_label(mercury__trans_opt__read_trans_opt_files_7_0_i6);
Declare_label(mercury__trans_opt__read_trans_opt_files_7_0_i7);
Declare_label(mercury__trans_opt__read_trans_opt_files_7_0_i8);
Declare_label(mercury__trans_opt__read_trans_opt_files_7_0_i9);
Declare_label(mercury__trans_opt__read_trans_opt_files_7_0_i10);
Declare_label(mercury__trans_opt__read_trans_opt_files_7_0_i11);
Declare_label(mercury__trans_opt__read_trans_opt_files_7_0_i12);
Declare_label(mercury__trans_opt__read_trans_opt_files_7_0_i13);
Declare_label(mercury__trans_opt__read_trans_opt_files_7_0_i14);
Declare_label(mercury__trans_opt__read_trans_opt_files_7_0_i15);
Declare_label(mercury__trans_opt__read_trans_opt_files_7_0_i3);

static const struct mercury_data_trans_opt__common_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_trans_opt__common_0;

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_pair_2;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_item_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_context_0;
static const struct mercury_data_trans_opt__common_0_struct mercury_data_trans_opt__common_0 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_prog_data__type_ctor_info_item_0,
	(Word *) &mercury_data_term__type_ctor_info_context_0
};

Declare_entry(mercury__hlds_pred__pred_info_procedures_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_proc_id_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_proc_info_0;
Declare_entry(mercury__map__lookup_3_0);
Declare_entry(mercury__hlds_pred__pred_info_name_2_0);
Declare_entry(mercury__hlds_pred__pred_info_module_2_0);
Declare_entry(mercury__hlds_pred__pred_info_get_is_pred_or_func_2_0);
Declare_entry(mercury__hlds_pred__pred_info_context_2_0);
Declare_entry(mercury__hlds_pred__proc_info_get_maybe_arg_size_info_2_0);
Declare_entry(mercury__hlds_pred__proc_info_get_maybe_termination_info_2_0);
Declare_entry(mercury__hlds_pred__proc_info_declared_argmodes_2_0);
Declare_entry(mercury__termination__write_pragma_termination_info_8_0);

BEGIN_MODULE(trans_opt_module0)
	init_entry(mercury__trans_opt__write_procs__ua0_5_0);
	init_label(mercury__trans_opt__write_procs__ua0_5_0_i1001);
	init_label(mercury__trans_opt__write_procs__ua0_5_0_i4);
	init_label(mercury__trans_opt__write_procs__ua0_5_0_i5);
	init_label(mercury__trans_opt__write_procs__ua0_5_0_i6);
	init_label(mercury__trans_opt__write_procs__ua0_5_0_i7);
	init_label(mercury__trans_opt__write_procs__ua0_5_0_i8);
	init_label(mercury__trans_opt__write_procs__ua0_5_0_i9);
	init_label(mercury__trans_opt__write_procs__ua0_5_0_i10);
	init_label(mercury__trans_opt__write_procs__ua0_5_0_i11);
	init_label(mercury__trans_opt__write_procs__ua0_5_0_i12);
	init_label(mercury__trans_opt__write_procs__ua0_5_0_i13);
	init_label(mercury__trans_opt__write_procs__ua0_5_0_i3);
BEGIN_CODE

/* code for predicate 'write_procs__ua0'/5 in mode 0 */
Define_static(mercury__trans_opt__write_procs__ua0_5_0);
	MR_incr_sp_push_msg(9, "trans_opt:write_procs__ua0/5");
	MR_stackvar(9) = (Word) MR_succip;
Define_label(mercury__trans_opt__write_procs__ua0_5_0_i1001);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__trans_opt__write_procs__ua0_5_0_i3);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = r2;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procedures_2_0),
		mercury__trans_opt__write_procs__ua0_5_0_i4,
		STATIC(mercury__trans_opt__write_procs__ua0_5_0));
Define_label(mercury__trans_opt__write_procs__ua0_5_0_i4);
	update_prof_current_proc(LABEL(mercury__trans_opt__write_procs__ua0_5_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0;
	r4 = MR_stackvar(3);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__trans_opt__write_procs__ua0_5_0_i5,
		STATIC(mercury__trans_opt__write_procs__ua0_5_0));
Define_label(mercury__trans_opt__write_procs__ua0_5_0_i5);
	update_prof_current_proc(LABEL(mercury__trans_opt__write_procs__ua0_5_0));
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_name_2_0),
		mercury__trans_opt__write_procs__ua0_5_0_i6,
		STATIC(mercury__trans_opt__write_procs__ua0_5_0));
Define_label(mercury__trans_opt__write_procs__ua0_5_0_i6);
	update_prof_current_proc(LABEL(mercury__trans_opt__write_procs__ua0_5_0));
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_module_2_0),
		mercury__trans_opt__write_procs__ua0_5_0_i7,
		STATIC(mercury__trans_opt__write_procs__ua0_5_0));
Define_label(mercury__trans_opt__write_procs__ua0_5_0_i7);
	update_prof_current_proc(LABEL(mercury__trans_opt__write_procs__ua0_5_0));
	MR_stackvar(6) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_get_is_pred_or_func_2_0),
		mercury__trans_opt__write_procs__ua0_5_0_i8,
		STATIC(mercury__trans_opt__write_procs__ua0_5_0));
Define_label(mercury__trans_opt__write_procs__ua0_5_0_i8);
	update_prof_current_proc(LABEL(mercury__trans_opt__write_procs__ua0_5_0));
	MR_stackvar(7) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_context_2_0),
		mercury__trans_opt__write_procs__ua0_5_0_i9,
		STATIC(mercury__trans_opt__write_procs__ua0_5_0));
Define_label(mercury__trans_opt__write_procs__ua0_5_0_i9);
	update_prof_current_proc(LABEL(mercury__trans_opt__write_procs__ua0_5_0));
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__trans_opt__write_procs__ua0_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_stackvar(5);
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(6);
	MR_stackvar(5) = r1;
	MR_stackvar(6) = r2;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_get_maybe_arg_size_info_2_0),
		mercury__trans_opt__write_procs__ua0_5_0_i10,
		STATIC(mercury__trans_opt__write_procs__ua0_5_0));
Define_label(mercury__trans_opt__write_procs__ua0_5_0_i10);
	update_prof_current_proc(LABEL(mercury__trans_opt__write_procs__ua0_5_0));
	MR_stackvar(8) = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_get_maybe_termination_info_2_0),
		mercury__trans_opt__write_procs__ua0_5_0_i11,
		STATIC(mercury__trans_opt__write_procs__ua0_5_0));
Define_label(mercury__trans_opt__write_procs__ua0_5_0_i11);
	update_prof_current_proc(LABEL(mercury__trans_opt__write_procs__ua0_5_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	MR_stackvar(3) = r2;
	call_localret(ENTRY(mercury__hlds_pred__proc_info_declared_argmodes_2_0),
		mercury__trans_opt__write_procs__ua0_5_0_i12,
		STATIC(mercury__trans_opt__write_procs__ua0_5_0));
Define_label(mercury__trans_opt__write_procs__ua0_5_0_i12);
	update_prof_current_proc(LABEL(mercury__trans_opt__write_procs__ua0_5_0));
	r3 = r1;
	r1 = MR_stackvar(7);
	r2 = MR_stackvar(6);
	r4 = MR_stackvar(5);
	r5 = MR_stackvar(8);
	r6 = MR_stackvar(3);
	r7 = MR_stackvar(2);
	call_localret(ENTRY(mercury__termination__write_pragma_termination_info_8_0),
		mercury__trans_opt__write_procs__ua0_5_0_i13,
		STATIC(mercury__trans_opt__write_procs__ua0_5_0));
Define_label(mercury__trans_opt__write_procs__ua0_5_0_i13);
	update_prof_current_proc(LABEL(mercury__trans_opt__write_procs__ua0_5_0));
	r3 = r1;
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(9);
	GOTO_LABEL(mercury__trans_opt__write_procs__ua0_5_0_i1001);
Define_label(mercury__trans_opt__write_procs__ua0_5_0_i3);
	r1 = r3;
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_module__module_info_name_2_0);
Declare_entry(mercury__modules__module_name_to_file_name_6_0);
Declare_entry(mercury__io__open_output_4_0);
Declare_entry(mercury__io__set_output_stream_4_0);
Declare_entry(mercury__io__write_string_3_0);
Declare_entry(mercury__mercury_to_mercury__mercury_output_bracketed_sym_name_3_0);
Declare_entry(mercury__hlds_module__module_info_predids_2_0);
Declare_entry(mercury__io__close_output_3_0);
Declare_entry(mercury__modules__update_interface_3_0);
Declare_entry(mercury__modules__touch_interface_datestamp_4_0);
Declare_entry(mercury__io__error_message_2_0);
Declare_entry(mercury__io__progname_base_4_0);
Declare_entry(mercury__io__nl_2_0);
Declare_entry(mercury__io__set_exit_status_3_0);

BEGIN_MODULE(trans_opt_module1)
	init_entry(mercury__trans_opt__write_optfile_3_0);
	init_label(mercury__trans_opt__write_optfile_3_0_i2);
	init_label(mercury__trans_opt__write_optfile_3_0_i3);
	init_label(mercury__trans_opt__write_optfile_3_0_i4);
	init_label(mercury__trans_opt__write_optfile_3_0_i7);
	init_label(mercury__trans_opt__write_optfile_3_0_i8);
	init_label(mercury__trans_opt__write_optfile_3_0_i9);
	init_label(mercury__trans_opt__write_optfile_3_0_i10);
	init_label(mercury__trans_opt__write_optfile_3_0_i11);
	init_label(mercury__trans_opt__write_optfile_3_0_i12);
	init_label(mercury__trans_opt__write_optfile_3_0_i13);
	init_label(mercury__trans_opt__write_optfile_3_0_i14);
	init_label(mercury__trans_opt__write_optfile_3_0_i15);
	init_label(mercury__trans_opt__write_optfile_3_0_i16);
	init_label(mercury__trans_opt__write_optfile_3_0_i17);
	init_label(mercury__trans_opt__write_optfile_3_0_i6);
	init_label(mercury__trans_opt__write_optfile_3_0_i19);
	init_label(mercury__trans_opt__write_optfile_3_0_i20);
	init_label(mercury__trans_opt__write_optfile_3_0_i21);
	init_label(mercury__trans_opt__write_optfile_3_0_i22);
	init_label(mercury__trans_opt__write_optfile_3_0_i23);
	init_label(mercury__trans_opt__write_optfile_3_0_i24);
	init_label(mercury__trans_opt__write_optfile_3_0_i25);
	init_label(mercury__trans_opt__write_optfile_3_0_i26);
	init_label(mercury__trans_opt__write_optfile_3_0_i27);
	init_label(mercury__trans_opt__write_optfile_3_0_i28);
BEGIN_CODE

/* code for predicate 'write_optfile'/3 in mode 0 */
Define_entry(mercury__trans_opt__write_optfile_3_0);
	MR_incr_sp_push_msg(6, "trans_opt:write_optfile/3");
	MR_stackvar(6) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__hlds_module__module_info_name_2_0),
		mercury__trans_opt__write_optfile_3_0_i2,
		ENTRY(mercury__trans_opt__write_optfile_3_0));
Define_label(mercury__trans_opt__write_optfile_3_0_i2);
	update_prof_current_proc(LABEL(mercury__trans_opt__write_optfile_3_0));
	r4 = MR_stackvar(2);
	r2 = (Word) MR_string_const(".trans_opt.tmp", 14);
	r3 = (Integer) 1;
	MR_stackvar(2) = r1;
	call_localret(ENTRY(mercury__modules__module_name_to_file_name_6_0),
		mercury__trans_opt__write_optfile_3_0_i3,
		ENTRY(mercury__trans_opt__write_optfile_3_0));
Define_label(mercury__trans_opt__write_optfile_3_0_i3);
	update_prof_current_proc(LABEL(mercury__trans_opt__write_optfile_3_0));
	MR_stackvar(3) = r1;
	call_localret(ENTRY(mercury__io__open_output_4_0),
		mercury__trans_opt__write_optfile_3_0_i4,
		ENTRY(mercury__trans_opt__write_optfile_3_0));
Define_label(mercury__trans_opt__write_optfile_3_0_i4);
	update_prof_current_proc(LABEL(mercury__trans_opt__write_optfile_3_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__trans_opt__write_optfile_3_0_i6);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(3) = r1;
	call_localret(ENTRY(mercury__io__set_output_stream_4_0),
		mercury__trans_opt__write_optfile_3_0_i7,
		ENTRY(mercury__trans_opt__write_optfile_3_0));
Define_label(mercury__trans_opt__write_optfile_3_0_i7);
	update_prof_current_proc(LABEL(mercury__trans_opt__write_optfile_3_0));
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(5) = r2;
	call_localret(ENTRY(mercury__hlds_module__module_info_name_2_0),
		mercury__trans_opt__write_optfile_3_0_i8,
		ENTRY(mercury__trans_opt__write_optfile_3_0));
Define_label(mercury__trans_opt__write_optfile_3_0_i8);
	update_prof_current_proc(LABEL(mercury__trans_opt__write_optfile_3_0));
	r2 = MR_stackvar(5);
	MR_stackvar(5) = r1;
	r1 = (Word) MR_string_const(":- module ", 10);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__trans_opt__write_optfile_3_0_i9,
		ENTRY(mercury__trans_opt__write_optfile_3_0));
Define_label(mercury__trans_opt__write_optfile_3_0_i9);
	update_prof_current_proc(LABEL(mercury__trans_opt__write_optfile_3_0));
	r2 = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__mercury_to_mercury__mercury_output_bracketed_sym_name_3_0),
		mercury__trans_opt__write_optfile_3_0_i10,
		ENTRY(mercury__trans_opt__write_optfile_3_0));
Define_label(mercury__trans_opt__write_optfile_3_0_i10);
	update_prof_current_proc(LABEL(mercury__trans_opt__write_optfile_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const(".\n", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__trans_opt__write_optfile_3_0_i11,
		ENTRY(mercury__trans_opt__write_optfile_3_0));
Define_label(mercury__trans_opt__write_optfile_3_0_i11);
	update_prof_current_proc(LABEL(mercury__trans_opt__write_optfile_3_0));
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_module__module_info_predids_2_0),
		mercury__trans_opt__write_optfile_3_0_i12,
		ENTRY(mercury__trans_opt__write_optfile_3_0));
Define_label(mercury__trans_opt__write_optfile_3_0_i12);
	update_prof_current_proc(LABEL(mercury__trans_opt__write_optfile_3_0));
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(5);
	call_localret(STATIC(mercury__trans_opt__write_preds_4_0),
		mercury__trans_opt__write_optfile_3_0_i13,
		ENTRY(mercury__trans_opt__write_optfile_3_0));
Define_label(mercury__trans_opt__write_optfile_3_0_i13);
	update_prof_current_proc(LABEL(mercury__trans_opt__write_optfile_3_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__io__set_output_stream_4_0),
		mercury__trans_opt__write_optfile_3_0_i14,
		ENTRY(mercury__trans_opt__write_optfile_3_0));
Define_label(mercury__trans_opt__write_optfile_3_0_i14);
	update_prof_current_proc(LABEL(mercury__trans_opt__write_optfile_3_0));
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__io__close_output_3_0),
		mercury__trans_opt__write_optfile_3_0_i15,
		ENTRY(mercury__trans_opt__write_optfile_3_0));
Define_label(mercury__trans_opt__write_optfile_3_0_i15);
	update_prof_current_proc(LABEL(mercury__trans_opt__write_optfile_3_0));
	r4 = r1;
	r1 = MR_stackvar(2);
	r2 = (Word) MR_string_const(".trans_opt", 10);
	r3 = (Integer) 0;
	call_localret(ENTRY(mercury__modules__module_name_to_file_name_6_0),
		mercury__trans_opt__write_optfile_3_0_i16,
		ENTRY(mercury__trans_opt__write_optfile_3_0));
Define_label(mercury__trans_opt__write_optfile_3_0_i16);
	update_prof_current_proc(LABEL(mercury__trans_opt__write_optfile_3_0));
	call_localret(ENTRY(mercury__modules__update_interface_3_0),
		mercury__trans_opt__write_optfile_3_0_i17,
		ENTRY(mercury__trans_opt__write_optfile_3_0));
Define_label(mercury__trans_opt__write_optfile_3_0_i17);
	update_prof_current_proc(LABEL(mercury__trans_opt__write_optfile_3_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	r2 = (Word) MR_string_const(".trans_opt_date", 15);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(ENTRY(mercury__modules__touch_interface_datestamp_4_0),
		ENTRY(mercury__trans_opt__write_optfile_3_0));
Define_label(mercury__trans_opt__write_optfile_3_0_i6);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__io__error_message_2_0),
		mercury__trans_opt__write_optfile_3_0_i19,
		ENTRY(mercury__trans_opt__write_optfile_3_0));
Define_label(mercury__trans_opt__write_optfile_3_0_i19);
	update_prof_current_proc(LABEL(mercury__trans_opt__write_optfile_3_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) MR_string_const("trans_opt.m", 11);
	call_localret(ENTRY(mercury__io__progname_base_4_0),
		mercury__trans_opt__write_optfile_3_0_i20,
		ENTRY(mercury__trans_opt__write_optfile_3_0));
Define_label(mercury__trans_opt__write_optfile_3_0_i20);
	update_prof_current_proc(LABEL(mercury__trans_opt__write_optfile_3_0));
	MR_stackvar(2) = r1;
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__trans_opt__write_optfile_3_0_i21,
		ENTRY(mercury__trans_opt__write_optfile_3_0));
Define_label(mercury__trans_opt__write_optfile_3_0_i21);
	update_prof_current_proc(LABEL(mercury__trans_opt__write_optfile_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const(": cannot open transitive optimisation file `", 44);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__trans_opt__write_optfile_3_0_i22,
		ENTRY(mercury__trans_opt__write_optfile_3_0));
Define_label(mercury__trans_opt__write_optfile_3_0_i22);
	update_prof_current_proc(LABEL(mercury__trans_opt__write_optfile_3_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__trans_opt__write_optfile_3_0_i23,
		ENTRY(mercury__trans_opt__write_optfile_3_0));
Define_label(mercury__trans_opt__write_optfile_3_0_i23);
	update_prof_current_proc(LABEL(mercury__trans_opt__write_optfile_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const("' \n", 3);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__trans_opt__write_optfile_3_0_i24,
		ENTRY(mercury__trans_opt__write_optfile_3_0));
Define_label(mercury__trans_opt__write_optfile_3_0_i24);
	update_prof_current_proc(LABEL(mercury__trans_opt__write_optfile_3_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__trans_opt__write_optfile_3_0_i25,
		ENTRY(mercury__trans_opt__write_optfile_3_0));
Define_label(mercury__trans_opt__write_optfile_3_0_i25);
	update_prof_current_proc(LABEL(mercury__trans_opt__write_optfile_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const(": for output: ", 14);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__trans_opt__write_optfile_3_0_i26,
		ENTRY(mercury__trans_opt__write_optfile_3_0));
Define_label(mercury__trans_opt__write_optfile_3_0_i26);
	update_prof_current_proc(LABEL(mercury__trans_opt__write_optfile_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__trans_opt__write_optfile_3_0_i27,
		ENTRY(mercury__trans_opt__write_optfile_3_0));
Define_label(mercury__trans_opt__write_optfile_3_0_i27);
	update_prof_current_proc(LABEL(mercury__trans_opt__write_optfile_3_0));
	call_localret(ENTRY(mercury__io__nl_2_0),
		mercury__trans_opt__write_optfile_3_0_i28,
		ENTRY(mercury__trans_opt__write_optfile_3_0));
Define_label(mercury__trans_opt__write_optfile_3_0_i28);
	update_prof_current_proc(LABEL(mercury__trans_opt__write_optfile_3_0));
	r2 = r1;
	r1 = (Integer) 1;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(ENTRY(mercury__io__set_exit_status_3_0),
		ENTRY(mercury__trans_opt__write_optfile_3_0));
END_MODULE

Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
Declare_entry(mercury__passes_aux__maybe_write_string_4_0);
Declare_entry(mercury__passes_aux__maybe_flush_output_3_0);
Declare_entry(mercury__modules__append_pseudo_decl_3_0);
Declare_entry(mercury__modules__module_imports_get_items_2_0);
Declare_entry(mercury__list__append_3_1);
Declare_entry(mercury__modules__module_imports_set_items_3_0);
Declare_entry(mercury__modules__module_imports_set_error_3_0);

BEGIN_MODULE(trans_opt_module2)
	init_entry(mercury__trans_opt__grab_optfiles_6_0);
	init_label(mercury__trans_opt__grab_optfiles_6_0_i2);
	init_label(mercury__trans_opt__grab_optfiles_6_0_i3);
	init_label(mercury__trans_opt__grab_optfiles_6_0_i4);
	init_label(mercury__trans_opt__grab_optfiles_6_0_i5);
	init_label(mercury__trans_opt__grab_optfiles_6_0_i6);
	init_label(mercury__trans_opt__grab_optfiles_6_0_i7);
	init_label(mercury__trans_opt__grab_optfiles_6_0_i8);
	init_label(mercury__trans_opt__grab_optfiles_6_0_i9);
	init_label(mercury__trans_opt__grab_optfiles_6_0_i10);
	init_label(mercury__trans_opt__grab_optfiles_6_0_i11);
BEGIN_CODE

/* code for predicate 'grab_optfiles'/6 in mode 0 */
Define_entry(mercury__trans_opt__grab_optfiles_6_0);
	MR_incr_sp_push_msg(6, "trans_opt:grab_optfiles/6");
	MR_stackvar(6) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Integer) 17;
	r2 = r3;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__trans_opt__grab_optfiles_6_0_i2,
		ENTRY(mercury__trans_opt__grab_optfiles_6_0));
Define_label(mercury__trans_opt__grab_optfiles_6_0_i2);
	update_prof_current_proc(LABEL(mercury__trans_opt__grab_optfiles_6_0));
	MR_stackvar(3) = r1;
	r3 = r2;
	r2 = (Word) MR_string_const("% Reading .trans_opt files..\n", 29);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__trans_opt__grab_optfiles_6_0_i3,
		ENTRY(mercury__trans_opt__grab_optfiles_6_0));
Define_label(mercury__trans_opt__grab_optfiles_6_0_i3);
	update_prof_current_proc(LABEL(mercury__trans_opt__grab_optfiles_6_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__passes_aux__maybe_flush_output_3_0),
		mercury__trans_opt__grab_optfiles_6_0_i4,
		ENTRY(mercury__trans_opt__grab_optfiles_6_0));
Define_label(mercury__trans_opt__grab_optfiles_6_0_i4);
	update_prof_current_proc(LABEL(mercury__trans_opt__grab_optfiles_6_0));
	r4 = r1;
	r1 = MR_stackvar(2);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r3 = (Integer) 0;
	call_localret(STATIC(mercury__trans_opt__read_trans_opt_files_7_0),
		mercury__trans_opt__grab_optfiles_6_0_i5,
		ENTRY(mercury__trans_opt__grab_optfiles_6_0));
Define_label(mercury__trans_opt__grab_optfiles_6_0_i5);
	update_prof_current_proc(LABEL(mercury__trans_opt__grab_optfiles_6_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	MR_stackvar(2) = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 3));
	MR_stackvar(5) = r3;
	call_localret(ENTRY(mercury__modules__append_pseudo_decl_3_0),
		mercury__trans_opt__grab_optfiles_6_0_i6,
		ENTRY(mercury__trans_opt__grab_optfiles_6_0));
	}
Define_label(mercury__trans_opt__grab_optfiles_6_0_i6);
	update_prof_current_proc(LABEL(mercury__trans_opt__grab_optfiles_6_0));
	MR_stackvar(4) = r1;
	call_localret(ENTRY(mercury__modules__module_imports_get_items_2_0),
		mercury__trans_opt__grab_optfiles_6_0_i7,
		ENTRY(mercury__trans_opt__grab_optfiles_6_0));
Define_label(mercury__trans_opt__grab_optfiles_6_0_i7);
	update_prof_current_proc(LABEL(mercury__trans_opt__grab_optfiles_6_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_trans_opt__common_0);
	r3 = MR_stackvar(1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__trans_opt__grab_optfiles_6_0_i8,
		ENTRY(mercury__trans_opt__grab_optfiles_6_0));
Define_label(mercury__trans_opt__grab_optfiles_6_0_i8);
	update_prof_current_proc(LABEL(mercury__trans_opt__grab_optfiles_6_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__modules__module_imports_set_items_3_0),
		mercury__trans_opt__grab_optfiles_6_0_i9,
		ENTRY(mercury__trans_opt__grab_optfiles_6_0));
Define_label(mercury__trans_opt__grab_optfiles_6_0_i9);
	update_prof_current_proc(LABEL(mercury__trans_opt__grab_optfiles_6_0));
	r2 = (Integer) 0;
	call_localret(ENTRY(mercury__modules__module_imports_set_error_3_0),
		mercury__trans_opt__grab_optfiles_6_0_i10,
		ENTRY(mercury__trans_opt__grab_optfiles_6_0));
Define_label(mercury__trans_opt__grab_optfiles_6_0_i10);
	update_prof_current_proc(LABEL(mercury__trans_opt__grab_optfiles_6_0));
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(3);
	r2 = (Word) MR_string_const("% Done.\n", 8);
	r3 = MR_stackvar(5);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__trans_opt__grab_optfiles_6_0_i11,
		ENTRY(mercury__trans_opt__grab_optfiles_6_0));
Define_label(mercury__trans_opt__grab_optfiles_6_0_i11);
	update_prof_current_proc(LABEL(mercury__trans_opt__grab_optfiles_6_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_module__module_info_preds_2_0);
Declare_entry(mercury__hlds_module__module_info_type_spec_info_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_id_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_info_0;
Declare_entry(mercury__hlds_pred__pred_info_is_exported_1_0);
Declare_entry(mercury__code_util__predinfo_is_builtin_1_0);
Declare_entry(mercury__code_util__compiler_generated_1_0);
Declare_entry(mercury__set__member_2_0);
Declare_entry(mercury__map__keys_2_0);

BEGIN_MODULE(trans_opt_module3)
	init_entry(mercury__trans_opt__write_preds_4_0);
	init_label(mercury__trans_opt__write_preds_4_0_i1005);
	init_label(mercury__trans_opt__write_preds_4_0_i4);
	init_label(mercury__trans_opt__write_preds_4_0_i5);
	init_label(mercury__trans_opt__write_preds_4_0_i6);
	init_label(mercury__trans_opt__write_preds_4_0_i8);
	init_label(mercury__trans_opt__write_preds_4_0_i12);
	init_label(mercury__trans_opt__write_preds_4_0_i16);
	init_label(mercury__trans_opt__write_preds_4_0_i19);
	init_label(mercury__trans_opt__write_preds_4_0_i21);
	init_label(mercury__trans_opt__write_preds_4_0_i22);
	init_label(mercury__trans_opt__write_preds_4_0_i23);
	init_label(mercury__trans_opt__write_preds_4_0_i7);
	init_label(mercury__trans_opt__write_preds_4_0_i3);
BEGIN_CODE

/* code for predicate 'write_preds'/4 in mode 0 */
Define_static(mercury__trans_opt__write_preds_4_0);
	MR_incr_sp_push_msg(7, "trans_opt:write_preds/4");
	MR_stackvar(7) = (Word) MR_succip;
Define_label(mercury__trans_opt__write_preds_4_0_i1005);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__trans_opt__write_preds_4_0_i3);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = r2;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__trans_opt__write_preds_4_0_i4,
		STATIC(mercury__trans_opt__write_preds_4_0));
Define_label(mercury__trans_opt__write_preds_4_0_i4);
	update_prof_current_proc(LABEL(mercury__trans_opt__write_preds_4_0));
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_module__module_info_type_spec_info_2_0),
		mercury__trans_opt__write_preds_4_0_i5,
		STATIC(mercury__trans_opt__write_preds_4_0));
Define_label(mercury__trans_opt__write_preds_4_0_i5);
	update_prof_current_proc(LABEL(mercury__trans_opt__write_preds_4_0));
	r3 = MR_stackvar(5);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	r4 = MR_stackvar(3);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__trans_opt__write_preds_4_0_i6,
		STATIC(mercury__trans_opt__write_preds_4_0));
Define_label(mercury__trans_opt__write_preds_4_0_i6);
	update_prof_current_proc(LABEL(mercury__trans_opt__write_preds_4_0));
	MR_stackvar(6) = r1;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_is_exported_1_0),
		mercury__trans_opt__write_preds_4_0_i8,
		STATIC(mercury__trans_opt__write_preds_4_0));
Define_label(mercury__trans_opt__write_preds_4_0_i8);
	update_prof_current_proc(LABEL(mercury__trans_opt__write_preds_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__trans_opt__write_preds_4_0_i7);
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__code_util__predinfo_is_builtin_1_0),
		mercury__trans_opt__write_preds_4_0_i12,
		STATIC(mercury__trans_opt__write_preds_4_0));
Define_label(mercury__trans_opt__write_preds_4_0_i12);
	update_prof_current_proc(LABEL(mercury__trans_opt__write_preds_4_0));
	if (r1)
		GOTO_LABEL(mercury__trans_opt__write_preds_4_0_i7);
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__code_util__compiler_generated_1_0),
		mercury__trans_opt__write_preds_4_0_i16,
		STATIC(mercury__trans_opt__write_preds_4_0));
Define_label(mercury__trans_opt__write_preds_4_0_i16);
	update_prof_current_proc(LABEL(mercury__trans_opt__write_preds_4_0));
	if (r1)
		GOTO_LABEL(mercury__trans_opt__write_preds_4_0_i7);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(5);
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__trans_opt__write_preds_4_0_i19,
		STATIC(mercury__trans_opt__write_preds_4_0));
Define_label(mercury__trans_opt__write_preds_4_0_i19);
	update_prof_current_proc(LABEL(mercury__trans_opt__write_preds_4_0));
	if (r1)
		GOTO_LABEL(mercury__trans_opt__write_preds_4_0_i7);
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procedures_2_0),
		mercury__trans_opt__write_preds_4_0_i21,
		STATIC(mercury__trans_opt__write_preds_4_0));
Define_label(mercury__trans_opt__write_preds_4_0_i21);
	update_prof_current_proc(LABEL(mercury__trans_opt__write_preds_4_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0;
	call_localret(ENTRY(mercury__map__keys_2_0),
		mercury__trans_opt__write_preds_4_0_i22,
		STATIC(mercury__trans_opt__write_preds_4_0));
Define_label(mercury__trans_opt__write_preds_4_0_i22);
	update_prof_current_proc(LABEL(mercury__trans_opt__write_preds_4_0));
	r2 = MR_stackvar(6);
	r3 = MR_stackvar(2);
	call_localret(STATIC(mercury__trans_opt__write_procs__ua0_5_0),
		mercury__trans_opt__write_preds_4_0_i23,
		STATIC(mercury__trans_opt__write_preds_4_0));
Define_label(mercury__trans_opt__write_preds_4_0_i23);
	update_prof_current_proc(LABEL(mercury__trans_opt__write_preds_4_0));
	r2 = MR_stackvar(1);
	r3 = r1;
	r1 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(7);
	GOTO_LABEL(mercury__trans_opt__write_preds_4_0_i1005);
Define_label(mercury__trans_opt__write_preds_4_0_i7);
	r2 = MR_stackvar(1);
	r1 = MR_stackvar(4);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(7);
	GOTO_LABEL(mercury__trans_opt__write_preds_4_0_i1005);
Define_label(mercury__trans_opt__write_preds_4_0_i3);
	r1 = r3;
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE

Declare_entry(mercury__prog_out__sym_name_to_string_2_0);
Declare_entry(mercury__prog_io__read_opt_file_8_0);
Declare_entry(mercury__intermod__update_error_status_8_0);

BEGIN_MODULE(trans_opt_module4)
	init_entry(mercury__trans_opt__read_trans_opt_files_7_0);
	init_label(mercury__trans_opt__read_trans_opt_files_7_0_i1001);
	init_label(mercury__trans_opt__read_trans_opt_files_7_0_i4);
	init_label(mercury__trans_opt__read_trans_opt_files_7_0_i5);
	init_label(mercury__trans_opt__read_trans_opt_files_7_0_i6);
	init_label(mercury__trans_opt__read_trans_opt_files_7_0_i7);
	init_label(mercury__trans_opt__read_trans_opt_files_7_0_i8);
	init_label(mercury__trans_opt__read_trans_opt_files_7_0_i9);
	init_label(mercury__trans_opt__read_trans_opt_files_7_0_i10);
	init_label(mercury__trans_opt__read_trans_opt_files_7_0_i11);
	init_label(mercury__trans_opt__read_trans_opt_files_7_0_i12);
	init_label(mercury__trans_opt__read_trans_opt_files_7_0_i13);
	init_label(mercury__trans_opt__read_trans_opt_files_7_0_i14);
	init_label(mercury__trans_opt__read_trans_opt_files_7_0_i15);
	init_label(mercury__trans_opt__read_trans_opt_files_7_0_i3);
BEGIN_CODE

/* code for predicate 'read_trans_opt_files'/7 in mode 0 */
Define_static(mercury__trans_opt__read_trans_opt_files_7_0);
	MR_incr_sp_push_msg(8, "trans_opt:read_trans_opt_files/7");
	MR_stackvar(8) = (Word) MR_succip;
Define_label(mercury__trans_opt__read_trans_opt_files_7_0_i1001);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__trans_opt__read_trans_opt_files_7_0_i3);
	MR_stackvar(1) = r2;
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Integer) 18;
	r2 = r4;
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__trans_opt__read_trans_opt_files_7_0_i4,
		STATIC(mercury__trans_opt__read_trans_opt_files_7_0));
Define_label(mercury__trans_opt__read_trans_opt_files_7_0_i4);
	update_prof_current_proc(LABEL(mercury__trans_opt__read_trans_opt_files_7_0));
	MR_stackvar(5) = r1;
	r3 = r2;
	r2 = (Word) MR_string_const("% Reading transitive optimization interface for module", 54);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__trans_opt__read_trans_opt_files_7_0_i5,
		STATIC(mercury__trans_opt__read_trans_opt_files_7_0));
Define_label(mercury__trans_opt__read_trans_opt_files_7_0_i5);
	update_prof_current_proc(LABEL(mercury__trans_opt__read_trans_opt_files_7_0));
	r3 = r1;
	r1 = MR_stackvar(5);
	r2 = (Word) MR_string_const(" `", 2);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__trans_opt__read_trans_opt_files_7_0_i6,
		STATIC(mercury__trans_opt__read_trans_opt_files_7_0));
Define_label(mercury__trans_opt__read_trans_opt_files_7_0_i6);
	update_prof_current_proc(LABEL(mercury__trans_opt__read_trans_opt_files_7_0));
	MR_stackvar(6) = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__prog_out__sym_name_to_string_2_0),
		mercury__trans_opt__read_trans_opt_files_7_0_i7,
		STATIC(mercury__trans_opt__read_trans_opt_files_7_0));
Define_label(mercury__trans_opt__read_trans_opt_files_7_0_i7);
	update_prof_current_proc(LABEL(mercury__trans_opt__read_trans_opt_files_7_0));
	r2 = r1;
	r1 = MR_stackvar(5);
	r3 = MR_stackvar(6);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__trans_opt__read_trans_opt_files_7_0_i8,
		STATIC(mercury__trans_opt__read_trans_opt_files_7_0));
Define_label(mercury__trans_opt__read_trans_opt_files_7_0_i8);
	update_prof_current_proc(LABEL(mercury__trans_opt__read_trans_opt_files_7_0));
	r3 = r1;
	r1 = MR_stackvar(5);
	r2 = (Word) MR_string_const("'... ", 5);
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__trans_opt__read_trans_opt_files_7_0_i9,
		STATIC(mercury__trans_opt__read_trans_opt_files_7_0));
Define_label(mercury__trans_opt__read_trans_opt_files_7_0_i9);
	update_prof_current_proc(LABEL(mercury__trans_opt__read_trans_opt_files_7_0));
	r2 = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__passes_aux__maybe_flush_output_3_0),
		mercury__trans_opt__read_trans_opt_files_7_0_i10,
		STATIC(mercury__trans_opt__read_trans_opt_files_7_0));
Define_label(mercury__trans_opt__read_trans_opt_files_7_0_i10);
	update_prof_current_proc(LABEL(mercury__trans_opt__read_trans_opt_files_7_0));
	r4 = r1;
	r1 = MR_stackvar(3);
	r2 = (Word) MR_string_const(".trans_opt", 10);
	r3 = (Integer) 0;
	call_localret(ENTRY(mercury__modules__module_name_to_file_name_6_0),
		mercury__trans_opt__read_trans_opt_files_7_0_i11,
		STATIC(mercury__trans_opt__read_trans_opt_files_7_0));
Define_label(mercury__trans_opt__read_trans_opt_files_7_0_i11);
	update_prof_current_proc(LABEL(mercury__trans_opt__read_trans_opt_files_7_0));
	r4 = r2;
	r2 = MR_stackvar(3);
	r3 = (Integer) 1;
	MR_stackvar(3) = r1;
	call_localret(ENTRY(mercury__prog_io__read_opt_file_8_0),
		mercury__trans_opt__read_trans_opt_files_7_0_i12,
		STATIC(mercury__trans_opt__read_trans_opt_files_7_0));
Define_label(mercury__trans_opt__read_trans_opt_files_7_0_i12);
	update_prof_current_proc(LABEL(mercury__trans_opt__read_trans_opt_files_7_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(5);
	MR_stackvar(5) = MR_tempr1;
	MR_stackvar(6) = r2;
	MR_stackvar(7) = r3;
	r2 = (Word) MR_string_const(" done.\n", 7);
	r3 = r4;
	call_localret(ENTRY(mercury__passes_aux__maybe_write_string_4_0),
		mercury__trans_opt__read_trans_opt_files_7_0_i13,
		STATIC(mercury__trans_opt__read_trans_opt_files_7_0));
	}
Define_label(mercury__trans_opt__read_trans_opt_files_7_0_i13);
	update_prof_current_proc(LABEL(mercury__trans_opt__read_trans_opt_files_7_0));
	r6 = r1;
	r1 = (Integer) 1;
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(5);
	r4 = MR_stackvar(6);
	r5 = MR_stackvar(2);
	call_localret(ENTRY(mercury__intermod__update_error_status_8_0),
		mercury__trans_opt__read_trans_opt_files_7_0_i14,
		STATIC(mercury__trans_opt__read_trans_opt_files_7_0));
Define_label(mercury__trans_opt__read_trans_opt_files_7_0_i14);
	update_prof_current_proc(LABEL(mercury__trans_opt__read_trans_opt_files_7_0));
	MR_stackvar(2) = r2;
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_trans_opt__common_0);
	r3 = MR_stackvar(7);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__trans_opt__read_trans_opt_files_7_0_i15,
		STATIC(mercury__trans_opt__read_trans_opt_files_7_0));
Define_label(mercury__trans_opt__read_trans_opt_files_7_0_i15);
	update_prof_current_proc(LABEL(mercury__trans_opt__read_trans_opt_files_7_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(8);
	GOTO_LABEL(mercury__trans_opt__read_trans_opt_files_7_0_i1001);
Define_label(mercury__trans_opt__read_trans_opt_files_7_0_i3);
	r1 = r2;
	r2 = r3;
	r3 = r4;
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__trans_opt_maybe_bunch_0(void)
{
	trans_opt_module0();
	trans_opt_module1();
	trans_opt_module2();
	trans_opt_module3();
	trans_opt_module4();
}

#endif

void mercury__trans_opt__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__trans_opt__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__trans_opt_maybe_bunch_0();
#endif

	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
