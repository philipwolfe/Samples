/*
** Automatically generated from `transform_llds.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__transform_llds__init
ENDINIT
*/

#include "mercury_imp.h"

Define_extern_entry(mercury__transform_llds__transform_llds_4_0);
Declare_label(mercury__transform_llds__transform_llds_4_0_i2);
Declare_label(mercury__transform_llds__transform_llds_4_0_i3);
Declare_label(mercury__transform_llds__transform_llds_4_0_i5);
Declare_static(mercury__transform_llds__transform_c_module_list_4_0);
Declare_label(mercury__transform_llds__transform_c_module_list_4_0_i4);
Declare_label(mercury__transform_llds__transform_c_module_list_4_0_i5);
Declare_label(mercury__transform_llds__transform_c_module_list_4_0_i3);
Declare_static(mercury__transform_llds__transform_c_procedure_list_4_0);
Declare_label(mercury__transform_llds__transform_c_procedure_list_4_0_i4);
Declare_label(mercury__transform_llds__transform_c_procedure_list_4_0_i5);
Declare_label(mercury__transform_llds__transform_c_procedure_list_4_0_i6);
Declare_label(mercury__transform_llds__transform_c_procedure_list_4_0_i7);
Declare_label(mercury__transform_llds__transform_c_procedure_list_4_0_i3);
Declare_static(mercury__transform_llds__transform_instructions_2_6_0);
Declare_label(mercury__transform_llds__transform_instructions_2_6_0_i4);
Declare_label(mercury__transform_llds__transform_instructions_2_6_0_i8);
Declare_label(mercury__transform_llds__transform_instructions_2_6_0_i9);
Declare_label(mercury__transform_llds__transform_instructions_2_6_0_i5);
Declare_label(mercury__transform_llds__transform_instructions_2_6_0_i6);
Declare_label(mercury__transform_llds__transform_instructions_2_6_0_i11);
Declare_label(mercury__transform_llds__transform_instructions_2_6_0_i12);
Declare_label(mercury__transform_llds__transform_instructions_2_6_0_i3);
Declare_static(mercury__transform_llds__split_computed_goto_9_0);
Declare_label(mercury__transform_llds__split_computed_goto_9_0_i2);
Declare_label(mercury__transform_llds__split_computed_goto_9_0_i6);
Declare_label(mercury__transform_llds__split_computed_goto_9_0_i5);
Declare_label(mercury__transform_llds__split_computed_goto_9_0_i8);
Declare_label(mercury__transform_llds__split_computed_goto_9_0_i9);
Declare_label(mercury__transform_llds__split_computed_goto_9_0_i10);
Declare_label(mercury__transform_llds__split_computed_goto_9_0_i11);
Declare_label(mercury__transform_llds__split_computed_goto_9_0_i12);
Declare_label(mercury__transform_llds__split_computed_goto_9_0_i3);
Declare_label(mercury__transform_llds__split_computed_goto_9_0_i13);
Declare_static(mercury__transform_llds__max_label_int_3_0);
Declare_label(mercury__transform_llds__max_label_int_3_0_i1004);
Declare_label(mercury__transform_llds__max_label_int_3_0_i4);
Declare_label(mercury__transform_llds__max_label_int_3_0_i3);

static const struct mercury_data_transform_llds__common_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_transform_llds__common_0;

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_pair_2;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_llds__type_ctor_info_instr_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_string_0;
static const struct mercury_data_transform_llds__common_0_struct mercury_data_transform_llds__common_0 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_llds__type_ctor_info_instr_0,
	(Word *) &mercury_data___type_ctor_info_string_0
};

Declare_entry(mercury__globals__io_lookup_int_option_4_0);

BEGIN_MODULE(transform_llds_module0)
	init_entry(mercury__transform_llds__transform_llds_4_0);
	init_label(mercury__transform_llds__transform_llds_4_0_i2);
	init_label(mercury__transform_llds__transform_llds_4_0_i3);
	init_label(mercury__transform_llds__transform_llds_4_0_i5);
BEGIN_CODE

/* code for predicate 'transform_llds'/4 in mode 0 */
Define_entry(mercury__transform_llds__transform_llds_4_0);
	MR_incr_sp_push_msg(7, "transform_llds:transform_llds/4");
	MR_stackvar(7) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = (Integer) 134;
	call_localret(ENTRY(mercury__globals__io_lookup_int_option_4_0),
		mercury__transform_llds__transform_llds_4_0_i2,
		ENTRY(mercury__transform_llds__transform_llds_4_0));
Define_label(mercury__transform_llds__transform_llds_4_0_i2);
	update_prof_current_proc(LABEL(mercury__transform_llds__transform_llds_4_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__transform_llds__transform_llds_4_0_i3);
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__transform_llds__transform_llds_4_0_i3);
	r3 = MR_stackvar(1);
	r1 = MR_const_field(MR_mktag(0), r3, (Integer) 6);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r3, (Integer) 2);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r3, (Integer) 3);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r3, (Integer) 4);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r3, (Integer) 5);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	call_localret(STATIC(mercury__transform_llds__transform_c_module_list_4_0),
		mercury__transform_llds__transform_llds_4_0_i5,
		ENTRY(mercury__transform_llds__transform_llds_4_0));
Define_label(mercury__transform_llds__transform_llds_4_0_i5);
	update_prof_current_proc(LABEL(mercury__transform_llds__transform_llds_4_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 7, mercury__transform_llds__transform_llds_4_0, "llds:c_file/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_stackvar(3);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_stackvar(4);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_stackvar(5);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_stackvar(6);
	MR_field(MR_mktag(0), r1, (Integer) 6) = r3;
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE


BEGIN_MODULE(transform_llds_module1)
	init_entry(mercury__transform_llds__transform_c_module_list_4_0);
	init_label(mercury__transform_llds__transform_c_module_list_4_0_i4);
	init_label(mercury__transform_llds__transform_c_module_list_4_0_i5);
	init_label(mercury__transform_llds__transform_c_module_list_4_0_i3);
BEGIN_CODE

/* code for predicate 'transform_c_module_list'/4 in mode 0 */
Define_static(mercury__transform_llds__transform_c_module_list_4_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__transform_llds__transform_c_module_list_4_0_i3);
	MR_incr_sp_push_msg(3, "transform_llds:transform_c_module_list/4");
	MR_stackvar(3) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	call_localret(STATIC(mercury__transform_llds__transform_c_procedure_list_4_0),
		mercury__transform_llds__transform_c_module_list_4_0_i4,
		STATIC(mercury__transform_llds__transform_c_module_list_4_0));
Define_label(mercury__transform_llds__transform_c_module_list_4_0_i4);
	update_prof_current_proc(LABEL(mercury__transform_llds__transform_c_module_list_4_0));
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__transform_llds__transform_c_module_list_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 1) = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(2);
	localcall(mercury__transform_llds__transform_c_module_list_4_0,
		LABEL(mercury__transform_llds__transform_c_module_list_4_0_i5),
		STATIC(mercury__transform_llds__transform_c_module_list_4_0));
Define_label(mercury__transform_llds__transform_c_module_list_4_0_i5);
	update_prof_current_proc(LABEL(mercury__transform_llds__transform_c_module_list_4_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__transform_llds__transform_c_module_list_4_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__transform_llds__transform_c_module_list_4_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE

Declare_entry(mercury__opt_util__get_prologue_5_0);

BEGIN_MODULE(transform_llds_module2)
	init_entry(mercury__transform_llds__transform_c_procedure_list_4_0);
	init_label(mercury__transform_llds__transform_c_procedure_list_4_0_i4);
	init_label(mercury__transform_llds__transform_c_procedure_list_4_0_i5);
	init_label(mercury__transform_llds__transform_c_procedure_list_4_0_i6);
	init_label(mercury__transform_llds__transform_c_procedure_list_4_0_i7);
	init_label(mercury__transform_llds__transform_c_procedure_list_4_0_i3);
BEGIN_CODE

/* code for predicate 'transform_c_procedure_list'/4 in mode 0 */
Define_static(mercury__transform_llds__transform_c_procedure_list_4_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__transform_llds__transform_c_procedure_list_4_0_i3);
	MR_incr_sp_push_msg(8, "transform_llds:transform_c_procedure_list/4");
	MR_stackvar(8) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r3, (Integer) 3);
	MR_stackvar(6) = r1;
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r3, (Integer) 2);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__opt_util__get_prologue_5_0),
		mercury__transform_llds__transform_c_procedure_list_4_0_i4,
		STATIC(mercury__transform_llds__transform_c_procedure_list_4_0));
Define_label(mercury__transform_llds__transform_c_procedure_list_4_0_i4);
	update_prof_current_proc(LABEL(mercury__transform_llds__transform_c_procedure_list_4_0));
	MR_stackvar(7) = r1;
	r1 = MR_stackvar(6);
	r2 = (Integer) 0;
	call_localret(STATIC(mercury__transform_llds__max_label_int_3_0),
		mercury__transform_llds__transform_c_procedure_list_4_0_i5,
		STATIC(mercury__transform_llds__transform_c_procedure_list_4_0));
Define_label(mercury__transform_llds__transform_c_procedure_list_4_0_i5);
	update_prof_current_proc(LABEL(mercury__transform_llds__transform_c_procedure_list_4_0));
	r3 = r1;
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(7);
	r4 = MR_stackvar(1);
	call_localret(STATIC(mercury__transform_llds__transform_instructions_2_6_0),
		mercury__transform_llds__transform_c_procedure_list_4_0_i6,
		STATIC(mercury__transform_llds__transform_c_procedure_list_4_0));
Define_label(mercury__transform_llds__transform_c_procedure_list_4_0_i6);
	update_prof_current_proc(LABEL(mercury__transform_llds__transform_c_procedure_list_4_0));
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__transform_llds__transform_c_procedure_list_4_0, "origin_lost_in_value_number");
	MR_stackvar(1) = r3;
	MR_field(MR_mktag(0), r3, (Integer) 3) = r1;
	r1 = MR_stackvar(2);
	MR_field(MR_mktag(0), r3, (Integer) 2) = MR_stackvar(5);
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(4);
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(3);
	localcall(mercury__transform_llds__transform_c_procedure_list_4_0,
		LABEL(mercury__transform_llds__transform_c_procedure_list_4_0_i7),
		STATIC(mercury__transform_llds__transform_c_procedure_list_4_0));
Define_label(mercury__transform_llds__transform_c_procedure_list_4_0_i7);
	update_prof_current_proc(LABEL(mercury__transform_llds__transform_c_procedure_list_4_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__transform_llds__transform_c_procedure_list_4_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__transform_llds__transform_c_procedure_list_4_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE

extern const struct MR_TypeCtorInfo_struct
	mercury_data_llds__type_ctor_info_label_0;
Declare_entry(mercury__list__length_2_0);
Declare_entry(mercury__list__append_3_1);

BEGIN_MODULE(transform_llds_module3)
	init_entry(mercury__transform_llds__transform_instructions_2_6_0);
	init_label(mercury__transform_llds__transform_instructions_2_6_0_i4);
	init_label(mercury__transform_llds__transform_instructions_2_6_0_i8);
	init_label(mercury__transform_llds__transform_instructions_2_6_0_i9);
	init_label(mercury__transform_llds__transform_instructions_2_6_0_i5);
	init_label(mercury__transform_llds__transform_instructions_2_6_0_i6);
	init_label(mercury__transform_llds__transform_instructions_2_6_0_i11);
	init_label(mercury__transform_llds__transform_instructions_2_6_0_i12);
	init_label(mercury__transform_llds__transform_instructions_2_6_0_i3);
BEGIN_CODE

/* code for predicate 'transform_instructions_2'/6 in mode 0 */
Define_static(mercury__transform_llds__transform_instructions_2_6_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__transform_llds__transform_instructions_2_6_0_i3);
	MR_incr_sp_push_msg(7, "transform_llds:transform_instructions_2/6");
	MR_stackvar(7) = (Word) MR_succip;
	MR_stackvar(1) = r2;
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Integer) 134;
	r2 = r4;
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__globals__io_lookup_int_option_4_0),
		mercury__transform_llds__transform_instructions_2_6_0_i4,
		STATIC(mercury__transform_llds__transform_instructions_2_6_0));
Define_label(mercury__transform_llds__transform_instructions_2_6_0_i4);
	update_prof_current_proc(LABEL(mercury__transform_llds__transform_instructions_2_6_0));
	r3 = MR_const_field(MR_mktag(0), MR_stackvar(4), (Integer) 0);
	if ((MR_tag(r3) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__transform_llds__transform_instructions_2_6_0_i6);
	if (((Integer) MR_const_field(MR_mktag(3), r3, (Integer) 0) != (Integer) 6))
		GOTO_LABEL(mercury__transform_llds__transform_instructions_2_6_0_i6);
	MR_stackvar(3) = r1;
	MR_stackvar(6) = r2;
	r2 = MR_const_field(MR_mktag(3), r3, (Integer) 2);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__transform_llds__transform_instructions_2_6_0_i8,
		STATIC(mercury__transform_llds__transform_instructions_2_6_0));
Define_label(mercury__transform_llds__transform_instructions_2_6_0_i8);
	update_prof_current_proc(LABEL(mercury__transform_llds__transform_instructions_2_6_0));
	if (((Integer) r1 <= (Integer) MR_stackvar(3)))
		GOTO_LABEL(mercury__transform_llds__transform_instructions_2_6_0_i5);
	r2 = MR_stackvar(3);
	r3 = r1;
	r1 = MR_stackvar(4);
	r4 = MR_stackvar(1);
	r5 = MR_stackvar(2);
	r6 = MR_stackvar(6);
	call_localret(STATIC(mercury__transform_llds__split_computed_goto_9_0),
		mercury__transform_llds__transform_instructions_2_6_0_i9,
		STATIC(mercury__transform_llds__transform_instructions_2_6_0));
Define_label(mercury__transform_llds__transform_instructions_2_6_0_i9);
	update_prof_current_proc(LABEL(mercury__transform_llds__transform_instructions_2_6_0));
	r4 = r3;
	r3 = r2;
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(1);
	localcall(mercury__transform_llds__transform_instructions_2_6_0,
		LABEL(mercury__transform_llds__transform_instructions_2_6_0_i11),
		STATIC(mercury__transform_llds__transform_instructions_2_6_0));
Define_label(mercury__transform_llds__transform_instructions_2_6_0_i5);
	r2 = MR_stackvar(6);
Define_label(mercury__transform_llds__transform_instructions_2_6_0_i6);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__transform_llds__transform_instructions_2_6_0, "origin_lost_in_value_number");
	r4 = r2;
	MR_stackvar(3) = MR_tempr1;
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(4);
	localcall(mercury__transform_llds__transform_instructions_2_6_0,
		LABEL(mercury__transform_llds__transform_instructions_2_6_0_i11),
		STATIC(mercury__transform_llds__transform_instructions_2_6_0));
	}
Define_label(mercury__transform_llds__transform_instructions_2_6_0_i11);
	update_prof_current_proc(LABEL(mercury__transform_llds__transform_instructions_2_6_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r2;
	r2 = MR_stackvar(3);
	MR_stackvar(3) = MR_tempr1;
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_transform_llds__common_0);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__transform_llds__transform_instructions_2_6_0_i12,
		STATIC(mercury__transform_llds__transform_instructions_2_6_0));
	}
Define_label(mercury__transform_llds__transform_instructions_2_6_0_i12);
	update_prof_current_proc(LABEL(mercury__transform_llds__transform_instructions_2_6_0));
	r2 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__transform_llds__transform_instructions_2_6_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = r4;
	proceed();
END_MODULE

Declare_entry(mercury__list__split_list_4_0);
Declare_entry(mercury__require__error_1_0);

BEGIN_MODULE(transform_llds_module4)
	init_entry(mercury__transform_llds__split_computed_goto_9_0);
	init_label(mercury__transform_llds__split_computed_goto_9_0_i2);
	init_label(mercury__transform_llds__split_computed_goto_9_0_i6);
	init_label(mercury__transform_llds__split_computed_goto_9_0_i5);
	init_label(mercury__transform_llds__split_computed_goto_9_0_i8);
	init_label(mercury__transform_llds__split_computed_goto_9_0_i9);
	init_label(mercury__transform_llds__split_computed_goto_9_0_i10);
	init_label(mercury__transform_llds__split_computed_goto_9_0_i11);
	init_label(mercury__transform_llds__split_computed_goto_9_0_i12);
	init_label(mercury__transform_llds__split_computed_goto_9_0_i3);
	init_label(mercury__transform_llds__split_computed_goto_9_0_i13);
BEGIN_CODE

/* code for predicate 'split_computed_goto'/9 in mode 0 */
Define_static(mercury__transform_llds__split_computed_goto_9_0);
	MR_incr_sp_push_msg(10, "transform_llds:split_computed_goto/9");
	MR_stackvar(10) = (Word) MR_succip;
	if (((Integer) r3 > (Integer) r2))
		GOTO_LABEL(mercury__transform_llds__split_computed_goto_9_0_i2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__transform_llds__split_computed_goto_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r1;
	r1 = MR_tempr1;
	r2 = r5;
	r3 = r6;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
	}
Define_label(mercury__transform_llds__split_computed_goto_9_0_i2);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	if ((MR_tag(MR_tempr1) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__transform_llds__split_computed_goto_9_0_i3);
	if (((Integer) MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 0) != (Integer) 6))
		GOTO_LABEL(mercury__transform_llds__split_computed_goto_9_0_i3);
	MR_stackvar(1) = r2;
	r2 = ((Integer) r3 / (Integer) 2);
	MR_stackvar(2) = r3;
	MR_stackvar(8) = r2;
	MR_stackvar(4) = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 1);
	r3 = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 2);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_label_0;
	MR_stackvar(3) = r4;
	MR_stackvar(5) = r6;
	MR_stackvar(6) = ((Integer) r5 + (Integer) 1);
	MR_stackvar(7) = ((Integer) r5 + (Integer) 2);
	call_localret(ENTRY(mercury__list__split_list_4_0),
		mercury__transform_llds__split_computed_goto_9_0_i6,
		STATIC(mercury__transform_llds__split_computed_goto_9_0));
	}
Define_label(mercury__transform_llds__split_computed_goto_9_0_i6);
	update_prof_current_proc(LABEL(mercury__transform_llds__split_computed_goto_9_0));
	if (!(r1))
		GOTO_LABEL(mercury__transform_llds__split_computed_goto_9_0_i5);
	r1 = r2;
	r2 = MR_stackvar(1);
	r4 = MR_stackvar(3);
	r6 = MR_stackvar(5);
	r5 = MR_stackvar(7);
	r7 = r3;
	r3 = MR_stackvar(8);
	r8 = MR_stackvar(4);
	tag_incr_hp_msg(MR_stackvar(4), MR_mktag(0), (Integer) 2, mercury__transform_llds__split_computed_goto_9_0, "std_util:pair/2");
	tag_incr_hp_msg(r9, MR_mktag(3), (Integer) 2, mercury__transform_llds__split_computed_goto_9_0, "llds:instr/0");
	MR_field(MR_mktag(3), r9, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(0), MR_stackvar(4), (Integer) 1) = (Word) MR_string_const("", 0);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__transform_llds__split_computed_goto_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = MR_stackvar(6);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r4;
	MR_field(MR_mktag(3), r9, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(0), MR_stackvar(4), (Integer) 0) = r9;
	tag_incr_hp_msg(MR_stackvar(9), MR_mktag(0), (Integer) 2, mercury__transform_llds__split_computed_goto_9_0, "std_util:pair/2");
	tag_incr_hp_msg(r9, MR_mktag(3), (Integer) 3, mercury__transform_llds__split_computed_goto_9_0, "llds:instr/0");
	MR_field(MR_mktag(3), r9, (Integer) 0) = (Integer) 8;
	tag_incr_hp_msg(r10, MR_mktag(3), (Integer) 4, mercury__transform_llds__split_computed_goto_9_0, "llds:rval/0");
	MR_field(MR_mktag(3), r10, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r10, (Integer) 1) = (Integer) 24;
	MR_field(MR_mktag(3), r10, (Integer) 2) = r8;
	tag_incr_hp_msg(r11, MR_mktag(3), (Integer) 2, mercury__transform_llds__split_computed_goto_9_0, "llds:rval/0");
	MR_field(MR_mktag(3), r11, (Integer) 0) = (Integer) 1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__transform_llds__split_computed_goto_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r3;
	MR_field(MR_mktag(3), r9, (Integer) 1) = r10;
	MR_field(MR_mktag(3), r10, (Integer) 3) = r11;
	MR_field(MR_mktag(3), r11, (Integer) 1) = MR_tempr1;
	tag_incr_hp_msg(r10, MR_mktag(1), (Integer) 1, mercury__transform_llds__split_computed_goto_9_0, "llds:code_addr/0");
	MR_field(MR_mktag(0), MR_stackvar(9), (Integer) 1) = (Word) MR_string_const("Binary search", 13);
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__transform_llds__split_computed_goto_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = MR_stackvar(6);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r4;
	MR_field(MR_mktag(3), r9, (Integer) 2) = r10;
	MR_field(MR_mktag(1), r10, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(0), MR_stackvar(9), (Integer) 0) = r9;
	r9 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__transform_llds__split_computed_goto_9_0, "std_util:pair/2");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 3, mercury__transform_llds__split_computed_goto_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = r9;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r8;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 6;
	MR_field(MR_mktag(0), r1, (Integer) 1) = (Word) MR_string_const("Then section", 12);
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(MR_stackvar(6), MR_mktag(0), (Integer) 2, mercury__transform_llds__split_computed_goto_9_0, "std_util:pair/2");
	tag_incr_hp_msg(r11, MR_mktag(3), (Integer) 3, mercury__transform_llds__split_computed_goto_9_0, "llds:instr/0");
	MR_field(MR_mktag(3), r11, (Integer) 0) = (Integer) 6;
	tag_incr_hp_msg(r12, MR_mktag(3), (Integer) 4, mercury__transform_llds__split_computed_goto_9_0, "llds:rval/0");
	MR_field(MR_mktag(3), r12, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r12, (Integer) 1) = (Integer) 1;
	MR_field(MR_mktag(3), r12, (Integer) 2) = r8;
	tag_incr_hp_msg(r13, MR_mktag(3), (Integer) 2, mercury__transform_llds__split_computed_goto_9_0, "llds:rval/0");
	MR_field(MR_mktag(3), r13, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r11, (Integer) 2) = r7;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__transform_llds__split_computed_goto_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r3;
	MR_field(MR_mktag(0), MR_stackvar(6), (Integer) 1) = (Word) MR_string_const("Else section", 12);
	MR_field(MR_mktag(3), r11, (Integer) 1) = r12;
	MR_field(MR_mktag(3), r12, (Integer) 3) = r13;
	MR_field(MR_mktag(3), r13, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(0), MR_stackvar(6), (Integer) 0) = r11;
	GOTO_LABEL(mercury__transform_llds__split_computed_goto_9_0_i9);
	}
Define_label(mercury__transform_llds__split_computed_goto_9_0_i5);
	r1 = (Word) MR_string_const("split_computed_goto: list__split_list", 37);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__transform_llds__split_computed_goto_9_0_i8,
		STATIC(mercury__transform_llds__split_computed_goto_9_0));
Define_label(mercury__transform_llds__split_computed_goto_9_0_i8);
	update_prof_current_proc(LABEL(mercury__transform_llds__split_computed_goto_9_0));
	r2 = MR_stackvar(1);
	r4 = MR_stackvar(3);
	r6 = MR_stackvar(5);
	r5 = MR_stackvar(7);
	r3 = MR_stackvar(8);
Define_label(mercury__transform_llds__split_computed_goto_9_0_i9);
	MR_stackvar(1) = r2;
	MR_stackvar(3) = r4;
	MR_stackvar(8) = r3;
	localcall(mercury__transform_llds__split_computed_goto_9_0,
		LABEL(mercury__transform_llds__split_computed_goto_9_0_i10),
		STATIC(mercury__transform_llds__split_computed_goto_9_0));
Define_label(mercury__transform_llds__split_computed_goto_9_0_i10);
	update_prof_current_proc(LABEL(mercury__transform_llds__split_computed_goto_9_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(6);
	MR_stackvar(6) = MR_tempr1;
	r5 = r2;
	r6 = r3;
	r2 = MR_stackvar(1);
	r3 = ((Integer) MR_stackvar(2) - (Integer) MR_stackvar(8));
	r4 = MR_stackvar(3);
	localcall(mercury__transform_llds__split_computed_goto_9_0,
		LABEL(mercury__transform_llds__split_computed_goto_9_0_i11),
		STATIC(mercury__transform_llds__split_computed_goto_9_0));
	}
Define_label(mercury__transform_llds__split_computed_goto_9_0_i11);
	update_prof_current_proc(LABEL(mercury__transform_llds__split_computed_goto_9_0));
	r4 = MR_stackvar(4);
	r6 = r1;
	MR_stackvar(4) = r2;
	r2 = MR_stackvar(6);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_transform_llds__common_0);
	MR_stackvar(6) = r3;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__transform_llds__split_computed_goto_9_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r6;
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__transform_llds__split_computed_goto_9_0_i12,
		STATIC(mercury__transform_llds__split_computed_goto_9_0));
Define_label(mercury__transform_llds__split_computed_goto_9_0_i12);
	update_prof_current_proc(LABEL(mercury__transform_llds__split_computed_goto_9_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__transform_llds__split_computed_goto_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(6);
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(9);
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
Define_label(mercury__transform_llds__split_computed_goto_9_0_i3);
	r1 = (Word) MR_string_const("split_computed_goto", 19);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__transform_llds__split_computed_goto_9_0_i13,
		STATIC(mercury__transform_llds__split_computed_goto_9_0));
Define_label(mercury__transform_llds__split_computed_goto_9_0_i13);
	update_prof_current_proc(LABEL(mercury__transform_llds__split_computed_goto_9_0));
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
END_MODULE


BEGIN_MODULE(transform_llds_module5)
	init_entry(mercury__transform_llds__max_label_int_3_0);
	init_label(mercury__transform_llds__max_label_int_3_0_i1004);
	init_label(mercury__transform_llds__max_label_int_3_0_i4);
	init_label(mercury__transform_llds__max_label_int_3_0_i3);
BEGIN_CODE

/* code for predicate 'max_label_int'/3 in mode 0 */
Define_static(mercury__transform_llds__max_label_int_3_0);
	MR_incr_sp_push_msg(1, "transform_llds:max_label_int/3");
	MR_stackvar(1) = (Word) MR_succip;
Define_label(mercury__transform_llds__max_label_int_3_0_i1004);
	while (1) {
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__transform_llds__max_label_int_3_0_i3);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__transform_llds__max_label_int_3_0_i4);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0), (Integer) 0) != (Integer) 4))
		GOTO_LABEL(mercury__transform_llds__max_label_int_3_0_i4);
	if ((MR_tag(MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0), (Integer) 1)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__transform_llds__max_label_int_3_0_i4);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0), (Integer) 1), (Integer) 1) <= (Integer) r2))
		GOTO_LABEL(mercury__transform_llds__max_label_int_3_0_i4);
	r2 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0), (Integer) 1), (Integer) 1);
	r1 = r3;
	/* continue */ } /* end while */
Define_label(mercury__transform_llds__max_label_int_3_0_i4);
	r1 = r3;
	GOTO_LABEL(mercury__transform_llds__max_label_int_3_0_i1004);
Define_label(mercury__transform_llds__max_label_int_3_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__transform_llds_maybe_bunch_0(void)
{
	transform_llds_module0();
	transform_llds_module1();
	transform_llds_module2();
	transform_llds_module3();
	transform_llds_module4();
	transform_llds_module5();
}

#endif

void mercury__transform_llds__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__transform_llds__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__transform_llds_maybe_bunch_0();
#endif

	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
