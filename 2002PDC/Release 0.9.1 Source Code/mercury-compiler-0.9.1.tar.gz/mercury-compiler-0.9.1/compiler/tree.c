/*
** Automatically generated from `tree.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__tree__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury__tree__flatten_2__ua0_3_0);
Declare_label(mercury__tree__flatten_2__ua0_3_0_i1002);
Declare_label(mercury__tree__flatten_2__ua0_3_0_i5);
Declare_label(mercury__tree__flatten_2__ua0_3_0_i6);
Declare_label(mercury__tree__flatten_2__ua0_3_0_i4);
Define_extern_entry(mercury__tree__flatten_2_0);
Define_extern_entry(mercury__tree__is_empty_1_0);
Declare_label(mercury__tree__is_empty_1_0_i1007);
Declare_label(mercury__tree__is_empty_1_0_i5);
Declare_label(mercury__tree__is_empty_1_0_i1003);
Declare_label(mercury__tree__is_empty_1_0_i1);
Define_extern_entry(mercury__tree__tree_of_lists_is_empty_1_0);
Declare_label(mercury__tree__tree_of_lists_is_empty_1_0_i1008);
Declare_label(mercury__tree__tree_of_lists_is_empty_1_0_i7);
Declare_label(mercury__tree__tree_of_lists_is_empty_1_0_i4);
Declare_label(mercury__tree__tree_of_lists_is_empty_1_0_i1004);
Declare_label(mercury__tree__tree_of_lists_is_empty_1_0_i1);
Define_extern_entry(mercury____Unify___tree__tree_1_0);
Declare_label(mercury____Unify___tree__tree_1_0_i1006);
Declare_label(mercury____Unify___tree__tree_1_0_i8);
Declare_label(mercury____Unify___tree__tree_1_0_i10);
Declare_label(mercury____Unify___tree__tree_1_0_i4);
Declare_label(mercury____Unify___tree__tree_1_0_i1);
Define_extern_entry(mercury____Index___tree__tree_1_0);
Declare_label(mercury____Index___tree__tree_1_0_i5);
Declare_label(mercury____Index___tree__tree_1_0_i4);
Define_extern_entry(mercury____Compare___tree__tree_1_0);
Declare_label(mercury____Compare___tree__tree_1_0_i1012);
Declare_label(mercury____Compare___tree__tree_1_0_i5);
Declare_label(mercury____Compare___tree__tree_1_0_i4);
Declare_label(mercury____Compare___tree__tree_1_0_i2);
Declare_label(mercury____Compare___tree__tree_1_0_i9);
Declare_label(mercury____Compare___tree__tree_1_0_i8);
Declare_label(mercury____Compare___tree__tree_1_0_i6);
Declare_label(mercury____Compare___tree__tree_1_0_i10);
Declare_label(mercury____Compare___tree__tree_1_0_i11);
Declare_label(mercury____Compare___tree__tree_1_0_i19);
Declare_label(mercury____Compare___tree__tree_1_0_i22);
Declare_label(mercury____Compare___tree__tree_1_0_i16);
Declare_label(mercury____Compare___tree__tree_1_0_i13);
Declare_label(mercury____Compare___tree__tree_1_0_i31);

const struct MR_TypeCtorInfo_struct mercury_data_tree__type_ctor_info_tree_1;

static const struct mercury_data_tree__common_0_struct {
	Integer f1;
	String f2;
	Word * f3;
	Integer f4;
	Integer f5;
}  mercury_data_tree__common_0;

static const struct mercury_data_tree__common_1_struct {
	Integer f1;
	Integer f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_tree__common_1;

static const struct mercury_data_tree__common_2_struct {
	Word * f1;
	Integer f2;
}  mercury_data_tree__common_2;

static const struct mercury_data_tree__common_3_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	String f4;
	Word * f5;
	Integer f6;
	Integer f7;
}  mercury_data_tree__common_3;

static const struct mercury_data_tree__common_4_struct {
	Integer f1;
	Integer f2;
	String f3;
}  mercury_data_tree__common_4;

static const struct mercury_data_tree__type_ctor_functors_tree_1_struct {
	Integer f1;
	Integer f2;
	Word * f3;
	Word * f4;
	Word * f5;
}  mercury_data_tree__type_ctor_functors_tree_1;

static const struct mercury_data_tree__type_ctor_layout_tree_1_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_tree__type_ctor_layout_tree_1;

const struct MR_TypeCtorInfo_struct mercury_data_tree__type_ctor_info_tree_1 = {
	(Integer) 1,
	ENTRY(mercury____Unify___tree__tree_1_0),
	ENTRY(mercury____Index___tree__tree_1_0),
	ENTRY(mercury____Compare___tree__tree_1_0),
	(Integer) 2,
	(Word *) &mercury_data_tree__type_ctor_functors_tree_1,
	(Word *) &mercury_data_tree__type_ctor_layout_tree_1,
	MR_string_const("tree", 4),
	MR_string_const("tree", 4),
	(Integer) 3
};

static const struct mercury_data_tree__common_0_struct mercury_data_tree__common_0 = {
	(Integer) 0,
	MR_string_const("empty", 5),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_tree__common_1_struct mercury_data_tree__common_1 = {
	(Integer) 1,
	(Integer) 1,
	MR_string_const("node", 4),
	MR_mkword(MR_mktag(1), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_tree__common_2_struct mercury_data_tree__common_2 = {
	(Word *) &mercury_data_tree__type_ctor_info_tree_1,
	(Integer) 1
};

static const struct mercury_data_tree__common_3_struct mercury_data_tree__common_3 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_tree__common_2),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_tree__common_2),
	MR_string_const("tree", 4),
	MR_mkword(MR_mktag(2), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_tree__common_4_struct mercury_data_tree__common_4 = {
	(Integer) 0,
	(Integer) 1,
	MR_string_const("empty", 5)
};

static const struct mercury_data_tree__type_ctor_functors_tree_1_struct mercury_data_tree__type_ctor_functors_tree_1 = {
	(Integer) 0,
	(Integer) 3,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_tree__common_0),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_tree__common_1),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_tree__common_3)
};

static const struct mercury_data_tree__type_ctor_layout_tree_1_struct mercury_data_tree__type_ctor_layout_tree_1 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_tree__common_4),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_tree__common_1),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_tree__common_3),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};


BEGIN_MODULE(tree_module0)
	init_entry(mercury__tree__flatten_2__ua0_3_0);
	init_label(mercury__tree__flatten_2__ua0_3_0_i1002);
	init_label(mercury__tree__flatten_2__ua0_3_0_i5);
	init_label(mercury__tree__flatten_2__ua0_3_0_i6);
	init_label(mercury__tree__flatten_2__ua0_3_0_i4);
BEGIN_CODE

/* code for predicate 'flatten_2__ua0'/3 in mode 0 */
Define_static(mercury__tree__flatten_2__ua0_3_0);
	MR_incr_sp_push_msg(2, "tree:flatten_2__ua0/3");
	MR_stackvar(2) = (Word) MR_succip;
Define_label(mercury__tree__flatten_2__ua0_3_0_i1002);
	r3 = MR_tag(r1);
	if ((r3 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__tree__flatten_2__ua0_3_0_i4);
	if ((r3 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__tree__flatten_2__ua0_3_0_i5);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__tree__flatten_2__ua0_3_0_i5);
	MR_stackvar(1) = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 1);
	localcall(mercury__tree__flatten_2__ua0_3_0,
		LABEL(mercury__tree__flatten_2__ua0_3_0_i6),
		STATIC(mercury__tree__flatten_2__ua0_3_0));
Define_label(mercury__tree__flatten_2__ua0_3_0_i6);
	update_prof_current_proc(LABEL(mercury__tree__flatten_2__ua0_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	GOTO_LABEL(mercury__tree__flatten_2__ua0_3_0_i1002);
Define_label(mercury__tree__flatten_2__ua0_3_0_i4);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__tree__flatten_2__ua0_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE


BEGIN_MODULE(tree_module1)
	init_entry(mercury__tree__flatten_2_0);
BEGIN_CODE

/* code for predicate 'flatten'/2 in mode 0 */
Define_entry(mercury__tree__flatten_2_0);
	r1 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tailcall(STATIC(mercury__tree__flatten_2__ua0_3_0),
		ENTRY(mercury__tree__flatten_2_0));
END_MODULE


BEGIN_MODULE(tree_module2)
	init_entry(mercury__tree__is_empty_1_0);
	init_label(mercury__tree__is_empty_1_0_i1007);
	init_label(mercury__tree__is_empty_1_0_i5);
	init_label(mercury__tree__is_empty_1_0_i1003);
	init_label(mercury__tree__is_empty_1_0_i1);
BEGIN_CODE

/* code for predicate 'is_empty'/1 in mode 0 */
Define_entry(mercury__tree__is_empty_1_0);
	MR_incr_sp_push_msg(3, "tree:is_empty/1");
	MR_stackvar(3) = (Word) MR_succip;
Define_label(mercury__tree__is_empty_1_0_i1007);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__tree__is_empty_1_0_i1003);
	if ((MR_tag(r2) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__tree__is_empty_1_0_i1);
	MR_stackvar(1) = MR_const_field(MR_mktag(2), r2, (Integer) 1);
	r2 = MR_const_field(MR_mktag(2), r2, (Integer) 0);
	MR_stackvar(2) = r1;
	localcall(mercury__tree__is_empty_1_0,
		LABEL(mercury__tree__is_empty_1_0_i5),
		ENTRY(mercury__tree__is_empty_1_0));
Define_label(mercury__tree__is_empty_1_0_i5);
	update_prof_current_proc(LABEL(mercury__tree__is_empty_1_0));
	if (!(r1))
		GOTO_LABEL(mercury__tree__is_empty_1_0_i1);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	GOTO_LABEL(mercury__tree__is_empty_1_0_i1007);
Define_label(mercury__tree__is_empty_1_0_i1003);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__tree__is_empty_1_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(tree_module3)
	init_entry(mercury__tree__tree_of_lists_is_empty_1_0);
	init_label(mercury__tree__tree_of_lists_is_empty_1_0_i1008);
	init_label(mercury__tree__tree_of_lists_is_empty_1_0_i7);
	init_label(mercury__tree__tree_of_lists_is_empty_1_0_i4);
	init_label(mercury__tree__tree_of_lists_is_empty_1_0_i1004);
	init_label(mercury__tree__tree_of_lists_is_empty_1_0_i1);
BEGIN_CODE

/* code for predicate 'tree_of_lists_is_empty'/1 in mode 0 */
Define_entry(mercury__tree__tree_of_lists_is_empty_1_0);
	MR_incr_sp_push_msg(3, "tree:tree_of_lists_is_empty/1");
	MR_stackvar(3) = (Word) MR_succip;
Define_label(mercury__tree__tree_of_lists_is_empty_1_0_i1008);
	r3 = MR_tag(r2);
	if ((r3 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__tree__tree_of_lists_is_empty_1_0_i4);
	if ((r3 != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__tree__tree_of_lists_is_empty_1_0_i1004);
	MR_stackvar(1) = MR_const_field(MR_mktag(2), r2, (Integer) 1);
	r2 = MR_const_field(MR_mktag(2), r2, (Integer) 0);
	MR_stackvar(2) = r1;
	localcall(mercury__tree__tree_of_lists_is_empty_1_0,
		LABEL(mercury__tree__tree_of_lists_is_empty_1_0_i7),
		ENTRY(mercury__tree__tree_of_lists_is_empty_1_0));
Define_label(mercury__tree__tree_of_lists_is_empty_1_0_i7);
	update_prof_current_proc(LABEL(mercury__tree__tree_of_lists_is_empty_1_0));
	if (!(r1))
		GOTO_LABEL(mercury__tree__tree_of_lists_is_empty_1_0_i1);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	GOTO_LABEL(mercury__tree__tree_of_lists_is_empty_1_0_i1008);
Define_label(mercury__tree__tree_of_lists_is_empty_1_0_i4);
	if (((Integer) MR_const_field(MR_mktag(1), r2, (Integer) 0) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__tree__tree_of_lists_is_empty_1_0_i1);
Define_label(mercury__tree__tree_of_lists_is_empty_1_0_i1004);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__tree__tree_of_lists_is_empty_1_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE

Declare_entry(mercury__unify_2_0);

BEGIN_MODULE(tree_module4)
	init_entry(mercury____Unify___tree__tree_1_0);
	init_label(mercury____Unify___tree__tree_1_0_i1006);
	init_label(mercury____Unify___tree__tree_1_0_i8);
	init_label(mercury____Unify___tree__tree_1_0_i10);
	init_label(mercury____Unify___tree__tree_1_0_i4);
	init_label(mercury____Unify___tree__tree_1_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___tree__tree_1_0);
	MR_incr_sp_push_msg(4, "tree:__Unify__/2");
	MR_stackvar(4) = (Word) MR_succip;
Define_label(mercury____Unify___tree__tree_1_0_i1006);
	if ((MR_tag(r2) == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Unify___tree__tree_1_0_i4);
	if ((MR_tag(r2) == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Unify___tree__tree_1_0_i8);
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Unify___tree__tree_1_0_i1);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Unify___tree__tree_1_0_i8);
	if ((MR_tag(r3) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Unify___tree__tree_1_0_i1);
	MR_stackvar(1) = MR_const_field(MR_mktag(2), r2, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(2), r3, (Integer) 1);
	r2 = MR_const_field(MR_mktag(2), r2, (Integer) 0);
	r3 = MR_const_field(MR_mktag(2), r3, (Integer) 0);
	MR_stackvar(3) = r1;
	localcall(mercury____Unify___tree__tree_1_0,
		LABEL(mercury____Unify___tree__tree_1_0_i10),
		ENTRY(mercury____Unify___tree__tree_1_0));
Define_label(mercury____Unify___tree__tree_1_0_i10);
	update_prof_current_proc(LABEL(mercury____Unify___tree__tree_1_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___tree__tree_1_0_i1);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	GOTO_LABEL(mercury____Unify___tree__tree_1_0_i1006);
Define_label(mercury____Unify___tree__tree_1_0_i4);
	if ((MR_tag(r3) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Unify___tree__tree_1_0_i1);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r3 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__unify_2_0),
		ENTRY(mercury____Unify___tree__tree_1_0));
Define_label(mercury____Unify___tree__tree_1_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE


BEGIN_MODULE(tree_module5)
	init_entry(mercury____Index___tree__tree_1_0);
	init_label(mercury____Index___tree__tree_1_0_i5);
	init_label(mercury____Index___tree__tree_1_0_i4);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___tree__tree_1_0);
	r3 = MR_tag(r2);
	if ((r3 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Index___tree__tree_1_0_i4);
	if ((r3 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Index___tree__tree_1_0_i5);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Index___tree__tree_1_0_i5);
	r1 = (Integer) 2;
	proceed();
Define_label(mercury____Index___tree__tree_1_0_i4);
	r1 = (Integer) 1;
	proceed();
END_MODULE

Declare_entry(mercury__compare_3_3);
Declare_entry(mercury__compare_error_0_0);

BEGIN_MODULE(tree_module6)
	init_entry(mercury____Compare___tree__tree_1_0);
	init_label(mercury____Compare___tree__tree_1_0_i1012);
	init_label(mercury____Compare___tree__tree_1_0_i5);
	init_label(mercury____Compare___tree__tree_1_0_i4);
	init_label(mercury____Compare___tree__tree_1_0_i2);
	init_label(mercury____Compare___tree__tree_1_0_i9);
	init_label(mercury____Compare___tree__tree_1_0_i8);
	init_label(mercury____Compare___tree__tree_1_0_i6);
	init_label(mercury____Compare___tree__tree_1_0_i10);
	init_label(mercury____Compare___tree__tree_1_0_i11);
	init_label(mercury____Compare___tree__tree_1_0_i19);
	init_label(mercury____Compare___tree__tree_1_0_i22);
	init_label(mercury____Compare___tree__tree_1_0_i16);
	init_label(mercury____Compare___tree__tree_1_0_i13);
	init_label(mercury____Compare___tree__tree_1_0_i31);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___tree__tree_1_0);
	MR_incr_sp_push_msg(4, "tree:__Compare__/3");
	MR_stackvar(4) = (Word) MR_succip;
Define_label(mercury____Compare___tree__tree_1_0_i1012);
	if ((MR_tag(r2) == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___tree__tree_1_0_i4);
	if ((MR_tag(r2) == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Compare___tree__tree_1_0_i5);
	MR_stackvar(3) = r1;
	r1 = r2;
	r2 = r3;
	r3 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___tree__tree_1_0_i2);
Define_label(mercury____Compare___tree__tree_1_0_i5);
	MR_stackvar(3) = r1;
	r1 = r2;
	r2 = r3;
	r3 = (Integer) 2;
	GOTO_LABEL(mercury____Compare___tree__tree_1_0_i2);
Define_label(mercury____Compare___tree__tree_1_0_i4);
	MR_stackvar(3) = r1;
	r1 = r2;
	r2 = r3;
	r3 = (Integer) 1;
Define_label(mercury____Compare___tree__tree_1_0_i2);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_tag(r2);
	if ((MR_tempr1 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___tree__tree_1_0_i8);
	if ((MR_tempr1 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Compare___tree__tree_1_0_i9);
	r4 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___tree__tree_1_0_i6);
	}
Define_label(mercury____Compare___tree__tree_1_0_i9);
	r4 = (Integer) 2;
	GOTO_LABEL(mercury____Compare___tree__tree_1_0_i6);
Define_label(mercury____Compare___tree__tree_1_0_i8);
	r4 = (Integer) 1;
Define_label(mercury____Compare___tree__tree_1_0_i6);
	if (((Integer) r3 >= (Integer) r4))
		GOTO_LABEL(mercury____Compare___tree__tree_1_0_i10);
	r1 = (Integer) 1;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___tree__tree_1_0_i10);
	if (((Integer) r3 <= (Integer) r4))
		GOTO_LABEL(mercury____Compare___tree__tree_1_0_i11);
	r1 = (Integer) 2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___tree__tree_1_0_i11);
	r3 = MR_tag(r1);
	if ((r3 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___tree__tree_1_0_i16);
	if ((r3 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Compare___tree__tree_1_0_i19);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury____Compare___tree__tree_1_0_i13);
	r1 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury____Compare___tree__tree_1_0_i19);
	if ((MR_tag(r2) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury____Compare___tree__tree_1_0_i13);
	r3 = MR_const_field(MR_mktag(2), r2, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(2), r2, (Integer) 1);
	r2 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(2), r1, (Integer) 1);
	r1 = MR_stackvar(3);
	localcall(mercury____Compare___tree__tree_1_0,
		LABEL(mercury____Compare___tree__tree_1_0_i22),
		ENTRY(mercury____Compare___tree__tree_1_0));
Define_label(mercury____Compare___tree__tree_1_0_i22);
	update_prof_current_proc(LABEL(mercury____Compare___tree__tree_1_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___tree__tree_1_0_i31);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	GOTO_LABEL(mercury____Compare___tree__tree_1_0_i1012);
Define_label(mercury____Compare___tree__tree_1_0_i16);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___tree__tree_1_0_i13);
	r3 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__compare_3_3),
		ENTRY(mercury____Compare___tree__tree_1_0));
Define_label(mercury____Compare___tree__tree_1_0_i13);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__compare_error_0_0),
		ENTRY(mercury____Compare___tree__tree_1_0));
Define_label(mercury____Compare___tree__tree_1_0_i31);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__tree_maybe_bunch_0(void)
{
	tree_module0();
	tree_module1();
	tree_module2();
	tree_module3();
	tree_module4();
	tree_module5();
	tree_module6();
}

#endif

void mercury__tree__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__tree__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__tree_maybe_bunch_0();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_tree__type_ctor_info_tree_1,
			tree__tree_1_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
