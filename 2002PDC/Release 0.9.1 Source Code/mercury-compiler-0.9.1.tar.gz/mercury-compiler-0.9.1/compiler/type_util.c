/*
** Automatically generated from `type_util.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__type_util__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury____Index___type_util__ctor_defn_0__ua0_2_0);
Declare_static(mercury__type_util__type_id_arity__ua0_3_0);
Declare_static(mercury__type_util__type_id_name__ua0_3_0);
Declare_static(mercury__type_util__type_id_module__ua0_3_0);
Declare_static(mercury__type_util__IntroducedFrom__pred__is_existq_cons__697__5_2_0);
Declare_static(mercury__type_util__IntroducedFrom__pred__apply_rec_subst_to_constraint_proofs__1173__4_5_0);
Declare_label(mercury__type_util__IntroducedFrom__pred__apply_rec_subst_to_constraint_proofs__1173__4_5_0_i2);
Declare_label(mercury__type_util__IntroducedFrom__pred__apply_rec_subst_to_constraint_proofs__1173__4_5_0_i4);
Declare_label(mercury__type_util__IntroducedFrom__pred__apply_rec_subst_to_constraint_proofs__1173__4_5_0_i5);
Declare_static(mercury__type_util__IntroducedFrom__pred__apply_subst_to_constraint_proofs__1153__3_5_0);
Declare_label(mercury__type_util__IntroducedFrom__pred__apply_subst_to_constraint_proofs__1153__3_5_0_i2);
Declare_label(mercury__type_util__IntroducedFrom__pred__apply_subst_to_constraint_proofs__1153__3_5_0_i4);
Declare_label(mercury__type_util__IntroducedFrom__pred__apply_subst_to_constraint_proofs__1153__3_5_0_i5);
Declare_static(mercury__type_util__IntroducedFrom__pred__get_cons_id_arg_types__677__2_2_0);
Declare_static(mercury__type_util__IntroducedFrom__pred__get_cons_id_arg_types__663__1_2_0);
Define_extern_entry(mercury__type_util__type_is_atomic_2_0);
Declare_label(mercury__type_util__type_is_atomic_2_0_i2);
Declare_label(mercury__type_util__type_is_atomic_2_0_i1);
Define_extern_entry(mercury__type_util__type_is_higher_order_4_0);
Declare_label(mercury__type_util__type_is_higher_order_4_0_i14);
Declare_label(mercury__type_util__type_is_higher_order_4_0_i9);
Declare_label(mercury__type_util__type_is_higher_order_4_0_i20);
Declare_label(mercury__type_util__type_is_higher_order_4_0_i24);
Declare_label(mercury__type_util__type_is_higher_order_4_0_i2);
Declare_label(mercury__type_util__type_is_higher_order_4_0_i30);
Declare_label(mercury__type_util__type_is_higher_order_4_0_i25);
Declare_label(mercury__type_util__type_is_higher_order_4_0_i36);
Declare_label(mercury__type_util__type_is_higher_order_4_0_i1);
Define_extern_entry(mercury__type_util__type_id_is_higher_order_3_0);
Declare_label(mercury__type_util__type_id_is_higher_order_3_0_i3);
Declare_label(mercury__type_util__type_id_is_higher_order_3_0_i6);
Declare_label(mercury__type_util__type_id_is_higher_order_3_0_i2);
Declare_label(mercury__type_util__type_id_is_higher_order_3_0_i9);
Declare_label(mercury__type_util__type_id_is_higher_order_3_0_i1);
Define_extern_entry(mercury__type_util__type_has_user_defined_equality_pred_3_0);
Declare_label(mercury__type_util__type_has_user_defined_equality_pred_3_0_i2);
Declare_label(mercury__type_util__type_has_user_defined_equality_pred_3_0_i3);
Declare_label(mercury__type_util__type_has_user_defined_equality_pred_3_0_i5);
Declare_label(mercury__type_util__type_has_user_defined_equality_pred_3_0_i7);
Declare_label(mercury__type_util__type_has_user_defined_equality_pred_3_0_i1);
Define_extern_entry(mercury__type_util__is_dummy_argument_type_1_0);
Declare_label(mercury__type_util__is_dummy_argument_type_1_0_i13);
Declare_label(mercury__type_util__is_dummy_argument_type_1_0_i15);
Declare_label(mercury__type_util__is_dummy_argument_type_1_0_i1028);
Declare_label(mercury__type_util__is_dummy_argument_type_1_0_i1);
Define_extern_entry(mercury__type_util__type_is_aditi_state_1_0);
Declare_label(mercury__type_util__type_is_aditi_state_1_0_i2);
Declare_label(mercury__type_util__type_is_aditi_state_1_0_i4);
Declare_label(mercury__type_util__type_is_aditi_state_1_0_i1);
Define_extern_entry(mercury__type_util__remove_aditi_state_3_0);
Declare_label(mercury__type_util__remove_aditi_state_3_0_i1004);
Declare_label(mercury__type_util__remove_aditi_state_3_0_i3);
Declare_label(mercury__type_util__remove_aditi_state_3_0_i11);
Declare_label(mercury__type_util__remove_aditi_state_3_0_i9);
Declare_label(mercury__type_util__remove_aditi_state_3_0_i14);
Declare_label(mercury__type_util__remove_aditi_state_3_0_i8);
Define_extern_entry(mercury__type_util__type_id_is_hand_defined_1_0);
Declare_label(mercury__type_util__type_id_is_hand_defined_1_0_i7);
Declare_label(mercury__type_util__type_id_is_hand_defined_1_0_i9);
Declare_label(mercury__type_util__type_id_is_hand_defined_1_0_i4);
Declare_label(mercury__type_util__type_id_is_hand_defined_1_0_i15);
Declare_label(mercury__type_util__type_id_is_hand_defined_1_0_i18);
Declare_label(mercury__type_util__type_id_is_hand_defined_1_0_i22);
Declare_label(mercury__type_util__type_id_is_hand_defined_1_0_i26);
Declare_label(mercury__type_util__type_id_is_hand_defined_1_0_i31);
Declare_label(mercury__type_util__type_id_is_hand_defined_1_0_i1);
Define_extern_entry(mercury__type_util__is_introduced_type_info_type_1_0);
Declare_label(mercury__type_util__is_introduced_type_info_type_1_0_i2);
Declare_label(mercury__type_util__is_introduced_type_info_type_1_0_i6);
Declare_label(mercury__type_util__is_introduced_type_info_type_1_0_i7);
Declare_label(mercury__type_util__is_introduced_type_info_type_1_0_i8);
Declare_label(mercury__type_util__is_introduced_type_info_type_1_0_i10);
Declare_label(mercury__type_util__is_introduced_type_info_type_1_0_i1);
Define_extern_entry(mercury__type_util__remove_new_prefix_2_0);
Declare_label(mercury__type_util__remove_new_prefix_2_0_i4);
Declare_label(mercury__type_util__remove_new_prefix_2_0_i3);
Declare_label(mercury__type_util__remove_new_prefix_2_0_i6);
Declare_label(mercury__type_util__remove_new_prefix_2_0_i1);
Define_extern_entry(mercury__type_util__remove_new_prefix_2_1);
Declare_label(mercury__type_util__remove_new_prefix_2_1_i4);
Declare_label(mercury__type_util__remove_new_prefix_2_1_i3);
Declare_label(mercury__type_util__remove_new_prefix_2_1_i5);
Define_extern_entry(mercury__type_util__classify_type_3_0);
Declare_label(mercury__type_util__classify_type_3_0_i4);
Declare_label(mercury__type_util__classify_type_3_0_i6);
Declare_label(mercury__type_util__classify_type_3_0_i10);
Declare_label(mercury__type_util__classify_type_3_0_i14);
Declare_label(mercury__type_util__classify_type_3_0_i18);
Declare_label(mercury__type_util__classify_type_3_0_i24);
Declare_label(mercury__type_util__classify_type_3_0_i22);
Declare_label(mercury__type_util__classify_type_3_0_i27);
Declare_label(mercury__type_util__classify_type_3_0_i28);
Declare_label(mercury__type_util__classify_type_3_0_i30);
Declare_label(mercury__type_util__classify_type_3_0_i26);
Declare_label(mercury__type_util__classify_type_3_0_i3);
Define_extern_entry(mercury__type_util__type_to_type_id_3_0);
Declare_label(mercury__type_util__type_to_type_id_3_0_i2);
Declare_label(mercury__type_util__type_to_type_id_3_0_i4);
Declare_label(mercury__type_util__type_to_type_id_3_0_i7);
Declare_label(mercury__type_util__type_to_type_id_3_0_i9);
Declare_label(mercury__type_util__type_to_type_id_3_0_i10);
Declare_label(mercury__type_util__type_to_type_id_3_0_i12);
Declare_label(mercury__type_util__type_to_type_id_3_0_i11);
Declare_label(mercury__type_util__type_to_type_id_3_0_i14);
Declare_label(mercury__type_util__type_to_type_id_3_0_i1017);
Declare_label(mercury__type_util__type_to_type_id_3_0_i5);
Declare_label(mercury__type_util__type_to_type_id_3_0_i16);
Declare_label(mercury__type_util__type_to_type_id_3_0_i17);
Declare_label(mercury__type_util__type_to_type_id_3_0_i21);
Declare_label(mercury__type_util__type_to_type_id_3_0_i19);
Declare_label(mercury__type_util__type_to_type_id_3_0_i1);
Define_extern_entry(mercury__type_util__var_2_0);
Declare_label(mercury__type_util__var_2_0_i1);
Define_extern_entry(mercury__type_util__var_2_1);
Define_extern_entry(mercury__type_util__construct_type_3_0);
Declare_label(mercury__type_util__construct_type_3_0_i2);
Define_extern_entry(mercury__type_util__construct_type_4_0);
Declare_label(mercury__type_util__construct_type_4_0_i4);
Declare_label(mercury__type_util__construct_type_4_0_i7);
Declare_label(mercury__type_util__construct_type_4_0_i9);
Declare_label(mercury__type_util__construct_type_4_0_i2);
Define_extern_entry(mercury__type_util__construct_higher_order_type_4_0);
Declare_label(mercury__type_util__construct_higher_order_type_4_0_i3);
Declare_label(mercury__type_util__construct_higher_order_type_4_0_i5);
Define_extern_entry(mercury__type_util__construct_higher_order_pred_type_3_0);
Declare_label(mercury__type_util__construct_higher_order_pred_type_3_0_i2);
Declare_label(mercury__type_util__construct_higher_order_pred_type_3_0_i3);
Declare_label(mercury__type_util__construct_higher_order_pred_type_3_0_i7);
Declare_label(mercury__type_util__construct_higher_order_pred_type_3_0_i6);
Declare_label(mercury__type_util__construct_higher_order_pred_type_3_0_i8);
Declare_label(mercury__type_util__construct_higher_order_pred_type_3_0_i4);
Define_extern_entry(mercury__type_util__construct_higher_order_func_type_4_0);
Declare_label(mercury__type_util__construct_higher_order_func_type_4_0_i2);
Declare_label(mercury__type_util__construct_higher_order_func_type_4_0_i3);
Declare_label(mercury__type_util__construct_higher_order_func_type_4_0_i5);
Declare_label(mercury__type_util__construct_higher_order_func_type_4_0_i7);
Declare_label(mercury__type_util__construct_higher_order_func_type_4_0_i6);
Declare_label(mercury__type_util__construct_higher_order_func_type_4_0_i8);
Define_extern_entry(mercury__fn__type_util__int_type_0_0);
Declare_label(mercury__fn__type_util__int_type_0_0_i2);
Define_extern_entry(mercury__fn__type_util__string_type_0_0);
Declare_label(mercury__fn__type_util__string_type_0_0_i2);
Define_extern_entry(mercury__fn__type_util__float_type_0_0);
Declare_label(mercury__fn__type_util__float_type_0_0_i2);
Define_extern_entry(mercury__fn__type_util__char_type_0_0);
Declare_label(mercury__fn__type_util__char_type_0_0_i2);
Define_extern_entry(mercury__type_util__make_type_id_3_0);
Declare_label(mercury__type_util__make_type_id_3_0_i1);
Define_extern_entry(mercury__type_util__type_id_module_3_0);
Define_extern_entry(mercury__type_util__type_id_name_3_0);
Define_extern_entry(mercury__type_util__type_id_arity_3_0);
Define_extern_entry(mercury__type_util__type_constructors_3_0);
Declare_label(mercury__type_util__type_constructors_3_0_i2);
Declare_label(mercury__type_util__type_constructors_3_0_i4);
Declare_label(mercury__type_util__type_constructors_3_0_i5);
Declare_label(mercury__type_util__type_constructors_3_0_i7);
Declare_label(mercury__type_util__type_constructors_3_0_i8);
Declare_label(mercury__type_util__type_constructors_3_0_i12);
Declare_label(mercury__type_util__type_constructors_3_0_i13);
Declare_label(mercury__type_util__type_constructors_3_0_i14);
Declare_label(mercury__type_util__type_constructors_3_0_i15);
Declare_label(mercury__type_util__type_constructors_3_0_i1);
Define_extern_entry(mercury__type_util__get_cons_id_arg_types_4_0);
Declare_label(mercury__type_util__get_cons_id_arg_types_4_0_i3);
Declare_label(mercury__type_util__get_cons_id_arg_types_4_0_i5);
Declare_label(mercury__type_util__get_cons_id_arg_types_4_0_i6);
Declare_label(mercury__type_util__get_cons_id_arg_types_4_0_i8);
Declare_label(mercury__type_util__get_cons_id_arg_types_4_0_i10);
Declare_label(mercury__type_util__get_cons_id_arg_types_4_0_i14);
Declare_label(mercury__type_util__get_cons_id_arg_types_4_0_i15);
Declare_label(mercury__type_util__get_cons_id_arg_types_4_0_i16);
Declare_label(mercury__type_util__get_cons_id_arg_types_4_0_i17);
Declare_label(mercury__type_util__get_cons_id_arg_types_4_0_i18);
Declare_label(mercury__type_util__get_cons_id_arg_types_4_0_i19);
Declare_label(mercury__type_util__get_cons_id_arg_types_4_0_i2);
Define_extern_entry(mercury__type_util__get_existq_cons_defn_4_0);
Declare_label(mercury__type_util__get_existq_cons_defn_4_0_i2);
Declare_label(mercury__type_util__get_existq_cons_defn_4_0_i4);
Declare_label(mercury__type_util__get_existq_cons_defn_4_0_i5);
Declare_label(mercury__type_util__get_existq_cons_defn_4_0_i7);
Declare_label(mercury__type_util__get_existq_cons_defn_4_0_i9);
Declare_label(mercury__type_util__get_existq_cons_defn_4_0_i13);
Declare_label(mercury__type_util__get_existq_cons_defn_4_0_i14);
Declare_label(mercury__type_util__get_existq_cons_defn_4_0_i16);
Declare_label(mercury__type_util__get_existq_cons_defn_4_0_i17);
Declare_label(mercury__type_util__get_existq_cons_defn_4_0_i18);
Declare_label(mercury__type_util__get_existq_cons_defn_4_0_i19);
Declare_label(mercury__type_util__get_existq_cons_defn_4_0_i1013);
Declare_label(mercury__type_util__get_existq_cons_defn_4_0_i1);
Define_extern_entry(mercury__type_util__is_existq_cons_3_0);
Declare_label(mercury__type_util__is_existq_cons_3_0_i2);
Declare_label(mercury__type_util__is_existq_cons_3_0_i4);
Declare_label(mercury__type_util__is_existq_cons_3_0_i5);
Declare_label(mercury__type_util__is_existq_cons_3_0_i7);
Declare_label(mercury__type_util__is_existq_cons_3_0_i9);
Declare_label(mercury__type_util__is_existq_cons_3_0_i1);
Define_extern_entry(mercury__type_util__type_is_no_tag_type_3_0);
Declare_label(mercury__type_util__type_is_no_tag_type_3_0_i7);
Declare_label(mercury__type_util__type_is_no_tag_type_3_0_i1014);
Declare_label(mercury__type_util__type_is_no_tag_type_3_0_i1);
Define_extern_entry(mercury__type_util__type_unify_5_0);
Declare_label(mercury__type_util__type_unify_5_0_i1023);
Declare_label(mercury__type_util__type_unify_5_0_i6);
Declare_label(mercury__type_util__type_unify_5_0_i7);
Declare_label(mercury__type_util__type_unify_5_0_i8);
Declare_label(mercury__type_util__type_unify_5_0_i5);
Declare_label(mercury__type_util__type_unify_5_0_i13);
Declare_label(mercury__type_util__type_unify_5_0_i12);
Declare_label(mercury__type_util__type_unify_5_0_i18);
Declare_label(mercury__type_util__type_unify_5_0_i21);
Declare_label(mercury__type_util__type_unify_5_0_i3);
Declare_label(mercury__type_util__type_unify_5_0_i28);
Declare_label(mercury__type_util__type_unify_5_0_i27);
Declare_label(mercury__type_util__type_unify_5_0_i33);
Declare_label(mercury__type_util__type_unify_5_0_i36);
Declare_label(mercury__type_util__type_unify_5_0_i26);
Declare_label(mercury__type_util__type_unify_5_0_i41);
Declare_label(mercury__type_util__type_unify_5_0_i40);
Declare_label(mercury__type_util__type_unify_5_0_i46);
Declare_label(mercury__type_util__type_unify_5_0_i45);
Declare_label(mercury__type_util__type_unify_5_0_i51);
Declare_label(mercury__type_util__type_unify_5_0_i54);
Declare_label(mercury__type_util__type_unify_5_0_i53);
Declare_label(mercury__type_util__type_unify_5_0_i58);
Declare_label(mercury__type_util__type_unify_5_0_i62);
Declare_label(mercury__type_util__type_unify_5_0_i59);
Declare_label(mercury__type_util__type_unify_5_0_i60);
Declare_label(mercury__type_util__type_unify_5_0_i65);
Declare_label(mercury__type_util__type_unify_5_0_i50);
Declare_label(mercury__type_util__type_unify_5_0_i71);
Declare_label(mercury__type_util__type_unify_5_0_i73);
Declare_label(mercury__type_util__type_unify_5_0_i77);
Declare_label(mercury__type_util__type_unify_5_0_i74);
Declare_label(mercury__type_util__type_unify_5_0_i75);
Declare_label(mercury__type_util__type_unify_5_0_i80);
Declare_label(mercury__type_util__type_unify_5_0_i70);
Declare_label(mercury__type_util__type_unify_5_0_i85);
Declare_label(mercury__type_util__type_unify_5_0_i84);
Declare_label(mercury__type_util__type_unify_5_0_i87);
Declare_label(mercury__type_util__type_unify_5_0_i1);
Define_extern_entry(mercury__type_util__type_unify_list_5_0);
Declare_label(mercury__type_util__type_unify_list_5_0_i1004);
Declare_label(mercury__type_util__type_unify_list_5_0_i3);
Declare_label(mercury__type_util__type_unify_list_5_0_i6);
Declare_label(mercury__type_util__type_unify_list_5_0_i1);
Define_extern_entry(mercury__type_util__vars_2_0);
Define_extern_entry(mercury__type_util__type_list_subsumes_3_0);
Declare_label(mercury__type_util__type_list_subsumes_3_0_i2);
Declare_label(mercury__type_util__type_list_subsumes_3_0_i3);
Define_extern_entry(mercury__type_util__apply_substitution_to_type_map_3_0);
Declare_label(mercury__type_util__apply_substitution_to_type_map_3_0_i3);
Declare_label(mercury__type_util__apply_substitution_to_type_map_3_0_i2);
Declare_label(mercury__type_util__apply_substitution_to_type_map_3_0_i5);
Define_extern_entry(mercury__type_util__apply_rec_substitution_to_type_map_3_0);
Declare_label(mercury__type_util__apply_rec_substitution_to_type_map_3_0_i3);
Declare_label(mercury__type_util__apply_rec_substitution_to_type_map_3_0_i2);
Declare_label(mercury__type_util__apply_rec_substitution_to_type_map_3_0_i5);
Define_extern_entry(mercury__type_util__apply_substitutions_to_var_map_5_0);
Declare_label(mercury__type_util__apply_substitutions_to_var_map_5_0_i3);
Declare_label(mercury__type_util__apply_substitutions_to_var_map_5_0_i5);
Declare_label(mercury__type_util__apply_substitutions_to_var_map_5_0_i7);
Declare_label(mercury__type_util__apply_substitutions_to_var_map_5_0_i2);
Declare_label(mercury__type_util__apply_substitutions_to_var_map_5_0_i9);
Declare_label(mercury__type_util__apply_substitutions_to_var_map_5_0_i10);
Define_extern_entry(mercury__type_util__apply_substitutions_to_typeclass_var_map_5_0);
Declare_label(mercury__type_util__apply_substitutions_to_typeclass_var_map_5_0_i2);
Declare_label(mercury__type_util__apply_substitutions_to_typeclass_var_map_5_0_i3);
Define_extern_entry(mercury__type_util__apply_rec_subst_to_constraints_3_0);
Declare_label(mercury__type_util__apply_rec_subst_to_constraints_3_0_i2);
Declare_label(mercury__type_util__apply_rec_subst_to_constraints_3_0_i3);
Define_extern_entry(mercury__type_util__apply_rec_subst_to_constraint_list_3_0);
Define_extern_entry(mercury__type_util__apply_rec_subst_to_constraint_3_0);
Declare_label(mercury__type_util__apply_rec_subst_to_constraint_3_0_i2);
Declare_label(mercury__type_util__apply_rec_subst_to_constraint_3_0_i3);
Define_extern_entry(mercury__type_util__apply_subst_to_constraints_3_0);
Declare_label(mercury__type_util__apply_subst_to_constraints_3_0_i2);
Declare_label(mercury__type_util__apply_subst_to_constraints_3_0_i3);
Define_extern_entry(mercury__type_util__apply_subst_to_constraint_list_3_0);
Define_extern_entry(mercury__type_util__apply_subst_to_constraint_3_0);
Declare_label(mercury__type_util__apply_subst_to_constraint_3_0_i2);
Define_extern_entry(mercury__type_util__apply_subst_to_constraint_proofs_3_0);
Declare_label(mercury__type_util__apply_subst_to_constraint_proofs_3_0_i2);
Define_extern_entry(mercury__type_util__apply_rec_subst_to_constraint_proofs_3_0);
Declare_label(mercury__type_util__apply_rec_subst_to_constraint_proofs_3_0_i2);
Define_extern_entry(mercury__type_util__apply_variable_renaming_to_constraints_3_0);
Declare_label(mercury__type_util__apply_variable_renaming_to_constraints_3_0_i2);
Declare_label(mercury__type_util__apply_variable_renaming_to_constraints_3_0_i3);
Define_extern_entry(mercury__type_util__apply_variable_renaming_to_constraint_list_3_0);
Define_extern_entry(mercury__type_util__apply_variable_renaming_to_constraint_3_0);
Declare_label(mercury__type_util__apply_variable_renaming_to_constraint_3_0_i2);
Define_extern_entry(mercury__type_util__apply_partial_map_to_list_3_0);
Declare_label(mercury__type_util__apply_partial_map_to_list_3_0_i6);
Declare_label(mercury__type_util__apply_partial_map_to_list_3_0_i4);
Declare_label(mercury__type_util__apply_partial_map_to_list_3_0_i9);
Declare_label(mercury__type_util__apply_partial_map_to_list_3_0_i3);
Define_extern_entry(mercury__type_util__strip_prog_contexts_2_0);
Define_extern_entry(mercury__type_util__strip_prog_context_2_0);
Declare_label(mercury__type_util__strip_prog_context_2_0_i4);
Declare_label(mercury__type_util__strip_prog_context_2_0_i5);
Declare_label(mercury__type_util__strip_prog_context_2_0_i3);
Define_extern_entry(mercury__fn__type_util__cons_id_adjusted_arity_3_0);
Declare_label(mercury__fn__type_util__cons_id_adjusted_arity_3_0_i2);
Declare_label(mercury__fn__type_util__cons_id_adjusted_arity_3_0_i5);
Declare_label(mercury__fn__type_util__cons_id_adjusted_arity_3_0_i7);
Declare_label(mercury__fn__type_util__cons_id_adjusted_arity_3_0_i8);
Declare_label(mercury__fn__type_util__cons_id_adjusted_arity_3_0_i9);
Declare_label(mercury__fn__type_util__cons_id_adjusted_arity_3_0_i10);
Declare_label(mercury__fn__type_util__cons_id_adjusted_arity_3_0_i3);
Define_extern_entry(mercury__type_util__constraint_list_get_tvars_2_0);
Declare_label(mercury__type_util__constraint_list_get_tvars_2_0_i2);
Define_extern_entry(mercury__type_util__constraint_get_tvars_2_0);
Declare_static(mercury__type_util__substitute_type_args_2_3_0);
Declare_label(mercury__type_util__substitute_type_args_2_3_0_i4);
Declare_label(mercury__type_util__substitute_type_args_2_3_0_i5);
Declare_label(mercury__type_util__substitute_type_args_2_3_0_i3);
Declare_static(mercury__type_util__substitute_type_args_3_3_0);
Declare_label(mercury__type_util__substitute_type_args_3_3_0_i4);
Declare_label(mercury__type_util__substitute_type_args_3_3_0_i5);
Declare_label(mercury__type_util__substitute_type_args_3_3_0_i3);
Declare_static(mercury__type_util__type_unify_head_type_param_5_0);
Declare_label(mercury__type_util__type_unify_head_type_param_5_0_i1004);
Declare_label(mercury__type_util__type_unify_head_type_param_5_0_i3);
Declare_label(mercury__type_util__type_unify_head_type_param_5_0_i2);
Declare_label(mercury__type_util__type_unify_head_type_param_5_0_i9);
Declare_label(mercury__type_util__type_unify_head_type_param_5_0_i8);
Declare_label(mercury__type_util__type_unify_head_type_param_5_0_i12);
Declare_label(mercury__type_util__type_unify_head_type_param_5_0_i14);
Declare_label(mercury__type_util__type_unify_head_type_param_5_0_i1);
Declare_static(mercury__type_util__apply_substitution_to_type_map_2_4_0);
Declare_label(mercury__type_util__apply_substitution_to_type_map_2_4_0_i1001);
Declare_label(mercury__type_util__apply_substitution_to_type_map_2_4_0_i4);
Declare_label(mercury__type_util__apply_substitution_to_type_map_2_4_0_i5);
Declare_label(mercury__type_util__apply_substitution_to_type_map_2_4_0_i6);
Declare_label(mercury__type_util__apply_substitution_to_type_map_2_4_0_i3);
Declare_static(mercury__type_util__apply_rec_substitution_to_type_map_2_4_0);
Declare_label(mercury__type_util__apply_rec_substitution_to_type_map_2_4_0_i1001);
Declare_label(mercury__type_util__apply_rec_substitution_to_type_map_2_4_0_i4);
Declare_label(mercury__type_util__apply_rec_substitution_to_type_map_2_4_0_i5);
Declare_label(mercury__type_util__apply_rec_substitution_to_type_map_2_4_0_i6);
Declare_label(mercury__type_util__apply_rec_substitution_to_type_map_2_4_0_i3);
Declare_static(mercury__type_util__apply_substitutions_to_var_map_2_7_0);
Declare_label(mercury__type_util__apply_substitutions_to_var_map_2_7_0_i1005);
Declare_label(mercury__type_util__apply_substitutions_to_var_map_2_7_0_i4);
Declare_label(mercury__type_util__apply_substitutions_to_var_map_2_7_0_i5);
Declare_label(mercury__type_util__apply_substitutions_to_var_map_2_7_0_i7);
Declare_label(mercury__type_util__apply_substitutions_to_var_map_2_7_0_i6);
Declare_label(mercury__type_util__apply_substitutions_to_var_map_2_7_0_i10);
Declare_label(mercury__type_util__apply_substitutions_to_var_map_2_7_0_i12);
Declare_label(mercury__type_util__apply_substitutions_to_var_map_2_7_0_i14);
Declare_label(mercury__type_util__apply_substitutions_to_var_map_2_7_0_i16);
Declare_label(mercury__type_util__apply_substitutions_to_var_map_2_7_0_i11);
Declare_label(mercury__type_util__apply_substitutions_to_var_map_2_7_0_i18);
Declare_label(mercury__type_util__apply_substitutions_to_var_map_2_7_0_i19);
Declare_label(mercury__type_util__apply_substitutions_to_var_map_2_7_0_i22);
Declare_label(mercury__type_util__apply_substitutions_to_var_map_2_7_0_i20);
Declare_label(mercury__type_util__apply_substitutions_to_var_map_2_7_0_i3);
Declare_static(mercury__type_util__apply_substitutions_to_typeclass_var_map_2_5_0);
Declare_label(mercury__type_util__apply_substitutions_to_typeclass_var_map_2_5_0_i2);
Declare_label(mercury__type_util__apply_substitutions_to_typeclass_var_map_2_5_0_i3);
Declare_label(mercury__type_util__apply_substitutions_to_typeclass_var_map_2_5_0_i5);
Declare_label(mercury__type_util__apply_substitutions_to_typeclass_var_map_2_5_0_i1005);
Define_extern_entry(mercury____Unify___type_util__builtin_type_0_0);
Declare_label(mercury____Unify___type_util__builtin_type_0_0_i1);
Define_extern_entry(mercury____Index___type_util__builtin_type_0_0);
Define_extern_entry(mercury____Compare___type_util__builtin_type_0_0);
Define_extern_entry(mercury____Unify___type_util__ctor_defn_0_0);
Declare_label(mercury____Unify___type_util__ctor_defn_0_0_i2);
Declare_label(mercury____Unify___type_util__ctor_defn_0_0_i4);
Declare_label(mercury____Unify___type_util__ctor_defn_0_0_i6);
Declare_label(mercury____Unify___type_util__ctor_defn_0_0_i8);
Declare_label(mercury____Unify___type_util__ctor_defn_0_0_i1);
Define_extern_entry(mercury____Index___type_util__ctor_defn_0_0);
Define_extern_entry(mercury____Compare___type_util__ctor_defn_0_0);
Declare_label(mercury____Compare___type_util__ctor_defn_0_0_i3);
Declare_label(mercury____Compare___type_util__ctor_defn_0_0_i7);
Declare_label(mercury____Compare___type_util__ctor_defn_0_0_i11);
Declare_label(mercury____Compare___type_util__ctor_defn_0_0_i15);
Declare_label(mercury____Compare___type_util__ctor_defn_0_0_i22);

const struct MR_TypeCtorInfo_struct mercury_data_type_util__type_ctor_info_builtin_type_0;

const struct MR_TypeCtorInfo_struct mercury_data_type_util__type_ctor_info_ctor_defn_0;

static const struct mercury_data_type_util__common_0_struct {
	String f1;
}  mercury_data_type_util__common_0;

static const struct mercury_data_type_util__common_1_struct {
	Word * f1;
	Word * f2;
}  mercury_data_type_util__common_1;

static const struct mercury_data_type_util__common_2_struct {
	Word * f1;
	Word * f2;
}  mercury_data_type_util__common_2;

static const struct mercury_data_type_util__common_3_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_type_util__common_3;

static const struct mercury_data_type_util__common_4_struct {
	String f1;
}  mercury_data_type_util__common_4;

static const struct mercury_data_type_util__common_5_struct {
	Word * f1;
	String f2;
}  mercury_data_type_util__common_5;

static const struct mercury_data_type_util__common_6_struct {
	Word * f1;
	Integer f2;
}  mercury_data_type_util__common_6;

static const struct mercury_data_type_util__common_7_struct {
	String f1;
}  mercury_data_type_util__common_7;

static const struct mercury_data_type_util__common_8_struct {
	String f1;
}  mercury_data_type_util__common_8;

static const struct mercury_data_type_util__common_9_struct {
	String f1;
}  mercury_data_type_util__common_9;

static const struct mercury_data_type_util__common_10_struct {
	String f1;
}  mercury_data_type_util__common_10;

static const struct mercury_data_type_util__common_11_struct {
	String f1;
}  mercury_data_type_util__common_11;

static const struct mercury_data_type_util__common_12_struct {
	String f1;
}  mercury_data_type_util__common_12;

static const struct mercury_data_type_util__common_13_struct {
	Word * f1;
	Integer f2;
}  mercury_data_type_util__common_13;

static const struct mercury_data_type_util__common_14_struct {
	String f1;
}  mercury_data_type_util__common_14;

static const struct mercury_data_type_util__common_15_struct {
	Word * f1;
	Integer f2;
}  mercury_data_type_util__common_15;

static const struct mercury_data_type_util__common_16_struct {
	String f1;
}  mercury_data_type_util__common_16;

static const struct mercury_data_type_util__common_17_struct {
	Word * f1;
	Integer f2;
}  mercury_data_type_util__common_17;

static const struct mercury_data_type_util__common_18_struct {
	String f1;
}  mercury_data_type_util__common_18;

static const struct mercury_data_type_util__common_19_struct {
	Word * f1;
	Integer f2;
}  mercury_data_type_util__common_19;

static const struct mercury_data_type_util__common_20_struct {
	Word * f1;
	Word * f2;
}  mercury_data_type_util__common_20;

static const struct mercury_data_type_util__common_21_struct {
	Word * f1;
}  mercury_data_type_util__common_21;

static const struct mercury_data_type_util__common_22_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_type_util__common_22;

static const struct mercury_data_type_util__common_23_struct {
	Word * f1;
	Word * f2;
}  mercury_data_type_util__common_23;

static const struct mercury_data_type_util__common_24_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_type_util__common_24;

static const struct mercury_data_type_util__common_25_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_type_util__common_25;

static const struct mercury_data_type_util__common_26_struct {
	Word * f1;
	Word * f2;
}  mercury_data_type_util__common_26;

static const struct mercury_data_type_util__common_27_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_type_util__common_27;

static const struct mercury_data_type_util__common_28_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_type_util__common_28;

static const struct mercury_data_type_util__common_29_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_type_util__common_29;

static const struct mercury_data_type_util__common_30_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
	Word * f13;
}  mercury_data_type_util__common_30;

static const struct mercury_data_type_util__common_31_struct {
	Word * f1;
}  mercury_data_type_util__common_31;

static const struct mercury_data_type_util__common_32_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_type_util__common_32;

static const struct mercury_data_type_util__common_33_struct {
	MR_uint_least32_t f1;
	MR_uint_least32_t f2;
}  mercury_data_type_util__common_33;

static const struct mercury_data_type_util__common_34_struct {
	Word * f1;
	Integer f2;
}  mercury_data_type_util__common_34;

static const struct mercury_data_type_util__common_35_struct {
	Word * f1;
	Integer f2;
}  mercury_data_type_util__common_35;

static const struct mercury_data_type_util__common_36_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_type_util__common_36;

static const struct mercury_data_type_util__common_37_struct {
	Word * f1;
	Code * f2;
	Integer f3;
	Word * f4;
}  mercury_data_type_util__common_37;

static const struct mercury_data_type_util__common_38_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_type_util__common_38;

static const struct mercury_data_type_util__common_39_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_type_util__common_39;

static const struct mercury_data_type_util__common_40_struct {
	Word * f1;
}  mercury_data_type_util__common_40;

static const struct mercury_data_type_util__common_41_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
	Word * f13;
}  mercury_data_type_util__common_41;

static const struct mercury_data_type_util__common_42_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
	Word * f12;
	Word * f13;
}  mercury_data_type_util__common_42;

static const struct mercury_data_type_util__common_43_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_type_util__common_43;

static const struct mercury_data_type_util__common_44_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
	Word * f11;
}  mercury_data_type_util__common_44;

static const struct mercury_data_type_util__common_45_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_type_util__common_45;

static const struct mercury_data_type_util__common_46_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_type_util__common_46;

static const struct mercury_data_type_util__common_47_struct {
	Word * f1;
	Word * f2;
}  mercury_data_type_util__common_47;

static const struct mercury_data_type_util__common_48_struct {
	Word * f1;
	Word * f2;
}  mercury_data_type_util__common_48;

static const struct mercury_data_type_util__common_49_struct {
	Word * f1;
	Word * f2;
}  mercury_data_type_util__common_49;

static const struct mercury_data_type_util__common_50_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	Word * f5;
	Word * f6;
	String f7;
	Word * f8;
	Integer f9;
	Integer f10;
}  mercury_data_type_util__common_50;

static const struct mercury_data_type_util__common_51_struct {
	Integer f1;
	Integer f2;
	String f3;
	String f4;
	String f5;
	String f6;
	String f7;
	String f8;
	String f9;
	String f10;
}  mercury_data_type_util__common_51;

static const struct mercury_data_type_util__type_ctor_functors_ctor_defn_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_type_util__type_ctor_functors_ctor_defn_0;

static const struct mercury_data_type_util__type_ctor_layout_ctor_defn_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_type_util__type_ctor_layout_ctor_defn_0;

static const struct mercury_data_type_util__type_ctor_functors_builtin_type_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_type_util__type_ctor_functors_builtin_type_0;

static const struct mercury_data_type_util__type_ctor_layout_builtin_type_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_type_util__type_ctor_layout_builtin_type_0;

const struct MR_TypeCtorInfo_struct mercury_data_type_util__type_ctor_info_builtin_type_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___type_util__builtin_type_0_0),
	ENTRY(mercury____Index___type_util__builtin_type_0_0),
	ENTRY(mercury____Compare___type_util__builtin_type_0_0),
	(Integer) 0,
	(Word *) &mercury_data_type_util__type_ctor_functors_builtin_type_0,
	(Word *) &mercury_data_type_util__type_ctor_layout_builtin_type_0,
	MR_string_const("type_util", 9),
	MR_string_const("builtin_type", 12),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_type_util__type_ctor_info_ctor_defn_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___type_util__ctor_defn_0_0),
	ENTRY(mercury____Index___type_util__ctor_defn_0_0),
	ENTRY(mercury____Compare___type_util__ctor_defn_0_0),
	(Integer) 2,
	(Word *) &mercury_data_type_util__type_ctor_functors_ctor_defn_0,
	(Word *) &mercury_data_type_util__type_ctor_layout_ctor_defn_0,
	MR_string_const("type_util", 9),
	MR_string_const("ctor_defn", 9),
	(Integer) 3
};

static const struct mercury_data_type_util__common_0_struct mercury_data_type_util__common_0 = {
	MR_string_const("", 0)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_var_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_tvar_type_0;
static const struct mercury_data_type_util__common_1_struct mercury_data_type_util__common_1 = {
	(Word *) &mercury_data_term__type_ctor_info_var_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_term_1;
static const struct mercury_data_type_util__common_2_struct mercury_data_type_util__common_2 = {
	(Word *) &mercury_data_term__type_ctor_info_term_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_pair_2;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_sym_name_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_int_0;
static const struct mercury_data_type_util__common_3_struct mercury_data_type_util__common_3 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_prog_data__type_ctor_info_sym_name_0,
	(Word *) &mercury_data___type_ctor_info_int_0
};

static const struct mercury_data_type_util__common_4_struct mercury_data_type_util__common_4 = {
	MR_string_const("aditi", 5)
};

static const struct mercury_data_type_util__common_5_struct mercury_data_type_util__common_5 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_4),
	MR_string_const("state", 5)
};

static const struct mercury_data_type_util__common_6_struct mercury_data_type_util__common_6 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_type_util__common_5),
	(Integer) 0
};

static const struct mercury_data_type_util__common_7_struct mercury_data_type_util__common_7 = {
	MR_string_const("aditi_top_down", 14)
};

static const struct mercury_data_type_util__common_8_struct mercury_data_type_util__common_8 = {
	MR_string_const("aditi_bottom_up", 15)
};

static const struct mercury_data_type_util__common_9_struct mercury_data_type_util__common_9 = {
	MR_string_const("pred", 4)
};

static const struct mercury_data_type_util__common_10_struct mercury_data_type_util__common_10 = {
	MR_string_const("func", 4)
};

static const struct mercury_data_type_util__common_11_struct mercury_data_type_util__common_11 = {
	MR_string_const("=", 1)
};

static const struct mercury_data_type_util__common_12_struct mercury_data_type_util__common_12 = {
	MR_string_const("int", 3)
};

static const struct mercury_data_type_util__common_13_struct mercury_data_type_util__common_13 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_12),
	(Integer) 0
};

static const struct mercury_data_type_util__common_14_struct mercury_data_type_util__common_14 = {
	MR_string_const("string", 6)
};

static const struct mercury_data_type_util__common_15_struct mercury_data_type_util__common_15 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_14),
	(Integer) 0
};

static const struct mercury_data_type_util__common_16_struct mercury_data_type_util__common_16 = {
	MR_string_const("float", 5)
};

static const struct mercury_data_type_util__common_17_struct mercury_data_type_util__common_17 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_16),
	(Integer) 0
};

static const struct mercury_data_type_util__common_18_struct mercury_data_type_util__common_18 = {
	MR_string_const("character", 9)
};

static const struct mercury_data_type_util__common_19_struct mercury_data_type_util__common_19 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_18),
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_list__type_ctor_info_list_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_data__type_ctor_info_hlds_cons_defn_0;
static const struct mercury_data_type_util__common_20_struct mercury_data_type_util__common_20 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data_hlds_data__type_ctor_info_hlds_cons_defn_0
};

static const struct mercury_data_type_util__common_21_struct mercury_data_type_util__common_21 = {
	(Word *) &mercury_data_hlds_data__type_ctor_info_hlds_cons_defn_0
};

static const struct mercury_data_type_util__common_22_struct mercury_data_type_util__common_22 = {
	(Integer) 0,
	MR_string_const("type_util", 9),
	MR_string_const("type_util", 9),
	MR_string_const("IntroducedFrom__pred__get_cons_id_arg_types__663__1", 51),
	2,
	0,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_3),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_21)
};

static const struct mercury_data_type_util__common_23_struct mercury_data_type_util__common_23 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_1)
};

static const struct mercury_data_type_util__common_24_struct mercury_data_type_util__common_24 = {
	(Integer) 0,
	MR_string_const("type_util", 9),
	MR_string_const("type_util", 9),
	MR_string_const("IntroducedFrom__pred__get_cons_id_arg_types__677__2", 51),
	2,
	0,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_23),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_23)
};

static const struct mercury_data_type_util__common_25_struct mercury_data_type_util__common_25 = {
	(Integer) 0,
	MR_string_const("type_util", 9),
	MR_string_const("type_util", 9),
	MR_string_const("IntroducedFrom__pred__is_existq_cons__697__5", 44),
	2,
	0,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_3),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_21)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_prog_var_type_0;
static const struct mercury_data_type_util__common_26_struct mercury_data_type_util__common_26 = {
	(Word *) &mercury_data_term__type_ctor_info_var_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_class_constraint_0;
static const struct mercury_data_type_util__common_27_struct mercury_data_type_util__common_27 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_prog_data__type_ctor_info_class_constraint_0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_26)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_tree234__type_ctor_info_tree234_2;
static const struct mercury_data_type_util__common_28_struct mercury_data_type_util__common_28 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_1),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_2)
};

static const struct mercury_data_type_util__common_29_struct mercury_data_type_util__common_29 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_26),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_26)
};

static const struct mercury_data_type_util__common_30_struct mercury_data_type_util__common_30 = {
	(Integer) 0,
	MR_string_const("type_util", 9),
	MR_string_const("type_util", 9),
	MR_string_const("apply_substitutions_to_typeclass_var_map_2", 42),
	5,
	0,
	0,
	5,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_28),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_28),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_29),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_27),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_27)
};

static const struct mercury_data_type_util__common_31_struct mercury_data_type_util__common_31 = {
	(Word *) &mercury_data_prog_data__type_ctor_info_class_constraint_0
};

static const struct mercury_data_type_util__common_32_struct mercury_data_type_util__common_32 = {
	(Integer) 0,
	MR_string_const("type_util", 9),
	MR_string_const("type_util", 9),
	MR_string_const("apply_rec_subst_to_constraint", 29),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_28),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_31),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_31)
};

static const struct mercury_data_type_util__common_33_struct mercury_data_type_util__common_33 = {
	1,
	16
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_private_builtin__type_ctor_info_type_info_1;
static const struct mercury_data_type_util__common_34_struct mercury_data_type_util__common_34 = {
	(Word *) &mercury_data_private_builtin__type_ctor_info_type_info_1,
	(Integer) 1
};

static const struct mercury_data_type_util__common_35_struct mercury_data_type_util__common_35 = {
	(Word *) &mercury_data_term__type_ctor_info_term_1,
	(Integer) 1
};

static const struct mercury_data_type_util__common_36_struct mercury_data_type_util__common_36 = {
	(Integer) 0,
	MR_string_const("type_util", 9),
	MR_string_const("type_util", 9),
	MR_string_const("strip_prog_context", 18),
	2,
	0,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_33),
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_34),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_35),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_35)
};

static const struct mercury_data_type_util__common_37_struct mercury_data_type_util__common_37 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_36),
	ENTRY(mercury__type_util__strip_prog_context_2_0),
	(Integer) 1,
	(Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0
};

static const struct mercury_data_type_util__common_38_struct mercury_data_type_util__common_38 = {
	(Integer) 0,
	MR_string_const("type_util", 9),
	MR_string_const("type_util", 9),
	MR_string_const("apply_subst_to_constraint", 25),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_28),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_31),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_31)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_data__type_ctor_info_constraint_proof_0;
static const struct mercury_data_type_util__common_39_struct mercury_data_type_util__common_39 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	(Word *) &mercury_data_prog_data__type_ctor_info_class_constraint_0,
	(Word *) &mercury_data_hlds_data__type_ctor_info_constraint_proof_0
};

static const struct mercury_data_type_util__common_40_struct mercury_data_type_util__common_40 = {
	(Word *) &mercury_data_hlds_data__type_ctor_info_constraint_proof_0
};

static const struct mercury_data_type_util__common_41_struct mercury_data_type_util__common_41 = {
	(Integer) 0,
	MR_string_const("type_util", 9),
	MR_string_const("type_util", 9),
	MR_string_const("IntroducedFrom__pred__apply_subst_to_constraint_proofs__1153__3", 63),
	5,
	0,
	0,
	5,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_28),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_31),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_40),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_39),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_39)
};

static const struct mercury_data_type_util__common_42_struct mercury_data_type_util__common_42 = {
	(Integer) 0,
	MR_string_const("type_util", 9),
	MR_string_const("type_util", 9),
	MR_string_const("IntroducedFrom__pred__apply_rec_subst_to_constraint_proofs__1173__4", 67),
	5,
	0,
	0,
	5,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_28),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_31),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_40),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_39),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_39)
};

static const struct mercury_data_type_util__common_43_struct mercury_data_type_util__common_43 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_1),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_1)
};

static const struct mercury_data_type_util__common_44_struct mercury_data_type_util__common_44 = {
	(Integer) 0,
	MR_string_const("type_util", 9),
	MR_string_const("type_util", 9),
	MR_string_const("apply_variable_renaming_to_constraint", 37),
	3,
	0,
	0,
	3,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_43),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_31),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_31)
};

static const struct mercury_data_type_util__common_45_struct mercury_data_type_util__common_45 = {
	(Integer) 0,
	MR_string_const("type_util", 9),
	MR_string_const("type_util", 9),
	MR_string_const("constraint_get_tvars", 20),
	2,
	0,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_31),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_23)
};

static const struct mercury_data_type_util__common_46_struct mercury_data_type_util__common_46 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_45),
	ENTRY(mercury__type_util__constraint_get_tvars_2_0),
	(Integer) 0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_varset__type_ctor_info_varset_1;
static const struct mercury_data_type_util__common_47_struct mercury_data_type_util__common_47 = {
	(Word *) &mercury_data_varset__type_ctor_info_varset_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0
};

static const struct mercury_data_type_util__common_48_struct mercury_data_type_util__common_48 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_class_constraint_0
};

static const struct mercury_data_type_util__common_49_struct mercury_data_type_util__common_49 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_2)
};

static const struct mercury_data_type_util__common_50_struct mercury_data_type_util__common_50 = {
	(Integer) 5,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_47),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_23),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_48),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_49),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_2),
	MR_string_const("ctor_defn", 9),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_type_util__common_51_struct mercury_data_type_util__common_51 = {
	(Integer) 1,
	(Integer) 8,
	MR_string_const("int_type", 8),
	MR_string_const("char_type", 9),
	MR_string_const("str_type", 8),
	MR_string_const("float_type", 10),
	MR_string_const("pred_type", 9),
	MR_string_const("enum_type", 9),
	MR_string_const("polymorphic_type", 16),
	MR_string_const("user_type", 9)
};

static const struct mercury_data_type_util__type_ctor_functors_ctor_defn_0_struct mercury_data_type_util__type_ctor_functors_ctor_defn_0 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_50)
};

static const struct mercury_data_type_util__type_ctor_layout_ctor_defn_0_struct mercury_data_type_util__type_ctor_layout_ctor_defn_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_type_util__common_50),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_type_util__type_ctor_functors_builtin_type_0_struct mercury_data_type_util__type_ctor_functors_builtin_type_0 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_51)
};

static const struct mercury_data_type_util__type_ctor_layout_builtin_type_0_struct mercury_data_type_util__type_ctor_layout_builtin_type_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_51),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_51),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_51),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_51)
};


BEGIN_MODULE(type_util_module0)
	init_entry(mercury____Index___type_util__ctor_defn_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___type_util__ctor_defn_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___type_util__ctor_defn_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE


BEGIN_MODULE(type_util_module1)
	init_entry(mercury__type_util__type_id_arity__ua0_3_0);
BEGIN_CODE

/* code for predicate 'type_id_arity__ua0'/3 in mode 0 */
Define_static(mercury__type_util__type_id_arity__ua0_3_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	proceed();
END_MODULE

Declare_entry(mercury__prog_util__unqualify_name_2_0);

BEGIN_MODULE(type_util_module2)
	init_entry(mercury__type_util__type_id_name__ua0_3_0);
BEGIN_CODE

/* code for predicate 'type_id_name__ua0'/3 in mode 0 */
Define_static(mercury__type_util__type_id_name__ua0_3_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	tailcall(ENTRY(mercury__prog_util__unqualify_name_2_0),
		STATIC(mercury__type_util__type_id_name__ua0_3_0));
END_MODULE

Declare_entry(mercury__prog_util__sym_name_get_module_name_3_0);

BEGIN_MODULE(type_util_module3)
	init_entry(mercury__type_util__type_id_module__ua0_3_0);
BEGIN_CODE

/* code for predicate 'type_id_module__ua0'/3 in mode 0 */
Define_static(mercury__type_util__type_id_module__ua0_3_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_0);
	tailcall(ENTRY(mercury__prog_util__sym_name_get_module_name_3_0),
		STATIC(mercury__type_util__type_id_module__ua0_3_0));
END_MODULE

Declare_entry(mercury____Unify___std_util__pair_2_0);

BEGIN_MODULE(type_util_module4)
	init_entry(mercury__type_util__IntroducedFrom__pred__is_existq_cons__697__5_2_0);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__is_existq_cons__697__5'/2 in mode 0 */
Define_static(mercury__type_util__IntroducedFrom__pred__is_existq_cons__697__5_2_0);
	r3 = r1;
	r4 = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_sym_name_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	tailcall(ENTRY(mercury____Unify___std_util__pair_2_0),
		STATIC(mercury__type_util__IntroducedFrom__pred__is_existq_cons__697__5_2_0));
END_MODULE

Declare_entry(mercury__map__set_4_1);

BEGIN_MODULE(type_util_module5)
	init_entry(mercury__type_util__IntroducedFrom__pred__apply_rec_subst_to_constraint_proofs__1173__4_5_0);
	init_label(mercury__type_util__IntroducedFrom__pred__apply_rec_subst_to_constraint_proofs__1173__4_5_0_i2);
	init_label(mercury__type_util__IntroducedFrom__pred__apply_rec_subst_to_constraint_proofs__1173__4_5_0_i4);
	init_label(mercury__type_util__IntroducedFrom__pred__apply_rec_subst_to_constraint_proofs__1173__4_5_0_i5);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__apply_rec_subst_to_constraint_proofs__1173__4'/5 in mode 0 */
Define_static(mercury__type_util__IntroducedFrom__pred__apply_rec_subst_to_constraint_proofs__1173__4_5_0);
	MR_incr_sp_push_msg(4, "type_util:IntroducedFrom__pred__apply_rec_subst_to_constraint_proofs__1173__4/5");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r4;
	MR_stackvar(3) = r3;
	call_localret(STATIC(mercury__type_util__apply_rec_subst_to_constraint_3_0),
		mercury__type_util__IntroducedFrom__pred__apply_rec_subst_to_constraint_proofs__1173__4_5_0_i2,
		STATIC(mercury__type_util__IntroducedFrom__pred__apply_rec_subst_to_constraint_proofs__1173__4_5_0));
Define_label(mercury__type_util__IntroducedFrom__pred__apply_rec_subst_to_constraint_proofs__1173__4_5_0_i2);
	update_prof_current_proc(LABEL(mercury__type_util__IntroducedFrom__pred__apply_rec_subst_to_constraint_proofs__1173__4_5_0));
	if ((MR_tag(MR_stackvar(3)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__type_util__IntroducedFrom__pred__apply_rec_subst_to_constraint_proofs__1173__4_5_0_i4);
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_class_constraint_0;
	r2 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_constraint_proof_0;
	r3 = MR_stackvar(2);
	r5 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__map__set_4_1),
		STATIC(mercury__type_util__IntroducedFrom__pred__apply_rec_subst_to_constraint_proofs__1173__4_5_0));
Define_label(mercury__type_util__IntroducedFrom__pred__apply_rec_subst_to_constraint_proofs__1173__4_5_0_i4);
	r3 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	r2 = MR_const_field(MR_mktag(1), MR_stackvar(3), (Integer) 0);
	call_localret(STATIC(mercury__type_util__apply_rec_subst_to_constraint_3_0),
		mercury__type_util__IntroducedFrom__pred__apply_rec_subst_to_constraint_proofs__1173__4_5_0_i5,
		STATIC(mercury__type_util__IntroducedFrom__pred__apply_rec_subst_to_constraint_proofs__1173__4_5_0));
Define_label(mercury__type_util__IntroducedFrom__pred__apply_rec_subst_to_constraint_proofs__1173__4_5_0_i5);
	update_prof_current_proc(LABEL(mercury__type_util__IntroducedFrom__pred__apply_rec_subst_to_constraint_proofs__1173__4_5_0));
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 1, mercury__type_util__IntroducedFrom__pred__apply_rec_subst_to_constraint_proofs__1173__4_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 0) = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_class_constraint_0;
	r2 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_constraint_proof_0;
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__map__set_4_1),
		STATIC(mercury__type_util__IntroducedFrom__pred__apply_rec_subst_to_constraint_proofs__1173__4_5_0));
END_MODULE

Declare_entry(mercury__term__apply_substitution_to_list_3_0);

BEGIN_MODULE(type_util_module6)
	init_entry(mercury__type_util__IntroducedFrom__pred__apply_subst_to_constraint_proofs__1153__3_5_0);
	init_label(mercury__type_util__IntroducedFrom__pred__apply_subst_to_constraint_proofs__1153__3_5_0_i2);
	init_label(mercury__type_util__IntroducedFrom__pred__apply_subst_to_constraint_proofs__1153__3_5_0_i4);
	init_label(mercury__type_util__IntroducedFrom__pred__apply_subst_to_constraint_proofs__1153__3_5_0_i5);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__apply_subst_to_constraint_proofs__1153__3'/5 in mode 0 */
Define_static(mercury__type_util__IntroducedFrom__pred__apply_subst_to_constraint_proofs__1153__3_5_0);
	MR_incr_sp_push_msg(5, "type_util:IntroducedFrom__pred__apply_subst_to_constraint_proofs__1153__3/5");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(3) = r3;
	r3 = r1;
	MR_stackvar(1) = r1;
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	MR_stackvar(2) = r4;
	call_localret(ENTRY(mercury__term__apply_substitution_to_list_3_0),
		mercury__type_util__IntroducedFrom__pred__apply_subst_to_constraint_proofs__1153__3_5_0_i2,
		STATIC(mercury__type_util__IntroducedFrom__pred__apply_subst_to_constraint_proofs__1153__3_5_0));
Define_label(mercury__type_util__IntroducedFrom__pred__apply_subst_to_constraint_proofs__1153__3_5_0_i2);
	update_prof_current_proc(LABEL(mercury__type_util__IntroducedFrom__pred__apply_subst_to_constraint_proofs__1153__3_5_0));
	if ((MR_tag(MR_stackvar(3)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__type_util__IntroducedFrom__pred__apply_subst_to_constraint_proofs__1153__3_5_0_i4);
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 2, mercury__type_util__IntroducedFrom__pred__apply_subst_to_constraint_proofs__1153__3_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r4, (Integer) 1) = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_class_constraint_0;
	r2 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_constraint_proof_0;
	r3 = MR_stackvar(2);
	r5 = MR_stackvar(3);
	MR_field(MR_mktag(0), r4, (Integer) 0) = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury__map__set_4_1),
		STATIC(mercury__type_util__IntroducedFrom__pred__apply_subst_to_constraint_proofs__1153__3_5_0));
Define_label(mercury__type_util__IntroducedFrom__pred__apply_subst_to_constraint_proofs__1153__3_5_0_i4);
	r2 = MR_stackvar(1);
	{
	Word MR_tempr1, MR_tempr2;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__type_util__IntroducedFrom__pred__apply_subst_to_constraint_proofs__1153__3_5_0, "origin_lost_in_value_number");
	MR_tempr2 = MR_const_field(MR_mktag(1), MR_stackvar(3), (Integer) 0);
	r3 = r2;
	MR_stackvar(1) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r1;
	r2 = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(4);
	call_localret(ENTRY(mercury__term__apply_substitution_to_list_3_0),
		mercury__type_util__IntroducedFrom__pred__apply_subst_to_constraint_proofs__1153__3_5_0_i5,
		STATIC(mercury__type_util__IntroducedFrom__pred__apply_subst_to_constraint_proofs__1153__3_5_0));
	}
Define_label(mercury__type_util__IntroducedFrom__pred__apply_subst_to_constraint_proofs__1153__3_5_0_i5);
	update_prof_current_proc(LABEL(mercury__type_util__IntroducedFrom__pred__apply_subst_to_constraint_proofs__1153__3_5_0));
	r4 = MR_stackvar(1);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 1, mercury__type_util__IntroducedFrom__pred__apply_subst_to_constraint_proofs__1153__3_5_0, "hlds_data:constraint_proof/0");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__type_util__IntroducedFrom__pred__apply_subst_to_constraint_proofs__1153__3_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_class_constraint_0;
	r2 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_constraint_proof_0;
	r3 = MR_stackvar(2);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury__map__set_4_1),
		STATIC(mercury__type_util__IntroducedFrom__pred__apply_subst_to_constraint_proofs__1153__3_5_0));
	}
END_MODULE

Declare_entry(mercury____Unify___list__list_1_0);

BEGIN_MODULE(type_util_module7)
	init_entry(mercury__type_util__IntroducedFrom__pred__get_cons_id_arg_types__677__2_2_0);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__get_cons_id_arg_types__677__2'/2 in mode 0 */
Define_static(mercury__type_util__IntroducedFrom__pred__get_cons_id_arg_types__677__2_2_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_1);
	tailcall(ENTRY(mercury____Unify___list__list_1_0),
		STATIC(mercury__type_util__IntroducedFrom__pred__get_cons_id_arg_types__677__2_2_0));
END_MODULE


BEGIN_MODULE(type_util_module8)
	init_entry(mercury__type_util__IntroducedFrom__pred__get_cons_id_arg_types__663__1_2_0);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__get_cons_id_arg_types__663__1'/2 in mode 0 */
Define_static(mercury__type_util__IntroducedFrom__pred__get_cons_id_arg_types__663__1_2_0);
	r3 = r1;
	r4 = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_sym_name_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	tailcall(ENTRY(mercury____Unify___std_util__pair_2_0),
		STATIC(mercury__type_util__IntroducedFrom__pred__get_cons_id_arg_types__663__1_2_0));
END_MODULE


BEGIN_MODULE(type_util_module9)
	init_entry(mercury__type_util__type_is_atomic_2_0);
	init_label(mercury__type_util__type_is_atomic_2_0_i2);
	init_label(mercury__type_util__type_is_atomic_2_0_i1);
BEGIN_CODE

/* code for predicate 'type_is_atomic'/2 in mode 0 */
Define_entry(mercury__type_util__type_is_atomic_2_0);
	MR_incr_sp_push_msg(1, "type_util:type_is_atomic/2");
	MR_stackvar(1) = (Word) MR_succip;
	call_localret(STATIC(mercury__type_util__classify_type_3_0),
		mercury__type_util__type_is_atomic_2_0_i2,
		ENTRY(mercury__type_util__type_is_atomic_2_0));
Define_label(mercury__type_util__type_is_atomic_2_0_i2);
	update_prof_current_proc(LABEL(mercury__type_util__type_is_atomic_2_0));
	if (((Integer) r1 == (Integer) 6))
		GOTO_LABEL(mercury__type_util__type_is_atomic_2_0_i1);
	if (((Integer) r1 == (Integer) 4))
		GOTO_LABEL(mercury__type_util__type_is_atomic_2_0_i1);
	if (((Integer) r1 == (Integer) 7))
		GOTO_LABEL(mercury__type_util__type_is_atomic_2_0_i1);
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	r1 = TRUE;
	proceed();
Define_label(mercury__type_util__type_is_atomic_2_0_i1);
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	r1 = FALSE;
	proceed();
END_MODULE

Declare_entry(mercury__list__append_3_1);

BEGIN_MODULE(type_util_module10)
	init_entry(mercury__type_util__type_is_higher_order_4_0);
	init_label(mercury__type_util__type_is_higher_order_4_0_i14);
	init_label(mercury__type_util__type_is_higher_order_4_0_i9);
	init_label(mercury__type_util__type_is_higher_order_4_0_i20);
	init_label(mercury__type_util__type_is_higher_order_4_0_i24);
	init_label(mercury__type_util__type_is_higher_order_4_0_i2);
	init_label(mercury__type_util__type_is_higher_order_4_0_i30);
	init_label(mercury__type_util__type_is_higher_order_4_0_i25);
	init_label(mercury__type_util__type_is_higher_order_4_0_i36);
	init_label(mercury__type_util__type_is_higher_order_4_0_i1);
BEGIN_CODE

/* code for predicate 'type_is_higher_order'/4 in mode 0 */
Define_entry(mercury__type_util__type_is_higher_order_4_0);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__type_util__type_is_higher_order_4_0_i2);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__type_util__type_is_higher_order_4_0_i2);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), r2, (Integer) 0), (char *)(Word) MR_string_const("=", 1)) != 0))
		GOTO_LABEL(mercury__type_util__type_is_higher_order_4_0_i2);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__type_util__type_is_higher_order_4_0_i2);
	if (((Integer) MR_const_field(MR_mktag(1), r2, (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__type_util__type_is_higher_order_4_0_i2);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r2, (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__type_util__type_is_higher_order_4_0_i2);
	MR_incr_sp_push_msg(2, "type_util:type_is_higher_order/4");
	MR_stackvar(2) = (Word) MR_succip;
	r1 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r2, (Integer) 1), (Integer) 0);
	r3 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	if ((MR_tag(r3) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__type_util__type_is_higher_order_4_0_i9);
	r4 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	if ((MR_tag(r4) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__type_util__type_is_higher_order_4_0_i9);
	r5 = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	if (((Integer) r5 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__type_util__type_is_higher_order_4_0_i9);
	if (((Integer) MR_const_field(MR_mktag(1), r5, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__type_util__type_is_higher_order_4_0_i9);
	r6 = MR_const_field(MR_mktag(1), r5, (Integer) 0);
	r7 = MR_const_field(MR_mktag(0), r4, (Integer) 0);
	if ((strcmp((char *)r7, (char *)(Word) MR_string_const("aditi_bottom_up", 15)) != 0))
		GOTO_LABEL(mercury__type_util__type_is_higher_order_4_0_i14);
	r2 = r6;
	MR_stackvar(1) = (Integer) 2;
	GOTO_LABEL(mercury__type_util__type_is_higher_order_4_0_i20);
Define_label(mercury__type_util__type_is_higher_order_4_0_i14);
	if ((strcmp((char *)r7, (char *)(Word) MR_string_const("aditi_top_down", 14)) != 0))
		GOTO_LABEL(mercury__type_util__type_is_higher_order_4_0_i9);
	MR_stackvar(1) = (Integer) 1;
	r2 = r6;
	GOTO_LABEL(mercury__type_util__type_is_higher_order_4_0_i20);
Define_label(mercury__type_util__type_is_higher_order_4_0_i9);
	MR_stackvar(1) = (Integer) 0;
	r2 = r3;
Define_label(mercury__type_util__type_is_higher_order_4_0_i20);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__type_util__type_is_higher_order_4_0_i1);
	if ((MR_tag(MR_const_field(MR_mktag(0), r2, (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__type_util__type_is_higher_order_4_0_i1);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), r2, (Integer) 0), (Integer) 0), (char *)(Word) MR_string_const("func", 4)) != 0))
		GOTO_LABEL(mercury__type_util__type_is_higher_order_4_0_i1);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_2);
	r4 = r2;
	r2 = MR_const_field(MR_mktag(0), r4, (Integer) 1);
	r4 = r3;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__type_util__type_is_higher_order_4_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__type_util__type_is_higher_order_4_0_i24,
		ENTRY(mercury__type_util__type_is_higher_order_4_0));
Define_label(mercury__type_util__type_is_higher_order_4_0_i24);
	update_prof_current_proc(LABEL(mercury__type_util__type_is_higher_order_4_0));
	r2 = (Integer) 1;
	r3 = MR_stackvar(1);
	r4 = r1;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__type_util__type_is_higher_order_4_0_i2);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__type_util__type_is_higher_order_4_0_i25);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__type_util__type_is_higher_order_4_0_i25);
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__type_util__type_is_higher_order_4_0_i25);
	if (((Integer) MR_const_field(MR_mktag(1), r3, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__type_util__type_is_higher_order_4_0_i25);
	r4 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	r5 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	if ((strcmp((char *)r5, (char *)(Word) MR_string_const("aditi_bottom_up", 15)) != 0))
		GOTO_LABEL(mercury__type_util__type_is_higher_order_4_0_i30);
	MR_incr_sp_push_msg(2, "type_util:type_is_higher_order/4");
	MR_stackvar(2) = (Word) MR_succip;
	r3 = (Integer) 2;
	r1 = r4;
	GOTO_LABEL(mercury__type_util__type_is_higher_order_4_0_i36);
Define_label(mercury__type_util__type_is_higher_order_4_0_i30);
	if ((strcmp((char *)r5, (char *)(Word) MR_string_const("aditi_top_down", 14)) != 0))
		GOTO_LABEL(mercury__type_util__type_is_higher_order_4_0_i25);
	MR_incr_sp_push_msg(2, "type_util:type_is_higher_order/4");
	MR_stackvar(2) = (Word) MR_succip;
	r3 = (Integer) 1;
	r1 = r4;
	GOTO_LABEL(mercury__type_util__type_is_higher_order_4_0_i36);
Define_label(mercury__type_util__type_is_higher_order_4_0_i25);
	r3 = (Integer) 0;
	MR_incr_sp_push_msg(2, "type_util:type_is_higher_order/4");
	MR_stackvar(2) = (Word) MR_succip;
Define_label(mercury__type_util__type_is_higher_order_4_0_i36);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__type_util__type_is_higher_order_4_0_i1);
	if ((MR_tag(MR_const_field(MR_mktag(0), r1, (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__type_util__type_is_higher_order_4_0_i1);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), r1, (Integer) 0), (Integer) 0), (char *)(Word) MR_string_const("pred", 4)) != 0))
		GOTO_LABEL(mercury__type_util__type_is_higher_order_4_0_i1);
	r2 = (Integer) 0;
	r4 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__type_util__type_is_higher_order_4_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE


BEGIN_MODULE(type_util_module11)
	init_entry(mercury__type_util__type_id_is_higher_order_3_0);
	init_label(mercury__type_util__type_id_is_higher_order_3_0_i3);
	init_label(mercury__type_util__type_id_is_higher_order_3_0_i6);
	init_label(mercury__type_util__type_id_is_higher_order_3_0_i2);
	init_label(mercury__type_util__type_id_is_higher_order_3_0_i9);
	init_label(mercury__type_util__type_id_is_higher_order_3_0_i1);
BEGIN_CODE

/* code for predicate 'type_id_is_higher_order'/3 in mode 0 */
Define_entry(mercury__type_util__type_id_is_higher_order_3_0);
	if ((MR_tag(MR_const_field(MR_mktag(0), r1, (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__type_util__type_id_is_higher_order_3_0_i3);
	r1 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), r1, (Integer) 0), (Integer) 0);
	r3 = (Integer) 0;
	GOTO_LABEL(mercury__type_util__type_id_is_higher_order_3_0_i2);
Define_label(mercury__type_util__type_id_is_higher_order_3_0_i3);
	if ((MR_tag(MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__type_util__type_id_is_higher_order_3_0_i1);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 0), (Integer) 0), (Integer) 0), (char *)(Word) MR_string_const("aditi_bottom_up", 15)) != 0))
		GOTO_LABEL(mercury__type_util__type_id_is_higher_order_3_0_i6);
	r1 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 0), (Integer) 1);
	r3 = (Integer) 2;
	GOTO_LABEL(mercury__type_util__type_id_is_higher_order_3_0_i2);
Define_label(mercury__type_util__type_id_is_higher_order_3_0_i6);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), r2, (Integer) 0), (char *)(Word) MR_string_const("aditi_top_down", 14)) != 0))
		GOTO_LABEL(mercury__type_util__type_id_is_higher_order_3_0_i1);
	r1 = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 1);
	r3 = (Integer) 1;
	}
Define_label(mercury__type_util__type_id_is_higher_order_3_0_i2);
	if ((strcmp((char *)r1, (char *)(Word) MR_string_const("func", 4)) != 0))
		GOTO_LABEL(mercury__type_util__type_id_is_higher_order_3_0_i9);
	r2 = (Integer) 1;
	r1 = TRUE;
	proceed();
Define_label(mercury__type_util__type_id_is_higher_order_3_0_i9);
	if ((strcmp((char *)r1, (char *)(Word) MR_string_const("pred", 4)) != 0))
		GOTO_LABEL(mercury__type_util__type_id_is_higher_order_3_0_i1);
	r2 = (Integer) 0;
	r1 = TRUE;
	proceed();
Define_label(mercury__type_util__type_id_is_higher_order_3_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

Declare_entry(mercury__hlds_module__module_info_types_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_data__type_ctor_info_hlds_type_defn_0;
Declare_entry(mercury__map__search_3_1);
Declare_entry(mercury__hlds_data__get_type_defn_body_2_0);

BEGIN_MODULE(type_util_module12)
	init_entry(mercury__type_util__type_has_user_defined_equality_pred_3_0);
	init_label(mercury__type_util__type_has_user_defined_equality_pred_3_0_i2);
	init_label(mercury__type_util__type_has_user_defined_equality_pred_3_0_i3);
	init_label(mercury__type_util__type_has_user_defined_equality_pred_3_0_i5);
	init_label(mercury__type_util__type_has_user_defined_equality_pred_3_0_i7);
	init_label(mercury__type_util__type_has_user_defined_equality_pred_3_0_i1);
BEGIN_CODE

/* code for predicate 'type_has_user_defined_equality_pred'/3 in mode 0 */
Define_entry(mercury__type_util__type_has_user_defined_equality_pred_3_0);
	MR_incr_sp_push_msg(2, "type_util:type_has_user_defined_equality_pred/3");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__hlds_module__module_info_types_2_0),
		mercury__type_util__type_has_user_defined_equality_pred_3_0_i2,
		ENTRY(mercury__type_util__type_has_user_defined_equality_pred_3_0));
Define_label(mercury__type_util__type_has_user_defined_equality_pred_3_0_i2);
	update_prof_current_proc(LABEL(mercury__type_util__type_has_user_defined_equality_pred_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__type_util__type_to_type_id_3_0),
		mercury__type_util__type_has_user_defined_equality_pred_3_0_i3,
		ENTRY(mercury__type_util__type_has_user_defined_equality_pred_3_0));
Define_label(mercury__type_util__type_has_user_defined_equality_pred_3_0_i3);
	update_prof_current_proc(LABEL(mercury__type_util__type_has_user_defined_equality_pred_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__type_util__type_has_user_defined_equality_pred_3_0_i1);
	r4 = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_3);
	r2 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_hlds_type_defn_0;
	r3 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__type_util__type_has_user_defined_equality_pred_3_0_i5,
		ENTRY(mercury__type_util__type_has_user_defined_equality_pred_3_0));
Define_label(mercury__type_util__type_has_user_defined_equality_pred_3_0_i5);
	update_prof_current_proc(LABEL(mercury__type_util__type_has_user_defined_equality_pred_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__type_util__type_has_user_defined_equality_pred_3_0_i1);
	r1 = r2;
	call_localret(ENTRY(mercury__hlds_data__get_type_defn_body_2_0),
		mercury__type_util__type_has_user_defined_equality_pred_3_0_i7,
		ENTRY(mercury__type_util__type_has_user_defined_equality_pred_3_0));
Define_label(mercury__type_util__type_has_user_defined_equality_pred_3_0_i7);
	update_prof_current_proc(LABEL(mercury__type_util__type_has_user_defined_equality_pred_3_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__type_util__type_has_user_defined_equality_pred_3_0_i1);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 3);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__type_util__type_has_user_defined_equality_pred_3_0_i1);
	r2 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__type_util__type_has_user_defined_equality_pred_3_0_i1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	r1 = FALSE;
	proceed();
END_MODULE

Declare_entry(mercury__list__length_2_0);

BEGIN_MODULE(type_util_module13)
	init_entry(mercury__type_util__is_dummy_argument_type_1_0);
	init_label(mercury__type_util__is_dummy_argument_type_1_0_i13);
	init_label(mercury__type_util__is_dummy_argument_type_1_0_i15);
	init_label(mercury__type_util__is_dummy_argument_type_1_0_i1028);
	init_label(mercury__type_util__is_dummy_argument_type_1_0_i1);
BEGIN_CODE

/* code for predicate 'is_dummy_argument_type'/1 in mode 0 */
Define_entry(mercury__type_util__is_dummy_argument_type_1_0);
	MR_incr_sp_push_msg(3, "type_util:is_dummy_argument_type/1");
	MR_stackvar(3) = (Word) MR_succip;
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__type_util__is_dummy_argument_type_1_0_i1028);
	if ((MR_tag(MR_const_field(MR_mktag(0), r1, (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__type_util__is_dummy_argument_type_1_0_i1028);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), r1, (Integer) 0), (Integer) 0), (char *)(Word) MR_string_const(":", 1)) != 0))
		GOTO_LABEL(mercury__type_util__is_dummy_argument_type_1_0_i1028);
	if (((Integer) MR_const_field(MR_mktag(0), r1, (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__type_util__is_dummy_argument_type_1_0_i1028);
	if ((MR_tag(MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__type_util__is_dummy_argument_type_1_0_i1028);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__type_util__is_dummy_argument_type_1_0_i1028);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 0), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__type_util__is_dummy_argument_type_1_0_i1028);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__type_util__is_dummy_argument_type_1_0_i1028);
	if ((MR_tag(MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 1), (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__type_util__is_dummy_argument_type_1_0_i1028);
	if ((MR_tag(MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 1), (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__type_util__is_dummy_argument_type_1_0_i1028);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__type_util__is_dummy_argument_type_1_0_i1028);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 0), (Integer) 0), (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 1), (Integer) 1), (Integer) 0), (Integer) 0), (Integer) 0);
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_2);
	r3 = r2;
	r2 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r3, (Integer) 1), (Integer) 1), (Integer) 0), (Integer) 1);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__type_util__is_dummy_argument_type_1_0_i13,
		ENTRY(mercury__type_util__is_dummy_argument_type_1_0));
Define_label(mercury__type_util__is_dummy_argument_type_1_0_i13);
	update_prof_current_proc(LABEL(mercury__type_util__is_dummy_argument_type_1_0));
	if ((strcmp((char *)MR_stackvar(1), (char *)(Word) MR_string_const("io", 2)) != 0))
		GOTO_LABEL(mercury__type_util__is_dummy_argument_type_1_0_i15);
	if ((strcmp((char *)MR_stackvar(2), (char *)(Word) MR_string_const("state", 5)) != 0))
		GOTO_LABEL(mercury__type_util__is_dummy_argument_type_1_0_i1);
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__type_util__is_dummy_argument_type_1_0_i1);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__type_util__is_dummy_argument_type_1_0_i15);
	if ((strcmp((char *)MR_stackvar(1), (char *)(Word) MR_string_const("store", 5)) != 0))
		GOTO_LABEL(mercury__type_util__is_dummy_argument_type_1_0_i1);
	if ((strcmp((char *)MR_stackvar(2), (char *)(Word) MR_string_const("store", 5)) != 0))
		GOTO_LABEL(mercury__type_util__is_dummy_argument_type_1_0_i1);
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__type_util__is_dummy_argument_type_1_0_i1);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__type_util__is_dummy_argument_type_1_0_i1028);
	r1 = FALSE;
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__type_util__is_dummy_argument_type_1_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(type_util_module14)
	init_entry(mercury__type_util__type_is_aditi_state_1_0);
	init_label(mercury__type_util__type_is_aditi_state_1_0_i2);
	init_label(mercury__type_util__type_is_aditi_state_1_0_i4);
	init_label(mercury__type_util__type_is_aditi_state_1_0_i1);
BEGIN_CODE

/* code for predicate 'type_is_aditi_state'/1 in mode 0 */
Define_entry(mercury__type_util__type_is_aditi_state_1_0);
	MR_incr_sp_push_msg(2, "type_util:type_is_aditi_state/1");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_6);
	call_localret(STATIC(mercury__type_util__type_to_type_id_3_0),
		mercury__type_util__type_is_aditi_state_1_0_i2,
		ENTRY(mercury__type_util__type_is_aditi_state_1_0));
Define_label(mercury__type_util__type_is_aditi_state_1_0_i2);
	update_prof_current_proc(LABEL(mercury__type_util__type_is_aditi_state_1_0));
	if (!(r1))
		GOTO_LABEL(mercury__type_util__type_is_aditi_state_1_0_i1);
	{
	Word MR_tempr1;
	MR_tempr1 = r3;
	r3 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	r4 = r2;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_sym_name_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury____Unify___std_util__pair_2_0),
		mercury__type_util__type_is_aditi_state_1_0_i4,
		ENTRY(mercury__type_util__type_is_aditi_state_1_0));
	}
Define_label(mercury__type_util__type_is_aditi_state_1_0_i4);
	update_prof_current_proc(LABEL(mercury__type_util__type_is_aditi_state_1_0));
	if (!(r1))
		GOTO_LABEL(mercury__type_util__type_is_aditi_state_1_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_2);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r3 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury____Unify___list__list_1_0),
		ENTRY(mercury__type_util__type_is_aditi_state_1_0));
Define_label(mercury__type_util__type_is_aditi_state_1_0_i1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	r1 = FALSE;
	proceed();
END_MODULE

Declare_entry(mercury__require__error_1_0);

BEGIN_MODULE(type_util_module15)
	init_entry(mercury__type_util__remove_aditi_state_3_0);
	init_label(mercury__type_util__remove_aditi_state_3_0_i1004);
	init_label(mercury__type_util__remove_aditi_state_3_0_i3);
	init_label(mercury__type_util__remove_aditi_state_3_0_i11);
	init_label(mercury__type_util__remove_aditi_state_3_0_i9);
	init_label(mercury__type_util__remove_aditi_state_3_0_i14);
	init_label(mercury__type_util__remove_aditi_state_3_0_i8);
BEGIN_CODE

/* code for predicate 'remove_aditi_state'/3 in mode 0 */
Define_entry(mercury__type_util__remove_aditi_state_3_0);
	MR_incr_sp_push_msg(5, "type_util:remove_aditi_state/3");
	MR_stackvar(5) = (Word) MR_succip;
Define_label(mercury__type_util__remove_aditi_state_3_0_i1004);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__type_util__remove_aditi_state_3_0_i3);
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__type_util__remove_aditi_state_3_0_i8);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__type_util__remove_aditi_state_3_0_i3);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__type_util__remove_aditi_state_3_0_i8);
	MR_stackvar(3) = r1;
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	call_localret(STATIC(mercury__type_util__type_is_aditi_state_1_0),
		mercury__type_util__remove_aditi_state_3_0_i11,
		ENTRY(mercury__type_util__remove_aditi_state_3_0));
Define_label(mercury__type_util__remove_aditi_state_3_0_i11);
	update_prof_current_proc(LABEL(mercury__type_util__remove_aditi_state_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__type_util__remove_aditi_state_3_0_i9);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(5);
	GOTO_LABEL(mercury__type_util__remove_aditi_state_3_0_i1004);
Define_label(mercury__type_util__remove_aditi_state_3_0_i9);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(2);
	localcall(mercury__type_util__remove_aditi_state_3_0,
		LABEL(mercury__type_util__remove_aditi_state_3_0_i14),
		ENTRY(mercury__type_util__remove_aditi_state_3_0));
Define_label(mercury__type_util__remove_aditi_state_3_0_i14);
	update_prof_current_proc(LABEL(mercury__type_util__remove_aditi_state_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__type_util__remove_aditi_state_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__type_util__remove_aditi_state_3_0_i8);
	r1 = (Word) MR_string_const("type_util__remove_aditi_state", 29);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__type_util__remove_aditi_state_3_0));
END_MODULE

Declare_entry(mercury__prog_util__mercury_private_builtin_module_1_0);
Declare_entry(mercury____Unify___prog_data__sym_name_0_0);

BEGIN_MODULE(type_util_module16)
	init_entry(mercury__type_util__type_id_is_hand_defined_1_0);
	init_label(mercury__type_util__type_id_is_hand_defined_1_0_i7);
	init_label(mercury__type_util__type_id_is_hand_defined_1_0_i9);
	init_label(mercury__type_util__type_id_is_hand_defined_1_0_i4);
	init_label(mercury__type_util__type_id_is_hand_defined_1_0_i15);
	init_label(mercury__type_util__type_id_is_hand_defined_1_0_i18);
	init_label(mercury__type_util__type_id_is_hand_defined_1_0_i22);
	init_label(mercury__type_util__type_id_is_hand_defined_1_0_i26);
	init_label(mercury__type_util__type_id_is_hand_defined_1_0_i31);
	init_label(mercury__type_util__type_id_is_hand_defined_1_0_i1);
BEGIN_CODE

/* code for predicate 'type_id_is_hand_defined'/1 in mode 0 */
Define_entry(mercury__type_util__type_id_is_hand_defined_1_0);
	if ((MR_tag(MR_const_field(MR_mktag(0), r1, (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__type_util__type_id_is_hand_defined_1_0_i1);
	if (((Integer) MR_const_field(MR_mktag(0), r1, (Integer) 1) != (Integer) 0))
		GOTO_LABEL(mercury__type_util__type_id_is_hand_defined_1_0_i4);
	if ((MR_tag(MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 0), (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__type_util__type_id_is_hand_defined_1_0_i1);
	if ((strcmp((char *)MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 0), (Integer) 1), (char *)(Word) MR_string_const("c_pointer", 9)) != 0))
		GOTO_LABEL(mercury__type_util__type_id_is_hand_defined_1_0_i7);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 0), (Integer) 0), (Integer) 0), (char *)(Word) MR_string_const("builtin", 7)) != 0))
		GOTO_LABEL(mercury__type_util__type_id_is_hand_defined_1_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury__type_util__type_id_is_hand_defined_1_0_i7);
	if ((strcmp((char *)MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 0), (Integer) 1), (char *)(Word) MR_string_const("type_info", 9)) != 0))
		GOTO_LABEL(mercury__type_util__type_id_is_hand_defined_1_0_i9);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 0), (Integer) 0), (Integer) 0), (char *)(Word) MR_string_const("std_util", 8)) != 0))
		GOTO_LABEL(mercury__type_util__type_id_is_hand_defined_1_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury__type_util__type_id_is_hand_defined_1_0_i9);
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	if ((strcmp((char *)r2, (char *)(Word) MR_string_const("univ", 4)) != 0))
		GOTO_LABEL(mercury__type_util__type_id_is_hand_defined_1_0_i1);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r3, (Integer) 0), (Integer) 0), (char *)(Word) MR_string_const("std_util", 8)) != 0))
		GOTO_LABEL(mercury__type_util__type_id_is_hand_defined_1_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury__type_util__type_id_is_hand_defined_1_0_i4);
	if (((Integer) MR_const_field(MR_mktag(0), r1, (Integer) 1) != (Integer) 1))
		GOTO_LABEL(mercury__type_util__type_id_is_hand_defined_1_0_i1);
	if ((strcmp((char *)MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 0), (Integer) 1), (char *)(Word) MR_string_const("array", 5)) != 0))
		GOTO_LABEL(mercury__type_util__type_id_is_hand_defined_1_0_i15);
	r2 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), r1, (Integer) 0), (Integer) 0);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__type_util__type_id_is_hand_defined_1_0_i1);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	if ((strcmp((char *)r3, (char *)(Word) MR_string_const("array", 5)) != 0))
		GOTO_LABEL(mercury__type_util__type_id_is_hand_defined_1_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury__type_util__type_id_is_hand_defined_1_0_i15);
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	if ((strcmp((char *)r2, (char *)(Word) MR_string_const("base_typeclass_info", 19)) != 0))
		GOTO_LABEL(mercury__type_util__type_id_is_hand_defined_1_0_i18);
	MR_incr_sp_push_msg(2, "type_util:type_id_is_hand_defined/1");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	call_localret(ENTRY(mercury__prog_util__mercury_private_builtin_module_1_0),
		mercury__type_util__type_id_is_hand_defined_1_0_i31,
		ENTRY(mercury__type_util__type_id_is_hand_defined_1_0));
Define_label(mercury__type_util__type_id_is_hand_defined_1_0_i18);
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	if ((strcmp((char *)r2, (char *)(Word) MR_string_const("type_ctor_info", 14)) != 0))
		GOTO_LABEL(mercury__type_util__type_id_is_hand_defined_1_0_i22);
	MR_incr_sp_push_msg(2, "type_util:type_id_is_hand_defined/1");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	call_localret(ENTRY(mercury__prog_util__mercury_private_builtin_module_1_0),
		mercury__type_util__type_id_is_hand_defined_1_0_i31,
		ENTRY(mercury__type_util__type_id_is_hand_defined_1_0));
Define_label(mercury__type_util__type_id_is_hand_defined_1_0_i22);
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	if ((strcmp((char *)r2, (char *)(Word) MR_string_const("type_info", 9)) != 0))
		GOTO_LABEL(mercury__type_util__type_id_is_hand_defined_1_0_i26);
	MR_incr_sp_push_msg(2, "type_util:type_id_is_hand_defined/1");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	call_localret(ENTRY(mercury__prog_util__mercury_private_builtin_module_1_0),
		mercury__type_util__type_id_is_hand_defined_1_0_i31,
		ENTRY(mercury__type_util__type_id_is_hand_defined_1_0));
Define_label(mercury__type_util__type_id_is_hand_defined_1_0_i26);
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	if ((strcmp((char *)r2, (char *)(Word) MR_string_const("typeclass_info", 14)) != 0))
		GOTO_LABEL(mercury__type_util__type_id_is_hand_defined_1_0_i1);
	MR_incr_sp_push_msg(2, "type_util:type_id_is_hand_defined/1");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	call_localret(ENTRY(mercury__prog_util__mercury_private_builtin_module_1_0),
		mercury__type_util__type_id_is_hand_defined_1_0_i31,
		ENTRY(mercury__type_util__type_id_is_hand_defined_1_0));
Define_label(mercury__type_util__type_id_is_hand_defined_1_0_i31);
	update_prof_current_proc(LABEL(mercury__type_util__type_id_is_hand_defined_1_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury____Unify___prog_data__sym_name_0_0),
		ENTRY(mercury__type_util__type_id_is_hand_defined_1_0));
Define_label(mercury__type_util__type_id_is_hand_defined_1_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

Declare_entry(mercury__prog_io__sym_name_and_args_3_0);

BEGIN_MODULE(type_util_module17)
	init_entry(mercury__type_util__is_introduced_type_info_type_1_0);
	init_label(mercury__type_util__is_introduced_type_info_type_1_0_i2);
	init_label(mercury__type_util__is_introduced_type_info_type_1_0_i6);
	init_label(mercury__type_util__is_introduced_type_info_type_1_0_i7);
	init_label(mercury__type_util__is_introduced_type_info_type_1_0_i8);
	init_label(mercury__type_util__is_introduced_type_info_type_1_0_i10);
	init_label(mercury__type_util__is_introduced_type_info_type_1_0_i1);
BEGIN_CODE

/* code for predicate 'is_introduced_type_info_type'/1 in mode 0 */
Define_entry(mercury__type_util__is_introduced_type_info_type_1_0);
	MR_incr_sp_push_msg(2, "type_util:is_introduced_type_info_type/1");
	MR_stackvar(2) = (Word) MR_succip;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	call_localret(ENTRY(mercury__prog_io__sym_name_and_args_3_0),
		mercury__type_util__is_introduced_type_info_type_1_0_i2,
		ENTRY(mercury__type_util__is_introduced_type_info_type_1_0));
Define_label(mercury__type_util__is_introduced_type_info_type_1_0_i2);
	update_prof_current_proc(LABEL(mercury__type_util__is_introduced_type_info_type_1_0));
	if (!(r1))
		GOTO_LABEL(mercury__type_util__is_introduced_type_info_type_1_0_i1);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__type_util__is_introduced_type_info_type_1_0_i1);
	if ((strcmp((char *)MR_const_field(MR_mktag(1), r2, (Integer) 1), (char *)(Word) MR_string_const("base_typeclass_info", 19)) != 0))
		GOTO_LABEL(mercury__type_util__is_introduced_type_info_type_1_0_i6);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	call_localret(ENTRY(mercury__prog_util__mercury_private_builtin_module_1_0),
		mercury__type_util__is_introduced_type_info_type_1_0_i10,
		ENTRY(mercury__type_util__is_introduced_type_info_type_1_0));
Define_label(mercury__type_util__is_introduced_type_info_type_1_0_i6);
	if ((strcmp((char *)MR_const_field(MR_mktag(1), r2, (Integer) 1), (char *)(Word) MR_string_const("type_ctor_info", 14)) != 0))
		GOTO_LABEL(mercury__type_util__is_introduced_type_info_type_1_0_i7);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	call_localret(ENTRY(mercury__prog_util__mercury_private_builtin_module_1_0),
		mercury__type_util__is_introduced_type_info_type_1_0_i10,
		ENTRY(mercury__type_util__is_introduced_type_info_type_1_0));
Define_label(mercury__type_util__is_introduced_type_info_type_1_0_i7);
	if ((strcmp((char *)MR_const_field(MR_mktag(1), r2, (Integer) 1), (char *)(Word) MR_string_const("type_info", 9)) != 0))
		GOTO_LABEL(mercury__type_util__is_introduced_type_info_type_1_0_i8);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	call_localret(ENTRY(mercury__prog_util__mercury_private_builtin_module_1_0),
		mercury__type_util__is_introduced_type_info_type_1_0_i10,
		ENTRY(mercury__type_util__is_introduced_type_info_type_1_0));
Define_label(mercury__type_util__is_introduced_type_info_type_1_0_i8);
	if ((strcmp((char *)MR_const_field(MR_mktag(1), r2, (Integer) 1), (char *)(Word) MR_string_const("typeclass_info", 14)) != 0))
		GOTO_LABEL(mercury__type_util__is_introduced_type_info_type_1_0_i1);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	call_localret(ENTRY(mercury__prog_util__mercury_private_builtin_module_1_0),
		mercury__type_util__is_introduced_type_info_type_1_0_i10,
		ENTRY(mercury__type_util__is_introduced_type_info_type_1_0));
Define_label(mercury__type_util__is_introduced_type_info_type_1_0_i10);
	update_prof_current_proc(LABEL(mercury__type_util__is_introduced_type_info_type_1_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury____Unify___prog_data__sym_name_0_0),
		ENTRY(mercury__type_util__is_introduced_type_info_type_1_0));
Define_label(mercury__type_util__is_introduced_type_info_type_1_0_i1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	r1 = FALSE;
	proceed();
END_MODULE

Declare_entry(mercury__string__append_3_1);

BEGIN_MODULE(type_util_module18)
	init_entry(mercury__type_util__remove_new_prefix_2_0);
	init_label(mercury__type_util__remove_new_prefix_2_0_i4);
	init_label(mercury__type_util__remove_new_prefix_2_0_i3);
	init_label(mercury__type_util__remove_new_prefix_2_0_i6);
	init_label(mercury__type_util__remove_new_prefix_2_0_i1);
BEGIN_CODE

/* code for predicate 'remove_new_prefix'/2 in mode 0 */
Define_entry(mercury__type_util__remove_new_prefix_2_0);
	MR_incr_sp_push_msg(2, "type_util:remove_new_prefix/2");
	MR_stackvar(2) = (Word) MR_succip;
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__type_util__remove_new_prefix_2_0_i3);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r1 = (Word) MR_string_const("new ", 4);
	call_localret(ENTRY(mercury__string__append_3_1),
		mercury__type_util__remove_new_prefix_2_0_i4,
		ENTRY(mercury__type_util__remove_new_prefix_2_0));
Define_label(mercury__type_util__remove_new_prefix_2_0_i4);
	update_prof_current_proc(LABEL(mercury__type_util__remove_new_prefix_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__type_util__remove_new_prefix_2_0_i1);
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 1, mercury__type_util__remove_new_prefix_2_0, "prog_data:sym_name/0");
	MR_field(MR_mktag(0), r2, (Integer) 0) = r1;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__type_util__remove_new_prefix_2_0_i3);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = (Word) MR_string_const("new ", 4);
	call_localret(ENTRY(mercury__string__append_3_1),
		mercury__type_util__remove_new_prefix_2_0_i6,
		ENTRY(mercury__type_util__remove_new_prefix_2_0));
Define_label(mercury__type_util__remove_new_prefix_2_0_i6);
	update_prof_current_proc(LABEL(mercury__type_util__remove_new_prefix_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__type_util__remove_new_prefix_2_0_i1);
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__type_util__remove_new_prefix_2_0, "prog_data:sym_name/0");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r2, (Integer) 1) = r1;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__type_util__remove_new_prefix_2_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE

Declare_entry(mercury__string__append_3_2);

BEGIN_MODULE(type_util_module19)
	init_entry(mercury__type_util__remove_new_prefix_2_1);
	init_label(mercury__type_util__remove_new_prefix_2_1_i4);
	init_label(mercury__type_util__remove_new_prefix_2_1_i3);
	init_label(mercury__type_util__remove_new_prefix_2_1_i5);
BEGIN_CODE

/* code for predicate 'remove_new_prefix'/2 in mode 1 */
Define_entry(mercury__type_util__remove_new_prefix_2_1);
	MR_incr_sp_push_msg(2, "type_util:remove_new_prefix/2");
	MR_stackvar(2) = (Word) MR_succip;
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__type_util__remove_new_prefix_2_1_i3);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r1 = (Word) MR_string_const("new ", 4);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__type_util__remove_new_prefix_2_1_i4,
		ENTRY(mercury__type_util__remove_new_prefix_2_1));
Define_label(mercury__type_util__remove_new_prefix_2_1_i4);
	update_prof_current_proc(LABEL(mercury__type_util__remove_new_prefix_2_1));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 1, mercury__type_util__remove_new_prefix_2_1, "prog_data:sym_name/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__type_util__remove_new_prefix_2_1_i3);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = (Word) MR_string_const("new ", 4);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__type_util__remove_new_prefix_2_1_i5,
		ENTRY(mercury__type_util__remove_new_prefix_2_1));
Define_label(mercury__type_util__remove_new_prefix_2_1_i5);
	update_prof_current_proc(LABEL(mercury__type_util__remove_new_prefix_2_1));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__type_util__remove_new_prefix_2_1, "prog_data:sym_name/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE


BEGIN_MODULE(type_util_module20)
	init_entry(mercury__type_util__classify_type_3_0);
	init_label(mercury__type_util__classify_type_3_0_i4);
	init_label(mercury__type_util__classify_type_3_0_i6);
	init_label(mercury__type_util__classify_type_3_0_i10);
	init_label(mercury__type_util__classify_type_3_0_i14);
	init_label(mercury__type_util__classify_type_3_0_i18);
	init_label(mercury__type_util__classify_type_3_0_i24);
	init_label(mercury__type_util__classify_type_3_0_i22);
	init_label(mercury__type_util__classify_type_3_0_i27);
	init_label(mercury__type_util__classify_type_3_0_i28);
	init_label(mercury__type_util__classify_type_3_0_i30);
	init_label(mercury__type_util__classify_type_3_0_i26);
	init_label(mercury__type_util__classify_type_3_0_i3);
BEGIN_CODE

/* code for predicate 'classify_type'/3 in mode 0 */
Define_entry(mercury__type_util__classify_type_3_0);
	MR_incr_sp_push_msg(3, "type_util:classify_type/3");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__type_util__type_to_type_id_3_0),
		mercury__type_util__classify_type_3_0_i4,
		ENTRY(mercury__type_util__classify_type_3_0));
Define_label(mercury__type_util__classify_type_3_0_i4);
	update_prof_current_proc(LABEL(mercury__type_util__classify_type_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__type_util__classify_type_3_0_i3);
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__type_util__classify_type_3_0_i6);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), r1, (Integer) 0), (char *)(Word) MR_string_const("character", 9)) != 0))
		GOTO_LABEL(mercury__type_util__classify_type_3_0_i6);
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__type_util__classify_type_3_0_i6);
	r1 = (Integer) 1;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__type_util__classify_type_3_0_i6);
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__type_util__classify_type_3_0_i10);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), r1, (Integer) 0), (char *)(Word) MR_string_const("int", 3)) != 0))
		GOTO_LABEL(mercury__type_util__classify_type_3_0_i10);
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__type_util__classify_type_3_0_i10);
	r1 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__type_util__classify_type_3_0_i10);
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__type_util__classify_type_3_0_i14);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), r1, (Integer) 0), (char *)(Word) MR_string_const("float", 5)) != 0))
		GOTO_LABEL(mercury__type_util__classify_type_3_0_i14);
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__type_util__classify_type_3_0_i14);
	r1 = (Integer) 3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__type_util__classify_type_3_0_i14);
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__type_util__classify_type_3_0_i18);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), r1, (Integer) 0), (char *)(Word) MR_string_const("string", 6)) != 0))
		GOTO_LABEL(mercury__type_util__classify_type_3_0_i18);
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__type_util__classify_type_3_0_i18);
	r1 = (Integer) 2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__type_util__classify_type_3_0_i18);
	MR_stackvar(2) = r2;
	r1 = r2;
	call_localret(STATIC(mercury__type_util__type_id_is_higher_order_3_0),
		mercury__type_util__classify_type_3_0_i24,
		ENTRY(mercury__type_util__classify_type_3_0));
Define_label(mercury__type_util__classify_type_3_0_i24);
	update_prof_current_proc(LABEL(mercury__type_util__classify_type_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__type_util__classify_type_3_0_i22);
	r1 = (Integer) 4;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__type_util__classify_type_3_0_i22);
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_module__module_info_types_2_0),
		mercury__type_util__classify_type_3_0_i27,
		ENTRY(mercury__type_util__classify_type_3_0));
Define_label(mercury__type_util__classify_type_3_0_i27);
	update_prof_current_proc(LABEL(mercury__type_util__classify_type_3_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_3);
	r2 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_hlds_type_defn_0;
	r4 = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__type_util__classify_type_3_0_i28,
		ENTRY(mercury__type_util__classify_type_3_0));
Define_label(mercury__type_util__classify_type_3_0_i28);
	update_prof_current_proc(LABEL(mercury__type_util__classify_type_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__type_util__classify_type_3_0_i26);
	r1 = r2;
	call_localret(ENTRY(mercury__hlds_data__get_type_defn_body_2_0),
		mercury__type_util__classify_type_3_0_i30,
		ENTRY(mercury__type_util__classify_type_3_0));
Define_label(mercury__type_util__classify_type_3_0_i30);
	update_prof_current_proc(LABEL(mercury__type_util__classify_type_3_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__type_util__classify_type_3_0_i26);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 2) != (Integer) 1))
		GOTO_LABEL(mercury__type_util__classify_type_3_0_i26);
	r1 = (Integer) 5;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__type_util__classify_type_3_0_i26);
	r1 = (Integer) 7;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__type_util__classify_type_3_0_i3);
	r1 = (Integer) 6;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_pred__adjust_func_arity_3_1);

BEGIN_MODULE(type_util_module21)
	init_entry(mercury__type_util__type_to_type_id_3_0);
	init_label(mercury__type_util__type_to_type_id_3_0_i2);
	init_label(mercury__type_util__type_to_type_id_3_0_i4);
	init_label(mercury__type_util__type_to_type_id_3_0_i7);
	init_label(mercury__type_util__type_to_type_id_3_0_i9);
	init_label(mercury__type_util__type_to_type_id_3_0_i10);
	init_label(mercury__type_util__type_to_type_id_3_0_i12);
	init_label(mercury__type_util__type_to_type_id_3_0_i11);
	init_label(mercury__type_util__type_to_type_id_3_0_i14);
	init_label(mercury__type_util__type_to_type_id_3_0_i1017);
	init_label(mercury__type_util__type_to_type_id_3_0_i5);
	init_label(mercury__type_util__type_to_type_id_3_0_i16);
	init_label(mercury__type_util__type_to_type_id_3_0_i17);
	init_label(mercury__type_util__type_to_type_id_3_0_i21);
	init_label(mercury__type_util__type_to_type_id_3_0_i19);
	init_label(mercury__type_util__type_to_type_id_3_0_i1);
BEGIN_CODE

/* code for predicate 'type_to_type_id'/3 in mode 0 */
Define_entry(mercury__type_util__type_to_type_id_3_0);
	MR_incr_sp_push_msg(7, "type_util:type_to_type_id/3");
	MR_stackvar(7) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	call_localret(ENTRY(mercury__prog_io__sym_name_and_args_3_0),
		mercury__type_util__type_to_type_id_3_0_i2,
		ENTRY(mercury__type_util__type_to_type_id_3_0));
Define_label(mercury__type_util__type_to_type_id_3_0_i2);
	update_prof_current_proc(LABEL(mercury__type_util__type_to_type_id_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__type_util__type_to_type_id_3_0_i1);
	MR_stackvar(3) = r2;
	MR_stackvar(4) = r3;
	call_localret(ENTRY(mercury__prog_util__mercury_private_builtin_module_1_0),
		mercury__type_util__type_to_type_id_3_0_i4,
		ENTRY(mercury__type_util__type_to_type_id_3_0));
Define_label(mercury__type_util__type_to_type_id_3_0_i4);
	update_prof_current_proc(LABEL(mercury__type_util__type_to_type_id_3_0));
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(1);
	call_localret(STATIC(mercury__type_util__type_is_higher_order_4_0),
		mercury__type_util__type_to_type_id_3_0_i7,
		ENTRY(mercury__type_util__type_to_type_id_3_0));
Define_label(mercury__type_util__type_to_type_id_3_0_i7);
	update_prof_current_proc(LABEL(mercury__type_util__type_to_type_id_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__type_util__type_to_type_id_3_0_i5);
	MR_stackvar(1) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_2);
	r2 = r4;
	MR_stackvar(2) = r4;
	MR_stackvar(6) = r3;
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__type_util__type_to_type_id_3_0_i9,
		ENTRY(mercury__type_util__type_to_type_id_3_0));
Define_label(mercury__type_util__type_to_type_id_3_0_i9);
	update_prof_current_proc(LABEL(mercury__type_util__type_to_type_id_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_pred__adjust_func_arity_3_1),
		mercury__type_util__type_to_type_id_3_0_i10,
		ENTRY(mercury__type_util__type_to_type_id_3_0));
Define_label(mercury__type_util__type_to_type_id_3_0_i10);
	update_prof_current_proc(LABEL(mercury__type_util__type_to_type_id_3_0));
	if (((Integer) MR_stackvar(1) != (Integer) 0))
		GOTO_LABEL(mercury__type_util__type_to_type_id_3_0_i12);
	r2 = r1;
	r1 = MR_stackvar(5);
	r3 = (Word) MR_string_const("pred", 4);
	GOTO_LABEL(mercury__type_util__type_to_type_id_3_0_i11);
Define_label(mercury__type_util__type_to_type_id_3_0_i12);
	r2 = r1;
	r1 = MR_stackvar(5);
	r3 = (Word) MR_string_const("func", 4);
Define_label(mercury__type_util__type_to_type_id_3_0_i11);
	if (((Integer) MR_stackvar(6) != (Integer) 0))
		GOTO_LABEL(mercury__type_util__type_to_type_id_3_0_i14);
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 1, mercury__type_util__type_to_type_id_3_0, "prog_data:sym_name/0");
	MR_field(MR_mktag(0), r4, (Integer) 0) = r3;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__type_util__type_to_type_id_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 1) = r2;
	r2 = r4;
	MR_stackvar(1) = r3;
	MR_field(MR_mktag(0), r3, (Integer) 0) = r4;
	GOTO_LABEL(mercury__type_util__type_to_type_id_3_0_i17);
Define_label(mercury__type_util__type_to_type_id_3_0_i14);
	if (((Integer) MR_stackvar(6) != (Integer) 1))
		GOTO_LABEL(mercury__type_util__type_to_type_id_3_0_i1017);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__type_util__type_to_type_id_3_0, "prog_data:sym_name/0");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_7);
	MR_field(MR_mktag(1), r4, (Integer) 1) = r3;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__type_util__type_to_type_id_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 1) = r2;
	r2 = r4;
	MR_stackvar(1) = r3;
	MR_field(MR_mktag(0), r3, (Integer) 0) = r4;
	GOTO_LABEL(mercury__type_util__type_to_type_id_3_0_i17);
Define_label(mercury__type_util__type_to_type_id_3_0_i1017);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__type_util__type_to_type_id_3_0, "prog_data:sym_name/0");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_8);
	MR_field(MR_mktag(1), r4, (Integer) 1) = r3;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__type_util__type_to_type_id_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 1) = r2;
	r2 = r4;
	MR_stackvar(1) = r3;
	MR_field(MR_mktag(0), r3, (Integer) 0) = r4;
	GOTO_LABEL(mercury__type_util__type_to_type_id_3_0_i17);
Define_label(mercury__type_util__type_to_type_id_3_0_i5);
	r2 = MR_stackvar(4);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_2);
	MR_stackvar(1) = MR_stackvar(3);
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__type_util__type_to_type_id_3_0_i16,
		ENTRY(mercury__type_util__type_to_type_id_3_0));
Define_label(mercury__type_util__type_to_type_id_3_0_i16);
	update_prof_current_proc(LABEL(mercury__type_util__type_to_type_id_3_0));
	r2 = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__type_util__type_to_type_id_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 1) = r1;
	MR_field(MR_mktag(0), r3, (Integer) 0) = r2;
	r1 = MR_stackvar(5);
	MR_stackvar(1) = r3;
Define_label(mercury__type_util__type_to_type_id_3_0_i17);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__type_util__type_to_type_id_3_0_i19);
	MR_stackvar(6) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	call_localret(ENTRY(mercury____Unify___prog_data__sym_name_0_0),
		mercury__type_util__type_to_type_id_3_0_i21,
		ENTRY(mercury__type_util__type_to_type_id_3_0));
Define_label(mercury__type_util__type_to_type_id_3_0_i21);
	update_prof_current_proc(LABEL(mercury__type_util__type_to_type_id_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__type_util__type_to_type_id_3_0_i19);
	if ((strcmp((char *)MR_stackvar(6), (char *)(Word) MR_string_const("constraint", 10)) == 0))
		GOTO_LABEL(mercury__type_util__type_to_type_id_3_0_i1);
Define_label(mercury__type_util__type_to_type_id_3_0_i19);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	r1 = TRUE;
	proceed();
Define_label(mercury__type_util__type_to_type_id_3_0_i1);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(type_util_module22)
	init_entry(mercury__type_util__var_2_0);
	init_label(mercury__type_util__var_2_0_i1);
BEGIN_CODE

/* code for predicate 'var'/2 in mode 0 */
Define_entry(mercury__type_util__var_2_0);
	if ((MR_tag(r1) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__type_util__var_2_0_i1);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = TRUE;
	proceed();
Define_label(mercury__type_util__var_2_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(type_util_module23)
	init_entry(mercury__type_util__var_2_1);
BEGIN_CODE

/* code for predicate 'var'/2 in mode 1 */
Define_entry(mercury__type_util__var_2_1);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__type_util__var_2_1, "term:term/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	proceed();
END_MODULE

Declare_entry(mercury__term__context_init_1_0);

BEGIN_MODULE(type_util_module24)
	init_entry(mercury__type_util__construct_type_3_0);
	init_label(mercury__type_util__construct_type_3_0_i2);
BEGIN_CODE

/* code for predicate 'construct_type'/3 in mode 0 */
Define_entry(mercury__type_util__construct_type_3_0);
	MR_incr_sp_push_msg(3, "type_util:construct_type/3");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__term__context_init_1_0),
		mercury__type_util__construct_type_3_0_i2,
		ENTRY(mercury__type_util__construct_type_3_0));
Define_label(mercury__type_util__construct_type_3_0_i2);
	update_prof_current_proc(LABEL(mercury__type_util__construct_type_3_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__type_util__construct_type_4_0),
		ENTRY(mercury__type_util__construct_type_3_0));
END_MODULE

Declare_entry(mercury__hlds_pred__pred_args_to_func_args_3_0);
Declare_entry(mercury__prog_util__construct_qualified_term_4_0);

BEGIN_MODULE(type_util_module25)
	init_entry(mercury__type_util__construct_type_4_0);
	init_label(mercury__type_util__construct_type_4_0_i4);
	init_label(mercury__type_util__construct_type_4_0_i7);
	init_label(mercury__type_util__construct_type_4_0_i9);
	init_label(mercury__type_util__construct_type_4_0_i2);
BEGIN_CODE

/* code for predicate 'construct_type'/4 in mode 0 */
Define_entry(mercury__type_util__construct_type_4_0);
	MR_incr_sp_push_msg(5, "type_util:construct_type/4");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	call_localret(STATIC(mercury__type_util__type_id_is_higher_order_3_0),
		mercury__type_util__construct_type_4_0_i4,
		ENTRY(mercury__type_util__construct_type_4_0));
Define_label(mercury__type_util__construct_type_4_0_i4);
	update_prof_current_proc(LABEL(mercury__type_util__construct_type_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__type_util__construct_type_4_0_i2);
	if (((Integer) r2 != (Integer) 0))
		GOTO_LABEL(mercury__type_util__construct_type_4_0_i7);
	r1 = r3;
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(STATIC(mercury__type_util__construct_higher_order_pred_type_3_0),
		ENTRY(mercury__type_util__construct_type_4_0));
Define_label(mercury__type_util__construct_type_4_0_i7);
	MR_stackvar(4) = r3;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_2);
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__hlds_pred__pred_args_to_func_args_3_0),
		mercury__type_util__construct_type_4_0_i9,
		ENTRY(mercury__type_util__construct_type_4_0));
Define_label(mercury__type_util__construct_type_4_0_i9);
	update_prof_current_proc(LABEL(mercury__type_util__construct_type_4_0));
	r3 = r2;
	r2 = r1;
	r1 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(STATIC(mercury__type_util__construct_higher_order_func_type_4_0),
		ENTRY(mercury__type_util__construct_type_4_0));
Define_label(mercury__type_util__construct_type_4_0_i2);
	r2 = MR_const_field(MR_mktag(0), MR_stackvar(1), (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury__prog_util__construct_qualified_term_4_0),
		ENTRY(mercury__type_util__construct_type_4_0));
END_MODULE


BEGIN_MODULE(type_util_module26)
	init_entry(mercury__type_util__construct_higher_order_type_4_0);
	init_label(mercury__type_util__construct_higher_order_type_4_0_i3);
	init_label(mercury__type_util__construct_higher_order_type_4_0_i5);
BEGIN_CODE

/* code for predicate 'construct_higher_order_type'/4 in mode 0 */
Define_entry(mercury__type_util__construct_higher_order_type_4_0);
	MR_incr_sp_push_msg(2, "type_util:construct_higher_order_type/4");
	MR_stackvar(2) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__type_util__construct_higher_order_type_4_0_i3);
	r1 = r2;
	r2 = r3;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__type_util__construct_higher_order_pred_type_3_0),
		ENTRY(mercury__type_util__construct_higher_order_type_4_0));
Define_label(mercury__type_util__construct_higher_order_type_4_0_i3);
	MR_stackvar(1) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_2);
	r2 = r3;
	call_localret(ENTRY(mercury__hlds_pred__pred_args_to_func_args_3_0),
		mercury__type_util__construct_higher_order_type_4_0_i5,
		ENTRY(mercury__type_util__construct_higher_order_type_4_0));
Define_label(mercury__type_util__construct_higher_order_type_4_0_i5);
	update_prof_current_proc(LABEL(mercury__type_util__construct_higher_order_type_4_0));
	r3 = r2;
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__type_util__construct_higher_order_func_type_4_0),
		ENTRY(mercury__type_util__construct_higher_order_type_4_0));
END_MODULE


BEGIN_MODULE(type_util_module27)
	init_entry(mercury__type_util__construct_higher_order_pred_type_3_0);
	init_label(mercury__type_util__construct_higher_order_pred_type_3_0_i2);
	init_label(mercury__type_util__construct_higher_order_pred_type_3_0_i3);
	init_label(mercury__type_util__construct_higher_order_pred_type_3_0_i7);
	init_label(mercury__type_util__construct_higher_order_pred_type_3_0_i6);
	init_label(mercury__type_util__construct_higher_order_pred_type_3_0_i8);
	init_label(mercury__type_util__construct_higher_order_pred_type_3_0_i4);
BEGIN_CODE

/* code for predicate 'construct_higher_order_pred_type'/3 in mode 0 */
Define_entry(mercury__type_util__construct_higher_order_pred_type_3_0);
	MR_incr_sp_push_msg(3, "type_util:construct_higher_order_pred_type/3");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__term__context_init_1_0),
		mercury__type_util__construct_higher_order_pred_type_3_0_i2,
		ENTRY(mercury__type_util__construct_higher_order_pred_type_3_0));
Define_label(mercury__type_util__construct_higher_order_pred_type_3_0_i2);
	update_prof_current_proc(LABEL(mercury__type_util__construct_higher_order_pred_type_3_0));
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_9);
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__prog_util__construct_qualified_term_4_0),
		mercury__type_util__construct_higher_order_pred_type_3_0_i3,
		ENTRY(mercury__type_util__construct_higher_order_pred_type_3_0));
Define_label(mercury__type_util__construct_higher_order_pred_type_3_0_i3);
	update_prof_current_proc(LABEL(mercury__type_util__construct_higher_order_pred_type_3_0));
	r2 = MR_stackvar(1);
	if (((Integer) r2 == (Integer) 0))
		GOTO_LABEL(mercury__type_util__construct_higher_order_pred_type_3_0_i4);
	if (((Integer) r2 != (Integer) 1))
		GOTO_LABEL(mercury__type_util__construct_higher_order_pred_type_3_0_i6);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__type_util__construct_higher_order_pred_type_3_0, "origin_lost_in_value_number");
	MR_stackvar(2) = r3;
	MR_stackvar(1) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_7);
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	call_localret(ENTRY(mercury__term__context_init_1_0),
		mercury__type_util__construct_higher_order_pred_type_3_0_i7,
		ENTRY(mercury__type_util__construct_higher_order_pred_type_3_0));
Define_label(mercury__type_util__construct_higher_order_pred_type_3_0_i7);
	update_prof_current_proc(LABEL(mercury__type_util__construct_higher_order_pred_type_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 3, mercury__type_util__construct_higher_order_pred_type_3_0, "term:term/1");
	MR_field(MR_mktag(0), r1, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_7);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(0), r1, (Integer) 2) = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__type_util__construct_higher_order_pred_type_3_0_i6);
	MR_stackvar(1) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_8);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__type_util__construct_higher_order_pred_type_3_0, "origin_lost_in_value_number");
	MR_stackvar(2) = r2;
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r2, (Integer) 0) = r1;
	call_localret(ENTRY(mercury__term__context_init_1_0),
		mercury__type_util__construct_higher_order_pred_type_3_0_i8,
		ENTRY(mercury__type_util__construct_higher_order_pred_type_3_0));
Define_label(mercury__type_util__construct_higher_order_pred_type_3_0_i8);
	update_prof_current_proc(LABEL(mercury__type_util__construct_higher_order_pred_type_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 3, mercury__type_util__construct_higher_order_pred_type_3_0, "term:term/1");
	MR_field(MR_mktag(0), r1, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_8);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(0), r1, (Integer) 2) = r2;
Define_label(mercury__type_util__construct_higher_order_pred_type_3_0_i4);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(type_util_module28)
	init_entry(mercury__type_util__construct_higher_order_func_type_4_0);
	init_label(mercury__type_util__construct_higher_order_func_type_4_0_i2);
	init_label(mercury__type_util__construct_higher_order_func_type_4_0_i3);
	init_label(mercury__type_util__construct_higher_order_func_type_4_0_i5);
	init_label(mercury__type_util__construct_higher_order_func_type_4_0_i7);
	init_label(mercury__type_util__construct_higher_order_func_type_4_0_i6);
	init_label(mercury__type_util__construct_higher_order_func_type_4_0_i8);
BEGIN_CODE

/* code for predicate 'construct_higher_order_func_type'/4 in mode 0 */
Define_entry(mercury__type_util__construct_higher_order_func_type_4_0);
	MR_incr_sp_push_msg(5, "type_util:construct_higher_order_func_type/4");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__term__context_init_1_0),
		mercury__type_util__construct_higher_order_func_type_4_0_i2,
		ENTRY(mercury__type_util__construct_higher_order_func_type_4_0));
Define_label(mercury__type_util__construct_higher_order_func_type_4_0_i2);
	update_prof_current_proc(LABEL(mercury__type_util__construct_higher_order_func_type_4_0));
	r3 = MR_stackvar(2);
	r4 = r1;
	MR_stackvar(2) = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_10);
	call_localret(ENTRY(mercury__prog_util__construct_qualified_term_4_0),
		mercury__type_util__construct_higher_order_func_type_4_0_i3,
		ENTRY(mercury__type_util__construct_higher_order_func_type_4_0));
Define_label(mercury__type_util__construct_higher_order_func_type_4_0_i3);
	update_prof_current_proc(LABEL(mercury__type_util__construct_higher_order_func_type_4_0));
	if (((Integer) MR_stackvar(1) != (Integer) 0))
		GOTO_LABEL(mercury__type_util__construct_higher_order_func_type_4_0_i5);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 3, mercury__type_util__construct_higher_order_func_type_4_0, "term:term/1");
	MR_field(MR_mktag(0), r1, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_11);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__type_util__construct_higher_order_func_type_4_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__type_util__construct_higher_order_func_type_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = r2;
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(0), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__type_util__construct_higher_order_func_type_4_0_i5);
	if (((Integer) MR_stackvar(1) != (Integer) 1))
		GOTO_LABEL(mercury__type_util__construct_higher_order_func_type_4_0_i6);
	MR_stackvar(1) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_7);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__type_util__construct_higher_order_func_type_4_0, "origin_lost_in_value_number");
	MR_stackvar(4) = r2;
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r2, (Integer) 0) = r1;
	call_localret(ENTRY(mercury__term__context_init_1_0),
		mercury__type_util__construct_higher_order_func_type_4_0_i7,
		ENTRY(mercury__type_util__construct_higher_order_func_type_4_0));
Define_label(mercury__type_util__construct_higher_order_func_type_4_0_i7);
	update_prof_current_proc(LABEL(mercury__type_util__construct_higher_order_func_type_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 3, mercury__type_util__construct_higher_order_func_type_4_0, "term:term/1");
	MR_field(MR_mktag(0), r1, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_11);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__type_util__construct_higher_order_func_type_4_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 3, mercury__type_util__construct_higher_order_func_type_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = r2;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = MR_stackvar(4);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_7);
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__type_util__construct_higher_order_func_type_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = r2;
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(0), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
	}
Define_label(mercury__type_util__construct_higher_order_func_type_4_0_i6);
	MR_stackvar(1) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_8);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__type_util__construct_higher_order_func_type_4_0, "origin_lost_in_value_number");
	MR_stackvar(4) = r2;
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r2, (Integer) 0) = r1;
	call_localret(ENTRY(mercury__term__context_init_1_0),
		mercury__type_util__construct_higher_order_func_type_4_0_i8,
		ENTRY(mercury__type_util__construct_higher_order_func_type_4_0));
Define_label(mercury__type_util__construct_higher_order_func_type_4_0_i8);
	update_prof_current_proc(LABEL(mercury__type_util__construct_higher_order_func_type_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 3, mercury__type_util__construct_higher_order_func_type_4_0, "term:term/1");
	MR_field(MR_mktag(0), r1, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_11);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__type_util__construct_higher_order_func_type_4_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 3, mercury__type_util__construct_higher_order_func_type_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = r2;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = MR_stackvar(4);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_8);
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__type_util__construct_higher_order_func_type_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = r2;
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(0), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
	}
END_MODULE


BEGIN_MODULE(type_util_module29)
	init_entry(mercury__fn__type_util__int_type_0_0);
	init_label(mercury__fn__type_util__int_type_0_0_i2);
BEGIN_CODE

/* code for predicate 'int_type'/1 in mode 0 */
Define_entry(mercury__fn__type_util__int_type_0_0);
	MR_incr_sp_push_msg(2, "type_util:int_type/1");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_13);
	call_localret(ENTRY(mercury__term__context_init_1_0),
		mercury__fn__type_util__int_type_0_0_i2,
		ENTRY(mercury__fn__type_util__int_type_0_0));
Define_label(mercury__fn__type_util__int_type_0_0_i2);
	update_prof_current_proc(LABEL(mercury__fn__type_util__int_type_0_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__type_util__construct_type_4_0),
		ENTRY(mercury__fn__type_util__int_type_0_0));
END_MODULE


BEGIN_MODULE(type_util_module30)
	init_entry(mercury__fn__type_util__string_type_0_0);
	init_label(mercury__fn__type_util__string_type_0_0_i2);
BEGIN_CODE

/* code for predicate 'string_type'/1 in mode 0 */
Define_entry(mercury__fn__type_util__string_type_0_0);
	MR_incr_sp_push_msg(2, "type_util:string_type/1");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_15);
	call_localret(ENTRY(mercury__term__context_init_1_0),
		mercury__fn__type_util__string_type_0_0_i2,
		ENTRY(mercury__fn__type_util__string_type_0_0));
Define_label(mercury__fn__type_util__string_type_0_0_i2);
	update_prof_current_proc(LABEL(mercury__fn__type_util__string_type_0_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__type_util__construct_type_4_0),
		ENTRY(mercury__fn__type_util__string_type_0_0));
END_MODULE


BEGIN_MODULE(type_util_module31)
	init_entry(mercury__fn__type_util__float_type_0_0);
	init_label(mercury__fn__type_util__float_type_0_0_i2);
BEGIN_CODE

/* code for predicate 'float_type'/1 in mode 0 */
Define_entry(mercury__fn__type_util__float_type_0_0);
	MR_incr_sp_push_msg(2, "type_util:float_type/1");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_17);
	call_localret(ENTRY(mercury__term__context_init_1_0),
		mercury__fn__type_util__float_type_0_0_i2,
		ENTRY(mercury__fn__type_util__float_type_0_0));
Define_label(mercury__fn__type_util__float_type_0_0_i2);
	update_prof_current_proc(LABEL(mercury__fn__type_util__float_type_0_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__type_util__construct_type_4_0),
		ENTRY(mercury__fn__type_util__float_type_0_0));
END_MODULE


BEGIN_MODULE(type_util_module32)
	init_entry(mercury__fn__type_util__char_type_0_0);
	init_label(mercury__fn__type_util__char_type_0_0_i2);
BEGIN_CODE

/* code for predicate 'char_type'/1 in mode 0 */
Define_entry(mercury__fn__type_util__char_type_0_0);
	MR_incr_sp_push_msg(2, "type_util:char_type/1");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_19);
	call_localret(ENTRY(mercury__term__context_init_1_0),
		mercury__fn__type_util__char_type_0_0_i2,
		ENTRY(mercury__fn__type_util__char_type_0_0));
Define_label(mercury__fn__type_util__char_type_0_0_i2);
	update_prof_current_proc(LABEL(mercury__fn__type_util__char_type_0_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__type_util__construct_type_4_0),
		ENTRY(mercury__fn__type_util__char_type_0_0));
END_MODULE


BEGIN_MODULE(type_util_module33)
	init_entry(mercury__type_util__make_type_id_3_0);
	init_label(mercury__type_util__make_type_id_3_0_i1);
BEGIN_CODE

/* code for predicate 'make_type_id'/3 in mode 0 */
Define_entry(mercury__type_util__make_type_id_3_0);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__type_util__make_type_id_3_0_i1);
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__type_util__make_type_id_3_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 1, mercury__type_util__make_type_id_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r1 = TRUE;
	MR_field(MR_mktag(0), r2, (Integer) 1) = r3;
	proceed();
	}
Define_label(mercury__type_util__make_type_id_3_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(type_util_module34)
	init_entry(mercury__type_util__type_id_module_3_0);
BEGIN_CODE

/* code for predicate 'type_id_module'/3 in mode 0 */
Define_entry(mercury__type_util__type_id_module_3_0);
	r1 = r2;
	tailcall(STATIC(mercury__type_util__type_id_module__ua0_3_0),
		ENTRY(mercury__type_util__type_id_module_3_0));
END_MODULE


BEGIN_MODULE(type_util_module35)
	init_entry(mercury__type_util__type_id_name_3_0);
BEGIN_CODE

/* code for predicate 'type_id_name'/3 in mode 0 */
Define_entry(mercury__type_util__type_id_name_3_0);
	r1 = r2;
	tailcall(STATIC(mercury__type_util__type_id_name__ua0_3_0),
		ENTRY(mercury__type_util__type_id_name_3_0));
END_MODULE


BEGIN_MODULE(type_util_module36)
	init_entry(mercury__type_util__type_id_arity_3_0);
BEGIN_CODE

/* code for predicate 'type_id_arity'/3 in mode 0 */
Define_entry(mercury__type_util__type_id_arity_3_0);
	r1 = r2;
	tailcall(STATIC(mercury__type_util__type_id_arity__ua0_3_0),
		ENTRY(mercury__type_util__type_id_arity_3_0));
END_MODULE

Declare_entry(mercury__hlds_data__get_type_defn_tparams_2_0);
Declare_entry(mercury__term__term_list_to_var_list_2_0);
Declare_entry(mercury__map__from_corresponding_lists_3_0);

BEGIN_MODULE(type_util_module37)
	init_entry(mercury__type_util__type_constructors_3_0);
	init_label(mercury__type_util__type_constructors_3_0_i2);
	init_label(mercury__type_util__type_constructors_3_0_i4);
	init_label(mercury__type_util__type_constructors_3_0_i5);
	init_label(mercury__type_util__type_constructors_3_0_i7);
	init_label(mercury__type_util__type_constructors_3_0_i8);
	init_label(mercury__type_util__type_constructors_3_0_i12);
	init_label(mercury__type_util__type_constructors_3_0_i13);
	init_label(mercury__type_util__type_constructors_3_0_i14);
	init_label(mercury__type_util__type_constructors_3_0_i15);
	init_label(mercury__type_util__type_constructors_3_0_i1);
BEGIN_CODE

/* code for predicate 'type_constructors'/3 in mode 0 */
Define_entry(mercury__type_util__type_constructors_3_0);
	MR_incr_sp_push_msg(3, "type_util:type_constructors/3");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__type_util__type_to_type_id_3_0),
		mercury__type_util__type_constructors_3_0_i2,
		ENTRY(mercury__type_util__type_constructors_3_0));
Define_label(mercury__type_util__type_constructors_3_0_i2);
	update_prof_current_proc(LABEL(mercury__type_util__type_constructors_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__type_util__type_constructors_3_0_i1);
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__hlds_module__module_info_types_2_0),
		mercury__type_util__type_constructors_3_0_i4,
		ENTRY(mercury__type_util__type_constructors_3_0));
Define_label(mercury__type_util__type_constructors_3_0_i4);
	update_prof_current_proc(LABEL(mercury__type_util__type_constructors_3_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_3);
	r2 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_hlds_type_defn_0;
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__type_util__type_constructors_3_0_i5,
		ENTRY(mercury__type_util__type_constructors_3_0));
Define_label(mercury__type_util__type_constructors_3_0_i5);
	update_prof_current_proc(LABEL(mercury__type_util__type_constructors_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__type_util__type_constructors_3_0_i1);
	MR_stackvar(1) = r2;
	r1 = r2;
	call_localret(ENTRY(mercury__hlds_data__get_type_defn_tparams_2_0),
		mercury__type_util__type_constructors_3_0_i7,
		ENTRY(mercury__type_util__type_constructors_3_0));
Define_label(mercury__type_util__type_constructors_3_0_i7);
	update_prof_current_proc(LABEL(mercury__type_util__type_constructors_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__hlds_data__get_type_defn_body_2_0),
		mercury__type_util__type_constructors_3_0_i8,
		ENTRY(mercury__type_util__type_constructors_3_0));
Define_label(mercury__type_util__type_constructors_3_0_i8);
	update_prof_current_proc(LABEL(mercury__type_util__type_constructors_3_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__type_util__type_constructors_3_0_i1);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	if (((Integer) MR_stackvar(1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__type_util__type_constructors_3_0_i15);
	r3 = r2;
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	call_localret(ENTRY(mercury__term__term_list_to_var_list_2_0),
		mercury__type_util__type_constructors_3_0_i12,
		ENTRY(mercury__type_util__type_constructors_3_0));
Define_label(mercury__type_util__type_constructors_3_0_i12);
	update_prof_current_proc(LABEL(mercury__type_util__type_constructors_3_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_2);
	r4 = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__from_corresponding_lists_3_0),
		mercury__type_util__type_constructors_3_0_i13,
		ENTRY(mercury__type_util__type_constructors_3_0));
Define_label(mercury__type_util__type_constructors_3_0_i13);
	update_prof_current_proc(LABEL(mercury__type_util__type_constructors_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(STATIC(mercury__type_util__substitute_type_args_2_3_0),
		mercury__type_util__type_constructors_3_0_i14,
		ENTRY(mercury__type_util__type_constructors_3_0));
Define_label(mercury__type_util__type_constructors_3_0_i14);
	update_prof_current_proc(LABEL(mercury__type_util__type_constructors_3_0));
	r2 = r1;
Define_label(mercury__type_util__type_constructors_3_0_i15);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	r1 = TRUE;
	proceed();
Define_label(mercury__type_util__type_constructors_3_0_i1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	r1 = FALSE;
	proceed();
END_MODULE

Declare_entry(mercury__hlds_module__module_info_ctors_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_data__type_ctor_info_cons_id_0;
Declare_entry(mercury__list__filter_3_0);
Declare_entry(mercury__map__lookup_3_0);
Declare_entry(mercury__require__require_2_0);

BEGIN_MODULE(type_util_module38)
	init_entry(mercury__type_util__get_cons_id_arg_types_4_0);
	init_label(mercury__type_util__get_cons_id_arg_types_4_0_i3);
	init_label(mercury__type_util__get_cons_id_arg_types_4_0_i5);
	init_label(mercury__type_util__get_cons_id_arg_types_4_0_i6);
	init_label(mercury__type_util__get_cons_id_arg_types_4_0_i8);
	init_label(mercury__type_util__get_cons_id_arg_types_4_0_i10);
	init_label(mercury__type_util__get_cons_id_arg_types_4_0_i14);
	init_label(mercury__type_util__get_cons_id_arg_types_4_0_i15);
	init_label(mercury__type_util__get_cons_id_arg_types_4_0_i16);
	init_label(mercury__type_util__get_cons_id_arg_types_4_0_i17);
	init_label(mercury__type_util__get_cons_id_arg_types_4_0_i18);
	init_label(mercury__type_util__get_cons_id_arg_types_4_0_i19);
	init_label(mercury__type_util__get_cons_id_arg_types_4_0_i2);
BEGIN_CODE

/* code for predicate 'get_cons_id_arg_types'/4 in mode 0 */
Define_entry(mercury__type_util__get_cons_id_arg_types_4_0);
	MR_incr_sp_push_msg(5, "type_util:get_cons_id_arg_types/4");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r2;
	MR_stackvar(2) = r3;
	call_localret(STATIC(mercury__type_util__type_to_type_id_3_0),
		mercury__type_util__get_cons_id_arg_types_4_0_i3,
		ENTRY(mercury__type_util__get_cons_id_arg_types_4_0));
Define_label(mercury__type_util__get_cons_id_arg_types_4_0_i3);
	update_prof_current_proc(LABEL(mercury__type_util__get_cons_id_arg_types_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__type_util__get_cons_id_arg_types_4_0_i2);
	MR_stackvar(3) = r2;
	MR_stackvar(4) = r3;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_module__module_info_ctors_2_0),
		mercury__type_util__get_cons_id_arg_types_4_0_i5,
		ENTRY(mercury__type_util__get_cons_id_arg_types_4_0));
Define_label(mercury__type_util__get_cons_id_arg_types_4_0_i5);
	update_prof_current_proc(LABEL(mercury__type_util__get_cons_id_arg_types_4_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_cons_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_20);
	r4 = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__type_util__get_cons_id_arg_types_4_0_i6,
		ENTRY(mercury__type_util__get_cons_id_arg_types_4_0));
Define_label(mercury__type_util__get_cons_id_arg_types_4_0_i6);
	update_prof_current_proc(LABEL(mercury__type_util__get_cons_id_arg_types_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__type_util__get_cons_id_arg_types_4_0_i2);
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_hlds_cons_defn_0;
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 4, mercury__type_util__get_cons_id_arg_types_4_0, "closure");
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_22);
	MR_field(MR_mktag(0), r2, (Integer) 1) = (Word) STATIC(mercury__type_util__IntroducedFrom__pred__get_cons_id_arg_types__663__1_2_0);
	MR_field(MR_mktag(0), r2, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r2, (Integer) 3) = MR_stackvar(3);
	call_localret(ENTRY(mercury__list__filter_3_0),
		mercury__type_util__get_cons_id_arg_types_4_0_i8,
		ENTRY(mercury__type_util__get_cons_id_arg_types_4_0));
Define_label(mercury__type_util__get_cons_id_arg_types_4_0_i8);
	update_prof_current_proc(LABEL(mercury__type_util__get_cons_id_arg_types_4_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__type_util__get_cons_id_arg_types_4_0_i2);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_hlds_cons_defn_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury__type_util__get_cons_id_arg_types_4_0_i10,
		ENTRY(mercury__type_util__get_cons_id_arg_types_4_0));
Define_label(mercury__type_util__get_cons_id_arg_types_4_0_i10);
	update_prof_current_proc(LABEL(mercury__type_util__get_cons_id_arg_types_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__type_util__get_cons_id_arg_types_4_0_i2);
	r2 = MR_stackvar(2);
	r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__type_util__get_cons_id_arg_types_4_0_i2);
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__hlds_module__module_info_types_2_0),
		mercury__type_util__get_cons_id_arg_types_4_0_i14,
		ENTRY(mercury__type_util__get_cons_id_arg_types_4_0));
Define_label(mercury__type_util__get_cons_id_arg_types_4_0_i14);
	update_prof_current_proc(LABEL(mercury__type_util__get_cons_id_arg_types_4_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_3);
	r2 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_hlds_type_defn_0;
	r4 = MR_stackvar(3);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__type_util__get_cons_id_arg_types_4_0_i15,
		ENTRY(mercury__type_util__get_cons_id_arg_types_4_0));
Define_label(mercury__type_util__get_cons_id_arg_types_4_0_i15);
	update_prof_current_proc(LABEL(mercury__type_util__get_cons_id_arg_types_4_0));
	call_localret(ENTRY(mercury__hlds_data__get_type_defn_tparams_2_0),
		mercury__type_util__get_cons_id_arg_types_4_0_i16,
		ENTRY(mercury__type_util__get_cons_id_arg_types_4_0));
Define_label(mercury__type_util__get_cons_id_arg_types_4_0_i16);
	update_prof_current_proc(LABEL(mercury__type_util__get_cons_id_arg_types_4_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	call_localret(ENTRY(mercury__term__term_list_to_var_list_2_0),
		mercury__type_util__get_cons_id_arg_types_4_0_i17,
		ENTRY(mercury__type_util__get_cons_id_arg_types_4_0));
Define_label(mercury__type_util__get_cons_id_arg_types_4_0_i17);
	update_prof_current_proc(LABEL(mercury__type_util__get_cons_id_arg_types_4_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 5, mercury__type_util__get_cons_id_arg_types_4_0, "closure");
	MR_field(MR_mktag(0), r1, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_24);
	MR_field(MR_mktag(0), r1, (Integer) 1) = (Word) STATIC(mercury__type_util__IntroducedFrom__pred__get_cons_id_arg_types__677__2_2_0);
	MR_field(MR_mktag(0), r1, (Integer) 2) = (Integer) 2;
	MR_field(MR_mktag(0), r1, (Integer) 3) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 4) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = (Word) MR_string_const("type_util__get_cons_id_arg_types: existentially typed cons_id", 61);
	call_localret(ENTRY(mercury__require__require_2_0),
		mercury__type_util__get_cons_id_arg_types_4_0_i18,
		ENTRY(mercury__type_util__get_cons_id_arg_types_4_0));
Define_label(mercury__type_util__get_cons_id_arg_types_4_0_i18);
	update_prof_current_proc(LABEL(mercury__type_util__get_cons_id_arg_types_4_0));
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_2);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(4);
	call_localret(ENTRY(mercury__map__from_corresponding_lists_3_0),
		mercury__type_util__get_cons_id_arg_types_4_0_i19,
		ENTRY(mercury__type_util__get_cons_id_arg_types_4_0));
Define_label(mercury__type_util__get_cons_id_arg_types_4_0_i19);
	update_prof_current_proc(LABEL(mercury__type_util__get_cons_id_arg_types_4_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury__term__apply_substitution_to_list_3_0),
		ENTRY(mercury__type_util__get_cons_id_arg_types_4_0));
Define_label(mercury__type_util__get_cons_id_arg_types_4_0_i2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_data__get_type_defn_tvarset_2_0);

BEGIN_MODULE(type_util_module39)
	init_entry(mercury__type_util__get_existq_cons_defn_4_0);
	init_label(mercury__type_util__get_existq_cons_defn_4_0_i2);
	init_label(mercury__type_util__get_existq_cons_defn_4_0_i4);
	init_label(mercury__type_util__get_existq_cons_defn_4_0_i5);
	init_label(mercury__type_util__get_existq_cons_defn_4_0_i7);
	init_label(mercury__type_util__get_existq_cons_defn_4_0_i9);
	init_label(mercury__type_util__get_existq_cons_defn_4_0_i13);
	init_label(mercury__type_util__get_existq_cons_defn_4_0_i14);
	init_label(mercury__type_util__get_existq_cons_defn_4_0_i16);
	init_label(mercury__type_util__get_existq_cons_defn_4_0_i17);
	init_label(mercury__type_util__get_existq_cons_defn_4_0_i18);
	init_label(mercury__type_util__get_existq_cons_defn_4_0_i19);
	init_label(mercury__type_util__get_existq_cons_defn_4_0_i1013);
	init_label(mercury__type_util__get_existq_cons_defn_4_0_i1);
BEGIN_CODE

/* code for predicate 'get_existq_cons_defn'/4 in mode 0 */
Define_entry(mercury__type_util__get_existq_cons_defn_4_0);
	MR_incr_sp_push_msg(7, "type_util:get_existq_cons_defn/4");
	MR_stackvar(7) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r2;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	call_localret(STATIC(mercury__type_util__type_to_type_id_3_0),
		mercury__type_util__get_existq_cons_defn_4_0_i2,
		ENTRY(mercury__type_util__get_existq_cons_defn_4_0));
Define_label(mercury__type_util__get_existq_cons_defn_4_0_i2);
	update_prof_current_proc(LABEL(mercury__type_util__get_existq_cons_defn_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__type_util__get_existq_cons_defn_4_0_i1);
	MR_stackvar(4) = r2;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_module__module_info_ctors_2_0),
		mercury__type_util__get_existq_cons_defn_4_0_i4,
		ENTRY(mercury__type_util__get_existq_cons_defn_4_0));
Define_label(mercury__type_util__get_existq_cons_defn_4_0_i4);
	update_prof_current_proc(LABEL(mercury__type_util__get_existq_cons_defn_4_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_cons_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_20);
	r4 = MR_stackvar(3);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__type_util__get_existq_cons_defn_4_0_i5,
		ENTRY(mercury__type_util__get_existq_cons_defn_4_0));
Define_label(mercury__type_util__get_existq_cons_defn_4_0_i5);
	update_prof_current_proc(LABEL(mercury__type_util__get_existq_cons_defn_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__type_util__get_existq_cons_defn_4_0_i1);
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_hlds_cons_defn_0;
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 4, mercury__type_util__get_existq_cons_defn_4_0, "closure");
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_25);
	MR_field(MR_mktag(0), r2, (Integer) 1) = (Word) STATIC(mercury__type_util__IntroducedFrom__pred__is_existq_cons__697__5_2_0);
	MR_field(MR_mktag(0), r2, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r2, (Integer) 3) = MR_stackvar(4);
	call_localret(ENTRY(mercury__list__filter_3_0),
		mercury__type_util__get_existq_cons_defn_4_0_i7,
		ENTRY(mercury__type_util__get_existq_cons_defn_4_0));
Define_label(mercury__type_util__get_existq_cons_defn_4_0_i7);
	update_prof_current_proc(LABEL(mercury__type_util__get_existq_cons_defn_4_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__type_util__get_existq_cons_defn_4_0_i1);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_hlds_cons_defn_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury__type_util__get_existq_cons_defn_4_0_i9,
		ENTRY(mercury__type_util__get_existq_cons_defn_4_0));
Define_label(mercury__type_util__get_existq_cons_defn_4_0_i9);
	update_prof_current_proc(LABEL(mercury__type_util__get_existq_cons_defn_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__type_util__get_existq_cons_defn_4_0_i1);
	r3 = MR_stackvar(3);
	r2 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__type_util__get_existq_cons_defn_4_0_i1);
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r3, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	call_localret(ENTRY(mercury__hlds_module__module_info_types_2_0),
		mercury__type_util__get_existq_cons_defn_4_0_i13,
		ENTRY(mercury__type_util__get_existq_cons_defn_4_0));
Define_label(mercury__type_util__get_existq_cons_defn_4_0_i13);
	update_prof_current_proc(LABEL(mercury__type_util__get_existq_cons_defn_4_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	call_localret(STATIC(mercury__type_util__type_to_type_id_3_0),
		mercury__type_util__get_existq_cons_defn_4_0_i14,
		ENTRY(mercury__type_util__get_existq_cons_defn_4_0));
Define_label(mercury__type_util__get_existq_cons_defn_4_0_i14);
	update_prof_current_proc(LABEL(mercury__type_util__get_existq_cons_defn_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__type_util__get_existq_cons_defn_4_0_i1);
	r3 = MR_stackvar(2);
	r4 = r2;
	MR_stackvar(2) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_3);
	r2 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_hlds_type_defn_0;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__type_util__get_existq_cons_defn_4_0_i16,
		ENTRY(mercury__type_util__get_existq_cons_defn_4_0));
Define_label(mercury__type_util__get_existq_cons_defn_4_0_i16);
	update_prof_current_proc(LABEL(mercury__type_util__get_existq_cons_defn_4_0));
	MR_stackvar(5) = r1;
	call_localret(ENTRY(mercury__hlds_data__get_type_defn_tvarset_2_0),
		mercury__type_util__get_existq_cons_defn_4_0_i17,
		ENTRY(mercury__type_util__get_existq_cons_defn_4_0));
Define_label(mercury__type_util__get_existq_cons_defn_4_0_i17);
	update_prof_current_proc(LABEL(mercury__type_util__get_existq_cons_defn_4_0));
	r2 = r1;
	r1 = MR_stackvar(5);
	MR_stackvar(5) = r2;
	call_localret(ENTRY(mercury__hlds_data__get_type_defn_tparams_2_0),
		mercury__type_util__get_existq_cons_defn_4_0_i18,
		ENTRY(mercury__type_util__get_existq_cons_defn_4_0));
Define_label(mercury__type_util__get_existq_cons_defn_4_0_i18);
	update_prof_current_proc(LABEL(mercury__type_util__get_existq_cons_defn_4_0));
	MR_stackvar(6) = r1;
	call_localret(ENTRY(mercury__term__context_init_1_0),
		mercury__type_util__get_existq_cons_defn_4_0_i19,
		ENTRY(mercury__type_util__get_existq_cons_defn_4_0));
Define_label(mercury__type_util__get_existq_cons_defn_4_0_i19);
	update_prof_current_proc(LABEL(mercury__type_util__get_existq_cons_defn_4_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(6);
	call_localret(STATIC(mercury__type_util__construct_type_4_0),
		mercury__type_util__get_existq_cons_defn_4_0_i1013,
		ENTRY(mercury__type_util__get_existq_cons_defn_4_0));
Define_label(mercury__type_util__get_existq_cons_defn_4_0_i1013);
	update_prof_current_proc(LABEL(mercury__type_util__get_existq_cons_defn_4_0));
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 5, mercury__type_util__get_existq_cons_defn_4_0, "type_util:ctor_defn/0");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(5);
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(0), r2, (Integer) 2) = MR_stackvar(3);
	MR_field(MR_mktag(0), r2, (Integer) 3) = MR_stackvar(4);
	MR_field(MR_mktag(0), r2, (Integer) 4) = r1;
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	r1 = TRUE;
	proceed();
Define_label(mercury__type_util__get_existq_cons_defn_4_0_i1);
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(type_util_module40)
	init_entry(mercury__type_util__is_existq_cons_3_0);
	init_label(mercury__type_util__is_existq_cons_3_0_i2);
	init_label(mercury__type_util__is_existq_cons_3_0_i4);
	init_label(mercury__type_util__is_existq_cons_3_0_i5);
	init_label(mercury__type_util__is_existq_cons_3_0_i7);
	init_label(mercury__type_util__is_existq_cons_3_0_i9);
	init_label(mercury__type_util__is_existq_cons_3_0_i1);
BEGIN_CODE

/* code for predicate 'is_existq_cons'/3 in mode 0 */
Define_entry(mercury__type_util__is_existq_cons_3_0);
	MR_incr_sp_push_msg(3, "type_util:is_existq_cons/3");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r2;
	MR_stackvar(2) = r3;
	call_localret(STATIC(mercury__type_util__type_to_type_id_3_0),
		mercury__type_util__is_existq_cons_3_0_i2,
		ENTRY(mercury__type_util__is_existq_cons_3_0));
Define_label(mercury__type_util__is_existq_cons_3_0_i2);
	update_prof_current_proc(LABEL(mercury__type_util__is_existq_cons_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__type_util__is_existq_cons_3_0_i1);
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__hlds_module__module_info_ctors_2_0),
		mercury__type_util__is_existq_cons_3_0_i4,
		ENTRY(mercury__type_util__is_existq_cons_3_0));
Define_label(mercury__type_util__is_existq_cons_3_0_i4);
	update_prof_current_proc(LABEL(mercury__type_util__is_existq_cons_3_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_cons_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_20);
	r4 = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__type_util__is_existq_cons_3_0_i5,
		ENTRY(mercury__type_util__is_existq_cons_3_0));
Define_label(mercury__type_util__is_existq_cons_3_0_i5);
	update_prof_current_proc(LABEL(mercury__type_util__is_existq_cons_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__type_util__is_existq_cons_3_0_i1);
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_hlds_cons_defn_0;
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 4, mercury__type_util__is_existq_cons_3_0, "closure");
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_25);
	MR_field(MR_mktag(0), r2, (Integer) 1) = (Word) STATIC(mercury__type_util__IntroducedFrom__pred__is_existq_cons__697__5_2_0);
	MR_field(MR_mktag(0), r2, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r2, (Integer) 3) = MR_stackvar(1);
	call_localret(ENTRY(mercury__list__filter_3_0),
		mercury__type_util__is_existq_cons_3_0_i7,
		ENTRY(mercury__type_util__is_existq_cons_3_0));
Define_label(mercury__type_util__is_existq_cons_3_0_i7);
	update_prof_current_proc(LABEL(mercury__type_util__is_existq_cons_3_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__type_util__is_existq_cons_3_0_i1);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_hlds_cons_defn_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury__type_util__is_existq_cons_3_0_i9,
		ENTRY(mercury__type_util__is_existq_cons_3_0));
Define_label(mercury__type_util__is_existq_cons_3_0_i9);
	update_prof_current_proc(LABEL(mercury__type_util__is_existq_cons_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__type_util__is_existq_cons_3_0_i1);
	if (((Integer) MR_const_field(MR_mktag(0), MR_stackvar(1), (Integer) 0) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__type_util__is_existq_cons_3_0_i1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	r1 = TRUE;
	proceed();
Define_label(mercury__type_util__is_existq_cons_3_0_i1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(type_util_module41)
	init_entry(mercury__type_util__type_is_no_tag_type_3_0);
	init_label(mercury__type_util__type_is_no_tag_type_3_0_i7);
	init_label(mercury__type_util__type_is_no_tag_type_3_0_i1014);
	init_label(mercury__type_util__type_is_no_tag_type_3_0_i1);
BEGIN_CODE

/* code for predicate 'type_is_no_tag_type'/3 in mode 0 */
Define_entry(mercury__type_util__type_is_no_tag_type_3_0);
	MR_incr_sp_push_msg(3, "type_util:type_is_no_tag_type/3");
	MR_stackvar(3) = (Word) MR_succip;
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__type_util__type_is_no_tag_type_3_0_i1014);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__type_util__type_is_no_tag_type_3_0_i1014);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 3) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__type_util__type_is_no_tag_type_3_0_i1014);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 3), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__type_util__type_is_no_tag_type_3_0_i1014);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__type_util__type_is_no_tag_type_3_0_i1014);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 2);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 3), (Integer) 0), (Integer) 1);
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__prog_util__unqualify_name_2_0),
		mercury__type_util__type_is_no_tag_type_3_0_i7,
		ENTRY(mercury__type_util__type_is_no_tag_type_3_0));
Define_label(mercury__type_util__type_is_no_tag_type_3_0_i7);
	update_prof_current_proc(LABEL(mercury__type_util__type_is_no_tag_type_3_0));
	if ((strcmp((char *)r1, (char *)(Word) MR_string_const("type_info", 9)) == 0))
		GOTO_LABEL(mercury__type_util__type_is_no_tag_type_3_0_i1);
	if ((strcmp((char *)r1, (char *)(Word) MR_string_const("type_ctor_info", 14)) == 0))
		GOTO_LABEL(mercury__type_util__type_is_no_tag_type_3_0_i1);
	if ((strcmp((char *)r1, (char *)(Word) MR_string_const("typeclass_info", 14)) == 0))
		GOTO_LABEL(mercury__type_util__type_is_no_tag_type_3_0_i1);
	if ((strcmp((char *)r1, (char *)(Word) MR_string_const("base_typeclass_info", 19)) == 0))
		GOTO_LABEL(mercury__type_util__type_is_no_tag_type_3_0_i1);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__type_util__type_is_no_tag_type_3_0_i1014);
	r1 = FALSE;
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__type_util__type_is_no_tag_type_3_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE

Declare_entry(mercury____Unify___term__const_0_0);
Declare_entry(mercury__term__occurs_list_3_0);
Declare_entry(mercury__list__member_2_0);
Declare_entry(mercury__map__det_insert_4_0);
Declare_entry(mercury__term__apply_rec_substitution_3_0);
Declare_entry(mercury____Unify___term__var_1_0);
Declare_entry(mercury__term__occurs_3_0);

BEGIN_MODULE(type_util_module42)
	init_entry(mercury__type_util__type_unify_5_0);
	init_label(mercury__type_util__type_unify_5_0_i1023);
	init_label(mercury__type_util__type_unify_5_0_i6);
	init_label(mercury__type_util__type_unify_5_0_i7);
	init_label(mercury__type_util__type_unify_5_0_i8);
	init_label(mercury__type_util__type_unify_5_0_i5);
	init_label(mercury__type_util__type_unify_5_0_i13);
	init_label(mercury__type_util__type_unify_5_0_i12);
	init_label(mercury__type_util__type_unify_5_0_i18);
	init_label(mercury__type_util__type_unify_5_0_i21);
	init_label(mercury__type_util__type_unify_5_0_i3);
	init_label(mercury__type_util__type_unify_5_0_i28);
	init_label(mercury__type_util__type_unify_5_0_i27);
	init_label(mercury__type_util__type_unify_5_0_i33);
	init_label(mercury__type_util__type_unify_5_0_i36);
	init_label(mercury__type_util__type_unify_5_0_i26);
	init_label(mercury__type_util__type_unify_5_0_i41);
	init_label(mercury__type_util__type_unify_5_0_i40);
	init_label(mercury__type_util__type_unify_5_0_i46);
	init_label(mercury__type_util__type_unify_5_0_i45);
	init_label(mercury__type_util__type_unify_5_0_i51);
	init_label(mercury__type_util__type_unify_5_0_i54);
	init_label(mercury__type_util__type_unify_5_0_i53);
	init_label(mercury__type_util__type_unify_5_0_i58);
	init_label(mercury__type_util__type_unify_5_0_i62);
	init_label(mercury__type_util__type_unify_5_0_i59);
	init_label(mercury__type_util__type_unify_5_0_i60);
	init_label(mercury__type_util__type_unify_5_0_i65);
	init_label(mercury__type_util__type_unify_5_0_i50);
	init_label(mercury__type_util__type_unify_5_0_i71);
	init_label(mercury__type_util__type_unify_5_0_i73);
	init_label(mercury__type_util__type_unify_5_0_i77);
	init_label(mercury__type_util__type_unify_5_0_i74);
	init_label(mercury__type_util__type_unify_5_0_i75);
	init_label(mercury__type_util__type_unify_5_0_i80);
	init_label(mercury__type_util__type_unify_5_0_i70);
	init_label(mercury__type_util__type_unify_5_0_i85);
	init_label(mercury__type_util__type_unify_5_0_i84);
	init_label(mercury__type_util__type_unify_5_0_i87);
	init_label(mercury__type_util__type_unify_5_0_i1);
BEGIN_CODE

/* code for predicate 'type_unify'/5 in mode 0 */
Define_entry(mercury__type_util__type_unify_5_0);
	MR_incr_sp_push_msg(8, "type_util:type_unify/5");
	MR_stackvar(8) = (Word) MR_succip;
Define_label(mercury__type_util__type_unify_5_0_i1023);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__type_util__type_unify_5_0_i3);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__type_util__type_unify_5_0_i5);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(6) = r2;
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_2);
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__type_util__type_unify_5_0_i6,
		ENTRY(mercury__type_util__type_unify_5_0));
Define_label(mercury__type_util__type_unify_5_0_i6);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_5_0));
	MR_stackvar(5) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_2);
	r2 = MR_stackvar(4);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__type_util__type_unify_5_0_i7,
		ENTRY(mercury__type_util__type_unify_5_0));
Define_label(mercury__type_util__type_unify_5_0_i7);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_5_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(7);
	call_localret(ENTRY(mercury____Unify___term__const_0_0),
		mercury__type_util__type_unify_5_0_i8,
		ENTRY(mercury__type_util__type_unify_5_0));
Define_label(mercury__type_util__type_unify_5_0_i8);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__type_util__type_unify_5_0_i1);
	if ((MR_stackvar(5) != MR_stackvar(1)))
		GOTO_LABEL(mercury__type_util__type_unify_5_0_i1);
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	tailcall(STATIC(mercury__type_util__type_unify_list_5_0),
		ENTRY(mercury__type_util__type_unify_5_0));
Define_label(mercury__type_util__type_unify_5_0_i5);
	MR_stackvar(2) = r3;
	r3 = r4;
	MR_stackvar(3) = r4;
	r4 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(4) = r4;
	MR_stackvar(1) = r1;
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_2);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__type_util__type_unify_5_0_i13,
		ENTRY(mercury__type_util__type_unify_5_0));
Define_label(mercury__type_util__type_unify_5_0_i13);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__type_util__type_unify_5_0_i12);
	r1 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(8);
	GOTO_LABEL(mercury__type_util__type_unify_5_0_i1023);
Define_label(mercury__type_util__type_unify_5_0_i12);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	r2 = MR_stackvar(6);
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(3);
	call_localret(ENTRY(mercury__term__occurs_list_3_0),
		mercury__type_util__type_unify_5_0_i18,
		ENTRY(mercury__type_util__type_unify_5_0));
Define_label(mercury__type_util__type_unify_5_0_i18);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_5_0));
	if (r1)
		GOTO_LABEL(mercury__type_util__type_unify_5_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_1);
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__type_util__type_unify_5_0_i21,
		ENTRY(mercury__type_util__type_unify_5_0));
Define_label(mercury__type_util__type_unify_5_0_i21);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_5_0));
	if (r1)
		GOTO_LABEL(mercury__type_util__type_unify_5_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	r5 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__type_util__type_unify_5_0_i87,
		ENTRY(mercury__type_util__type_unify_5_0));
Define_label(mercury__type_util__type_unify_5_0_i3);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__type_util__type_unify_5_0_i26);
	MR_stackvar(2) = r3;
	r3 = r4;
	MR_stackvar(3) = r4;
	r4 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(6) = r4;
	MR_stackvar(1) = r2;
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_2);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__type_util__type_unify_5_0_i28,
		ENTRY(mercury__type_util__type_unify_5_0));
Define_label(mercury__type_util__type_unify_5_0_i28);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__type_util__type_unify_5_0_i27);
	r1 = r2;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(8);
	GOTO_LABEL(mercury__type_util__type_unify_5_0_i1023);
Define_label(mercury__type_util__type_unify_5_0_i27);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(6);
	r4 = MR_stackvar(3);
	call_localret(ENTRY(mercury__term__occurs_list_3_0),
		mercury__type_util__type_unify_5_0_i33,
		ENTRY(mercury__type_util__type_unify_5_0));
Define_label(mercury__type_util__type_unify_5_0_i33);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_5_0));
	if (r1)
		GOTO_LABEL(mercury__type_util__type_unify_5_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_1);
	r2 = MR_stackvar(6);
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__type_util__type_unify_5_0_i36,
		ENTRY(mercury__type_util__type_unify_5_0));
Define_label(mercury__type_util__type_unify_5_0_i36);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_5_0));
	if (r1)
		GOTO_LABEL(mercury__type_util__type_unify_5_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(6);
	r5 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__type_util__type_unify_5_0_i87,
		ENTRY(mercury__type_util__type_unify_5_0));
Define_label(mercury__type_util__type_unify_5_0_i26);
	MR_stackvar(1) = r2;
	MR_stackvar(6) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(4) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_1);
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__type_util__type_unify_5_0_i41,
		ENTRY(mercury__type_util__type_unify_5_0));
Define_label(mercury__type_util__type_unify_5_0_i41);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__type_util__type_unify_5_0_i40);
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	tailcall(STATIC(mercury__type_util__type_unify_head_type_param_5_0),
		ENTRY(mercury__type_util__type_unify_5_0));
Define_label(mercury__type_util__type_unify_5_0_i40);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_1);
	r2 = MR_stackvar(6);
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__type_util__type_unify_5_0_i46,
		ENTRY(mercury__type_util__type_unify_5_0));
Define_label(mercury__type_util__type_unify_5_0_i46);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__type_util__type_unify_5_0_i45);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(6);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	tailcall(STATIC(mercury__type_util__type_unify_head_type_param_5_0),
		ENTRY(mercury__type_util__type_unify_5_0));
Define_label(mercury__type_util__type_unify_5_0_i45);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(6);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__type_util__type_unify_5_0_i51,
		ENTRY(mercury__type_util__type_unify_5_0));
Define_label(mercury__type_util__type_unify_5_0_i51);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__type_util__type_unify_5_0_i50);
	MR_stackvar(5) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__type_util__type_unify_5_0_i54,
		ENTRY(mercury__type_util__type_unify_5_0));
Define_label(mercury__type_util__type_unify_5_0_i54);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__type_util__type_unify_5_0_i53);
	r1 = MR_stackvar(5);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(8);
	GOTO_LABEL(mercury__type_util__type_unify_5_0_i1023);
Define_label(mercury__type_util__type_unify_5_0_i53);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury__term__apply_rec_substitution_3_0),
		mercury__type_util__type_unify_5_0_i58,
		ENTRY(mercury__type_util__type_unify_5_0));
Define_label(mercury__type_util__type_unify_5_0_i58);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_5_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__type_util__type_unify_5_0_i60);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(2) = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	r2 = MR_stackvar(4);
	call_localret(ENTRY(mercury____Unify___term__var_1_0),
		mercury__type_util__type_unify_5_0_i62,
		ENTRY(mercury__type_util__type_unify_5_0));
Define_label(mercury__type_util__type_unify_5_0_i62);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__type_util__type_unify_5_0_i59);
	r2 = MR_stackvar(3);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__type_util__type_unify_5_0_i59);
	r1 = MR_stackvar(2);
Define_label(mercury__type_util__type_unify_5_0_i60);
	MR_stackvar(2) = r1;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(3);
	call_localret(ENTRY(mercury__term__occurs_3_0),
		mercury__type_util__type_unify_5_0_i65,
		ENTRY(mercury__type_util__type_unify_5_0));
Define_label(mercury__type_util__type_unify_5_0_i65);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_5_0));
	if (r1)
		GOTO_LABEL(mercury__type_util__type_unify_5_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	r5 = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__type_util__type_unify_5_0_i87,
		ENTRY(mercury__type_util__type_unify_5_0));
Define_label(mercury__type_util__type_unify_5_0_i50);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__type_util__type_unify_5_0_i71,
		ENTRY(mercury__type_util__type_unify_5_0));
Define_label(mercury__type_util__type_unify_5_0_i71);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__type_util__type_unify_5_0_i70);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury__term__apply_rec_substitution_3_0),
		mercury__type_util__type_unify_5_0_i73,
		ENTRY(mercury__type_util__type_unify_5_0));
Define_label(mercury__type_util__type_unify_5_0_i73);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_5_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__type_util__type_unify_5_0_i75);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(2) = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	r2 = MR_stackvar(6);
	call_localret(ENTRY(mercury____Unify___term__var_1_0),
		mercury__type_util__type_unify_5_0_i77,
		ENTRY(mercury__type_util__type_unify_5_0));
Define_label(mercury__type_util__type_unify_5_0_i77);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__type_util__type_unify_5_0_i74);
	r2 = MR_stackvar(3);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__type_util__type_unify_5_0_i74);
	r1 = MR_stackvar(2);
Define_label(mercury__type_util__type_unify_5_0_i75);
	MR_stackvar(2) = r1;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	r3 = MR_stackvar(6);
	r4 = MR_stackvar(3);
	call_localret(ENTRY(mercury__term__occurs_3_0),
		mercury__type_util__type_unify_5_0_i80,
		ENTRY(mercury__type_util__type_unify_5_0));
Define_label(mercury__type_util__type_unify_5_0_i80);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_5_0));
	if (r1)
		GOTO_LABEL(mercury__type_util__type_unify_5_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(6);
	r5 = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__type_util__type_unify_5_0_i87,
		ENTRY(mercury__type_util__type_unify_5_0));
Define_label(mercury__type_util__type_unify_5_0_i70);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	r2 = MR_stackvar(6);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury____Unify___term__var_1_0),
		mercury__type_util__type_unify_5_0_i85,
		ENTRY(mercury__type_util__type_unify_5_0));
Define_label(mercury__type_util__type_unify_5_0_i85);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__type_util__type_unify_5_0_i84);
	r2 = MR_stackvar(3);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__type_util__type_unify_5_0_i84);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(6);
	r5 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__type_util__type_unify_5_0_i87,
		ENTRY(mercury__type_util__type_unify_5_0));
Define_label(mercury__type_util__type_unify_5_0_i87);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_5_0));
	r2 = r1;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__type_util__type_unify_5_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
END_MODULE


BEGIN_MODULE(type_util_module43)
	init_entry(mercury__type_util__type_unify_list_5_0);
	init_label(mercury__type_util__type_unify_list_5_0_i1004);
	init_label(mercury__type_util__type_unify_list_5_0_i3);
	init_label(mercury__type_util__type_unify_list_5_0_i6);
	init_label(mercury__type_util__type_unify_list_5_0_i1);
BEGIN_CODE

/* code for predicate 'type_unify_list'/5 in mode 0 */
Define_entry(mercury__type_util__type_unify_list_5_0);
	MR_incr_sp_push_msg(4, "type_util:type_unify_list/5");
	MR_stackvar(4) = (Word) MR_succip;
Define_label(mercury__type_util__type_unify_list_5_0_i1004);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__type_util__type_unify_list_5_0_i3);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__type_util__type_unify_list_5_0_i1);
	r2 = r4;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__type_util__type_unify_list_5_0_i3);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__type_util__type_unify_list_5_0_i1);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(1) = r3;
	call_localret(STATIC(mercury__type_util__type_unify_5_0),
		mercury__type_util__type_unify_list_5_0_i6,
		ENTRY(mercury__type_util__type_unify_list_5_0));
Define_label(mercury__type_util__type_unify_list_5_0_i6);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_list_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__type_util__type_unify_list_5_0_i1);
	r4 = r2;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(4);
	GOTO_LABEL(mercury__type_util__type_unify_list_5_0_i1004);
Define_label(mercury__type_util__type_unify_list_5_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE

Declare_entry(mercury__term__vars_2_0);

BEGIN_MODULE(type_util_module44)
	init_entry(mercury__type_util__vars_2_0);
BEGIN_CODE

/* code for predicate 'vars'/2 in mode 0 */
Define_entry(mercury__type_util__vars_2_0);
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	tailcall(ENTRY(mercury__term__vars_2_0),
		ENTRY(mercury__type_util__vars_2_0));
END_MODULE

Declare_entry(mercury__term__vars_list_2_0);
Declare_entry(mercury__map__init_1_0);

BEGIN_MODULE(type_util_module45)
	init_entry(mercury__type_util__type_list_subsumes_3_0);
	init_label(mercury__type_util__type_list_subsumes_3_0_i2);
	init_label(mercury__type_util__type_list_subsumes_3_0_i3);
BEGIN_CODE

/* code for predicate 'type_list_subsumes'/3 in mode 0 */
Define_entry(mercury__type_util__type_list_subsumes_3_0);
	MR_incr_sp_push_msg(4, "type_util:type_list_subsumes/3");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__term__vars_list_2_0),
		mercury__type_util__type_list_subsumes_3_0_i2,
		ENTRY(mercury__type_util__type_list_subsumes_3_0));
Define_label(mercury__type_util__type_list_subsumes_3_0_i2);
	update_prof_current_proc(LABEL(mercury__type_util__type_list_subsumes_3_0));
	MR_stackvar(3) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_2);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__type_util__type_list_subsumes_3_0_i3,
		ENTRY(mercury__type_util__type_list_subsumes_3_0));
Define_label(mercury__type_util__type_list_subsumes_3_0_i3);
	update_prof_current_proc(LABEL(mercury__type_util__type_list_subsumes_3_0));
	r4 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__type_util__type_unify_list_5_0),
		ENTRY(mercury__type_util__type_list_subsumes_3_0));
END_MODULE

Declare_entry(mercury__map__is_empty_1_0);
Declare_entry(mercury__map__keys_2_0);

BEGIN_MODULE(type_util_module46)
	init_entry(mercury__type_util__apply_substitution_to_type_map_3_0);
	init_label(mercury__type_util__apply_substitution_to_type_map_3_0_i3);
	init_label(mercury__type_util__apply_substitution_to_type_map_3_0_i2);
	init_label(mercury__type_util__apply_substitution_to_type_map_3_0_i5);
BEGIN_CODE

/* code for predicate 'apply_substitution_to_type_map'/3 in mode 0 */
Define_entry(mercury__type_util__apply_substitution_to_type_map_3_0);
	MR_incr_sp_push_msg(3, "type_util:apply_substitution_to_type_map/3");
	MR_stackvar(3) = (Word) MR_succip;
	r3 = r2;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_2);
	call_localret(ENTRY(mercury__map__is_empty_1_0),
		mercury__type_util__apply_substitution_to_type_map_3_0_i3,
		ENTRY(mercury__type_util__apply_substitution_to_type_map_3_0));
Define_label(mercury__type_util__apply_substitution_to_type_map_3_0_i3);
	update_prof_current_proc(LABEL(mercury__type_util__apply_substitution_to_type_map_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__type_util__apply_substitution_to_type_map_3_0_i2);
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__type_util__apply_substitution_to_type_map_3_0_i2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_26);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_2);
	r3 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__keys_2_0),
		mercury__type_util__apply_substitution_to_type_map_3_0_i5,
		ENTRY(mercury__type_util__apply_substitution_to_type_map_3_0));
Define_label(mercury__type_util__apply_substitution_to_type_map_3_0_i5);
	update_prof_current_proc(LABEL(mercury__type_util__apply_substitution_to_type_map_3_0));
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__type_util__apply_substitution_to_type_map_2_4_0),
		ENTRY(mercury__type_util__apply_substitution_to_type_map_3_0));
END_MODULE


BEGIN_MODULE(type_util_module47)
	init_entry(mercury__type_util__apply_rec_substitution_to_type_map_3_0);
	init_label(mercury__type_util__apply_rec_substitution_to_type_map_3_0_i3);
	init_label(mercury__type_util__apply_rec_substitution_to_type_map_3_0_i2);
	init_label(mercury__type_util__apply_rec_substitution_to_type_map_3_0_i5);
BEGIN_CODE

/* code for predicate 'apply_rec_substitution_to_type_map'/3 in mode 0 */
Define_entry(mercury__type_util__apply_rec_substitution_to_type_map_3_0);
	MR_incr_sp_push_msg(3, "type_util:apply_rec_substitution_to_type_map/3");
	MR_stackvar(3) = (Word) MR_succip;
	r3 = r2;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_2);
	call_localret(ENTRY(mercury__map__is_empty_1_0),
		mercury__type_util__apply_rec_substitution_to_type_map_3_0_i3,
		ENTRY(mercury__type_util__apply_rec_substitution_to_type_map_3_0));
Define_label(mercury__type_util__apply_rec_substitution_to_type_map_3_0_i3);
	update_prof_current_proc(LABEL(mercury__type_util__apply_rec_substitution_to_type_map_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__type_util__apply_rec_substitution_to_type_map_3_0_i2);
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__type_util__apply_rec_substitution_to_type_map_3_0_i2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_26);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_2);
	r3 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__keys_2_0),
		mercury__type_util__apply_rec_substitution_to_type_map_3_0_i5,
		ENTRY(mercury__type_util__apply_rec_substitution_to_type_map_3_0));
Define_label(mercury__type_util__apply_rec_substitution_to_type_map_3_0_i5);
	update_prof_current_proc(LABEL(mercury__type_util__apply_rec_substitution_to_type_map_3_0));
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__type_util__apply_rec_substitution_to_type_map_2_4_0),
		ENTRY(mercury__type_util__apply_rec_substitution_to_type_map_3_0));
END_MODULE

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_type_info_locn_0;

BEGIN_MODULE(type_util_module48)
	init_entry(mercury__type_util__apply_substitutions_to_var_map_5_0);
	init_label(mercury__type_util__apply_substitutions_to_var_map_5_0_i3);
	init_label(mercury__type_util__apply_substitutions_to_var_map_5_0_i5);
	init_label(mercury__type_util__apply_substitutions_to_var_map_5_0_i7);
	init_label(mercury__type_util__apply_substitutions_to_var_map_5_0_i2);
	init_label(mercury__type_util__apply_substitutions_to_var_map_5_0_i9);
	init_label(mercury__type_util__apply_substitutions_to_var_map_5_0_i10);
BEGIN_CODE

/* code for predicate 'apply_substitutions_to_var_map'/5 in mode 0 */
Define_entry(mercury__type_util__apply_substitutions_to_var_map_5_0);
	MR_incr_sp_push_msg(6, "type_util:apply_substitutions_to_var_map/5");
	MR_stackvar(6) = (Word) MR_succip;
	MR_stackvar(3) = r3;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_26);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_26);
	r3 = r4;
	MR_stackvar(4) = r4;
	call_localret(ENTRY(mercury__map__is_empty_1_0),
		mercury__type_util__apply_substitutions_to_var_map_5_0_i3,
		ENTRY(mercury__type_util__apply_substitutions_to_var_map_5_0));
Define_label(mercury__type_util__apply_substitutions_to_var_map_5_0_i3);
	update_prof_current_proc(LABEL(mercury__type_util__apply_substitutions_to_var_map_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__type_util__apply_substitutions_to_var_map_5_0_i2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_2);
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury__map__is_empty_1_0),
		mercury__type_util__apply_substitutions_to_var_map_5_0_i5,
		ENTRY(mercury__type_util__apply_substitutions_to_var_map_5_0));
Define_label(mercury__type_util__apply_substitutions_to_var_map_5_0_i5);
	update_prof_current_proc(LABEL(mercury__type_util__apply_substitutions_to_var_map_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__type_util__apply_substitutions_to_var_map_5_0_i2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_2);
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__is_empty_1_0),
		mercury__type_util__apply_substitutions_to_var_map_5_0_i7,
		ENTRY(mercury__type_util__apply_substitutions_to_var_map_5_0));
Define_label(mercury__type_util__apply_substitutions_to_var_map_5_0_i7);
	update_prof_current_proc(LABEL(mercury__type_util__apply_substitutions_to_var_map_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__type_util__apply_substitutions_to_var_map_5_0_i2);
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__type_util__apply_substitutions_to_var_map_5_0_i2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_1);
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_type_info_locn_0;
	r3 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__keys_2_0),
		mercury__type_util__apply_substitutions_to_var_map_5_0_i9,
		ENTRY(mercury__type_util__apply_substitutions_to_var_map_5_0));
Define_label(mercury__type_util__apply_substitutions_to_var_map_5_0_i9);
	update_prof_current_proc(LABEL(mercury__type_util__apply_substitutions_to_var_map_5_0));
	MR_stackvar(5) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_1);
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_type_info_locn_0;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__type_util__apply_substitutions_to_var_map_5_0_i10,
		ENTRY(mercury__type_util__apply_substitutions_to_var_map_5_0));
Define_label(mercury__type_util__apply_substitutions_to_var_map_5_0_i10);
	update_prof_current_proc(LABEL(mercury__type_util__apply_substitutions_to_var_map_5_0));
	r6 = r1;
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(STATIC(mercury__type_util__apply_substitutions_to_var_map_2_7_0),
		ENTRY(mercury__type_util__apply_substitutions_to_var_map_5_0));
END_MODULE

Declare_entry(mercury__map__to_assoc_list_2_0);
Declare_entry(mercury__list__map_3_0);
Declare_entry(mercury__map__from_assoc_list_2_0);

BEGIN_MODULE(type_util_module49)
	init_entry(mercury__type_util__apply_substitutions_to_typeclass_var_map_5_0);
	init_label(mercury__type_util__apply_substitutions_to_typeclass_var_map_5_0_i2);
	init_label(mercury__type_util__apply_substitutions_to_typeclass_var_map_5_0_i3);
BEGIN_CODE

/* code for predicate 'apply_substitutions_to_typeclass_var_map'/5 in mode 0 */
Define_entry(mercury__type_util__apply_substitutions_to_typeclass_var_map_5_0);
	MR_incr_sp_push_msg(4, "type_util:apply_substitutions_to_typeclass_var_map/5");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(2) = r3;
	r3 = r1;
	MR_stackvar(1) = r2;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_class_constraint_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_26);
	MR_stackvar(3) = r4;
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__type_util__apply_substitutions_to_typeclass_var_map_5_0_i2,
		ENTRY(mercury__type_util__apply_substitutions_to_typeclass_var_map_5_0));
Define_label(mercury__type_util__apply_substitutions_to_typeclass_var_map_5_0_i2);
	update_prof_current_proc(LABEL(mercury__type_util__apply_substitutions_to_typeclass_var_map_5_0));
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 6, mercury__type_util__apply_substitutions_to_typeclass_var_map_5_0, "origin_lost_in_value_number");
	r4 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_27);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_27);
	MR_field(MR_mktag(0), r3, (Integer) 5) = MR_stackvar(3);
	MR_field(MR_mktag(0), r3, (Integer) 4) = MR_stackvar(2);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 3;
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(1);
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) STATIC(mercury__type_util__apply_substitutions_to_typeclass_var_map_2_5_0);
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_30);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__type_util__apply_substitutions_to_typeclass_var_map_5_0_i3,
		ENTRY(mercury__type_util__apply_substitutions_to_typeclass_var_map_5_0));
Define_label(mercury__type_util__apply_substitutions_to_typeclass_var_map_5_0_i3);
	update_prof_current_proc(LABEL(mercury__type_util__apply_substitutions_to_typeclass_var_map_5_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_class_constraint_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_26);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__map__from_assoc_list_2_0),
		ENTRY(mercury__type_util__apply_substitutions_to_typeclass_var_map_5_0));
END_MODULE


BEGIN_MODULE(type_util_module50)
	init_entry(mercury__type_util__apply_rec_subst_to_constraints_3_0);
	init_label(mercury__type_util__apply_rec_subst_to_constraints_3_0_i2);
	init_label(mercury__type_util__apply_rec_subst_to_constraints_3_0_i3);
BEGIN_CODE

/* code for predicate 'apply_rec_subst_to_constraints'/3 in mode 0 */
Define_entry(mercury__type_util__apply_rec_subst_to_constraints_3_0);
	MR_incr_sp_push_msg(3, "type_util:apply_rec_subst_to_constraints/3");
	MR_stackvar(3) = (Word) MR_succip;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__type_util__apply_rec_subst_to_constraints_3_0, "origin_lost_in_value_number");
	r4 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(2) = r3;
	MR_field(MR_mktag(0), r3, (Integer) 3) = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_class_constraint_0;
	r2 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_class_constraint_0;
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_32);
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) ENTRY(mercury__type_util__apply_rec_subst_to_constraint_3_0);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__type_util__apply_rec_subst_to_constraints_3_0_i2,
		ENTRY(mercury__type_util__apply_rec_subst_to_constraints_3_0));
Define_label(mercury__type_util__apply_rec_subst_to_constraints_3_0_i2);
	update_prof_current_proc(LABEL(mercury__type_util__apply_rec_subst_to_constraints_3_0));
	r4 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_class_constraint_0;
	r2 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_class_constraint_0;
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__type_util__apply_rec_subst_to_constraints_3_0_i3,
		ENTRY(mercury__type_util__apply_rec_subst_to_constraints_3_0));
Define_label(mercury__type_util__apply_rec_subst_to_constraints_3_0_i3);
	update_prof_current_proc(LABEL(mercury__type_util__apply_rec_subst_to_constraints_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__type_util__apply_rec_subst_to_constraints_3_0, "prog_data:class_constraints/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(type_util_module51)
	init_entry(mercury__type_util__apply_rec_subst_to_constraint_list_3_0);
BEGIN_CODE

/* code for predicate 'apply_rec_subst_to_constraint_list'/3 in mode 0 */
Define_entry(mercury__type_util__apply_rec_subst_to_constraint_list_3_0);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__type_util__apply_rec_subst_to_constraint_list_3_0, "origin_lost_in_value_number");
	r4 = r2;
	MR_field(MR_mktag(0), r3, (Integer) 3) = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_class_constraint_0;
	r2 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_class_constraint_0;
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) ENTRY(mercury__type_util__apply_rec_subst_to_constraint_3_0);
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_32);
	tailcall(ENTRY(mercury__list__map_3_0),
		ENTRY(mercury__type_util__apply_rec_subst_to_constraint_list_3_0));
END_MODULE

Declare_entry(mercury__term__apply_rec_substitution_to_list_3_0);

BEGIN_MODULE(type_util_module52)
	init_entry(mercury__type_util__apply_rec_subst_to_constraint_3_0);
	init_label(mercury__type_util__apply_rec_subst_to_constraint_3_0_i2);
	init_label(mercury__type_util__apply_rec_subst_to_constraint_3_0_i3);
BEGIN_CODE

/* code for predicate 'apply_rec_subst_to_constraint'/3 in mode 0 */
Define_entry(mercury__type_util__apply_rec_subst_to_constraint_3_0);
	MR_incr_sp_push_msg(2, "type_util:apply_rec_subst_to_constraint/3");
	MR_stackvar(2) = (Word) MR_succip;
	r3 = r1;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	call_localret(ENTRY(mercury__term__apply_rec_substitution_to_list_3_0),
		mercury__type_util__apply_rec_subst_to_constraint_3_0_i2,
		ENTRY(mercury__type_util__apply_rec_subst_to_constraint_3_0));
Define_label(mercury__type_util__apply_rec_subst_to_constraint_3_0_i2);
	update_prof_current_proc(LABEL(mercury__type_util__apply_rec_subst_to_constraint_3_0));
	r4 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_2);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_2);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_37);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__type_util__apply_rec_subst_to_constraint_3_0_i3,
		ENTRY(mercury__type_util__apply_rec_subst_to_constraint_3_0));
Define_label(mercury__type_util__apply_rec_subst_to_constraint_3_0_i3);
	update_prof_current_proc(LABEL(mercury__type_util__apply_rec_subst_to_constraint_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__type_util__apply_rec_subst_to_constraint_3_0, "prog_data:class_constraint/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE


BEGIN_MODULE(type_util_module53)
	init_entry(mercury__type_util__apply_subst_to_constraints_3_0);
	init_label(mercury__type_util__apply_subst_to_constraints_3_0_i2);
	init_label(mercury__type_util__apply_subst_to_constraints_3_0_i3);
BEGIN_CODE

/* code for predicate 'apply_subst_to_constraints'/3 in mode 0 */
Define_entry(mercury__type_util__apply_subst_to_constraints_3_0);
	MR_incr_sp_push_msg(3, "type_util:apply_subst_to_constraints/3");
	MR_stackvar(3) = (Word) MR_succip;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__type_util__apply_subst_to_constraints_3_0, "origin_lost_in_value_number");
	r4 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(2) = r3;
	MR_field(MR_mktag(0), r3, (Integer) 3) = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_class_constraint_0;
	r2 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_class_constraint_0;
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_38);
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) ENTRY(mercury__type_util__apply_subst_to_constraint_3_0);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__type_util__apply_subst_to_constraints_3_0_i2,
		ENTRY(mercury__type_util__apply_subst_to_constraints_3_0));
Define_label(mercury__type_util__apply_subst_to_constraints_3_0_i2);
	update_prof_current_proc(LABEL(mercury__type_util__apply_subst_to_constraints_3_0));
	r4 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_class_constraint_0;
	r2 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_class_constraint_0;
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__type_util__apply_subst_to_constraints_3_0_i3,
		ENTRY(mercury__type_util__apply_subst_to_constraints_3_0));
Define_label(mercury__type_util__apply_subst_to_constraints_3_0_i3);
	update_prof_current_proc(LABEL(mercury__type_util__apply_subst_to_constraints_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__type_util__apply_subst_to_constraints_3_0, "prog_data:class_constraints/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(type_util_module54)
	init_entry(mercury__type_util__apply_subst_to_constraint_list_3_0);
BEGIN_CODE

/* code for predicate 'apply_subst_to_constraint_list'/3 in mode 0 */
Define_entry(mercury__type_util__apply_subst_to_constraint_list_3_0);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__type_util__apply_subst_to_constraint_list_3_0, "origin_lost_in_value_number");
	r4 = r2;
	MR_field(MR_mktag(0), r3, (Integer) 3) = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_class_constraint_0;
	r2 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_class_constraint_0;
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) ENTRY(mercury__type_util__apply_subst_to_constraint_3_0);
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_38);
	tailcall(ENTRY(mercury__list__map_3_0),
		ENTRY(mercury__type_util__apply_subst_to_constraint_list_3_0));
END_MODULE


BEGIN_MODULE(type_util_module55)
	init_entry(mercury__type_util__apply_subst_to_constraint_3_0);
	init_label(mercury__type_util__apply_subst_to_constraint_3_0_i2);
BEGIN_CODE

/* code for predicate 'apply_subst_to_constraint'/3 in mode 0 */
Define_entry(mercury__type_util__apply_subst_to_constraint_3_0);
	MR_incr_sp_push_msg(2, "type_util:apply_subst_to_constraint/3");
	MR_stackvar(2) = (Word) MR_succip;
	r3 = r1;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	call_localret(ENTRY(mercury__term__apply_substitution_to_list_3_0),
		mercury__type_util__apply_subst_to_constraint_3_0_i2,
		ENTRY(mercury__type_util__apply_subst_to_constraint_3_0));
Define_label(mercury__type_util__apply_subst_to_constraint_3_0_i2);
	update_prof_current_proc(LABEL(mercury__type_util__apply_subst_to_constraint_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__type_util__apply_subst_to_constraint_3_0, "prog_data:class_constraint/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE

Declare_entry(mercury__map__foldl_4_0);

BEGIN_MODULE(type_util_module56)
	init_entry(mercury__type_util__apply_subst_to_constraint_proofs_3_0);
	init_label(mercury__type_util__apply_subst_to_constraint_proofs_3_0_i2);
BEGIN_CODE

/* code for predicate 'apply_subst_to_constraint_proofs'/3 in mode 0 */
Define_entry(mercury__type_util__apply_subst_to_constraint_proofs_3_0);
	MR_incr_sp_push_msg(3, "type_util:apply_subst_to_constraint_proofs/3");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_class_constraint_0;
	r2 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_constraint_proof_0;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__type_util__apply_subst_to_constraint_proofs_3_0_i2,
		ENTRY(mercury__type_util__apply_subst_to_constraint_proofs_3_0));
Define_label(mercury__type_util__apply_subst_to_constraint_proofs_3_0_i2);
	update_prof_current_proc(LABEL(mercury__type_util__apply_subst_to_constraint_proofs_3_0));
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 4, mercury__type_util__apply_subst_to_constraint_proofs_3_0, "origin_lost_in_value_number");
	r6 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_class_constraint_0;
	r2 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_constraint_proof_0;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_39);
	r5 = MR_stackvar(2);
	MR_field(MR_mktag(0), r4, (Integer) 3) = MR_stackvar(1);
	MR_field(MR_mktag(0), r4, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r4, (Integer) 1) = (Word) STATIC(mercury__type_util__IntroducedFrom__pred__apply_subst_to_constraint_proofs__1153__3_5_0);
	MR_field(MR_mktag(0), r4, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_41);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__map__foldl_4_0),
		ENTRY(mercury__type_util__apply_subst_to_constraint_proofs_3_0));
END_MODULE


BEGIN_MODULE(type_util_module57)
	init_entry(mercury__type_util__apply_rec_subst_to_constraint_proofs_3_0);
	init_label(mercury__type_util__apply_rec_subst_to_constraint_proofs_3_0_i2);
BEGIN_CODE

/* code for predicate 'apply_rec_subst_to_constraint_proofs'/3 in mode 0 */
Define_entry(mercury__type_util__apply_rec_subst_to_constraint_proofs_3_0);
	MR_incr_sp_push_msg(3, "type_util:apply_rec_subst_to_constraint_proofs/3");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_class_constraint_0;
	r2 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_constraint_proof_0;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__type_util__apply_rec_subst_to_constraint_proofs_3_0_i2,
		ENTRY(mercury__type_util__apply_rec_subst_to_constraint_proofs_3_0));
Define_label(mercury__type_util__apply_rec_subst_to_constraint_proofs_3_0_i2);
	update_prof_current_proc(LABEL(mercury__type_util__apply_rec_subst_to_constraint_proofs_3_0));
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 4, mercury__type_util__apply_rec_subst_to_constraint_proofs_3_0, "origin_lost_in_value_number");
	r6 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_class_constraint_0;
	r2 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_constraint_proof_0;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_39);
	r5 = MR_stackvar(2);
	MR_field(MR_mktag(0), r4, (Integer) 3) = MR_stackvar(1);
	MR_field(MR_mktag(0), r4, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r4, (Integer) 1) = (Word) STATIC(mercury__type_util__IntroducedFrom__pred__apply_rec_subst_to_constraint_proofs__1173__4_5_0);
	MR_field(MR_mktag(0), r4, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_42);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__map__foldl_4_0),
		ENTRY(mercury__type_util__apply_rec_subst_to_constraint_proofs_3_0));
END_MODULE


BEGIN_MODULE(type_util_module58)
	init_entry(mercury__type_util__apply_variable_renaming_to_constraints_3_0);
	init_label(mercury__type_util__apply_variable_renaming_to_constraints_3_0_i2);
	init_label(mercury__type_util__apply_variable_renaming_to_constraints_3_0_i3);
BEGIN_CODE

/* code for predicate 'apply_variable_renaming_to_constraints'/3 in mode 0 */
Define_entry(mercury__type_util__apply_variable_renaming_to_constraints_3_0);
	MR_incr_sp_push_msg(3, "type_util:apply_variable_renaming_to_constraints/3");
	MR_stackvar(3) = (Word) MR_succip;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__type_util__apply_variable_renaming_to_constraints_3_0, "origin_lost_in_value_number");
	r4 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(2) = r3;
	MR_field(MR_mktag(0), r3, (Integer) 3) = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_class_constraint_0;
	r2 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_class_constraint_0;
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_44);
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) ENTRY(mercury__type_util__apply_variable_renaming_to_constraint_3_0);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__type_util__apply_variable_renaming_to_constraints_3_0_i2,
		ENTRY(mercury__type_util__apply_variable_renaming_to_constraints_3_0));
Define_label(mercury__type_util__apply_variable_renaming_to_constraints_3_0_i2);
	update_prof_current_proc(LABEL(mercury__type_util__apply_variable_renaming_to_constraints_3_0));
	r4 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_class_constraint_0;
	r2 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_class_constraint_0;
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__type_util__apply_variable_renaming_to_constraints_3_0_i3,
		ENTRY(mercury__type_util__apply_variable_renaming_to_constraints_3_0));
Define_label(mercury__type_util__apply_variable_renaming_to_constraints_3_0_i3);
	update_prof_current_proc(LABEL(mercury__type_util__apply_variable_renaming_to_constraints_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__type_util__apply_variable_renaming_to_constraints_3_0, "prog_data:class_constraints/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(type_util_module59)
	init_entry(mercury__type_util__apply_variable_renaming_to_constraint_list_3_0);
BEGIN_CODE

/* code for predicate 'apply_variable_renaming_to_constraint_list'/3 in mode 0 */
Define_entry(mercury__type_util__apply_variable_renaming_to_constraint_list_3_0);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__type_util__apply_variable_renaming_to_constraint_list_3_0, "origin_lost_in_value_number");
	r4 = r2;
	MR_field(MR_mktag(0), r3, (Integer) 3) = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_class_constraint_0;
	r2 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_class_constraint_0;
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) ENTRY(mercury__type_util__apply_variable_renaming_to_constraint_3_0);
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_44);
	tailcall(ENTRY(mercury__list__map_3_0),
		ENTRY(mercury__type_util__apply_variable_renaming_to_constraint_list_3_0));
END_MODULE

Declare_entry(mercury__term__apply_variable_renaming_to_list_3_0);

BEGIN_MODULE(type_util_module60)
	init_entry(mercury__type_util__apply_variable_renaming_to_constraint_3_0);
	init_label(mercury__type_util__apply_variable_renaming_to_constraint_3_0_i2);
BEGIN_CODE

/* code for predicate 'apply_variable_renaming_to_constraint'/3 in mode 0 */
Define_entry(mercury__type_util__apply_variable_renaming_to_constraint_3_0);
	MR_incr_sp_push_msg(2, "type_util:apply_variable_renaming_to_constraint/3");
	MR_stackvar(2) = (Word) MR_succip;
	r3 = r1;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	call_localret(ENTRY(mercury__term__apply_variable_renaming_to_list_3_0),
		mercury__type_util__apply_variable_renaming_to_constraint_3_0_i2,
		ENTRY(mercury__type_util__apply_variable_renaming_to_constraint_3_0));
Define_label(mercury__type_util__apply_variable_renaming_to_constraint_3_0_i2);
	update_prof_current_proc(LABEL(mercury__type_util__apply_variable_renaming_to_constraint_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__type_util__apply_variable_renaming_to_constraint_3_0, "prog_data:class_constraint/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE


BEGIN_MODULE(type_util_module61)
	init_entry(mercury__type_util__apply_partial_map_to_list_3_0);
	init_label(mercury__type_util__apply_partial_map_to_list_3_0_i6);
	init_label(mercury__type_util__apply_partial_map_to_list_3_0_i4);
	init_label(mercury__type_util__apply_partial_map_to_list_3_0_i9);
	init_label(mercury__type_util__apply_partial_map_to_list_3_0_i3);
BEGIN_CODE

/* code for predicate 'apply_partial_map_to_list'/3 in mode 0 */
Define_entry(mercury__type_util__apply_partial_map_to_list_3_0);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__type_util__apply_partial_map_to_list_3_0_i3);
	MR_incr_sp_push_msg(6, "type_util:apply_partial_map_to_list/3");
	MR_stackvar(6) = (Word) MR_succip;
	r4 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(2) = r4;
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r2 = r1;
	MR_stackvar(1) = r3;
	MR_stackvar(5) = r1;
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__type_util__apply_partial_map_to_list_3_0_i6,
		ENTRY(mercury__type_util__apply_partial_map_to_list_3_0));
Define_label(mercury__type_util__apply_partial_map_to_list_3_0_i6);
	update_prof_current_proc(LABEL(mercury__type_util__apply_partial_map_to_list_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__type_util__apply_partial_map_to_list_3_0_i4);
	MR_stackvar(4) = r2;
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(1);
	localcall(mercury__type_util__apply_partial_map_to_list_3_0,
		LABEL(mercury__type_util__apply_partial_map_to_list_3_0_i9),
		ENTRY(mercury__type_util__apply_partial_map_to_list_3_0));
Define_label(mercury__type_util__apply_partial_map_to_list_3_0_i4);
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(1);
	MR_stackvar(4) = MR_stackvar(2);
	localcall(mercury__type_util__apply_partial_map_to_list_3_0,
		LABEL(mercury__type_util__apply_partial_map_to_list_3_0_i9),
		ENTRY(mercury__type_util__apply_partial_map_to_list_3_0));
Define_label(mercury__type_util__apply_partial_map_to_list_3_0_i9);
	update_prof_current_proc(LABEL(mercury__type_util__apply_partial_map_to_list_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__type_util__apply_partial_map_to_list_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__type_util__apply_partial_map_to_list_3_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE


BEGIN_MODULE(type_util_module62)
	init_entry(mercury__type_util__strip_prog_contexts_2_0);
BEGIN_CODE

/* code for predicate 'strip_prog_contexts'/2 in mode 0 */
Define_entry(mercury__type_util__strip_prog_contexts_2_0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__type_util__strip_prog_contexts_2_0, "private_builtin:type_info/1");
	MR_field(MR_mktag(0), r1, (Integer) 0) = (Word) (Word *) &mercury_data_term__type_ctor_info_term_1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r3;
	r4 = r2;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__type_util__strip_prog_contexts_2_0, "private_builtin:type_info/1");
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) (Word *) &mercury_data_term__type_ctor_info_term_1;
	MR_field(MR_mktag(0), r2, (Integer) 1) = r3;
	r5 = r3;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__type_util__strip_prog_contexts_2_0, "closure");
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_36);
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) ENTRY(mercury__type_util__strip_prog_context_2_0);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r3, (Integer) 3) = r5;
	tailcall(ENTRY(mercury__list__map_3_0),
		ENTRY(mercury__type_util__strip_prog_contexts_2_0));
END_MODULE


BEGIN_MODULE(type_util_module63)
	init_entry(mercury__type_util__strip_prog_context_2_0);
	init_label(mercury__type_util__strip_prog_context_2_0_i4);
	init_label(mercury__type_util__strip_prog_context_2_0_i5);
	init_label(mercury__type_util__strip_prog_context_2_0_i3);
BEGIN_CODE

/* code for predicate 'strip_prog_context'/2 in mode 0 */
Define_entry(mercury__type_util__strip_prog_context_2_0);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__type_util__strip_prog_context_2_0_i3);
	MR_incr_sp_push_msg(4, "type_util:strip_prog_context/2");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(3) = r1;
	call_localret(ENTRY(mercury__term__context_init_1_0),
		mercury__type_util__strip_prog_context_2_0_i4,
		ENTRY(mercury__type_util__strip_prog_context_2_0));
Define_label(mercury__type_util__strip_prog_context_2_0_i4);
	update_prof_current_proc(LABEL(mercury__type_util__strip_prog_context_2_0));
	r2 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__type_util__strip_prog_context_2_0, "private_builtin:type_info/1");
	MR_field(MR_mktag(0), r1, (Integer) 0) = (Word) (Word *) &mercury_data_term__type_ctor_info_term_1;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(3);
	r4 = r2;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__type_util__strip_prog_context_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_stackvar(3);
	MR_field(MR_mktag(0), r2, (Integer) 0) = (Word) (Word *) &mercury_data_term__type_ctor_info_term_1;
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__type_util__strip_prog_context_2_0, "closure");
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_36);
	MR_field(MR_mktag(0), r3, (Integer) 1) = (Word) ENTRY(mercury__type_util__strip_prog_context_2_0);
	MR_field(MR_mktag(0), r3, (Integer) 2) = (Integer) 1;
	MR_field(MR_mktag(0), r3, (Integer) 3) = MR_stackvar(3);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__type_util__strip_prog_context_2_0_i5,
		ENTRY(mercury__type_util__strip_prog_context_2_0));
Define_label(mercury__type_util__strip_prog_context_2_0_i5);
	update_prof_current_proc(LABEL(mercury__type_util__strip_prog_context_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 3, mercury__type_util__strip_prog_context_2_0, "term:term/1");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), r1, (Integer) 1) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__type_util__strip_prog_context_2_0_i3);
	r1 = r2;
	proceed();
END_MODULE

Declare_entry(mercury__hlds_data__cons_id_arity_2_0);
Declare_entry(mercury__list__delete_elems_3_0);

BEGIN_MODULE(type_util_module64)
	init_entry(mercury__fn__type_util__cons_id_adjusted_arity_3_0);
	init_label(mercury__fn__type_util__cons_id_adjusted_arity_3_0_i2);
	init_label(mercury__fn__type_util__cons_id_adjusted_arity_3_0_i5);
	init_label(mercury__fn__type_util__cons_id_adjusted_arity_3_0_i7);
	init_label(mercury__fn__type_util__cons_id_adjusted_arity_3_0_i8);
	init_label(mercury__fn__type_util__cons_id_adjusted_arity_3_0_i9);
	init_label(mercury__fn__type_util__cons_id_adjusted_arity_3_0_i10);
	init_label(mercury__fn__type_util__cons_id_adjusted_arity_3_0_i3);
BEGIN_CODE

/* code for predicate 'cons_id_adjusted_arity'/4 in mode 0 */
Define_entry(mercury__fn__type_util__cons_id_adjusted_arity_3_0);
	MR_incr_sp_push_msg(4, "type_util:cons_id_adjusted_arity/4");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r3;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__hlds_data__cons_id_arity_2_0),
		mercury__fn__type_util__cons_id_adjusted_arity_3_0_i2,
		ENTRY(mercury__fn__type_util__cons_id_adjusted_arity_3_0));
Define_label(mercury__fn__type_util__cons_id_adjusted_arity_3_0_i2);
	update_prof_current_proc(LABEL(mercury__fn__type_util__cons_id_adjusted_arity_3_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	call_localret(STATIC(mercury__type_util__get_existq_cons_defn_4_0),
		mercury__fn__type_util__cons_id_adjusted_arity_3_0_i5,
		ENTRY(mercury__fn__type_util__cons_id_adjusted_arity_3_0));
	}
Define_label(mercury__fn__type_util__cons_id_adjusted_arity_3_0_i5);
	update_prof_current_proc(LABEL(mercury__fn__type_util__cons_id_adjusted_arity_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__fn__type_util__cons_id_adjusted_arity_3_0_i3);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(3) = r2;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_class_constraint_0;
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__fn__type_util__cons_id_adjusted_arity_3_0_i7,
		ENTRY(mercury__fn__type_util__cons_id_adjusted_arity_3_0));
Define_label(mercury__fn__type_util__cons_id_adjusted_arity_3_0_i7);
	update_prof_current_proc(LABEL(mercury__fn__type_util__cons_id_adjusted_arity_3_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	MR_stackvar(3) = r2;
	call_localret(STATIC(mercury__type_util__constraint_list_get_tvars_2_0),
		mercury__fn__type_util__cons_id_adjusted_arity_3_0_i8,
		ENTRY(mercury__fn__type_util__cons_id_adjusted_arity_3_0));
Define_label(mercury__fn__type_util__cons_id_adjusted_arity_3_0_i8);
	update_prof_current_proc(LABEL(mercury__fn__type_util__cons_id_adjusted_arity_3_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_1);
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__list__delete_elems_3_0),
		mercury__fn__type_util__cons_id_adjusted_arity_3_0_i9,
		ENTRY(mercury__fn__type_util__cons_id_adjusted_arity_3_0));
Define_label(mercury__fn__type_util__cons_id_adjusted_arity_3_0_i9);
	update_prof_current_proc(LABEL(mercury__fn__type_util__cons_id_adjusted_arity_3_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_1);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__fn__type_util__cons_id_adjusted_arity_3_0_i10,
		ENTRY(mercury__fn__type_util__cons_id_adjusted_arity_3_0));
Define_label(mercury__fn__type_util__cons_id_adjusted_arity_3_0_i10);
	update_prof_current_proc(LABEL(mercury__fn__type_util__cons_id_adjusted_arity_3_0));
	r1 = (((Integer) MR_stackvar(1) + (Integer) MR_stackvar(3)) + (Integer) r1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__fn__type_util__cons_id_adjusted_arity_3_0_i3);
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE

Declare_entry(mercury__list__condense_2_0);

BEGIN_MODULE(type_util_module65)
	init_entry(mercury__type_util__constraint_list_get_tvars_2_0);
	init_label(mercury__type_util__constraint_list_get_tvars_2_0_i2);
BEGIN_CODE

/* code for predicate 'constraint_list_get_tvars'/2 in mode 0 */
Define_entry(mercury__type_util__constraint_list_get_tvars_2_0);
	MR_incr_sp_push_msg(1, "type_util:constraint_list_get_tvars/2");
	MR_stackvar(1) = (Word) MR_succip;
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_class_constraint_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_23);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_46);
	call_localret(ENTRY(mercury__list__map_3_0),
		mercury__type_util__constraint_list_get_tvars_2_0_i2,
		ENTRY(mercury__type_util__constraint_list_get_tvars_2_0));
Define_label(mercury__type_util__constraint_list_get_tvars_2_0_i2);
	update_prof_current_proc(LABEL(mercury__type_util__constraint_list_get_tvars_2_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_1);
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__list__condense_2_0),
		ENTRY(mercury__type_util__constraint_list_get_tvars_2_0));
END_MODULE


BEGIN_MODULE(type_util_module66)
	init_entry(mercury__type_util__constraint_get_tvars_2_0);
BEGIN_CODE

/* code for predicate 'constraint_get_tvars'/2 in mode 0 */
Define_entry(mercury__type_util__constraint_get_tvars_2_0);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	tailcall(ENTRY(mercury__term__vars_list_2_0),
		ENTRY(mercury__type_util__constraint_get_tvars_2_0));
END_MODULE


BEGIN_MODULE(type_util_module67)
	init_entry(mercury__type_util__substitute_type_args_2_3_0);
	init_label(mercury__type_util__substitute_type_args_2_3_0_i4);
	init_label(mercury__type_util__substitute_type_args_2_3_0_i5);
	init_label(mercury__type_util__substitute_type_args_2_3_0_i3);
BEGIN_CODE

/* code for predicate 'substitute_type_args_2'/3 in mode 0 */
Define_static(mercury__type_util__substitute_type_args_2_3_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__type_util__substitute_type_args_2_3_0_i3);
	MR_incr_sp_push_msg(6, "type_util:substitute_type_args_2/3");
	MR_stackvar(6) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r3, (Integer) 3);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r3, (Integer) 2);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__type_util__substitute_type_args_3_3_0),
		mercury__type_util__substitute_type_args_2_3_0_i4,
		STATIC(mercury__type_util__substitute_type_args_2_3_0));
Define_label(mercury__type_util__substitute_type_args_2_3_0_i4);
	update_prof_current_proc(LABEL(mercury__type_util__substitute_type_args_2_3_0));
	r2 = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 4, mercury__type_util__substitute_type_args_2_3_0, "origin_lost_in_value_number");
	MR_stackvar(1) = r3;
	MR_field(MR_mktag(0), r3, (Integer) 3) = r1;
	r1 = MR_stackvar(2);
	MR_field(MR_mktag(0), r3, (Integer) 2) = MR_stackvar(5);
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(4);
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(3);
	localcall(mercury__type_util__substitute_type_args_2_3_0,
		LABEL(mercury__type_util__substitute_type_args_2_3_0_i5),
		STATIC(mercury__type_util__substitute_type_args_2_3_0));
Define_label(mercury__type_util__substitute_type_args_2_3_0_i5);
	update_prof_current_proc(LABEL(mercury__type_util__substitute_type_args_2_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__type_util__substitute_type_args_2_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__type_util__substitute_type_args_2_3_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE

Declare_entry(mercury__term__apply_substitution_3_0);

BEGIN_MODULE(type_util_module68)
	init_entry(mercury__type_util__substitute_type_args_3_3_0);
	init_label(mercury__type_util__substitute_type_args_3_3_0_i4);
	init_label(mercury__type_util__substitute_type_args_3_3_0_i5);
	init_label(mercury__type_util__substitute_type_args_3_3_0_i3);
BEGIN_CODE

/* code for predicate 'substitute_type_args_3'/3 in mode 0 */
Define_static(mercury__type_util__substitute_type_args_3_3_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__type_util__substitute_type_args_3_3_0_i3);
	MR_incr_sp_push_msg(4, "type_util:substitute_type_args_3/3");
	MR_stackvar(4) = (Word) MR_succip;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r3 = r2;
	MR_stackvar(1) = r2;
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	call_localret(ENTRY(mercury__term__apply_substitution_3_0),
		mercury__type_util__substitute_type_args_3_3_0_i4,
		STATIC(mercury__type_util__substitute_type_args_3_3_0));
	}
Define_label(mercury__type_util__substitute_type_args_3_3_0_i4);
	update_prof_current_proc(LABEL(mercury__type_util__substitute_type_args_3_3_0));
	r2 = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__type_util__substitute_type_args_3_3_0, "origin_lost_in_value_number");
	MR_stackvar(1) = r3;
	MR_field(MR_mktag(0), r3, (Integer) 1) = r1;
	r1 = MR_stackvar(3);
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(2);
	localcall(mercury__type_util__substitute_type_args_3_3_0,
		LABEL(mercury__type_util__substitute_type_args_3_3_0_i5),
		STATIC(mercury__type_util__substitute_type_args_3_3_0));
Define_label(mercury__type_util__substitute_type_args_3_3_0_i5);
	update_prof_current_proc(LABEL(mercury__type_util__substitute_type_args_3_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__type_util__substitute_type_args_3_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__type_util__substitute_type_args_3_3_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE


BEGIN_MODULE(type_util_module69)
	init_entry(mercury__type_util__type_unify_head_type_param_5_0);
	init_label(mercury__type_util__type_unify_head_type_param_5_0_i1004);
	init_label(mercury__type_util__type_unify_head_type_param_5_0_i3);
	init_label(mercury__type_util__type_unify_head_type_param_5_0_i2);
	init_label(mercury__type_util__type_unify_head_type_param_5_0_i9);
	init_label(mercury__type_util__type_unify_head_type_param_5_0_i8);
	init_label(mercury__type_util__type_unify_head_type_param_5_0_i12);
	init_label(mercury__type_util__type_unify_head_type_param_5_0_i14);
	init_label(mercury__type_util__type_unify_head_type_param_5_0_i1);
BEGIN_CODE

/* code for predicate 'type_unify_head_type_param'/5 in mode 0 */
Define_static(mercury__type_util__type_unify_head_type_param_5_0);
	MR_incr_sp_push_msg(5, "type_util:type_unify_head_type_param/5");
	MR_stackvar(5) = (Word) MR_succip;
Define_label(mercury__type_util__type_unify_head_type_param_5_0_i1004);
	MR_stackvar(3) = r3;
	r3 = r4;
	MR_stackvar(4) = r4;
	r4 = r1;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_2);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__type_util__type_unify_head_type_param_5_0_i3,
		STATIC(mercury__type_util__type_unify_head_type_param_5_0));
Define_label(mercury__type_util__type_unify_head_type_param_5_0_i3);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_head_type_param_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__type_util__type_unify_head_type_param_5_0_i2);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__type_util__type_unify_head_type_param_5_0_i1);
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	GOTO_LABEL(mercury__type_util__type_unify_head_type_param_5_0_i1004);
Define_label(mercury__type_util__type_unify_head_type_param_5_0_i2);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury____Unify___term__var_1_0),
		mercury__type_util__type_unify_head_type_param_5_0_i9,
		STATIC(mercury__type_util__type_unify_head_type_param_5_0));
Define_label(mercury__type_util__type_unify_head_type_param_5_0_i9);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_head_type_param_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__type_util__type_unify_head_type_param_5_0_i8);
	r2 = MR_stackvar(4);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__type_util__type_unify_head_type_param_5_0_i8);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_1);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__type_util__type_unify_head_type_param_5_0_i12,
		STATIC(mercury__type_util__type_unify_head_type_param_5_0));
Define_label(mercury__type_util__type_unify_head_type_param_5_0_i12);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_head_type_param_5_0));
	if (r1)
		GOTO_LABEL(mercury__type_util__type_unify_head_type_param_5_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_2);
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(1);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 1, mercury__type_util__type_unify_head_type_param_5_0, "term:term/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__type_util__type_unify_head_type_param_5_0_i14,
		STATIC(mercury__type_util__type_unify_head_type_param_5_0));
Define_label(mercury__type_util__type_unify_head_type_param_5_0_i14);
	update_prof_current_proc(LABEL(mercury__type_util__type_unify_head_type_param_5_0));
	r2 = r1;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__type_util__type_unify_head_type_param_5_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE

Declare_entry(mercury__map__det_update_4_0);

BEGIN_MODULE(type_util_module70)
	init_entry(mercury__type_util__apply_substitution_to_type_map_2_4_0);
	init_label(mercury__type_util__apply_substitution_to_type_map_2_4_0_i1001);
	init_label(mercury__type_util__apply_substitution_to_type_map_2_4_0_i4);
	init_label(mercury__type_util__apply_substitution_to_type_map_2_4_0_i5);
	init_label(mercury__type_util__apply_substitution_to_type_map_2_4_0_i6);
	init_label(mercury__type_util__apply_substitution_to_type_map_2_4_0_i3);
BEGIN_CODE

/* code for predicate 'apply_substitution_to_type_map_2'/4 in mode 0 */
Define_static(mercury__type_util__apply_substitution_to_type_map_2_4_0);
	MR_incr_sp_push_msg(5, "type_util:apply_substitution_to_type_map_2/4");
	MR_stackvar(5) = (Word) MR_succip;
Define_label(mercury__type_util__apply_substitution_to_type_map_2_4_0_i1001);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__type_util__apply_substitution_to_type_map_2_4_0_i3);
	MR_stackvar(2) = r3;
	r4 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(3) = r4;
	r3 = r2;
	MR_stackvar(1) = r2;
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_26);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_2);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__type_util__apply_substitution_to_type_map_2_4_0_i4,
		STATIC(mercury__type_util__apply_substitution_to_type_map_2_4_0));
Define_label(mercury__type_util__apply_substitution_to_type_map_2_4_0_i4);
	update_prof_current_proc(LABEL(mercury__type_util__apply_substitution_to_type_map_2_4_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__term__apply_substitution_3_0),
		mercury__type_util__apply_substitution_to_type_map_2_4_0_i5,
		STATIC(mercury__type_util__apply_substitution_to_type_map_2_4_0));
Define_label(mercury__type_util__apply_substitution_to_type_map_2_4_0_i5);
	update_prof_current_proc(LABEL(mercury__type_util__apply_substitution_to_type_map_2_4_0));
	r5 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_26);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_2);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(3);
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__type_util__apply_substitution_to_type_map_2_4_0_i6,
		STATIC(mercury__type_util__apply_substitution_to_type_map_2_4_0));
Define_label(mercury__type_util__apply_substitution_to_type_map_2_4_0_i6);
	update_prof_current_proc(LABEL(mercury__type_util__apply_substitution_to_type_map_2_4_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(5);
	GOTO_LABEL(mercury__type_util__apply_substitution_to_type_map_2_4_0_i1001);
Define_label(mercury__type_util__apply_substitution_to_type_map_2_4_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE


BEGIN_MODULE(type_util_module71)
	init_entry(mercury__type_util__apply_rec_substitution_to_type_map_2_4_0);
	init_label(mercury__type_util__apply_rec_substitution_to_type_map_2_4_0_i1001);
	init_label(mercury__type_util__apply_rec_substitution_to_type_map_2_4_0_i4);
	init_label(mercury__type_util__apply_rec_substitution_to_type_map_2_4_0_i5);
	init_label(mercury__type_util__apply_rec_substitution_to_type_map_2_4_0_i6);
	init_label(mercury__type_util__apply_rec_substitution_to_type_map_2_4_0_i3);
BEGIN_CODE

/* code for predicate 'apply_rec_substitution_to_type_map_2'/4 in mode 0 */
Define_static(mercury__type_util__apply_rec_substitution_to_type_map_2_4_0);
	MR_incr_sp_push_msg(5, "type_util:apply_rec_substitution_to_type_map_2/4");
	MR_stackvar(5) = (Word) MR_succip;
Define_label(mercury__type_util__apply_rec_substitution_to_type_map_2_4_0_i1001);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__type_util__apply_rec_substitution_to_type_map_2_4_0_i3);
	MR_stackvar(2) = r3;
	r4 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(3) = r4;
	r3 = r2;
	MR_stackvar(1) = r2;
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_26);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_2);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__type_util__apply_rec_substitution_to_type_map_2_4_0_i4,
		STATIC(mercury__type_util__apply_rec_substitution_to_type_map_2_4_0));
Define_label(mercury__type_util__apply_rec_substitution_to_type_map_2_4_0_i4);
	update_prof_current_proc(LABEL(mercury__type_util__apply_rec_substitution_to_type_map_2_4_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__term__apply_rec_substitution_3_0),
		mercury__type_util__apply_rec_substitution_to_type_map_2_4_0_i5,
		STATIC(mercury__type_util__apply_rec_substitution_to_type_map_2_4_0));
Define_label(mercury__type_util__apply_rec_substitution_to_type_map_2_4_0_i5);
	update_prof_current_proc(LABEL(mercury__type_util__apply_rec_substitution_to_type_map_2_4_0));
	r5 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_26);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_2);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(3);
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__type_util__apply_rec_substitution_to_type_map_2_4_0_i6,
		STATIC(mercury__type_util__apply_rec_substitution_to_type_map_2_4_0));
Define_label(mercury__type_util__apply_rec_substitution_to_type_map_2_4_0_i6);
	update_prof_current_proc(LABEL(mercury__type_util__apply_rec_substitution_to_type_map_2_4_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(5);
	GOTO_LABEL(mercury__type_util__apply_rec_substitution_to_type_map_2_4_0_i1001);
Define_label(mercury__type_util__apply_rec_substitution_to_type_map_2_4_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_pred__type_info_locn_var_2_0);
Declare_entry(mercury__hlds_pred__type_info_locn_set_var_3_0);

BEGIN_MODULE(type_util_module72)
	init_entry(mercury__type_util__apply_substitutions_to_var_map_2_7_0);
	init_label(mercury__type_util__apply_substitutions_to_var_map_2_7_0_i1005);
	init_label(mercury__type_util__apply_substitutions_to_var_map_2_7_0_i4);
	init_label(mercury__type_util__apply_substitutions_to_var_map_2_7_0_i5);
	init_label(mercury__type_util__apply_substitutions_to_var_map_2_7_0_i7);
	init_label(mercury__type_util__apply_substitutions_to_var_map_2_7_0_i6);
	init_label(mercury__type_util__apply_substitutions_to_var_map_2_7_0_i10);
	init_label(mercury__type_util__apply_substitutions_to_var_map_2_7_0_i12);
	init_label(mercury__type_util__apply_substitutions_to_var_map_2_7_0_i14);
	init_label(mercury__type_util__apply_substitutions_to_var_map_2_7_0_i16);
	init_label(mercury__type_util__apply_substitutions_to_var_map_2_7_0_i11);
	init_label(mercury__type_util__apply_substitutions_to_var_map_2_7_0_i18);
	init_label(mercury__type_util__apply_substitutions_to_var_map_2_7_0_i19);
	init_label(mercury__type_util__apply_substitutions_to_var_map_2_7_0_i22);
	init_label(mercury__type_util__apply_substitutions_to_var_map_2_7_0_i20);
	init_label(mercury__type_util__apply_substitutions_to_var_map_2_7_0_i3);
BEGIN_CODE

/* code for predicate 'apply_substitutions_to_var_map_2'/7 in mode 0 */
Define_static(mercury__type_util__apply_substitutions_to_var_map_2_7_0);
	MR_incr_sp_push_msg(11, "type_util:apply_substitutions_to_var_map_2/7");
	MR_stackvar(11) = (Word) MR_succip;
Define_label(mercury__type_util__apply_substitutions_to_var_map_2_7_0_i1005);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__type_util__apply_substitutions_to_var_map_2_7_0_i3);
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	r4 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(6) = r4;
	r3 = r2;
	MR_stackvar(1) = r2;
	MR_stackvar(7) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_1);
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_type_info_locn_0;
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r6;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__type_util__apply_substitutions_to_var_map_2_7_0_i4,
		STATIC(mercury__type_util__apply_substitutions_to_var_map_2_7_0));
Define_label(mercury__type_util__apply_substitutions_to_var_map_2_7_0_i4);
	update_prof_current_proc(LABEL(mercury__type_util__apply_substitutions_to_var_map_2_7_0));
	MR_stackvar(8) = r1;
	call_localret(ENTRY(mercury__hlds_pred__type_info_locn_var_2_0),
		mercury__type_util__apply_substitutions_to_var_map_2_7_0_i5,
		STATIC(mercury__type_util__apply_substitutions_to_var_map_2_7_0));
Define_label(mercury__type_util__apply_substitutions_to_var_map_2_7_0_i5);
	update_prof_current_proc(LABEL(mercury__type_util__apply_substitutions_to_var_map_2_7_0));
	r4 = r1;
	MR_stackvar(9) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_26);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_26);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__type_util__apply_substitutions_to_var_map_2_7_0_i7,
		STATIC(mercury__type_util__apply_substitutions_to_var_map_2_7_0));
Define_label(mercury__type_util__apply_substitutions_to_var_map_2_7_0_i7);
	update_prof_current_proc(LABEL(mercury__type_util__apply_substitutions_to_var_map_2_7_0));
	if (!(r1))
		GOTO_LABEL(mercury__type_util__apply_substitutions_to_var_map_2_7_0_i6);
	r1 = MR_stackvar(8);
	call_localret(ENTRY(mercury__hlds_pred__type_info_locn_set_var_3_0),
		mercury__type_util__apply_substitutions_to_var_map_2_7_0_i10,
		STATIC(mercury__type_util__apply_substitutions_to_var_map_2_7_0));
Define_label(mercury__type_util__apply_substitutions_to_var_map_2_7_0_i6);
	r1 = MR_stackvar(8);
	r2 = MR_stackvar(9);
	call_localret(ENTRY(mercury__hlds_pred__type_info_locn_set_var_3_0),
		mercury__type_util__apply_substitutions_to_var_map_2_7_0_i10,
		STATIC(mercury__type_util__apply_substitutions_to_var_map_2_7_0));
Define_label(mercury__type_util__apply_substitutions_to_var_map_2_7_0_i10);
	update_prof_current_proc(LABEL(mercury__type_util__apply_substitutions_to_var_map_2_7_0));
	MR_stackvar(10) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_2);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(6);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__type_util__apply_substitutions_to_var_map_2_7_0_i12,
		STATIC(mercury__type_util__apply_substitutions_to_var_map_2_7_0));
Define_label(mercury__type_util__apply_substitutions_to_var_map_2_7_0_i12);
	update_prof_current_proc(LABEL(mercury__type_util__apply_substitutions_to_var_map_2_7_0));
	if (!(r1))
		GOTO_LABEL(mercury__type_util__apply_substitutions_to_var_map_2_7_0_i11);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__type_util__apply_substitutions_to_var_map_2_7_0_i14);
	r3 = MR_stackvar(3);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	GOTO_LABEL(mercury__type_util__apply_substitutions_to_var_map_2_7_0_i18);
Define_label(mercury__type_util__apply_substitutions_to_var_map_2_7_0_i14);
	r1 = (Word) MR_string_const("apply_substitution_to_var_map_2: weird type renaming", 52);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__type_util__apply_substitutions_to_var_map_2_7_0_i16,
		STATIC(mercury__type_util__apply_substitutions_to_var_map_2_7_0));
Define_label(mercury__type_util__apply_substitutions_to_var_map_2_7_0_i16);
	update_prof_current_proc(LABEL(mercury__type_util__apply_substitutions_to_var_map_2_7_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = r2;
	r2 = MR_tempr1;
	r3 = MR_stackvar(3);
	GOTO_LABEL(mercury__type_util__apply_substitutions_to_var_map_2_7_0_i18);
	}
Define_label(mercury__type_util__apply_substitutions_to_var_map_2_7_0_i11);
	r3 = MR_stackvar(3);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__type_util__apply_substitutions_to_var_map_2_7_0, "term:term/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(6);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
Define_label(mercury__type_util__apply_substitutions_to_var_map_2_7_0_i18);
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__term__apply_rec_substitution_3_0),
		mercury__type_util__apply_substitutions_to_var_map_2_7_0_i19,
		STATIC(mercury__type_util__apply_substitutions_to_var_map_2_7_0));
Define_label(mercury__type_util__apply_substitutions_to_var_map_2_7_0_i19);
	update_prof_current_proc(LABEL(mercury__type_util__apply_substitutions_to_var_map_2_7_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__type_util__apply_substitutions_to_var_map_2_7_0_i20);
	r4 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_1);
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_type_info_locn_0;
	r3 = MR_stackvar(5);
	r5 = MR_stackvar(10);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__type_util__apply_substitutions_to_var_map_2_7_0_i22,
		STATIC(mercury__type_util__apply_substitutions_to_var_map_2_7_0));
Define_label(mercury__type_util__apply_substitutions_to_var_map_2_7_0_i22);
	update_prof_current_proc(LABEL(mercury__type_util__apply_substitutions_to_var_map_2_7_0));
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r6 = r1;
	r1 = MR_stackvar(7);
	MR_succip = (Code *) MR_stackvar(11);
	GOTO_LABEL(mercury__type_util__apply_substitutions_to_var_map_2_7_0_i1005);
Define_label(mercury__type_util__apply_substitutions_to_var_map_2_7_0_i20);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r1 = MR_stackvar(7);
	r6 = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(11);
	GOTO_LABEL(mercury__type_util__apply_substitutions_to_var_map_2_7_0_i1005);
Define_label(mercury__type_util__apply_substitutions_to_var_map_2_7_0_i3);
	r1 = r6;
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	proceed();
END_MODULE


BEGIN_MODULE(type_util_module73)
	init_entry(mercury__type_util__apply_substitutions_to_typeclass_var_map_2_5_0);
	init_label(mercury__type_util__apply_substitutions_to_typeclass_var_map_2_5_0_i2);
	init_label(mercury__type_util__apply_substitutions_to_typeclass_var_map_2_5_0_i3);
	init_label(mercury__type_util__apply_substitutions_to_typeclass_var_map_2_5_0_i5);
	init_label(mercury__type_util__apply_substitutions_to_typeclass_var_map_2_5_0_i1005);
BEGIN_CODE

/* code for predicate 'apply_substitutions_to_typeclass_var_map_2'/5 in mode 0 */
Define_static(mercury__type_util__apply_substitutions_to_typeclass_var_map_2_5_0);
	MR_incr_sp_push_msg(5, "type_util:apply_substitutions_to_typeclass_var_map_2/5");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(2) = r3;
	r3 = r1;
	MR_stackvar(1) = r2;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), r4, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r4, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	call_localret(ENTRY(mercury__term__apply_substitution_to_list_3_0),
		mercury__type_util__apply_substitutions_to_typeclass_var_map_2_5_0_i2,
		STATIC(mercury__type_util__apply_substitutions_to_typeclass_var_map_2_5_0));
	}
Define_label(mercury__type_util__apply_substitutions_to_typeclass_var_map_2_5_0_i2);
	update_prof_current_proc(LABEL(mercury__type_util__apply_substitutions_to_typeclass_var_map_2_5_0));
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__type_util__apply_substitutions_to_typeclass_var_map_2_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 1) = r1;
	r1 = MR_stackvar(1);
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(4);
	call_localret(STATIC(mercury__type_util__apply_rec_subst_to_constraint_3_0),
		mercury__type_util__apply_substitutions_to_typeclass_var_map_2_5_0_i3,
		STATIC(mercury__type_util__apply_substitutions_to_typeclass_var_map_2_5_0));
Define_label(mercury__type_util__apply_substitutions_to_typeclass_var_map_2_5_0_i3);
	update_prof_current_proc(LABEL(mercury__type_util__apply_substitutions_to_typeclass_var_map_2_5_0));
	MR_stackvar(1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_26);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_26);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__type_util__apply_substitutions_to_typeclass_var_map_2_5_0_i5,
		STATIC(mercury__type_util__apply_substitutions_to_typeclass_var_map_2_5_0));
Define_label(mercury__type_util__apply_substitutions_to_typeclass_var_map_2_5_0_i5);
	update_prof_current_proc(LABEL(mercury__type_util__apply_substitutions_to_typeclass_var_map_2_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__type_util__apply_substitutions_to_typeclass_var_map_2_5_0_i1005);
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__type_util__apply_substitutions_to_typeclass_var_map_2_5_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__type_util__apply_substitutions_to_typeclass_var_map_2_5_0_i1005);
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__type_util__apply_substitutions_to_typeclass_var_map_2_5_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE


BEGIN_MODULE(type_util_module74)
	init_entry(mercury____Unify___type_util__builtin_type_0_0);
	init_label(mercury____Unify___type_util__builtin_type_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___type_util__builtin_type_0_0);
	if ((r1 != r2))
		GOTO_LABEL(mercury____Unify___type_util__builtin_type_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___type_util__builtin_type_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(type_util_module75)
	init_entry(mercury____Index___type_util__builtin_type_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___type_util__builtin_type_0_0);
	proceed();
END_MODULE

Declare_entry(mercury__builtin_compare_int_3_0);

BEGIN_MODULE(type_util_module76)
	init_entry(mercury____Compare___type_util__builtin_type_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___type_util__builtin_type_0_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___type_util__builtin_type_0_0));
END_MODULE

Declare_entry(mercury____Unify___varset__varset_1_0);
Declare_entry(mercury____Unify___term__term_1_0);

BEGIN_MODULE(type_util_module77)
	init_entry(mercury____Unify___type_util__ctor_defn_0_0);
	init_label(mercury____Unify___type_util__ctor_defn_0_0_i2);
	init_label(mercury____Unify___type_util__ctor_defn_0_0_i4);
	init_label(mercury____Unify___type_util__ctor_defn_0_0_i6);
	init_label(mercury____Unify___type_util__ctor_defn_0_0_i8);
	init_label(mercury____Unify___type_util__ctor_defn_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___type_util__ctor_defn_0_0);
	MR_incr_sp_push_msg(9, "type_util:__Unify__/2");
	MR_stackvar(9) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	call_localret(ENTRY(mercury____Unify___varset__varset_1_0),
		mercury____Unify___type_util__ctor_defn_0_0_i2,
		ENTRY(mercury____Unify___type_util__ctor_defn_0_0));
Define_label(mercury____Unify___type_util__ctor_defn_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___type_util__ctor_defn_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___type_util__ctor_defn_0_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_1);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(5);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury____Unify___type_util__ctor_defn_0_0_i4,
		ENTRY(mercury____Unify___type_util__ctor_defn_0_0));
Define_label(mercury____Unify___type_util__ctor_defn_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___type_util__ctor_defn_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___type_util__ctor_defn_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_class_constraint_0;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(6);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury____Unify___type_util__ctor_defn_0_0_i6,
		ENTRY(mercury____Unify___type_util__ctor_defn_0_0));
Define_label(mercury____Unify___type_util__ctor_defn_0_0_i6);
	update_prof_current_proc(LABEL(mercury____Unify___type_util__ctor_defn_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___type_util__ctor_defn_0_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_2);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(7);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury____Unify___type_util__ctor_defn_0_0_i8,
		ENTRY(mercury____Unify___type_util__ctor_defn_0_0));
Define_label(mercury____Unify___type_util__ctor_defn_0_0_i8);
	update_prof_current_proc(LABEL(mercury____Unify___type_util__ctor_defn_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___type_util__ctor_defn_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(8);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	tailcall(ENTRY(mercury____Unify___term__term_1_0),
		ENTRY(mercury____Unify___type_util__ctor_defn_0_0));
Define_label(mercury____Unify___type_util__ctor_defn_0_0_i1);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(type_util_module78)
	init_entry(mercury____Index___type_util__ctor_defn_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___type_util__ctor_defn_0_0);
	tailcall(STATIC(mercury____Index___type_util__ctor_defn_0__ua0_2_0),
		ENTRY(mercury____Index___type_util__ctor_defn_0_0));
END_MODULE

Declare_entry(mercury____Compare___varset__varset_1_0);
Declare_entry(mercury____Compare___list__list_1_0);
Declare_entry(mercury____Compare___term__term_1_0);

BEGIN_MODULE(type_util_module79)
	init_entry(mercury____Compare___type_util__ctor_defn_0_0);
	init_label(mercury____Compare___type_util__ctor_defn_0_0_i3);
	init_label(mercury____Compare___type_util__ctor_defn_0_0_i7);
	init_label(mercury____Compare___type_util__ctor_defn_0_0_i11);
	init_label(mercury____Compare___type_util__ctor_defn_0_0_i15);
	init_label(mercury____Compare___type_util__ctor_defn_0_0_i22);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___type_util__ctor_defn_0_0);
	MR_incr_sp_push_msg(9, "type_util:__Compare__/3");
	MR_stackvar(9) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	call_localret(ENTRY(mercury____Compare___varset__varset_1_0),
		mercury____Compare___type_util__ctor_defn_0_0_i3,
		ENTRY(mercury____Compare___type_util__ctor_defn_0_0));
Define_label(mercury____Compare___type_util__ctor_defn_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___type_util__ctor_defn_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___type_util__ctor_defn_0_0_i22);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_1);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(5);
	call_localret(ENTRY(mercury____Compare___list__list_1_0),
		mercury____Compare___type_util__ctor_defn_0_0_i7,
		ENTRY(mercury____Compare___type_util__ctor_defn_0_0));
Define_label(mercury____Compare___type_util__ctor_defn_0_0_i7);
	update_prof_current_proc(LABEL(mercury____Compare___type_util__ctor_defn_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___type_util__ctor_defn_0_0_i22);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_class_constraint_0;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(6);
	call_localret(ENTRY(mercury____Compare___list__list_1_0),
		mercury____Compare___type_util__ctor_defn_0_0_i11,
		ENTRY(mercury____Compare___type_util__ctor_defn_0_0));
Define_label(mercury____Compare___type_util__ctor_defn_0_0_i11);
	update_prof_current_proc(LABEL(mercury____Compare___type_util__ctor_defn_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___type_util__ctor_defn_0_0_i22);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_type_util__common_2);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(7);
	call_localret(ENTRY(mercury____Compare___list__list_1_0),
		mercury____Compare___type_util__ctor_defn_0_0_i15,
		ENTRY(mercury____Compare___type_util__ctor_defn_0_0));
Define_label(mercury____Compare___type_util__ctor_defn_0_0_i15);
	update_prof_current_proc(LABEL(mercury____Compare___type_util__ctor_defn_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___type_util__ctor_defn_0_0_i22);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(8);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	tailcall(ENTRY(mercury____Compare___term__term_1_0),
		ENTRY(mercury____Compare___type_util__ctor_defn_0_0));
Define_label(mercury____Compare___type_util__ctor_defn_0_0_i22);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__type_util_maybe_bunch_0(void)
{
	type_util_module0();
	type_util_module1();
	type_util_module2();
	type_util_module3();
	type_util_module4();
	type_util_module5();
	type_util_module6();
	type_util_module7();
	type_util_module8();
	type_util_module9();
	type_util_module10();
	type_util_module11();
	type_util_module12();
	type_util_module13();
	type_util_module14();
	type_util_module15();
	type_util_module16();
	type_util_module17();
	type_util_module18();
	type_util_module19();
	type_util_module20();
	type_util_module21();
	type_util_module22();
	type_util_module23();
	type_util_module24();
	type_util_module25();
	type_util_module26();
	type_util_module27();
	type_util_module28();
	type_util_module29();
	type_util_module30();
	type_util_module31();
	type_util_module32();
	type_util_module33();
	type_util_module34();
	type_util_module35();
	type_util_module36();
	type_util_module37();
	type_util_module38();
	type_util_module39();
}

static void mercury__type_util_maybe_bunch_1(void)
{
	type_util_module40();
	type_util_module41();
	type_util_module42();
	type_util_module43();
	type_util_module44();
	type_util_module45();
	type_util_module46();
	type_util_module47();
	type_util_module48();
	type_util_module49();
	type_util_module50();
	type_util_module51();
	type_util_module52();
	type_util_module53();
	type_util_module54();
	type_util_module55();
	type_util_module56();
	type_util_module57();
	type_util_module58();
	type_util_module59();
	type_util_module60();
	type_util_module61();
	type_util_module62();
	type_util_module63();
	type_util_module64();
	type_util_module65();
	type_util_module66();
	type_util_module67();
	type_util_module68();
	type_util_module69();
	type_util_module70();
	type_util_module71();
	type_util_module72();
	type_util_module73();
	type_util_module74();
	type_util_module75();
	type_util_module76();
	type_util_module77();
	type_util_module78();
	type_util_module79();
}

#endif

void mercury__type_util__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__type_util__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__type_util_maybe_bunch_0();
		mercury__type_util_maybe_bunch_1();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_type_util__type_ctor_info_builtin_type_0,
			type_util__builtin_type_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_type_util__type_ctor_info_ctor_defn_0,
			type_util__ctor_defn_0_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
