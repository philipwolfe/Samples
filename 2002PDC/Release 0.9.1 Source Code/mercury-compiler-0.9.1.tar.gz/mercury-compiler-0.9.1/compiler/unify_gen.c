/*
** Automatically generated from `unify_gen.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__unify_gen__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury__unify_gen__generate_construction_2__ua0_8_0);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i4);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i10);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i5);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i14);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i16);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i18);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i19);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i21);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i22);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i23);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i24);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i25);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i26);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i27);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i28);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i29);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i36);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i39);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i41);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i43);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i42);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i48);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i46);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i49);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i50);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i51);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i52);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i53);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i54);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i55);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i56);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i57);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i58);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i59);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i31);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i1015);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i62);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i63);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i61);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i66);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i67);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i68);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i69);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i70);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i71);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i72);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i73);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i74);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i1215);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i76);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i79);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i80);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i83);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i84);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i85);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i87);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i88);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i90);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i93);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i94);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i96);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i99);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i100);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i103);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i104);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i105);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i106);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i107);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i108);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i109);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i110);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i111);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i112);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i113);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i114);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i116);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i117);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i118);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i119);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i120);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i121);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i122);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i124);
Declare_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i125);
Define_extern_entry(mercury__unify_gen__generate_unification_5_0);
Declare_label(mercury__unify_gen__generate_unification_5_0_i4);
Declare_label(mercury__unify_gen__generate_unification_5_0_i2);
Declare_label(mercury__unify_gen__generate_unification_5_0_i5);
Declare_label(mercury__unify_gen__generate_unification_5_0_i8);
Declare_label(mercury__unify_gen__generate_unification_5_0_i9);
Declare_label(mercury__unify_gen__generate_unification_5_0_i11);
Declare_label(mercury__unify_gen__generate_unification_5_0_i12);
Declare_label(mercury__unify_gen__generate_unification_5_0_i15);
Declare_label(mercury__unify_gen__generate_unification_5_0_i16);
Declare_label(mercury__unify_gen__generate_unification_5_0_i17);
Declare_label(mercury__unify_gen__generate_unification_5_0_i18);
Declare_label(mercury__unify_gen__generate_unification_5_0_i19);
Declare_label(mercury__unify_gen__generate_unification_5_0_i21);
Declare_label(mercury__unify_gen__generate_unification_5_0_i24);
Declare_label(mercury__unify_gen__generate_unification_5_0_i26);
Declare_label(mercury__unify_gen__generate_unification_5_0_i22);
Declare_label(mercury__unify_gen__generate_unification_5_0_i27);
Declare_label(mercury__unify_gen__generate_unification_5_0_i28);
Declare_label(mercury__unify_gen__generate_unification_5_0_i30);
Declare_label(mercury__unify_gen__generate_unification_5_0_i29);
Define_extern_entry(mercury__unify_gen__generate_tag_test_7_0);
Declare_label(mercury__unify_gen__generate_tag_test_7_0_i2);
Declare_label(mercury__unify_gen__generate_tag_test_7_0_i5);
Declare_label(mercury__unify_gen__generate_tag_test_7_0_i6);
Declare_label(mercury__unify_gen__generate_tag_test_7_0_i7);
Declare_label(mercury__unify_gen__generate_tag_test_7_0_i10);
Declare_label(mercury__unify_gen__generate_tag_test_7_0_i14);
Declare_label(mercury__unify_gen__generate_tag_test_7_0_i11);
Declare_label(mercury__unify_gen__generate_tag_test_7_0_i12);
Declare_label(mercury__unify_gen__generate_tag_test_7_0_i24);
Declare_label(mercury__unify_gen__generate_tag_test_7_0_i8);
Declare_label(mercury__unify_gen__generate_tag_test_7_0_i3);
Declare_label(mercury__unify_gen__generate_tag_test_7_0_i32);
Declare_label(mercury__unify_gen__generate_tag_test_7_0_i33);
Declare_label(mercury__unify_gen__generate_tag_test_7_0_i34);
Declare_label(mercury__unify_gen__generate_tag_test_7_0_i37);
Declare_label(mercury__unify_gen__generate_tag_test_7_0_i38);
Declare_label(mercury__unify_gen__generate_tag_test_7_0_i36);
Declare_label(mercury__unify_gen__generate_tag_test_7_0_i40);
Declare_label(mercury__unify_gen__generate_tag_test_7_0_i41);
Declare_label(mercury__unify_gen__generate_tag_test_7_0_i42);
Declare_label(mercury__unify_gen__generate_tag_test_7_0_i43);
Declare_label(mercury__unify_gen__generate_tag_test_7_0_i44);
Declare_label(mercury__unify_gen__generate_tag_test_7_0_i46);
Declare_label(mercury__unify_gen__generate_tag_test_7_0_i47);
Declare_static(mercury__unify_gen__generate_test_5_0);
Declare_label(mercury__unify_gen__generate_test_5_0_i2);
Declare_label(mercury__unify_gen__generate_test_5_0_i3);
Declare_label(mercury__unify_gen__generate_test_5_0_i4);
Declare_label(mercury__unify_gen__generate_test_5_0_i5);
Declare_label(mercury__unify_gen__generate_test_5_0_i1021);
Declare_label(mercury__unify_gen__generate_test_5_0_i17);
Declare_static(mercury__unify_gen__generate_tag_rval_2_3_0);
Declare_label(mercury__unify_gen__generate_tag_rval_2_3_0_i4);
Declare_label(mercury__unify_gen__generate_tag_rval_2_3_0_i5);
Declare_label(mercury__unify_gen__generate_tag_rval_2_3_0_i6);
Declare_label(mercury__unify_gen__generate_tag_rval_2_3_0_i7);
Declare_label(mercury__unify_gen__generate_tag_rval_2_3_0_i8);
Declare_label(mercury__unify_gen__generate_tag_rval_2_3_0_i9);
Declare_label(mercury__unify_gen__generate_tag_rval_2_3_0_i11);
Declare_label(mercury__unify_gen__generate_tag_rval_2_3_0_i13);
Declare_label(mercury__unify_gen__generate_tag_rval_2_3_0_i15);
Declare_label(mercury__unify_gen__generate_tag_rval_2_3_0_i17);
Declare_label(mercury__unify_gen__generate_tag_rval_2_3_0_i19);
Declare_label(mercury__unify_gen__generate_tag_rval_2_3_0_i20);
Declare_label(mercury__unify_gen__generate_tag_rval_2_3_0_i21);
Declare_static(mercury__unify_gen__generate_extra_closure_args_6_0);
Declare_label(mercury__unify_gen__generate_extra_closure_args_6_0_i4);
Declare_label(mercury__unify_gen__generate_extra_closure_args_6_0_i5);
Declare_label(mercury__unify_gen__generate_extra_closure_args_6_0_i3);
Declare_static(mercury__unify_gen__generate_pred_args_3_0);
Declare_label(mercury__unify_gen__generate_pred_args_3_0_i3);
Declare_label(mercury__unify_gen__generate_pred_args_3_0_i6);
Declare_label(mercury__unify_gen__generate_pred_args_3_0_i9);
Declare_label(mercury__unify_gen__generate_pred_args_3_0_i5);
Declare_static(mercury__unify_gen__generate_cons_args_5_0);
Declare_label(mercury__unify_gen__generate_cons_args_5_0_i4);
Declare_label(mercury__unify_gen__generate_cons_args_5_0_i3);
Declare_static(mercury__unify_gen__generate_cons_args_2_5_0);
Declare_label(mercury__unify_gen__generate_cons_args_2_5_0_i3);
Declare_label(mercury__unify_gen__generate_cons_args_2_5_0_i9);
Declare_label(mercury__unify_gen__generate_cons_args_2_5_0_i8);
Declare_label(mercury__unify_gen__generate_cons_args_2_5_0_i11);
Declare_label(mercury__unify_gen__generate_cons_args_2_5_0_i1013);
Declare_label(mercury__unify_gen__generate_cons_args_2_5_0_i1);
Declare_static(mercury__unify_gen__var_types_4_0);
Declare_label(mercury__unify_gen__var_types_4_0_i2);
Declare_label(mercury__unify_gen__var_types_4_0_i3);
Declare_label(mercury__unify_gen__var_types_4_0_i4);
Declare_static(mercury__unify_gen__make_fields_and_argvars_6_0);
Declare_label(mercury__unify_gen__make_fields_and_argvars_6_0_i4);
Declare_label(mercury__unify_gen__make_fields_and_argvars_6_0_i5);
Declare_label(mercury__unify_gen__make_fields_and_argvars_6_0_i2);
Declare_static(mercury__unify_gen__generate_det_deconstruction_7_0);
Declare_label(mercury__unify_gen__generate_det_deconstruction_7_0_i2);
Declare_label(mercury__unify_gen__generate_det_deconstruction_7_0_i5);
Declare_label(mercury__unify_gen__generate_det_deconstruction_7_0_i11);
Declare_label(mercury__unify_gen__generate_det_deconstruction_7_0_i6);
Declare_label(mercury__unify_gen__generate_det_deconstruction_7_0_i17);
Declare_label(mercury__unify_gen__generate_det_deconstruction_7_0_i24);
Declare_label(mercury__unify_gen__generate_det_deconstruction_7_0_i25);
Declare_label(mercury__unify_gen__generate_det_deconstruction_7_0_i26);
Declare_label(mercury__unify_gen__generate_det_deconstruction_7_0_i27);
Declare_label(mercury__unify_gen__generate_det_deconstruction_7_0_i28);
Declare_label(mercury__unify_gen__generate_det_deconstruction_7_0_i30);
Declare_label(mercury__unify_gen__generate_det_deconstruction_7_0_i31);
Declare_label(mercury__unify_gen__generate_det_deconstruction_7_0_i32);
Declare_label(mercury__unify_gen__generate_det_deconstruction_7_0_i33);
Declare_label(mercury__unify_gen__generate_det_deconstruction_7_0_i34);
Declare_label(mercury__unify_gen__generate_det_deconstruction_7_0_i37);
Declare_label(mercury__unify_gen__generate_det_deconstruction_7_0_i36);
Declare_label(mercury__unify_gen__generate_det_deconstruction_7_0_i41);
Declare_static(mercury__unify_gen__generate_unify_args_7_0);
Declare_label(mercury__unify_gen__generate_unify_args_7_0_i4);
Declare_label(mercury__unify_gen__generate_unify_args_7_0_i3);
Declare_static(mercury__unify_gen__generate_unify_args_2_7_0);
Declare_label(mercury__unify_gen__generate_unify_args_2_7_0_i3);
Declare_label(mercury__unify_gen__generate_unify_args_2_7_0_i10);
Declare_label(mercury__unify_gen__generate_unify_args_2_7_0_i11);
Declare_label(mercury__unify_gen__generate_unify_args_2_7_0_i1012);
Declare_label(mercury__unify_gen__generate_unify_args_2_7_0_i1);
Declare_static(mercury__unify_gen__generate_sub_unify_7_0);
Declare_label(mercury__unify_gen__generate_sub_unify_7_0_i2);
Declare_label(mercury__unify_gen__generate_sub_unify_7_0_i3);
Declare_label(mercury__unify_gen__generate_sub_unify_7_0_i4);
Declare_label(mercury__unify_gen__generate_sub_unify_7_0_i5);
Declare_label(mercury__unify_gen__generate_sub_unify_7_0_i18);
Declare_label(mercury__unify_gen__generate_sub_unify_7_0_i20);
Declare_label(mercury__unify_gen__generate_sub_unify_7_0_i17);
Declare_label(mercury__unify_gen__generate_sub_unify_7_0_i21);
Declare_label(mercury__unify_gen__generate_sub_unify_7_0_i15);
Declare_label(mercury__unify_gen__generate_sub_unify_7_0_i24);
Declare_label(mercury__unify_gen__generate_sub_unify_7_0_i26);
Declare_label(mercury__unify_gen__generate_sub_unify_7_0_i23);
Declare_label(mercury__unify_gen__generate_sub_unify_7_0_i27);
Declare_label(mercury__unify_gen__generate_sub_unify_7_0_i13);
Declare_label(mercury__unify_gen__generate_sub_unify_7_0_i30);
Declare_label(mercury__unify_gen__generate_sub_unify_7_0_i31);
Declare_label(mercury__unify_gen__generate_sub_unify_7_0_i32);
Declare_label(mercury__unify_gen__generate_sub_unify_7_0_i29);
Declare_label(mercury__unify_gen__generate_sub_unify_7_0_i36);
Declare_label(mercury__unify_gen__generate_sub_unify_7_0_i37);
Declare_label(mercury__unify_gen__generate_sub_unify_7_0_i9);
Declare_label(mercury__unify_gen__generate_sub_unify_7_0_i41);
Declare_label(mercury__unify_gen__generate_sub_unify_7_0_i45);
Declare_label(mercury__unify_gen__generate_sub_unify_7_0_i48);
Declare_static(mercury__unify_gen__generate_sub_assign_5_0);
Declare_label(mercury__unify_gen__generate_sub_assign_5_0_i8);
Declare_label(mercury__unify_gen__generate_sub_assign_5_0_i10);
Declare_label(mercury__unify_gen__generate_sub_assign_5_0_i6);
Declare_label(mercury__unify_gen__generate_sub_assign_5_0_i11);
Declare_label(mercury__unify_gen__generate_sub_assign_5_0_i5);
Declare_label(mercury__unify_gen__generate_sub_assign_5_0_i14);
Declare_label(mercury__unify_gen__generate_sub_assign_5_0_i16);
Declare_label(mercury__unify_gen__generate_sub_assign_5_0_i12);
Declare_label(mercury__unify_gen__generate_sub_assign_5_0_i17);
Declare_label(mercury__unify_gen__generate_sub_assign_5_0_i3);
Declare_label(mercury__unify_gen__generate_sub_assign_5_0_i20);
Declare_label(mercury__unify_gen__generate_sub_assign_5_0_i21);
Declare_label(mercury__unify_gen__generate_sub_assign_5_0_i22);
Declare_label(mercury__unify_gen__generate_sub_assign_5_0_i19);
Declare_label(mercury__unify_gen__generate_sub_assign_5_0_i26);
Declare_label(mercury__unify_gen__generate_sub_assign_5_0_i27);
Declare_label(mercury__unify_gen__generate_sub_assign_5_0_i29);
Declare_static(mercury__unify_gen__var_type_msg_2_0);
Declare_label(mercury__unify_gen__var_type_msg_2_0_i4);
Declare_label(mercury__unify_gen__var_type_msg_2_0_i6);
Declare_label(mercury__unify_gen__var_type_msg_2_0_i7);
Declare_label(mercury__unify_gen__var_type_msg_2_0_i3);
Define_extern_entry(mercury____Unify___unify_gen__test_sense_0_0);
Declare_label(mercury____Unify___unify_gen__test_sense_0_0_i1);
Define_extern_entry(mercury____Index___unify_gen__test_sense_0_0);
Define_extern_entry(mercury____Compare___unify_gen__test_sense_0_0);
Declare_static(mercury____Unify___unify_gen__uni_val_0_0);
Declare_label(mercury____Unify___unify_gen__uni_val_0_0_i3);
Declare_label(mercury____Unify___unify_gen__uni_val_0_0_i1);
Declare_static(mercury____Index___unify_gen__uni_val_0_0);
Declare_label(mercury____Index___unify_gen__uni_val_0_0_i3);
Declare_static(mercury____Compare___unify_gen__uni_val_0_0);
Declare_label(mercury____Compare___unify_gen__uni_val_0_0_i3);
Declare_label(mercury____Compare___unify_gen__uni_val_0_0_i2);
Declare_label(mercury____Compare___unify_gen__uni_val_0_0_i5);
Declare_label(mercury____Compare___unify_gen__uni_val_0_0_i4);
Declare_label(mercury____Compare___unify_gen__uni_val_0_0_i6);
Declare_label(mercury____Compare___unify_gen__uni_val_0_0_i7);
Declare_label(mercury____Compare___unify_gen__uni_val_0_0_i11);
Declare_label(mercury____Compare___unify_gen__uni_val_0_0_i1014);

const struct MR_TypeCtorInfo_struct mercury_data_unify_gen__type_ctor_info_test_sense_0;

const struct MR_TypeCtorInfo_struct mercury_data_unify_gen__type_ctor_info_uni_val_0;

static const struct mercury_data_unify_gen__common_0_struct {
	Word * f1;
	Word * f2;
}  mercury_data_unify_gen__common_0;

static const struct mercury_data_unify_gen__common_1_struct {
	Integer f1;
}  mercury_data_unify_gen__common_1;

static const struct mercury_data_unify_gen__common_2_struct {
	Integer f1;
	Word * f2;
}  mercury_data_unify_gen__common_2;

static const struct mercury_data_unify_gen__common_3_struct {
	Integer f1;
}  mercury_data_unify_gen__common_3;

static const struct mercury_data_unify_gen__common_4_struct {
	Integer f1;
	Word * f2;
}  mercury_data_unify_gen__common_4;

static const struct mercury_data_unify_gen__common_5_struct {
	Integer f1;
}  mercury_data_unify_gen__common_5;

static const struct mercury_data_unify_gen__common_6_struct {
	Integer f1;
	Word * f2;
}  mercury_data_unify_gen__common_6;

static const struct mercury_data_unify_gen__common_7_struct {
	Integer f1;
}  mercury_data_unify_gen__common_7;

static const struct mercury_data_unify_gen__common_8_struct {
	Integer f1;
	Word * f2;
}  mercury_data_unify_gen__common_8;

static const struct mercury_data_unify_gen__common_9_struct {
	String f1;
}  mercury_data_unify_gen__common_9;

static const struct mercury_data_unify_gen__common_10_struct {
	Word * f1;
	String f2;
}  mercury_data_unify_gen__common_10;

static const struct mercury_data_unify_gen__common_11_struct {
	Word * f1;
}  mercury_data_unify_gen__common_11;

static const struct mercury_data_unify_gen__common_12_struct {
	String f1;
	Word * f2;
}  mercury_data_unify_gen__common_12;

static const struct mercury_data_unify_gen__common_13_struct {
	Integer f1;
	Word * f2;
}  mercury_data_unify_gen__common_13;

static const struct mercury_data_unify_gen__common_14_struct {
	Word * f1;
	Word * f2;
}  mercury_data_unify_gen__common_14;

static const struct mercury_data_unify_gen__common_15_struct {
	Word * f1;
}  mercury_data_unify_gen__common_15;

static const struct mercury_data_unify_gen__common_16_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_unify_gen__common_16;

static const struct mercury_data_unify_gen__common_17_struct {
	Integer f1;
	Word * f2;
	String f3;
	Word * f4;
	Integer f5;
	Integer f6;
}  mercury_data_unify_gen__common_17;

static const struct mercury_data_unify_gen__common_18_struct {
	Integer f1;
	Integer f2;
	String f3;
	String f4;
}  mercury_data_unify_gen__common_18;

static const struct mercury_data_unify_gen__type_ctor_functors_uni_val_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
	Word * f4;
}  mercury_data_unify_gen__type_ctor_functors_uni_val_0;

static const struct mercury_data_unify_gen__type_ctor_layout_uni_val_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_unify_gen__type_ctor_layout_uni_val_0;

static const struct mercury_data_unify_gen__type_ctor_functors_test_sense_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_unify_gen__type_ctor_functors_test_sense_0;

static const struct mercury_data_unify_gen__type_ctor_layout_test_sense_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_unify_gen__type_ctor_layout_test_sense_0;

const struct MR_TypeCtorInfo_struct mercury_data_unify_gen__type_ctor_info_test_sense_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___unify_gen__test_sense_0_0),
	ENTRY(mercury____Index___unify_gen__test_sense_0_0),
	ENTRY(mercury____Compare___unify_gen__test_sense_0_0),
	(Integer) 0,
	(Word *) &mercury_data_unify_gen__type_ctor_functors_test_sense_0,
	(Word *) &mercury_data_unify_gen__type_ctor_layout_test_sense_0,
	MR_string_const("unify_gen", 9),
	MR_string_const("test_sense", 10),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_unify_gen__type_ctor_info_uni_val_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___unify_gen__uni_val_0_0),
	STATIC(mercury____Index___unify_gen__uni_val_0_0),
	STATIC(mercury____Compare___unify_gen__uni_val_0_0),
	(Integer) 2,
	(Word *) &mercury_data_unify_gen__type_ctor_functors_uni_val_0,
	(Word *) &mercury_data_unify_gen__type_ctor_layout_uni_val_0,
	MR_string_const("unify_gen", 9),
	MR_string_const("uni_val", 7),
	(Integer) 3
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_var_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_prog_var_type_0;
static const struct mercury_data_unify_gen__common_0_struct mercury_data_unify_gen__common_0 = {
	(Word *) &mercury_data_term__type_ctor_info_var_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0
};

static const struct mercury_data_unify_gen__common_1_struct mercury_data_unify_gen__common_1 = {
	(Integer) 0
};

static const struct mercury_data_unify_gen__common_2_struct mercury_data_unify_gen__common_2 = {
	(Integer) 1,
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_unify_gen__common_1)
};

static const struct mercury_data_unify_gen__common_3_struct mercury_data_unify_gen__common_3 = {
	(Integer) 1
};

static const struct mercury_data_unify_gen__common_4_struct mercury_data_unify_gen__common_4 = {
	(Integer) 1,
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_unify_gen__common_3)
};

static const struct mercury_data_unify_gen__common_5_struct mercury_data_unify_gen__common_5 = {
	(Integer) 2
};

static const struct mercury_data_unify_gen__common_6_struct mercury_data_unify_gen__common_6 = {
	(Integer) 1,
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_unify_gen__common_5)
};

static const struct mercury_data_unify_gen__common_7_struct mercury_data_unify_gen__common_7 = {
	(Integer) 3
};

static const struct mercury_data_unify_gen__common_8_struct mercury_data_unify_gen__common_8 = {
	(Integer) 1,
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_unify_gen__common_7)
};

static const struct mercury_data_unify_gen__common_9_struct mercury_data_unify_gen__common_9 = {
	MR_string_const("build new closure from old closure", 34)
};

static const struct mercury_data_unify_gen__common_10_struct mercury_data_unify_gen__common_10 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_unify_gen__common_9),
	MR_string_const("", 0)
};

static const struct mercury_data_unify_gen__common_11_struct mercury_data_unify_gen__common_11 = {
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_unify_gen__common_12_struct mercury_data_unify_gen__common_12 = {
	MR_string_const(" (inverted test)", 16),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_unify_gen__common_13_struct mercury_data_unify_gen__common_13 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_term_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_tvar_type_0;
static const struct mercury_data_unify_gen__common_14_struct mercury_data_unify_gen__common_14 = {
	(Word *) &mercury_data_term__type_ctor_info_term_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_llds__type_ctor_info_lval_0;
static const struct mercury_data_unify_gen__common_15_struct mercury_data_unify_gen__common_15 = {
	(Word *) &mercury_data_llds__type_ctor_info_lval_0
};

static const struct mercury_data_unify_gen__common_16_struct mercury_data_unify_gen__common_16 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_gen__common_15),
	MR_string_const("lval", 4),
	MR_mkword(MR_mktag(1), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_unify_gen__common_17_struct mercury_data_unify_gen__common_17 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_gen__common_0),
	MR_string_const("ref", 3),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_unify_gen__common_18_struct mercury_data_unify_gen__common_18 = {
	(Integer) 1,
	(Integer) 2,
	MR_string_const("branch_on_success", 17),
	MR_string_const("branch_on_failure", 17)
};

static const struct mercury_data_unify_gen__type_ctor_functors_uni_val_0_struct mercury_data_unify_gen__type_ctor_functors_uni_val_0 = {
	(Integer) 0,
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_gen__common_16),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_gen__common_17)
};

static const struct mercury_data_unify_gen__type_ctor_layout_uni_val_0_struct mercury_data_unify_gen__type_ctor_layout_uni_val_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_unify_gen__common_17),
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_unify_gen__common_16),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_unify_gen__type_ctor_functors_test_sense_0_struct mercury_data_unify_gen__type_ctor_functors_test_sense_0 = {
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_gen__common_18)
};

static const struct mercury_data_unify_gen__type_ctor_layout_test_sense_0_struct mercury_data_unify_gen__type_ctor_layout_test_sense_0 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_gen__common_18),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_gen__common_18),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_gen__common_18),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_gen__common_18)
};

Declare_entry(mercury__code_info__variable_type_4_0);
Declare_entry(mercury__require__error_1_0);
Declare_entry(mercury__code_info__cache_expression_4_0);
Declare_entry(mercury__code_info__get_module_info_3_0);
Declare_entry(mercury__hlds_module__module_info_preds_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_id_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_info_0;
Declare_entry(mercury__map__lookup_3_0);
Declare_entry(mercury__hlds_pred__pred_info_procedures_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_proc_id_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_proc_info_0;
Declare_entry(mercury__hlds_pred__proc_info_goal_2_0);
Declare_entry(mercury__hlds_pred__proc_info_interface_code_model_2_0);
Declare_entry(mercury__hlds_pred__proc_info_headvars_2_0);
Declare_entry(mercury____Unify___list__list_1_0);
Declare_entry(mercury____Unify___term__var_1_0);
Declare_entry(mercury__hlds_data__determinism_to_code_model_2_0);
Declare_entry(mercury__code_info__produce_variable_5_0);
Declare_entry(mercury__code_info__get_next_label_3_0);
Declare_entry(mercury__code_info__acquire_reg_4_0);
Declare_entry(mercury__list__length_2_0);
Declare_entry(mercury__code_info__release_reg_3_0);
Declare_entry(mercury__continuation_info__generate_closure_layout_4_0);
Declare_entry(mercury__code_info__make_entry_label_7_0);
Declare_entry(mercury__code_util__extract_proc_label_from_code_addr_2_0);
Declare_entry(mercury__code_info__get_cell_count_3_0);
Declare_entry(mercury__stack_layout__construct_closure_layout_6_0);
Declare_entry(mercury__code_info__set_cell_count_3_0);
Declare_entry(mercury__code_info__get_next_cell_number_3_0);
Declare_entry(mercury__hlds_pred__proc_info_arg_info_2_0);
Declare_entry(mercury__code_util__make_proc_label_4_0);
Declare_entry(mercury__hlds_module__module_info_name_2_0);

BEGIN_MODULE(unify_gen_module0)
	init_entry(mercury__unify_gen__generate_construction_2__ua0_8_0);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i4);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i10);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i5);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i14);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i16);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i18);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i19);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i21);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i22);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i23);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i24);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i25);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i26);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i27);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i28);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i29);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i36);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i39);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i41);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i43);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i42);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i48);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i46);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i49);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i50);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i51);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i52);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i53);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i54);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i55);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i56);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i57);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i58);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i59);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i31);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i1015);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i62);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i63);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i61);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i66);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i67);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i68);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i69);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i70);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i71);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i72);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i73);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i74);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i1215);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i76);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i79);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i80);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i83);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i84);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i85);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i87);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i88);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i90);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i93);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i94);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i96);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i99);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i100);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i103);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i104);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i105);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i106);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i107);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i108);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i109);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i110);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i111);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i112);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i113);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i114);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i116);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i117);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i118);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i119);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i120);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i121);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i122);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i124);
	init_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i125);
BEGIN_CODE

/* code for predicate 'generate_construction_2__ua0'/8 in mode 0 */
Define_static(mercury__unify_gen__generate_construction_2__ua0_8_0);
	MR_incr_sp_push_msg(21, "unify_gen:generate_construction_2__ua0/8");
	MR_stackvar(21) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0_i4) AND
		LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0_i14) AND
		LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0_i16) AND
		LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0_i18));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i4);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0_i5);
	if (((Integer) MR_const_field(MR_mktag(1), r3, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0_i5);
	if (((Integer) r4 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0_i5);
	if (((Integer) MR_const_field(MR_mktag(1), r4, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0_i5);
	MR_stackvar(1) = r2;
	r1 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_stackvar(2) = r1;
	r2 = r5;
	call_localret(ENTRY(mercury__code_info__variable_type_4_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i10,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i10);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	r3 = r1;
	r5 = r2;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 1, mercury__unify_gen__generate_construction_2__ua0_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 1, mercury__unify_gen__generate_construction_2__ua0_8_0, "origin_lost_in_value_number");
	r4 = r3;
	r3 = MR_stackvar(3);
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(21);
	MR_decr_sp_pop_msg(21);
	tailcall(STATIC(mercury__unify_gen__generate_sub_unify_7_0),
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i5);
	r1 = (Word) MR_string_const("unify_gen__generate_construction_2: no_tag: arity != 1", 54);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i107,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i14);
	r3 = r1;
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "llds:rval/0");
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 1;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r2, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	r3 = r5;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 0;
	call_localret(ENTRY(mercury__code_info__cache_expression_4_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i125,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
	}
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i16);
	r3 = r1;
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "llds:rval/0");
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 1;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__unify_gen__generate_construction_2__ua0_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r2, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(2), r3, (Integer) 0);
	r3 = r5;
	call_localret(ENTRY(mercury__code_info__cache_expression_4_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i125,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
	}
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i18);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0_i19) AND
		LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0_i21) AND
		LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0_i79) AND
		LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0_i87) AND
		LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0_i93) AND
		LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0_i99) AND
		LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0_i108) AND
		LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0_i116) AND
		LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0_i124));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i19);
	r3 = r1;
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "llds:rval/0");
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 1;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__unify_gen__generate_construction_2__ua0_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r2, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(3), r3, (Integer) 1);
	r3 = r5;
	call_localret(ENTRY(mercury__code_info__cache_expression_4_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i125,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
	}
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i21);
	MR_stackvar(4) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(6) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	r1 = r5;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__code_info__get_module_info_3_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i22,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i22);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	MR_stackvar(7) = r1;
	MR_stackvar(20) = r2;
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i23,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i23);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	r4 = MR_stackvar(4);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i24,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i24);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procedures_2_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i25,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i25);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0;
	r4 = MR_stackvar(5);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i26,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i26);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	MR_stackvar(8) = r1;
	call_localret(ENTRY(mercury__hlds_pred__proc_info_goal_2_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i27,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i27);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(8);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_interface_code_model_2_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i28,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i28);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	MR_stackvar(9) = r1;
	r1 = MR_stackvar(8);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_headvars_2_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i29,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i29);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	if (((Integer) MR_stackvar(6) != (Integer) 0))
		GOTO_LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0_i31);
	{
	Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_stackvar(2);
	if (((Integer) MR_tempr1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0_i31);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0_i31);
	MR_tempr2 = MR_const_field(MR_mktag(0), MR_stackvar(3), (Integer) 0);
	if ((MR_tag(MR_tempr2) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0_i31);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(11) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(12) = MR_const_field(MR_mktag(2), MR_tempr2, (Integer) 3);
	r3 = MR_const_field(MR_mktag(2), MR_tempr2, (Integer) 1);
	MR_stackvar(13) = MR_const_field(MR_mktag(2), MR_tempr2, (Integer) 0);
	MR_stackvar(10) = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_gen__common_0);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i36,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
	}
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i36);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	if (!(r1))
		GOTO_LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0_i31);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(13);
	if ((MR_tag(MR_tempr1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0_i31);
	r3 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	r2 = MR_stackvar(11);
	call_localret(ENTRY(mercury____Unify___term__var_1_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i39,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
	}
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i39);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	if (!(r1))
		GOTO_LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0_i31);
	r1 = MR_stackvar(12);
	call_localret(ENTRY(mercury__hlds_data__determinism_to_code_model_2_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i41,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i41);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	if ((MR_stackvar(9) != r1))
		GOTO_LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0_i43);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(20);
	GOTO_LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0_i42);
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i43);
	if (((Integer) MR_stackvar(9) != (Integer) 2))
		GOTO_LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0_i31);
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0_i31);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(20);
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i42);
	if (((Integer) MR_stackvar(10) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0_i46);
	call_localret(ENTRY(mercury__code_info__produce_variable_5_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i48,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i48);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__code_info__cache_expression_4_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i107,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i46);
	MR_stackvar(3) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_next_label_3_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i49,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i49);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	MR_stackvar(9) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_next_label_3_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i50,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i50);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	MR_stackvar(11) = r1;
	r1 = (Integer) 0;
	call_localret(ENTRY(mercury__code_info__acquire_reg_4_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i51,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i51);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	MR_stackvar(12) = r1;
	r1 = (Integer) 0;
	call_localret(ENTRY(mercury__code_info__acquire_reg_4_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i52,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i52);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	MR_stackvar(13) = r1;
	r1 = (Integer) 0;
	call_localret(ENTRY(mercury__code_info__acquire_reg_4_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i53,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i53);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	MR_stackvar(14) = r1;
	MR_stackvar(19) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_gen__common_0);
	r2 = MR_stackvar(10);
	MR_stackvar(15) = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_unify_gen__common_2);
	MR_stackvar(16) = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_unify_gen__common_4);
	MR_stackvar(17) = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_unify_gen__common_6);
	MR_stackvar(18) = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_unify_gen__common_8);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i54,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i54);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	r2 = MR_stackvar(3);
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 1;
	MR_stackvar(3) = r3;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__unify_gen__generate_construction_2__ua0_8_0, "llds:rval_const/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_field(MR_mktag(3), MR_stackvar(3), (Integer) 1) = r3;
	r3 = MR_stackvar(19);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_stackvar(19) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__unify_gen__generate_construction_2__ua0_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = ((Integer) r1 + (Integer) 3);
	r1 = r2;
	MR_field(MR_mktag(3), MR_stackvar(19), (Integer) 1) = MR_tempr1;
	r2 = r3;
	call_localret(ENTRY(mercury__code_info__produce_variable_5_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i55,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
	}
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i55);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(9);
	r6 = MR_stackvar(10);
	tag_incr_hp_msg(r7, MR_mktag(0), (Integer) 1, mercury__unify_gen__generate_construction_2__ua0_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r7, (Integer) 0) = MR_stackvar(14);
	MR_stackvar(3) = r7;
	MR_stackvar(9) = r1;
	tag_incr_hp_msg(MR_stackvar(10), MR_mktag(1), (Integer) 1, mercury__unify_gen__generate_construction_2__ua0_8_0, "tree:tree/1");
	tag_incr_hp_msg(r11, MR_mktag(1), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "list:list/1");
	MR_field(MR_mktag(1), r11, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_gen__common_10);
	tag_incr_hp_msg(r12, MR_mktag(1), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "list:list/1");
	tag_incr_hp_msg(r13, MR_mktag(0), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "std_util:pair/2");
	tag_incr_hp_msg(r14, MR_mktag(3), (Integer) 3, mercury__unify_gen__generate_construction_2__ua0_8_0, "llds:instr/0");
	MR_field(MR_mktag(3), r14, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r14, (Integer) 1) = MR_stackvar(13);
	tag_incr_hp_msg(r15, MR_mktag(0), (Integer) 1, mercury__unify_gen__generate_construction_2__ua0_8_0, "llds:rval/0");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 4, mercury__unify_gen__generate_construction_2__ua0_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 3) = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_unify_gen__common_6);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = r2;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_unify_gen__common_1);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 7;
	MR_field(MR_mktag(0), r13, (Integer) 1) = (Word) MR_string_const("get number of arguments", 23);
	MR_field(MR_mktag(3), r14, (Integer) 2) = r15;
	MR_field(MR_mktag(1), r12, (Integer) 0) = r13;
	MR_field(MR_mktag(0), r13, (Integer) 0) = r14;
	MR_field(MR_mktag(0), r15, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r13, MR_mktag(1), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "list:list/1");
	tag_incr_hp_msg(r14, MR_mktag(0), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "std_util:pair/2");
	tag_incr_hp_msg(r15, MR_mktag(3), (Integer) 5, mercury__unify_gen__generate_construction_2__ua0_8_0, "llds:instr/0");
	MR_field(MR_mktag(3), r15, (Integer) 0) = (Integer) 9;
	MR_field(MR_mktag(3), r15, (Integer) 1) = MR_stackvar(14);
	MR_field(MR_mktag(3), r15, (Integer) 2) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r16, MR_mktag(3), (Integer) 4, mercury__unify_gen__generate_construction_2__ua0_8_0, "llds:rval/0");
	MR_field(MR_mktag(3), r16, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r16, (Integer) 1) = (Integer) 0;
	MR_field(MR_mktag(3), r15, (Integer) 4) = (Word) MR_string_const("closure", 7);
	MR_field(MR_mktag(3), r16, (Integer) 3) = MR_stackvar(19);
	MR_field(MR_mktag(0), r14, (Integer) 1) = (Word) MR_string_const("allocate new closure", 20);
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 1, mercury__unify_gen__generate_construction_2__ua0_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(13);
	MR_field(MR_mktag(3), r15, (Integer) 3) = r16;
	MR_field(MR_mktag(3), r16, (Integer) 2) = MR_tempr1;
	MR_field(MR_mktag(1), r13, (Integer) 0) = r14;
	MR_field(MR_mktag(0), r14, (Integer) 0) = r15;
	tag_incr_hp_msg(r14, MR_mktag(1), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "list:list/1");
	tag_incr_hp_msg(r15, MR_mktag(0), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "std_util:pair/2");
	tag_incr_hp_msg(r16, MR_mktag(3), (Integer) 3, mercury__unify_gen__generate_construction_2__ua0_8_0, "llds:instr/0");
	MR_field(MR_mktag(3), r16, (Integer) 0) = (Integer) 1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 4, mercury__unify_gen__generate_construction_2__ua0_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 3) = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_unify_gen__common_2);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = r7;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_unify_gen__common_1);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 7;
	MR_field(MR_mktag(3), r16, (Integer) 1) = MR_tempr1;
	tag_incr_hp_msg(r17, MR_mktag(0), (Integer) 1, mercury__unify_gen__generate_construction_2__ua0_8_0, "llds:rval/0");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 4, mercury__unify_gen__generate_construction_2__ua0_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 3) = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_unify_gen__common_2);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = r2;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_unify_gen__common_1);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 7;
	MR_field(MR_mktag(0), r15, (Integer) 1) = (Word) MR_string_const("set closure layout structure", 28);
	MR_field(MR_mktag(3), r16, (Integer) 2) = r17;
	MR_field(MR_mktag(1), r14, (Integer) 0) = r15;
	MR_field(MR_mktag(0), r15, (Integer) 0) = r16;
	MR_field(MR_mktag(0), r17, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r15, MR_mktag(1), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "list:list/1");
	tag_incr_hp_msg(r16, MR_mktag(0), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "std_util:pair/2");
	tag_incr_hp_msg(r17, MR_mktag(3), (Integer) 3, mercury__unify_gen__generate_construction_2__ua0_8_0, "llds:instr/0");
	MR_field(MR_mktag(3), r17, (Integer) 0) = (Integer) 1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 4, mercury__unify_gen__generate_construction_2__ua0_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 3) = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_unify_gen__common_4);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = r7;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_unify_gen__common_1);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 7;
	MR_field(MR_mktag(3), r17, (Integer) 1) = MR_tempr1;
	tag_incr_hp_msg(r18, MR_mktag(0), (Integer) 1, mercury__unify_gen__generate_construction_2__ua0_8_0, "llds:rval/0");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 4, mercury__unify_gen__generate_construction_2__ua0_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 3) = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_unify_gen__common_4);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = r2;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_unify_gen__common_1);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 7;
	MR_field(MR_mktag(0), r16, (Integer) 1) = (Word) MR_string_const("set closure code pointer", 24);
	MR_field(MR_mktag(3), r17, (Integer) 2) = r18;
	MR_field(MR_mktag(1), r15, (Integer) 0) = r16;
	MR_field(MR_mktag(0), r16, (Integer) 0) = r17;
	MR_field(MR_mktag(0), r18, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r16, MR_mktag(1), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "list:list/1");
	tag_incr_hp_msg(r17, MR_mktag(0), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "std_util:pair/2");
	tag_incr_hp_msg(r18, MR_mktag(3), (Integer) 3, mercury__unify_gen__generate_construction_2__ua0_8_0, "llds:instr/0");
	MR_field(MR_mktag(3), r18, (Integer) 0) = (Integer) 1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 4, mercury__unify_gen__generate_construction_2__ua0_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 3) = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_unify_gen__common_6);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = r7;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_unify_gen__common_1);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 7;
	MR_field(MR_mktag(3), r18, (Integer) 1) = MR_tempr1;
	tag_incr_hp_msg(r19, MR_mktag(3), (Integer) 4, mercury__unify_gen__generate_construction_2__ua0_8_0, "llds:rval/0");
	MR_field(MR_mktag(3), r19, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r19, (Integer) 1) = (Integer) 0;
	MR_field(MR_mktag(3), r19, (Integer) 3) = r4;
	MR_field(MR_mktag(0), r17, (Integer) 1) = (Word) MR_string_const("set new number of arguments", 27);
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 1, mercury__unify_gen__generate_construction_2__ua0_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(13);
	MR_field(MR_mktag(3), r18, (Integer) 2) = r19;
	MR_field(MR_mktag(3), r19, (Integer) 2) = MR_tempr1;
	MR_field(MR_mktag(1), r16, (Integer) 0) = r17;
	MR_field(MR_mktag(0), r17, (Integer) 0) = r18;
	tag_incr_hp_msg(r17, MR_mktag(1), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "list:list/1");
	tag_incr_hp_msg(r18, MR_mktag(0), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "std_util:pair/2");
	tag_incr_hp_msg(r19, MR_mktag(3), (Integer) 3, mercury__unify_gen__generate_construction_2__ua0_8_0, "llds:instr/0");
	MR_field(MR_mktag(3), r19, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r19, (Integer) 1) = MR_stackvar(13);
	tag_incr_hp_msg(r20, MR_mktag(3), (Integer) 4, mercury__unify_gen__generate_construction_2__ua0_8_0, "llds:rval/0");
	MR_field(MR_mktag(3), r20, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r20, (Integer) 1) = (Integer) 0;
	MR_field(MR_mktag(3), r20, (Integer) 3) = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_unify_gen__common_8);
	MR_field(MR_mktag(0), r18, (Integer) 1) = (Word) MR_string_const("set up loop limit", 17);
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 1, mercury__unify_gen__generate_construction_2__ua0_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(13);
	MR_field(MR_mktag(3), r19, (Integer) 2) = r20;
	MR_field(MR_mktag(3), r20, (Integer) 2) = MR_tempr1;
	MR_field(MR_mktag(1), r17, (Integer) 0) = r18;
	MR_field(MR_mktag(0), r18, (Integer) 0) = r19;
	tag_incr_hp_msg(r18, MR_mktag(1), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "list:list/1");
	tag_incr_hp_msg(r19, MR_mktag(0), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "std_util:pair/2");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 3, mercury__unify_gen__generate_construction_2__ua0_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_unify_gen__common_8);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(12);
	MR_field(MR_mktag(0), r19, (Integer) 1) = (Word) MR_string_const("initialize loop counter", 23);
	MR_field(MR_mktag(1), r18, (Integer) 0) = r19;
	MR_field(MR_mktag(0), r19, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r19, MR_mktag(1), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "list:list/1");
	tag_incr_hp_msg(r20, MR_mktag(0), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "std_util:pair/2");
	tag_incr_hp_msg(r21, MR_mktag(3), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "llds:instr/0");
	MR_field(MR_mktag(3), r21, (Integer) 0) = (Integer) 5;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__unify_gen__generate_construction_2__ua0_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(11);
	MR_field(MR_mktag(0), r20, (Integer) 1) = (Word) MR_string_const("enter the copy loop at the conceptual top", 41);
	MR_field(MR_mktag(3), r21, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r19, (Integer) 0) = r20;
	MR_field(MR_mktag(0), r20, (Integer) 0) = r21;
	tag_incr_hp_msg(r20, MR_mktag(1), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "list:list/1");
	tag_incr_hp_msg(r21, MR_mktag(0), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "std_util:pair/2");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r5;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(0), r21, (Integer) 1) = (Word) MR_string_const("start of loop", 13);
	MR_field(MR_mktag(1), r20, (Integer) 0) = r21;
	MR_field(MR_mktag(0), r21, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r21, MR_mktag(1), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "list:list/1");
	tag_incr_hp_msg(r22, MR_mktag(0), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "std_util:pair/2");
	tag_incr_hp_msg(r23, MR_mktag(3), (Integer) 3, mercury__unify_gen__generate_construction_2__ua0_8_0, "llds:instr/0");
	MR_field(MR_mktag(3), r23, (Integer) 0) = (Integer) 1;
	tag_incr_hp_msg(r24, MR_mktag(3), (Integer) 4, mercury__unify_gen__generate_construction_2__ua0_8_0, "llds:lval/0");
	MR_field(MR_mktag(3), r24, (Integer) 0) = (Integer) 7;
	MR_field(MR_mktag(3), r24, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_unify_gen__common_1);
	MR_field(MR_mktag(3), r24, (Integer) 2) = r7;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 1, mercury__unify_gen__generate_construction_2__ua0_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(12);
	MR_field(MR_mktag(3), r23, (Integer) 1) = r24;
	MR_field(MR_mktag(3), r24, (Integer) 3) = MR_tempr1;
	tag_incr_hp_msg(r24, MR_mktag(0), (Integer) 1, mercury__unify_gen__generate_construction_2__ua0_8_0, "llds:rval/0");
	tag_incr_hp_msg(r25, MR_mktag(3), (Integer) 4, mercury__unify_gen__generate_construction_2__ua0_8_0, "llds:lval/0");
	MR_field(MR_mktag(3), r25, (Integer) 0) = (Integer) 7;
	MR_field(MR_mktag(3), r25, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_unify_gen__common_1);
	MR_field(MR_mktag(3), r25, (Integer) 2) = r2;
	MR_field(MR_mktag(0), r22, (Integer) 1) = (Word) MR_string_const("copy old hidden argument", 24);
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 1, mercury__unify_gen__generate_construction_2__ua0_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(12);
	MR_field(MR_mktag(3), r23, (Integer) 2) = r24;
	MR_field(MR_mktag(3), r25, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r21, (Integer) 0) = r22;
	MR_field(MR_mktag(0), r22, (Integer) 0) = r23;
	MR_field(MR_mktag(0), r24, (Integer) 0) = r25;
	tag_incr_hp_msg(r22, MR_mktag(1), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "list:list/1");
	tag_incr_hp_msg(r23, MR_mktag(0), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "std_util:pair/2");
	tag_incr_hp_msg(r24, MR_mktag(3), (Integer) 3, mercury__unify_gen__generate_construction_2__ua0_8_0, "llds:instr/0");
	MR_field(MR_mktag(3), r24, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r24, (Integer) 1) = MR_stackvar(12);
	tag_incr_hp_msg(r25, MR_mktag(3), (Integer) 4, mercury__unify_gen__generate_construction_2__ua0_8_0, "llds:rval/0");
	MR_field(MR_mktag(3), r25, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r25, (Integer) 1) = (Integer) 0;
	MR_field(MR_mktag(3), r25, (Integer) 3) = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_unify_gen__common_4);
	MR_field(MR_mktag(0), r23, (Integer) 1) = (Word) MR_string_const("increment loop counter", 22);
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 1, mercury__unify_gen__generate_construction_2__ua0_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(12);
	MR_field(MR_mktag(3), r24, (Integer) 2) = r25;
	MR_field(MR_mktag(3), r25, (Integer) 2) = MR_tempr1;
	MR_field(MR_mktag(1), r22, (Integer) 0) = r23;
	MR_field(MR_mktag(0), r23, (Integer) 0) = r24;
	tag_incr_hp_msg(r23, MR_mktag(1), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "list:list/1");
	tag_incr_hp_msg(r24, MR_mktag(0), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "std_util:pair/2");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(11);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(0), r24, (Integer) 1) = (Word) MR_string_const("do we have more old arguments to copy?", 38);
	MR_field(MR_mktag(1), r23, (Integer) 0) = r24;
	MR_field(MR_mktag(0), r24, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r24, MR_mktag(1), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "list:list/1");
	tag_incr_hp_msg(r25, MR_mktag(0), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "std_util:pair/2");
	tag_incr_hp_msg(r26, MR_mktag(3), (Integer) 3, mercury__unify_gen__generate_construction_2__ua0_8_0, "llds:instr/0");
	MR_field(MR_mktag(3), r26, (Integer) 0) = (Integer) 8;
	tag_incr_hp_msg(r27, MR_mktag(3), (Integer) 4, mercury__unify_gen__generate_construction_2__ua0_8_0, "llds:rval/0");
	MR_field(MR_mktag(3), r27, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r27, (Integer) 1) = (Integer) 21;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 1, mercury__unify_gen__generate_construction_2__ua0_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(12);
	MR_field(MR_mktag(3), r27, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 1, mercury__unify_gen__generate_construction_2__ua0_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(13);
	MR_field(MR_mktag(3), r26, (Integer) 1) = r27;
	MR_field(MR_mktag(3), r27, (Integer) 3) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__unify_gen__generate_construction_2__ua0_8_0, "origin_lost_in_value_number");
	r4 = r3;
	MR_field(MR_mktag(3), r26, (Integer) 2) = MR_tempr1;
	r1 = r6;
	r2 = MR_stackvar(12);
	r3 = MR_stackvar(14);
	MR_field(MR_mktag(1), MR_stackvar(10), (Integer) 0) = r11;
	MR_field(MR_mktag(1), r11, (Integer) 1) = r12;
	MR_field(MR_mktag(1), r12, (Integer) 1) = r13;
	MR_field(MR_mktag(1), r13, (Integer) 1) = r14;
	MR_field(MR_mktag(1), r14, (Integer) 1) = r15;
	MR_field(MR_mktag(1), r15, (Integer) 1) = r16;
	MR_field(MR_mktag(1), r16, (Integer) 1) = r17;
	MR_field(MR_mktag(1), r17, (Integer) 1) = r18;
	MR_field(MR_mktag(1), r18, (Integer) 1) = r19;
	MR_field(MR_mktag(1), r19, (Integer) 1) = r20;
	MR_field(MR_mktag(1), r20, (Integer) 1) = r21;
	MR_field(MR_mktag(1), r21, (Integer) 1) = r22;
	MR_field(MR_mktag(1), r22, (Integer) 1) = r23;
	MR_field(MR_mktag(1), r23, (Integer) 1) = r24;
	MR_field(MR_mktag(1), r24, (Integer) 0) = r25;
	MR_field(MR_mktag(1), r24, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r5;
	MR_field(MR_mktag(0), r25, (Integer) 0) = r26;
	MR_field(MR_mktag(0), r25, (Integer) 1) = (Word) MR_string_const("repeat the loop?", 16);
	call_localret(STATIC(mercury__unify_gen__generate_extra_closure_args_6_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i56,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
	}
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i56);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	MR_stackvar(11) = r1;
	r1 = MR_stackvar(12);
	call_localret(ENTRY(mercury__code_info__release_reg_3_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i57,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i57);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	r2 = r1;
	r1 = MR_stackvar(13);
	call_localret(ENTRY(mercury__code_info__release_reg_3_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i58,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i58);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	r2 = r1;
	r1 = MR_stackvar(14);
	call_localret(ENTRY(mercury__code_info__release_reg_3_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i59,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i59);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	r3 = MR_stackvar(3);
	{
	Word MR_tempr1, MR_tempr2;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(9);
	MR_stackvar(3) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "origin_lost_in_value_number");
	MR_tempr2 = r2;
	r2 = r3;
	r3 = MR_tempr2;
	MR_field(MR_mktag(2), MR_stackvar(3), (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = MR_stackvar(11);
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(10);
	call_localret(ENTRY(mercury__code_info__cache_expression_4_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i107,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
	}
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i31);
	if (((Integer) MR_stackvar(6) != (Integer) 0))
		GOTO_LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0_i62);
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i1015);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(5);
	r1 = MR_stackvar(7);
	GOTO_LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0_i61);
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i62);
	if (((Integer) MR_stackvar(6) != (Integer) 1))
		GOTO_LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0_i63);
	r1 = (Word) MR_string_const("Sorry, not implemented: `aditi_top_down' closures", 49);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i1015,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i63);
	r1 = (Word) MR_string_const("Sorry, not implemented: `aditi_bottom_up' closures", 50);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i1015,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i61);
	MR_stackvar(4) = r2;
	MR_stackvar(5) = r3;
	MR_stackvar(7) = r1;
	call_localret(ENTRY(mercury__continuation_info__generate_closure_layout_4_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i66,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i66);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(7);
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(5);
	r4 = (Integer) 0;
	r5 = MR_stackvar(20);
	call_localret(ENTRY(mercury__code_info__make_entry_label_7_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i67,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i67);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	MR_stackvar(4) = r1;
	MR_stackvar(5) = r2;
	call_localret(ENTRY(mercury__code_util__extract_proc_label_from_code_addr_2_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i68,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i68);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	r2 = r1;
	r1 = MR_stackvar(5);
	MR_stackvar(5) = r2;
	call_localret(ENTRY(mercury__code_info__get_cell_count_3_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i69,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i69);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r2;
	r2 = MR_stackvar(3);
	MR_stackvar(3) = MR_tempr1;
	r3 = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__stack_layout__construct_closure_layout_6_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i70,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
	}
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i70);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	MR_stackvar(5) = r2;
	r2 = MR_stackvar(3);
	MR_stackvar(3) = r1;
	r1 = r3;
	call_localret(ENTRY(mercury__code_info__set_cell_count_3_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i71,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i71);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	call_localret(ENTRY(mercury__code_info__get_next_cell_number_3_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i72,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i72);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	r3 = MR_stackvar(3);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 6, mercury__unify_gen__generate_construction_2__ua0_8_0, "origin_lost_in_value_number");
	MR_stackvar(3) = MR_tempr1;
	MR_stackvar(6) = r2;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 4) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_gen__common_0);
	r2 = MR_stackvar(2);
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 5) = (Word) MR_string_const("closure_layout", 14);
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 3) = (Integer) 0;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 2) = MR_stackvar(5);
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = r3;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = (Integer) 0;
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i73,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
	}
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i73);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(8);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_arg_info_2_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i74,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i74);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(STATIC(mercury__unify_gen__generate_pred_args_3_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i1215,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i1215);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	tag_incr_hp_msg(MR_stackvar(2), MR_mktag(1), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "list:list/1");
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__unify_gen__generate_construction_2__ua0_8_0, "std_util:maybe/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(1), MR_stackvar(2), (Integer) 0) = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__unify_gen__generate_construction_2__ua0_8_0, "std_util:maybe/1");
	tag_incr_hp_msg(r4, MR_mktag(3), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "llds:rval/0");
	MR_field(MR_mktag(3), r4, (Integer) 0) = (Integer) 1;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(4);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r4, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r2, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "list:list/1");
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 1, mercury__unify_gen__generate_construction_2__ua0_8_0, "std_util:maybe/1");
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__unify_gen__generate_construction_2__ua0_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r5, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r1;
	r1 = MR_stackvar(6);
	MR_field(MR_mktag(1), MR_stackvar(2), (Integer) 1) = r2;
	MR_field(MR_mktag(1), r2, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 0) = r5;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(5);
	call_localret(ENTRY(mercury__code_info__get_next_cell_number_3_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i76,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
	}
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i76);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(3) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r4 = r2;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 6, mercury__unify_gen__generate_construction_2__ua0_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), r2, (Integer) 4) = r3;
	r3 = r4;
	MR_field(MR_mktag(2), r2, (Integer) 5) = (Word) MR_string_const("closure", 7);
	MR_field(MR_mktag(2), r2, (Integer) 3) = (Integer) 1;
	MR_field(MR_mktag(2), r2, (Integer) 2) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_unify_gen__common_11);
	MR_field(MR_mktag(2), r2, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(2), r2, (Integer) 0) = (Integer) 0;
	call_localret(ENTRY(mercury__code_info__cache_expression_4_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i107,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i79);
	r6 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r4 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0_i80);
	MR_stackvar(2) = r6;
	MR_stackvar(4) = r4;
	r1 = r5;
	MR_stackvar(1) = r2;
	MR_stackvar(3) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__code_info__get_module_info_3_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i84,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i80);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r6;
	MR_stackvar(4) = r4;
	r1 = (Word) MR_string_const("unify_gen: address constant has args", 36);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i83,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i83);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	call_localret(ENTRY(mercury__code_info__get_module_info_3_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i84,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i84);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	r5 = r2;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(4);
	r4 = (Integer) 0;
	call_localret(ENTRY(mercury__code_info__make_entry_label_7_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i85,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i85);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r4 = r2;
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "llds:rval/0");
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 1;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r2, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r3;
	r3 = r4;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 2;
	call_localret(ENTRY(mercury__code_info__cache_expression_4_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i107,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
	}
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i87);
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0_i88);
	r4 = r1;
	r1 = r2;
	r3 = r5;
	MR_stackvar(3) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "llds:rval/0");
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 1;
	tag_incr_hp_msg(r7, MR_mktag(3), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "llds:rval_const/0");
	MR_field(MR_mktag(3), r7, (Integer) 0) = (Integer) 3;
	tag_incr_hp_msg(r8, MR_mktag(0), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "llds:data_addr/0");
	MR_field(MR_mktag(0), r8, (Integer) 0) = MR_const_field(MR_mktag(3), r4, (Integer) 1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 3, mercury__unify_gen__generate_construction_2__ua0_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r8, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = MR_const_field(MR_mktag(3), r4, (Integer) 2);
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 2) = MR_const_field(MR_mktag(3), r4, (Integer) 3);
	MR_field(MR_mktag(3), r2, (Integer) 1) = r7;
	MR_field(MR_mktag(3), r7, (Integer) 1) = r8;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = (Integer) 0;
	call_localret(ENTRY(mercury__code_info__cache_expression_4_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i107,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
	}
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i88);
	MR_stackvar(1) = r2;
	r1 = (Word) MR_string_const("unify_gen: type-info constant has args", 38);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i90,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i90);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__code_info__cache_expression_4_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i107,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i93);
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0_i94);
	r4 = r1;
	r1 = r2;
	r3 = r5;
	MR_stackvar(3) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "llds:rval/0");
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 1;
	tag_incr_hp_msg(r7, MR_mktag(3), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "llds:rval_const/0");
	MR_field(MR_mktag(3), r7, (Integer) 0) = (Integer) 3;
	tag_incr_hp_msg(r8, MR_mktag(0), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "llds:data_addr/0");
	MR_field(MR_mktag(0), r8, (Integer) 0) = MR_const_field(MR_mktag(3), r4, (Integer) 1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 3, mercury__unify_gen__generate_construction_2__ua0_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r8, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_const_field(MR_mktag(3), r4, (Integer) 2);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_const_field(MR_mktag(3), r4, (Integer) 3);
	MR_field(MR_mktag(3), r2, (Integer) 1) = r7;
	MR_field(MR_mktag(3), r7, (Integer) 1) = r8;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 0;
	call_localret(ENTRY(mercury__code_info__cache_expression_4_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i107,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
	}
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i94);
	MR_stackvar(1) = r2;
	r1 = (Word) MR_string_const("unify_gen: typeclass-info constant has args", 43);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i96,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i96);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__code_info__cache_expression_4_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i107,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i99);
	r6 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r4 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0_i100);
	MR_stackvar(2) = r6;
	MR_stackvar(4) = r4;
	r1 = r5;
	MR_stackvar(1) = r2;
	MR_stackvar(3) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__code_info__get_module_info_3_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i104,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i100);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r6;
	MR_stackvar(4) = r4;
	r1 = (Word) MR_string_const("unify_gen: tabling pointer constant has args", 44);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i103,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i103);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	call_localret(ENTRY(mercury__code_info__get_module_info_3_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i104,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i104);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	r3 = MR_stackvar(4);
	MR_stackvar(4) = r2;
	r2 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	call_localret(ENTRY(mercury__code_util__make_proc_label_4_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i105,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i105);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__hlds_module__module_info_name_2_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i106,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i106);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "llds:rval/0");
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 1;
	tag_incr_hp_msg(r4, MR_mktag(3), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "llds:rval_const/0");
	MR_field(MR_mktag(3), r4, (Integer) 0) = (Integer) 3;
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "llds:data_addr/0");
	MR_field(MR_mktag(0), r5, (Integer) 0) = r3;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r5, (Integer) 1) = MR_tempr1;
	r3 = MR_stackvar(4);
	MR_field(MR_mktag(3), r2, (Integer) 1) = r4;
	MR_field(MR_mktag(3), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 3;
	call_localret(ENTRY(mercury__code_info__cache_expression_4_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i107,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
	}
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i107);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(21);
	MR_decr_sp_pop_msg(21);
	proceed();
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i108);
	MR_stackvar(4) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r1 = r5;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	call_localret(ENTRY(mercury__code_info__get_module_info_3_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i109,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i109);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	MR_stackvar(5) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_next_cell_number_3_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i110,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i110);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	MR_stackvar(6) = r1;
	r1 = MR_stackvar(2);
	call_localret(STATIC(mercury__unify_gen__var_types_4_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i111,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i111);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	r2 = MR_tempr1;
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(5);
	call_localret(STATIC(mercury__unify_gen__generate_cons_args_5_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i112,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
	}
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i112);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	r2 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__code_info__variable_type_4_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i113,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i113);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	MR_stackvar(3) = r2;
	call_localret(STATIC(mercury__unify_gen__var_type_msg_2_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i114,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i114);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 6, mercury__unify_gen__generate_construction_2__ua0_8_0, "llds:rval/0");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(2), r2, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(2), r2, (Integer) 2) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_unify_gen__common_11);
	MR_field(MR_mktag(2), r2, (Integer) 3) = (Integer) 1;
	MR_field(MR_mktag(2), r2, (Integer) 4) = MR_stackvar(6);
	MR_field(MR_mktag(2), r2, (Integer) 5) = r3;
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury__code_info__cache_expression_4_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i125,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i116);
	MR_stackvar(4) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = r5;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	call_localret(ENTRY(mercury__code_info__get_module_info_3_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i117,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i117);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	MR_stackvar(6) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_next_cell_number_3_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i118,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i118);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	MR_stackvar(7) = r1;
	r1 = MR_stackvar(2);
	call_localret(STATIC(mercury__unify_gen__var_types_4_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i119,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i119);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	r2 = MR_tempr1;
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(6);
	call_localret(STATIC(mercury__unify_gen__generate_cons_args_5_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i120,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
	}
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i120);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	r2 = MR_stackvar(2);
	tag_incr_hp_msg(MR_stackvar(2), MR_mktag(1), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__unify_gen__generate_construction_2__ua0_8_0, "std_util:maybe/1");
	tag_incr_hp_msg(r4, MR_mktag(3), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "llds:rval/0");
	MR_field(MR_mktag(3), r4, (Integer) 0) = (Integer) 1;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__unify_gen__generate_construction_2__ua0_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r4, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), MR_stackvar(2), (Integer) 1) = r1;
	r1 = MR_stackvar(1);
	MR_field(MR_mktag(1), MR_stackvar(2), (Integer) 0) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(5);
	call_localret(ENTRY(mercury__code_info__variable_type_4_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i121,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
	}
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i121);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	MR_stackvar(3) = r2;
	call_localret(STATIC(mercury__unify_gen__var_type_msg_2_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i122,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i122);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 6, mercury__unify_gen__generate_construction_2__ua0_8_0, "llds:rval/0");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(2), r2, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(2), r2, (Integer) 2) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_unify_gen__common_11);
	MR_field(MR_mktag(2), r2, (Integer) 3) = (Integer) 1;
	MR_field(MR_mktag(2), r2, (Integer) 4) = MR_stackvar(7);
	MR_field(MR_mktag(2), r2, (Integer) 5) = r3;
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury__code_info__cache_expression_4_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i125,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i124);
	r3 = r1;
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 3, mercury__unify_gen__generate_construction_2__ua0_8_0, "llds:rval/0");
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(3), r2, (Integer) 1) = MR_const_field(MR_mktag(3), r3, (Integer) 1);
	tag_incr_hp_msg(r4, MR_mktag(3), (Integer) 3, mercury__unify_gen__generate_construction_2__ua0_8_0, "llds:rval/0");
	MR_field(MR_mktag(3), r4, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r4, (Integer) 1) = (Integer) 3;
	tag_incr_hp_msg(r6, MR_mktag(3), (Integer) 2, mercury__unify_gen__generate_construction_2__ua0_8_0, "llds:rval/0");
	MR_field(MR_mktag(3), r6, (Integer) 0) = (Integer) 1;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__unify_gen__generate_construction_2__ua0_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r6, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(3), r3, (Integer) 2);
	r3 = r5;
	MR_field(MR_mktag(3), r2, (Integer) 2) = r4;
	MR_field(MR_mktag(3), r4, (Integer) 2) = r6;
	call_localret(ENTRY(mercury__code_info__cache_expression_4_0),
		mercury__unify_gen__generate_construction_2__ua0_8_0_i125,
		STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0));
	}
Define_label(mercury__unify_gen__generate_construction_2__ua0_8_0_i125);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_construction_2__ua0_8_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(21);
	MR_decr_sp_pop_msg(21);
	proceed();
END_MODULE

Declare_entry(mercury__code_info__cons_id_to_tag_5_0);
Declare_entry(mercury__code_info__remember_position_3_0);
Declare_entry(mercury__code_info__generate_failure_3_0);
Declare_entry(mercury__code_info__reset_to_position_3_0);
Declare_entry(mercury__code_info__variable_is_forward_live_3_0);

BEGIN_MODULE(unify_gen_module1)
	init_entry(mercury__unify_gen__generate_unification_5_0);
	init_label(mercury__unify_gen__generate_unification_5_0_i4);
	init_label(mercury__unify_gen__generate_unification_5_0_i2);
	init_label(mercury__unify_gen__generate_unification_5_0_i5);
	init_label(mercury__unify_gen__generate_unification_5_0_i8);
	init_label(mercury__unify_gen__generate_unification_5_0_i9);
	init_label(mercury__unify_gen__generate_unification_5_0_i11);
	init_label(mercury__unify_gen__generate_unification_5_0_i12);
	init_label(mercury__unify_gen__generate_unification_5_0_i15);
	init_label(mercury__unify_gen__generate_unification_5_0_i16);
	init_label(mercury__unify_gen__generate_unification_5_0_i17);
	init_label(mercury__unify_gen__generate_unification_5_0_i18);
	init_label(mercury__unify_gen__generate_unification_5_0_i19);
	init_label(mercury__unify_gen__generate_unification_5_0_i21);
	init_label(mercury__unify_gen__generate_unification_5_0_i24);
	init_label(mercury__unify_gen__generate_unification_5_0_i26);
	init_label(mercury__unify_gen__generate_unification_5_0_i22);
	init_label(mercury__unify_gen__generate_unification_5_0_i27);
	init_label(mercury__unify_gen__generate_unification_5_0_i28);
	init_label(mercury__unify_gen__generate_unification_5_0_i30);
	init_label(mercury__unify_gen__generate_unification_5_0_i29);
BEGIN_CODE

/* code for predicate 'generate_unification'/5 in mode 0 */
Define_entry(mercury__unify_gen__generate_unification_5_0);
	MR_incr_sp_push_msg(8, "unify_gen:generate_unification/5");
	MR_stackvar(8) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) 2))
		GOTO_LABEL(mercury__unify_gen__generate_unification_5_0_i2);
	MR_stackvar(1) = r1;
	r1 = (Word) MR_string_const("nondet unification in unify_gen__generate_unification", 53);
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__unify_gen__generate_unification_5_0_i4,
		ENTRY(mercury__unify_gen__generate_unification_5_0));
Define_label(mercury__unify_gen__generate_unification_5_0_i4);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_unification_5_0));
	r2 = MR_stackvar(3);
	GOTO_LABEL(mercury__unify_gen__generate_unification_5_0_i5);
Define_label(mercury__unify_gen__generate_unification_5_0_i2);
	MR_stackvar(2) = r2;
	r2 = r3;
	MR_stackvar(1) = r1;
Define_label(mercury__unify_gen__generate_unification_5_0_i5);
	r1 = MR_stackvar(2);
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__unify_gen__generate_unification_5_0_i8) AND
		LABEL(mercury__unify_gen__generate_unification_5_0_i11) AND
		LABEL(mercury__unify_gen__generate_unification_5_0_i21) AND
		LABEL(mercury__unify_gen__generate_unification_5_0_i28));
Define_label(mercury__unify_gen__generate_unification_5_0_i8);
	r3 = r2;
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__code_info__cons_id_to_tag_5_0),
		mercury__unify_gen__generate_unification_5_0_i9,
		ENTRY(mercury__unify_gen__generate_unification_5_0));
Define_label(mercury__unify_gen__generate_unification_5_0_i9);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_unification_5_0));
	r5 = r2;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	tailcall(STATIC(mercury__unify_gen__generate_construction_2__ua0_8_0),
		ENTRY(mercury__unify_gen__generate_unification_5_0));
Define_label(mercury__unify_gen__generate_unification_5_0_i11);
	r4 = MR_const_field(MR_mktag(1), r1, (Integer) 3);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 2);
	r5 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r6 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	if (((Integer) MR_stackvar(1) != (Integer) 0))
		GOTO_LABEL(mercury__unify_gen__generate_unification_5_0_i12);
	{
	Word MR_tempr1;
	MR_tempr1 = r2;
	r2 = r5;
	r5 = MR_tempr1;
	r1 = r6;
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	tailcall(STATIC(mercury__unify_gen__generate_det_deconstruction_7_0),
		ENTRY(mercury__unify_gen__generate_unification_5_0));
	}
Define_label(mercury__unify_gen__generate_unification_5_0_i12);
	MR_stackvar(4) = r4;
	r4 = r2;
	MR_stackvar(3) = r3;
	r1 = r6;
	r2 = r5;
	r3 = (Integer) 0;
	MR_stackvar(1) = r6;
	MR_stackvar(2) = r5;
	call_localret(STATIC(mercury__unify_gen__generate_tag_test_7_0),
		mercury__unify_gen__generate_unification_5_0_i15,
		ENTRY(mercury__unify_gen__generate_unification_5_0));
Define_label(mercury__unify_gen__generate_unification_5_0_i15);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_unification_5_0));
	MR_stackvar(5) = r1;
	r1 = r3;
	MR_stackvar(6) = r2;
	call_localret(ENTRY(mercury__code_info__remember_position_3_0),
		mercury__unify_gen__generate_unification_5_0_i16,
		ENTRY(mercury__unify_gen__generate_unification_5_0));
Define_label(mercury__unify_gen__generate_unification_5_0_i16);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_unification_5_0));
	MR_stackvar(7) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__generate_failure_3_0),
		mercury__unify_gen__generate_unification_5_0_i17,
		ENTRY(mercury__unify_gen__generate_unification_5_0));
Define_label(mercury__unify_gen__generate_unification_5_0_i17);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_unification_5_0));
	r3 = r1;
	r1 = MR_stackvar(7);
	MR_stackvar(7) = r3;
	call_localret(ENTRY(mercury__code_info__reset_to_position_3_0),
		mercury__unify_gen__generate_unification_5_0_i18,
		ENTRY(mercury__unify_gen__generate_unification_5_0));
Define_label(mercury__unify_gen__generate_unification_5_0_i18);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_unification_5_0));
	r5 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	call_localret(STATIC(mercury__unify_gen__generate_det_deconstruction_7_0),
		mercury__unify_gen__generate_unification_5_0_i19,
		ENTRY(mercury__unify_gen__generate_unification_5_0));
Define_label(mercury__unify_gen__generate_unification_5_0_i19);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_unification_5_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 2, mercury__unify_gen__generate_unification_5_0, "tree:tree/1");
	MR_field(MR_mktag(2), r1, (Integer) 0) = MR_stackvar(6);
	tag_incr_hp_msg(r4, MR_mktag(2), (Integer) 2, mercury__unify_gen__generate_unification_5_0, "tree:tree/1");
	MR_field(MR_mktag(2), r4, (Integer) 0) = MR_stackvar(7);
	tag_incr_hp_msg(r5, MR_mktag(2), (Integer) 2, mercury__unify_gen__generate_unification_5_0, "tree:tree/1");
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 1, mercury__unify_gen__generate_unification_5_0, "tree:tree/1");
	tag_incr_hp_msg(r7, MR_mktag(1), (Integer) 2, mercury__unify_gen__generate_unification_5_0, "list:list/1");
	tag_incr_hp_msg(r8, MR_mktag(0), (Integer) 2, mercury__unify_gen__generate_unification_5_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__unify_gen__generate_unification_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r8, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(5);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(2), r1, (Integer) 1) = r4;
	MR_field(MR_mktag(2), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(2), r5, (Integer) 1) = r3;
	MR_field(MR_mktag(2), r5, (Integer) 0) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 0) = r7;
	MR_field(MR_mktag(1), r7, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r7, (Integer) 0) = r8;
	MR_field(MR_mktag(0), r8, (Integer) 1) = (Word) MR_string_const("", 0);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
	}
Define_label(mercury__unify_gen__generate_unification_5_0_i21);
	MR_stackvar(2) = MR_const_field(MR_mktag(2), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	MR_stackvar(1) = r1;
	MR_stackvar(3) = r2;
	call_localret(ENTRY(mercury__code_info__variable_is_forward_live_3_0),
		mercury__unify_gen__generate_unification_5_0_i24,
		ENTRY(mercury__unify_gen__generate_unification_5_0));
Define_label(mercury__unify_gen__generate_unification_5_0_i24);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_unification_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__unify_gen__generate_unification_5_0_i22);
	r1 = MR_stackvar(1);
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__unify_gen__generate_unification_5_0, "llds:rval/0");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(2);
	call_localret(ENTRY(mercury__code_info__cache_expression_4_0),
		mercury__unify_gen__generate_unification_5_0_i26,
		ENTRY(mercury__unify_gen__generate_unification_5_0));
Define_label(mercury__unify_gen__generate_unification_5_0_i26);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_unification_5_0));
	r2 = r1;
	GOTO_LABEL(mercury__unify_gen__generate_unification_5_0_i27);
Define_label(mercury__unify_gen__generate_unification_5_0_i22);
	r2 = MR_stackvar(3);
Define_label(mercury__unify_gen__generate_unification_5_0_i27);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__unify_gen__generate_unification_5_0_i28);
	if (((Integer) MR_const_field(MR_mktag(3), r1, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__unify_gen__generate_unification_5_0_i29);
	r3 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r4 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	if (((Integer) MR_stackvar(1) != (Integer) 0))
		GOTO_LABEL(mercury__unify_gen__generate_unification_5_0_i30);
	r1 = (Word) MR_string_const("det simple_test during code generation", 38);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__unify_gen__generate_unification_5_0));
Define_label(mercury__unify_gen__generate_unification_5_0_i30);
	{
	Word MR_tempr1;
	MR_tempr1 = r2;
	r2 = r3;
	r3 = MR_tempr1;
	r1 = r4;
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	tailcall(STATIC(mercury__unify_gen__generate_test_5_0),
		ENTRY(mercury__unify_gen__generate_unification_5_0));
	}
Define_label(mercury__unify_gen__generate_unification_5_0_i29);
	r1 = (Word) MR_string_const("complicated unify during code generation", 40);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__unify_gen__generate_unification_5_0));
END_MODULE

Declare_entry(mercury__code_info__lookup_type_defn_4_0);
Declare_entry(mercury__hlds_data__get_type_defn_body_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_data__type_ctor_info_cons_id_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_data__type_ctor_info_cons_tag_0;
Declare_entry(mercury__map__to_assoc_list_2_0);
Declare_entry(mercury____Unify___hlds_data__cons_id_0_0);
Declare_entry(mercury__code_info__variable_to_string_4_0);
Declare_entry(mercury__hlds_out__cons_id_to_string_2_0);
Declare_entry(mercury__string__append_list_2_0);
Declare_entry(mercury__code_util__neg_rval_2_0);

BEGIN_MODULE(unify_gen_module2)
	init_entry(mercury__unify_gen__generate_tag_test_7_0);
	init_label(mercury__unify_gen__generate_tag_test_7_0_i2);
	init_label(mercury__unify_gen__generate_tag_test_7_0_i5);
	init_label(mercury__unify_gen__generate_tag_test_7_0_i6);
	init_label(mercury__unify_gen__generate_tag_test_7_0_i7);
	init_label(mercury__unify_gen__generate_tag_test_7_0_i10);
	init_label(mercury__unify_gen__generate_tag_test_7_0_i14);
	init_label(mercury__unify_gen__generate_tag_test_7_0_i11);
	init_label(mercury__unify_gen__generate_tag_test_7_0_i12);
	init_label(mercury__unify_gen__generate_tag_test_7_0_i24);
	init_label(mercury__unify_gen__generate_tag_test_7_0_i8);
	init_label(mercury__unify_gen__generate_tag_test_7_0_i3);
	init_label(mercury__unify_gen__generate_tag_test_7_0_i32);
	init_label(mercury__unify_gen__generate_tag_test_7_0_i33);
	init_label(mercury__unify_gen__generate_tag_test_7_0_i34);
	init_label(mercury__unify_gen__generate_tag_test_7_0_i37);
	init_label(mercury__unify_gen__generate_tag_test_7_0_i38);
	init_label(mercury__unify_gen__generate_tag_test_7_0_i36);
	init_label(mercury__unify_gen__generate_tag_test_7_0_i40);
	init_label(mercury__unify_gen__generate_tag_test_7_0_i41);
	init_label(mercury__unify_gen__generate_tag_test_7_0_i42);
	init_label(mercury__unify_gen__generate_tag_test_7_0_i43);
	init_label(mercury__unify_gen__generate_tag_test_7_0_i44);
	init_label(mercury__unify_gen__generate_tag_test_7_0_i46);
	init_label(mercury__unify_gen__generate_tag_test_7_0_i47);
BEGIN_CODE

/* code for predicate 'generate_tag_test'/7 in mode 0 */
Define_entry(mercury__unify_gen__generate_tag_test_7_0);
	MR_incr_sp_push_msg(11, "unify_gen:generate_tag_test/7");
	MR_stackvar(11) = (Word) MR_succip;
	MR_stackvar(2) = r2;
	r2 = r4;
	MR_stackvar(1) = r1;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__code_info__produce_variable_5_0),
		mercury__unify_gen__generate_tag_test_7_0_i2,
		ENTRY(mercury__unify_gen__generate_tag_test_7_0));
Define_label(mercury__unify_gen__generate_tag_test_7_0_i2);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_tag_test_7_0));
	if ((MR_tag(MR_stackvar(2)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__unify_gen__generate_tag_test_7_0_i3);
	r4 = MR_const_field(MR_mktag(0), MR_stackvar(2), (Integer) 1);
	if (((Integer) r4 <= (Integer) 0))
		GOTO_LABEL(mercury__unify_gen__generate_tag_test_7_0_i3);
	MR_stackvar(6) = r1;
	MR_stackvar(7) = r2;
	r1 = MR_stackvar(1);
	r2 = r3;
	call_localret(ENTRY(mercury__code_info__variable_type_4_0),
		mercury__unify_gen__generate_tag_test_7_0_i5,
		ENTRY(mercury__unify_gen__generate_tag_test_7_0));
Define_label(mercury__unify_gen__generate_tag_test_7_0_i5);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_tag_test_7_0));
	call_localret(ENTRY(mercury__code_info__lookup_type_defn_4_0),
		mercury__unify_gen__generate_tag_test_7_0_i6,
		ENTRY(mercury__unify_gen__generate_tag_test_7_0));
Define_label(mercury__unify_gen__generate_tag_test_7_0_i6);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_tag_test_7_0));
	MR_stackvar(10) = r2;
	call_localret(ENTRY(mercury__hlds_data__get_type_defn_body_2_0),
		mercury__unify_gen__generate_tag_test_7_0_i7,
		ENTRY(mercury__unify_gen__generate_tag_test_7_0));
Define_label(mercury__unify_gen__generate_tag_test_7_0_i7);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_tag_test_7_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__unify_gen__generate_tag_test_7_0_i8);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_cons_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_data__type_ctor_info_cons_tag_0;
	call_localret(ENTRY(mercury__map__to_assoc_list_2_0),
		mercury__unify_gen__generate_tag_test_7_0_i10,
		ENTRY(mercury__unify_gen__generate_tag_test_7_0));
Define_label(mercury__unify_gen__generate_tag_test_7_0_i10);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_tag_test_7_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_gen__generate_tag_test_7_0_i12);
	r2 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(8) = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury____Unify___hlds_data__cons_id_0_0),
		mercury__unify_gen__generate_tag_test_7_0_i14,
		ENTRY(mercury__unify_gen__generate_tag_test_7_0));
Define_label(mercury__unify_gen__generate_tag_test_7_0_i14);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_tag_test_7_0));
	r3 = MR_stackvar(4);
	if (!(r1))
		GOTO_LABEL(mercury__unify_gen__generate_tag_test_7_0_i11);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_gen__generate_tag_test_7_0_i11);
	if (((Integer) MR_const_field(MR_mktag(1), r3, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_gen__generate_tag_test_7_0_i11);
	{
	Word MR_tempr1, MR_tempr2, MR_tempr3, MR_tempr4, MR_tempr5;
	MR_tempr3 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r3, (Integer) 0), (Integer) 0);
	if ((MR_tag(MR_tempr3) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__unify_gen__generate_tag_test_7_0_i11);
	if (((Integer) MR_const_field(MR_mktag(0), MR_tempr3, (Integer) 1) != (Integer) 0))
		GOTO_LABEL(mercury__unify_gen__generate_tag_test_7_0_i11);
	tag_incr_hp_msg(MR_tempr5, MR_mktag(1), (Integer) 1, mercury__unify_gen__generate_tag_test_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr5, (Integer) 0) = MR_tempr3;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(10);
	MR_stackvar(4) = MR_tempr5;
	GOTO_LABEL(mercury__unify_gen__generate_tag_test_7_0_i32);
	}
Define_label(mercury__unify_gen__generate_tag_test_7_0_i11);
	r1 = MR_stackvar(8);
Define_label(mercury__unify_gen__generate_tag_test_7_0_i12);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_gen__generate_tag_test_7_0_i8);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_gen__generate_tag_test_7_0_i8);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	r2 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r3, (Integer) 0), (Integer) 0);
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury____Unify___hlds_data__cons_id_0_0),
		mercury__unify_gen__generate_tag_test_7_0_i24,
		ENTRY(mercury__unify_gen__generate_tag_test_7_0));
Define_label(mercury__unify_gen__generate_tag_test_7_0_i24);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_tag_test_7_0));
	if (!(r1))
		GOTO_LABEL(mercury__unify_gen__generate_tag_test_7_0_i8);
	if (((Integer) MR_stackvar(4) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_gen__generate_tag_test_7_0_i8);
	if ((MR_tag(MR_stackvar(5)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__unify_gen__generate_tag_test_7_0_i8);
	r1 = MR_const_field(MR_mktag(0), MR_stackvar(5), (Integer) 1);
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__unify_gen__generate_tag_test_7_0_i8);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(10);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__unify_gen__generate_tag_test_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(5);
	MR_stackvar(4) = r3;
	GOTO_LABEL(mercury__unify_gen__generate_tag_test_7_0_i32);
Define_label(mercury__unify_gen__generate_tag_test_7_0_i8);
	r1 = MR_stackvar(1);
	MR_stackvar(4) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = MR_stackvar(10);
	GOTO_LABEL(mercury__unify_gen__generate_tag_test_7_0_i32);
Define_label(mercury__unify_gen__generate_tag_test_7_0_i3);
	MR_stackvar(6) = r1;
	MR_stackvar(7) = r2;
	r1 = MR_stackvar(1);
	r2 = r3;
	MR_stackvar(4) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
Define_label(mercury__unify_gen__generate_tag_test_7_0_i32);
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__code_info__variable_to_string_4_0),
		mercury__unify_gen__generate_tag_test_7_0_i33,
		ENTRY(mercury__unify_gen__generate_tag_test_7_0));
Define_label(mercury__unify_gen__generate_tag_test_7_0_i33);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_tag_test_7_0));
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(9) = r2;
	call_localret(ENTRY(mercury__hlds_out__cons_id_to_string_2_0),
		mercury__unify_gen__generate_tag_test_7_0_i34,
		ENTRY(mercury__unify_gen__generate_tag_test_7_0));
Define_label(mercury__unify_gen__generate_tag_test_7_0_i34);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_tag_test_7_0));
	if (((Integer) MR_stackvar(4) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_gen__generate_tag_test_7_0_i36);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__unify_gen__generate_tag_test_7_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("checking that ", 14);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__unify_gen__generate_tag_test_7_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(5);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__unify_gen__generate_tag_test_7_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = (Word) MR_string_const(" has functor ", 13);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__unify_gen__generate_tag_test_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__unify_gen__generate_tag_test_7_0_i37,
		ENTRY(mercury__unify_gen__generate_tag_test_7_0));
	}
Define_label(mercury__unify_gen__generate_tag_test_7_0_i37);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_tag_test_7_0));
	r2 = MR_stackvar(9);
	tag_incr_hp_msg(MR_stackvar(9), MR_mktag(1), (Integer) 1, mercury__unify_gen__generate_tag_test_7_0, "tree:tree/1");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__unify_gen__generate_tag_test_7_0, "list:list/1");
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 2, mercury__unify_gen__generate_tag_test_7_0, "std_util:pair/2");
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__unify_gen__generate_tag_test_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r4, (Integer) 1) = (Word) MR_string_const("", 0);
	r1 = MR_stackvar(1);
	MR_field(MR_mktag(1), MR_stackvar(9), (Integer) 0) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(0), r4, (Integer) 0) = MR_tempr1;
	r3 = r2;
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__code_info__cons_id_to_tag_5_0),
		mercury__unify_gen__generate_tag_test_7_0_i38,
		ENTRY(mercury__unify_gen__generate_tag_test_7_0));
	}
Define_label(mercury__unify_gen__generate_tag_test_7_0_i38);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_tag_test_7_0));
	MR_stackvar(4) = r2;
	r2 = MR_stackvar(7);
	call_localret(STATIC(mercury__unify_gen__generate_tag_rval_2_3_0),
		mercury__unify_gen__generate_tag_test_7_0_i43,
		ENTRY(mercury__unify_gen__generate_tag_test_7_0));
Define_label(mercury__unify_gen__generate_tag_test_7_0_i36);
	r2 = MR_stackvar(4);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__unify_gen__generate_tag_test_7_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("checking that ", 14);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__unify_gen__generate_tag_test_7_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_stackvar(5);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__unify_gen__generate_tag_test_7_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = (Word) MR_string_const(" has functor ", 13);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__unify_gen__generate_tag_test_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 1) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_unify_gen__common_12);
	MR_field(MR_mktag(1), r2, (Integer) 0) = r3;
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__unify_gen__generate_tag_test_7_0_i40,
		ENTRY(mercury__unify_gen__generate_tag_test_7_0));
Define_label(mercury__unify_gen__generate_tag_test_7_0_i40);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_tag_test_7_0));
	r2 = MR_stackvar(9);
	tag_incr_hp_msg(MR_stackvar(9), MR_mktag(1), (Integer) 1, mercury__unify_gen__generate_tag_test_7_0, "tree:tree/1");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__unify_gen__generate_tag_test_7_0, "list:list/1");
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 2, mercury__unify_gen__generate_tag_test_7_0, "std_util:pair/2");
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__unify_gen__generate_tag_test_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r4, (Integer) 1) = (Word) MR_string_const("", 0);
	r1 = MR_stackvar(1);
	MR_field(MR_mktag(1), MR_stackvar(9), (Integer) 0) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(0), r4, (Integer) 0) = MR_tempr1;
	r3 = r2;
	r2 = MR_stackvar(4);
	call_localret(ENTRY(mercury__code_info__cons_id_to_tag_5_0),
		mercury__unify_gen__generate_tag_test_7_0_i41,
		ENTRY(mercury__unify_gen__generate_tag_test_7_0));
	}
Define_label(mercury__unify_gen__generate_tag_test_7_0_i41);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_tag_test_7_0));
	MR_stackvar(4) = r2;
	r2 = MR_stackvar(7);
	call_localret(STATIC(mercury__unify_gen__generate_tag_rval_2_3_0),
		mercury__unify_gen__generate_tag_test_7_0_i42,
		ENTRY(mercury__unify_gen__generate_tag_test_7_0));
Define_label(mercury__unify_gen__generate_tag_test_7_0_i42);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_tag_test_7_0));
	call_localret(ENTRY(mercury__code_util__neg_rval_2_0),
		mercury__unify_gen__generate_tag_test_7_0_i43,
		ENTRY(mercury__unify_gen__generate_tag_test_7_0));
Define_label(mercury__unify_gen__generate_tag_test_7_0_i43);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_tag_test_7_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	MR_stackvar(4) = r2;
	call_localret(ENTRY(mercury__code_info__get_next_label_3_0),
		mercury__unify_gen__generate_tag_test_7_0_i44,
		ENTRY(mercury__unify_gen__generate_tag_test_7_0));
Define_label(mercury__unify_gen__generate_tag_test_7_0_i44);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_tag_test_7_0));
	if (((Integer) MR_stackvar(3) != (Integer) 0))
		GOTO_LABEL(mercury__unify_gen__generate_tag_test_7_0_i46);
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 2, mercury__unify_gen__generate_tag_test_7_0, "tree:tree/1");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_stackvar(6);
	tag_incr_hp_msg(r4, MR_mktag(2), (Integer) 2, mercury__unify_gen__generate_tag_test_7_0, "tree:tree/1");
	MR_field(MR_mktag(2), r4, (Integer) 0) = MR_stackvar(9);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 1, mercury__unify_gen__generate_tag_test_7_0, "tree:tree/1");
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__unify_gen__generate_tag_test_7_0, "list:list/1");
	tag_incr_hp_msg(r7, MR_mktag(0), (Integer) 2, mercury__unify_gen__generate_tag_test_7_0, "std_util:pair/2");
	tag_incr_hp_msg(r8, MR_mktag(3), (Integer) 3, mercury__unify_gen__generate_tag_test_7_0, "llds:instr/0");
	MR_field(MR_mktag(3), r8, (Integer) 0) = (Integer) 8;
	MR_field(MR_mktag(3), r8, (Integer) 1) = MR_stackvar(4);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__unify_gen__generate_tag_test_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r8, (Integer) 2) = MR_tempr1;
	MR_field(MR_mktag(2), r2, (Integer) 1) = r4;
	MR_field(MR_mktag(2), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 0) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 0) = r7;
	MR_field(MR_mktag(1), r6, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r7, (Integer) 0) = r8;
	MR_field(MR_mktag(0), r7, (Integer) 1) = (Word) MR_string_const("tag test", 8);
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	proceed();
	}
Define_label(mercury__unify_gen__generate_tag_test_7_0_i46);
	r3 = r1;
	r1 = MR_stackvar(4);
	MR_stackvar(4) = r3;
	MR_stackvar(5) = r2;
	call_localret(ENTRY(mercury__code_util__neg_rval_2_0),
		mercury__unify_gen__generate_tag_test_7_0_i47,
		ENTRY(mercury__unify_gen__generate_tag_test_7_0));
Define_label(mercury__unify_gen__generate_tag_test_7_0_i47);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_tag_test_7_0));
	r3 = r1;
	r1 = MR_stackvar(4);
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 2, mercury__unify_gen__generate_tag_test_7_0, "tree:tree/1");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_stackvar(6);
	tag_incr_hp_msg(r4, MR_mktag(2), (Integer) 2, mercury__unify_gen__generate_tag_test_7_0, "tree:tree/1");
	MR_field(MR_mktag(2), r4, (Integer) 0) = MR_stackvar(9);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 1, mercury__unify_gen__generate_tag_test_7_0, "tree:tree/1");
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__unify_gen__generate_tag_test_7_0, "list:list/1");
	tag_incr_hp_msg(r7, MR_mktag(0), (Integer) 2, mercury__unify_gen__generate_tag_test_7_0, "std_util:pair/2");
	tag_incr_hp_msg(r8, MR_mktag(3), (Integer) 3, mercury__unify_gen__generate_tag_test_7_0, "llds:instr/0");
	MR_field(MR_mktag(3), r8, (Integer) 0) = (Integer) 8;
	MR_field(MR_mktag(3), r8, (Integer) 1) = r3;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__unify_gen__generate_tag_test_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r8, (Integer) 2) = MR_tempr1;
	r3 = MR_stackvar(5);
	MR_field(MR_mktag(2), r2, (Integer) 1) = r4;
	MR_field(MR_mktag(2), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 0) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 0) = r7;
	MR_field(MR_mktag(1), r6, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r1;
	MR_field(MR_mktag(0), r7, (Integer) 0) = r8;
	MR_field(MR_mktag(0), r7, (Integer) 1) = (Word) MR_string_const("tag test", 8);
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	proceed();
	}
END_MODULE

Declare_entry(mercury__code_info__fail_if_rval_is_false_4_0);

BEGIN_MODULE(unify_gen_module3)
	init_entry(mercury__unify_gen__generate_test_5_0);
	init_label(mercury__unify_gen__generate_test_5_0_i2);
	init_label(mercury__unify_gen__generate_test_5_0_i3);
	init_label(mercury__unify_gen__generate_test_5_0_i4);
	init_label(mercury__unify_gen__generate_test_5_0_i5);
	init_label(mercury__unify_gen__generate_test_5_0_i1021);
	init_label(mercury__unify_gen__generate_test_5_0_i17);
BEGIN_CODE

/* code for predicate 'generate_test'/5 in mode 0 */
Define_static(mercury__unify_gen__generate_test_5_0);
	MR_incr_sp_push_msg(4, "unify_gen:generate_test/5");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(2) = r2;
	r2 = r3;
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__code_info__produce_variable_5_0),
		mercury__unify_gen__generate_test_5_0_i2,
		STATIC(mercury__unify_gen__generate_test_5_0));
Define_label(mercury__unify_gen__generate_test_5_0_i2);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_test_5_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = MR_tempr1;
	MR_stackvar(3) = r2;
	r2 = r3;
	call_localret(ENTRY(mercury__code_info__produce_variable_5_0),
		mercury__unify_gen__generate_test_5_0_i3,
		STATIC(mercury__unify_gen__generate_test_5_0));
	}
Define_label(mercury__unify_gen__generate_test_5_0_i3);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_test_5_0));
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 2, mercury__unify_gen__generate_test_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = r1;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(2);
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = MR_tempr1;
	r2 = r3;
	call_localret(ENTRY(mercury__code_info__variable_type_4_0),
		mercury__unify_gen__generate_test_5_0_i4,
		STATIC(mercury__unify_gen__generate_test_5_0));
	}
Define_label(mercury__unify_gen__generate_test_5_0_i4);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_test_5_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__unify_gen__generate_test_5_0_i5);
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	if ((MR_tag(r3) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__unify_gen__generate_test_5_0_i5);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), r3, (Integer) 0), (char *)(Word) MR_string_const("string", 6)) != 0))
		GOTO_LABEL(mercury__unify_gen__generate_test_5_0_i5);
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_gen__generate_test_5_0_i5);
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__unify_gen__generate_test_5_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Integer) 15;
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_stackvar(3);
	MR_field(MR_mktag(3), r1, (Integer) 3) = MR_stackvar(1);
	call_localret(ENTRY(mercury__code_info__fail_if_rval_is_false_4_0),
		mercury__unify_gen__generate_test_5_0_i17,
		STATIC(mercury__unify_gen__generate_test_5_0));
Define_label(mercury__unify_gen__generate_test_5_0_i5);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__unify_gen__generate_test_5_0_i1021);
	if ((MR_tag(MR_const_field(MR_mktag(0), r1, (Integer) 0)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__unify_gen__generate_test_5_0_i1021);
	if ((strcmp((char *)MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), r1, (Integer) 0), (Integer) 0), (char *)(Word) MR_string_const("float", 5)) != 0))
		GOTO_LABEL(mercury__unify_gen__generate_test_5_0_i1021);
	if (((Integer) MR_const_field(MR_mktag(0), r1, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_gen__generate_test_5_0_i1021);
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__unify_gen__generate_test_5_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Integer) 29;
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_stackvar(3);
	MR_field(MR_mktag(3), r1, (Integer) 3) = MR_stackvar(1);
	call_localret(ENTRY(mercury__code_info__fail_if_rval_is_false_4_0),
		mercury__unify_gen__generate_test_5_0_i17,
		STATIC(mercury__unify_gen__generate_test_5_0));
Define_label(mercury__unify_gen__generate_test_5_0_i1021);
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__unify_gen__generate_test_5_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Integer) 12;
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_stackvar(3);
	MR_field(MR_mktag(3), r1, (Integer) 3) = MR_stackvar(1);
	call_localret(ENTRY(mercury__code_info__fail_if_rval_is_false_4_0),
		mercury__unify_gen__generate_test_5_0_i17,
		STATIC(mercury__unify_gen__generate_test_5_0));
Define_label(mercury__unify_gen__generate_test_5_0_i17);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_test_5_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 2, mercury__unify_gen__generate_test_5_0, "tree:tree/1");
	MR_field(MR_mktag(2), r1, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(2), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE


BEGIN_MODULE(unify_gen_module4)
	init_entry(mercury__unify_gen__generate_tag_rval_2_3_0);
	init_label(mercury__unify_gen__generate_tag_rval_2_3_0_i4);
	init_label(mercury__unify_gen__generate_tag_rval_2_3_0_i5);
	init_label(mercury__unify_gen__generate_tag_rval_2_3_0_i6);
	init_label(mercury__unify_gen__generate_tag_rval_2_3_0_i7);
	init_label(mercury__unify_gen__generate_tag_rval_2_3_0_i8);
	init_label(mercury__unify_gen__generate_tag_rval_2_3_0_i9);
	init_label(mercury__unify_gen__generate_tag_rval_2_3_0_i11);
	init_label(mercury__unify_gen__generate_tag_rval_2_3_0_i13);
	init_label(mercury__unify_gen__generate_tag_rval_2_3_0_i15);
	init_label(mercury__unify_gen__generate_tag_rval_2_3_0_i17);
	init_label(mercury__unify_gen__generate_tag_rval_2_3_0_i19);
	init_label(mercury__unify_gen__generate_tag_rval_2_3_0_i20);
	init_label(mercury__unify_gen__generate_tag_rval_2_3_0_i21);
BEGIN_CODE

/* code for predicate 'generate_tag_rval_2'/3 in mode 0 */
Define_static(mercury__unify_gen__generate_tag_rval_2_3_0);
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__unify_gen__generate_tag_rval_2_3_0_i4) AND
		LABEL(mercury__unify_gen__generate_tag_rval_2_3_0_i5) AND
		LABEL(mercury__unify_gen__generate_tag_rval_2_3_0_i6) AND
		LABEL(mercury__unify_gen__generate_tag_rval_2_3_0_i7));
Define_label(mercury__unify_gen__generate_tag_rval_2_3_0_i4);
	r1 = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_unify_gen__common_13);
	proceed();
Define_label(mercury__unify_gen__generate_tag_rval_2_3_0_i5);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__unify_gen__generate_tag_rval_2_3_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Integer) 15;
	MR_field(MR_mktag(3), r1, (Integer) 2) = r2;
	tag_incr_hp_msg(r4, MR_mktag(3), (Integer) 2, mercury__unify_gen__generate_tag_rval_2_3_0, "llds:rval/0");
	MR_field(MR_mktag(3), r4, (Integer) 0) = (Integer) 1;
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 2, mercury__unify_gen__generate_tag_rval_2_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r4, (Integer) 1) = r2;
	MR_field(MR_mktag(3), r2, (Integer) 1) = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_field(MR_mktag(3), r1, (Integer) 3) = r4;
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 0;
	proceed();
Define_label(mercury__unify_gen__generate_tag_rval_2_3_0_i6);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__unify_gen__generate_tag_rval_2_3_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Integer) 29;
	MR_field(MR_mktag(3), r1, (Integer) 2) = r2;
	tag_incr_hp_msg(r4, MR_mktag(3), (Integer) 2, mercury__unify_gen__generate_tag_rval_2_3_0, "llds:rval/0");
	MR_field(MR_mktag(3), r4, (Integer) 0) = (Integer) 1;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 1, mercury__unify_gen__generate_tag_rval_2_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r4, (Integer) 1) = r2;
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_const_field(MR_mktag(2), r3, (Integer) 0);
	MR_field(MR_mktag(3), r1, (Integer) 3) = r4;
	proceed();
Define_label(mercury__unify_gen__generate_tag_rval_2_3_0_i7);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__unify_gen__generate_tag_rval_2_3_0_i8) AND
		LABEL(mercury__unify_gen__generate_tag_rval_2_3_0_i9) AND
		LABEL(mercury__unify_gen__generate_tag_rval_2_3_0_i11) AND
		LABEL(mercury__unify_gen__generate_tag_rval_2_3_0_i13) AND
		LABEL(mercury__unify_gen__generate_tag_rval_2_3_0_i15) AND
		LABEL(mercury__unify_gen__generate_tag_rval_2_3_0_i17) AND
		LABEL(mercury__unify_gen__generate_tag_rval_2_3_0_i19) AND
		LABEL(mercury__unify_gen__generate_tag_rval_2_3_0_i20) AND
		LABEL(mercury__unify_gen__generate_tag_rval_2_3_0_i21));
Define_label(mercury__unify_gen__generate_tag_rval_2_3_0_i8);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__unify_gen__generate_tag_rval_2_3_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Integer) 12;
	MR_field(MR_mktag(3), r1, (Integer) 2) = r2;
	tag_incr_hp_msg(r4, MR_mktag(3), (Integer) 2, mercury__unify_gen__generate_tag_rval_2_3_0, "llds:rval/0");
	MR_field(MR_mktag(3), r4, (Integer) 0) = (Integer) 1;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__unify_gen__generate_tag_rval_2_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r4, (Integer) 1) = r2;
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_const_field(MR_mktag(3), r3, (Integer) 1);
	MR_field(MR_mktag(3), r1, (Integer) 3) = r4;
	proceed();
Define_label(mercury__unify_gen__generate_tag_rval_2_3_0_i9);
	r1 = (Word) MR_string_const("Attempted higher-order unification", 34);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__unify_gen__generate_tag_rval_2_3_0));
Define_label(mercury__unify_gen__generate_tag_rval_2_3_0_i11);
	r1 = (Word) MR_string_const("Attempted code_addr unification", 31);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__unify_gen__generate_tag_rval_2_3_0));
Define_label(mercury__unify_gen__generate_tag_rval_2_3_0_i13);
	r1 = (Word) MR_string_const("Attempted type_ctor_info unification", 36);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__unify_gen__generate_tag_rval_2_3_0));
Define_label(mercury__unify_gen__generate_tag_rval_2_3_0_i15);
	r1 = (Word) MR_string_const("Attempted base_typeclass_info unification", 41);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__unify_gen__generate_tag_rval_2_3_0));
Define_label(mercury__unify_gen__generate_tag_rval_2_3_0_i17);
	r1 = (Word) MR_string_const("Attempted tabling_pointer unification", 37);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__unify_gen__generate_tag_rval_2_3_0));
Define_label(mercury__unify_gen__generate_tag_rval_2_3_0_i19);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__unify_gen__generate_tag_rval_2_3_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Integer) 12;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 3, mercury__unify_gen__generate_tag_rval_2_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = r2;
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(r4, MR_mktag(3), (Integer) 3, mercury__unify_gen__generate_tag_rval_2_3_0, "llds:rval/0");
	MR_field(MR_mktag(3), r4, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r4, (Integer) 1) = (Integer) 0;
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 2, mercury__unify_gen__generate_tag_rval_2_3_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 1;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__unify_gen__generate_tag_rval_2_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r5, (Integer) 1) = r2;
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_const_field(MR_mktag(3), r3, (Integer) 1);
	MR_field(MR_mktag(3), r1, (Integer) 3) = r4;
	MR_field(MR_mktag(3), r4, (Integer) 2) = r5;
	proceed();
	}
Define_label(mercury__unify_gen__generate_tag_rval_2_3_0_i20);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__unify_gen__generate_tag_rval_2_3_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Integer) 10;
	tag_incr_hp_msg(r4, MR_mktag(3), (Integer) 4, mercury__unify_gen__generate_tag_rval_2_3_0, "llds:rval/0");
	MR_field(MR_mktag(3), r4, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r4, (Integer) 1) = (Integer) 12;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 3, mercury__unify_gen__generate_tag_rval_2_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = r2;
	MR_field(MR_mktag(3), r4, (Integer) 2) = MR_tempr1;
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 3, mercury__unify_gen__generate_tag_rval_2_3_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 0;
	tag_incr_hp_msg(r6, MR_mktag(3), (Integer) 2, mercury__unify_gen__generate_tag_rval_2_3_0, "llds:rval/0");
	MR_field(MR_mktag(3), r6, (Integer) 0) = (Integer) 1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__unify_gen__generate_tag_rval_2_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(3), r3, (Integer) 1);
	MR_field(MR_mktag(3), r1, (Integer) 2) = r4;
	MR_field(MR_mktag(3), r4, (Integer) 3) = r5;
	MR_field(MR_mktag(3), r5, (Integer) 2) = r6;
	MR_field(MR_mktag(3), r6, (Integer) 1) = MR_tempr1;
	tag_incr_hp_msg(r4, MR_mktag(3), (Integer) 4, mercury__unify_gen__generate_tag_rval_2_3_0, "llds:rval/0");
	MR_field(MR_mktag(3), r4, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r4, (Integer) 1) = (Integer) 12;
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 1, mercury__unify_gen__generate_tag_rval_2_3_0, "llds:rval/0");
	tag_incr_hp_msg(r6, MR_mktag(3), (Integer) 4, mercury__unify_gen__generate_tag_rval_2_3_0, "llds:lval/0");
	MR_field(MR_mktag(3), r6, (Integer) 0) = (Integer) 7;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__unify_gen__generate_tag_rval_2_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(3), r3, (Integer) 1);
	MR_field(MR_mktag(3), r6, (Integer) 3) = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_unify_gen__common_2);
	MR_field(MR_mktag(3), r6, (Integer) 2) = r2;
	MR_field(MR_mktag(3), r4, (Integer) 2) = r5;
	MR_field(MR_mktag(3), r6, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(0), r5, (Integer) 0) = r6;
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 2, mercury__unify_gen__generate_tag_rval_2_3_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 1;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__unify_gen__generate_tag_rval_2_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r5, (Integer) 1) = r2;
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_const_field(MR_mktag(3), r3, (Integer) 2);
	MR_field(MR_mktag(3), r1, (Integer) 3) = r4;
	MR_field(MR_mktag(3), r4, (Integer) 3) = r5;
	proceed();
	}
Define_label(mercury__unify_gen__generate_tag_rval_2_3_0_i21);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__unify_gen__generate_tag_rval_2_3_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Integer) 12;
	MR_field(MR_mktag(3), r1, (Integer) 2) = r2;
	tag_incr_hp_msg(r4, MR_mktag(3), (Integer) 3, mercury__unify_gen__generate_tag_rval_2_3_0, "llds:rval/0");
	MR_field(MR_mktag(3), r4, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(3), r4, (Integer) 1) = MR_const_field(MR_mktag(3), r3, (Integer) 1);
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 3, mercury__unify_gen__generate_tag_rval_2_3_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r5, (Integer) 1) = (Integer) 3;
	tag_incr_hp_msg(r6, MR_mktag(3), (Integer) 2, mercury__unify_gen__generate_tag_rval_2_3_0, "llds:rval/0");
	MR_field(MR_mktag(3), r6, (Integer) 0) = (Integer) 1;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__unify_gen__generate_tag_rval_2_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r6, (Integer) 1) = r2;
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_const_field(MR_mktag(3), r3, (Integer) 2);
	MR_field(MR_mktag(3), r1, (Integer) 3) = r4;
	MR_field(MR_mktag(3), r4, (Integer) 2) = r5;
	MR_field(MR_mktag(3), r5, (Integer) 2) = r6;
	proceed();
END_MODULE


BEGIN_MODULE(unify_gen_module5)
	init_entry(mercury__unify_gen__generate_extra_closure_args_6_0);
	init_label(mercury__unify_gen__generate_extra_closure_args_6_0_i4);
	init_label(mercury__unify_gen__generate_extra_closure_args_6_0_i5);
	init_label(mercury__unify_gen__generate_extra_closure_args_6_0_i3);
BEGIN_CODE

/* code for predicate 'generate_extra_closure_args'/6 in mode 0 */
Define_static(mercury__unify_gen__generate_extra_closure_args_6_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_gen__generate_extra_closure_args_6_0_i3);
	MR_incr_sp_push_msg(4, "unify_gen:generate_extra_closure_args/6");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r2;
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = r4;
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__code_info__produce_variable_5_0),
		mercury__unify_gen__generate_extra_closure_args_6_0_i4,
		STATIC(mercury__unify_gen__generate_extra_closure_args_6_0));
Define_label(mercury__unify_gen__generate_extra_closure_args_6_0_i4);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_extra_closure_args_6_0));
	r4 = MR_stackvar(1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 2, mercury__unify_gen__generate_extra_closure_args_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = r1;
	MR_stackvar(1) = MR_tempr1;
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 1, mercury__unify_gen__generate_extra_closure_args_6_0, "tree:tree/1");
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__unify_gen__generate_extra_closure_args_6_0, "list:list/1");
	tag_incr_hp_msg(r7, MR_mktag(0), (Integer) 2, mercury__unify_gen__generate_extra_closure_args_6_0, "std_util:pair/2");
	tag_incr_hp_msg(r8, MR_mktag(3), (Integer) 3, mercury__unify_gen__generate_extra_closure_args_6_0, "llds:instr/0");
	MR_field(MR_mktag(3), r8, (Integer) 0) = (Integer) 1;
	tag_incr_hp_msg(r9, MR_mktag(3), (Integer) 4, mercury__unify_gen__generate_extra_closure_args_6_0, "llds:lval/0");
	MR_field(MR_mktag(3), r9, (Integer) 0) = (Integer) 7;
	MR_field(MR_mktag(3), r9, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_unify_gen__common_1);
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 1, mercury__unify_gen__generate_extra_closure_args_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(3), r9, (Integer) 2) = MR_tempr1;
	MR_field(MR_mktag(3), r8, (Integer) 2) = r2;
	MR_field(MR_mktag(0), r7, (Integer) 1) = (Word) MR_string_const("set new argument field", 22);
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 1, mercury__unify_gen__generate_extra_closure_args_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r4;
	MR_field(MR_mktag(3), r8, (Integer) 1) = r9;
	MR_field(MR_mktag(3), r9, (Integer) 3) = MR_tempr1;
	MR_field(MR_mktag(1), r6, (Integer) 0) = r7;
	MR_field(MR_mktag(0), r7, (Integer) 0) = r8;
	tag_incr_hp_msg(r7, MR_mktag(1), (Integer) 2, mercury__unify_gen__generate_extra_closure_args_6_0, "list:list/1");
	tag_incr_hp_msg(r8, MR_mktag(0), (Integer) 2, mercury__unify_gen__generate_extra_closure_args_6_0, "std_util:pair/2");
	tag_incr_hp_msg(r9, MR_mktag(3), (Integer) 3, mercury__unify_gen__generate_extra_closure_args_6_0, "llds:instr/0");
	MR_field(MR_mktag(3), r9, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r9, (Integer) 1) = r4;
	tag_incr_hp_msg(r10, MR_mktag(3), (Integer) 4, mercury__unify_gen__generate_extra_closure_args_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r10, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r10, (Integer) 1) = (Integer) 0;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 1, mercury__unify_gen__generate_extra_closure_args_6_0, "origin_lost_in_value_number");
	r2 = r4;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r4;
	r4 = r3;
	MR_field(MR_mktag(3), r10, (Integer) 2) = MR_tempr1;
	r1 = MR_stackvar(3);
	r3 = MR_stackvar(2);
	MR_field(MR_mktag(3), r9, (Integer) 2) = r10;
	MR_field(MR_mktag(3), r10, (Integer) 3) = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_unify_gen__common_4);
	MR_field(MR_mktag(2), MR_stackvar(1), (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 0) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 1) = r7;
	MR_field(MR_mktag(1), r7, (Integer) 0) = r8;
	MR_field(MR_mktag(1), r7, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r8, (Integer) 0) = r9;
	MR_field(MR_mktag(0), r8, (Integer) 1) = (Word) MR_string_const("increment argument counter", 26);
	localcall(mercury__unify_gen__generate_extra_closure_args_6_0,
		LABEL(mercury__unify_gen__generate_extra_closure_args_6_0_i5),
		STATIC(mercury__unify_gen__generate_extra_closure_args_6_0));
	}
Define_label(mercury__unify_gen__generate_extra_closure_args_6_0_i5);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_extra_closure_args_6_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 2, mercury__unify_gen__generate_extra_closure_args_6_0, "tree:tree/1");
	MR_field(MR_mktag(2), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(2), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__unify_gen__generate_extra_closure_args_6_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = r4;
	proceed();
END_MODULE


BEGIN_MODULE(unify_gen_module6)
	init_entry(mercury__unify_gen__generate_pred_args_3_0);
	init_label(mercury__unify_gen__generate_pred_args_3_0_i3);
	init_label(mercury__unify_gen__generate_pred_args_3_0_i6);
	init_label(mercury__unify_gen__generate_pred_args_3_0_i9);
	init_label(mercury__unify_gen__generate_pred_args_3_0_i5);
BEGIN_CODE

/* code for predicate 'generate_pred_args'/3 in mode 0 */
Define_static(mercury__unify_gen__generate_pred_args_3_0);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_gen__generate_pred_args_3_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
Define_label(mercury__unify_gen__generate_pred_args_3_0_i3);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_gen__generate_pred_args_3_0_i5);
	MR_incr_sp_push_msg(2, "unify_gen:generate_pred_args/3");
	MR_stackvar(2) = (Word) MR_succip;
	r4 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	if (((Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r2, (Integer) 0), (Integer) 1) != (Integer) 0))
		GOTO_LABEL(mercury__unify_gen__generate_pred_args_3_0_i6);
	r2 = r4;
	tag_incr_hp_msg(MR_stackvar(1), MR_mktag(1), (Integer) 1, mercury__unify_gen__generate_pred_args_3_0, "origin_lost_in_value_number");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__unify_gen__generate_pred_args_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_stackvar(1), (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = r3;
	localcall(mercury__unify_gen__generate_pred_args_3_0,
		LABEL(mercury__unify_gen__generate_pred_args_3_0_i9),
		STATIC(mercury__unify_gen__generate_pred_args_3_0));
	}
Define_label(mercury__unify_gen__generate_pred_args_3_0_i6);
	r2 = r4;
	MR_stackvar(1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = r3;
	localcall(mercury__unify_gen__generate_pred_args_3_0,
		LABEL(mercury__unify_gen__generate_pred_args_3_0_i9),
		STATIC(mercury__unify_gen__generate_pred_args_3_0));
Define_label(mercury__unify_gen__generate_pred_args_3_0_i9);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_pred_args_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__unify_gen__generate_pred_args_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__unify_gen__generate_pred_args_3_0_i5);
	r1 = (Word) MR_string_const("unify_gen__generate_pred_args: insufficient args", 48);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__unify_gen__generate_pred_args_3_0));
END_MODULE


BEGIN_MODULE(unify_gen_module7)
	init_entry(mercury__unify_gen__generate_cons_args_5_0);
	init_label(mercury__unify_gen__generate_cons_args_5_0_i4);
	init_label(mercury__unify_gen__generate_cons_args_5_0_i3);
BEGIN_CODE

/* code for predicate 'generate_cons_args'/5 in mode 0 */
Define_static(mercury__unify_gen__generate_cons_args_5_0);
	MR_incr_sp_push_msg(1, "unify_gen:generate_cons_args/5");
	MR_stackvar(1) = (Word) MR_succip;
	call_localret(STATIC(mercury__unify_gen__generate_cons_args_2_5_0),
		mercury__unify_gen__generate_cons_args_5_0_i4,
		STATIC(mercury__unify_gen__generate_cons_args_5_0));
Define_label(mercury__unify_gen__generate_cons_args_5_0_i4);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_cons_args_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__unify_gen__generate_cons_args_5_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__unify_gen__generate_cons_args_5_0_i3);
	r1 = (Word) MR_string_const("unify_gen__generate_cons_args: length mismatch", 46);
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__unify_gen__generate_cons_args_5_0));
END_MODULE

Declare_entry(mercury__mode_util__mode_to_arg_mode_4_0);

BEGIN_MODULE(unify_gen_module8)
	init_entry(mercury__unify_gen__generate_cons_args_2_5_0);
	init_label(mercury__unify_gen__generate_cons_args_2_5_0_i3);
	init_label(mercury__unify_gen__generate_cons_args_2_5_0_i9);
	init_label(mercury__unify_gen__generate_cons_args_2_5_0_i8);
	init_label(mercury__unify_gen__generate_cons_args_2_5_0_i11);
	init_label(mercury__unify_gen__generate_cons_args_2_5_0_i1013);
	init_label(mercury__unify_gen__generate_cons_args_2_5_0_i1);
BEGIN_CODE

/* code for predicate 'generate_cons_args_2'/5 in mode 0 */
Define_static(mercury__unify_gen__generate_cons_args_2_5_0);
	MR_incr_sp_push_msg(6, "unify_gen:generate_cons_args_2/5");
	MR_stackvar(6) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_gen__generate_cons_args_2_5_0_i3);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_gen__generate_cons_args_2_5_0_i1013);
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_gen__generate_cons_args_2_5_0_i1013);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__unify_gen__generate_cons_args_2_5_0_i3);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_gen__generate_cons_args_2_5_0_i1);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_gen__generate_cons_args_2_5_0_i1);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	r3 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__unify_gen__generate_cons_args_2_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1), (Integer) 1);
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0), (Integer) 1);
	r1 = r4;
	MR_stackvar(1) = r4;
	call_localret(ENTRY(mercury__mode_util__mode_to_arg_mode_4_0),
		mercury__unify_gen__generate_cons_args_2_5_0_i9,
		STATIC(mercury__unify_gen__generate_cons_args_2_5_0));
	}
Define_label(mercury__unify_gen__generate_cons_args_2_5_0_i9);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_cons_args_2_5_0));
	if (((Integer) 0 != (Integer) r1))
		GOTO_LABEL(mercury__unify_gen__generate_cons_args_2_5_0_i8);
	r4 = MR_stackvar(1);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(5);
	r5 = MR_stackvar(2);
	tag_incr_hp_msg(MR_stackvar(2), MR_mktag(1), (Integer) 1, mercury__unify_gen__generate_cons_args_2_5_0, "std_util:maybe/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__unify_gen__generate_cons_args_2_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_stackvar(2), (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r5;
	localcall(mercury__unify_gen__generate_cons_args_2_5_0,
		LABEL(mercury__unify_gen__generate_cons_args_2_5_0_i11),
		STATIC(mercury__unify_gen__generate_cons_args_2_5_0));
	}
Define_label(mercury__unify_gen__generate_cons_args_2_5_0_i8);
	r4 = MR_stackvar(1);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(5);
	MR_stackvar(2) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	localcall(mercury__unify_gen__generate_cons_args_2_5_0,
		LABEL(mercury__unify_gen__generate_cons_args_2_5_0_i11),
		STATIC(mercury__unify_gen__generate_cons_args_2_5_0));
Define_label(mercury__unify_gen__generate_cons_args_2_5_0_i11);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_cons_args_2_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__unify_gen__generate_cons_args_2_5_0_i1);
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__unify_gen__generate_cons_args_2_5_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), r2, (Integer) 1) = r1;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__unify_gen__generate_cons_args_2_5_0_i1013);
	r1 = FALSE;
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__unify_gen__generate_cons_args_2_5_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE

Declare_entry(mercury__code_info__get_proc_info_3_0);
Declare_entry(mercury__hlds_pred__proc_info_vartypes_2_0);
Declare_entry(mercury__map__apply_to_list_3_0);

BEGIN_MODULE(unify_gen_module9)
	init_entry(mercury__unify_gen__var_types_4_0);
	init_label(mercury__unify_gen__var_types_4_0_i2);
	init_label(mercury__unify_gen__var_types_4_0_i3);
	init_label(mercury__unify_gen__var_types_4_0_i4);
BEGIN_CODE

/* code for predicate 'var_types'/4 in mode 0 */
Define_static(mercury__unify_gen__var_types_4_0);
	MR_incr_sp_push_msg(3, "unify_gen:var_types/4");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__code_info__get_proc_info_3_0),
		mercury__unify_gen__var_types_4_0_i2,
		STATIC(mercury__unify_gen__var_types_4_0));
Define_label(mercury__unify_gen__var_types_4_0_i2);
	update_prof_current_proc(LABEL(mercury__unify_gen__var_types_4_0));
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__hlds_pred__proc_info_vartypes_2_0),
		mercury__unify_gen__var_types_4_0_i3,
		STATIC(mercury__unify_gen__var_types_4_0));
Define_label(mercury__unify_gen__var_types_4_0_i3);
	update_prof_current_proc(LABEL(mercury__unify_gen__var_types_4_0));
	r4 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_gen__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_gen__common_14);
	r3 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__apply_to_list_3_0),
		mercury__unify_gen__var_types_4_0_i4,
		STATIC(mercury__unify_gen__var_types_4_0));
Define_label(mercury__unify_gen__var_types_4_0_i4);
	update_prof_current_proc(LABEL(mercury__unify_gen__var_types_4_0));
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(unify_gen_module10)
	init_entry(mercury__unify_gen__make_fields_and_argvars_6_0);
	init_label(mercury__unify_gen__make_fields_and_argvars_6_0_i4);
	init_label(mercury__unify_gen__make_fields_and_argvars_6_0_i5);
	init_label(mercury__unify_gen__make_fields_and_argvars_6_0_i2);
BEGIN_CODE

/* code for predicate 'make_fields_and_argvars'/6 in mode 0 */
Define_static(mercury__unify_gen__make_fields_and_argvars_6_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_gen__make_fields_and_argvars_6_0_i2);
	r8 = (Word) MR_sp;
Define_label(mercury__unify_gen__make_fields_and_argvars_6_0_i4);
	MR_incr_sp_push_msg(2, "unify_gen:make_fields_and_argvars");
	tag_incr_hp_msg(MR_stackvar(1), MR_mktag(1), (Integer) 1, mercury__unify_gen__make_fields_and_argvars_6_0, "unify_gen:uni_val/0");
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 4, mercury__unify_gen__make_fields_and_argvars_6_0, "llds:lval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 7;
	MR_field(MR_mktag(3), r5, (Integer) 2) = r2;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__unify_gen__make_fields_and_argvars_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r4;
	MR_field(MR_mktag(3), r5, (Integer) 1) = MR_tempr1;
	tag_incr_hp_msg(r6, MR_mktag(3), (Integer) 2, mercury__unify_gen__make_fields_and_argvars_6_0, "llds:rval/0");
	MR_field(MR_mktag(3), r6, (Integer) 0) = (Integer) 1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__unify_gen__make_fields_and_argvars_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r3;
	MR_field(MR_mktag(3), r5, (Integer) 3) = r6;
	MR_field(MR_mktag(3), r6, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), MR_stackvar(1), (Integer) 0) = r5;
	tag_incr_hp_msg(MR_stackvar(2), MR_mktag(0), (Integer) 1, mercury__unify_gen__make_fields_and_argvars_6_0, "unify_gen:uni_val/0");
	MR_field(MR_mktag(0), MR_stackvar(2), (Integer) 0) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r5 = r1;
	r1 = MR_const_field(MR_mktag(1), r5, (Integer) 1);
	r6 = r3;
	r3 = ((Integer) r6 + (Integer) 1);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_gen__make_fields_and_argvars_6_0_i4);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	}
Define_label(mercury__unify_gen__make_fields_and_argvars_6_0_i5);
	while (1) {
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__unify_gen__make_fields_and_argvars_6_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	r4 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__unify_gen__make_fields_and_argvars_6_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), r2, (Integer) 1) = r4;
	MR_decr_sp_pop_msg(2);
	if (((Integer) MR_sp > (Integer) r8))
		continue;
	proceed();
	break; } /* end while */
Define_label(mercury__unify_gen__make_fields_and_argvars_6_0_i2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE


BEGIN_MODULE(unify_gen_module11)
	init_entry(mercury__unify_gen__generate_det_deconstruction_7_0);
	init_label(mercury__unify_gen__generate_det_deconstruction_7_0_i2);
	init_label(mercury__unify_gen__generate_det_deconstruction_7_0_i5);
	init_label(mercury__unify_gen__generate_det_deconstruction_7_0_i11);
	init_label(mercury__unify_gen__generate_det_deconstruction_7_0_i6);
	init_label(mercury__unify_gen__generate_det_deconstruction_7_0_i17);
	init_label(mercury__unify_gen__generate_det_deconstruction_7_0_i24);
	init_label(mercury__unify_gen__generate_det_deconstruction_7_0_i25);
	init_label(mercury__unify_gen__generate_det_deconstruction_7_0_i26);
	init_label(mercury__unify_gen__generate_det_deconstruction_7_0_i27);
	init_label(mercury__unify_gen__generate_det_deconstruction_7_0_i28);
	init_label(mercury__unify_gen__generate_det_deconstruction_7_0_i30);
	init_label(mercury__unify_gen__generate_det_deconstruction_7_0_i31);
	init_label(mercury__unify_gen__generate_det_deconstruction_7_0_i32);
	init_label(mercury__unify_gen__generate_det_deconstruction_7_0_i33);
	init_label(mercury__unify_gen__generate_det_deconstruction_7_0_i34);
	init_label(mercury__unify_gen__generate_det_deconstruction_7_0_i37);
	init_label(mercury__unify_gen__generate_det_deconstruction_7_0_i36);
	init_label(mercury__unify_gen__generate_det_deconstruction_7_0_i41);
BEGIN_CODE

/* code for predicate 'generate_det_deconstruction'/7 in mode 0 */
Define_static(mercury__unify_gen__generate_det_deconstruction_7_0);
	MR_incr_sp_push_msg(6, "unify_gen:generate_det_deconstruction/7");
	MR_stackvar(6) = (Word) MR_succip;
	MR_stackvar(2) = r3;
	r3 = r5;
	MR_stackvar(1) = r1;
	MR_stackvar(3) = r4;
	call_localret(ENTRY(mercury__code_info__cons_id_to_tag_5_0),
		mercury__unify_gen__generate_det_deconstruction_7_0_i2,
		STATIC(mercury__unify_gen__generate_det_deconstruction_7_0));
Define_label(mercury__unify_gen__generate_det_deconstruction_7_0_i2);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_det_deconstruction_7_0));
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__unify_gen__generate_det_deconstruction_7_0_i5) AND
		LABEL(mercury__unify_gen__generate_det_deconstruction_7_0_i41) AND
		LABEL(mercury__unify_gen__generate_det_deconstruction_7_0_i41) AND
		LABEL(mercury__unify_gen__generate_det_deconstruction_7_0_i17));
Define_label(mercury__unify_gen__generate_det_deconstruction_7_0_i5);
	r3 = MR_stackvar(2);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_gen__generate_det_deconstruction_7_0_i6);
	if (((Integer) MR_const_field(MR_mktag(1), r3, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_gen__generate_det_deconstruction_7_0_i6);
	{
	Word MR_tempr1, MR_tempr2;
	MR_tempr2 = MR_stackvar(3);
	if (((Integer) MR_tempr2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_gen__generate_det_deconstruction_7_0_i6);
	if (((Integer) MR_const_field(MR_mktag(1), MR_tempr2, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_gen__generate_det_deconstruction_7_0_i6);
	r1 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), MR_tempr2, (Integer) 0);
	MR_stackvar(2) = r1;
	call_localret(ENTRY(mercury__code_info__variable_type_4_0),
		mercury__unify_gen__generate_det_deconstruction_7_0_i11,
		STATIC(mercury__unify_gen__generate_det_deconstruction_7_0));
	}
Define_label(mercury__unify_gen__generate_det_deconstruction_7_0_i11);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_det_deconstruction_7_0));
	r3 = r1;
	r5 = r2;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 1, mercury__unify_gen__generate_det_deconstruction_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 1, mercury__unify_gen__generate_det_deconstruction_7_0, "origin_lost_in_value_number");
	r4 = r3;
	r3 = MR_stackvar(3);
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(STATIC(mercury__unify_gen__generate_sub_unify_7_0),
		STATIC(mercury__unify_gen__generate_det_deconstruction_7_0));
Define_label(mercury__unify_gen__generate_det_deconstruction_7_0_i6);
	r1 = (Word) MR_string_const("unify_gen__generate_det_deconstruction: no_tag: arity != 1", 58);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__unify_gen__generate_det_deconstruction_7_0));
Define_label(mercury__unify_gen__generate_det_deconstruction_7_0_i17);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__unify_gen__generate_det_deconstruction_7_0_i41) AND
		LABEL(mercury__unify_gen__generate_det_deconstruction_7_0_i41) AND
		LABEL(mercury__unify_gen__generate_det_deconstruction_7_0_i41) AND
		LABEL(mercury__unify_gen__generate_det_deconstruction_7_0_i41) AND
		LABEL(mercury__unify_gen__generate_det_deconstruction_7_0_i41) AND
		LABEL(mercury__unify_gen__generate_det_deconstruction_7_0_i41) AND
		LABEL(mercury__unify_gen__generate_det_deconstruction_7_0_i24) AND
		LABEL(mercury__unify_gen__generate_det_deconstruction_7_0_i30) AND
		LABEL(mercury__unify_gen__generate_det_deconstruction_7_0_i41));
Define_label(mercury__unify_gen__generate_det_deconstruction_7_0_i24);
	r3 = MR_stackvar(1);
	r4 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(1) = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__unify_gen__generate_det_deconstruction_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r2, (Integer) 0) = r3;
	r4 = MR_const_field(MR_mktag(3), r4, (Integer) 1);
	r3 = (Integer) 0;
	call_localret(STATIC(mercury__unify_gen__make_fields_and_argvars_6_0),
		mercury__unify_gen__generate_det_deconstruction_7_0_i25,
		STATIC(mercury__unify_gen__generate_det_deconstruction_7_0));
Define_label(mercury__unify_gen__generate_det_deconstruction_7_0_i25);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_det_deconstruction_7_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	MR_stackvar(4) = r2;
	call_localret(ENTRY(mercury__code_info__get_proc_info_3_0),
		mercury__unify_gen__generate_det_deconstruction_7_0_i26,
		STATIC(mercury__unify_gen__generate_det_deconstruction_7_0));
Define_label(mercury__unify_gen__generate_det_deconstruction_7_0_i26);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_det_deconstruction_7_0));
	MR_stackvar(5) = r2;
	call_localret(ENTRY(mercury__hlds_pred__proc_info_vartypes_2_0),
		mercury__unify_gen__generate_det_deconstruction_7_0_i27,
		STATIC(mercury__unify_gen__generate_det_deconstruction_7_0));
Define_label(mercury__unify_gen__generate_det_deconstruction_7_0_i27);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_det_deconstruction_7_0));
	r4 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_gen__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_gen__common_14);
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__apply_to_list_3_0),
		mercury__unify_gen__generate_det_deconstruction_7_0_i28,
		STATIC(mercury__unify_gen__generate_det_deconstruction_7_0));
Define_label(mercury__unify_gen__generate_det_deconstruction_7_0_i28);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_det_deconstruction_7_0));
	r4 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(3);
	r5 = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(STATIC(mercury__unify_gen__generate_unify_args_7_0),
		STATIC(mercury__unify_gen__generate_det_deconstruction_7_0));
Define_label(mercury__unify_gen__generate_det_deconstruction_7_0_i30);
	r3 = MR_stackvar(1);
	r4 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(1) = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__unify_gen__generate_det_deconstruction_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r2, (Integer) 0) = r3;
	r4 = MR_const_field(MR_mktag(3), r4, (Integer) 1);
	r3 = (Integer) 1;
	call_localret(STATIC(mercury__unify_gen__make_fields_and_argvars_6_0),
		mercury__unify_gen__generate_det_deconstruction_7_0_i31,
		STATIC(mercury__unify_gen__generate_det_deconstruction_7_0));
Define_label(mercury__unify_gen__generate_det_deconstruction_7_0_i31);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_det_deconstruction_7_0));
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(5) = r2;
	call_localret(ENTRY(mercury__code_info__get_proc_info_3_0),
		mercury__unify_gen__generate_det_deconstruction_7_0_i32,
		STATIC(mercury__unify_gen__generate_det_deconstruction_7_0));
Define_label(mercury__unify_gen__generate_det_deconstruction_7_0_i32);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_det_deconstruction_7_0));
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__hlds_pred__proc_info_vartypes_2_0),
		mercury__unify_gen__generate_det_deconstruction_7_0_i33,
		STATIC(mercury__unify_gen__generate_det_deconstruction_7_0));
Define_label(mercury__unify_gen__generate_det_deconstruction_7_0_i33);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_det_deconstruction_7_0));
	r4 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_gen__common_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_gen__common_14);
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__apply_to_list_3_0),
		mercury__unify_gen__generate_det_deconstruction_7_0_i34,
		STATIC(mercury__unify_gen__generate_det_deconstruction_7_0));
Define_label(mercury__unify_gen__generate_det_deconstruction_7_0_i34);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_det_deconstruction_7_0));
	r4 = r1;
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(3);
	r5 = MR_stackvar(1);
	call_localret(STATIC(mercury__unify_gen__generate_unify_args_2_7_0),
		mercury__unify_gen__generate_det_deconstruction_7_0_i37,
		STATIC(mercury__unify_gen__generate_det_deconstruction_7_0));
Define_label(mercury__unify_gen__generate_det_deconstruction_7_0_i37);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_det_deconstruction_7_0));
	if (!(r1))
		GOTO_LABEL(mercury__unify_gen__generate_det_deconstruction_7_0_i36);
	r1 = r2;
	r2 = r3;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__unify_gen__generate_det_deconstruction_7_0_i36);
	r1 = (Word) MR_string_const("unify_gen__generate_unify_args: length mismatch", 47);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__unify_gen__generate_det_deconstruction_7_0));
Define_label(mercury__unify_gen__generate_det_deconstruction_7_0_i41);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE


BEGIN_MODULE(unify_gen_module12)
	init_entry(mercury__unify_gen__generate_unify_args_7_0);
	init_label(mercury__unify_gen__generate_unify_args_7_0_i4);
	init_label(mercury__unify_gen__generate_unify_args_7_0_i3);
BEGIN_CODE

/* code for predicate 'generate_unify_args'/7 in mode 0 */
Define_static(mercury__unify_gen__generate_unify_args_7_0);
	MR_incr_sp_push_msg(1, "unify_gen:generate_unify_args/7");
	MR_stackvar(1) = (Word) MR_succip;
	call_localret(STATIC(mercury__unify_gen__generate_unify_args_2_7_0),
		mercury__unify_gen__generate_unify_args_7_0_i4,
		STATIC(mercury__unify_gen__generate_unify_args_7_0));
Define_label(mercury__unify_gen__generate_unify_args_7_0_i4);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_unify_args_7_0));
	if (!(r1))
		GOTO_LABEL(mercury__unify_gen__generate_unify_args_7_0_i3);
	r1 = r2;
	r2 = r3;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__unify_gen__generate_unify_args_7_0_i3);
	r1 = (Word) MR_string_const("unify_gen__generate_unify_args: length mismatch", 47);
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__unify_gen__generate_unify_args_7_0));
END_MODULE


BEGIN_MODULE(unify_gen_module13)
	init_entry(mercury__unify_gen__generate_unify_args_2_7_0);
	init_label(mercury__unify_gen__generate_unify_args_2_7_0_i3);
	init_label(mercury__unify_gen__generate_unify_args_2_7_0_i10);
	init_label(mercury__unify_gen__generate_unify_args_2_7_0_i11);
	init_label(mercury__unify_gen__generate_unify_args_2_7_0_i1012);
	init_label(mercury__unify_gen__generate_unify_args_2_7_0_i1);
BEGIN_CODE

/* code for predicate 'generate_unify_args_2'/7 in mode 0 */
Define_static(mercury__unify_gen__generate_unify_args_2_7_0);
	MR_incr_sp_push_msg(5, "unify_gen:generate_unify_args_2/7");
	MR_stackvar(5) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_gen__generate_unify_args_2_7_0_i3);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_gen__generate_unify_args_2_7_0_i1012);
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_gen__generate_unify_args_2_7_0_i1012);
	if (((Integer) r4 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_gen__generate_unify_args_2_7_0_i1012);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r3 = r5;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__unify_gen__generate_unify_args_2_7_0_i3);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_gen__generate_unify_args_2_7_0_i1);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_gen__generate_unify_args_2_7_0_i1);
	if (((Integer) r4 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_gen__generate_unify_args_2_7_0_i1);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r4, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r4 = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	r3 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	call_localret(STATIC(mercury__unify_gen__generate_sub_unify_7_0),
		mercury__unify_gen__generate_unify_args_2_7_0_i10,
		STATIC(mercury__unify_gen__generate_unify_args_2_7_0));
Define_label(mercury__unify_gen__generate_unify_args_2_7_0_i10);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_unify_args_2_7_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	r5 = r2;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	localcall(mercury__unify_gen__generate_unify_args_2_7_0,
		LABEL(mercury__unify_gen__generate_unify_args_2_7_0_i11),
		STATIC(mercury__unify_gen__generate_unify_args_2_7_0));
	}
Define_label(mercury__unify_gen__generate_unify_args_2_7_0_i11);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_unify_args_2_7_0));
	if (!(r1))
		GOTO_LABEL(mercury__unify_gen__generate_unify_args_2_7_0_i1);
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 2, mercury__unify_gen__generate_unify_args_2_7_0, "tree:tree/1");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(2), r2, (Integer) 1) = r1;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__unify_gen__generate_unify_args_2_7_0_i1012);
	r1 = FALSE;
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__unify_gen__generate_unify_args_2_7_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE

Declare_entry(mercury__code_info__materialize_vars_in_rval_5_0);

BEGIN_MODULE(unify_gen_module14)
	init_entry(mercury__unify_gen__generate_sub_unify_7_0);
	init_label(mercury__unify_gen__generate_sub_unify_7_0_i2);
	init_label(mercury__unify_gen__generate_sub_unify_7_0_i3);
	init_label(mercury__unify_gen__generate_sub_unify_7_0_i4);
	init_label(mercury__unify_gen__generate_sub_unify_7_0_i5);
	init_label(mercury__unify_gen__generate_sub_unify_7_0_i18);
	init_label(mercury__unify_gen__generate_sub_unify_7_0_i20);
	init_label(mercury__unify_gen__generate_sub_unify_7_0_i17);
	init_label(mercury__unify_gen__generate_sub_unify_7_0_i21);
	init_label(mercury__unify_gen__generate_sub_unify_7_0_i15);
	init_label(mercury__unify_gen__generate_sub_unify_7_0_i24);
	init_label(mercury__unify_gen__generate_sub_unify_7_0_i26);
	init_label(mercury__unify_gen__generate_sub_unify_7_0_i23);
	init_label(mercury__unify_gen__generate_sub_unify_7_0_i27);
	init_label(mercury__unify_gen__generate_sub_unify_7_0_i13);
	init_label(mercury__unify_gen__generate_sub_unify_7_0_i30);
	init_label(mercury__unify_gen__generate_sub_unify_7_0_i31);
	init_label(mercury__unify_gen__generate_sub_unify_7_0_i32);
	init_label(mercury__unify_gen__generate_sub_unify_7_0_i29);
	init_label(mercury__unify_gen__generate_sub_unify_7_0_i36);
	init_label(mercury__unify_gen__generate_sub_unify_7_0_i37);
	init_label(mercury__unify_gen__generate_sub_unify_7_0_i9);
	init_label(mercury__unify_gen__generate_sub_unify_7_0_i41);
	init_label(mercury__unify_gen__generate_sub_unify_7_0_i45);
	init_label(mercury__unify_gen__generate_sub_unify_7_0_i48);
BEGIN_CODE

/* code for predicate 'generate_sub_unify'/7 in mode 0 */
Define_static(mercury__unify_gen__generate_sub_unify_7_0);
	MR_incr_sp_push_msg(8, "unify_gen:generate_sub_unify/7");
	MR_stackvar(8) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	{
	Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_tempr2 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 0);
	r1 = r5;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r4;
	call_localret(ENTRY(mercury__code_info__get_module_info_3_0),
		mercury__unify_gen__generate_sub_unify_7_0_i2,
		STATIC(mercury__unify_gen__generate_sub_unify_7_0));
	}
Define_label(mercury__unify_gen__generate_sub_unify_7_0_i2);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_sub_unify_7_0));
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__unify_gen__generate_sub_unify_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = MR_stackvar(6);
	MR_stackvar(6) = r2;
	r2 = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(4);
	r3 = MR_stackvar(3);
	MR_stackvar(4) = r1;
	call_localret(ENTRY(mercury__mode_util__mode_to_arg_mode_4_0),
		mercury__unify_gen__generate_sub_unify_7_0_i3,
		STATIC(mercury__unify_gen__generate_sub_unify_7_0));
	}
Define_label(mercury__unify_gen__generate_sub_unify_7_0_i3);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_sub_unify_7_0));
	r4 = MR_stackvar(3);
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(4);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__unify_gen__generate_sub_unify_7_0, "origin_lost_in_value_number");
	r3 = r4;
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_stackvar(7);
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(5);
	call_localret(ENTRY(mercury__mode_util__mode_to_arg_mode_4_0),
		mercury__unify_gen__generate_sub_unify_7_0_i4,
		STATIC(mercury__unify_gen__generate_sub_unify_7_0));
Define_label(mercury__unify_gen__generate_sub_unify_7_0_i4);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_sub_unify_7_0));
	if (((Integer) MR_stackvar(3) != (Integer) 0))
		GOTO_LABEL(mercury__unify_gen__generate_sub_unify_7_0_i5);
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__unify_gen__generate_sub_unify_7_0_i5);
	r1 = (Word) MR_string_const("test in arg of [de]construction", 31);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__unify_gen__generate_sub_unify_7_0_i48,
		STATIC(mercury__unify_gen__generate_sub_unify_7_0));
Define_label(mercury__unify_gen__generate_sub_unify_7_0_i5);
	if (((Integer) MR_stackvar(3) != (Integer) 0))
		GOTO_LABEL(mercury__unify_gen__generate_sub_unify_7_0_i9);
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__unify_gen__generate_sub_unify_7_0_i9);
	if ((MR_tag(MR_stackvar(2)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__unify_gen__generate_sub_unify_7_0_i13);
	if ((MR_tag(MR_stackvar(1)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__unify_gen__generate_sub_unify_7_0_i15);
	r1 = MR_const_field(MR_mktag(0), MR_stackvar(2), (Integer) 0);
	MR_stackvar(2) = r1;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), MR_stackvar(1), (Integer) 0);
	r2 = MR_stackvar(6);
	call_localret(ENTRY(mercury__code_info__variable_is_forward_live_3_0),
		mercury__unify_gen__generate_sub_unify_7_0_i18,
		STATIC(mercury__unify_gen__generate_sub_unify_7_0));
Define_label(mercury__unify_gen__generate_sub_unify_7_0_i18);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_sub_unify_7_0));
	if (!(r1))
		GOTO_LABEL(mercury__unify_gen__generate_sub_unify_7_0_i17);
	r1 = MR_stackvar(2);
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__unify_gen__generate_sub_unify_7_0, "llds:rval/0");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(1);
	call_localret(ENTRY(mercury__code_info__cache_expression_4_0),
		mercury__unify_gen__generate_sub_unify_7_0_i20,
		STATIC(mercury__unify_gen__generate_sub_unify_7_0));
Define_label(mercury__unify_gen__generate_sub_unify_7_0_i20);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_sub_unify_7_0));
	r2 = r1;
	GOTO_LABEL(mercury__unify_gen__generate_sub_unify_7_0_i21);
Define_label(mercury__unify_gen__generate_sub_unify_7_0_i17);
	r2 = MR_stackvar(6);
Define_label(mercury__unify_gen__generate_sub_unify_7_0_i21);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__unify_gen__generate_sub_unify_7_0_i15);
	r1 = MR_const_field(MR_mktag(0), MR_stackvar(2), (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_stackvar(1), (Integer) 0);
	MR_stackvar(2) = r1;
	r2 = MR_stackvar(6);
	call_localret(ENTRY(mercury__code_info__variable_is_forward_live_3_0),
		mercury__unify_gen__generate_sub_unify_7_0_i24,
		STATIC(mercury__unify_gen__generate_sub_unify_7_0));
Define_label(mercury__unify_gen__generate_sub_unify_7_0_i24);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_sub_unify_7_0));
	if (!(r1))
		GOTO_LABEL(mercury__unify_gen__generate_sub_unify_7_0_i23);
	r1 = MR_stackvar(2);
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 1, mercury__unify_gen__generate_sub_unify_7_0, "llds:rval/0");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(1);
	call_localret(ENTRY(mercury__code_info__cache_expression_4_0),
		mercury__unify_gen__generate_sub_unify_7_0_i26,
		STATIC(mercury__unify_gen__generate_sub_unify_7_0));
Define_label(mercury__unify_gen__generate_sub_unify_7_0_i26);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_sub_unify_7_0));
	r2 = r1;
	GOTO_LABEL(mercury__unify_gen__generate_sub_unify_7_0_i27);
Define_label(mercury__unify_gen__generate_sub_unify_7_0_i23);
	r2 = MR_stackvar(6);
Define_label(mercury__unify_gen__generate_sub_unify_7_0_i27);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__unify_gen__generate_sub_unify_7_0_i13);
	if ((MR_tag(MR_stackvar(1)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__unify_gen__generate_sub_unify_7_0_i29);
	r1 = MR_const_field(MR_mktag(0), MR_stackvar(1), (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), MR_stackvar(2), (Integer) 0);
	r2 = MR_stackvar(6);
	call_localret(ENTRY(mercury__code_info__produce_variable_5_0),
		mercury__unify_gen__generate_sub_unify_7_0_i30,
		STATIC(mercury__unify_gen__generate_sub_unify_7_0));
Define_label(mercury__unify_gen__generate_sub_unify_7_0_i30);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_sub_unify_7_0));
	r4 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 1, mercury__unify_gen__generate_sub_unify_7_0, "origin_lost_in_value_number");
	r2 = r3;
	MR_field(MR_mktag(0), r1, (Integer) 0) = r4;
	call_localret(ENTRY(mercury__code_info__materialize_vars_in_rval_5_0),
		mercury__unify_gen__generate_sub_unify_7_0_i31,
		STATIC(mercury__unify_gen__generate_sub_unify_7_0));
Define_label(mercury__unify_gen__generate_sub_unify_7_0_i31);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_sub_unify_7_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__unify_gen__generate_sub_unify_7_0_i32);
	r4 = r1;
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 2, mercury__unify_gen__generate_sub_unify_7_0, "tree:tree/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 2, mercury__unify_gen__generate_sub_unify_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = r2;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(2), r1, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 1, mercury__unify_gen__generate_sub_unify_7_0, "tree:tree/1");
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__unify_gen__generate_sub_unify_7_0, "list:list/1");
	tag_incr_hp_msg(r7, MR_mktag(0), (Integer) 2, mercury__unify_gen__generate_sub_unify_7_0, "std_util:pair/2");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 3, mercury__unify_gen__generate_sub_unify_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r7, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_const_field(MR_mktag(0), r4, (Integer) 0);
	r2 = r3;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(2), r1, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 0) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 0) = r7;
	MR_field(MR_mktag(1), r6, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r7, (Integer) 1) = (Word) MR_string_const("Copy value", 10);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
	}
Define_label(mercury__unify_gen__generate_sub_unify_7_0_i32);
	MR_stackvar(1) = r3;
	r1 = (Word) MR_string_const("unify_gen__generate_sub_assign: lval vanished with ref", 54);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__unify_gen__generate_sub_unify_7_0_i48,
		STATIC(mercury__unify_gen__generate_sub_unify_7_0));
Define_label(mercury__unify_gen__generate_sub_unify_7_0_i29);
	r2 = MR_stackvar(1);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 1, mercury__unify_gen__generate_sub_unify_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_stackvar(2), (Integer) 0);
	r2 = MR_stackvar(6);
	call_localret(ENTRY(mercury__code_info__materialize_vars_in_rval_5_0),
		mercury__unify_gen__generate_sub_unify_7_0_i36,
		STATIC(mercury__unify_gen__generate_sub_unify_7_0));
Define_label(mercury__unify_gen__generate_sub_unify_7_0_i36);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_sub_unify_7_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__unify_gen__generate_sub_unify_7_0_i37);
	r4 = r1;
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 2, mercury__unify_gen__generate_sub_unify_7_0, "tree:tree/1");
	MR_field(MR_mktag(2), r1, (Integer) 0) = r2;
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 1, mercury__unify_gen__generate_sub_unify_7_0, "tree:tree/1");
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__unify_gen__generate_sub_unify_7_0, "list:list/1");
	tag_incr_hp_msg(r7, MR_mktag(0), (Integer) 2, mercury__unify_gen__generate_sub_unify_7_0, "std_util:pair/2");
	tag_incr_hp_msg(r8, MR_mktag(3), (Integer) 3, mercury__unify_gen__generate_sub_unify_7_0, "llds:instr/0");
	MR_field(MR_mktag(3), r8, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r8, (Integer) 1) = MR_const_field(MR_mktag(0), r4, (Integer) 0);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 1, mercury__unify_gen__generate_sub_unify_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r8, (Integer) 2) = MR_tempr1;
	r2 = r3;
	MR_field(MR_mktag(2), r1, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 0) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 0) = r7;
	MR_field(MR_mktag(1), r6, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r7, (Integer) 0) = r8;
	MR_field(MR_mktag(0), r7, (Integer) 1) = (Word) MR_string_const("Copy field", 10);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
	}
Define_label(mercury__unify_gen__generate_sub_unify_7_0_i37);
	MR_stackvar(1) = r3;
	r1 = (Word) MR_string_const("unify_gen__generate_sub_assign: lval vanished with lval", 55);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__unify_gen__generate_sub_unify_7_0_i48,
		STATIC(mercury__unify_gen__generate_sub_unify_7_0));
Define_label(mercury__unify_gen__generate_sub_unify_7_0_i9);
	if (((Integer) MR_stackvar(3) != (Integer) 1))
		GOTO_LABEL(mercury__unify_gen__generate_sub_unify_7_0_i41);
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__unify_gen__generate_sub_unify_7_0_i41);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	tailcall(STATIC(mercury__unify_gen__generate_sub_assign_5_0),
		STATIC(mercury__unify_gen__generate_sub_unify_7_0));
Define_label(mercury__unify_gen__generate_sub_unify_7_0_i41);
	if (((Integer) MR_stackvar(3) != (Integer) 2))
		GOTO_LABEL(mercury__unify_gen__generate_sub_unify_7_0_i45);
	if (((Integer) r1 != (Integer) 2))
		GOTO_LABEL(mercury__unify_gen__generate_sub_unify_7_0_i45);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__unify_gen__generate_sub_unify_7_0_i45);
	r1 = (Word) MR_string_const("unify_gen__generate_sub_unify: some strange unify", 49);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__unify_gen__generate_sub_unify_7_0_i48,
		STATIC(mercury__unify_gen__generate_sub_unify_7_0));
Define_label(mercury__unify_gen__generate_sub_unify_7_0_i48);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_sub_unify_7_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
END_MODULE


BEGIN_MODULE(unify_gen_module15)
	init_entry(mercury__unify_gen__generate_sub_assign_5_0);
	init_label(mercury__unify_gen__generate_sub_assign_5_0_i8);
	init_label(mercury__unify_gen__generate_sub_assign_5_0_i10);
	init_label(mercury__unify_gen__generate_sub_assign_5_0_i6);
	init_label(mercury__unify_gen__generate_sub_assign_5_0_i11);
	init_label(mercury__unify_gen__generate_sub_assign_5_0_i5);
	init_label(mercury__unify_gen__generate_sub_assign_5_0_i14);
	init_label(mercury__unify_gen__generate_sub_assign_5_0_i16);
	init_label(mercury__unify_gen__generate_sub_assign_5_0_i12);
	init_label(mercury__unify_gen__generate_sub_assign_5_0_i17);
	init_label(mercury__unify_gen__generate_sub_assign_5_0_i3);
	init_label(mercury__unify_gen__generate_sub_assign_5_0_i20);
	init_label(mercury__unify_gen__generate_sub_assign_5_0_i21);
	init_label(mercury__unify_gen__generate_sub_assign_5_0_i22);
	init_label(mercury__unify_gen__generate_sub_assign_5_0_i19);
	init_label(mercury__unify_gen__generate_sub_assign_5_0_i26);
	init_label(mercury__unify_gen__generate_sub_assign_5_0_i27);
	init_label(mercury__unify_gen__generate_sub_assign_5_0_i29);
BEGIN_CODE

/* code for predicate 'generate_sub_assign'/5 in mode 0 */
Define_static(mercury__unify_gen__generate_sub_assign_5_0);
	MR_incr_sp_push_msg(4, "unify_gen:generate_sub_assign/5");
	MR_stackvar(4) = (Word) MR_succip;
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__unify_gen__generate_sub_assign_5_0_i3);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__unify_gen__generate_sub_assign_5_0_i5);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(3) = r1;
	r2 = r3;
	MR_stackvar(1) = r3;
	call_localret(ENTRY(mercury__code_info__variable_is_forward_live_3_0),
		mercury__unify_gen__generate_sub_assign_5_0_i8,
		STATIC(mercury__unify_gen__generate_sub_assign_5_0));
Define_label(mercury__unify_gen__generate_sub_assign_5_0_i8);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_sub_assign_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__unify_gen__generate_sub_assign_5_0_i6);
	r1 = MR_stackvar(3);
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__unify_gen__generate_sub_assign_5_0, "llds:rval/0");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(2);
	call_localret(ENTRY(mercury__code_info__cache_expression_4_0),
		mercury__unify_gen__generate_sub_assign_5_0_i10,
		STATIC(mercury__unify_gen__generate_sub_assign_5_0));
Define_label(mercury__unify_gen__generate_sub_assign_5_0_i10);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_sub_assign_5_0));
	r2 = r1;
	GOTO_LABEL(mercury__unify_gen__generate_sub_assign_5_0_i11);
Define_label(mercury__unify_gen__generate_sub_assign_5_0_i6);
	r2 = MR_stackvar(1);
Define_label(mercury__unify_gen__generate_sub_assign_5_0_i11);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__unify_gen__generate_sub_assign_5_0_i5);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(3) = r1;
	r2 = r3;
	MR_stackvar(1) = r3;
	call_localret(ENTRY(mercury__code_info__variable_is_forward_live_3_0),
		mercury__unify_gen__generate_sub_assign_5_0_i14,
		STATIC(mercury__unify_gen__generate_sub_assign_5_0));
Define_label(mercury__unify_gen__generate_sub_assign_5_0_i14);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_sub_assign_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__unify_gen__generate_sub_assign_5_0_i12);
	r1 = MR_stackvar(3);
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 1, mercury__unify_gen__generate_sub_assign_5_0, "llds:rval/0");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(2);
	call_localret(ENTRY(mercury__code_info__cache_expression_4_0),
		mercury__unify_gen__generate_sub_assign_5_0_i16,
		STATIC(mercury__unify_gen__generate_sub_assign_5_0));
Define_label(mercury__unify_gen__generate_sub_assign_5_0_i16);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_sub_assign_5_0));
	r2 = r1;
	GOTO_LABEL(mercury__unify_gen__generate_sub_assign_5_0_i17);
Define_label(mercury__unify_gen__generate_sub_assign_5_0_i12);
	r2 = MR_stackvar(1);
Define_label(mercury__unify_gen__generate_sub_assign_5_0_i17);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__unify_gen__generate_sub_assign_5_0_i3);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__unify_gen__generate_sub_assign_5_0_i19);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	r2 = r3;
	call_localret(ENTRY(mercury__code_info__produce_variable_5_0),
		mercury__unify_gen__generate_sub_assign_5_0_i20,
		STATIC(mercury__unify_gen__generate_sub_assign_5_0));
Define_label(mercury__unify_gen__generate_sub_assign_5_0_i20);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_sub_assign_5_0));
	r4 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 1, mercury__unify_gen__generate_sub_assign_5_0, "origin_lost_in_value_number");
	r2 = r3;
	MR_field(MR_mktag(0), r1, (Integer) 0) = r4;
	call_localret(ENTRY(mercury__code_info__materialize_vars_in_rval_5_0),
		mercury__unify_gen__generate_sub_assign_5_0_i21,
		STATIC(mercury__unify_gen__generate_sub_assign_5_0));
Define_label(mercury__unify_gen__generate_sub_assign_5_0_i21);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_sub_assign_5_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__unify_gen__generate_sub_assign_5_0_i22);
	r4 = r1;
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 2, mercury__unify_gen__generate_sub_assign_5_0, "tree:tree/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 2, mercury__unify_gen__generate_sub_assign_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = r2;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(2), r1, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 1, mercury__unify_gen__generate_sub_assign_5_0, "tree:tree/1");
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__unify_gen__generate_sub_assign_5_0, "list:list/1");
	tag_incr_hp_msg(r7, MR_mktag(0), (Integer) 2, mercury__unify_gen__generate_sub_assign_5_0, "std_util:pair/2");
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 3, mercury__unify_gen__generate_sub_assign_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r7, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_const_field(MR_mktag(0), r4, (Integer) 0);
	r2 = r3;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(2), r1, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 0) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 0) = r7;
	MR_field(MR_mktag(1), r6, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r7, (Integer) 1) = (Word) MR_string_const("Copy value", 10);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
	}
Define_label(mercury__unify_gen__generate_sub_assign_5_0_i22);
	MR_stackvar(1) = r3;
	r1 = (Word) MR_string_const("unify_gen__generate_sub_assign: lval vanished with ref", 54);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__unify_gen__generate_sub_assign_5_0_i29,
		STATIC(mercury__unify_gen__generate_sub_assign_5_0));
Define_label(mercury__unify_gen__generate_sub_assign_5_0_i19);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r4 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 1, mercury__unify_gen__generate_sub_assign_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	r2 = r3;
	call_localret(ENTRY(mercury__code_info__materialize_vars_in_rval_5_0),
		mercury__unify_gen__generate_sub_assign_5_0_i26,
		STATIC(mercury__unify_gen__generate_sub_assign_5_0));
Define_label(mercury__unify_gen__generate_sub_assign_5_0_i26);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_sub_assign_5_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__unify_gen__generate_sub_assign_5_0_i27);
	r4 = r1;
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 2, mercury__unify_gen__generate_sub_assign_5_0, "tree:tree/1");
	MR_field(MR_mktag(2), r1, (Integer) 0) = r2;
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 1, mercury__unify_gen__generate_sub_assign_5_0, "tree:tree/1");
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__unify_gen__generate_sub_assign_5_0, "list:list/1");
	tag_incr_hp_msg(r7, MR_mktag(0), (Integer) 2, mercury__unify_gen__generate_sub_assign_5_0, "std_util:pair/2");
	tag_incr_hp_msg(r8, MR_mktag(3), (Integer) 3, mercury__unify_gen__generate_sub_assign_5_0, "llds:instr/0");
	MR_field(MR_mktag(3), r8, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r8, (Integer) 1) = MR_const_field(MR_mktag(0), r4, (Integer) 0);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 1, mercury__unify_gen__generate_sub_assign_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r8, (Integer) 2) = MR_tempr1;
	r2 = r3;
	MR_field(MR_mktag(2), r1, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 0) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 0) = r7;
	MR_field(MR_mktag(1), r6, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r7, (Integer) 0) = r8;
	MR_field(MR_mktag(0), r7, (Integer) 1) = (Word) MR_string_const("Copy field", 10);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
	}
Define_label(mercury__unify_gen__generate_sub_assign_5_0_i27);
	MR_stackvar(1) = r3;
	r1 = (Word) MR_string_const("unify_gen__generate_sub_assign: lval vanished with lval", 55);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__unify_gen__generate_sub_assign_5_0_i29,
		STATIC(mercury__unify_gen__generate_sub_assign_5_0));
Define_label(mercury__unify_gen__generate_sub_assign_5_0_i29);
	update_prof_current_proc(LABEL(mercury__unify_gen__generate_sub_assign_5_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE

Declare_entry(mercury__type_util__type_to_type_id_3_0);
Declare_entry(mercury__prog_out__sym_name_to_string_2_0);
Declare_entry(mercury__string__int_to_string_2_0);

BEGIN_MODULE(unify_gen_module16)
	init_entry(mercury__unify_gen__var_type_msg_2_0);
	init_label(mercury__unify_gen__var_type_msg_2_0_i4);
	init_label(mercury__unify_gen__var_type_msg_2_0_i6);
	init_label(mercury__unify_gen__var_type_msg_2_0_i7);
	init_label(mercury__unify_gen__var_type_msg_2_0_i3);
BEGIN_CODE

/* code for predicate 'var_type_msg'/2 in mode 0 */
Define_static(mercury__unify_gen__var_type_msg_2_0);
	MR_incr_sp_push_msg(2, "unify_gen:var_type_msg/2");
	MR_stackvar(2) = (Word) MR_succip;
	call_localret(ENTRY(mercury__type_util__type_to_type_id_3_0),
		mercury__unify_gen__var_type_msg_2_0_i4,
		STATIC(mercury__unify_gen__var_type_msg_2_0));
Define_label(mercury__unify_gen__var_type_msg_2_0_i4);
	update_prof_current_proc(LABEL(mercury__unify_gen__var_type_msg_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__unify_gen__var_type_msg_2_0_i3);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(ENTRY(mercury__prog_out__sym_name_to_string_2_0),
		mercury__unify_gen__var_type_msg_2_0_i6,
		STATIC(mercury__unify_gen__var_type_msg_2_0));
Define_label(mercury__unify_gen__var_type_msg_2_0_i6);
	update_prof_current_proc(LABEL(mercury__unify_gen__var_type_msg_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__unify_gen__var_type_msg_2_0_i7,
		STATIC(mercury__unify_gen__var_type_msg_2_0));
Define_label(mercury__unify_gen__var_type_msg_2_0_i7);
	update_prof_current_proc(LABEL(mercury__unify_gen__var_type_msg_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__unify_gen__var_type_msg_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__unify_gen__var_type_msg_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const("/", 1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__unify_gen__var_type_msg_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__string__append_list_2_0),
		STATIC(mercury__unify_gen__var_type_msg_2_0));
	}
Define_label(mercury__unify_gen__var_type_msg_2_0_i3);
	r1 = (Word) MR_string_const("type is still a type variable in var_type_msg", 45);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__unify_gen__var_type_msg_2_0));
END_MODULE


BEGIN_MODULE(unify_gen_module17)
	init_entry(mercury____Unify___unify_gen__test_sense_0_0);
	init_label(mercury____Unify___unify_gen__test_sense_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___unify_gen__test_sense_0_0);
	if ((r1 != r2))
		GOTO_LABEL(mercury____Unify___unify_gen__test_sense_0_0_i1);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___unify_gen__test_sense_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(unify_gen_module18)
	init_entry(mercury____Index___unify_gen__test_sense_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___unify_gen__test_sense_0_0);
	proceed();
END_MODULE

Declare_entry(mercury__builtin_compare_int_3_0);

BEGIN_MODULE(unify_gen_module19)
	init_entry(mercury____Compare___unify_gen__test_sense_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___unify_gen__test_sense_0_0);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___unify_gen__test_sense_0_0));
END_MODULE

Declare_entry(mercury____Unify___llds__lval_0_0);

BEGIN_MODULE(unify_gen_module20)
	init_entry(mercury____Unify___unify_gen__uni_val_0_0);
	init_label(mercury____Unify___unify_gen__uni_val_0_0_i3);
	init_label(mercury____Unify___unify_gen__uni_val_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___unify_gen__uni_val_0_0);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Unify___unify_gen__uni_val_0_0_i3);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Unify___unify_gen__uni_val_0_0_i1);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	tailcall(ENTRY(mercury____Unify___term__var_1_0),
		STATIC(mercury____Unify___unify_gen__uni_val_0_0));
Define_label(mercury____Unify___unify_gen__uni_val_0_0_i3);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Unify___unify_gen__uni_val_0_0_i1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	tailcall(ENTRY(mercury____Unify___llds__lval_0_0),
		STATIC(mercury____Unify___unify_gen__uni_val_0_0));
Define_label(mercury____Unify___unify_gen__uni_val_0_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(unify_gen_module21)
	init_entry(mercury____Index___unify_gen__uni_val_0_0);
	init_label(mercury____Index___unify_gen__uni_val_0_0_i3);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___unify_gen__uni_val_0_0);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Index___unify_gen__uni_val_0_0_i3);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury____Index___unify_gen__uni_val_0_0_i3);
	r1 = (Integer) 1;
	proceed();
END_MODULE

Declare_entry(mercury____Compare___term__var_1_0);
Declare_entry(mercury____Compare___llds__lval_0_0);
Declare_entry(mercury__compare_error_0_0);

BEGIN_MODULE(unify_gen_module22)
	init_entry(mercury____Compare___unify_gen__uni_val_0_0);
	init_label(mercury____Compare___unify_gen__uni_val_0_0_i3);
	init_label(mercury____Compare___unify_gen__uni_val_0_0_i2);
	init_label(mercury____Compare___unify_gen__uni_val_0_0_i5);
	init_label(mercury____Compare___unify_gen__uni_val_0_0_i4);
	init_label(mercury____Compare___unify_gen__uni_val_0_0_i6);
	init_label(mercury____Compare___unify_gen__uni_val_0_0_i7);
	init_label(mercury____Compare___unify_gen__uni_val_0_0_i11);
	init_label(mercury____Compare___unify_gen__uni_val_0_0_i1014);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___unify_gen__uni_val_0_0);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___unify_gen__uni_val_0_0_i3);
	r3 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___unify_gen__uni_val_0_0_i2);
Define_label(mercury____Compare___unify_gen__uni_val_0_0_i3);
	r3 = (Integer) 1;
Define_label(mercury____Compare___unify_gen__uni_val_0_0_i2);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___unify_gen__uni_val_0_0_i5);
	r4 = (Integer) 0;
	GOTO_LABEL(mercury____Compare___unify_gen__uni_val_0_0_i4);
Define_label(mercury____Compare___unify_gen__uni_val_0_0_i5);
	r4 = (Integer) 1;
Define_label(mercury____Compare___unify_gen__uni_val_0_0_i4);
	if (((Integer) r3 >= (Integer) r4))
		GOTO_LABEL(mercury____Compare___unify_gen__uni_val_0_0_i6);
	r1 = (Integer) 1;
	proceed();
Define_label(mercury____Compare___unify_gen__uni_val_0_0_i6);
	if (((Integer) r3 <= (Integer) r4))
		GOTO_LABEL(mercury____Compare___unify_gen__uni_val_0_0_i7);
	r1 = (Integer) 2;
	proceed();
Define_label(mercury____Compare___unify_gen__uni_val_0_0_i7);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___unify_gen__uni_val_0_0_i11);
	if ((MR_tag(r2) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury____Compare___unify_gen__uni_val_0_0_i1014);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	tailcall(ENTRY(mercury____Compare___term__var_1_0),
		STATIC(mercury____Compare___unify_gen__uni_val_0_0));
Define_label(mercury____Compare___unify_gen__uni_val_0_0_i11);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury____Compare___unify_gen__uni_val_0_0_i1014);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	tailcall(ENTRY(mercury____Compare___llds__lval_0_0),
		STATIC(mercury____Compare___unify_gen__uni_val_0_0));
Define_label(mercury____Compare___unify_gen__uni_val_0_0_i1014);
	tailcall(ENTRY(mercury__compare_error_0_0),
		STATIC(mercury____Compare___unify_gen__uni_val_0_0));
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__unify_gen_maybe_bunch_0(void)
{
	unify_gen_module0();
	unify_gen_module1();
	unify_gen_module2();
	unify_gen_module3();
	unify_gen_module4();
	unify_gen_module5();
	unify_gen_module6();
	unify_gen_module7();
	unify_gen_module8();
	unify_gen_module9();
	unify_gen_module10();
	unify_gen_module11();
	unify_gen_module12();
	unify_gen_module13();
	unify_gen_module14();
	unify_gen_module15();
	unify_gen_module16();
	unify_gen_module17();
	unify_gen_module18();
	unify_gen_module19();
	unify_gen_module20();
	unify_gen_module21();
	unify_gen_module22();
}

#endif

void mercury__unify_gen__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__unify_gen__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__unify_gen_maybe_bunch_0();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_unify_gen__type_ctor_info_test_sense_0,
			unify_gen__test_sense_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_unify_gen__type_ctor_info_uni_val_0,
			unify_gen__uni_val_0_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
