/*
** Automatically generated from `unify_proc.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__unify_proc__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury____Index___unify_proc__unify_proc_info_0__ua0_2_0);
Declare_static(mercury____Index___unify_proc__proc_requests_0__ua0_2_0);
Define_extern_entry(mercury__unify_proc__init_requests_1_0);
Declare_label(mercury__unify_proc__init_requests_1_0_i2);
Declare_label(mercury__unify_proc__init_requests_1_0_i3);
Define_extern_entry(mercury__unify_proc__request_unify_5_0);
Declare_label(mercury__unify_proc__request_unify_5_0_i10);
Declare_label(mercury__unify_proc__request_unify_5_0_i12);
Declare_label(mercury__unify_proc__request_unify_5_0_i7);
Declare_label(mercury__unify_proc__request_unify_5_0_i8);
Declare_label(mercury__unify_proc__request_unify_5_0_i15);
Declare_label(mercury__unify_proc__request_unify_5_0_i18);
Declare_label(mercury__unify_proc__request_unify_5_0_i21);
Declare_label(mercury__unify_proc__request_unify_5_0_i22);
Declare_label(mercury__unify_proc__request_unify_5_0_i5);
Declare_label(mercury__unify_proc__request_unify_5_0_i27);
Declare_label(mercury__unify_proc__request_unify_5_0_i1006);
Declare_label(mercury__unify_proc__request_unify_5_0_i2);
Declare_label(mercury__unify_proc__request_unify_5_0_i29);
Declare_label(mercury__unify_proc__request_unify_5_0_i30);
Declare_label(mercury__unify_proc__request_unify_5_0_i31);
Declare_label(mercury__unify_proc__request_unify_5_0_i32);
Declare_label(mercury__unify_proc__request_unify_5_0_i33);
Declare_label(mercury__unify_proc__request_unify_5_0_i34);
Declare_label(mercury__unify_proc__request_unify_5_0_i35);
Declare_label(mercury__unify_proc__request_unify_5_0_i36);
Define_extern_entry(mercury__unify_proc__request_proc_8_0);
Declare_label(mercury__unify_proc__request_proc_8_0_i2);
Declare_label(mercury__unify_proc__request_proc_8_0_i3);
Declare_label(mercury__unify_proc__request_proc_8_0_i4);
Declare_label(mercury__unify_proc__request_proc_8_0_i5);
Declare_label(mercury__unify_proc__request_proc_8_0_i6);
Declare_label(mercury__unify_proc__request_proc_8_0_i7);
Declare_label(mercury__unify_proc__request_proc_8_0_i8);
Declare_label(mercury__unify_proc__request_proc_8_0_i9);
Declare_label(mercury__unify_proc__request_proc_8_0_i10);
Declare_label(mercury__unify_proc__request_proc_8_0_i11);
Declare_label(mercury__unify_proc__request_proc_8_0_i12);
Declare_label(mercury__unify_proc__request_proc_8_0_i13);
Declare_label(mercury__unify_proc__request_proc_8_0_i14);
Declare_label(mercury__unify_proc__request_proc_8_0_i15);
Declare_label(mercury__unify_proc__request_proc_8_0_i16);
Declare_label(mercury__unify_proc__request_proc_8_0_i17);
Declare_label(mercury__unify_proc__request_proc_8_0_i18);
Declare_label(mercury__unify_proc__request_proc_8_0_i19);
Declare_label(mercury__unify_proc__request_proc_8_0_i20);
Define_extern_entry(mercury__unify_proc__modecheck_queued_procs_8_0);
Declare_label(mercury__unify_proc__modecheck_queued_procs_8_0_i2);
Declare_label(mercury__unify_proc__modecheck_queued_procs_8_0_i4);
Declare_label(mercury__unify_proc__modecheck_queued_procs_8_0_i6);
Declare_label(mercury__unify_proc__modecheck_queued_procs_8_0_i7);
Declare_label(mercury__unify_proc__modecheck_queued_procs_8_0_i9);
Declare_label(mercury__unify_proc__modecheck_queued_procs_8_0_i11);
Declare_label(mercury__unify_proc__modecheck_queued_procs_8_0_i14);
Declare_label(mercury__unify_proc__modecheck_queued_procs_8_0_i17);
Declare_label(mercury__unify_proc__modecheck_queued_procs_8_0_i19);
Declare_label(mercury__unify_proc__modecheck_queued_procs_8_0_i20);
Declare_label(mercury__unify_proc__modecheck_queued_procs_8_0_i12);
Declare_label(mercury__unify_proc__modecheck_queued_procs_8_0_i21);
Declare_label(mercury__unify_proc__modecheck_queued_procs_8_0_i22);
Declare_label(mercury__unify_proc__modecheck_queued_procs_8_0_i8);
Declare_label(mercury__unify_proc__modecheck_queued_procs_8_0_i24);
Declare_label(mercury__unify_proc__modecheck_queued_procs_8_0_i25);
Declare_label(mercury__unify_proc__modecheck_queued_procs_8_0_i3);
Define_extern_entry(mercury__unify_proc__lookup_mode_num_5_0);
Declare_label(mercury__unify_proc__lookup_mode_num_5_0_i7);
Declare_label(mercury__unify_proc__lookup_mode_num_5_0_i9);
Declare_label(mercury__unify_proc__lookup_mode_num_5_0_i4);
Declare_label(mercury__unify_proc__lookup_mode_num_5_0_i1007);
Declare_label(mercury__unify_proc__lookup_mode_num_5_0_i5);
Declare_label(mercury__unify_proc__lookup_mode_num_5_0_i12);
Declare_label(mercury__unify_proc__lookup_mode_num_5_0_i15);
Declare_label(mercury__unify_proc__lookup_mode_num_5_0_i18);
Declare_label(mercury__unify_proc__lookup_mode_num_5_0_i19);
Declare_label(mercury__unify_proc__lookup_mode_num_5_0_i3);
Define_extern_entry(mercury__unify_proc__generate_clause_info_6_0);
Declare_label(mercury__unify_proc__generate_clause_info_6_0_i2);
Declare_label(mercury__unify_proc__generate_clause_info_6_0_i3);
Declare_label(mercury__unify_proc__generate_clause_info_6_0_i4);
Declare_label(mercury__unify_proc__generate_clause_info_6_0_i6);
Declare_label(mercury__unify_proc__generate_clause_info_6_0_i7);
Declare_label(mercury__unify_proc__generate_clause_info_6_0_i8);
Declare_label(mercury__unify_proc__generate_clause_info_6_0_i9);
Declare_label(mercury__unify_proc__generate_clause_info_6_0_i10);
Declare_label(mercury__unify_proc__generate_clause_info_6_0_i18);
Declare_label(mercury__unify_proc__generate_clause_info_6_0_i13);
Declare_label(mercury__unify_proc__generate_clause_info_6_0_i24);
Declare_label(mercury__unify_proc__generate_clause_info_6_0_i19);
Declare_label(mercury__unify_proc__generate_clause_info_6_0_i31);
Declare_label(mercury__unify_proc__generate_clause_info_6_0_i25);
Declare_label(mercury__unify_proc__generate_clause_info_6_0_i11);
Declare_label(mercury__unify_proc__generate_clause_info_6_0_i36);
Declare_label(mercury__unify_proc__generate_clause_info_6_0_i37);
Declare_label(mercury__unify_proc__generate_clause_info_6_0_i38);
Declare_static(mercury__unify_proc__modecheck_queued_proc_9_0);
Declare_label(mercury__unify_proc__modecheck_queued_proc_9_0_i2);
Declare_label(mercury__unify_proc__modecheck_queued_proc_9_0_i3);
Declare_label(mercury__unify_proc__modecheck_queued_proc_9_0_i4);
Declare_label(mercury__unify_proc__modecheck_queued_proc_9_0_i5);
Declare_label(mercury__unify_proc__modecheck_queued_proc_9_0_i6);
Declare_label(mercury__unify_proc__modecheck_queued_proc_9_0_i7);
Declare_label(mercury__unify_proc__modecheck_queued_proc_9_0_i8);
Declare_label(mercury__unify_proc__modecheck_queued_proc_9_0_i9);
Declare_label(mercury__unify_proc__modecheck_queued_proc_9_0_i10);
Declare_label(mercury__unify_proc__modecheck_queued_proc_9_0_i11);
Declare_label(mercury__unify_proc__modecheck_queued_proc_9_0_i16);
Declare_label(mercury__unify_proc__modecheck_queued_proc_9_0_i17);
Declare_label(mercury__unify_proc__modecheck_queued_proc_9_0_i13);
Declare_label(mercury__unify_proc__modecheck_queued_proc_9_0_i20);
Declare_label(mercury__unify_proc__modecheck_queued_proc_9_0_i21);
Declare_label(mercury__unify_proc__modecheck_queued_proc_9_0_i22);
Declare_label(mercury__unify_proc__modecheck_queued_proc_9_0_i23);
Declare_label(mercury__unify_proc__modecheck_queued_proc_9_0_i24);
Declare_label(mercury__unify_proc__modecheck_queued_proc_9_0_i25);
Declare_label(mercury__unify_proc__modecheck_queued_proc_9_0_i26);
Declare_label(mercury__unify_proc__modecheck_queued_proc_9_0_i27);
Declare_label(mercury__unify_proc__modecheck_queued_proc_9_0_i28);
Declare_label(mercury__unify_proc__modecheck_queued_proc_9_0_i29);
Declare_label(mercury__unify_proc__modecheck_queued_proc_9_0_i30);
Declare_label(mercury__unify_proc__modecheck_queued_proc_9_0_i18);
Declare_static(mercury__unify_proc__generate_unify_clauses_7_0);
Declare_label(mercury__unify_proc__generate_unify_clauses_7_0_i1022);
Declare_label(mercury__unify_proc__generate_unify_clauses_7_0_i6);
Declare_label(mercury__unify_proc__generate_unify_clauses_7_0_i9);
Declare_label(mercury__unify_proc__generate_unify_clauses_7_0_i10);
Declare_label(mercury__unify_proc__generate_unify_clauses_7_0_i11);
Declare_label(mercury__unify_proc__generate_unify_clauses_7_0_i12);
Declare_label(mercury__unify_proc__generate_unify_clauses_7_0_i7);
Declare_label(mercury__unify_proc__generate_unify_clauses_7_0_i16);
Declare_label(mercury__unify_proc__generate_unify_clauses_7_0_i17);
Declare_label(mercury__unify_proc__generate_unify_clauses_7_0_i18);
Declare_label(mercury__unify_proc__generate_unify_clauses_7_0_i19);
Declare_label(mercury__unify_proc__generate_unify_clauses_7_0_i20);
Declare_label(mercury__unify_proc__generate_unify_clauses_7_0_i21);
Declare_label(mercury__unify_proc__generate_unify_clauses_7_0_i22);
Declare_label(mercury__unify_proc__generate_unify_clauses_7_0_i23);
Declare_label(mercury__unify_proc__generate_unify_clauses_7_0_i24);
Declare_label(mercury__unify_proc__generate_unify_clauses_7_0_i14);
Declare_label(mercury__unify_proc__generate_unify_clauses_7_0_i1024);
Declare_label(mercury__unify_proc__generate_unify_clauses_7_0_i31);
Declare_label(mercury__unify_proc__generate_unify_clauses_7_0_i32);
Declare_static(mercury__unify_proc__generate_index_clauses_7_0);
Declare_label(mercury__unify_proc__generate_index_clauses_7_0_i1008);
Declare_label(mercury__unify_proc__generate_index_clauses_7_0_i6);
Declare_label(mercury__unify_proc__generate_index_clauses_7_0_i7);
Declare_label(mercury__unify_proc__generate_index_clauses_7_0_i11);
Declare_label(mercury__unify_proc__generate_index_clauses_7_0_i1010);
Declare_label(mercury__unify_proc__generate_index_clauses_7_0_i20);
Declare_label(mercury__unify_proc__generate_index_clauses_7_0_i21);
Declare_static(mercury__unify_proc__generate_compare_clauses_8_0);
Declare_label(mercury__unify_proc__generate_compare_clauses_8_0_i1022);
Declare_label(mercury__unify_proc__generate_compare_clauses_8_0_i6);
Declare_label(mercury__unify_proc__generate_compare_clauses_8_0_i7);
Declare_label(mercury__unify_proc__generate_compare_clauses_8_0_i13);
Declare_label(mercury__unify_proc__generate_compare_clauses_8_0_i14);
Declare_label(mercury__unify_proc__generate_compare_clauses_8_0_i15);
Declare_label(mercury__unify_proc__generate_compare_clauses_8_0_i16);
Declare_label(mercury__unify_proc__generate_compare_clauses_8_0_i17);
Declare_label(mercury__unify_proc__generate_compare_clauses_8_0_i18);
Declare_label(mercury__unify_proc__generate_compare_clauses_8_0_i19);
Declare_label(mercury__unify_proc__generate_compare_clauses_8_0_i20);
Declare_label(mercury__unify_proc__generate_compare_clauses_8_0_i21);
Declare_label(mercury__unify_proc__generate_compare_clauses_8_0_i22);
Declare_label(mercury__unify_proc__generate_compare_clauses_8_0_i11);
Declare_label(mercury__unify_proc__generate_compare_clauses_8_0_i1024);
Declare_label(mercury__unify_proc__generate_compare_clauses_8_0_i29);
Declare_label(mercury__unify_proc__generate_compare_clauses_8_0_i30);
Declare_static(mercury__unify_proc__quantify_clause_body_6_0);
Declare_label(mercury__unify_proc__quantify_clause_body_6_0_i2);
Declare_static(mercury__unify_proc__generate_du_unify_clauses_7_0);
Declare_label(mercury__unify_proc__generate_du_unify_clauses_7_0_i4);
Declare_label(mercury__unify_proc__generate_du_unify_clauses_7_0_i5);
Declare_label(mercury__unify_proc__generate_du_unify_clauses_7_0_i6);
Declare_label(mercury__unify_proc__generate_du_unify_clauses_7_0_i7);
Declare_label(mercury__unify_proc__generate_du_unify_clauses_7_0_i8);
Declare_label(mercury__unify_proc__generate_du_unify_clauses_7_0_i11);
Declare_label(mercury__unify_proc__generate_du_unify_clauses_7_0_i10);
Declare_label(mercury__unify_proc__generate_du_unify_clauses_7_0_i14);
Declare_label(mercury__unify_proc__generate_du_unify_clauses_7_0_i15);
Declare_label(mercury__unify_proc__generate_du_unify_clauses_7_0_i16);
Declare_label(mercury__unify_proc__generate_du_unify_clauses_7_0_i17);
Declare_label(mercury__unify_proc__generate_du_unify_clauses_7_0_i1008);
Declare_label(mercury__unify_proc__generate_du_unify_clauses_7_0_i19);
Declare_label(mercury__unify_proc__generate_du_unify_clauses_7_0_i3);
Declare_static(mercury__unify_proc__generate_du_index_clauses_8_0);
Declare_label(mercury__unify_proc__generate_du_index_clauses_8_0_i4);
Declare_label(mercury__unify_proc__generate_du_index_clauses_8_0_i5);
Declare_label(mercury__unify_proc__generate_du_index_clauses_8_0_i6);
Declare_label(mercury__unify_proc__generate_du_index_clauses_8_0_i7);
Declare_label(mercury__unify_proc__generate_du_index_clauses_8_0_i8);
Declare_label(mercury__unify_proc__generate_du_index_clauses_8_0_i9);
Declare_label(mercury__unify_proc__generate_du_index_clauses_8_0_i10);
Declare_label(mercury__unify_proc__generate_du_index_clauses_8_0_i11);
Declare_label(mercury__unify_proc__generate_du_index_clauses_8_0_i12);
Declare_label(mercury__unify_proc__generate_du_index_clauses_8_0_i3);
Declare_static(mercury__unify_proc__generate_du_compare_clauses_8_0);
Declare_label(mercury__unify_proc__generate_du_compare_clauses_8_0_i5);
Declare_label(mercury__unify_proc__generate_du_compare_clauses_8_0_i6);
Declare_label(mercury__unify_proc__generate_du_compare_clauses_8_0_i7);
Declare_label(mercury__unify_proc__generate_du_compare_clauses_8_0_i8);
Declare_label(mercury__unify_proc__generate_du_compare_clauses_8_0_i9);
Declare_label(mercury__unify_proc__generate_du_compare_clauses_8_0_i12);
Declare_label(mercury__unify_proc__generate_du_compare_clauses_8_0_i11);
Declare_label(mercury__unify_proc__generate_du_compare_clauses_8_0_i15);
Declare_label(mercury__unify_proc__generate_du_compare_clauses_8_0_i16);
Declare_label(mercury__unify_proc__generate_du_compare_clauses_8_0_i17);
Declare_label(mercury__unify_proc__generate_du_compare_clauses_8_0_i18);
Declare_label(mercury__unify_proc__generate_du_compare_clauses_8_0_i2);
Declare_label(mercury__unify_proc__generate_du_compare_clauses_8_0_i19);
Declare_label(mercury__unify_proc__generate_du_compare_clauses_8_0_i21);
Declare_label(mercury__unify_proc__generate_du_compare_clauses_8_0_i22);
Declare_label(mercury__unify_proc__generate_du_compare_clauses_8_0_i23);
Declare_static(mercury__unify_proc__generate_du_compare_clauses_2_8_0);
Declare_label(mercury__unify_proc__generate_du_compare_clauses_2_8_0_i2);
Declare_label(mercury__unify_proc__generate_du_compare_clauses_2_8_0_i3);
Declare_label(mercury__unify_proc__generate_du_compare_clauses_2_8_0_i4);
Declare_label(mercury__unify_proc__generate_du_compare_clauses_2_8_0_i5);
Declare_label(mercury__unify_proc__generate_du_compare_clauses_2_8_0_i6);
Declare_label(mercury__unify_proc__generate_du_compare_clauses_2_8_0_i7);
Declare_label(mercury__unify_proc__generate_du_compare_clauses_2_8_0_i8);
Declare_label(mercury__unify_proc__generate_du_compare_clauses_2_8_0_i9);
Declare_label(mercury__unify_proc__generate_du_compare_clauses_2_8_0_i10);
Declare_label(mercury__unify_proc__generate_du_compare_clauses_2_8_0_i11);
Declare_label(mercury__unify_proc__generate_du_compare_clauses_2_8_0_i12);
Declare_label(mercury__unify_proc__generate_du_compare_clauses_2_8_0_i13);
Declare_label(mercury__unify_proc__generate_du_compare_clauses_2_8_0_i14);
Declare_label(mercury__unify_proc__generate_du_compare_clauses_2_8_0_i15);
Declare_label(mercury__unify_proc__generate_du_compare_clauses_2_8_0_i16);
Declare_label(mercury__unify_proc__generate_du_compare_clauses_2_8_0_i17);
Declare_label(mercury__unify_proc__generate_du_compare_clauses_2_8_0_i18);
Declare_label(mercury__unify_proc__generate_du_compare_clauses_2_8_0_i19);
Declare_static(mercury__unify_proc__generate_compare_cases_8_0);
Declare_label(mercury__unify_proc__generate_compare_cases_8_0_i4);
Declare_label(mercury__unify_proc__generate_compare_cases_8_0_i5);
Declare_label(mercury__unify_proc__generate_compare_cases_8_0_i6);
Declare_label(mercury__unify_proc__generate_compare_cases_8_0_i7);
Declare_label(mercury__unify_proc__generate_compare_cases_8_0_i8);
Declare_label(mercury__unify_proc__generate_compare_cases_8_0_i11);
Declare_label(mercury__unify_proc__generate_compare_cases_8_0_i10);
Declare_label(mercury__unify_proc__generate_compare_cases_8_0_i14);
Declare_label(mercury__unify_proc__generate_compare_cases_8_0_i15);
Declare_label(mercury__unify_proc__generate_compare_cases_8_0_i16);
Declare_label(mercury__unify_proc__generate_compare_cases_8_0_i17);
Declare_label(mercury__unify_proc__generate_compare_cases_8_0_i18);
Declare_label(mercury__unify_proc__generate_compare_cases_8_0_i3);
Declare_static(mercury__unify_proc__compare_args_2_9_0);
Declare_label(mercury__unify_proc__compare_args_2_9_0_i6);
Declare_label(mercury__unify_proc__compare_args_2_9_0_i3);
Declare_label(mercury__unify_proc__compare_args_2_9_0_i9);
Declare_label(mercury__unify_proc__compare_args_2_9_0_i10);
Declare_label(mercury__unify_proc__compare_args_2_9_0_i15);
Declare_label(mercury__unify_proc__compare_args_2_9_0_i1050);
Declare_label(mercury__unify_proc__compare_args_2_9_0_i13);
Declare_label(mercury__unify_proc__compare_args_2_9_0_i18);
Declare_label(mercury__unify_proc__compare_args_2_9_0_i12);
Declare_label(mercury__unify_proc__compare_args_2_9_0_i19);
Declare_label(mercury__unify_proc__compare_args_2_9_0_i23);
Declare_label(mercury__unify_proc__compare_args_2_9_0_i20);
Declare_label(mercury__unify_proc__compare_args_2_9_0_i24);
Declare_label(mercury__unify_proc__compare_args_2_9_0_i25);
Declare_label(mercury__unify_proc__compare_args_2_9_0_i26);
Declare_label(mercury__unify_proc__compare_args_2_9_0_i27);
Declare_label(mercury__unify_proc__compare_args_2_9_0_i28);
Declare_label(mercury__unify_proc__compare_args_2_9_0_i29);
Declare_label(mercury__unify_proc__compare_args_2_9_0_i30);
Declare_label(mercury__unify_proc__compare_args_2_9_0_i31);
Declare_label(mercury__unify_proc__compare_args_2_9_0_i1038);
Declare_label(mercury__unify_proc__compare_args_2_9_0_i1);
Declare_static(mercury__unify_proc__build_call_6_0);
Declare_label(mercury__unify_proc__build_call_6_0_i2);
Declare_label(mercury__unify_proc__build_call_6_0_i3);
Declare_label(mercury__unify_proc__build_call_6_0_i6);
Declare_label(mercury__unify_proc__build_call_6_0_i4);
Declare_label(mercury__unify_proc__build_call_6_0_i9);
Declare_label(mercury__unify_proc__build_call_6_0_i12);
Declare_label(mercury__unify_proc__build_call_6_0_i15);
Declare_label(mercury__unify_proc__build_call_6_0_i11);
Declare_label(mercury__unify_proc__build_call_6_0_i17);
Declare_label(mercury__unify_proc__build_call_6_0_i18);
Declare_label(mercury__unify_proc__build_call_6_0_i19);
Declare_label(mercury__unify_proc__build_call_6_0_i21);
Declare_label(mercury__unify_proc__build_call_6_0_i22);
Declare_label(mercury__unify_proc__build_call_6_0_i23);
Declare_label(mercury__unify_proc__build_call_6_0_i24);
Declare_static(mercury__unify_proc__make_fresh_named_vars_from_types_6_0);
Declare_label(mercury__unify_proc__make_fresh_named_vars_from_types_6_0_i4);
Declare_label(mercury__unify_proc__make_fresh_named_vars_from_types_6_0_i5);
Declare_label(mercury__unify_proc__make_fresh_named_vars_from_types_6_0_i6);
Declare_label(mercury__unify_proc__make_fresh_named_vars_from_types_6_0_i7);
Declare_label(mercury__unify_proc__make_fresh_named_vars_from_types_6_0_i8);
Declare_label(mercury__unify_proc__make_fresh_named_vars_from_types_6_0_i3);
Declare_static(mercury__unify_proc__make_fresh_vars_from_types_4_0);
Declare_label(mercury__unify_proc__make_fresh_vars_from_types_4_0_i4);
Declare_label(mercury__unify_proc__make_fresh_vars_from_types_4_0_i5);
Declare_label(mercury__unify_proc__make_fresh_vars_from_types_4_0_i6);
Declare_label(mercury__unify_proc__make_fresh_vars_from_types_4_0_i3);
Declare_static(mercury__unify_proc__make_fresh_vars_5_0);
Declare_label(mercury__unify_proc__make_fresh_vars_5_0_i4);
Declare_label(mercury__unify_proc__make_fresh_vars_5_0_i2);
Declare_label(mercury__unify_proc__make_fresh_vars_5_0_i6);
Declare_label(mercury__unify_proc__make_fresh_vars_5_0_i7);
Declare_static(mercury__unify_proc__unify_var_lists_2_7_0);
Declare_label(mercury__unify_proc__unify_var_lists_2_7_0_i3);
Declare_label(mercury__unify_proc__unify_var_lists_2_7_0_i8);
Declare_label(mercury__unify_proc__unify_var_lists_2_7_0_i13);
Declare_label(mercury__unify_proc__unify_var_lists_2_7_0_i1033);
Declare_label(mercury__unify_proc__unify_var_lists_2_7_0_i11);
Declare_label(mercury__unify_proc__unify_var_lists_2_7_0_i16);
Declare_label(mercury__unify_proc__unify_var_lists_2_7_0_i17);
Declare_label(mercury__unify_proc__unify_var_lists_2_7_0_i10);
Declare_label(mercury__unify_proc__unify_var_lists_2_7_0_i18);
Declare_label(mercury__unify_proc__unify_var_lists_2_7_0_i20);
Declare_label(mercury__unify_proc__unify_var_lists_2_7_0_i1023);
Declare_label(mercury__unify_proc__unify_var_lists_2_7_0_i1);
Declare_static(mercury__unify_proc__info_new_var_4_0);
Declare_label(mercury__unify_proc__info_new_var_4_0_i2);
Declare_label(mercury__unify_proc__info_new_var_4_0_i3);
Declare_static(mercury__unify_proc__info_set_varset_3_0);
Declare_static(mercury__unify_proc__info_set_types_3_0);
Define_extern_entry(mercury____Unify___unify_proc__proc_requests_0_0);
Declare_label(mercury____Unify___unify_proc__proc_requests_0_0_i2);
Declare_label(mercury____Unify___unify_proc__proc_requests_0_0_i1);
Define_extern_entry(mercury____Index___unify_proc__proc_requests_0_0);
Define_extern_entry(mercury____Compare___unify_proc__proc_requests_0_0);
Declare_label(mercury____Compare___unify_proc__proc_requests_0_0_i3);
Declare_label(mercury____Compare___unify_proc__proc_requests_0_0_i7);
Define_extern_entry(mercury____Unify___unify_proc__unify_proc_id_0_0);
Define_extern_entry(mercury____Index___unify_proc__unify_proc_id_0_0);
Define_extern_entry(mercury____Compare___unify_proc__unify_proc_id_0_0);
Declare_static(mercury____Unify___unify_proc__unify_req_map_0_0);
Declare_static(mercury____Index___unify_proc__unify_req_map_0_0);
Declare_static(mercury____Compare___unify_proc__unify_req_map_0_0);
Declare_static(mercury____Unify___unify_proc__req_queue_0_0);
Declare_static(mercury____Index___unify_proc__req_queue_0_0);
Declare_static(mercury____Compare___unify_proc__req_queue_0_0);
Declare_static(mercury____Unify___unify_proc__unify_proc_info_0_0);
Declare_label(mercury____Unify___unify_proc__unify_proc_info_0_0_i2);
Declare_label(mercury____Unify___unify_proc__unify_proc_info_0_0_i4);
Declare_label(mercury____Unify___unify_proc__unify_proc_info_0_0_i1);
Declare_static(mercury____Index___unify_proc__unify_proc_info_0_0);
Declare_static(mercury____Compare___unify_proc__unify_proc_info_0_0);
Declare_label(mercury____Compare___unify_proc__unify_proc_info_0_0_i3);
Declare_label(mercury____Compare___unify_proc__unify_proc_info_0_0_i7);
Declare_label(mercury____Compare___unify_proc__unify_proc_info_0_0_i12);

const struct MR_TypeCtorInfo_struct mercury_data_unify_proc__type_ctor_info_proc_requests_0;

const struct MR_TypeCtorInfo_struct mercury_data_unify_proc__type_ctor_info_req_queue_0;

const struct MR_TypeCtorInfo_struct mercury_data_unify_proc__type_ctor_info_unify_proc_id_0;

const struct MR_TypeCtorInfo_struct mercury_data_unify_proc__type_ctor_info_unify_proc_info_0;

const struct MR_TypeCtorInfo_struct mercury_data_unify_proc__type_ctor_info_unify_req_map_0;

static const struct mercury_data_unify_proc__common_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_unify_proc__common_0;

static const struct mercury_data_unify_proc__common_1_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_unify_proc__common_1;

static const struct mercury_data_unify_proc__common_2_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_unify_proc__common_2;

static const struct mercury_data_unify_proc__common_3_struct {
	Word * f1;
	Word * f2;
}  mercury_data_unify_proc__common_3;

static const struct mercury_data_unify_proc__common_4_struct {
	Word * f1;
	Word * f2;
}  mercury_data_unify_proc__common_4;

static const struct mercury_data_unify_proc__common_5_struct {
	Word * f1;
	Word * f2;
}  mercury_data_unify_proc__common_5;

static const struct mercury_data_unify_proc__common_6_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_unify_proc__common_6;

static const struct mercury_data_unify_proc__common_7_struct {
	String f1;
}  mercury_data_unify_proc__common_7;

static const struct mercury_data_unify_proc__common_8_struct {
	Word * f1;
	Integer f2;
}  mercury_data_unify_proc__common_8;

static const struct mercury_data_unify_proc__common_9_struct {
	Word * f1;
	Word * f2;
}  mercury_data_unify_proc__common_9;

static const struct mercury_data_unify_proc__common_10_struct {
	String f1;
}  mercury_data_unify_proc__common_10;

static const struct mercury_data_unify_proc__common_11_struct {
	Word * f1;
	Integer f2;
}  mercury_data_unify_proc__common_11;

static const struct mercury_data_unify_proc__common_12_struct {
	Word * f1;
	Word * f2;
}  mercury_data_unify_proc__common_12;

static const struct mercury_data_unify_proc__common_13_struct {
	String f1;
}  mercury_data_unify_proc__common_13;

static const struct mercury_data_unify_proc__common_14_struct {
	Word * f1;
	Integer f2;
}  mercury_data_unify_proc__common_14;

static const struct mercury_data_unify_proc__common_15_struct {
	Word * f1;
	Word * f2;
}  mercury_data_unify_proc__common_15;

static const struct mercury_data_unify_proc__common_16_struct {
	String f1;
	Word * f2;
}  mercury_data_unify_proc__common_16;

static const struct mercury_data_unify_proc__common_17_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_unify_proc__common_17;

static const struct mercury_data_unify_proc__common_18_struct {
	Integer f1;
	Word * f2;
}  mercury_data_unify_proc__common_18;

static const struct mercury_data_unify_proc__common_19_struct {
	Word * f1;
	Word * f2;
}  mercury_data_unify_proc__common_19;

static const struct mercury_data_unify_proc__common_20_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_unify_proc__common_20;

static const struct mercury_data_unify_proc__common_21_struct {
	Word * f1;
}  mercury_data_unify_proc__common_21;

static const struct mercury_data_unify_proc__common_22_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	String f5;
	Word * f6;
	Integer f7;
	Integer f8;
}  mercury_data_unify_proc__common_22;

static const struct mercury_data_unify_proc__common_23_struct {
	Integer f1;
	Word * f2;
}  mercury_data_unify_proc__common_23;

static const struct mercury_data_unify_proc__common_24_struct {
	Word * f1;
	Word * f2;
}  mercury_data_unify_proc__common_24;

static const struct mercury_data_unify_proc__common_25_struct {
	Integer f1;
	Word * f2;
}  mercury_data_unify_proc__common_25;

static const struct mercury_data_unify_proc__common_26_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	String f4;
	Word * f5;
	Integer f6;
	Integer f7;
}  mercury_data_unify_proc__common_26;

static const struct mercury_data_unify_proc__type_ctor_functors_unify_req_map_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_unify_proc__type_ctor_functors_unify_req_map_0;

static const struct mercury_data_unify_proc__type_ctor_layout_unify_req_map_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_unify_proc__type_ctor_layout_unify_req_map_0;

static const struct mercury_data_unify_proc__type_ctor_functors_unify_proc_info_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_unify_proc__type_ctor_functors_unify_proc_info_0;

static const struct mercury_data_unify_proc__type_ctor_layout_unify_proc_info_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_unify_proc__type_ctor_layout_unify_proc_info_0;

static const struct mercury_data_unify_proc__type_ctor_functors_unify_proc_id_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_unify_proc__type_ctor_functors_unify_proc_id_0;

static const struct mercury_data_unify_proc__type_ctor_layout_unify_proc_id_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_unify_proc__type_ctor_layout_unify_proc_id_0;

static const struct mercury_data_unify_proc__type_ctor_functors_req_queue_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_unify_proc__type_ctor_functors_req_queue_0;

static const struct mercury_data_unify_proc__type_ctor_layout_req_queue_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_unify_proc__type_ctor_layout_req_queue_0;

static const struct mercury_data_unify_proc__type_ctor_functors_proc_requests_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_unify_proc__type_ctor_functors_proc_requests_0;

static const struct mercury_data_unify_proc__type_ctor_layout_proc_requests_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_unify_proc__type_ctor_layout_proc_requests_0;

const struct MR_TypeCtorInfo_struct mercury_data_unify_proc__type_ctor_info_proc_requests_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___unify_proc__proc_requests_0_0),
	ENTRY(mercury____Index___unify_proc__proc_requests_0_0),
	ENTRY(mercury____Compare___unify_proc__proc_requests_0_0),
	(Integer) 2,
	(Word *) &mercury_data_unify_proc__type_ctor_functors_proc_requests_0,
	(Word *) &mercury_data_unify_proc__type_ctor_layout_proc_requests_0,
	MR_string_const("unify_proc", 10),
	MR_string_const("proc_requests", 13),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_unify_proc__type_ctor_info_req_queue_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___unify_proc__req_queue_0_0),
	STATIC(mercury____Index___unify_proc__req_queue_0_0),
	STATIC(mercury____Compare___unify_proc__req_queue_0_0),
	(Integer) 6,
	(Word *) &mercury_data_unify_proc__type_ctor_functors_req_queue_0,
	(Word *) &mercury_data_unify_proc__type_ctor_layout_req_queue_0,
	MR_string_const("unify_proc", 10),
	MR_string_const("req_queue", 9),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_unify_proc__type_ctor_info_unify_proc_id_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___unify_proc__unify_proc_id_0_0),
	ENTRY(mercury____Index___unify_proc__unify_proc_id_0_0),
	ENTRY(mercury____Compare___unify_proc__unify_proc_id_0_0),
	(Integer) 6,
	(Word *) &mercury_data_unify_proc__type_ctor_functors_unify_proc_id_0,
	(Word *) &mercury_data_unify_proc__type_ctor_layout_unify_proc_id_0,
	MR_string_const("unify_proc", 10),
	MR_string_const("unify_proc_id", 13),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_unify_proc__type_ctor_info_unify_proc_info_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___unify_proc__unify_proc_info_0_0),
	STATIC(mercury____Index___unify_proc__unify_proc_info_0_0),
	STATIC(mercury____Compare___unify_proc__unify_proc_info_0_0),
	(Integer) 2,
	(Word *) &mercury_data_unify_proc__type_ctor_functors_unify_proc_info_0,
	(Word *) &mercury_data_unify_proc__type_ctor_layout_unify_proc_info_0,
	MR_string_const("unify_proc", 10),
	MR_string_const("unify_proc_info", 15),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_unify_proc__type_ctor_info_unify_req_map_0 = {
	(Integer) 0,
	STATIC(mercury____Unify___unify_proc__unify_req_map_0_0),
	STATIC(mercury____Index___unify_proc__unify_req_map_0_0),
	STATIC(mercury____Compare___unify_proc__unify_req_map_0_0),
	(Integer) 6,
	(Word *) &mercury_data_unify_proc__type_ctor_functors_unify_req_map_0,
	(Word *) &mercury_data_unify_proc__type_ctor_layout_unify_req_map_0,
	MR_string_const("unify_proc", 10),
	MR_string_const("unify_req_map", 13),
	(Integer) 3
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_pair_2;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_sym_name_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_int_0;
static const struct mercury_data_unify_proc__common_0_struct mercury_data_unify_proc__common_0 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_prog_data__type_ctor_info_sym_name_0,
	(Word *) &mercury_data___type_ctor_info_int_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_goal__type_ctor_info_uni_mode_0;
static const struct mercury_data_unify_proc__common_1_struct mercury_data_unify_proc__common_1 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_0),
	(Word *) &mercury_data_hlds_goal__type_ctor_info_uni_mode_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_special_pred__type_ctor_info_special_pred_id_0;
static const struct mercury_data_unify_proc__common_2_struct mercury_data_unify_proc__common_2 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_special_pred__type_ctor_info_special_pred_id_0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_0)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_var_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_prog_var_type_0;
static const struct mercury_data_unify_proc__common_3_struct mercury_data_unify_proc__common_3 = {
	(Word *) &mercury_data_term__type_ctor_info_var_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_term_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_tvar_type_0;
static const struct mercury_data_unify_proc__common_4_struct mercury_data_unify_proc__common_4 = {
	(Word *) &mercury_data_term__type_ctor_info_term_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0
};

static const struct mercury_data_unify_proc__common_5_struct mercury_data_unify_proc__common_5 = {
	(Word *) &mercury_data_term__type_ctor_info_var_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_string_0;
static const struct mercury_data_unify_proc__common_6_struct mercury_data_unify_proc__common_6 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data___type_ctor_info_string_0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_4)
};

static const struct mercury_data_unify_proc__common_7_struct mercury_data_unify_proc__common_7 = {
	MR_string_const("<", 1)
};

static const struct mercury_data_unify_proc__common_8_struct mercury_data_unify_proc__common_8 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_7),
	(Integer) 0
};

static const struct mercury_data_unify_proc__common_9_struct mercury_data_unify_proc__common_9 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_8),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_unify_proc__common_10_struct mercury_data_unify_proc__common_10 = {
	MR_string_const(">", 1)
};

static const struct mercury_data_unify_proc__common_11_struct mercury_data_unify_proc__common_11 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_10),
	(Integer) 0
};

static const struct mercury_data_unify_proc__common_12_struct mercury_data_unify_proc__common_12 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_11),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_unify_proc__common_13_struct mercury_data_unify_proc__common_13 = {
	MR_string_const("=", 1)
};

static const struct mercury_data_unify_proc__common_14_struct mercury_data_unify_proc__common_14 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_13),
	(Integer) 0
};

static const struct mercury_data_unify_proc__common_15_struct mercury_data_unify_proc__common_15 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_14),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_unify_proc__common_16_struct mercury_data_unify_proc__common_16 = {
	MR_string_const("'", 1),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_tree234__type_ctor_info_tree234_2;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_proc_id_0;
static const struct mercury_data_unify_proc__common_17_struct mercury_data_unify_proc__common_17 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_1),
	(Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0
};

static const struct mercury_data_unify_proc__common_18_struct mercury_data_unify_proc__common_18 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_17)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_varset__type_ctor_info_varset_1;
static const struct mercury_data_unify_proc__common_19_struct mercury_data_unify_proc__common_19 = {
	(Word *) &mercury_data_varset__type_ctor_info_varset_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0
};

static const struct mercury_data_unify_proc__common_20_struct mercury_data_unify_proc__common_20 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_3),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_4)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_module__type_ctor_info_module_info_0;
static const struct mercury_data_unify_proc__common_21_struct mercury_data_unify_proc__common_21 = {
	(Word *) &mercury_data_hlds_module__type_ctor_info_module_info_0
};

static const struct mercury_data_unify_proc__common_22_struct mercury_data_unify_proc__common_22 = {
	(Integer) 3,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_19),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_20),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_21),
	MR_string_const("unify_proc_info", 15),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_unify_proc__common_23_struct mercury_data_unify_proc__common_23 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_1)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_queue__type_ctor_info_queue_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
static const struct mercury_data_unify_proc__common_24_struct mercury_data_unify_proc__common_24 = {
	(Word *) &mercury_data_queue__type_ctor_info_queue_1,
	(Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0
};

static const struct mercury_data_unify_proc__common_25_struct mercury_data_unify_proc__common_25 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_24)
};

static const struct mercury_data_unify_proc__common_26_struct mercury_data_unify_proc__common_26 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_17),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_24),
	MR_string_const("proc_requests", 13),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_unify_proc__type_ctor_functors_unify_req_map_0_struct mercury_data_unify_proc__type_ctor_functors_unify_req_map_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_17)
};

static const struct mercury_data_unify_proc__type_ctor_layout_unify_req_map_0_struct mercury_data_unify_proc__type_ctor_layout_unify_req_map_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_unify_proc__common_18),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_unify_proc__common_18),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_unify_proc__common_18),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_unify_proc__common_18)
};

static const struct mercury_data_unify_proc__type_ctor_functors_unify_proc_info_0_struct mercury_data_unify_proc__type_ctor_functors_unify_proc_info_0 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_22)
};

static const struct mercury_data_unify_proc__type_ctor_layout_unify_proc_info_0_struct mercury_data_unify_proc__type_ctor_layout_unify_proc_info_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_unify_proc__common_22),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_unify_proc__type_ctor_functors_unify_proc_id_0_struct mercury_data_unify_proc__type_ctor_functors_unify_proc_id_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_1)
};

static const struct mercury_data_unify_proc__type_ctor_layout_unify_proc_id_0_struct mercury_data_unify_proc__type_ctor_layout_unify_proc_id_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_unify_proc__common_23),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_unify_proc__common_23),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_unify_proc__common_23),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_unify_proc__common_23)
};

static const struct mercury_data_unify_proc__type_ctor_functors_req_queue_0_struct mercury_data_unify_proc__type_ctor_functors_req_queue_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_24)
};

static const struct mercury_data_unify_proc__type_ctor_layout_req_queue_0_struct mercury_data_unify_proc__type_ctor_layout_req_queue_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_unify_proc__common_25),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_unify_proc__common_25),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_unify_proc__common_25),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_unify_proc__common_25)
};

static const struct mercury_data_unify_proc__type_ctor_functors_proc_requests_0_struct mercury_data_unify_proc__type_ctor_functors_proc_requests_0 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_26)
};

static const struct mercury_data_unify_proc__type_ctor_layout_proc_requests_0_struct mercury_data_unify_proc__type_ctor_layout_proc_requests_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_unify_proc__common_26),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};


BEGIN_MODULE(unify_proc_module0)
	init_entry(mercury____Index___unify_proc__unify_proc_info_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___unify_proc__unify_proc_info_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___unify_proc__unify_proc_info_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE


BEGIN_MODULE(unify_proc_module1)
	init_entry(mercury____Index___unify_proc__proc_requests_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___unify_proc__proc_requests_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___unify_proc__proc_requests_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE

Declare_entry(mercury__map__init_1_0);
Declare_entry(mercury__queue__init_1_0);

BEGIN_MODULE(unify_proc_module2)
	init_entry(mercury__unify_proc__init_requests_1_0);
	init_label(mercury__unify_proc__init_requests_1_0_i2);
	init_label(mercury__unify_proc__init_requests_1_0_i3);
BEGIN_CODE

/* code for predicate 'init_requests'/1 in mode 0 */
Define_entry(mercury__unify_proc__init_requests_1_0);
	MR_incr_sp_push_msg(2, "unify_proc:init_requests/1");
	MR_stackvar(2) = (Word) MR_succip;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_1);
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__unify_proc__init_requests_1_0_i2,
		ENTRY(mercury__unify_proc__init_requests_1_0));
Define_label(mercury__unify_proc__init_requests_1_0_i2);
	update_prof_current_proc(LABEL(mercury__unify_proc__init_requests_1_0));
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	call_localret(ENTRY(mercury__queue__init_1_0),
		mercury__unify_proc__init_requests_1_0_i3,
		ENTRY(mercury__unify_proc__init_requests_1_0));
Define_label(mercury__unify_proc__init_requests_1_0_i3);
	update_prof_current_proc(LABEL(mercury__unify_proc__init_requests_1_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__unify_proc__init_requests_1_0, "unify_proc:proc_requests/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE

Declare_entry(mercury__inst_match__inst_is_ground_or_any_2_0);
Declare_entry(mercury__hlds_pred__in_in_unification_proc_id_1_0);
Declare_entry(mercury__hlds_module__module_info_get_proc_requests_2_0);
Declare_entry(mercury__map__search_3_1);
Declare_entry(mercury__type_util__type_id_is_hand_defined_1_0);
Declare_entry(mercury__hlds_module__module_info_get_special_pred_map_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_id_0;
Declare_entry(mercury__map__lookup_3_0);
Declare_entry(mercury__mode_util__in_mode_1_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_mode_0;
Declare_entry(mercury__list__duplicate_3_0);
Declare_entry(mercury__list__append_3_1);
Declare_entry(mercury__map__set_4_1);
Declare_entry(mercury__hlds_module__module_info_set_proc_requests_3_0);

BEGIN_MODULE(unify_proc_module3)
	init_entry(mercury__unify_proc__request_unify_5_0);
	init_label(mercury__unify_proc__request_unify_5_0_i10);
	init_label(mercury__unify_proc__request_unify_5_0_i12);
	init_label(mercury__unify_proc__request_unify_5_0_i7);
	init_label(mercury__unify_proc__request_unify_5_0_i8);
	init_label(mercury__unify_proc__request_unify_5_0_i15);
	init_label(mercury__unify_proc__request_unify_5_0_i18);
	init_label(mercury__unify_proc__request_unify_5_0_i21);
	init_label(mercury__unify_proc__request_unify_5_0_i22);
	init_label(mercury__unify_proc__request_unify_5_0_i5);
	init_label(mercury__unify_proc__request_unify_5_0_i27);
	init_label(mercury__unify_proc__request_unify_5_0_i1006);
	init_label(mercury__unify_proc__request_unify_5_0_i2);
	init_label(mercury__unify_proc__request_unify_5_0_i29);
	init_label(mercury__unify_proc__request_unify_5_0_i30);
	init_label(mercury__unify_proc__request_unify_5_0_i31);
	init_label(mercury__unify_proc__request_unify_5_0_i32);
	init_label(mercury__unify_proc__request_unify_5_0_i33);
	init_label(mercury__unify_proc__request_unify_5_0_i34);
	init_label(mercury__unify_proc__request_unify_5_0_i35);
	init_label(mercury__unify_proc__request_unify_5_0_i36);
BEGIN_CODE

/* code for predicate 'request_unify'/5 in mode 0 */
Define_entry(mercury__unify_proc__request_unify_5_0);
	MR_incr_sp_push_msg(9, "unify_proc:request_unify/5");
	MR_stackvar(9) = (Word) MR_succip;
	r5 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r6 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r7 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), r5, (Integer) 0), (Integer) 1);
	r8 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), r5, (Integer) 0), (Integer) 0);
	if (((Integer) r2 != (Integer) 1))
		GOTO_LABEL(mercury__unify_proc__request_unify_5_0_i8);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = r4;
	r2 = r8;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r6;
	MR_stackvar(6) = r5;
	MR_stackvar(7) = r8;
	MR_stackvar(8) = r7;
	call_localret(ENTRY(mercury__inst_match__inst_is_ground_or_any_2_0),
		mercury__unify_proc__request_unify_5_0_i10,
		ENTRY(mercury__unify_proc__request_unify_5_0));
Define_label(mercury__unify_proc__request_unify_5_0_i10);
	update_prof_current_proc(LABEL(mercury__unify_proc__request_unify_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__unify_proc__request_unify_5_0_i7);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(8);
	call_localret(ENTRY(mercury__inst_match__inst_is_ground_or_any_2_0),
		mercury__unify_proc__request_unify_5_0_i12,
		ENTRY(mercury__unify_proc__request_unify_5_0));
Define_label(mercury__unify_proc__request_unify_5_0_i12);
	update_prof_current_proc(LABEL(mercury__unify_proc__request_unify_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__unify_proc__request_unify_5_0_i7);
	call_localret(ENTRY(mercury__hlds_pred__in_in_unification_proc_id_1_0),
		mercury__unify_proc__request_unify_5_0_i1006,
		ENTRY(mercury__unify_proc__request_unify_5_0));
Define_label(mercury__unify_proc__request_unify_5_0_i7);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	r5 = MR_stackvar(6);
	r8 = MR_stackvar(7);
	r7 = MR_stackvar(8);
Define_label(mercury__unify_proc__request_unify_5_0_i8);
	if (((Integer) r8 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))))
		GOTO_LABEL(mercury__unify_proc__request_unify_5_0_i15);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r6;
	MR_stackvar(6) = r5;
	call_localret(ENTRY(mercury__hlds_pred__in_in_unification_proc_id_1_0),
		mercury__unify_proc__request_unify_5_0_i1006,
		ENTRY(mercury__unify_proc__request_unify_5_0));
Define_label(mercury__unify_proc__request_unify_5_0_i15);
	if (((Integer) r7 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))))
		GOTO_LABEL(mercury__unify_proc__request_unify_5_0_i18);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r6;
	MR_stackvar(6) = r5;
	call_localret(ENTRY(mercury__hlds_pred__in_in_unification_proc_id_1_0),
		mercury__unify_proc__request_unify_5_0_i1006,
		ENTRY(mercury__unify_proc__request_unify_5_0));
Define_label(mercury__unify_proc__request_unify_5_0_i18);
	MR_stackvar(1) = r1;
	r1 = r4;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r6;
	MR_stackvar(6) = r5;
	call_localret(ENTRY(mercury__hlds_module__module_info_get_proc_requests_2_0),
		mercury__unify_proc__request_unify_5_0_i21,
		ENTRY(mercury__unify_proc__request_unify_5_0));
Define_label(mercury__unify_proc__request_unify_5_0_i21);
	update_prof_current_proc(LABEL(mercury__unify_proc__request_unify_5_0));
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_1);
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0;
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__unify_proc__request_unify_5_0_i22,
		ENTRY(mercury__unify_proc__request_unify_5_0));
Define_label(mercury__unify_proc__request_unify_5_0_i22);
	update_prof_current_proc(LABEL(mercury__unify_proc__request_unify_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__unify_proc__request_unify_5_0_i5);
	r1 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__unify_proc__request_unify_5_0_i5);
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__type_util__type_id_is_hand_defined_1_0),
		mercury__unify_proc__request_unify_5_0_i27,
		ENTRY(mercury__unify_proc__request_unify_5_0));
Define_label(mercury__unify_proc__request_unify_5_0_i27);
	update_prof_current_proc(LABEL(mercury__unify_proc__request_unify_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__unify_proc__request_unify_5_0_i2);
Define_label(mercury__unify_proc__request_unify_5_0_i1006);
	update_prof_current_proc(LABEL(mercury__unify_proc__request_unify_5_0));
	r1 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__unify_proc__request_unify_5_0_i2);
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__hlds_module__module_info_get_special_pred_map_2_0),
		mercury__unify_proc__request_unify_5_0_i29,
		ENTRY(mercury__unify_proc__request_unify_5_0));
Define_label(mercury__unify_proc__request_unify_5_0_i29);
	update_prof_current_proc(LABEL(mercury__unify_proc__request_unify_5_0));
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 2, mercury__unify_proc__request_unify_5_0, "origin_lost_in_value_number");
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_2);
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	MR_field(MR_mktag(0), r4, (Integer) 1) = MR_stackvar(5);
	MR_field(MR_mktag(0), r4, (Integer) 0) = (Integer) 0;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__unify_proc__request_unify_5_0_i30,
		ENTRY(mercury__unify_proc__request_unify_5_0));
Define_label(mercury__unify_proc__request_unify_5_0_i30);
	update_prof_current_proc(LABEL(mercury__unify_proc__request_unify_5_0));
	r2 = MR_stackvar(5);
	MR_stackvar(5) = r1;
	r3 = MR_stackvar(6);
	tag_incr_hp_msg(MR_stackvar(6), MR_mktag(1), (Integer) 2, mercury__unify_proc__request_unify_5_0, "list:list/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__unify_proc__request_unify_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), r3, (Integer) 1), (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), r3, (Integer) 0), (Integer) 0);
	MR_field(MR_mktag(1), MR_stackvar(6), (Integer) 0) = r1;
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__unify_proc__request_unify_5_0, "list:list/1");
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__unify_proc__request_unify_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 0) = r1;
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), r3, (Integer) 1), (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), r3, (Integer) 0), (Integer) 1);
	MR_field(MR_mktag(1), MR_stackvar(6), (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__mode_util__in_mode_1_0),
		mercury__unify_proc__request_unify_5_0_i31,
		ENTRY(mercury__unify_proc__request_unify_5_0));
Define_label(mercury__unify_proc__request_unify_5_0_i31);
	update_prof_current_proc(LABEL(mercury__unify_proc__request_unify_5_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_mode_0;
	r2 = MR_stackvar(7);
	call_localret(ENTRY(mercury__list__duplicate_3_0),
		mercury__unify_proc__request_unify_5_0_i32,
		ENTRY(mercury__unify_proc__request_unify_5_0));
Define_label(mercury__unify_proc__request_unify_5_0_i32);
	update_prof_current_proc(LABEL(mercury__unify_proc__request_unify_5_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_mode_0;
	r3 = MR_stackvar(6);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__unify_proc__request_unify_5_0_i33,
		ENTRY(mercury__unify_proc__request_unify_5_0));
Define_label(mercury__unify_proc__request_unify_5_0_i33);
	update_prof_current_proc(LABEL(mercury__unify_proc__request_unify_5_0));
	r2 = r1;
	r1 = MR_stackvar(5);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 1, mercury__unify_proc__request_unify_5_0, "std_util:maybe/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_stackvar(2);
	r5 = MR_stackvar(3);
	r6 = MR_stackvar(4);
	call_localret(STATIC(mercury__unify_proc__request_proc_8_0),
		mercury__unify_proc__request_unify_5_0_i34,
		ENTRY(mercury__unify_proc__request_unify_5_0));
Define_label(mercury__unify_proc__request_unify_5_0_i34);
	update_prof_current_proc(LABEL(mercury__unify_proc__request_unify_5_0));
	MR_stackvar(2) = r1;
	r1 = r2;
	MR_stackvar(3) = r2;
	call_localret(ENTRY(mercury__hlds_module__module_info_get_proc_requests_2_0),
		mercury__unify_proc__request_unify_5_0_i35,
		ENTRY(mercury__unify_proc__request_unify_5_0));
Define_label(mercury__unify_proc__request_unify_5_0_i35);
	update_prof_current_proc(LABEL(mercury__unify_proc__request_unify_5_0));
	r4 = MR_stackvar(1);
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_1);
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0;
	r5 = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__unify_proc__request_unify_5_0_i36,
		ENTRY(mercury__unify_proc__request_unify_5_0));
Define_label(mercury__unify_proc__request_unify_5_0_i36);
	update_prof_current_proc(LABEL(mercury__unify_proc__request_unify_5_0));
	r3 = r1;
	r1 = MR_stackvar(3);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__unify_proc__request_unify_5_0, "unify_proc:proc_requests/0");
	MR_field(MR_mktag(0), r2, (Integer) 0) = r3;
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_const_field(MR_mktag(0), MR_stackvar(1), (Integer) 1);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	tailcall(ENTRY(mercury__hlds_module__module_info_set_proc_requests_3_0),
		ENTRY(mercury__unify_proc__request_unify_5_0));
END_MODULE

Declare_entry(mercury__hlds_module__module_info_preds_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_pred_info_0;
Declare_entry(mercury__list__length_2_0);
Declare_entry(mercury__make_hlds__add_new_proc_10_0);
Declare_entry(mercury__hlds_pred__pred_info_procedures_2_0);
Declare_entry(mercury__hlds_pred__pred_info_clauses_info_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_proc_info_0;
Declare_entry(mercury__hlds_pred__proc_info_set_can_process_3_0);
Declare_entry(mercury__clause_to_proc__copy_clauses_to_proc_4_0);
Declare_entry(mercury__hlds_pred__proc_info_goal_2_0);
Declare_entry(mercury__hlds_goal__set_goal_contexts_3_0);
Declare_entry(mercury__hlds_pred__proc_info_set_goal_3_0);
Declare_entry(mercury__map__det_update_4_0);
Declare_entry(mercury__hlds_pred__pred_info_set_procedures_3_0);
Declare_entry(mercury__hlds_module__module_info_set_preds_3_0);
Declare_entry(mercury__queue__put_3_0);

BEGIN_MODULE(unify_proc_module4)
	init_entry(mercury__unify_proc__request_proc_8_0);
	init_label(mercury__unify_proc__request_proc_8_0_i2);
	init_label(mercury__unify_proc__request_proc_8_0_i3);
	init_label(mercury__unify_proc__request_proc_8_0_i4);
	init_label(mercury__unify_proc__request_proc_8_0_i5);
	init_label(mercury__unify_proc__request_proc_8_0_i6);
	init_label(mercury__unify_proc__request_proc_8_0_i7);
	init_label(mercury__unify_proc__request_proc_8_0_i8);
	init_label(mercury__unify_proc__request_proc_8_0_i9);
	init_label(mercury__unify_proc__request_proc_8_0_i10);
	init_label(mercury__unify_proc__request_proc_8_0_i11);
	init_label(mercury__unify_proc__request_proc_8_0_i12);
	init_label(mercury__unify_proc__request_proc_8_0_i13);
	init_label(mercury__unify_proc__request_proc_8_0_i14);
	init_label(mercury__unify_proc__request_proc_8_0_i15);
	init_label(mercury__unify_proc__request_proc_8_0_i16);
	init_label(mercury__unify_proc__request_proc_8_0_i17);
	init_label(mercury__unify_proc__request_proc_8_0_i18);
	init_label(mercury__unify_proc__request_proc_8_0_i19);
	init_label(mercury__unify_proc__request_proc_8_0_i20);
BEGIN_CODE

/* code for predicate 'request_proc'/8 in mode 0 */
Define_entry(mercury__unify_proc__request_proc_8_0);
	MR_incr_sp_push_msg(9, "unify_proc:request_proc/8");
	MR_stackvar(9) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r6;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r5;
	MR_stackvar(6) = r6;
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__unify_proc__request_proc_8_0_i2,
		ENTRY(mercury__unify_proc__request_proc_8_0));
Define_label(mercury__unify_proc__request_proc_8_0_i2);
	update_prof_current_proc(LABEL(mercury__unify_proc__request_proc_8_0));
	r3 = r1;
	MR_stackvar(7) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__unify_proc__request_proc_8_0_i3,
		ENTRY(mercury__unify_proc__request_proc_8_0));
Define_label(mercury__unify_proc__request_proc_8_0_i3);
	update_prof_current_proc(LABEL(mercury__unify_proc__request_proc_8_0));
	MR_stackvar(8) = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_mode_0;
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__unify_proc__request_proc_8_0_i4,
		ENTRY(mercury__unify_proc__request_proc_8_0));
Define_label(mercury__unify_proc__request_proc_8_0_i4);
	update_prof_current_proc(LABEL(mercury__unify_proc__request_proc_8_0));
	r2 = r1;
	r1 = MR_stackvar(8);
	r3 = MR_stackvar(2);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r5 = MR_stackvar(3);
	r6 = MR_stackvar(4);
	r7 = MR_stackvar(5);
	r8 = (Integer) 1;
	call_localret(ENTRY(mercury__make_hlds__add_new_proc_10_0),
		mercury__unify_proc__request_proc_8_0_i5,
		ENTRY(mercury__unify_proc__request_proc_8_0));
Define_label(mercury__unify_proc__request_proc_8_0_i5);
	update_prof_current_proc(LABEL(mercury__unify_proc__request_proc_8_0));
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r1;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procedures_2_0),
		mercury__unify_proc__request_proc_8_0_i6,
		ENTRY(mercury__unify_proc__request_proc_8_0));
Define_label(mercury__unify_proc__request_proc_8_0_i6);
	update_prof_current_proc(LABEL(mercury__unify_proc__request_proc_8_0));
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_clauses_info_2_0),
		mercury__unify_proc__request_proc_8_0_i7,
		ENTRY(mercury__unify_proc__request_proc_8_0));
Define_label(mercury__unify_proc__request_proc_8_0_i7);
	update_prof_current_proc(LABEL(mercury__unify_proc__request_proc_8_0));
	MR_stackvar(8) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0;
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__unify_proc__request_proc_8_0_i8,
		ENTRY(mercury__unify_proc__request_proc_8_0));
Define_label(mercury__unify_proc__request_proc_8_0_i8);
	update_prof_current_proc(LABEL(mercury__unify_proc__request_proc_8_0));
	r2 = (Integer) 0;
	call_localret(ENTRY(mercury__hlds_pred__proc_info_set_can_process_3_0),
		mercury__unify_proc__request_proc_8_0_i9,
		ENTRY(mercury__unify_proc__request_proc_8_0));
Define_label(mercury__unify_proc__request_proc_8_0_i9);
	update_prof_current_proc(LABEL(mercury__unify_proc__request_proc_8_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(8);
	call_localret(ENTRY(mercury__clause_to_proc__copy_clauses_to_proc_4_0),
		mercury__unify_proc__request_proc_8_0_i10,
		ENTRY(mercury__unify_proc__request_proc_8_0));
Define_label(mercury__unify_proc__request_proc_8_0_i10);
	update_prof_current_proc(LABEL(mercury__unify_proc__request_proc_8_0));
	MR_stackvar(8) = r1;
	call_localret(ENTRY(mercury__hlds_pred__proc_info_goal_2_0),
		mercury__unify_proc__request_proc_8_0_i11,
		ENTRY(mercury__unify_proc__request_proc_8_0));
Define_label(mercury__unify_proc__request_proc_8_0_i11);
	update_prof_current_proc(LABEL(mercury__unify_proc__request_proc_8_0));
	r2 = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__hlds_goal__set_goal_contexts_3_0),
		mercury__unify_proc__request_proc_8_0_i12,
		ENTRY(mercury__unify_proc__request_proc_8_0));
Define_label(mercury__unify_proc__request_proc_8_0_i12);
	update_prof_current_proc(LABEL(mercury__unify_proc__request_proc_8_0));
	r2 = r1;
	r1 = MR_stackvar(8);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_set_goal_3_0),
		mercury__unify_proc__request_proc_8_0_i13,
		ENTRY(mercury__unify_proc__request_proc_8_0));
Define_label(mercury__unify_proc__request_proc_8_0_i13);
	update_prof_current_proc(LABEL(mercury__unify_proc__request_proc_8_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0;
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__unify_proc__request_proc_8_0_i14,
		ENTRY(mercury__unify_proc__request_proc_8_0));
Define_label(mercury__unify_proc__request_proc_8_0_i14);
	update_prof_current_proc(LABEL(mercury__unify_proc__request_proc_8_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_set_procedures_3_0),
		mercury__unify_proc__request_proc_8_0_i15,
		ENTRY(mercury__unify_proc__request_proc_8_0));
Define_label(mercury__unify_proc__request_proc_8_0_i15);
	update_prof_current_proc(LABEL(mercury__unify_proc__request_proc_8_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	r3 = MR_stackvar(7);
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__unify_proc__request_proc_8_0_i16,
		ENTRY(mercury__unify_proc__request_proc_8_0));
Define_label(mercury__unify_proc__request_proc_8_0_i16);
	update_prof_current_proc(LABEL(mercury__unify_proc__request_proc_8_0));
	r2 = r1;
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__hlds_module__module_info_set_preds_3_0),
		mercury__unify_proc__request_proc_8_0_i17,
		ENTRY(mercury__unify_proc__request_proc_8_0));
Define_label(mercury__unify_proc__request_proc_8_0_i17);
	update_prof_current_proc(LABEL(mercury__unify_proc__request_proc_8_0));
	MR_stackvar(3) = r1;
	call_localret(ENTRY(mercury__hlds_module__module_info_get_proc_requests_2_0),
		mercury__unify_proc__request_proc_8_0_i18,
		ENTRY(mercury__unify_proc__request_proc_8_0));
Define_label(mercury__unify_proc__request_proc_8_0_i18);
	update_prof_current_proc(LABEL(mercury__unify_proc__request_proc_8_0));
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__unify_proc__request_proc_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(1);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(2);
	call_localret(ENTRY(mercury__queue__put_3_0),
		mercury__unify_proc__request_proc_8_0_i19,
		ENTRY(mercury__unify_proc__request_proc_8_0));
Define_label(mercury__unify_proc__request_proc_8_0_i19);
	update_prof_current_proc(LABEL(mercury__unify_proc__request_proc_8_0));
	r3 = r1;
	r1 = MR_stackvar(3);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__unify_proc__request_proc_8_0, "unify_proc:proc_requests/0");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_const_field(MR_mktag(0), MR_stackvar(1), (Integer) 0);
	MR_field(MR_mktag(0), r2, (Integer) 1) = r3;
	call_localret(ENTRY(mercury__hlds_module__module_info_set_proc_requests_3_0),
		mercury__unify_proc__request_proc_8_0_i20,
		ENTRY(mercury__unify_proc__request_proc_8_0));
Define_label(mercury__unify_proc__request_proc_8_0_i20);
	update_prof_current_proc(LABEL(mercury__unify_proc__request_proc_8_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE

Declare_entry(mercury__queue__get_3_0);
Declare_entry(mercury__hlds_module__module_info_predids_2_0);
Declare_entry(mercury__list__member_2_0);
Declare_entry(mercury__globals__io_lookup_bool_option_4_0);
Declare_entry(mercury__io__write_string_3_0);
Declare_entry(mercury__hlds_out__write_pred_proc_id_5_0);
Declare_entry(mercury__bool__or_3_0);

BEGIN_MODULE(unify_proc_module5)
	init_entry(mercury__unify_proc__modecheck_queued_procs_8_0);
	init_label(mercury__unify_proc__modecheck_queued_procs_8_0_i2);
	init_label(mercury__unify_proc__modecheck_queued_procs_8_0_i4);
	init_label(mercury__unify_proc__modecheck_queued_procs_8_0_i6);
	init_label(mercury__unify_proc__modecheck_queued_procs_8_0_i7);
	init_label(mercury__unify_proc__modecheck_queued_procs_8_0_i9);
	init_label(mercury__unify_proc__modecheck_queued_procs_8_0_i11);
	init_label(mercury__unify_proc__modecheck_queued_procs_8_0_i14);
	init_label(mercury__unify_proc__modecheck_queued_procs_8_0_i17);
	init_label(mercury__unify_proc__modecheck_queued_procs_8_0_i19);
	init_label(mercury__unify_proc__modecheck_queued_procs_8_0_i20);
	init_label(mercury__unify_proc__modecheck_queued_procs_8_0_i12);
	init_label(mercury__unify_proc__modecheck_queued_procs_8_0_i21);
	init_label(mercury__unify_proc__modecheck_queued_procs_8_0_i22);
	init_label(mercury__unify_proc__modecheck_queued_procs_8_0_i8);
	init_label(mercury__unify_proc__modecheck_queued_procs_8_0_i24);
	init_label(mercury__unify_proc__modecheck_queued_procs_8_0_i25);
	init_label(mercury__unify_proc__modecheck_queued_procs_8_0_i3);
BEGIN_CODE

/* code for predicate 'modecheck_queued_procs'/8 in mode 0 */
Define_entry(mercury__unify_proc__modecheck_queued_procs_8_0);
	MR_incr_sp_push_msg(9, "unify_proc:modecheck_queued_procs/8");
	MR_stackvar(9) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r3;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(6) = r4;
	call_localret(ENTRY(mercury__hlds_module__module_info_get_proc_requests_2_0),
		mercury__unify_proc__modecheck_queued_procs_8_0_i2,
		ENTRY(mercury__unify_proc__modecheck_queued_procs_8_0));
Define_label(mercury__unify_proc__modecheck_queued_procs_8_0_i2);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_queued_procs_8_0));
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(4) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	call_localret(ENTRY(mercury__queue__get_3_0),
		mercury__unify_proc__modecheck_queued_procs_8_0_i4,
		ENTRY(mercury__unify_proc__modecheck_queued_procs_8_0));
Define_label(mercury__unify_proc__modecheck_queued_procs_8_0_i4);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_queued_procs_8_0));
	if (!(r1))
		GOTO_LABEL(mercury__unify_proc__modecheck_queued_procs_8_0_i3);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__unify_proc__modecheck_queued_procs_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(0), MR_stackvar(4), (Integer) 0);
	MR_stackvar(4) = r2;
	r2 = MR_tempr1;
	r1 = MR_stackvar(3);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r3;
	call_localret(ENTRY(mercury__hlds_module__module_info_set_proc_requests_3_0),
		mercury__unify_proc__modecheck_queued_procs_8_0_i6,
		ENTRY(mercury__unify_proc__modecheck_queued_procs_8_0));
	}
Define_label(mercury__unify_proc__modecheck_queued_procs_8_0_i6);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_queued_procs_8_0));
	MR_stackvar(8) = r1;
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_stackvar(4), (Integer) 0);
	call_localret(ENTRY(mercury__hlds_module__module_info_predids_2_0),
		mercury__unify_proc__modecheck_queued_procs_8_0_i7,
		ENTRY(mercury__unify_proc__modecheck_queued_procs_8_0));
Define_label(mercury__unify_proc__modecheck_queued_procs_8_0_i7);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_queued_procs_8_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = MR_stackvar(5);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__unify_proc__modecheck_queued_procs_8_0_i9,
		ENTRY(mercury__unify_proc__modecheck_queued_procs_8_0));
Define_label(mercury__unify_proc__modecheck_queued_procs_8_0_i9);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_queued_procs_8_0));
	if (!(r1))
		GOTO_LABEL(mercury__unify_proc__modecheck_queued_procs_8_0_i8);
	r1 = (Integer) 18;
	r2 = MR_stackvar(6);
	call_localret(ENTRY(mercury__globals__io_lookup_bool_option_4_0),
		mercury__unify_proc__modecheck_queued_procs_8_0_i11,
		ENTRY(mercury__unify_proc__modecheck_queued_procs_8_0));
Define_label(mercury__unify_proc__modecheck_queued_procs_8_0_i11);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_queued_procs_8_0));
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__unify_proc__modecheck_queued_procs_8_0_i12);
	if (((Integer) MR_stackvar(1) != (Integer) 1))
		GOTO_LABEL(mercury__unify_proc__modecheck_queued_procs_8_0_i14);
	r1 = (Word) MR_string_const("% Analyzing modes, determinism, and unique-modes for\n% ", 55);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__unify_proc__modecheck_queued_procs_8_0_i17,
		ENTRY(mercury__unify_proc__modecheck_queued_procs_8_0));
Define_label(mercury__unify_proc__modecheck_queued_procs_8_0_i14);
	r1 = (Word) MR_string_const("% Mode-analyzing ", 17);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__unify_proc__modecheck_queued_procs_8_0_i17,
		ENTRY(mercury__unify_proc__modecheck_queued_procs_8_0));
Define_label(mercury__unify_proc__modecheck_queued_procs_8_0_i17);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_queued_procs_8_0));
	r4 = r1;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(4);
	r3 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r1 = MR_stackvar(8);
	call_localret(ENTRY(mercury__hlds_out__write_pred_proc_id_5_0),
		mercury__unify_proc__modecheck_queued_procs_8_0_i19,
		ENTRY(mercury__unify_proc__modecheck_queued_procs_8_0));
	}
Define_label(mercury__unify_proc__modecheck_queued_procs_8_0_i19);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_queued_procs_8_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\n", 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__unify_proc__modecheck_queued_procs_8_0_i20,
		ENTRY(mercury__unify_proc__modecheck_queued_procs_8_0));
Define_label(mercury__unify_proc__modecheck_queued_procs_8_0_i20);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_queued_procs_8_0));
	r5 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(8);
	GOTO_LABEL(mercury__unify_proc__modecheck_queued_procs_8_0_i21);
Define_label(mercury__unify_proc__modecheck_queued_procs_8_0_i12);
	r5 = r2;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(8);
Define_label(mercury__unify_proc__modecheck_queued_procs_8_0_i21);
	MR_stackvar(1) = r1;
	call_localret(STATIC(mercury__unify_proc__modecheck_queued_proc_9_0),
		mercury__unify_proc__modecheck_queued_procs_8_0_i22,
		ENTRY(mercury__unify_proc__modecheck_queued_procs_8_0));
Define_label(mercury__unify_proc__modecheck_queued_procs_8_0_i22);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_queued_procs_8_0));
	MR_stackvar(4) = r3;
	r3 = r2;
	r2 = r1;
	r1 = MR_stackvar(1);
	localcall(mercury__unify_proc__modecheck_queued_procs_8_0,
		LABEL(mercury__unify_proc__modecheck_queued_procs_8_0_i24),
		ENTRY(mercury__unify_proc__modecheck_queued_procs_8_0));
Define_label(mercury__unify_proc__modecheck_queued_procs_8_0_i8);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(8);
	MR_stackvar(4) = (Integer) 0;
	r4 = MR_stackvar(6);
	localcall(mercury__unify_proc__modecheck_queued_procs_8_0,
		LABEL(mercury__unify_proc__modecheck_queued_procs_8_0_i24),
		ENTRY(mercury__unify_proc__modecheck_queued_procs_8_0));
Define_label(mercury__unify_proc__modecheck_queued_procs_8_0_i24);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_queued_procs_8_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(4);
	MR_stackvar(4) = MR_tempr1;
	MR_stackvar(5) = r2;
	r2 = r3;
	MR_stackvar(7) = r4;
	call_localret(ENTRY(mercury__bool__or_3_0),
		mercury__unify_proc__modecheck_queued_procs_8_0_i25,
		ENTRY(mercury__unify_proc__modecheck_queued_procs_8_0));
	}
Define_label(mercury__unify_proc__modecheck_queued_procs_8_0_i25);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_queued_procs_8_0));
	r3 = r1;
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(5);
	r4 = MR_stackvar(7);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__unify_proc__modecheck_queued_procs_8_0_i3);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(3);
	r3 = (Integer) 0;
	r4 = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE

Declare_entry(mercury__require__error_1_0);

BEGIN_MODULE(unify_proc_module6)
	init_entry(mercury__unify_proc__lookup_mode_num_5_0);
	init_label(mercury__unify_proc__lookup_mode_num_5_0_i7);
	init_label(mercury__unify_proc__lookup_mode_num_5_0_i9);
	init_label(mercury__unify_proc__lookup_mode_num_5_0_i4);
	init_label(mercury__unify_proc__lookup_mode_num_5_0_i1007);
	init_label(mercury__unify_proc__lookup_mode_num_5_0_i5);
	init_label(mercury__unify_proc__lookup_mode_num_5_0_i12);
	init_label(mercury__unify_proc__lookup_mode_num_5_0_i15);
	init_label(mercury__unify_proc__lookup_mode_num_5_0_i18);
	init_label(mercury__unify_proc__lookup_mode_num_5_0_i19);
	init_label(mercury__unify_proc__lookup_mode_num_5_0_i3);
BEGIN_CODE

/* code for predicate 'lookup_mode_num'/5 in mode 0 */
Define_entry(mercury__unify_proc__lookup_mode_num_5_0);
	MR_incr_sp_push_msg(6, "unify_proc:lookup_mode_num/5");
	MR_stackvar(6) = (Word) MR_succip;
	r5 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), r3, (Integer) 0), (Integer) 1);
	r6 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), r3, (Integer) 0), (Integer) 0);
	if (((Integer) r4 != (Integer) 1))
		GOTO_LABEL(mercury__unify_proc__lookup_mode_num_5_0_i1007);
	MR_stackvar(2) = r2;
	r2 = r6;
	MR_stackvar(1) = r1;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r6;
	MR_stackvar(5) = r5;
	call_localret(ENTRY(mercury__inst_match__inst_is_ground_or_any_2_0),
		mercury__unify_proc__lookup_mode_num_5_0_i7,
		ENTRY(mercury__unify_proc__lookup_mode_num_5_0));
Define_label(mercury__unify_proc__lookup_mode_num_5_0_i7);
	update_prof_current_proc(LABEL(mercury__unify_proc__lookup_mode_num_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__unify_proc__lookup_mode_num_5_0_i4);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(5);
	call_localret(ENTRY(mercury__inst_match__inst_is_ground_or_any_2_0),
		mercury__unify_proc__lookup_mode_num_5_0_i9,
		ENTRY(mercury__unify_proc__lookup_mode_num_5_0));
Define_label(mercury__unify_proc__lookup_mode_num_5_0_i9);
	update_prof_current_proc(LABEL(mercury__unify_proc__lookup_mode_num_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__unify_proc__lookup_mode_num_5_0_i4);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(ENTRY(mercury__hlds_pred__in_in_unification_proc_id_1_0),
		ENTRY(mercury__unify_proc__lookup_mode_num_5_0));
Define_label(mercury__unify_proc__lookup_mode_num_5_0_i4);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r6 = MR_stackvar(4);
	r5 = MR_stackvar(5);
	GOTO_LABEL(mercury__unify_proc__lookup_mode_num_5_0_i5);
Define_label(mercury__unify_proc__lookup_mode_num_5_0_i1007);
	if (((Integer) r6 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))))
		GOTO_LABEL(mercury__unify_proc__lookup_mode_num_5_0_i12);
	MR_decr_sp_pop_msg(6);
	tailcall(ENTRY(mercury__hlds_pred__in_in_unification_proc_id_1_0),
		ENTRY(mercury__unify_proc__lookup_mode_num_5_0));
Define_label(mercury__unify_proc__lookup_mode_num_5_0_i5);
	if (((Integer) r6 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))))
		GOTO_LABEL(mercury__unify_proc__lookup_mode_num_5_0_i12);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(ENTRY(mercury__hlds_pred__in_in_unification_proc_id_1_0),
		ENTRY(mercury__unify_proc__lookup_mode_num_5_0));
Define_label(mercury__unify_proc__lookup_mode_num_5_0_i12);
	if (((Integer) r5 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))))
		GOTO_LABEL(mercury__unify_proc__lookup_mode_num_5_0_i15);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(ENTRY(mercury__hlds_pred__in_in_unification_proc_id_1_0),
		ENTRY(mercury__unify_proc__lookup_mode_num_5_0));
Define_label(mercury__unify_proc__lookup_mode_num_5_0_i15);
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__hlds_module__module_info_get_proc_requests_2_0),
		mercury__unify_proc__lookup_mode_num_5_0_i18,
		ENTRY(mercury__unify_proc__lookup_mode_num_5_0));
Define_label(mercury__unify_proc__lookup_mode_num_5_0_i18);
	update_prof_current_proc(LABEL(mercury__unify_proc__lookup_mode_num_5_0));
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 2, mercury__unify_proc__lookup_mode_num_5_0, "origin_lost_in_value_number");
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_1);
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0;
	MR_field(MR_mktag(0), r4, (Integer) 1) = MR_stackvar(3);
	MR_field(MR_mktag(0), r4, (Integer) 0) = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__unify_proc__lookup_mode_num_5_0_i19,
		ENTRY(mercury__unify_proc__lookup_mode_num_5_0));
Define_label(mercury__unify_proc__lookup_mode_num_5_0_i19);
	update_prof_current_proc(LABEL(mercury__unify_proc__lookup_mode_num_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__unify_proc__lookup_mode_num_5_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__unify_proc__lookup_mode_num_5_0_i3);
	r1 = (Word) MR_string_const("unify_proc.m: unify_proc__search_num failed", 43);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__unify_proc__lookup_mode_num_5_0));
END_MODULE

Declare_entry(mercury__hlds_module__module_info_globals_2_0);
Declare_entry(mercury__globals__lookup_bool_option_3_0);
Declare_entry(mercury__special_pred__special_pred_info_6_0);
Declare_entry(mercury__varset__init_1_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_hlds_pred__type_ctor_info_type_info_locn_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_class_constraint_0;

BEGIN_MODULE(unify_proc_module7)
	init_entry(mercury__unify_proc__generate_clause_info_6_0);
	init_label(mercury__unify_proc__generate_clause_info_6_0_i2);
	init_label(mercury__unify_proc__generate_clause_info_6_0_i3);
	init_label(mercury__unify_proc__generate_clause_info_6_0_i4);
	init_label(mercury__unify_proc__generate_clause_info_6_0_i6);
	init_label(mercury__unify_proc__generate_clause_info_6_0_i7);
	init_label(mercury__unify_proc__generate_clause_info_6_0_i8);
	init_label(mercury__unify_proc__generate_clause_info_6_0_i9);
	init_label(mercury__unify_proc__generate_clause_info_6_0_i10);
	init_label(mercury__unify_proc__generate_clause_info_6_0_i18);
	init_label(mercury__unify_proc__generate_clause_info_6_0_i13);
	init_label(mercury__unify_proc__generate_clause_info_6_0_i24);
	init_label(mercury__unify_proc__generate_clause_info_6_0_i19);
	init_label(mercury__unify_proc__generate_clause_info_6_0_i31);
	init_label(mercury__unify_proc__generate_clause_info_6_0_i25);
	init_label(mercury__unify_proc__generate_clause_info_6_0_i11);
	init_label(mercury__unify_proc__generate_clause_info_6_0_i36);
	init_label(mercury__unify_proc__generate_clause_info_6_0_i37);
	init_label(mercury__unify_proc__generate_clause_info_6_0_i38);
BEGIN_CODE

/* code for predicate 'generate_clause_info'/6 in mode 0 */
Define_entry(mercury__unify_proc__generate_clause_info_6_0);
	MR_incr_sp_push_msg(8, "unify_proc:generate_clause_info/6");
	MR_stackvar(8) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r5;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r5;
	call_localret(ENTRY(mercury__hlds_module__module_info_globals_2_0),
		mercury__unify_proc__generate_clause_info_6_0_i2,
		ENTRY(mercury__unify_proc__generate_clause_info_6_0));
Define_label(mercury__unify_proc__generate_clause_info_6_0_i2);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_clause_info_6_0));
	r2 = (Integer) 111;
	call_localret(ENTRY(mercury__globals__lookup_bool_option_3_0),
		mercury__unify_proc__generate_clause_info_6_0_i3,
		ENTRY(mercury__unify_proc__generate_clause_info_6_0));
Define_label(mercury__unify_proc__generate_clause_info_6_0_i3);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_clause_info_6_0));
	if ((MR_tag(MR_stackvar(3)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__unify_proc__generate_clause_info_6_0_i4);
	MR_stackvar(2) = r1;
	r2 = MR_const_field(MR_mktag(3), MR_stackvar(3), (Integer) 0);
	r1 = MR_stackvar(1);
	GOTO_LABEL(mercury__unify_proc__generate_clause_info_6_0_i6);
Define_label(mercury__unify_proc__generate_clause_info_6_0_i4);
	r2 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(1);
Define_label(mercury__unify_proc__generate_clause_info_6_0_i6);
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__special_pred__special_pred_info_6_0),
		mercury__unify_proc__generate_clause_info_6_0_i7,
		ENTRY(mercury__unify_proc__generate_clause_info_6_0));
Define_label(mercury__unify_proc__generate_clause_info_6_0_i7);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_clause_info_6_0));
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	MR_stackvar(6) = r2;
	call_localret(ENTRY(mercury__varset__init_1_0),
		mercury__unify_proc__generate_clause_info_6_0_i8,
		ENTRY(mercury__unify_proc__generate_clause_info_6_0));
Define_label(mercury__unify_proc__generate_clause_info_6_0_i8);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_clause_info_6_0));
	MR_stackvar(7) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_3);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_4);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__unify_proc__generate_clause_info_6_0_i9,
		ENTRY(mercury__unify_proc__generate_clause_info_6_0));
Define_label(mercury__unify_proc__generate_clause_info_6_0_i9);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_clause_info_6_0));
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 3, mercury__unify_proc__generate_clause_info_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r4, (Integer) 1) = r1;
	r1 = MR_stackvar(6);
	r2 = (Word) MR_string_const("HeadVar__", 9);
	r3 = (Integer) 1;
	MR_field(MR_mktag(0), r4, (Integer) 2) = MR_stackvar(5);
	MR_field(MR_mktag(0), r4, (Integer) 0) = MR_stackvar(7);
	call_localret(STATIC(mercury__unify_proc__make_fresh_named_vars_from_types_6_0),
		mercury__unify_proc__generate_clause_info_6_0_i10,
		ENTRY(mercury__unify_proc__generate_clause_info_6_0));
Define_label(mercury__unify_proc__generate_clause_info_6_0_i10);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_clause_info_6_0));
	if (((Integer) MR_stackvar(2) != (Integer) 1))
		GOTO_LABEL(mercury__unify_proc__generate_clause_info_6_0_i11);
	if (((Integer) MR_stackvar(1) != (Integer) 0))
		GOTO_LABEL(mercury__unify_proc__generate_clause_info_6_0_i13);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_proc__generate_clause_info_6_0_i13);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_proc__generate_clause_info_6_0_i13);
	if (((Integer) MR_const_field(MR_mktag(1), r3, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_proc__generate_clause_info_6_0_i13);
	r5 = r2;
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = r1;
	r3 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	r1 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	call_localret(STATIC(mercury__unify_proc__generate_unify_clauses_7_0),
		mercury__unify_proc__generate_clause_info_6_0_i18,
		ENTRY(mercury__unify_proc__generate_clause_info_6_0));
Define_label(mercury__unify_proc__generate_clause_info_6_0_i18);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_clause_info_6_0));
	MR_stackvar(2) = r1;
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_5);
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_type_info_locn_0;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__unify_proc__generate_clause_info_6_0_i37,
		ENTRY(mercury__unify_proc__generate_clause_info_6_0));
Define_label(mercury__unify_proc__generate_clause_info_6_0_i13);
	if (((Integer) MR_stackvar(1) != (Integer) 1))
		GOTO_LABEL(mercury__unify_proc__generate_clause_info_6_0_i19);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_proc__generate_clause_info_6_0_i19);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_proc__generate_clause_info_6_0_i19);
	if (((Integer) MR_const_field(MR_mktag(1), r3, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_proc__generate_clause_info_6_0_i19);
	r5 = r2;
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = r1;
	r3 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	r1 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	call_localret(STATIC(mercury__unify_proc__generate_index_clauses_7_0),
		mercury__unify_proc__generate_clause_info_6_0_i24,
		ENTRY(mercury__unify_proc__generate_clause_info_6_0));
Define_label(mercury__unify_proc__generate_clause_info_6_0_i24);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_clause_info_6_0));
	MR_stackvar(2) = r1;
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_5);
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_type_info_locn_0;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__unify_proc__generate_clause_info_6_0_i37,
		ENTRY(mercury__unify_proc__generate_clause_info_6_0));
Define_label(mercury__unify_proc__generate_clause_info_6_0_i19);
	if (((Integer) MR_stackvar(1) != (Integer) 2))
		GOTO_LABEL(mercury__unify_proc__generate_clause_info_6_0_i25);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_proc__generate_clause_info_6_0_i25);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_proc__generate_clause_info_6_0_i25);
	if (((Integer) MR_const_field(MR_mktag(1), r3, (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_proc__generate_clause_info_6_0_i25);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r3, (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_proc__generate_clause_info_6_0_i25);
	r6 = r2;
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r4 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r3, (Integer) 1), (Integer) 0);
	MR_stackvar(1) = r1;
	r3 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	r1 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	call_localret(STATIC(mercury__unify_proc__generate_compare_clauses_8_0),
		mercury__unify_proc__generate_clause_info_6_0_i31,
		ENTRY(mercury__unify_proc__generate_clause_info_6_0));
Define_label(mercury__unify_proc__generate_clause_info_6_0_i31);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_clause_info_6_0));
	MR_stackvar(2) = r1;
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_5);
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_type_info_locn_0;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__unify_proc__generate_clause_info_6_0_i37,
		ENTRY(mercury__unify_proc__generate_clause_info_6_0));
Define_label(mercury__unify_proc__generate_clause_info_6_0_i25);
	MR_stackvar(1) = r1;
	r1 = (Word) MR_string_const("unknown special pred", 20);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__unify_proc__generate_clause_info_6_0_i36,
		ENTRY(mercury__unify_proc__generate_clause_info_6_0));
Define_label(mercury__unify_proc__generate_clause_info_6_0_i11);
	MR_stackvar(1) = r1;
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_5);
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_type_info_locn_0;
	MR_stackvar(2) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
Define_label(mercury__unify_proc__generate_clause_info_6_0_i36);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_clause_info_6_0));
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__unify_proc__generate_clause_info_6_0_i37,
		ENTRY(mercury__unify_proc__generate_clause_info_6_0));
Define_label(mercury__unify_proc__generate_clause_info_6_0_i37);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_clause_info_6_0));
	MR_stackvar(5) = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_class_constraint_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_3);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__unify_proc__generate_clause_info_6_0_i38,
		ENTRY(mercury__unify_proc__generate_clause_info_6_0));
Define_label(mercury__unify_proc__generate_clause_info_6_0_i38);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_clause_info_6_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 7, mercury__unify_proc__generate_clause_info_6_0, "origin_lost_in_value_number");
	r3 = MR_stackvar(4);
	MR_field(MR_mktag(0), r1, (Integer) 6) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_stackvar(5);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_stackvar(2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_stackvar(1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
END_MODULE

Declare_entry(mercury__modes__modecheck_proc_8_0);
Declare_entry(mercury__io__set_exit_status_3_0);
Declare_entry(mercury__hlds_module__module_info_remove_predid_3_0);
Declare_entry(mercury__switch_detection__detect_switches_in_proc_4_0);
Declare_entry(mercury__cse_detection__detect_cse_in_proc_6_0);
Declare_entry(mercury__det_analysis__determinism_check_proc_6_0);
Declare_entry(mercury__hlds_module__module_info_pred_proc_info_5_0);
Declare_entry(mercury__unique_modes__check_proc_7_0);

BEGIN_MODULE(unify_proc_module8)
	init_entry(mercury__unify_proc__modecheck_queued_proc_9_0);
	init_label(mercury__unify_proc__modecheck_queued_proc_9_0_i2);
	init_label(mercury__unify_proc__modecheck_queued_proc_9_0_i3);
	init_label(mercury__unify_proc__modecheck_queued_proc_9_0_i4);
	init_label(mercury__unify_proc__modecheck_queued_proc_9_0_i5);
	init_label(mercury__unify_proc__modecheck_queued_proc_9_0_i6);
	init_label(mercury__unify_proc__modecheck_queued_proc_9_0_i7);
	init_label(mercury__unify_proc__modecheck_queued_proc_9_0_i8);
	init_label(mercury__unify_proc__modecheck_queued_proc_9_0_i9);
	init_label(mercury__unify_proc__modecheck_queued_proc_9_0_i10);
	init_label(mercury__unify_proc__modecheck_queued_proc_9_0_i11);
	init_label(mercury__unify_proc__modecheck_queued_proc_9_0_i16);
	init_label(mercury__unify_proc__modecheck_queued_proc_9_0_i17);
	init_label(mercury__unify_proc__modecheck_queued_proc_9_0_i13);
	init_label(mercury__unify_proc__modecheck_queued_proc_9_0_i20);
	init_label(mercury__unify_proc__modecheck_queued_proc_9_0_i21);
	init_label(mercury__unify_proc__modecheck_queued_proc_9_0_i22);
	init_label(mercury__unify_proc__modecheck_queued_proc_9_0_i23);
	init_label(mercury__unify_proc__modecheck_queued_proc_9_0_i24);
	init_label(mercury__unify_proc__modecheck_queued_proc_9_0_i25);
	init_label(mercury__unify_proc__modecheck_queued_proc_9_0_i26);
	init_label(mercury__unify_proc__modecheck_queued_proc_9_0_i27);
	init_label(mercury__unify_proc__modecheck_queued_proc_9_0_i28);
	init_label(mercury__unify_proc__modecheck_queued_proc_9_0_i29);
	init_label(mercury__unify_proc__modecheck_queued_proc_9_0_i30);
	init_label(mercury__unify_proc__modecheck_queued_proc_9_0_i18);
BEGIN_CODE

/* code for predicate 'modecheck_queued_proc'/9 in mode 0 */
Define_static(mercury__unify_proc__modecheck_queued_proc_9_0);
	MR_incr_sp_push_msg(10, "unify_proc:modecheck_queued_proc/9");
	MR_stackvar(10) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	r1 = r4;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	call_localret(ENTRY(mercury__hlds_module__module_info_preds_2_0),
		mercury__unify_proc__modecheck_queued_proc_9_0_i2,
		STATIC(mercury__unify_proc__modecheck_queued_proc_9_0));
Define_label(mercury__unify_proc__modecheck_queued_proc_9_0_i2);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_queued_proc_9_0));
	r3 = r1;
	MR_stackvar(7) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	r4 = MR_stackvar(5);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__unify_proc__modecheck_queued_proc_9_0_i3,
		STATIC(mercury__unify_proc__modecheck_queued_proc_9_0));
Define_label(mercury__unify_proc__modecheck_queued_proc_9_0_i3);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_queued_proc_9_0));
	MR_stackvar(8) = r1;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procedures_2_0),
		mercury__unify_proc__modecheck_queued_proc_9_0_i4,
		STATIC(mercury__unify_proc__modecheck_queued_proc_9_0));
Define_label(mercury__unify_proc__modecheck_queued_proc_9_0_i4);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_queued_proc_9_0));
	r3 = r1;
	MR_stackvar(9) = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0;
	r4 = MR_stackvar(6);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__unify_proc__modecheck_queued_proc_9_0_i5,
		STATIC(mercury__unify_proc__modecheck_queued_proc_9_0));
Define_label(mercury__unify_proc__modecheck_queued_proc_9_0_i5);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_queued_proc_9_0));
	r2 = (Integer) 1;
	call_localret(ENTRY(mercury__hlds_pred__proc_info_set_can_process_3_0),
		mercury__unify_proc__modecheck_queued_proc_9_0_i6,
		STATIC(mercury__unify_proc__modecheck_queued_proc_9_0));
Define_label(mercury__unify_proc__modecheck_queued_proc_9_0_i6);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_queued_proc_9_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0;
	r3 = MR_stackvar(9);
	r4 = MR_stackvar(6);
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__unify_proc__modecheck_queued_proc_9_0_i7,
		STATIC(mercury__unify_proc__modecheck_queued_proc_9_0));
Define_label(mercury__unify_proc__modecheck_queued_proc_9_0_i7);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_queued_proc_9_0));
	r2 = r1;
	r1 = MR_stackvar(8);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_set_procedures_3_0),
		mercury__unify_proc__modecheck_queued_proc_9_0_i8,
		STATIC(mercury__unify_proc__modecheck_queued_proc_9_0));
Define_label(mercury__unify_proc__modecheck_queued_proc_9_0_i8);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_queued_proc_9_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	r3 = MR_stackvar(7);
	r4 = MR_stackvar(5);
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__unify_proc__modecheck_queued_proc_9_0_i9,
		STATIC(mercury__unify_proc__modecheck_queued_proc_9_0));
Define_label(mercury__unify_proc__modecheck_queued_proc_9_0_i9);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_queued_proc_9_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__hlds_module__module_info_set_preds_3_0),
		mercury__unify_proc__modecheck_queued_proc_9_0_i10,
		STATIC(mercury__unify_proc__modecheck_queued_proc_9_0));
Define_label(mercury__unify_proc__modecheck_queued_proc_9_0_i10);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_queued_proc_9_0));
	r3 = r1;
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(5);
	r4 = MR_stackvar(4);
	call_localret(ENTRY(mercury__modes__modecheck_proc_8_0),
		mercury__unify_proc__modecheck_queued_proc_9_0_i11,
		STATIC(mercury__unify_proc__modecheck_queued_proc_9_0));
Define_label(mercury__unify_proc__modecheck_queued_proc_9_0_i11);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_queued_proc_9_0));
	if (((Integer) r2 == (Integer) 0))
		GOTO_LABEL(mercury__unify_proc__modecheck_queued_proc_9_0_i13);
	MR_stackvar(7) = r1;
	r1 = (Integer) 1;
	r2 = r4;
	MR_stackvar(8) = r3;
	call_localret(ENTRY(mercury__io__set_exit_status_3_0),
		mercury__unify_proc__modecheck_queued_proc_9_0_i16,
		STATIC(mercury__unify_proc__modecheck_queued_proc_9_0));
Define_label(mercury__unify_proc__modecheck_queued_proc_9_0_i16);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_queued_proc_9_0));
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(7);
	r2 = MR_stackvar(5);
	MR_stackvar(3) = MR_stackvar(2);
	call_localret(ENTRY(mercury__hlds_module__module_info_remove_predid_3_0),
		mercury__unify_proc__modecheck_queued_proc_9_0_i17,
		STATIC(mercury__unify_proc__modecheck_queued_proc_9_0));
Define_label(mercury__unify_proc__modecheck_queued_proc_9_0_i17);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_queued_proc_9_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	r3 = MR_stackvar(8);
	r4 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
Define_label(mercury__unify_proc__modecheck_queued_proc_9_0_i13);
	if (((Integer) MR_stackvar(1) != (Integer) 1))
		GOTO_LABEL(mercury__unify_proc__modecheck_queued_proc_9_0_i18);
	MR_stackvar(8) = r3;
	r3 = r1;
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(5);
	MR_stackvar(9) = r4;
	call_localret(ENTRY(mercury__switch_detection__detect_switches_in_proc_4_0),
		mercury__unify_proc__modecheck_queued_proc_9_0_i20,
		STATIC(mercury__unify_proc__modecheck_queued_proc_9_0));
Define_label(mercury__unify_proc__modecheck_queued_proc_9_0_i20);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_queued_proc_9_0));
	r3 = r1;
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(5);
	r4 = MR_stackvar(9);
	call_localret(ENTRY(mercury__cse_detection__detect_cse_in_proc_6_0),
		mercury__unify_proc__modecheck_queued_proc_9_0_i21,
		STATIC(mercury__unify_proc__modecheck_queued_proc_9_0));
Define_label(mercury__unify_proc__modecheck_queued_proc_9_0_i21);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_queued_proc_9_0));
	r3 = r1;
	r1 = MR_stackvar(6);
	r4 = r2;
	r2 = MR_stackvar(5);
	call_localret(ENTRY(mercury__det_analysis__determinism_check_proc_6_0),
		mercury__unify_proc__modecheck_queued_proc_9_0_i22,
		STATIC(mercury__unify_proc__modecheck_queued_proc_9_0));
Define_label(mercury__unify_proc__modecheck_queued_proc_9_0_i22);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_queued_proc_9_0));
	MR_stackvar(3) = r2;
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(6);
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__hlds_module__module_info_pred_proc_info_5_0),
		mercury__unify_proc__modecheck_queued_proc_9_0_i23,
		STATIC(mercury__unify_proc__modecheck_queued_proc_9_0));
Define_label(mercury__unify_proc__modecheck_queued_proc_9_0_i23);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_queued_proc_9_0));
	MR_stackvar(4) = r2;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(5);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__unify_proc__modecheck_queued_proc_9_0_i24,
		STATIC(mercury__unify_proc__modecheck_queued_proc_9_0));
Define_label(mercury__unify_proc__modecheck_queued_proc_9_0_i24);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_queued_proc_9_0));
	MR_stackvar(7) = r1;
	call_localret(ENTRY(mercury__hlds_pred__pred_info_procedures_2_0),
		mercury__unify_proc__modecheck_queued_proc_9_0_i25,
		STATIC(mercury__unify_proc__modecheck_queued_proc_9_0));
Define_label(mercury__unify_proc__modecheck_queued_proc_9_0_i25);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_queued_proc_9_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_info_0;
	r4 = MR_stackvar(6);
	r5 = MR_stackvar(4);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__unify_proc__modecheck_queued_proc_9_0_i26,
		STATIC(mercury__unify_proc__modecheck_queued_proc_9_0));
Define_label(mercury__unify_proc__modecheck_queued_proc_9_0_i26);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_queued_proc_9_0));
	r2 = r1;
	r1 = MR_stackvar(7);
	call_localret(ENTRY(mercury__hlds_pred__pred_info_set_procedures_3_0),
		mercury__unify_proc__modecheck_queued_proc_9_0_i27,
		STATIC(mercury__unify_proc__modecheck_queued_proc_9_0));
Define_label(mercury__unify_proc__modecheck_queued_proc_9_0_i27);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_queued_proc_9_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_info_0;
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(5);
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__unify_proc__modecheck_queued_proc_9_0_i28,
		STATIC(mercury__unify_proc__modecheck_queued_proc_9_0));
Define_label(mercury__unify_proc__modecheck_queued_proc_9_0_i28);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_queued_proc_9_0));
	r4 = MR_stackvar(3);
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(1);
	call_localret(ENTRY(mercury__unique_modes__check_proc_7_0),
		mercury__unify_proc__modecheck_queued_proc_9_0_i29,
		STATIC(mercury__unify_proc__modecheck_queued_proc_9_0));
Define_label(mercury__unify_proc__modecheck_queued_proc_9_0_i29);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_queued_proc_9_0));
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(8);
	MR_stackvar(4) = r3;
	call_localret(ENTRY(mercury__bool__or_3_0),
		mercury__unify_proc__modecheck_queued_proc_9_0_i30,
		STATIC(mercury__unify_proc__modecheck_queued_proc_9_0));
Define_label(mercury__unify_proc__modecheck_queued_proc_9_0_i30);
	update_prof_current_proc(LABEL(mercury__unify_proc__modecheck_queued_proc_9_0));
	r3 = r1;
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(1);
	r4 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
Define_label(mercury__unify_proc__modecheck_queued_proc_9_0_i18);
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_pred__invalid_pred_id_1_0);
Declare_entry(mercury__hlds_pred__invalid_proc_id_1_0);
Declare_entry(mercury__hlds_goal__goal_info_init_1_0);
Declare_entry(mercury__hlds_goal__goal_info_set_context_3_0);
Declare_entry(mercury__fn__type_util__int_type_0_0);
Declare_entry(mercury__hlds_goal__conj_list_to_goal_3_0);
Declare_entry(mercury__make_hlds__create_atomic_unification_6_0);

BEGIN_MODULE(unify_proc_module9)
	init_entry(mercury__unify_proc__generate_unify_clauses_7_0);
	init_label(mercury__unify_proc__generate_unify_clauses_7_0_i1022);
	init_label(mercury__unify_proc__generate_unify_clauses_7_0_i6);
	init_label(mercury__unify_proc__generate_unify_clauses_7_0_i9);
	init_label(mercury__unify_proc__generate_unify_clauses_7_0_i10);
	init_label(mercury__unify_proc__generate_unify_clauses_7_0_i11);
	init_label(mercury__unify_proc__generate_unify_clauses_7_0_i12);
	init_label(mercury__unify_proc__generate_unify_clauses_7_0_i7);
	init_label(mercury__unify_proc__generate_unify_clauses_7_0_i16);
	init_label(mercury__unify_proc__generate_unify_clauses_7_0_i17);
	init_label(mercury__unify_proc__generate_unify_clauses_7_0_i18);
	init_label(mercury__unify_proc__generate_unify_clauses_7_0_i19);
	init_label(mercury__unify_proc__generate_unify_clauses_7_0_i20);
	init_label(mercury__unify_proc__generate_unify_clauses_7_0_i21);
	init_label(mercury__unify_proc__generate_unify_clauses_7_0_i22);
	init_label(mercury__unify_proc__generate_unify_clauses_7_0_i23);
	init_label(mercury__unify_proc__generate_unify_clauses_7_0_i24);
	init_label(mercury__unify_proc__generate_unify_clauses_7_0_i14);
	init_label(mercury__unify_proc__generate_unify_clauses_7_0_i1024);
	init_label(mercury__unify_proc__generate_unify_clauses_7_0_i31);
	init_label(mercury__unify_proc__generate_unify_clauses_7_0_i32);
BEGIN_CODE

/* code for predicate 'generate_unify_clauses'/7 in mode 0 */
Define_static(mercury__unify_proc__generate_unify_clauses_7_0);
	MR_incr_sp_push_msg(8, "unify_proc:generate_unify_clauses/7");
	MR_stackvar(8) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__unify_proc__generate_unify_clauses_7_0_i1022) AND
		LABEL(mercury__unify_proc__generate_unify_clauses_7_0_i6) AND
		LABEL(mercury__unify_proc__generate_unify_clauses_7_0_i1024) AND
		LABEL(mercury__unify_proc__generate_unify_clauses_7_0_i31));
Define_label(mercury__unify_proc__generate_unify_clauses_7_0_i1022);
	r1 = (Word) MR_string_const("trying to create unify proc for abstract type", 45);
	MR_decr_sp_pop_msg(8);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__unify_proc__generate_unify_clauses_7_0));
Define_label(mercury__unify_proc__generate_unify_clauses_7_0_i6);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 3);
	r7 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r6 = MR_const_field(MR_mktag(1), r1, (Integer) 2);
	if (((Integer) MR_tempr1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_proc__generate_unify_clauses_7_0_i7);
	MR_stackvar(5) = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	call_localret(ENTRY(mercury__hlds_pred__invalid_pred_id_1_0),
		mercury__unify_proc__generate_unify_clauses_7_0_i9,
		STATIC(mercury__unify_proc__generate_unify_clauses_7_0));
	}
Define_label(mercury__unify_proc__generate_unify_clauses_7_0_i9);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_unify_clauses_7_0));
	MR_stackvar(6) = r1;
	call_localret(ENTRY(mercury__hlds_pred__invalid_proc_id_1_0),
		mercury__unify_proc__generate_unify_clauses_7_0_i10,
		STATIC(mercury__unify_proc__generate_unify_clauses_7_0));
Define_label(mercury__unify_proc__generate_unify_clauses_7_0_i10);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_unify_clauses_7_0));
	r2 = MR_stackvar(5);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 6, mercury__unify_proc__generate_unify_clauses_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = r1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(6);
	MR_stackvar(5) = r3;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_unify_clauses_7_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_unify_clauses_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = r1;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(5);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 5) = r2;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 4) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 3) = (Integer) 2;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 2) = r3;
	MR_field(MR_mktag(1), r1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(2);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_init_1_0),
		mercury__unify_proc__generate_unify_clauses_7_0_i11,
		STATIC(mercury__unify_proc__generate_unify_clauses_7_0));
	}
Define_label(mercury__unify_proc__generate_unify_clauses_7_0_i11);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_unify_clauses_7_0));
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_set_context_3_0),
		mercury__unify_proc__generate_unify_clauses_7_0_i12,
		STATIC(mercury__unify_proc__generate_unify_clauses_7_0));
Define_label(mercury__unify_proc__generate_unify_clauses_7_0_i12);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_unify_clauses_7_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_unify_clauses_7_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_unify_clauses_7_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__unify_proc__generate_unify_clauses_7_0, "std_util:pair/2");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(5);
	MR_field(MR_mktag(0), r2, (Integer) 1) = r3;
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	tailcall(STATIC(mercury__unify_proc__quantify_clause_body_6_0),
		STATIC(mercury__unify_proc__generate_unify_clauses_7_0));
Define_label(mercury__unify_proc__generate_unify_clauses_7_0_i7);
	if (((Integer) r6 != (Integer) 1))
		GOTO_LABEL(mercury__unify_proc__generate_unify_clauses_7_0_i14);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	call_localret(ENTRY(mercury__fn__type_util__int_type_0_0),
		mercury__unify_proc__generate_unify_clauses_7_0_i16,
		STATIC(mercury__unify_proc__generate_unify_clauses_7_0));
Define_label(mercury__unify_proc__generate_unify_clauses_7_0_i16);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_unify_clauses_7_0));
	r2 = MR_stackvar(4);
	MR_stackvar(4) = r1;
	call_localret(STATIC(mercury__unify_proc__info_new_var_4_0),
		mercury__unify_proc__generate_unify_clauses_7_0_i17,
		STATIC(mercury__unify_proc__generate_unify_clauses_7_0));
Define_label(mercury__unify_proc__generate_unify_clauses_7_0_i17);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_unify_clauses_7_0));
	r3 = r1;
	r1 = MR_stackvar(4);
	MR_stackvar(4) = r3;
	call_localret(STATIC(mercury__unify_proc__info_new_var_4_0),
		mercury__unify_proc__generate_unify_clauses_7_0_i18,
		STATIC(mercury__unify_proc__generate_unify_clauses_7_0));
Define_label(mercury__unify_proc__generate_unify_clauses_7_0_i18);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_unify_clauses_7_0));
	MR_stackvar(5) = r1;
	r1 = (Word) MR_string_const("unsafe_type_cast", 16);
	r4 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_unify_clauses_7_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_unify_clauses_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_tempr1;
	r3 = MR_stackvar(3);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(4);
	call_localret(STATIC(mercury__unify_proc__build_call_6_0),
		mercury__unify_proc__generate_unify_clauses_7_0_i19,
		STATIC(mercury__unify_proc__generate_unify_clauses_7_0));
	}
Define_label(mercury__unify_proc__generate_unify_clauses_7_0_i19);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_unify_clauses_7_0));
	MR_stackvar(6) = r1;
	r1 = (Word) MR_string_const("unsafe_type_cast", 16);
	r4 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_unify_clauses_7_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_unify_clauses_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_tempr1;
	r3 = MR_stackvar(3);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(5);
	call_localret(STATIC(mercury__unify_proc__build_call_6_0),
		mercury__unify_proc__generate_unify_clauses_7_0_i20,
		STATIC(mercury__unify_proc__generate_unify_clauses_7_0));
	}
Define_label(mercury__unify_proc__generate_unify_clauses_7_0_i20);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_unify_clauses_7_0));
	r3 = MR_stackvar(4);
	MR_stackvar(4) = r1;
	r1 = (Word) MR_string_const("unify", 5);
	r5 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_unify_clauses_7_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = r3;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_unify_clauses_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_tempr1;
	r3 = MR_stackvar(3);
	r4 = r5;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(5);
	call_localret(STATIC(mercury__unify_proc__build_call_6_0),
		mercury__unify_proc__generate_unify_clauses_7_0_i21,
		STATIC(mercury__unify_proc__generate_unify_clauses_7_0));
	}
Define_label(mercury__unify_proc__generate_unify_clauses_7_0_i21);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_unify_clauses_7_0));
	MR_stackvar(5) = r1;
	MR_stackvar(7) = r2;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_init_1_0),
		mercury__unify_proc__generate_unify_clauses_7_0_i22,
		STATIC(mercury__unify_proc__generate_unify_clauses_7_0));
Define_label(mercury__unify_proc__generate_unify_clauses_7_0_i22);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_unify_clauses_7_0));
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_set_context_3_0),
		mercury__unify_proc__generate_unify_clauses_7_0_i23,
		STATIC(mercury__unify_proc__generate_unify_clauses_7_0));
Define_label(mercury__unify_proc__generate_unify_clauses_7_0_i23);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_unify_clauses_7_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_unify_clauses_7_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(6);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_unify_clauses_7_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(4);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_unify_clauses_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(5);
	call_localret(ENTRY(mercury__hlds_goal__conj_list_to_goal_3_0),
		mercury__unify_proc__generate_unify_clauses_7_0_i24,
		STATIC(mercury__unify_proc__generate_unify_clauses_7_0));
	}
Define_label(mercury__unify_proc__generate_unify_clauses_7_0_i24);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_unify_clauses_7_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_unify_clauses_7_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_unify_clauses_7_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(7);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	tailcall(STATIC(mercury__unify_proc__quantify_clause_body_6_0),
		STATIC(mercury__unify_proc__generate_unify_clauses_7_0));
Define_label(mercury__unify_proc__generate_unify_clauses_7_0_i14);
	r1 = r7;
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	tailcall(STATIC(mercury__unify_proc__generate_du_unify_clauses_7_0),
		STATIC(mercury__unify_proc__generate_unify_clauses_7_0));
Define_label(mercury__unify_proc__generate_unify_clauses_7_0_i1024);
	r1 = (Word) MR_string_const("trying to create unify proc for uu type", 39);
	MR_decr_sp_pop_msg(8);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__unify_proc__generate_unify_clauses_7_0));
Define_label(mercury__unify_proc__generate_unify_clauses_7_0_i31);
	r1 = r2;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 1, mercury__unify_proc__generate_unify_clauses_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 0) = r3;
	r3 = r4;
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__make_hlds__create_atomic_unification_6_0),
		mercury__unify_proc__generate_unify_clauses_7_0_i32,
		STATIC(mercury__unify_proc__generate_unify_clauses_7_0));
Define_label(mercury__unify_proc__generate_unify_clauses_7_0_i32);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_unify_clauses_7_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_unify_clauses_7_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_unify_clauses_7_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	tailcall(STATIC(mercury__unify_proc__quantify_clause_body_6_0),
		STATIC(mercury__unify_proc__generate_unify_clauses_7_0));
END_MODULE


BEGIN_MODULE(unify_proc_module10)
	init_entry(mercury__unify_proc__generate_index_clauses_7_0);
	init_label(mercury__unify_proc__generate_index_clauses_7_0_i1008);
	init_label(mercury__unify_proc__generate_index_clauses_7_0_i6);
	init_label(mercury__unify_proc__generate_index_clauses_7_0_i7);
	init_label(mercury__unify_proc__generate_index_clauses_7_0_i11);
	init_label(mercury__unify_proc__generate_index_clauses_7_0_i1010);
	init_label(mercury__unify_proc__generate_index_clauses_7_0_i20);
	init_label(mercury__unify_proc__generate_index_clauses_7_0_i21);
BEGIN_CODE

/* code for predicate 'generate_index_clauses'/7 in mode 0 */
Define_static(mercury__unify_proc__generate_index_clauses_7_0);
	MR_incr_sp_push_msg(3, "unify_proc:generate_index_clauses/7");
	MR_stackvar(3) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__unify_proc__generate_index_clauses_7_0_i1008) AND
		LABEL(mercury__unify_proc__generate_index_clauses_7_0_i6) AND
		LABEL(mercury__unify_proc__generate_index_clauses_7_0_i1010) AND
		LABEL(mercury__unify_proc__generate_index_clauses_7_0_i20));
Define_label(mercury__unify_proc__generate_index_clauses_7_0_i1008);
	r1 = (Word) MR_string_const("trying to create index proc for abstract type", 45);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__unify_proc__generate_index_clauses_7_0));
Define_label(mercury__unify_proc__generate_index_clauses_7_0_i6);
	r7 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r6 = MR_const_field(MR_mktag(1), r1, (Integer) 2);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 3) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_proc__generate_index_clauses_7_0_i7);
	{
	Word MR_tempr1, MR_tempr2;
	tag_incr_hp_msg(MR_tempr2, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_index_clauses_7_0, "origin_lost_in_value_number");
	MR_stackvar(1) = r4;
	MR_stackvar(2) = MR_tempr2;
	MR_field(MR_mktag(1), MR_tempr2, (Integer) 0) = r2;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_index_clauses_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r3;
	r3 = r4;
	MR_field(MR_mktag(1), MR_stackvar(2), (Integer) 1) = MR_tempr1;
	r2 = MR_stackvar(2);
	r1 = (Word) MR_string_const("builtin_index_non_canonical_type", 32);
	r4 = r5;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(STATIC(mercury__unify_proc__build_call_6_0),
		mercury__unify_proc__generate_index_clauses_7_0_i21,
		STATIC(mercury__unify_proc__generate_index_clauses_7_0));
	}
Define_label(mercury__unify_proc__generate_index_clauses_7_0_i7);
	if (((Integer) r6 != (Integer) 1))
		GOTO_LABEL(mercury__unify_proc__generate_index_clauses_7_0_i11);
	MR_stackvar(1) = r4;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_index_clauses_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	MR_stackvar(2) = r1;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_index_clauses_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r3;
	r2 = r1;
	r3 = r4;
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_tempr1;
	r4 = r5;
	r1 = (Word) MR_string_const("unsafe_type_cast", 16);
	call_localret(STATIC(mercury__unify_proc__build_call_6_0),
		mercury__unify_proc__generate_index_clauses_7_0_i21,
		STATIC(mercury__unify_proc__generate_index_clauses_7_0));
	}
Define_label(mercury__unify_proc__generate_index_clauses_7_0_i11);
	r1 = r7;
	r6 = r5;
	r5 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__unify_proc__generate_du_index_clauses_8_0),
		STATIC(mercury__unify_proc__generate_index_clauses_7_0));
Define_label(mercury__unify_proc__generate_index_clauses_7_0_i1010);
	r1 = (Word) MR_string_const("trying to create index proc for uu type", 39);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__unify_proc__generate_index_clauses_7_0));
Define_label(mercury__unify_proc__generate_index_clauses_7_0_i20);
	MR_stackvar(1) = r4;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_index_clauses_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	MR_stackvar(2) = r1;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_index_clauses_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r3;
	r2 = r1;
	r3 = r4;
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_tempr1;
	r4 = r5;
	r1 = (Word) MR_string_const("index", 5);
	call_localret(STATIC(mercury__unify_proc__build_call_6_0),
		mercury__unify_proc__generate_index_clauses_7_0_i21,
		STATIC(mercury__unify_proc__generate_index_clauses_7_0));
	}
Define_label(mercury__unify_proc__generate_index_clauses_7_0_i21);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_index_clauses_7_0));
	r4 = r2;
	r2 = r1;
	r1 = MR_stackvar(2);
	r3 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__unify_proc__quantify_clause_body_6_0),
		STATIC(mercury__unify_proc__generate_index_clauses_7_0));
END_MODULE

Declare_entry(mercury__varset__new_var_3_0);
Declare_entry(mercury__map__det_insert_4_0);

BEGIN_MODULE(unify_proc_module11)
	init_entry(mercury__unify_proc__generate_compare_clauses_8_0);
	init_label(mercury__unify_proc__generate_compare_clauses_8_0_i1022);
	init_label(mercury__unify_proc__generate_compare_clauses_8_0_i6);
	init_label(mercury__unify_proc__generate_compare_clauses_8_0_i7);
	init_label(mercury__unify_proc__generate_compare_clauses_8_0_i13);
	init_label(mercury__unify_proc__generate_compare_clauses_8_0_i14);
	init_label(mercury__unify_proc__generate_compare_clauses_8_0_i15);
	init_label(mercury__unify_proc__generate_compare_clauses_8_0_i16);
	init_label(mercury__unify_proc__generate_compare_clauses_8_0_i17);
	init_label(mercury__unify_proc__generate_compare_clauses_8_0_i18);
	init_label(mercury__unify_proc__generate_compare_clauses_8_0_i19);
	init_label(mercury__unify_proc__generate_compare_clauses_8_0_i20);
	init_label(mercury__unify_proc__generate_compare_clauses_8_0_i21);
	init_label(mercury__unify_proc__generate_compare_clauses_8_0_i22);
	init_label(mercury__unify_proc__generate_compare_clauses_8_0_i11);
	init_label(mercury__unify_proc__generate_compare_clauses_8_0_i1024);
	init_label(mercury__unify_proc__generate_compare_clauses_8_0_i29);
	init_label(mercury__unify_proc__generate_compare_clauses_8_0_i30);
BEGIN_CODE

/* code for predicate 'generate_compare_clauses'/8 in mode 0 */
Define_static(mercury__unify_proc__generate_compare_clauses_8_0);
	MR_incr_sp_push_msg(9, "unify_proc:generate_compare_clauses/8");
	MR_stackvar(9) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__unify_proc__generate_compare_clauses_8_0_i1022) AND
		LABEL(mercury__unify_proc__generate_compare_clauses_8_0_i6) AND
		LABEL(mercury__unify_proc__generate_compare_clauses_8_0_i1024) AND
		LABEL(mercury__unify_proc__generate_compare_clauses_8_0_i29));
Define_label(mercury__unify_proc__generate_compare_clauses_8_0_i1022);
	r1 = (Word) MR_string_const("trying to create compare proc for abstract type", 47);
	MR_decr_sp_pop_msg(9);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__unify_proc__generate_compare_clauses_8_0));
Define_label(mercury__unify_proc__generate_compare_clauses_8_0_i6);
	r8 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r7 = MR_const_field(MR_mktag(1), r1, (Integer) 2);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 3) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_proc__generate_compare_clauses_8_0_i7);
	{
	Word MR_tempr1, MR_tempr2;
	tag_incr_hp_msg(MR_tempr2, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_compare_clauses_8_0, "origin_lost_in_value_number");
	MR_stackvar(1) = MR_tempr2;
	MR_stackvar(4) = r5;
	MR_field(MR_mktag(1), MR_tempr2, (Integer) 0) = r2;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_compare_clauses_8_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	r3 = r5;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_compare_clauses_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r4;
	r2 = MR_stackvar(1);
	r4 = r6;
	MR_field(MR_mktag(1), r2, (Integer) 1) = r1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_tempr1;
	r1 = (Word) MR_string_const("builtin_compare_non_canonical_type", 34);
	call_localret(STATIC(mercury__unify_proc__build_call_6_0),
		mercury__unify_proc__generate_compare_clauses_8_0_i30,
		STATIC(mercury__unify_proc__generate_compare_clauses_8_0));
	}
Define_label(mercury__unify_proc__generate_compare_clauses_8_0_i7);
	if (((Integer) r7 != (Integer) 1))
		GOTO_LABEL(mercury__unify_proc__generate_compare_clauses_8_0_i11);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r6;
	call_localret(ENTRY(mercury__fn__type_util__int_type_0_0),
		mercury__unify_proc__generate_compare_clauses_8_0_i13,
		STATIC(mercury__unify_proc__generate_compare_clauses_8_0));
Define_label(mercury__unify_proc__generate_compare_clauses_8_0_i13);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_compare_clauses_8_0));
	r3 = MR_stackvar(5);
	r2 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r3, (Integer) 2);
	MR_stackvar(5) = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	call_localret(ENTRY(mercury__varset__new_var_3_0),
		mercury__unify_proc__generate_compare_clauses_8_0_i14,
		STATIC(mercury__unify_proc__generate_compare_clauses_8_0));
Define_label(mercury__unify_proc__generate_compare_clauses_8_0_i14);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_compare_clauses_8_0));
	r3 = MR_stackvar(6);
	r4 = r1;
	MR_stackvar(6) = r1;
	MR_stackvar(8) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_3);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_4);
	r5 = MR_stackvar(5);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__unify_proc__generate_compare_clauses_8_0_i15,
		STATIC(mercury__unify_proc__generate_compare_clauses_8_0));
Define_label(mercury__unify_proc__generate_compare_clauses_8_0_i15);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_compare_clauses_8_0));
	r3 = r1;
	r1 = MR_stackvar(5);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 3, mercury__unify_proc__generate_compare_clauses_8_0, "unify_proc:unify_proc_info/0");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(8);
	MR_field(MR_mktag(0), r2, (Integer) 1) = r3;
	MR_field(MR_mktag(0), r2, (Integer) 2) = MR_stackvar(7);
	call_localret(STATIC(mercury__unify_proc__info_new_var_4_0),
		mercury__unify_proc__generate_compare_clauses_8_0_i16,
		STATIC(mercury__unify_proc__generate_compare_clauses_8_0));
Define_label(mercury__unify_proc__generate_compare_clauses_8_0_i16);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_compare_clauses_8_0));
	MR_stackvar(5) = r1;
	r1 = (Word) MR_string_const("unsafe_type_cast", 16);
	r4 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_compare_clauses_8_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_compare_clauses_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_tempr1;
	r3 = MR_stackvar(4);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(6);
	call_localret(STATIC(mercury__unify_proc__build_call_6_0),
		mercury__unify_proc__generate_compare_clauses_8_0_i17,
		STATIC(mercury__unify_proc__generate_compare_clauses_8_0));
	}
Define_label(mercury__unify_proc__generate_compare_clauses_8_0_i17);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_compare_clauses_8_0));
	MR_stackvar(7) = r1;
	r1 = (Word) MR_string_const("unsafe_type_cast", 16);
	r4 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_compare_clauses_8_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(3);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_compare_clauses_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_tempr1;
	r3 = MR_stackvar(4);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(5);
	call_localret(STATIC(mercury__unify_proc__build_call_6_0),
		mercury__unify_proc__generate_compare_clauses_8_0_i18,
		STATIC(mercury__unify_proc__generate_compare_clauses_8_0));
	}
Define_label(mercury__unify_proc__generate_compare_clauses_8_0_i18);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_compare_clauses_8_0));
	r3 = MR_stackvar(5);
	MR_stackvar(5) = r1;
	r1 = (Word) MR_string_const("builtin_compare_int", 19);
	r5 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_compare_clauses_8_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_compare_clauses_8_0, "list:list/1");
	MR_field(MR_mktag(1), r6, (Integer) 0) = MR_stackvar(6);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_compare_clauses_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r6, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r3;
	r3 = MR_stackvar(4);
	r4 = r5;
	MR_field(MR_mktag(1), r2, (Integer) 1) = r6;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(STATIC(mercury__unify_proc__build_call_6_0),
		mercury__unify_proc__generate_compare_clauses_8_0_i19,
		STATIC(mercury__unify_proc__generate_compare_clauses_8_0));
	}
Define_label(mercury__unify_proc__generate_compare_clauses_8_0_i19);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_compare_clauses_8_0));
	MR_stackvar(6) = r1;
	MR_stackvar(8) = r2;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_init_1_0),
		mercury__unify_proc__generate_compare_clauses_8_0_i20,
		STATIC(mercury__unify_proc__generate_compare_clauses_8_0));
Define_label(mercury__unify_proc__generate_compare_clauses_8_0_i20);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_compare_clauses_8_0));
	r2 = MR_stackvar(4);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_set_context_3_0),
		mercury__unify_proc__generate_compare_clauses_8_0_i21,
		STATIC(mercury__unify_proc__generate_compare_clauses_8_0));
Define_label(mercury__unify_proc__generate_compare_clauses_8_0_i21);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_compare_clauses_8_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_compare_clauses_8_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(7);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_compare_clauses_8_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(5);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_compare_clauses_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(6);
	call_localret(ENTRY(mercury__hlds_goal__conj_list_to_goal_3_0),
		mercury__unify_proc__generate_compare_clauses_8_0_i22,
		STATIC(mercury__unify_proc__generate_compare_clauses_8_0));
	}
Define_label(mercury__unify_proc__generate_compare_clauses_8_0_i22);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_compare_clauses_8_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_compare_clauses_8_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_compare_clauses_8_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(2);
	r4 = MR_stackvar(8);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_compare_clauses_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(9);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_tempr1;
	r3 = MR_stackvar(4);
	MR_decr_sp_pop_msg(9);
	tailcall(STATIC(mercury__unify_proc__quantify_clause_body_6_0),
		STATIC(mercury__unify_proc__generate_compare_clauses_8_0));
	}
Define_label(mercury__unify_proc__generate_compare_clauses_8_0_i11);
	r1 = r8;
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	tailcall(STATIC(mercury__unify_proc__generate_du_compare_clauses_8_0),
		STATIC(mercury__unify_proc__generate_compare_clauses_8_0));
Define_label(mercury__unify_proc__generate_compare_clauses_8_0_i1024);
	r1 = (Word) MR_string_const("trying to create compare proc for uu type", 41);
	MR_decr_sp_pop_msg(9);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__unify_proc__generate_compare_clauses_8_0));
Define_label(mercury__unify_proc__generate_compare_clauses_8_0_i29);
	MR_stackvar(4) = r5;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_compare_clauses_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	MR_stackvar(1) = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_compare_clauses_8_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	r3 = r5;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_compare_clauses_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r4;
	r2 = MR_stackvar(1);
	r4 = r6;
	MR_field(MR_mktag(1), r2, (Integer) 1) = r1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_tempr1;
	r1 = (Word) MR_string_const("compare", 7);
	call_localret(STATIC(mercury__unify_proc__build_call_6_0),
		mercury__unify_proc__generate_compare_clauses_8_0_i30,
		STATIC(mercury__unify_proc__generate_compare_clauses_8_0));
	}
Define_label(mercury__unify_proc__generate_compare_clauses_8_0_i30);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_compare_clauses_8_0));
	r4 = r2;
	r2 = r1;
	r1 = MR_stackvar(1);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	tailcall(STATIC(mercury__unify_proc__quantify_clause_body_6_0),
		STATIC(mercury__unify_proc__generate_compare_clauses_8_0));
END_MODULE

Declare_entry(mercury__quantification__implicitly_quantify_clause_body_8_0);

BEGIN_MODULE(unify_proc_module12)
	init_entry(mercury__unify_proc__quantify_clause_body_6_0);
	init_label(mercury__unify_proc__quantify_clause_body_6_0_i2);
BEGIN_CODE

/* code for predicate 'quantify_clause_body'/6 in mode 0 */
Define_static(mercury__unify_proc__quantify_clause_body_6_0);
	MR_incr_sp_push_msg(3, "unify_proc:quantify_clause_body/6");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r3;
	r3 = MR_const_field(MR_mktag(0), r4, (Integer) 0);
	MR_stackvar(2) = r4;
	r4 = MR_const_field(MR_mktag(0), r4, (Integer) 1);
	call_localret(ENTRY(mercury__quantification__implicitly_quantify_clause_body_8_0),
		mercury__unify_proc__quantify_clause_body_6_0_i2,
		STATIC(mercury__unify_proc__quantify_clause_body_6_0));
Define_label(mercury__unify_proc__quantify_clause_body_6_0_i2);
	update_prof_current_proc(LABEL(mercury__unify_proc__quantify_clause_body_6_0));
	r5 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__unify_proc__quantify_clause_body_6_0, "list:list/1");
	r6 = r2;
	MR_field(MR_mktag(1), r1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 3, mercury__unify_proc__quantify_clause_body_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = MR_stackvar(1);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r5;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_tempr1;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 3, mercury__unify_proc__quantify_clause_body_6_0, "unify_proc:unify_proc_info/0");
	MR_field(MR_mktag(0), r2, (Integer) 0) = r6;
	MR_field(MR_mktag(0), r2, (Integer) 1) = r3;
	MR_field(MR_mktag(0), r2, (Integer) 2) = MR_const_field(MR_mktag(0), MR_stackvar(2), (Integer) 2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
	}
END_MODULE


BEGIN_MODULE(unify_proc_module13)
	init_entry(mercury__unify_proc__generate_du_unify_clauses_7_0);
	init_label(mercury__unify_proc__generate_du_unify_clauses_7_0_i4);
	init_label(mercury__unify_proc__generate_du_unify_clauses_7_0_i5);
	init_label(mercury__unify_proc__generate_du_unify_clauses_7_0_i6);
	init_label(mercury__unify_proc__generate_du_unify_clauses_7_0_i7);
	init_label(mercury__unify_proc__generate_du_unify_clauses_7_0_i8);
	init_label(mercury__unify_proc__generate_du_unify_clauses_7_0_i11);
	init_label(mercury__unify_proc__generate_du_unify_clauses_7_0_i10);
	init_label(mercury__unify_proc__generate_du_unify_clauses_7_0_i14);
	init_label(mercury__unify_proc__generate_du_unify_clauses_7_0_i15);
	init_label(mercury__unify_proc__generate_du_unify_clauses_7_0_i16);
	init_label(mercury__unify_proc__generate_du_unify_clauses_7_0_i17);
	init_label(mercury__unify_proc__generate_du_unify_clauses_7_0_i1008);
	init_label(mercury__unify_proc__generate_du_unify_clauses_7_0_i19);
	init_label(mercury__unify_proc__generate_du_unify_clauses_7_0_i3);
BEGIN_CODE

/* code for predicate 'generate_du_unify_clauses'/7 in mode 0 */
Define_static(mercury__unify_proc__generate_du_unify_clauses_7_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_proc__generate_du_unify_clauses_7_0_i3);
	MR_incr_sp_push_msg(11, "unify_proc:generate_du_unify_clauses/7");
	MR_stackvar(11) = (Word) MR_succip;
	MR_stackvar(1) = r2;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 3);
	MR_stackvar(8) = r2;
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 2);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_6);
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__unify_proc__generate_du_unify_clauses_7_0_i4,
		STATIC(mercury__unify_proc__generate_du_unify_clauses_7_0));
	}
Define_label(mercury__unify_proc__generate_du_unify_clauses_7_0_i4);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_unify_clauses_7_0));
	r3 = MR_stackvar(4);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__unify_proc__generate_du_unify_clauses_7_0, "origin_lost_in_value_number");
	MR_stackvar(4) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r1;
	r1 = MR_stackvar(8);
	r2 = MR_stackvar(6);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(7);
	call_localret(STATIC(mercury__unify_proc__make_fresh_vars_5_0),
		mercury__unify_proc__generate_du_unify_clauses_7_0_i5,
		STATIC(mercury__unify_proc__generate_du_unify_clauses_7_0));
	}
Define_label(mercury__unify_proc__generate_du_unify_clauses_7_0_i5);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_unify_clauses_7_0));
	r3 = r2;
	MR_stackvar(7) = r1;
	r1 = MR_stackvar(8);
	r2 = MR_stackvar(6);
	call_localret(STATIC(mercury__unify_proc__make_fresh_vars_5_0),
		mercury__unify_proc__generate_du_unify_clauses_7_0_i6,
		STATIC(mercury__unify_proc__generate_du_unify_clauses_7_0));
Define_label(mercury__unify_proc__generate_du_unify_clauses_7_0_i6);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_unify_clauses_7_0));
	MR_stackvar(9) = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(10) = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_du_unify_clauses_7_0, "origin_lost_in_value_number");
	r3 = MR_stackvar(3);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_stackvar(7);
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(4);
	call_localret(ENTRY(mercury__make_hlds__create_atomic_unification_6_0),
		mercury__unify_proc__generate_du_unify_clauses_7_0_i7,
		STATIC(mercury__unify_proc__generate_du_unify_clauses_7_0));
Define_label(mercury__unify_proc__generate_du_unify_clauses_7_0_i7);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_unify_clauses_7_0));
	r4 = MR_stackvar(4);
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(2);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_du_unify_clauses_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r2, (Integer) 0) = r4;
	r3 = MR_stackvar(3);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_stackvar(9);
	call_localret(ENTRY(mercury__make_hlds__create_atomic_unification_6_0),
		mercury__unify_proc__generate_du_unify_clauses_7_0_i8,
		STATIC(mercury__unify_proc__generate_du_unify_clauses_7_0));
Define_label(mercury__unify_proc__generate_du_unify_clauses_7_0_i8);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_unify_clauses_7_0));
	r2 = MR_stackvar(6);
	MR_stackvar(6) = r1;
	r1 = MR_stackvar(8);
	r3 = MR_stackvar(7);
	r4 = MR_stackvar(9);
	r5 = MR_stackvar(10);
	call_localret(STATIC(mercury__unify_proc__unify_var_lists_2_7_0),
		mercury__unify_proc__generate_du_unify_clauses_7_0_i11,
		STATIC(mercury__unify_proc__generate_du_unify_clauses_7_0));
Define_label(mercury__unify_proc__generate_du_unify_clauses_7_0_i11);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_unify_clauses_7_0));
	if (!(r1))
		GOTO_LABEL(mercury__unify_proc__generate_du_unify_clauses_7_0_i10);
	r1 = MR_stackvar(4);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_du_unify_clauses_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r1;
	MR_stackvar(4) = MR_tempr1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_du_unify_clauses_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_stackvar(4), (Integer) 1) = r1;
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(6);
	MR_stackvar(6) = r3;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_init_1_0),
		mercury__unify_proc__generate_du_unify_clauses_7_0_i15,
		STATIC(mercury__unify_proc__generate_du_unify_clauses_7_0));
	}
Define_label(mercury__unify_proc__generate_du_unify_clauses_7_0_i10);
	r1 = (Word) MR_string_const("unify_proc__unify_var_lists: length mismatch", 44);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__unify_proc__generate_du_unify_clauses_7_0_i14,
		STATIC(mercury__unify_proc__generate_du_unify_clauses_7_0));
Define_label(mercury__unify_proc__generate_du_unify_clauses_7_0_i14);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_unify_clauses_7_0));
	call_localret(ENTRY(mercury__hlds_goal__goal_info_init_1_0),
		mercury__unify_proc__generate_du_unify_clauses_7_0_i15,
		STATIC(mercury__unify_proc__generate_du_unify_clauses_7_0));
Define_label(mercury__unify_proc__generate_du_unify_clauses_7_0_i15);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_unify_clauses_7_0));
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_set_context_3_0),
		mercury__unify_proc__generate_du_unify_clauses_7_0_i16,
		STATIC(mercury__unify_proc__generate_du_unify_clauses_7_0));
Define_label(mercury__unify_proc__generate_du_unify_clauses_7_0_i16);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_unify_clauses_7_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__hlds_goal__conj_list_to_goal_3_0),
		mercury__unify_proc__generate_du_unify_clauses_7_0_i17,
		STATIC(mercury__unify_proc__generate_du_unify_clauses_7_0));
Define_label(mercury__unify_proc__generate_du_unify_clauses_7_0_i17);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_unify_clauses_7_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_du_unify_clauses_7_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	{
	Word MR_tempr1, MR_tempr2;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_du_unify_clauses_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_tempr1;
	MR_tempr2 = MR_stackvar(6);
	r4 = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 1);
	r3 = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 0);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(2);
	call_localret(ENTRY(mercury__quantification__implicitly_quantify_clause_body_8_0),
		mercury__unify_proc__generate_du_unify_clauses_7_0_i1008,
		STATIC(mercury__unify_proc__generate_du_unify_clauses_7_0));
	}
Define_label(mercury__unify_proc__generate_du_unify_clauses_7_0_i1008);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_unify_clauses_7_0));
	r6 = r2;
	r7 = r3;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 3, mercury__unify_proc__generate_du_unify_clauses_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r4 = MR_stackvar(3);
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_stackvar(4) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = r4;
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 3, mercury__unify_proc__generate_du_unify_clauses_7_0, "unify_proc:unify_proc_info/0");
	MR_field(MR_mktag(0), r5, (Integer) 0) = r6;
	MR_field(MR_mktag(0), r5, (Integer) 1) = r7;
	MR_field(MR_mktag(0), r5, (Integer) 2) = MR_const_field(MR_mktag(0), MR_stackvar(6), (Integer) 2);
	localcall(mercury__unify_proc__generate_du_unify_clauses_7_0,
		LABEL(mercury__unify_proc__generate_du_unify_clauses_7_0_i19),
		STATIC(mercury__unify_proc__generate_du_unify_clauses_7_0));
	}
Define_label(mercury__unify_proc__generate_du_unify_clauses_7_0_i19);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_unify_clauses_7_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_du_unify_clauses_7_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__unify_proc__generate_du_unify_clauses_7_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = r5;
	proceed();
END_MODULE


BEGIN_MODULE(unify_proc_module14)
	init_entry(mercury__unify_proc__generate_du_index_clauses_8_0);
	init_label(mercury__unify_proc__generate_du_index_clauses_8_0_i4);
	init_label(mercury__unify_proc__generate_du_index_clauses_8_0_i5);
	init_label(mercury__unify_proc__generate_du_index_clauses_8_0_i6);
	init_label(mercury__unify_proc__generate_du_index_clauses_8_0_i7);
	init_label(mercury__unify_proc__generate_du_index_clauses_8_0_i8);
	init_label(mercury__unify_proc__generate_du_index_clauses_8_0_i9);
	init_label(mercury__unify_proc__generate_du_index_clauses_8_0_i10);
	init_label(mercury__unify_proc__generate_du_index_clauses_8_0_i11);
	init_label(mercury__unify_proc__generate_du_index_clauses_8_0_i12);
	init_label(mercury__unify_proc__generate_du_index_clauses_8_0_i3);
BEGIN_CODE

/* code for predicate 'generate_du_index_clauses'/8 in mode 0 */
Define_static(mercury__unify_proc__generate_du_index_clauses_8_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_proc__generate_du_index_clauses_8_0_i3);
	MR_incr_sp_push_msg(10, "unify_proc:generate_du_index_clauses/8");
	MR_stackvar(10) = (Word) MR_succip;
	MR_stackvar(1) = r2;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 3);
	MR_stackvar(9) = r2;
	MR_stackvar(6) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 2);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_6);
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r6;
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__unify_proc__generate_du_index_clauses_8_0_i4,
		STATIC(mercury__unify_proc__generate_du_index_clauses_8_0));
	}
Define_label(mercury__unify_proc__generate_du_index_clauses_8_0_i4);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_index_clauses_8_0));
	r3 = MR_stackvar(5);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__unify_proc__generate_du_index_clauses_8_0, "origin_lost_in_value_number");
	MR_stackvar(5) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r1;
	r1 = MR_stackvar(9);
	r2 = MR_stackvar(7);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(8);
	call_localret(STATIC(mercury__unify_proc__make_fresh_vars_5_0),
		mercury__unify_proc__generate_du_index_clauses_8_0_i5,
		STATIC(mercury__unify_proc__generate_du_index_clauses_8_0));
	}
Define_label(mercury__unify_proc__generate_du_index_clauses_8_0_i5);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_index_clauses_8_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(7) = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_du_index_clauses_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r2, (Integer) 1) = r3;
	r3 = MR_stackvar(3);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(5);
	call_localret(ENTRY(mercury__make_hlds__create_atomic_unification_6_0),
		mercury__unify_proc__generate_du_index_clauses_8_0_i6,
		STATIC(mercury__unify_proc__generate_du_index_clauses_8_0));
Define_label(mercury__unify_proc__generate_du_index_clauses_8_0_i6);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_index_clauses_8_0));
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(2);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_du_index_clauses_8_0, "hlds_goal:unify_rhs/0");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__unify_proc__generate_du_index_clauses_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_tempr1;
	r3 = MR_stackvar(3);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(4);
	call_localret(ENTRY(mercury__make_hlds__create_atomic_unification_6_0),
		mercury__unify_proc__generate_du_index_clauses_8_0_i7,
		STATIC(mercury__unify_proc__generate_du_index_clauses_8_0));
	}
Define_label(mercury__unify_proc__generate_du_index_clauses_8_0_i7);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_index_clauses_8_0));
	r2 = MR_stackvar(5);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_du_index_clauses_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_stackvar(5) = r3;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_du_index_clauses_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = r2;
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r2, (Integer) 0) = r1;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_init_1_0),
		mercury__unify_proc__generate_du_index_clauses_8_0_i8,
		STATIC(mercury__unify_proc__generate_du_index_clauses_8_0));
Define_label(mercury__unify_proc__generate_du_index_clauses_8_0_i8);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_index_clauses_8_0));
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_set_context_3_0),
		mercury__unify_proc__generate_du_index_clauses_8_0_i9,
		STATIC(mercury__unify_proc__generate_du_index_clauses_8_0));
Define_label(mercury__unify_proc__generate_du_index_clauses_8_0_i9);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_index_clauses_8_0));
	r2 = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__hlds_goal__conj_list_to_goal_3_0),
		mercury__unify_proc__generate_du_index_clauses_8_0_i10,
		STATIC(mercury__unify_proc__generate_du_index_clauses_8_0));
Define_label(mercury__unify_proc__generate_du_index_clauses_8_0_i10);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_index_clauses_8_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_du_index_clauses_8_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	{
	Word MR_tempr1, MR_tempr2;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_du_index_clauses_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_tempr1;
	MR_tempr2 = MR_stackvar(7);
	r4 = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 1);
	r3 = MR_const_field(MR_mktag(0), MR_tempr2, (Integer) 0);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(2);
	call_localret(ENTRY(mercury__quantification__implicitly_quantify_clause_body_8_0),
		mercury__unify_proc__generate_du_index_clauses_8_0_i11,
		STATIC(mercury__unify_proc__generate_du_index_clauses_8_0));
	}
Define_label(mercury__unify_proc__generate_du_index_clauses_8_0_i11);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_index_clauses_8_0));
	r5 = MR_stackvar(1);
	r7 = r2;
	r9 = r3;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 3, mercury__unify_proc__generate_du_index_clauses_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r4 = MR_stackvar(3);
	r2 = r5;
	r1 = MR_stackvar(6);
	r3 = MR_stackvar(2);
	r5 = ((Integer) MR_stackvar(4) + (Integer) 1);
	MR_stackvar(1) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 2) = r4;
	tag_incr_hp_msg(r6, MR_mktag(0), (Integer) 3, mercury__unify_proc__generate_du_index_clauses_8_0, "unify_proc:unify_proc_info/0");
	MR_field(MR_mktag(0), r6, (Integer) 0) = r7;
	MR_field(MR_mktag(0), r6, (Integer) 1) = r9;
	MR_field(MR_mktag(0), r6, (Integer) 2) = MR_const_field(MR_mktag(0), MR_stackvar(7), (Integer) 2);
	localcall(mercury__unify_proc__generate_du_index_clauses_8_0,
		LABEL(mercury__unify_proc__generate_du_index_clauses_8_0_i12),
		STATIC(mercury__unify_proc__generate_du_index_clauses_8_0));
	}
Define_label(mercury__unify_proc__generate_du_index_clauses_8_0_i12);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_index_clauses_8_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_du_index_clauses_8_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
Define_label(mercury__unify_proc__generate_du_index_clauses_8_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = r6;
	proceed();
END_MODULE


BEGIN_MODULE(unify_proc_module15)
	init_entry(mercury__unify_proc__generate_du_compare_clauses_8_0);
	init_label(mercury__unify_proc__generate_du_compare_clauses_8_0_i5);
	init_label(mercury__unify_proc__generate_du_compare_clauses_8_0_i6);
	init_label(mercury__unify_proc__generate_du_compare_clauses_8_0_i7);
	init_label(mercury__unify_proc__generate_du_compare_clauses_8_0_i8);
	init_label(mercury__unify_proc__generate_du_compare_clauses_8_0_i9);
	init_label(mercury__unify_proc__generate_du_compare_clauses_8_0_i12);
	init_label(mercury__unify_proc__generate_du_compare_clauses_8_0_i11);
	init_label(mercury__unify_proc__generate_du_compare_clauses_8_0_i15);
	init_label(mercury__unify_proc__generate_du_compare_clauses_8_0_i16);
	init_label(mercury__unify_proc__generate_du_compare_clauses_8_0_i17);
	init_label(mercury__unify_proc__generate_du_compare_clauses_8_0_i18);
	init_label(mercury__unify_proc__generate_du_compare_clauses_8_0_i2);
	init_label(mercury__unify_proc__generate_du_compare_clauses_8_0_i19);
	init_label(mercury__unify_proc__generate_du_compare_clauses_8_0_i21);
	init_label(mercury__unify_proc__generate_du_compare_clauses_8_0_i22);
	init_label(mercury__unify_proc__generate_du_compare_clauses_8_0_i23);
BEGIN_CODE

/* code for predicate 'generate_du_compare_clauses'/8 in mode 0 */
Define_static(mercury__unify_proc__generate_du_compare_clauses_8_0);
	MR_incr_sp_push_msg(11, "unify_proc:generate_du_compare_clauses/8");
	MR_stackvar(11) = (Word) MR_succip;
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_proc__generate_du_compare_clauses_8_0_i2);
	r7 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	if (((Integer) r7 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_proc__generate_du_compare_clauses_8_0_i2);
	MR_stackvar(1) = r2;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 3);
	MR_stackvar(8) = r2;
	MR_stackvar(7) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 2);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_6);
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r6;
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__unify_proc__generate_du_compare_clauses_8_0_i5,
		STATIC(mercury__unify_proc__generate_du_compare_clauses_8_0));
	}
Define_label(mercury__unify_proc__generate_du_compare_clauses_8_0_i5);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_compare_clauses_8_0));
	r3 = MR_stackvar(5);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__unify_proc__generate_du_compare_clauses_8_0, "origin_lost_in_value_number");
	MR_stackvar(5) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r1;
	r1 = MR_stackvar(8);
	r2 = MR_stackvar(6);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(7);
	call_localret(STATIC(mercury__unify_proc__make_fresh_vars_5_0),
		mercury__unify_proc__generate_du_compare_clauses_8_0_i6,
		STATIC(mercury__unify_proc__generate_du_compare_clauses_8_0));
	}
Define_label(mercury__unify_proc__generate_du_compare_clauses_8_0_i6);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_compare_clauses_8_0));
	r3 = r2;
	MR_stackvar(7) = r1;
	r1 = MR_stackvar(8);
	r2 = MR_stackvar(6);
	call_localret(STATIC(mercury__unify_proc__make_fresh_vars_5_0),
		mercury__unify_proc__generate_du_compare_clauses_8_0_i7,
		STATIC(mercury__unify_proc__generate_du_compare_clauses_8_0));
Define_label(mercury__unify_proc__generate_du_compare_clauses_8_0_i7);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_compare_clauses_8_0));
	MR_stackvar(9) = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(10) = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_du_compare_clauses_8_0, "origin_lost_in_value_number");
	r3 = MR_stackvar(4);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_stackvar(7);
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(5);
	call_localret(ENTRY(mercury__make_hlds__create_atomic_unification_6_0),
		mercury__unify_proc__generate_du_compare_clauses_8_0_i8,
		STATIC(mercury__unify_proc__generate_du_compare_clauses_8_0));
Define_label(mercury__unify_proc__generate_du_compare_clauses_8_0_i8);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_compare_clauses_8_0));
	r4 = MR_stackvar(5);
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(3);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_du_compare_clauses_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r2, (Integer) 0) = r4;
	r3 = MR_stackvar(4);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_stackvar(9);
	call_localret(ENTRY(mercury__make_hlds__create_atomic_unification_6_0),
		mercury__unify_proc__generate_du_compare_clauses_8_0_i9,
		STATIC(mercury__unify_proc__generate_du_compare_clauses_8_0));
Define_label(mercury__unify_proc__generate_du_compare_clauses_8_0_i9);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_compare_clauses_8_0));
	r2 = MR_stackvar(6);
	MR_stackvar(6) = r1;
	r1 = MR_stackvar(8);
	r3 = MR_stackvar(7);
	r4 = MR_stackvar(9);
	r5 = MR_stackvar(1);
	r6 = MR_stackvar(4);
	r7 = MR_stackvar(10);
	call_localret(STATIC(mercury__unify_proc__compare_args_2_9_0),
		mercury__unify_proc__generate_du_compare_clauses_8_0_i12,
		STATIC(mercury__unify_proc__generate_du_compare_clauses_8_0));
Define_label(mercury__unify_proc__generate_du_compare_clauses_8_0_i12);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_compare_clauses_8_0));
	if (!(r1))
		GOTO_LABEL(mercury__unify_proc__generate_du_compare_clauses_8_0_i11);
	r1 = MR_stackvar(5);
	MR_stackvar(5) = r3;
	r4 = MR_stackvar(6);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_du_compare_clauses_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_stackvar(6) = r3;
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_du_compare_clauses_8_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = r4;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_du_compare_clauses_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 1) = r1;
	MR_field(MR_mktag(1), MR_stackvar(6), (Integer) 1) = r5;
	MR_field(MR_mktag(1), r1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_init_1_0),
		mercury__unify_proc__generate_du_compare_clauses_8_0_i16,
		STATIC(mercury__unify_proc__generate_du_compare_clauses_8_0));
Define_label(mercury__unify_proc__generate_du_compare_clauses_8_0_i11);
	r1 = (Word) MR_string_const("unify_proc__compare_args: length mismatch", 41);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__unify_proc__generate_du_compare_clauses_8_0_i15,
		STATIC(mercury__unify_proc__generate_du_compare_clauses_8_0));
Define_label(mercury__unify_proc__generate_du_compare_clauses_8_0_i15);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_compare_clauses_8_0));
	call_localret(ENTRY(mercury__hlds_goal__goal_info_init_1_0),
		mercury__unify_proc__generate_du_compare_clauses_8_0_i16,
		STATIC(mercury__unify_proc__generate_du_compare_clauses_8_0));
Define_label(mercury__unify_proc__generate_du_compare_clauses_8_0_i16);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_compare_clauses_8_0));
	r2 = MR_stackvar(4);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_set_context_3_0),
		mercury__unify_proc__generate_du_compare_clauses_8_0_i17,
		STATIC(mercury__unify_proc__generate_du_compare_clauses_8_0));
Define_label(mercury__unify_proc__generate_du_compare_clauses_8_0_i17);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_compare_clauses_8_0));
	r2 = r1;
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__hlds_goal__conj_list_to_goal_3_0),
		mercury__unify_proc__generate_du_compare_clauses_8_0_i18,
		STATIC(mercury__unify_proc__generate_du_compare_clauses_8_0));
Define_label(mercury__unify_proc__generate_du_compare_clauses_8_0_i18);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_compare_clauses_8_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_du_compare_clauses_8_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	{
	Word MR_tempr1, MR_tempr2, MR_tempr3;
	MR_tempr1 = MR_stackvar(5);
	r4 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	r3 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	tag_incr_hp_msg(MR_tempr2, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_du_compare_clauses_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr2, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(MR_tempr3, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_du_compare_clauses_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr3, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_tempr2;
	MR_field(MR_mktag(1), MR_tempr2, (Integer) 1) = MR_tempr3;
	call_localret(ENTRY(mercury__quantification__implicitly_quantify_clause_body_8_0),
		mercury__unify_proc__generate_du_compare_clauses_8_0_i21,
		STATIC(mercury__unify_proc__generate_du_compare_clauses_8_0));
	}
Define_label(mercury__unify_proc__generate_du_compare_clauses_8_0_i2);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	call_localret(STATIC(mercury__unify_proc__generate_du_compare_clauses_2_8_0),
		mercury__unify_proc__generate_du_compare_clauses_8_0_i19,
		STATIC(mercury__unify_proc__generate_du_compare_clauses_8_0));
Define_label(mercury__unify_proc__generate_du_compare_clauses_8_0_i19);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_compare_clauses_8_0));
	r3 = r2;
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_du_compare_clauses_8_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_du_compare_clauses_8_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_stackvar(2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_du_compare_clauses_8_0, "origin_lost_in_value_number");
	r4 = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_stackvar(5) = r3;
	MR_field(MR_mktag(1), r5, (Integer) 1) = MR_tempr1;
	r3 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r5;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(3);
	call_localret(ENTRY(mercury__quantification__implicitly_quantify_clause_body_8_0),
		mercury__unify_proc__generate_du_compare_clauses_8_0_i21,
		STATIC(mercury__unify_proc__generate_du_compare_clauses_8_0));
	}
Define_label(mercury__unify_proc__generate_du_compare_clauses_8_0_i21);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_compare_clauses_8_0));
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(5);
	MR_stackvar(5) = r1;
	r1 = r2;
	r2 = MR_tempr1;
	MR_stackvar(6) = r3;
	call_localret(STATIC(mercury__unify_proc__info_set_varset_3_0),
		mercury__unify_proc__generate_du_compare_clauses_8_0_i22,
		STATIC(mercury__unify_proc__generate_du_compare_clauses_8_0));
	}
Define_label(mercury__unify_proc__generate_du_compare_clauses_8_0_i22);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_compare_clauses_8_0));
	r2 = r1;
	r1 = MR_stackvar(6);
	call_localret(STATIC(mercury__unify_proc__info_set_types_3_0),
		mercury__unify_proc__generate_du_compare_clauses_8_0_i23,
		STATIC(mercury__unify_proc__generate_du_compare_clauses_8_0));
Define_label(mercury__unify_proc__generate_du_compare_clauses_8_0_i23);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_compare_clauses_8_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_du_compare_clauses_8_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 3, mercury__unify_proc__generate_du_compare_clauses_8_0, "hlds_pred:clause/0");
	MR_field(MR_mktag(0), r3, (Integer) 0) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(5);
	MR_field(MR_mktag(0), r3, (Integer) 2) = MR_stackvar(4);
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	proceed();
END_MODULE

Declare_entry(mercury__prog_util__mercury_public_builtin_module_1_0);
Declare_entry(mercury__type_util__construct_type_3_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_llds__type_ctor_info_lval_0;

BEGIN_MODULE(unify_proc_module16)
	init_entry(mercury__unify_proc__generate_du_compare_clauses_2_8_0);
	init_label(mercury__unify_proc__generate_du_compare_clauses_2_8_0_i2);
	init_label(mercury__unify_proc__generate_du_compare_clauses_2_8_0_i3);
	init_label(mercury__unify_proc__generate_du_compare_clauses_2_8_0_i4);
	init_label(mercury__unify_proc__generate_du_compare_clauses_2_8_0_i5);
	init_label(mercury__unify_proc__generate_du_compare_clauses_2_8_0_i6);
	init_label(mercury__unify_proc__generate_du_compare_clauses_2_8_0_i7);
	init_label(mercury__unify_proc__generate_du_compare_clauses_2_8_0_i8);
	init_label(mercury__unify_proc__generate_du_compare_clauses_2_8_0_i9);
	init_label(mercury__unify_proc__generate_du_compare_clauses_2_8_0_i10);
	init_label(mercury__unify_proc__generate_du_compare_clauses_2_8_0_i11);
	init_label(mercury__unify_proc__generate_du_compare_clauses_2_8_0_i12);
	init_label(mercury__unify_proc__generate_du_compare_clauses_2_8_0_i13);
	init_label(mercury__unify_proc__generate_du_compare_clauses_2_8_0_i14);
	init_label(mercury__unify_proc__generate_du_compare_clauses_2_8_0_i15);
	init_label(mercury__unify_proc__generate_du_compare_clauses_2_8_0_i16);
	init_label(mercury__unify_proc__generate_du_compare_clauses_2_8_0_i17);
	init_label(mercury__unify_proc__generate_du_compare_clauses_2_8_0_i18);
	init_label(mercury__unify_proc__generate_du_compare_clauses_2_8_0_i19);
BEGIN_CODE

/* code for predicate 'generate_du_compare_clauses_2'/8 in mode 0 */
Define_static(mercury__unify_proc__generate_du_compare_clauses_2_8_0);
	MR_incr_sp_push_msg(14, "unify_proc:generate_du_compare_clauses_2/8");
	MR_stackvar(14) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r5;
	MR_stackvar(6) = r6;
	call_localret(ENTRY(mercury__fn__type_util__int_type_0_0),
		mercury__unify_proc__generate_du_compare_clauses_2_8_0_i2,
		STATIC(mercury__unify_proc__generate_du_compare_clauses_2_8_0));
Define_label(mercury__unify_proc__generate_du_compare_clauses_2_8_0_i2);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_compare_clauses_2_8_0));
	MR_stackvar(7) = r1;
	call_localret(ENTRY(mercury__prog_util__mercury_public_builtin_module_1_0),
		mercury__unify_proc__generate_du_compare_clauses_2_8_0_i3,
		STATIC(mercury__unify_proc__generate_du_compare_clauses_2_8_0));
Define_label(mercury__unify_proc__generate_du_compare_clauses_2_8_0_i3);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_compare_clauses_2_8_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__unify_proc__generate_du_compare_clauses_2_8_0, "std_util:pair/2");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_du_compare_clauses_2_8_0, "prog_data:sym_name/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_string_const("comparison_result", 17);
	MR_field(MR_mktag(0), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 1) = (Integer) 0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__type_util__construct_type_3_0),
		mercury__unify_proc__generate_du_compare_clauses_2_8_0_i4,
		STATIC(mercury__unify_proc__generate_du_compare_clauses_2_8_0));
Define_label(mercury__unify_proc__generate_du_compare_clauses_2_8_0_i4);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_compare_clauses_2_8_0));
	r2 = MR_stackvar(6);
	MR_stackvar(6) = r1;
	r1 = MR_stackvar(7);
	call_localret(STATIC(mercury__unify_proc__info_new_var_4_0),
		mercury__unify_proc__generate_du_compare_clauses_2_8_0_i5,
		STATIC(mercury__unify_proc__generate_du_compare_clauses_2_8_0));
Define_label(mercury__unify_proc__generate_du_compare_clauses_2_8_0_i5);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_compare_clauses_2_8_0));
	r3 = r1;
	r1 = MR_stackvar(7);
	MR_stackvar(7) = r3;
	call_localret(STATIC(mercury__unify_proc__info_new_var_4_0),
		mercury__unify_proc__generate_du_compare_clauses_2_8_0_i6,
		STATIC(mercury__unify_proc__generate_du_compare_clauses_2_8_0));
Define_label(mercury__unify_proc__generate_du_compare_clauses_2_8_0_i6);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_compare_clauses_2_8_0));
	r3 = r1;
	r1 = MR_stackvar(6);
	MR_stackvar(6) = r3;
	call_localret(STATIC(mercury__unify_proc__info_new_var_4_0),
		mercury__unify_proc__generate_du_compare_clauses_2_8_0_i7,
		STATIC(mercury__unify_proc__generate_du_compare_clauses_2_8_0));
Define_label(mercury__unify_proc__generate_du_compare_clauses_2_8_0_i7);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_compare_clauses_2_8_0));
	MR_stackvar(8) = r1;
	MR_stackvar(9) = r2;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_init_1_0),
		mercury__unify_proc__generate_du_compare_clauses_2_8_0_i8,
		STATIC(mercury__unify_proc__generate_du_compare_clauses_2_8_0));
Define_label(mercury__unify_proc__generate_du_compare_clauses_2_8_0_i8);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_compare_clauses_2_8_0));
	r2 = MR_stackvar(5);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_set_context_3_0),
		mercury__unify_proc__generate_du_compare_clauses_2_8_0_i9,
		STATIC(mercury__unify_proc__generate_du_compare_clauses_2_8_0));
Define_label(mercury__unify_proc__generate_du_compare_clauses_2_8_0_i9);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_compare_clauses_2_8_0));
	r4 = MR_stackvar(9);
	MR_stackvar(9) = r1;
	r1 = (Word) MR_string_const("index", 5);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_du_compare_clauses_2_8_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(3);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_du_compare_clauses_2_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_tempr1;
	r3 = MR_stackvar(5);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(7);
	call_localret(STATIC(mercury__unify_proc__build_call_6_0),
		mercury__unify_proc__generate_du_compare_clauses_2_8_0_i10,
		STATIC(mercury__unify_proc__generate_du_compare_clauses_2_8_0));
	}
Define_label(mercury__unify_proc__generate_du_compare_clauses_2_8_0_i10);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_compare_clauses_2_8_0));
	MR_stackvar(10) = r1;
	r1 = (Word) MR_string_const("index", 5);
	r4 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_du_compare_clauses_2_8_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(4);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_du_compare_clauses_2_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_tempr1;
	r3 = MR_stackvar(5);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(6);
	call_localret(STATIC(mercury__unify_proc__build_call_6_0),
		mercury__unify_proc__generate_du_compare_clauses_2_8_0_i11,
		STATIC(mercury__unify_proc__generate_du_compare_clauses_2_8_0));
	}
Define_label(mercury__unify_proc__generate_du_compare_clauses_2_8_0_i11);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_compare_clauses_2_8_0));
	MR_stackvar(11) = r1;
	r1 = (Word) MR_string_const("builtin_int_lt", 14);
	r4 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_du_compare_clauses_2_8_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(7);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_du_compare_clauses_2_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_tempr1;
	r3 = MR_stackvar(5);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(6);
	call_localret(STATIC(mercury__unify_proc__build_call_6_0),
		mercury__unify_proc__generate_du_compare_clauses_2_8_0_i12,
		STATIC(mercury__unify_proc__generate_du_compare_clauses_2_8_0));
	}
Define_label(mercury__unify_proc__generate_du_compare_clauses_2_8_0_i12);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_compare_clauses_2_8_0));
	r3 = MR_stackvar(6);
	MR_stackvar(6) = r1;
	r1 = (Word) MR_string_const("builtin_int_gt", 14);
	r5 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_du_compare_clauses_2_8_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(7);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_du_compare_clauses_2_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r3;
	r3 = MR_stackvar(5);
	r4 = r5;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(STATIC(mercury__unify_proc__build_call_6_0),
		mercury__unify_proc__generate_du_compare_clauses_2_8_0_i13,
		STATIC(mercury__unify_proc__generate_du_compare_clauses_2_8_0));
	}
Define_label(mercury__unify_proc__generate_du_compare_clauses_2_8_0_i13);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_compare_clauses_2_8_0));
	MR_stackvar(7) = r1;
	MR_stackvar(13) = r2;
	r1 = MR_stackvar(2);
	r2 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_unify_proc__common_9);
	r3 = MR_stackvar(5);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__make_hlds__create_atomic_unification_6_0),
		mercury__unify_proc__generate_du_compare_clauses_2_8_0_i14,
		STATIC(mercury__unify_proc__generate_du_compare_clauses_2_8_0));
Define_label(mercury__unify_proc__generate_du_compare_clauses_2_8_0_i14);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_compare_clauses_2_8_0));
	MR_stackvar(12) = r1;
	r1 = MR_stackvar(2);
	r2 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_unify_proc__common_12);
	r3 = MR_stackvar(5);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__make_hlds__create_atomic_unification_6_0),
		mercury__unify_proc__generate_du_compare_clauses_2_8_0_i15,
		STATIC(mercury__unify_proc__generate_du_compare_clauses_2_8_0));
Define_label(mercury__unify_proc__generate_du_compare_clauses_2_8_0_i15);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_compare_clauses_2_8_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r3;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 1, mercury__unify_proc__generate_du_compare_clauses_2_8_0, "origin_lost_in_value_number");
	r3 = MR_stackvar(5);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(8);
	call_localret(ENTRY(mercury__make_hlds__create_atomic_unification_6_0),
		mercury__unify_proc__generate_du_compare_clauses_2_8_0_i16,
		STATIC(mercury__unify_proc__generate_du_compare_clauses_2_8_0));
Define_label(mercury__unify_proc__generate_du_compare_clauses_2_8_0_i16);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_compare_clauses_2_8_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	r2 = MR_stackvar(8);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	r5 = MR_stackvar(5);
	r6 = MR_stackvar(13);
	call_localret(STATIC(mercury__unify_proc__generate_compare_cases_8_0),
		mercury__unify_proc__generate_du_compare_clauses_2_8_0_i17,
		STATIC(mercury__unify_proc__generate_du_compare_clauses_2_8_0));
	}
Define_label(mercury__unify_proc__generate_du_compare_clauses_2_8_0_i17);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_compare_clauses_2_8_0));
	MR_stackvar(3) = r1;
	MR_stackvar(4) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_3);
	r2 = (Word) (Word *) &mercury_data_llds__type_ctor_info_lval_0;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__unify_proc__generate_du_compare_clauses_2_8_0_i18,
		STATIC(mercury__unify_proc__generate_du_compare_clauses_2_8_0));
Define_label(mercury__unify_proc__generate_du_compare_clauses_2_8_0_i18);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_compare_clauses_2_8_0));
	r2 = MR_stackvar(3);
	MR_stackvar(3) = r1;
	r3 = MR_stackvar(4);
	tag_incr_hp_msg(MR_stackvar(4), MR_mktag(0), (Integer) 2, mercury__unify_proc__generate_du_compare_clauses_2_8_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 3, mercury__unify_proc__generate_du_compare_clauses_2_8_0, "origin_lost_in_value_number");
	r4 = r3;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r2;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = r1;
	MR_field(MR_mktag(0), MR_stackvar(4), (Integer) 0) = MR_tempr1;
	r1 = (Word) MR_string_const("compare_error", 13);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r3 = MR_stackvar(5);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(0), MR_stackvar(4), (Integer) 1) = MR_stackvar(9);
	call_localret(STATIC(mercury__unify_proc__build_call_6_0),
		mercury__unify_proc__generate_du_compare_clauses_2_8_0_i19,
		STATIC(mercury__unify_proc__generate_du_compare_clauses_2_8_0));
	}
Define_label(mercury__unify_proc__generate_du_compare_clauses_2_8_0_i19);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_du_compare_clauses_2_8_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__unify_proc__generate_du_compare_clauses_2_8_0, "std_util:pair/2");
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 1, mercury__unify_proc__generate_du_compare_clauses_2_8_0, "hlds_goal:hlds_goal_expr/0");
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_du_compare_clauses_2_8_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_stackvar(10);
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_du_compare_clauses_2_8_0, "list:list/1");
	MR_field(MR_mktag(1), r6, (Integer) 0) = MR_stackvar(11);
	tag_incr_hp_msg(r7, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_du_compare_clauses_2_8_0, "list:list/1");
	tag_incr_hp_msg(r8, MR_mktag(0), (Integer) 2, mercury__unify_proc__generate_du_compare_clauses_2_8_0, "std_util:pair/2");
	tag_incr_hp_msg(r9, MR_mktag(3), (Integer) 6, mercury__unify_proc__generate_du_compare_clauses_2_8_0, "hlds_goal:hlds_goal_expr/0");
	MR_field(MR_mktag(3), r9, (Integer) 0) = (Integer) 5;
	MR_field(MR_mktag(3), r9, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(3), r9, (Integer) 2) = MR_stackvar(6);
	MR_field(MR_mktag(3), r9, (Integer) 3) = MR_stackvar(12);
	tag_incr_hp_msg(r10, MR_mktag(0), (Integer) 2, mercury__unify_proc__generate_du_compare_clauses_2_8_0, "std_util:pair/2");
	tag_incr_hp_msg(r11, MR_mktag(3), (Integer) 6, mercury__unify_proc__generate_du_compare_clauses_2_8_0, "hlds_goal:hlds_goal_expr/0");
	MR_field(MR_mktag(3), r11, (Integer) 0) = (Integer) 5;
	MR_field(MR_mktag(3), r11, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(3), r11, (Integer) 2) = MR_stackvar(7);
	MR_field(MR_mktag(3), r11, (Integer) 3) = MR_stackvar(2);
	tag_incr_hp_msg(r12, MR_mktag(0), (Integer) 2, mercury__unify_proc__generate_du_compare_clauses_2_8_0, "std_util:pair/2");
	{
	Word MR_tempr1, MR_tempr2, MR_tempr3;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 6, mercury__unify_proc__generate_du_compare_clauses_2_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r12, (Integer) 0) = MR_tempr1;
	MR_tempr2 = MR_stackvar(9);
	MR_tempr3 = MR_stackvar(3);
	MR_field(MR_mktag(3), r9, (Integer) 4) = r10;
	MR_field(MR_mktag(3), r9, (Integer) 5) = MR_tempr3;
	MR_field(MR_mktag(3), r11, (Integer) 4) = r12;
	MR_field(MR_mktag(3), r11, (Integer) 5) = MR_tempr3;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 4) = r3;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 3) = MR_stackvar(1);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_stackvar(4);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 5;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 5) = MR_tempr3;
	MR_field(MR_mktag(1), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 1) = r7;
	MR_field(MR_mktag(1), r7, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r7, (Integer) 0) = r8;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_tempr2;
	MR_field(MR_mktag(0), r1, (Integer) 0) = r4;
	MR_field(MR_mktag(0), r4, (Integer) 0) = r5;
	MR_field(MR_mktag(0), r8, (Integer) 1) = MR_tempr2;
	MR_field(MR_mktag(0), r8, (Integer) 0) = r9;
	MR_field(MR_mktag(0), r10, (Integer) 1) = MR_tempr2;
	MR_field(MR_mktag(0), r10, (Integer) 0) = r11;
	MR_field(MR_mktag(0), r12, (Integer) 1) = MR_tempr2;
	MR_succip = (Code *) MR_stackvar(14);
	MR_decr_sp_pop_msg(14);
	proceed();
	}
END_MODULE


BEGIN_MODULE(unify_proc_module17)
	init_entry(mercury__unify_proc__generate_compare_cases_8_0);
	init_label(mercury__unify_proc__generate_compare_cases_8_0_i4);
	init_label(mercury__unify_proc__generate_compare_cases_8_0_i5);
	init_label(mercury__unify_proc__generate_compare_cases_8_0_i6);
	init_label(mercury__unify_proc__generate_compare_cases_8_0_i7);
	init_label(mercury__unify_proc__generate_compare_cases_8_0_i8);
	init_label(mercury__unify_proc__generate_compare_cases_8_0_i11);
	init_label(mercury__unify_proc__generate_compare_cases_8_0_i10);
	init_label(mercury__unify_proc__generate_compare_cases_8_0_i14);
	init_label(mercury__unify_proc__generate_compare_cases_8_0_i15);
	init_label(mercury__unify_proc__generate_compare_cases_8_0_i16);
	init_label(mercury__unify_proc__generate_compare_cases_8_0_i17);
	init_label(mercury__unify_proc__generate_compare_cases_8_0_i18);
	init_label(mercury__unify_proc__generate_compare_cases_8_0_i3);
BEGIN_CODE

/* code for predicate 'generate_compare_cases'/8 in mode 0 */
Define_static(mercury__unify_proc__generate_compare_cases_8_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_proc__generate_compare_cases_8_0_i3);
	MR_incr_sp_push_msg(12, "unify_proc:generate_compare_cases/8");
	MR_stackvar(12) = (Word) MR_succip;
	MR_stackvar(1) = r2;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 3);
	MR_stackvar(9) = r2;
	MR_stackvar(6) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 2);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_6);
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r6;
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__unify_proc__generate_compare_cases_8_0_i4,
		STATIC(mercury__unify_proc__generate_compare_cases_8_0));
	}
Define_label(mercury__unify_proc__generate_compare_cases_8_0_i4);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_compare_cases_8_0));
	r3 = MR_stackvar(5);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 2, mercury__unify_proc__generate_compare_cases_8_0, "origin_lost_in_value_number");
	MR_stackvar(5) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 1) = r1;
	r1 = MR_stackvar(9);
	r2 = MR_stackvar(7);
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_stackvar(8);
	call_localret(STATIC(mercury__unify_proc__make_fresh_vars_5_0),
		mercury__unify_proc__generate_compare_cases_8_0_i5,
		STATIC(mercury__unify_proc__generate_compare_cases_8_0));
	}
Define_label(mercury__unify_proc__generate_compare_cases_8_0_i5);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_compare_cases_8_0));
	r3 = r2;
	MR_stackvar(8) = r1;
	r1 = MR_stackvar(9);
	r2 = MR_stackvar(7);
	call_localret(STATIC(mercury__unify_proc__make_fresh_vars_5_0),
		mercury__unify_proc__generate_compare_cases_8_0_i6,
		STATIC(mercury__unify_proc__generate_compare_cases_8_0));
Define_label(mercury__unify_proc__generate_compare_cases_8_0_i6);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_compare_cases_8_0));
	MR_stackvar(10) = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(11) = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_compare_cases_8_0, "origin_lost_in_value_number");
	r3 = MR_stackvar(4);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_stackvar(8);
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(5);
	call_localret(ENTRY(mercury__make_hlds__create_atomic_unification_6_0),
		mercury__unify_proc__generate_compare_cases_8_0_i7,
		STATIC(mercury__unify_proc__generate_compare_cases_8_0));
Define_label(mercury__unify_proc__generate_compare_cases_8_0_i7);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_compare_cases_8_0));
	r4 = MR_stackvar(5);
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(3);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_compare_cases_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r2, (Integer) 0) = r4;
	r3 = MR_stackvar(4);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_stackvar(10);
	call_localret(ENTRY(mercury__make_hlds__create_atomic_unification_6_0),
		mercury__unify_proc__generate_compare_cases_8_0_i8,
		STATIC(mercury__unify_proc__generate_compare_cases_8_0));
Define_label(mercury__unify_proc__generate_compare_cases_8_0_i8);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_compare_cases_8_0));
	r2 = MR_stackvar(7);
	MR_stackvar(7) = r1;
	r1 = MR_stackvar(9);
	r3 = MR_stackvar(8);
	r4 = MR_stackvar(10);
	r5 = MR_stackvar(1);
	r6 = MR_stackvar(4);
	r7 = MR_stackvar(11);
	call_localret(STATIC(mercury__unify_proc__compare_args_2_9_0),
		mercury__unify_proc__generate_compare_cases_8_0_i11,
		STATIC(mercury__unify_proc__generate_compare_cases_8_0));
Define_label(mercury__unify_proc__generate_compare_cases_8_0_i11);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_compare_cases_8_0));
	if (!(r1))
		GOTO_LABEL(mercury__unify_proc__generate_compare_cases_8_0_i10);
	r1 = MR_stackvar(5);
	MR_stackvar(5) = r3;
	r4 = MR_stackvar(7);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_compare_cases_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	MR_stackvar(7) = r3;
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_compare_cases_8_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = r4;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_compare_cases_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 1) = r1;
	MR_field(MR_mktag(1), MR_stackvar(7), (Integer) 1) = r5;
	MR_field(MR_mktag(1), r1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_init_1_0),
		mercury__unify_proc__generate_compare_cases_8_0_i15,
		STATIC(mercury__unify_proc__generate_compare_cases_8_0));
Define_label(mercury__unify_proc__generate_compare_cases_8_0_i10);
	r1 = (Word) MR_string_const("unify_proc__compare_args: length mismatch", 41);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__unify_proc__generate_compare_cases_8_0_i14,
		STATIC(mercury__unify_proc__generate_compare_cases_8_0));
Define_label(mercury__unify_proc__generate_compare_cases_8_0_i14);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_compare_cases_8_0));
	call_localret(ENTRY(mercury__hlds_goal__goal_info_init_1_0),
		mercury__unify_proc__generate_compare_cases_8_0_i15,
		STATIC(mercury__unify_proc__generate_compare_cases_8_0));
Define_label(mercury__unify_proc__generate_compare_cases_8_0_i15);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_compare_cases_8_0));
	r2 = MR_stackvar(4);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_set_context_3_0),
		mercury__unify_proc__generate_compare_cases_8_0_i16,
		STATIC(mercury__unify_proc__generate_compare_cases_8_0));
Define_label(mercury__unify_proc__generate_compare_cases_8_0_i16);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_compare_cases_8_0));
	r2 = r1;
	r1 = MR_stackvar(7);
	call_localret(ENTRY(mercury__hlds_goal__conj_list_to_goal_3_0),
		mercury__unify_proc__generate_compare_cases_8_0_i17,
		STATIC(mercury__unify_proc__generate_compare_cases_8_0));
Define_label(mercury__unify_proc__generate_compare_cases_8_0_i17);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_compare_cases_8_0));
	r6 = MR_stackvar(5);
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	localcall(mercury__unify_proc__generate_compare_cases_8_0,
		LABEL(mercury__unify_proc__generate_compare_cases_8_0_i18),
		STATIC(mercury__unify_proc__generate_compare_cases_8_0));
Define_label(mercury__unify_proc__generate_compare_cases_8_0_i18);
	update_prof_current_proc(LABEL(mercury__unify_proc__generate_compare_cases_8_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__unify_proc__generate_compare_cases_8_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(5);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	proceed();
Define_label(mercury__unify_proc__generate_compare_cases_8_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = r6;
	proceed();
END_MODULE

Declare_entry(mercury__list__member_2_1);
Declare_entry(mercury__term__contains_var_2_0);
Declare_entry(do_redo);

BEGIN_MODULE(unify_proc_module18)
	init_entry(mercury__unify_proc__compare_args_2_9_0);
	init_label(mercury__unify_proc__compare_args_2_9_0_i6);
	init_label(mercury__unify_proc__compare_args_2_9_0_i3);
	init_label(mercury__unify_proc__compare_args_2_9_0_i9);
	init_label(mercury__unify_proc__compare_args_2_9_0_i10);
	init_label(mercury__unify_proc__compare_args_2_9_0_i15);
	init_label(mercury__unify_proc__compare_args_2_9_0_i1050);
	init_label(mercury__unify_proc__compare_args_2_9_0_i13);
	init_label(mercury__unify_proc__compare_args_2_9_0_i18);
	init_label(mercury__unify_proc__compare_args_2_9_0_i12);
	init_label(mercury__unify_proc__compare_args_2_9_0_i19);
	init_label(mercury__unify_proc__compare_args_2_9_0_i23);
	init_label(mercury__unify_proc__compare_args_2_9_0_i20);
	init_label(mercury__unify_proc__compare_args_2_9_0_i24);
	init_label(mercury__unify_proc__compare_args_2_9_0_i25);
	init_label(mercury__unify_proc__compare_args_2_9_0_i26);
	init_label(mercury__unify_proc__compare_args_2_9_0_i27);
	init_label(mercury__unify_proc__compare_args_2_9_0_i28);
	init_label(mercury__unify_proc__compare_args_2_9_0_i29);
	init_label(mercury__unify_proc__compare_args_2_9_0_i30);
	init_label(mercury__unify_proc__compare_args_2_9_0_i31);
	init_label(mercury__unify_proc__compare_args_2_9_0_i1038);
	init_label(mercury__unify_proc__compare_args_2_9_0_i1);
BEGIN_CODE

/* code for predicate 'compare_args_2'/9 in mode 0 */
Define_static(mercury__unify_proc__compare_args_2_9_0);
	MR_incr_sp_push_msg(17, "unify_proc:compare_args_2/9");
	MR_stackvar(17) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_proc__compare_args_2_9_0_i3);
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_proc__compare_args_2_9_0_i1038);
	if (((Integer) r4 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_proc__compare_args_2_9_0_i1038);
	MR_stackvar(1) = r7;
	r1 = r5;
	r2 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_unify_proc__common_15);
	r3 = r6;
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__make_hlds__create_atomic_unification_6_0),
		mercury__unify_proc__compare_args_2_9_0_i6,
		STATIC(mercury__unify_proc__compare_args_2_9_0));
Define_label(mercury__unify_proc__compare_args_2_9_0_i6);
	update_prof_current_proc(LABEL(mercury__unify_proc__compare_args_2_9_0));
	r2 = r1;
	r3 = MR_stackvar(1);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(17);
	MR_decr_sp_pop_msg(17);
	proceed();
Define_label(mercury__unify_proc__compare_args_2_9_0_i3);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_proc__compare_args_2_9_0_i1);
	if (((Integer) r4 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_proc__compare_args_2_9_0_i1);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r5;
	MR_stackvar(3) = r6;
	MR_stackvar(4) = r7;
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(7) = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_stackvar(8) = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	MR_stackvar(9) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_stackvar(10) = MR_const_field(MR_mktag(1), r4, (Integer) 1);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_init_1_0),
		mercury__unify_proc__compare_args_2_9_0_i9,
		STATIC(mercury__unify_proc__compare_args_2_9_0));
Define_label(mercury__unify_proc__compare_args_2_9_0_i9);
	update_prof_current_proc(LABEL(mercury__unify_proc__compare_args_2_9_0));
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_set_context_3_0),
		mercury__unify_proc__compare_args_2_9_0_i10,
		STATIC(mercury__unify_proc__compare_args_2_9_0));
Define_label(mercury__unify_proc__compare_args_2_9_0_i10);
	update_prof_current_proc(LABEL(mercury__unify_proc__compare_args_2_9_0));
	MR_stackvar(14) = (Word) MR_redoip_slot(MR_maxfr);
	MR_stackvar(15) = (Word) MR_redofr_slot(MR_maxfr);
	MR_stackvar(16) = (Word) MR_maxfr;
	MR_redofr_slot(MR_maxfr) = MR_curfr;
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__unify_proc__compare_args_2_9_0_i13);
	MR_stackvar(11) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_5);
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__list__member_2_1),
		mercury__unify_proc__compare_args_2_9_0_i15,
		STATIC(mercury__unify_proc__compare_args_2_9_0));
Define_label(mercury__unify_proc__compare_args_2_9_0_i15);
	update_prof_current_proc(LABEL(mercury__unify_proc__compare_args_2_9_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	r2 = MR_stackvar(5);
	call_localret(ENTRY(mercury__term__contains_var_2_0),
		mercury__unify_proc__compare_args_2_9_0_i1050,
		STATIC(mercury__unify_proc__compare_args_2_9_0));
Define_label(mercury__unify_proc__compare_args_2_9_0_i1050);
	update_prof_current_proc(LABEL(mercury__unify_proc__compare_args_2_9_0));
	if (!(r1))
		GOTO(ENTRY(do_redo));
	MR_maxfr = (Word *) MR_stackvar(16);
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(14);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(15);
	GOTO_LABEL(mercury__unify_proc__compare_args_2_9_0_i18);
Define_label(mercury__unify_proc__compare_args_2_9_0_i13);
	update_prof_current_proc(LABEL(mercury__unify_proc__compare_args_2_9_0));
	r1 = MR_stackvar(11);
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(14);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(15);
	GOTO_LABEL(mercury__unify_proc__compare_args_2_9_0_i12);
Define_label(mercury__unify_proc__compare_args_2_9_0_i18);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	r1 = (Word) MR_string_const("typed_compare", 13);
	GOTO_LABEL(mercury__unify_proc__compare_args_2_9_0_i19);
Define_label(mercury__unify_proc__compare_args_2_9_0_i12);
	MR_stackvar(11) = r1;
	r1 = (Word) MR_string_const("compare", 7);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
Define_label(mercury__unify_proc__compare_args_2_9_0_i19);
	if (((Integer) MR_stackvar(8) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_proc__compare_args_2_9_0_i20);
	if (((Integer) MR_stackvar(10) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_proc__compare_args_2_9_0_i20);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__unify_proc__compare_args_2_9_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__unify_proc__compare_args_2_9_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_stackvar(7);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__unify_proc__compare_args_2_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r2, (Integer) 1) = r5;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(9);
	call_localret(STATIC(mercury__unify_proc__build_call_6_0),
		mercury__unify_proc__compare_args_2_9_0_i23,
		STATIC(mercury__unify_proc__compare_args_2_9_0));
	}
Define_label(mercury__unify_proc__compare_args_2_9_0_i23);
	update_prof_current_proc(LABEL(mercury__unify_proc__compare_args_2_9_0));
	r3 = r2;
	r2 = r1;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(17);
	MR_decr_sp_pop_msg(17);
	proceed();
Define_label(mercury__unify_proc__compare_args_2_9_0_i20);
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r1;
	call_localret(ENTRY(mercury__prog_util__mercury_public_builtin_module_1_0),
		mercury__unify_proc__compare_args_2_9_0_i24,
		STATIC(mercury__unify_proc__compare_args_2_9_0));
Define_label(mercury__unify_proc__compare_args_2_9_0_i24);
	update_prof_current_proc(LABEL(mercury__unify_proc__compare_args_2_9_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__unify_proc__compare_args_2_9_0, "std_util:pair/2");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__unify_proc__compare_args_2_9_0, "prog_data:sym_name/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_string_const("comparison_result", 17);
	MR_field(MR_mktag(0), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 1) = (Integer) 0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__type_util__construct_type_3_0),
		mercury__unify_proc__compare_args_2_9_0_i25,
		STATIC(mercury__unify_proc__compare_args_2_9_0));
Define_label(mercury__unify_proc__compare_args_2_9_0_i25);
	update_prof_current_proc(LABEL(mercury__unify_proc__compare_args_2_9_0));
	r2 = MR_stackvar(4);
	call_localret(STATIC(mercury__unify_proc__info_new_var_4_0),
		mercury__unify_proc__compare_args_2_9_0_i26,
		STATIC(mercury__unify_proc__compare_args_2_9_0));
Define_label(mercury__unify_proc__compare_args_2_9_0_i26);
	update_prof_current_proc(LABEL(mercury__unify_proc__compare_args_2_9_0));
	r3 = MR_stackvar(5);
	MR_stackvar(5) = r1;
	r4 = r1;
	r1 = r3;
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__unify_proc__compare_args_2_9_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = r4;
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__unify_proc__compare_args_2_9_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_stackvar(7);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__unify_proc__compare_args_2_9_0, "origin_lost_in_value_number");
	r4 = r3;
	MR_field(MR_mktag(1), r5, (Integer) 1) = MR_tempr1;
	r3 = MR_stackvar(3);
	MR_field(MR_mktag(1), r2, (Integer) 1) = r5;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(9);
	call_localret(STATIC(mercury__unify_proc__build_call_6_0),
		mercury__unify_proc__compare_args_2_9_0_i27,
		STATIC(mercury__unify_proc__compare_args_2_9_0));
	}
Define_label(mercury__unify_proc__compare_args_2_9_0_i27);
	update_prof_current_proc(LABEL(mercury__unify_proc__compare_args_2_9_0));
	MR_stackvar(12) = r1;
	MR_stackvar(13) = r2;
	r1 = MR_stackvar(5);
	r2 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_unify_proc__common_15);
	r3 = MR_stackvar(3);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__make_hlds__create_atomic_unification_6_0),
		mercury__unify_proc__compare_args_2_9_0_i28,
		STATIC(mercury__unify_proc__compare_args_2_9_0));
Define_label(mercury__unify_proc__compare_args_2_9_0_i28);
	update_prof_current_proc(LABEL(mercury__unify_proc__compare_args_2_9_0));
	r2 = MR_stackvar(5);
	tag_incr_hp_msg(MR_stackvar(5), MR_mktag(0), (Integer) 2, mercury__unify_proc__compare_args_2_9_0, "std_util:pair/2");
	r4 = r2;
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 2, mercury__unify_proc__compare_args_2_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r3, (Integer) 1) = r1;
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(0), MR_stackvar(5), (Integer) 1) = MR_stackvar(11);
	r1 = MR_stackvar(2);
	MR_field(MR_mktag(0), MR_stackvar(5), (Integer) 0) = r3;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 1, mercury__unify_proc__compare_args_2_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 0) = r4;
	r3 = MR_stackvar(3);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__make_hlds__create_atomic_unification_6_0),
		mercury__unify_proc__compare_args_2_9_0_i29,
		STATIC(mercury__unify_proc__compare_args_2_9_0));
Define_label(mercury__unify_proc__compare_args_2_9_0_i29);
	update_prof_current_proc(LABEL(mercury__unify_proc__compare_args_2_9_0));
	r2 = MR_stackvar(5);
	MR_stackvar(5) = r1;
	r3 = MR_stackvar(12);
	tag_incr_hp_msg(MR_stackvar(12), MR_mktag(0), (Integer) 2, mercury__unify_proc__compare_args_2_9_0, "std_util:pair/2");
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 1, mercury__unify_proc__compare_args_2_9_0, "hlds_goal:hlds_goal_expr/0");
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__unify_proc__compare_args_2_9_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = r3;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__unify_proc__compare_args_2_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_3);
	r2 = (Word) (Word *) &mercury_data_llds__type_ctor_info_lval_0;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), MR_stackvar(12), (Integer) 1) = MR_stackvar(11);
	MR_field(MR_mktag(0), MR_stackvar(12), (Integer) 0) = r4;
	MR_field(MR_mktag(0), r4, (Integer) 0) = r5;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__unify_proc__compare_args_2_9_0_i30,
		STATIC(mercury__unify_proc__compare_args_2_9_0));
Define_label(mercury__unify_proc__compare_args_2_9_0_i30);
	update_prof_current_proc(LABEL(mercury__unify_proc__compare_args_2_9_0));
	r7 = MR_stackvar(13);
	MR_stackvar(13) = r1;
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(8);
	r4 = MR_stackvar(10);
	r5 = MR_stackvar(2);
	r6 = MR_stackvar(3);
	localcall(mercury__unify_proc__compare_args_2_9_0,
		LABEL(mercury__unify_proc__compare_args_2_9_0_i31),
		STATIC(mercury__unify_proc__compare_args_2_9_0));
Define_label(mercury__unify_proc__compare_args_2_9_0_i31);
	update_prof_current_proc(LABEL(mercury__unify_proc__compare_args_2_9_0));
	if (!(r1))
		GOTO_LABEL(mercury__unify_proc__compare_args_2_9_0_i1);
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 2, mercury__unify_proc__compare_args_2_9_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 6, mercury__unify_proc__compare_args_2_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 4) = r1;
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_tempr1;
	r1 = TRUE;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 3) = MR_stackvar(5);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_stackvar(12);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 5;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 5) = MR_stackvar(13);
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_stackvar(11);
	MR_succip = (Code *) MR_stackvar(17);
	MR_decr_sp_pop_msg(17);
	proceed();
	}
Define_label(mercury__unify_proc__compare_args_2_9_0_i1038);
	r1 = FALSE;
	MR_decr_sp_pop_msg(17);
	proceed();
Define_label(mercury__unify_proc__compare_args_2_9_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(17);
	MR_decr_sp_pop_msg(17);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_module__module_info_get_predicate_table_2_0);
Declare_entry(mercury__special_pred__special_pred_name_arity_4_1);
Declare_entry(mercury__prog_util__mercury_private_builtin_module_1_0);
Declare_entry(mercury__hlds_module__predicate_table_search_pred_m_n_a_5_0);
Declare_entry(mercury____Unify___list__list_1_0);
Declare_entry(mercury__prog_out__sym_name_to_string_2_0);
Declare_entry(mercury__string__int_to_string_2_0);
Declare_entry(mercury__string__append_list_2_0);
Declare_entry(mercury__hlds_pred__initial_proc_id_1_0);

BEGIN_MODULE(unify_proc_module19)
	init_entry(mercury__unify_proc__build_call_6_0);
	init_label(mercury__unify_proc__build_call_6_0_i2);
	init_label(mercury__unify_proc__build_call_6_0_i3);
	init_label(mercury__unify_proc__build_call_6_0_i6);
	init_label(mercury__unify_proc__build_call_6_0_i4);
	init_label(mercury__unify_proc__build_call_6_0_i9);
	init_label(mercury__unify_proc__build_call_6_0_i12);
	init_label(mercury__unify_proc__build_call_6_0_i15);
	init_label(mercury__unify_proc__build_call_6_0_i11);
	init_label(mercury__unify_proc__build_call_6_0_i17);
	init_label(mercury__unify_proc__build_call_6_0_i18);
	init_label(mercury__unify_proc__build_call_6_0_i19);
	init_label(mercury__unify_proc__build_call_6_0_i21);
	init_label(mercury__unify_proc__build_call_6_0_i22);
	init_label(mercury__unify_proc__build_call_6_0_i23);
	init_label(mercury__unify_proc__build_call_6_0_i24);
BEGIN_CODE

/* code for predicate 'build_call'/6 in mode 0 */
Define_static(mercury__unify_proc__build_call_6_0);
	MR_incr_sp_push_msg(9, "unify_proc:build_call/6");
	MR_stackvar(9) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = MR_const_field(MR_mktag(0), r4, (Integer) 2);
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	call_localret(ENTRY(mercury__hlds_module__module_info_get_predicate_table_2_0),
		mercury__unify_proc__build_call_6_0_i2,
		STATIC(mercury__unify_proc__build_call_6_0));
Define_label(mercury__unify_proc__build_call_6_0_i2);
	update_prof_current_proc(LABEL(mercury__unify_proc__build_call_6_0));
	MR_stackvar(5) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_3);
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__unify_proc__build_call_6_0_i3,
		STATIC(mercury__unify_proc__build_call_6_0));
Define_label(mercury__unify_proc__build_call_6_0_i3);
	update_prof_current_proc(LABEL(mercury__unify_proc__build_call_6_0));
	MR_stackvar(6) = r1;
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__special_pred__special_pred_name_arity_4_1),
		mercury__unify_proc__build_call_6_0_i6,
		STATIC(mercury__unify_proc__build_call_6_0));
Define_label(mercury__unify_proc__build_call_6_0_i6);
	update_prof_current_proc(LABEL(mercury__unify_proc__build_call_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__unify_proc__build_call_6_0_i4);
	call_localret(ENTRY(mercury__prog_util__mercury_public_builtin_module_1_0),
		mercury__unify_proc__build_call_6_0_i9,
		STATIC(mercury__unify_proc__build_call_6_0));
Define_label(mercury__unify_proc__build_call_6_0_i4);
	call_localret(ENTRY(mercury__prog_util__mercury_private_builtin_module_1_0),
		mercury__unify_proc__build_call_6_0_i9,
		STATIC(mercury__unify_proc__build_call_6_0));
Define_label(mercury__unify_proc__build_call_6_0_i9);
	update_prof_current_proc(LABEL(mercury__unify_proc__build_call_6_0));
	r2 = r1;
	MR_stackvar(7) = r1;
	r1 = MR_stackvar(5);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(6);
	call_localret(ENTRY(mercury__hlds_module__predicate_table_search_pred_m_n_a_5_0),
		mercury__unify_proc__build_call_6_0_i12,
		STATIC(mercury__unify_proc__build_call_6_0));
Define_label(mercury__unify_proc__build_call_6_0_i12);
	update_prof_current_proc(LABEL(mercury__unify_proc__build_call_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__unify_proc__build_call_6_0_i11);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_proc__build_call_6_0_i11);
	r3 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	MR_stackvar(8) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_id_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury__unify_proc__build_call_6_0_i15,
		STATIC(mercury__unify_proc__build_call_6_0));
Define_label(mercury__unify_proc__build_call_6_0_i15);
	update_prof_current_proc(LABEL(mercury__unify_proc__build_call_6_0));
	if (r1)
		GOTO_LABEL(mercury__unify_proc__build_call_6_0_i21);
Define_label(mercury__unify_proc__build_call_6_0_i11);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__unify_proc__build_call_6_0, "prog_data:sym_name/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(7);
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_stackvar(1);
	call_localret(ENTRY(mercury__prog_out__sym_name_to_string_2_0),
		mercury__unify_proc__build_call_6_0_i17,
		STATIC(mercury__unify_proc__build_call_6_0));
Define_label(mercury__unify_proc__build_call_6_0_i17);
	update_prof_current_proc(LABEL(mercury__unify_proc__build_call_6_0));
	MR_stackvar(8) = r1;
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__unify_proc__build_call_6_0_i18,
		STATIC(mercury__unify_proc__build_call_6_0));
Define_label(mercury__unify_proc__build_call_6_0_i18);
	update_prof_current_proc(LABEL(mercury__unify_proc__build_call_6_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__unify_proc__build_call_6_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = (Word) MR_string_const("unify_proc__build_call: ", 24);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__unify_proc__build_call_6_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const("invalid/ambiguous pred `", 24);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__unify_proc__build_call_6_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_stackvar(8);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__unify_proc__build_call_6_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = (Word) MR_string_const("/", 1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__unify_proc__build_call_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_unify_proc__common_16);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__unify_proc__build_call_6_0_i19,
		STATIC(mercury__unify_proc__build_call_6_0));
	}
Define_label(mercury__unify_proc__build_call_6_0_i19);
	update_prof_current_proc(LABEL(mercury__unify_proc__build_call_6_0));
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__unify_proc__build_call_6_0_i21,
		STATIC(mercury__unify_proc__build_call_6_0));
Define_label(mercury__unify_proc__build_call_6_0_i21);
	update_prof_current_proc(LABEL(mercury__unify_proc__build_call_6_0));
	call_localret(ENTRY(mercury__hlds_pred__initial_proc_id_1_0),
		mercury__unify_proc__build_call_6_0_i22,
		STATIC(mercury__unify_proc__build_call_6_0));
Define_label(mercury__unify_proc__build_call_6_0_i22);
	update_prof_current_proc(LABEL(mercury__unify_proc__build_call_6_0));
	r2 = MR_stackvar(8);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 6, mercury__unify_proc__build_call_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 4) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r3, (Integer) 3) = (Integer) 2;
	MR_field(MR_mktag(1), r3, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(1), r3, (Integer) 1) = r1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r2;
	MR_stackvar(8) = r3;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__unify_proc__build_call_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 5) = r1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(7);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_init_1_0),
		mercury__unify_proc__build_call_6_0_i23,
		STATIC(mercury__unify_proc__build_call_6_0));
Define_label(mercury__unify_proc__build_call_6_0_i23);
	update_prof_current_proc(LABEL(mercury__unify_proc__build_call_6_0));
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_set_context_3_0),
		mercury__unify_proc__build_call_6_0_i24,
		STATIC(mercury__unify_proc__build_call_6_0));
Define_label(mercury__unify_proc__build_call_6_0_i24);
	update_prof_current_proc(LABEL(mercury__unify_proc__build_call_6_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 2, mercury__unify_proc__build_call_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r1, (Integer) 1) = r2;
	r2 = MR_stackvar(4);
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(8);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE

Declare_entry(mercury__string__append_3_2);
Declare_entry(mercury__varset__new_named_var_4_0);

BEGIN_MODULE(unify_proc_module20)
	init_entry(mercury__unify_proc__make_fresh_named_vars_from_types_6_0);
	init_label(mercury__unify_proc__make_fresh_named_vars_from_types_6_0_i4);
	init_label(mercury__unify_proc__make_fresh_named_vars_from_types_6_0_i5);
	init_label(mercury__unify_proc__make_fresh_named_vars_from_types_6_0_i6);
	init_label(mercury__unify_proc__make_fresh_named_vars_from_types_6_0_i7);
	init_label(mercury__unify_proc__make_fresh_named_vars_from_types_6_0_i8);
	init_label(mercury__unify_proc__make_fresh_named_vars_from_types_6_0_i3);
BEGIN_CODE

/* code for predicate 'make_fresh_named_vars_from_types'/6 in mode 0 */
Define_static(mercury__unify_proc__make_fresh_named_vars_from_types_6_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_proc__make_fresh_named_vars_from_types_6_0_i3);
	MR_incr_sp_push_msg(7, "unify_proc:make_fresh_named_vars_from_types/6");
	MR_stackvar(7) = (Word) MR_succip;
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = r3;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__unify_proc__make_fresh_named_vars_from_types_6_0_i4,
		STATIC(mercury__unify_proc__make_fresh_named_vars_from_types_6_0));
Define_label(mercury__unify_proc__make_fresh_named_vars_from_types_6_0_i4);
	update_prof_current_proc(LABEL(mercury__unify_proc__make_fresh_named_vars_from_types_6_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__unify_proc__make_fresh_named_vars_from_types_6_0_i5,
		STATIC(mercury__unify_proc__make_fresh_named_vars_from_types_6_0));
Define_label(mercury__unify_proc__make_fresh_named_vars_from_types_6_0_i5);
	update_prof_current_proc(LABEL(mercury__unify_proc__make_fresh_named_vars_from_types_6_0));
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(3);
	r2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r3 = r1;
	MR_stackvar(6) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	call_localret(ENTRY(mercury__varset__new_named_var_4_0),
		mercury__unify_proc__make_fresh_named_vars_from_types_6_0_i6,
		STATIC(mercury__unify_proc__make_fresh_named_vars_from_types_6_0));
	}
Define_label(mercury__unify_proc__make_fresh_named_vars_from_types_6_0_i6);
	update_prof_current_proc(LABEL(mercury__unify_proc__make_fresh_named_vars_from_types_6_0));
	r3 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	r4 = r1;
	MR_stackvar(3) = r1;
	MR_stackvar(4) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_3);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_4);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__unify_proc__make_fresh_named_vars_from_types_6_0_i7,
		STATIC(mercury__unify_proc__make_fresh_named_vars_from_types_6_0));
Define_label(mercury__unify_proc__make_fresh_named_vars_from_types_6_0_i7);
	update_prof_current_proc(LABEL(mercury__unify_proc__make_fresh_named_vars_from_types_6_0));
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 3, mercury__unify_proc__make_fresh_named_vars_from_types_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r4, (Integer) 1) = r1;
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(1);
	r3 = ((Integer) MR_stackvar(2) + (Integer) 1);
	MR_field(MR_mktag(0), r4, (Integer) 2) = MR_stackvar(6);
	MR_field(MR_mktag(0), r4, (Integer) 0) = MR_stackvar(4);
	localcall(mercury__unify_proc__make_fresh_named_vars_from_types_6_0,
		LABEL(mercury__unify_proc__make_fresh_named_vars_from_types_6_0_i8),
		STATIC(mercury__unify_proc__make_fresh_named_vars_from_types_6_0));
Define_label(mercury__unify_proc__make_fresh_named_vars_from_types_6_0_i8);
	update_prof_current_proc(LABEL(mercury__unify_proc__make_fresh_named_vars_from_types_6_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__unify_proc__make_fresh_named_vars_from_types_6_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__unify_proc__make_fresh_named_vars_from_types_6_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = r4;
	proceed();
END_MODULE


BEGIN_MODULE(unify_proc_module21)
	init_entry(mercury__unify_proc__make_fresh_vars_from_types_4_0);
	init_label(mercury__unify_proc__make_fresh_vars_from_types_4_0_i4);
	init_label(mercury__unify_proc__make_fresh_vars_from_types_4_0_i5);
	init_label(mercury__unify_proc__make_fresh_vars_from_types_4_0_i6);
	init_label(mercury__unify_proc__make_fresh_vars_from_types_4_0_i3);
BEGIN_CODE

/* code for predicate 'make_fresh_vars_from_types'/4 in mode 0 */
Define_static(mercury__unify_proc__make_fresh_vars_from_types_4_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_proc__make_fresh_vars_from_types_4_0_i3);
	MR_incr_sp_push_msg(5, "unify_proc:make_fresh_vars_from_types/4");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	call_localret(ENTRY(mercury__varset__new_var_3_0),
		mercury__unify_proc__make_fresh_vars_from_types_4_0_i4,
		STATIC(mercury__unify_proc__make_fresh_vars_from_types_4_0));
Define_label(mercury__unify_proc__make_fresh_vars_from_types_4_0_i4);
	update_prof_current_proc(LABEL(mercury__unify_proc__make_fresh_vars_from_types_4_0));
	r3 = MR_stackvar(3);
	r5 = MR_stackvar(1);
	r4 = r1;
	MR_stackvar(1) = r1;
	MR_stackvar(3) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_3);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_4);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__unify_proc__make_fresh_vars_from_types_4_0_i5,
		STATIC(mercury__unify_proc__make_fresh_vars_from_types_4_0));
Define_label(mercury__unify_proc__make_fresh_vars_from_types_4_0_i5);
	update_prof_current_proc(LABEL(mercury__unify_proc__make_fresh_vars_from_types_4_0));
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 3, mercury__unify_proc__make_fresh_vars_from_types_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 1) = r1;
	r1 = MR_stackvar(2);
	MR_field(MR_mktag(0), r2, (Integer) 2) = MR_stackvar(4);
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(3);
	localcall(mercury__unify_proc__make_fresh_vars_from_types_4_0,
		LABEL(mercury__unify_proc__make_fresh_vars_from_types_4_0_i6),
		STATIC(mercury__unify_proc__make_fresh_vars_from_types_4_0));
Define_label(mercury__unify_proc__make_fresh_vars_from_types_4_0_i6);
	update_prof_current_proc(LABEL(mercury__unify_proc__make_fresh_vars_from_types_4_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__unify_proc__make_fresh_vars_from_types_4_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__unify_proc__make_fresh_vars_from_types_4_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE

Declare_entry(mercury__assoc_list__values_2_0);
Declare_entry(mercury__varset__new_vars_4_0);

BEGIN_MODULE(unify_proc_module22)
	init_entry(mercury__unify_proc__make_fresh_vars_5_0);
	init_label(mercury__unify_proc__make_fresh_vars_5_0_i4);
	init_label(mercury__unify_proc__make_fresh_vars_5_0_i2);
	init_label(mercury__unify_proc__make_fresh_vars_5_0_i6);
	init_label(mercury__unify_proc__make_fresh_vars_5_0_i7);
BEGIN_CODE

/* code for predicate 'make_fresh_vars'/5 in mode 0 */
Define_static(mercury__unify_proc__make_fresh_vars_5_0);
	MR_incr_sp_push_msg(3, "unify_proc:make_fresh_vars/5");
	MR_stackvar(3) = (Word) MR_succip;
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_proc__make_fresh_vars_5_0_i2);
	MR_stackvar(1) = r3;
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_string_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_4);
	call_localret(ENTRY(mercury__assoc_list__values_2_0),
		mercury__unify_proc__make_fresh_vars_5_0_i4,
		STATIC(mercury__unify_proc__make_fresh_vars_5_0));
Define_label(mercury__unify_proc__make_fresh_vars_5_0_i4);
	update_prof_current_proc(LABEL(mercury__unify_proc__make_fresh_vars_5_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__unify_proc__make_fresh_vars_from_types_4_0),
		STATIC(mercury__unify_proc__make_fresh_vars_5_0));
Define_label(mercury__unify_proc__make_fresh_vars_5_0_i2);
	MR_stackvar(1) = r3;
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_6);
	call_localret(ENTRY(mercury__list__length_2_0),
		mercury__unify_proc__make_fresh_vars_5_0_i6,
		STATIC(mercury__unify_proc__make_fresh_vars_5_0));
Define_label(mercury__unify_proc__make_fresh_vars_5_0_i6);
	update_prof_current_proc(LABEL(mercury__unify_proc__make_fresh_vars_5_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__varset__new_vars_4_0),
		mercury__unify_proc__make_fresh_vars_5_0_i7,
		STATIC(mercury__unify_proc__make_fresh_vars_5_0));
Define_label(mercury__unify_proc__make_fresh_vars_5_0_i7);
	update_prof_current_proc(LABEL(mercury__unify_proc__make_fresh_vars_5_0));
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 3, mercury__unify_proc__make_fresh_vars_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 0) = r2;
	r2 = r3;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(1);
	MR_field(MR_mktag(0), r3, (Integer) 2) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 2);
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
	}
END_MODULE

Declare_entry(mercury__term__context_init_1_0);

BEGIN_MODULE(unify_proc_module23)
	init_entry(mercury__unify_proc__unify_var_lists_2_7_0);
	init_label(mercury__unify_proc__unify_var_lists_2_7_0_i3);
	init_label(mercury__unify_proc__unify_var_lists_2_7_0_i8);
	init_label(mercury__unify_proc__unify_var_lists_2_7_0_i13);
	init_label(mercury__unify_proc__unify_var_lists_2_7_0_i1033);
	init_label(mercury__unify_proc__unify_var_lists_2_7_0_i11);
	init_label(mercury__unify_proc__unify_var_lists_2_7_0_i16);
	init_label(mercury__unify_proc__unify_var_lists_2_7_0_i17);
	init_label(mercury__unify_proc__unify_var_lists_2_7_0_i10);
	init_label(mercury__unify_proc__unify_var_lists_2_7_0_i18);
	init_label(mercury__unify_proc__unify_var_lists_2_7_0_i20);
	init_label(mercury__unify_proc__unify_var_lists_2_7_0_i1023);
	init_label(mercury__unify_proc__unify_var_lists_2_7_0_i1);
BEGIN_CODE

/* code for predicate 'unify_var_lists_2'/7 in mode 0 */
Define_static(mercury__unify_proc__unify_var_lists_2_7_0);
	MR_incr_sp_push_msg(13, "unify_proc:unify_var_lists_2/7");
	MR_stackvar(13) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_proc__unify_var_lists_2_7_0_i3);
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_proc__unify_var_lists_2_7_0_i1023);
	if (((Integer) r4 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_proc__unify_var_lists_2_7_0_i1023);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r3 = r5;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	proceed();
Define_label(mercury__unify_proc__unify_var_lists_2_7_0_i3);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_proc__unify_var_lists_2_7_0_i1);
	if (((Integer) r4 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unify_proc__unify_var_lists_2_7_0_i1);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r5;
	MR_stackvar(3) = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_stackvar(6) = MR_const_field(MR_mktag(1), r3, (Integer) 1);
	MR_stackvar(7) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_stackvar(8) = MR_const_field(MR_mktag(1), r4, (Integer) 1);
	call_localret(ENTRY(mercury__term__context_init_1_0),
		mercury__unify_proc__unify_var_lists_2_7_0_i8,
		STATIC(mercury__unify_proc__unify_var_lists_2_7_0));
Define_label(mercury__unify_proc__unify_var_lists_2_7_0_i8);
	update_prof_current_proc(LABEL(mercury__unify_proc__unify_var_lists_2_7_0));
	MR_stackvar(10) = (Word) MR_redoip_slot(MR_maxfr);
	MR_stackvar(11) = (Word) MR_redofr_slot(MR_maxfr);
	MR_stackvar(12) = (Word) MR_maxfr;
	MR_redofr_slot(MR_maxfr) = MR_curfr;
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__unify_proc__unify_var_lists_2_7_0_i11);
	MR_stackvar(9) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_5);
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__list__member_2_1),
		mercury__unify_proc__unify_var_lists_2_7_0_i13,
		STATIC(mercury__unify_proc__unify_var_lists_2_7_0));
Define_label(mercury__unify_proc__unify_var_lists_2_7_0_i13);
	update_prof_current_proc(LABEL(mercury__unify_proc__unify_var_lists_2_7_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_tvar_type_0;
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__term__contains_var_2_0),
		mercury__unify_proc__unify_var_lists_2_7_0_i1033,
		STATIC(mercury__unify_proc__unify_var_lists_2_7_0));
Define_label(mercury__unify_proc__unify_var_lists_2_7_0_i1033);
	update_prof_current_proc(LABEL(mercury__unify_proc__unify_var_lists_2_7_0));
	if (!(r1))
		GOTO(ENTRY(do_redo));
	MR_maxfr = (Word *) MR_stackvar(12);
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(10);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(11);
	GOTO_LABEL(mercury__unify_proc__unify_var_lists_2_7_0_i16);
Define_label(mercury__unify_proc__unify_var_lists_2_7_0_i11);
	update_prof_current_proc(LABEL(mercury__unify_proc__unify_var_lists_2_7_0));
	r1 = MR_stackvar(9);
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(10);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(11);
	GOTO_LABEL(mercury__unify_proc__unify_var_lists_2_7_0_i10);
Define_label(mercury__unify_proc__unify_var_lists_2_7_0_i16);
	r1 = (Word) MR_string_const("typed_unify", 11);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__unify_proc__unify_var_lists_2_7_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(5);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__unify_proc__unify_var_lists_2_7_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(7);
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r2, (Integer) 1) = r3;
	r3 = MR_stackvar(9);
	r4 = MR_stackvar(2);
	call_localret(STATIC(mercury__unify_proc__build_call_6_0),
		mercury__unify_proc__unify_var_lists_2_7_0_i17,
		STATIC(mercury__unify_proc__unify_var_lists_2_7_0));
Define_label(mercury__unify_proc__unify_var_lists_2_7_0_i17);
	update_prof_current_proc(LABEL(mercury__unify_proc__unify_var_lists_2_7_0));
	r5 = r2;
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(6);
	r4 = MR_stackvar(8);
	localcall(mercury__unify_proc__unify_var_lists_2_7_0,
		LABEL(mercury__unify_proc__unify_var_lists_2_7_0_i20),
		STATIC(mercury__unify_proc__unify_var_lists_2_7_0));
Define_label(mercury__unify_proc__unify_var_lists_2_7_0_i10);
	r3 = r1;
	r1 = MR_stackvar(5);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 1, mercury__unify_proc__unify_var_lists_2_7_0, "hlds_goal:unify_rhs/0");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(7);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__make_hlds__create_atomic_unification_6_0),
		mercury__unify_proc__unify_var_lists_2_7_0_i18,
		STATIC(mercury__unify_proc__unify_var_lists_2_7_0));
Define_label(mercury__unify_proc__unify_var_lists_2_7_0_i18);
	update_prof_current_proc(LABEL(mercury__unify_proc__unify_var_lists_2_7_0));
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(6);
	r4 = MR_stackvar(8);
	r5 = MR_stackvar(2);
	localcall(mercury__unify_proc__unify_var_lists_2_7_0,
		LABEL(mercury__unify_proc__unify_var_lists_2_7_0_i20),
		STATIC(mercury__unify_proc__unify_var_lists_2_7_0));
Define_label(mercury__unify_proc__unify_var_lists_2_7_0_i20);
	update_prof_current_proc(LABEL(mercury__unify_proc__unify_var_lists_2_7_0));
	if (!(r1))
		GOTO_LABEL(mercury__unify_proc__unify_var_lists_2_7_0_i1);
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__unify_proc__unify_var_lists_2_7_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(1), r2, (Integer) 1) = r1;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	proceed();
Define_label(mercury__unify_proc__unify_var_lists_2_7_0_i1023);
	r1 = FALSE;
	MR_decr_sp_pop_msg(13);
	proceed();
Define_label(mercury__unify_proc__unify_var_lists_2_7_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	proceed();
END_MODULE


BEGIN_MODULE(unify_proc_module24)
	init_entry(mercury__unify_proc__info_new_var_4_0);
	init_label(mercury__unify_proc__info_new_var_4_0_i2);
	init_label(mercury__unify_proc__info_new_var_4_0_i3);
BEGIN_CODE

/* code for predicate 'info_new_var'/4 in mode 0 */
Define_static(mercury__unify_proc__info_new_var_4_0);
	MR_incr_sp_push_msg(4, "unify_proc:info_new_var/4");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	call_localret(ENTRY(mercury__varset__new_var_3_0),
		mercury__unify_proc__info_new_var_4_0_i2,
		STATIC(mercury__unify_proc__info_new_var_4_0));
Define_label(mercury__unify_proc__info_new_var_4_0_i2);
	update_prof_current_proc(LABEL(mercury__unify_proc__info_new_var_4_0));
	r3 = MR_stackvar(2);
	r5 = MR_stackvar(1);
	r4 = r1;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_3);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_4);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__unify_proc__info_new_var_4_0_i3,
		STATIC(mercury__unify_proc__info_new_var_4_0));
Define_label(mercury__unify_proc__info_new_var_4_0_i3);
	update_prof_current_proc(LABEL(mercury__unify_proc__info_new_var_4_0));
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 3, mercury__unify_proc__info_new_var_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 1) = r1;
	r1 = MR_stackvar(1);
	MR_field(MR_mktag(0), r2, (Integer) 2) = MR_stackvar(3);
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE


BEGIN_MODULE(unify_proc_module25)
	init_entry(mercury__unify_proc__info_set_varset_3_0);
BEGIN_CODE

/* code for predicate 'info_set_varset'/3 in mode 0 */
Define_static(mercury__unify_proc__info_set_varset_3_0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 3, mercury__unify_proc__info_set_varset_3_0, "unify_proc:unify_proc_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	proceed();
END_MODULE


BEGIN_MODULE(unify_proc_module26)
	init_entry(mercury__unify_proc__info_set_types_3_0);
BEGIN_CODE

/* code for predicate 'info_set_types'/3 in mode 0 */
Define_static(mercury__unify_proc__info_set_types_3_0);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 3, mercury__unify_proc__info_set_types_3_0, "unify_proc:unify_proc_info/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_field(MR_mktag(0), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	proceed();
END_MODULE

Declare_entry(mercury____Unify___tree234__tree234_2_0);
Declare_entry(mercury____Unify___queue__queue_1_0);

BEGIN_MODULE(unify_proc_module27)
	init_entry(mercury____Unify___unify_proc__proc_requests_0_0);
	init_label(mercury____Unify___unify_proc__proc_requests_0_0_i2);
	init_label(mercury____Unify___unify_proc__proc_requests_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___unify_proc__proc_requests_0_0);
	MR_incr_sp_push_msg(3, "unify_proc:__Unify__/2");
	MR_stackvar(3) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r4 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_1);
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0;
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___unify_proc__proc_requests_0_0_i2,
		ENTRY(mercury____Unify___unify_proc__proc_requests_0_0));
Define_label(mercury____Unify___unify_proc__proc_requests_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___unify_proc__proc_requests_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___unify_proc__proc_requests_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury____Unify___queue__queue_1_0),
		ENTRY(mercury____Unify___unify_proc__proc_requests_0_0));
Define_label(mercury____Unify___unify_proc__proc_requests_0_0_i1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(unify_proc_module28)
	init_entry(mercury____Index___unify_proc__proc_requests_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___unify_proc__proc_requests_0_0);
	tailcall(STATIC(mercury____Index___unify_proc__proc_requests_0__ua0_2_0),
		ENTRY(mercury____Index___unify_proc__proc_requests_0_0));
END_MODULE

Declare_entry(mercury____Compare___tree234__tree234_2_0);
Declare_entry(mercury____Compare___queue__queue_1_0);

BEGIN_MODULE(unify_proc_module29)
	init_entry(mercury____Compare___unify_proc__proc_requests_0_0);
	init_label(mercury____Compare___unify_proc__proc_requests_0_0_i3);
	init_label(mercury____Compare___unify_proc__proc_requests_0_0_i7);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___unify_proc__proc_requests_0_0);
	MR_incr_sp_push_msg(3, "unify_proc:__Compare__/3");
	MR_stackvar(3) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r4 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_1);
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0;
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___unify_proc__proc_requests_0_0_i3,
		ENTRY(mercury____Compare___unify_proc__proc_requests_0_0));
Define_label(mercury____Compare___unify_proc__proc_requests_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___unify_proc__proc_requests_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___unify_proc__proc_requests_0_0_i7);
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury____Compare___queue__queue_1_0),
		ENTRY(mercury____Compare___unify_proc__proc_requests_0_0));
Define_label(mercury____Compare___unify_proc__proc_requests_0_0_i7);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE

Declare_entry(mercury____Unify___std_util__pair_2_0);

BEGIN_MODULE(unify_proc_module30)
	init_entry(mercury____Unify___unify_proc__unify_proc_id_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___unify_proc__unify_proc_id_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_0);
	r4 = r2;
	r2 = (Word) (Word *) &mercury_data_hlds_goal__type_ctor_info_uni_mode_0;
	tailcall(ENTRY(mercury____Unify___std_util__pair_2_0),
		ENTRY(mercury____Unify___unify_proc__unify_proc_id_0_0));
END_MODULE

Declare_entry(mercury____Index___std_util__pair_2_0);

BEGIN_MODULE(unify_proc_module31)
	init_entry(mercury____Index___unify_proc__unify_proc_id_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___unify_proc__unify_proc_id_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_0);
	r2 = (Word) (Word *) &mercury_data_hlds_goal__type_ctor_info_uni_mode_0;
	tailcall(ENTRY(mercury____Index___std_util__pair_2_0),
		ENTRY(mercury____Index___unify_proc__unify_proc_id_0_0));
END_MODULE

Declare_entry(mercury____Compare___std_util__pair_2_0);

BEGIN_MODULE(unify_proc_module32)
	init_entry(mercury____Compare___unify_proc__unify_proc_id_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___unify_proc__unify_proc_id_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_0);
	r4 = r2;
	r2 = (Word) (Word *) &mercury_data_hlds_goal__type_ctor_info_uni_mode_0;
	tailcall(ENTRY(mercury____Compare___std_util__pair_2_0),
		ENTRY(mercury____Compare___unify_proc__unify_proc_id_0_0));
END_MODULE


BEGIN_MODULE(unify_proc_module33)
	init_entry(mercury____Unify___unify_proc__unify_req_map_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___unify_proc__unify_req_map_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_1);
	r4 = r2;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0;
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		STATIC(mercury____Unify___unify_proc__unify_req_map_0_0));
END_MODULE

Declare_entry(mercury____Index___tree234__tree234_2_0);

BEGIN_MODULE(unify_proc_module34)
	init_entry(mercury____Index___unify_proc__unify_req_map_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___unify_proc__unify_req_map_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_1);
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0;
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		STATIC(mercury____Index___unify_proc__unify_req_map_0_0));
END_MODULE


BEGIN_MODULE(unify_proc_module35)
	init_entry(mercury____Compare___unify_proc__unify_req_map_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___unify_proc__unify_req_map_0_0);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_1);
	r4 = r2;
	r2 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_proc_id_0;
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		STATIC(mercury____Compare___unify_proc__unify_req_map_0_0));
END_MODULE


BEGIN_MODULE(unify_proc_module36)
	init_entry(mercury____Unify___unify_proc__req_queue_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___unify_proc__req_queue_0_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	tailcall(ENTRY(mercury____Unify___queue__queue_1_0),
		STATIC(mercury____Unify___unify_proc__req_queue_0_0));
END_MODULE

Declare_entry(mercury____Index___queue__queue_1_0);

BEGIN_MODULE(unify_proc_module37)
	init_entry(mercury____Index___unify_proc__req_queue_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___unify_proc__req_queue_0_0);
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	tailcall(ENTRY(mercury____Index___queue__queue_1_0),
		STATIC(mercury____Index___unify_proc__req_queue_0_0));
END_MODULE


BEGIN_MODULE(unify_proc_module38)
	init_entry(mercury____Compare___unify_proc__req_queue_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___unify_proc__req_queue_0_0);
	r3 = r2;
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_hlds_pred__type_ctor_info_pred_proc_id_0;
	tailcall(ENTRY(mercury____Compare___queue__queue_1_0),
		STATIC(mercury____Compare___unify_proc__req_queue_0_0));
END_MODULE

Declare_entry(mercury____Unify___varset__varset_1_0);
Declare_entry(mercury____Unify___hlds_module__module_info_0_0);

BEGIN_MODULE(unify_proc_module39)
	init_entry(mercury____Unify___unify_proc__unify_proc_info_0_0);
	init_label(mercury____Unify___unify_proc__unify_proc_info_0_0_i2);
	init_label(mercury____Unify___unify_proc__unify_proc_info_0_0_i4);
	init_label(mercury____Unify___unify_proc__unify_proc_info_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_static(mercury____Unify___unify_proc__unify_proc_info_0_0);
	MR_incr_sp_push_msg(5, "unify_proc:__Unify__/2");
	MR_stackvar(5) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	call_localret(ENTRY(mercury____Unify___varset__varset_1_0),
		mercury____Unify___unify_proc__unify_proc_info_0_0_i2,
		STATIC(mercury____Unify___unify_proc__unify_proc_info_0_0));
Define_label(mercury____Unify___unify_proc__unify_proc_info_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___unify_proc__unify_proc_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___unify_proc__unify_proc_info_0_0_i1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_3);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_4);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(3);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___unify_proc__unify_proc_info_0_0_i4,
		STATIC(mercury____Unify___unify_proc__unify_proc_info_0_0));
Define_label(mercury____Unify___unify_proc__unify_proc_info_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___unify_proc__unify_proc_info_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___unify_proc__unify_proc_info_0_0_i1);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury____Unify___hlds_module__module_info_0_0),
		STATIC(mercury____Unify___unify_proc__unify_proc_info_0_0));
Define_label(mercury____Unify___unify_proc__unify_proc_info_0_0_i1);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(unify_proc_module40)
	init_entry(mercury____Index___unify_proc__unify_proc_info_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_static(mercury____Index___unify_proc__unify_proc_info_0_0);
	tailcall(STATIC(mercury____Index___unify_proc__unify_proc_info_0__ua0_2_0),
		STATIC(mercury____Index___unify_proc__unify_proc_info_0_0));
END_MODULE

Declare_entry(mercury____Compare___varset__varset_1_0);
Declare_entry(mercury____Compare___hlds_module__module_info_0_0);

BEGIN_MODULE(unify_proc_module41)
	init_entry(mercury____Compare___unify_proc__unify_proc_info_0_0);
	init_label(mercury____Compare___unify_proc__unify_proc_info_0_0_i3);
	init_label(mercury____Compare___unify_proc__unify_proc_info_0_0_i7);
	init_label(mercury____Compare___unify_proc__unify_proc_info_0_0_i12);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_static(mercury____Compare___unify_proc__unify_proc_info_0_0);
	MR_incr_sp_push_msg(5, "unify_proc:__Compare__/3");
	MR_stackvar(5) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	r1 = (Word) (Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0;
	call_localret(ENTRY(mercury____Compare___varset__varset_1_0),
		mercury____Compare___unify_proc__unify_proc_info_0_0_i3,
		STATIC(mercury____Compare___unify_proc__unify_proc_info_0_0));
Define_label(mercury____Compare___unify_proc__unify_proc_info_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___unify_proc__unify_proc_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___unify_proc__unify_proc_info_0_0_i12);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_3);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unify_proc__common_4);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(3);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___unify_proc__unify_proc_info_0_0_i7,
		STATIC(mercury____Compare___unify_proc__unify_proc_info_0_0));
Define_label(mercury____Compare___unify_proc__unify_proc_info_0_0_i7);
	update_prof_current_proc(LABEL(mercury____Compare___unify_proc__unify_proc_info_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___unify_proc__unify_proc_info_0_0_i12);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury____Compare___hlds_module__module_info_0_0),
		STATIC(mercury____Compare___unify_proc__unify_proc_info_0_0));
Define_label(mercury____Compare___unify_proc__unify_proc_info_0_0_i12);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__unify_proc_maybe_bunch_0(void)
{
	unify_proc_module0();
	unify_proc_module1();
	unify_proc_module2();
	unify_proc_module3();
	unify_proc_module4();
	unify_proc_module5();
	unify_proc_module6();
	unify_proc_module7();
	unify_proc_module8();
	unify_proc_module9();
	unify_proc_module10();
	unify_proc_module11();
	unify_proc_module12();
	unify_proc_module13();
	unify_proc_module14();
	unify_proc_module15();
	unify_proc_module16();
	unify_proc_module17();
	unify_proc_module18();
	unify_proc_module19();
	unify_proc_module20();
	unify_proc_module21();
	unify_proc_module22();
	unify_proc_module23();
	unify_proc_module24();
	unify_proc_module25();
	unify_proc_module26();
	unify_proc_module27();
	unify_proc_module28();
	unify_proc_module29();
	unify_proc_module30();
	unify_proc_module31();
	unify_proc_module32();
	unify_proc_module33();
	unify_proc_module34();
	unify_proc_module35();
	unify_proc_module36();
	unify_proc_module37();
	unify_proc_module38();
	unify_proc_module39();
}

static void mercury__unify_proc_maybe_bunch_1(void)
{
	unify_proc_module40();
	unify_proc_module41();
}

#endif

void mercury__unify_proc__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__unify_proc__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__unify_proc_maybe_bunch_0();
		mercury__unify_proc_maybe_bunch_1();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_unify_proc__type_ctor_info_proc_requests_0,
			unify_proc__proc_requests_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_unify_proc__type_ctor_info_req_queue_0,
			unify_proc__req_queue_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_unify_proc__type_ctor_info_unify_proc_id_0,
			unify_proc__unify_proc_id_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_unify_proc__type_ctor_info_unify_proc_info_0,
			unify_proc__unify_proc_info_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_unify_proc__type_ctor_info_unify_req_map_0,
			unify_proc__unify_req_map_0_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
