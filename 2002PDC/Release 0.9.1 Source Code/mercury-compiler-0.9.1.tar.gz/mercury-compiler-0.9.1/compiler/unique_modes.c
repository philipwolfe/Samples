/*
** Automatically generated from `unique_modes.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__unique_modes__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury__unique_modes__DeforestationIn__pred__make_all_nondet_live_vars_mostly_uniq__176__0_3_0);
Declare_label(mercury__unique_modes__DeforestationIn__pred__make_all_nondet_live_vars_mostly_uniq__176__0_3_0_i5);
Declare_label(mercury__unique_modes__DeforestationIn__pred__make_all_nondet_live_vars_mostly_uniq__176__0_3_0_i6);
Declare_label(mercury__unique_modes__DeforestationIn__pred__make_all_nondet_live_vars_mostly_uniq__176__0_3_0_i4);
Declare_label(mercury__unique_modes__DeforestationIn__pred__make_all_nondet_live_vars_mostly_uniq__176__0_3_0_i7);
Declare_label(mercury__unique_modes__DeforestationIn__pred__make_all_nondet_live_vars_mostly_uniq__176__0_3_0_i1005);
Declare_static(mercury__unique_modes__IntroducedFrom__pred__check_par_conj_0__712__1_2_0);
Declare_label(mercury__unique_modes__IntroducedFrom__pred__check_par_conj_0__712__1_2_0_i1);
Define_extern_entry(mercury__unique_modes__check_module_4_0);
Declare_label(mercury__unique_modes__check_module_4_0_i2);
Define_extern_entry(mercury__unique_modes__check_proc_7_0);
Declare_label(mercury__unique_modes__check_proc_7_0_i2);
Declare_label(mercury__unique_modes__check_proc_7_0_i7);
Declare_label(mercury__unique_modes__check_proc_7_0_i4);
Define_extern_entry(mercury__unique_modes__check_goal_4_0);
Declare_label(mercury__unique_modes__check_goal_4_0_i2);
Declare_label(mercury__unique_modes__check_goal_4_0_i3);
Declare_label(mercury__unique_modes__check_goal_4_0_i6);
Declare_label(mercury__unique_modes__check_goal_4_0_i5);
Declare_label(mercury__unique_modes__check_goal_4_0_i9);
Declare_label(mercury__unique_modes__check_goal_4_0_i10);
Declare_label(mercury__unique_modes__check_goal_4_0_i11);
Declare_label(mercury__unique_modes__check_goal_4_0_i12);
Declare_label(mercury__unique_modes__check_goal_4_0_i13);
Declare_label(mercury__unique_modes__check_goal_4_0_i15);
Declare_label(mercury__unique_modes__check_goal_4_0_i16);
Declare_label(mercury__unique_modes__check_goal_4_0_i17);
Declare_label(mercury__unique_modes__check_goal_4_0_i18);
Declare_label(mercury__unique_modes__check_goal_4_0_i19);
Declare_label(mercury__unique_modes__check_goal_4_0_i20);
Declare_label(mercury__unique_modes__check_goal_4_0_i21);
Declare_label(mercury__unique_modes__check_goal_4_0_i22);
Declare_static(mercury__unique_modes__make_all_nondet_live_vars_mostly_uniq_2_0);
Declare_label(mercury__unique_modes__make_all_nondet_live_vars_mostly_uniq_2_0_i2);
Declare_label(mercury__unique_modes__make_all_nondet_live_vars_mostly_uniq_2_0_i5);
Declare_label(mercury__unique_modes__make_all_nondet_live_vars_mostly_uniq_2_0_i7);
Declare_label(mercury__unique_modes__make_all_nondet_live_vars_mostly_uniq_2_0_i4);
Declare_static(mercury__unique_modes__select_live_vars_3_0);
Declare_label(mercury__unique_modes__select_live_vars_3_0_i1002);
Declare_label(mercury__unique_modes__select_live_vars_3_0_i5);
Declare_label(mercury__unique_modes__select_live_vars_3_0_i6);
Declare_label(mercury__unique_modes__select_live_vars_3_0_i4);
Declare_label(mercury__unique_modes__select_live_vars_3_0_i3);
Declare_static(mercury__unique_modes__select_nondet_live_vars_3_0);
Declare_label(mercury__unique_modes__select_nondet_live_vars_3_0_i1002);
Declare_label(mercury__unique_modes__select_nondet_live_vars_3_0_i5);
Declare_label(mercury__unique_modes__select_nondet_live_vars_3_0_i6);
Declare_label(mercury__unique_modes__select_nondet_live_vars_3_0_i4);
Declare_label(mercury__unique_modes__select_nondet_live_vars_3_0_i3);
Declare_static(mercury__unique_modes__select_changed_inst_vars_4_0);
Declare_label(mercury__unique_modes__select_changed_inst_vars_4_0_i1004);
Declare_label(mercury__unique_modes__select_changed_inst_vars_4_0_i4);
Declare_label(mercury__unique_modes__select_changed_inst_vars_4_0_i5);
Declare_label(mercury__unique_modes__select_changed_inst_vars_4_0_i6);
Declare_label(mercury__unique_modes__select_changed_inst_vars_4_0_i8);
Declare_label(mercury__unique_modes__select_changed_inst_vars_4_0_i10);
Declare_label(mercury__unique_modes__select_changed_inst_vars_4_0_i14);
Declare_label(mercury__unique_modes__select_changed_inst_vars_4_0_i16);
Declare_label(mercury__unique_modes__select_changed_inst_vars_4_0_i7);
Declare_label(mercury__unique_modes__select_changed_inst_vars_4_0_i3);
Declare_static(mercury__unique_modes__make_var_list_mostly_uniq_3_0);
Declare_label(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i1008);
Declare_label(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i4);
Declare_label(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i5);
Declare_label(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i7);
Declare_label(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i9);
Declare_label(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i10);
Declare_label(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i12);
Declare_label(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i13);
Declare_label(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i17);
Declare_label(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i19);
Declare_label(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i16);
Declare_label(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i23);
Declare_label(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i24);
Declare_label(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i25);
Declare_label(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i26);
Declare_label(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i6);
Declare_label(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i3);
Declare_static(mercury__unique_modes__check_goal_2_5_0);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i4);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i5);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i6);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i8);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i9);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i12);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i13);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i14);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i15);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i16);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i17);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i18);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i19);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i21);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i22);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i23);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i24);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i26);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i25);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i28);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i32);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i31);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i36);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i37);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i38);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i39);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i40);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i41);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i44);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i45);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i42);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i46);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i47);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i48);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i51);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i52);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i53);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i54);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i55);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i57);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i58);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i61);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i1041);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i59);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i63);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i64);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i67);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i68);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i69);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i65);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i70);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i71);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i1043);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i75);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i76);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i77);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i78);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i79);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i80);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i81);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i82);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i83);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i84);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i1044);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i86);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i87);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i88);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i90);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i91);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i92);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i94);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i95);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i96);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i97);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i98);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i99);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i100);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i101);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i102);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i103);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i104);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i105);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i106);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i107);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i108);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i109);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i110);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i111);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i112);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i113);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i116);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i118);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i119);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i114);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i120);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i121);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i122);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i123);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i124);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i125);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i126);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i128);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i129);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i130);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i131);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i132);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i133);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i135);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i136);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i137);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i138);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i139);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i1053);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i141);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i142);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i143);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i144);
Declare_label(mercury__unique_modes__check_goal_2_5_0_i145);
Declare_static(mercury__unique_modes__check_call_6_0);
Declare_label(mercury__unique_modes__check_call_6_0_i2);
Declare_label(mercury__unique_modes__check_call_6_0_i3);
Declare_label(mercury__unique_modes__check_call_6_0_i4);
Declare_label(mercury__unique_modes__check_call_6_0_i5);
Declare_label(mercury__unique_modes__check_call_6_0_i6);
Declare_label(mercury__unique_modes__check_call_6_0_i7);
Declare_label(mercury__unique_modes__check_call_6_0_i8);
Declare_label(mercury__unique_modes__check_call_6_0_i9);
Declare_label(mercury__unique_modes__check_call_6_0_i10);
Declare_label(mercury__unique_modes__check_call_6_0_i11);
Declare_label(mercury__unique_modes__check_call_6_0_i12);
Declare_label(mercury__unique_modes__check_call_6_0_i13);
Declare_label(mercury__unique_modes__check_call_6_0_i14);
Declare_label(mercury__unique_modes__check_call_6_0_i15);
Declare_label(mercury__unique_modes__check_call_6_0_i17);
Declare_label(mercury__unique_modes__check_call_6_0_i16);
Declare_label(mercury__unique_modes__check_call_6_0_i21);
Declare_label(mercury__unique_modes__check_call_6_0_i24);
Declare_label(mercury__unique_modes__check_call_6_0_i22);
Declare_label(mercury__unique_modes__check_call_6_0_i28);
Declare_label(mercury__unique_modes__check_call_6_0_i31);
Declare_label(mercury__unique_modes__check_call_6_0_i33);
Declare_label(mercury__unique_modes__check_call_6_0_i26);
Declare_label(mercury__unique_modes__check_call_6_0_i37);
Declare_label(mercury__unique_modes__check_call_6_0_i38);
Declare_label(mercury__unique_modes__check_call_6_0_i39);
Declare_label(mercury__unique_modes__check_call_6_0_i40);
Declare_label(mercury__unique_modes__check_call_6_0_i41);
Declare_label(mercury__unique_modes__check_call_6_0_i45);
Declare_label(mercury__unique_modes__check_call_6_0_i46);
Declare_label(mercury__unique_modes__check_call_6_0_i43);
Declare_label(mercury__unique_modes__check_call_6_0_i47);
Declare_label(mercury__unique_modes__check_call_6_0_i48);
Declare_label(mercury__unique_modes__check_call_6_0_i49);
Declare_label(mercury__unique_modes__check_call_6_0_i51);
Declare_label(mercury__unique_modes__check_call_6_0_i1007);
Declare_label(mercury__unique_modes__check_call_6_0_i50);
Declare_static(mercury__unique_modes__check_call_modes_7_0);
Declare_label(mercury__unique_modes__check_call_modes_7_0_i2);
Declare_label(mercury__unique_modes__check_call_modes_7_0_i3);
Declare_label(mercury__unique_modes__check_call_modes_7_0_i4);
Declare_label(mercury__unique_modes__check_call_modes_7_0_i5);
Declare_label(mercury__unique_modes__check_call_modes_7_0_i6);
Declare_label(mercury__unique_modes__check_call_modes_7_0_i8);
Declare_label(mercury__unique_modes__check_call_modes_7_0_i7);
Declare_label(mercury__unique_modes__check_call_modes_7_0_i12);
Declare_label(mercury__unique_modes__check_call_modes_7_0_i15);
Declare_label(mercury__unique_modes__check_call_modes_7_0_i13);
Declare_label(mercury__unique_modes__check_call_modes_7_0_i19);
Declare_label(mercury__unique_modes__check_call_modes_7_0_i22);
Declare_label(mercury__unique_modes__check_call_modes_7_0_i24);
Declare_label(mercury__unique_modes__check_call_modes_7_0_i17);
Declare_static(mercury__unique_modes__check_conj_4_0);
Declare_label(mercury__unique_modes__check_conj_4_0_i3);
Declare_label(mercury__unique_modes__check_conj_4_0_i4);
Declare_label(mercury__unique_modes__check_conj_4_0_i5);
Declare_label(mercury__unique_modes__check_conj_4_0_i6);
Declare_label(mercury__unique_modes__check_conj_4_0_i7);
Declare_label(mercury__unique_modes__check_conj_4_0_i10);
Declare_label(mercury__unique_modes__check_conj_4_0_i12);
Declare_label(mercury__unique_modes__check_conj_4_0_i8);
Declare_label(mercury__unique_modes__check_conj_4_0_i13);
Declare_static(mercury__unique_modes__make_par_conj_nonlocal_multiset_2_0);
Declare_label(mercury__unique_modes__make_par_conj_nonlocal_multiset_2_0_i4);
Declare_label(mercury__unique_modes__make_par_conj_nonlocal_multiset_2_0_i5);
Declare_label(mercury__unique_modes__make_par_conj_nonlocal_multiset_2_0_i6);
Declare_label(mercury__unique_modes__make_par_conj_nonlocal_multiset_2_0_i7);
Declare_label(mercury__unique_modes__make_par_conj_nonlocal_multiset_2_0_i3);
Declare_static(mercury__unique_modes__check_par_conj_6_0);
Declare_label(mercury__unique_modes__check_par_conj_6_0_i2);
Declare_label(mercury__unique_modes__check_par_conj_6_0_i3);
Declare_label(mercury__unique_modes__check_par_conj_6_0_i4);
Declare_label(mercury__unique_modes__check_par_conj_6_0_i5);
Declare_label(mercury__unique_modes__check_par_conj_6_0_i6);
Declare_label(mercury__unique_modes__check_par_conj_6_0_i7);
Declare_label(mercury__unique_modes__check_par_conj_6_0_i8);
Declare_label(mercury__unique_modes__check_par_conj_6_0_i9);
Declare_label(mercury__unique_modes__check_par_conj_6_0_i10);
Declare_static(mercury__unique_modes__check_par_conj_1_5_0);
Declare_label(mercury__unique_modes__check_par_conj_1_5_0_i4);
Declare_label(mercury__unique_modes__check_par_conj_1_5_0_i5);
Declare_label(mercury__unique_modes__check_par_conj_1_5_0_i6);
Declare_label(mercury__unique_modes__check_par_conj_1_5_0_i7);
Declare_label(mercury__unique_modes__check_par_conj_1_5_0_i8);
Declare_label(mercury__unique_modes__check_par_conj_1_5_0_i9);
Declare_label(mercury__unique_modes__check_par_conj_1_5_0_i3);
Declare_static(mercury__unique_modes__check_disj_7_0);
Declare_label(mercury__unique_modes__check_disj_7_0_i4);
Declare_label(mercury__unique_modes__check_disj_7_0_i9);
Declare_label(mercury__unique_modes__check_disj_7_0_i10);
Declare_label(mercury__unique_modes__check_disj_7_0_i12);
Declare_label(mercury__unique_modes__check_disj_7_0_i13);
Declare_label(mercury__unique_modes__check_disj_7_0_i16);
Declare_label(mercury__unique_modes__check_disj_7_0_i18);
Declare_label(mercury__unique_modes__check_disj_7_0_i19);
Declare_label(mercury__unique_modes__check_disj_7_0_i15);
Declare_label(mercury__unique_modes__check_disj_7_0_i20);
Declare_label(mercury__unique_modes__check_disj_7_0_i21);
Declare_label(mercury__unique_modes__check_disj_7_0_i5);
Declare_label(mercury__unique_modes__check_disj_7_0_i6);
Declare_label(mercury__unique_modes__check_disj_7_0_i23);
Declare_label(mercury__unique_modes__check_disj_7_0_i24);
Declare_label(mercury__unique_modes__check_disj_7_0_i25);
Declare_label(mercury__unique_modes__check_disj_7_0_i26);
Declare_label(mercury__unique_modes__check_disj_7_0_i3);
Declare_static(mercury__unique_modes__check_case_list_6_0);
Declare_label(mercury__unique_modes__check_case_list_6_0_i4);
Declare_label(mercury__unique_modes__check_case_list_6_0_i5);
Declare_label(mercury__unique_modes__check_case_list_6_0_i6);
Declare_label(mercury__unique_modes__check_case_list_6_0_i9);
Declare_label(mercury__unique_modes__check_case_list_6_0_i11);
Declare_label(mercury__unique_modes__check_case_list_6_0_i7);
Declare_label(mercury__unique_modes__check_case_list_6_0_i12);
Declare_label(mercury__unique_modes__check_case_list_6_0_i14);
Declare_label(mercury__unique_modes__check_case_list_6_0_i15);
Declare_label(mercury__unique_modes__check_case_list_6_0_i16);
Declare_label(mercury__unique_modes__check_case_list_6_0_i17);
Declare_label(mercury__unique_modes__check_case_list_6_0_i3);
Declare_static(mercury__unique_modes__goal_get_nonlocals_2_0);

static const struct mercury_data_unique_modes__common_0_struct {
	Word * f1;
	Word * f2;
}  mercury_data_unique_modes__common_0;

static const struct mercury_data_unique_modes__common_1_struct {
	Word * f1;
}  mercury_data_unique_modes__common_1;

static const struct mercury_data_unique_modes__common_2_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_unique_modes__common_2;

static const struct mercury_data_unique_modes__common_3_struct {
	Integer f1;
	String f2;
	String f3;
	String f4;
	MR_int_least16_t f5;
	MR_int_least16_t f6;
	Word * f7;
	Integer f8;
	Word * f9;
	Word * f10;
}  mercury_data_unique_modes__common_3;

static const struct mercury_data_unique_modes__common_4_struct {
	Word * f1;
	Code * f2;
	Integer f3;
}  mercury_data_unique_modes__common_4;

extern const struct MR_TypeCtorInfo_struct
	mercury_data_term__type_ctor_info_var_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_prog_data__type_ctor_info_prog_var_type_0;
static const struct mercury_data_unique_modes__common_0_struct mercury_data_unique_modes__common_0 = {
	(Word *) &mercury_data_term__type_ctor_info_var_1,
	(Word *) &mercury_data_prog_data__type_ctor_info_prog_var_type_0
};

static const struct mercury_data_unique_modes__common_1_struct mercury_data_unique_modes__common_1 = {
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_pair_2;
extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_int_0;
static const struct mercury_data_unique_modes__common_2_struct mercury_data_unique_modes__common_2 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_unique_modes__common_0),
	(Word *) &mercury_data___type_ctor_info_int_0
};

static const struct mercury_data_unique_modes__common_3_struct mercury_data_unique_modes__common_3 = {
	(Integer) 0,
	MR_string_const("unique_modes", 12),
	MR_string_const("unique_modes", 12),
	MR_string_const("IntroducedFrom__pred__check_par_conj_0__712__1", 46),
	2,
	0,
	0,
	2,
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unique_modes__common_2),
	(Word *) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unique_modes__common_0)
};

static const struct mercury_data_unique_modes__common_4_struct mercury_data_unique_modes__common_4 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_unique_modes__common_3),
	STATIC(mercury__unique_modes__IntroducedFrom__pred__check_par_conj_0__712__1_2_0),
	(Integer) 0
};

Declare_entry(mercury__mode_info__mode_info_var_is_nondet_live_3_0);

BEGIN_MODULE(unique_modes_module0)
	init_entry(mercury__unique_modes__DeforestationIn__pred__make_all_nondet_live_vars_mostly_uniq__176__0_3_0);
	init_label(mercury__unique_modes__DeforestationIn__pred__make_all_nondet_live_vars_mostly_uniq__176__0_3_0_i5);
	init_label(mercury__unique_modes__DeforestationIn__pred__make_all_nondet_live_vars_mostly_uniq__176__0_3_0_i6);
	init_label(mercury__unique_modes__DeforestationIn__pred__make_all_nondet_live_vars_mostly_uniq__176__0_3_0_i4);
	init_label(mercury__unique_modes__DeforestationIn__pred__make_all_nondet_live_vars_mostly_uniq__176__0_3_0_i7);
	init_label(mercury__unique_modes__DeforestationIn__pred__make_all_nondet_live_vars_mostly_uniq__176__0_3_0_i1005);
BEGIN_CODE

/* code for predicate 'DeforestationIn__pred__make_all_nondet_live_vars_mostly_uniq__176__0'/3 in mode 0 */
Define_static(mercury__unique_modes__DeforestationIn__pred__make_all_nondet_live_vars_mostly_uniq__176__0_3_0);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unique_modes__DeforestationIn__pred__make_all_nondet_live_vars_mostly_uniq__176__0_3_0_i1005);
	MR_incr_sp_push_msg(4, "unique_modes:DeforestationIn__pred__make_all_nondet_live_vars_mostly_uniq__176__0/3");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_stackvar(2) = r2;
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__mode_info__mode_info_var_is_nondet_live_3_0),
		mercury__unique_modes__DeforestationIn__pred__make_all_nondet_live_vars_mostly_uniq__176__0_3_0_i5,
		STATIC(mercury__unique_modes__DeforestationIn__pred__make_all_nondet_live_vars_mostly_uniq__176__0_3_0));
Define_label(mercury__unique_modes__DeforestationIn__pred__make_all_nondet_live_vars_mostly_uniq__176__0_3_0_i5);
	update_prof_current_proc(LABEL(mercury__unique_modes__DeforestationIn__pred__make_all_nondet_live_vars_mostly_uniq__176__0_3_0));
	if (((Integer) 0 != (Integer) r1))
		GOTO_LABEL(mercury__unique_modes__DeforestationIn__pred__make_all_nondet_live_vars_mostly_uniq__176__0_3_0_i4);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(1);
	call_localret(STATIC(mercury__unique_modes__select_nondet_live_vars_3_0),
		mercury__unique_modes__DeforestationIn__pred__make_all_nondet_live_vars_mostly_uniq__176__0_3_0_i6,
		STATIC(mercury__unique_modes__DeforestationIn__pred__make_all_nondet_live_vars_mostly_uniq__176__0_3_0));
Define_label(mercury__unique_modes__DeforestationIn__pred__make_all_nondet_live_vars_mostly_uniq__176__0_3_0_i6);
	update_prof_current_proc(LABEL(mercury__unique_modes__DeforestationIn__pred__make_all_nondet_live_vars_mostly_uniq__176__0_3_0));
	r2 = MR_stackvar(1);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__unique_modes__DeforestationIn__pred__make_all_nondet_live_vars_mostly_uniq__176__0_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__unique_modes__make_var_list_mostly_uniq_3_0),
		STATIC(mercury__unique_modes__DeforestationIn__pred__make_all_nondet_live_vars_mostly_uniq__176__0_3_0));
Define_label(mercury__unique_modes__DeforestationIn__pred__make_all_nondet_live_vars_mostly_uniq__176__0_3_0_i4);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(1);
	call_localret(STATIC(mercury__unique_modes__select_nondet_live_vars_3_0),
		mercury__unique_modes__DeforestationIn__pred__make_all_nondet_live_vars_mostly_uniq__176__0_3_0_i7,
		STATIC(mercury__unique_modes__DeforestationIn__pred__make_all_nondet_live_vars_mostly_uniq__176__0_3_0));
Define_label(mercury__unique_modes__DeforestationIn__pred__make_all_nondet_live_vars_mostly_uniq__176__0_3_0_i7);
	update_prof_current_proc(LABEL(mercury__unique_modes__DeforestationIn__pred__make_all_nondet_live_vars_mostly_uniq__176__0_3_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__unique_modes__make_var_list_mostly_uniq_3_0),
		STATIC(mercury__unique_modes__DeforestationIn__pred__make_all_nondet_live_vars_mostly_uniq__176__0_3_0));
Define_label(mercury__unique_modes__DeforestationIn__pred__make_all_nondet_live_vars_mostly_uniq__176__0_3_0_i1005);
	proceed();
END_MODULE


BEGIN_MODULE(unique_modes_module1)
	init_entry(mercury__unique_modes__IntroducedFrom__pred__check_par_conj_0__712__1_2_0);
	init_label(mercury__unique_modes__IntroducedFrom__pred__check_par_conj_0__712__1_2_0_i1);
BEGIN_CODE

/* code for predicate 'IntroducedFrom__pred__check_par_conj_0__712__1'/2 in mode 0 */
Define_static(mercury__unique_modes__IntroducedFrom__pred__check_par_conj_0__712__1_2_0);
	if (((Integer) MR_const_field(MR_mktag(0), r1, (Integer) 1) <= (Integer) 1))
		GOTO_LABEL(mercury__unique_modes__IntroducedFrom__pred__check_par_conj_0__712__1_2_0_i1);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r1 = TRUE;
	proceed();
Define_label(mercury__unique_modes__IntroducedFrom__pred__check_par_conj_0__712__1_2_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE

Declare_entry(mercury__modes__check_pred_modes_7_0);

BEGIN_MODULE(unique_modes_module2)
	init_entry(mercury__unique_modes__check_module_4_0);
	init_label(mercury__unique_modes__check_module_4_0_i2);
BEGIN_CODE

/* code for predicate 'check_module'/4 in mode 0 */
Define_entry(mercury__unique_modes__check_module_4_0);
	MR_incr_sp_push_msg(1, "unique_modes:check_module/4");
	MR_stackvar(1) = (Word) MR_succip;
	r3 = r1;
	r1 = (Integer) 1;
	r4 = r2;
	r2 = (Integer) 0;
	call_localret(ENTRY(mercury__modes__check_pred_modes_7_0),
		mercury__unique_modes__check_module_4_0_i2,
		ENTRY(mercury__unique_modes__check_module_4_0));
Define_label(mercury__unique_modes__check_module_4_0_i2);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_module_4_0));
	r2 = r3;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
END_MODULE

Declare_entry(mercury__modes__modecheck_proc_10_0);
Declare_entry(mercury__io__set_exit_status_3_0);

BEGIN_MODULE(unique_modes_module3)
	init_entry(mercury__unique_modes__check_proc_7_0);
	init_label(mercury__unique_modes__check_proc_7_0_i2);
	init_label(mercury__unique_modes__check_proc_7_0_i7);
	init_label(mercury__unique_modes__check_proc_7_0_i4);
BEGIN_CODE

/* code for predicate 'check_proc'/7 in mode 0 */
Define_entry(mercury__unique_modes__check_proc_7_0);
	MR_incr_sp_push_msg(4, "unique_modes:check_proc/7");
	MR_stackvar(4) = (Word) MR_succip;
	r5 = r3;
	r3 = (Integer) 1;
	r6 = r4;
	r4 = (Integer) 0;
	call_localret(ENTRY(mercury__modes__modecheck_proc_10_0),
		mercury__unique_modes__check_proc_7_0_i2,
		ENTRY(mercury__unique_modes__check_proc_7_0));
Define_label(mercury__unique_modes__check_proc_7_0_i2);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_proc_7_0));
	if (((Integer) r2 == (Integer) 0))
		GOTO_LABEL(mercury__unique_modes__check_proc_7_0_i4);
	MR_stackvar(1) = r1;
	r1 = (Integer) 1;
	r2 = r4;
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__io__set_exit_status_3_0),
		mercury__unique_modes__check_proc_7_0_i7,
		ENTRY(mercury__unique_modes__check_proc_7_0));
Define_label(mercury__unique_modes__check_proc_7_0_i7);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_proc_7_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__unique_modes__check_proc_7_0_i4);
	r2 = r3;
	r3 = r4;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE

Declare_entry(mercury__hlds_goal__goal_info_get_context_2_0);
Declare_entry(mercury__term__context_init_1_0);
Declare_entry(mercury____Unify___term__context_0_0);
Declare_entry(mercury__mode_info__mode_info_set_context_3_0);
Declare_entry(mercury__mode_info__mode_info_get_instmap_2_0);
Declare_entry(mercury__mode_info__mode_info_get_nondet_live_vars_2_0);
Declare_entry(mercury__hlds_goal__goal_info_get_code_model_2_0);
Declare_entry(mercury__mode_info__mode_info_set_nondet_live_vars_3_0);
Declare_entry(mercury__hlds_goal__goal_info_get_nonlocals_2_0);
Declare_entry(mercury__instmap__compute_instmap_delta_4_0);
Declare_entry(mercury__hlds_goal__goal_info_set_instmap_delta_3_0);

BEGIN_MODULE(unique_modes_module4)
	init_entry(mercury__unique_modes__check_goal_4_0);
	init_label(mercury__unique_modes__check_goal_4_0_i2);
	init_label(mercury__unique_modes__check_goal_4_0_i3);
	init_label(mercury__unique_modes__check_goal_4_0_i6);
	init_label(mercury__unique_modes__check_goal_4_0_i5);
	init_label(mercury__unique_modes__check_goal_4_0_i9);
	init_label(mercury__unique_modes__check_goal_4_0_i10);
	init_label(mercury__unique_modes__check_goal_4_0_i11);
	init_label(mercury__unique_modes__check_goal_4_0_i12);
	init_label(mercury__unique_modes__check_goal_4_0_i13);
	init_label(mercury__unique_modes__check_goal_4_0_i15);
	init_label(mercury__unique_modes__check_goal_4_0_i16);
	init_label(mercury__unique_modes__check_goal_4_0_i17);
	init_label(mercury__unique_modes__check_goal_4_0_i18);
	init_label(mercury__unique_modes__check_goal_4_0_i19);
	init_label(mercury__unique_modes__check_goal_4_0_i20);
	init_label(mercury__unique_modes__check_goal_4_0_i21);
	init_label(mercury__unique_modes__check_goal_4_0_i22);
BEGIN_CODE

/* code for predicate 'check_goal'/4 in mode 0 */
Define_entry(mercury__unique_modes__check_goal_4_0);
	MR_incr_sp_push_msg(9, "unique_modes:check_goal/4");
	MR_stackvar(9) = (Word) MR_succip;
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(4) = r1;
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_context_2_0),
		mercury__unique_modes__check_goal_4_0_i2,
		ENTRY(mercury__unique_modes__check_goal_4_0));
Define_label(mercury__unique_modes__check_goal_4_0_i2);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_4_0));
	MR_stackvar(5) = r1;
	call_localret(ENTRY(mercury__term__context_init_1_0),
		mercury__unique_modes__check_goal_4_0_i3,
		ENTRY(mercury__unique_modes__check_goal_4_0));
Define_label(mercury__unique_modes__check_goal_4_0_i3);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_4_0));
	r2 = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury____Unify___term__context_0_0),
		mercury__unique_modes__check_goal_4_0_i6,
		ENTRY(mercury__unique_modes__check_goal_4_0));
Define_label(mercury__unique_modes__check_goal_4_0_i6);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__unique_modes__check_goal_4_0_i5);
	r1 = MR_stackvar(1);
	GOTO_LABEL(mercury__unique_modes__check_goal_4_0_i9);
Define_label(mercury__unique_modes__check_goal_4_0_i5);
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__mode_info__mode_info_set_context_3_0),
		mercury__unique_modes__check_goal_4_0_i9,
		ENTRY(mercury__unique_modes__check_goal_4_0));
Define_label(mercury__unique_modes__check_goal_4_0_i9);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_4_0));
	MR_stackvar(2) = r1;
	call_localret(ENTRY(mercury__mode_info__mode_info_get_instmap_2_0),
		mercury__unique_modes__check_goal_4_0_i10,
		ENTRY(mercury__unique_modes__check_goal_4_0));
Define_label(mercury__unique_modes__check_goal_4_0_i10);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_4_0));
	MR_stackvar(6) = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__mode_info__mode_info_get_nondet_live_vars_2_0),
		mercury__unique_modes__check_goal_4_0_i11,
		ENTRY(mercury__unique_modes__check_goal_4_0));
Define_label(mercury__unique_modes__check_goal_4_0_i11);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_4_0));
	MR_stackvar(7) = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_code_model_2_0),
		mercury__unique_modes__check_goal_4_0_i12,
		ENTRY(mercury__unique_modes__check_goal_4_0));
Define_label(mercury__unique_modes__check_goal_4_0_i12);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_4_0));
	if (((Integer) r1 != (Integer) 2))
		GOTO_LABEL(mercury__unique_modes__check_goal_4_0_i13);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(2);
	GOTO_LABEL(mercury__unique_modes__check_goal_4_0_i16);
Define_label(mercury__unique_modes__check_goal_4_0_i13);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__mode_info__mode_info_set_nondet_live_vars_3_0),
		mercury__unique_modes__check_goal_4_0_i15,
		ENTRY(mercury__unique_modes__check_goal_4_0));
Define_label(mercury__unique_modes__check_goal_4_0_i15);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_4_0));
	r3 = r1;
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(4);
Define_label(mercury__unique_modes__check_goal_4_0_i16);
	MR_stackvar(4) = r2;
	call_localret(STATIC(mercury__unique_modes__check_goal_2_5_0),
		mercury__unique_modes__check_goal_4_0_i17,
		ENTRY(mercury__unique_modes__check_goal_4_0));
Define_label(mercury__unique_modes__check_goal_4_0_i17);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_4_0));
	r3 = r1;
	r1 = MR_stackvar(7);
	MR_stackvar(7) = r3;
	call_localret(ENTRY(mercury__mode_info__mode_info_set_nondet_live_vars_3_0),
		mercury__unique_modes__check_goal_4_0_i18,
		ENTRY(mercury__unique_modes__check_goal_4_0));
Define_label(mercury__unique_modes__check_goal_4_0_i18);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_4_0));
	MR_stackvar(2) = r1;
	call_localret(ENTRY(mercury__mode_info__mode_info_get_instmap_2_0),
		mercury__unique_modes__check_goal_4_0_i19,
		ENTRY(mercury__unique_modes__check_goal_4_0));
Define_label(mercury__unique_modes__check_goal_4_0_i19);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_4_0));
	MR_stackvar(8) = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_nonlocals_2_0),
		mercury__unique_modes__check_goal_4_0_i20,
		ENTRY(mercury__unique_modes__check_goal_4_0));
Define_label(mercury__unique_modes__check_goal_4_0_i20);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_4_0));
	r3 = r1;
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(8);
	call_localret(ENTRY(mercury__instmap__compute_instmap_delta_4_0),
		mercury__unique_modes__check_goal_4_0_i21,
		ENTRY(mercury__unique_modes__check_goal_4_0));
Define_label(mercury__unique_modes__check_goal_4_0_i21);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_4_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_set_instmap_delta_3_0),
		mercury__unique_modes__check_goal_4_0_i22,
		ENTRY(mercury__unique_modes__check_goal_4_0));
Define_label(mercury__unique_modes__check_goal_4_0_i22);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_4_0));
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__unique_modes__check_goal_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 1) = r1;
	r1 = r3;
	r2 = MR_stackvar(2);
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(7);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE

Declare_entry(mercury__instmap__is_reachable_1_0);
Declare_entry(mercury__instmap__vars_list_2_0);

BEGIN_MODULE(unique_modes_module5)
	init_entry(mercury__unique_modes__make_all_nondet_live_vars_mostly_uniq_2_0);
	init_label(mercury__unique_modes__make_all_nondet_live_vars_mostly_uniq_2_0_i2);
	init_label(mercury__unique_modes__make_all_nondet_live_vars_mostly_uniq_2_0_i5);
	init_label(mercury__unique_modes__make_all_nondet_live_vars_mostly_uniq_2_0_i7);
	init_label(mercury__unique_modes__make_all_nondet_live_vars_mostly_uniq_2_0_i4);
BEGIN_CODE

/* code for predicate 'make_all_nondet_live_vars_mostly_uniq'/2 in mode 0 */
Define_static(mercury__unique_modes__make_all_nondet_live_vars_mostly_uniq_2_0);
	MR_incr_sp_push_msg(3, "unique_modes:make_all_nondet_live_vars_mostly_uniq/2");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__mode_info__mode_info_get_instmap_2_0),
		mercury__unique_modes__make_all_nondet_live_vars_mostly_uniq_2_0_i2,
		STATIC(mercury__unique_modes__make_all_nondet_live_vars_mostly_uniq_2_0));
Define_label(mercury__unique_modes__make_all_nondet_live_vars_mostly_uniq_2_0_i2);
	update_prof_current_proc(LABEL(mercury__unique_modes__make_all_nondet_live_vars_mostly_uniq_2_0));
	MR_stackvar(2) = r1;
	call_localret(ENTRY(mercury__instmap__is_reachable_1_0),
		mercury__unique_modes__make_all_nondet_live_vars_mostly_uniq_2_0_i5,
		STATIC(mercury__unique_modes__make_all_nondet_live_vars_mostly_uniq_2_0));
Define_label(mercury__unique_modes__make_all_nondet_live_vars_mostly_uniq_2_0_i5);
	update_prof_current_proc(LABEL(mercury__unique_modes__make_all_nondet_live_vars_mostly_uniq_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__unique_modes__make_all_nondet_live_vars_mostly_uniq_2_0_i4);
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__instmap__vars_list_2_0),
		mercury__unique_modes__make_all_nondet_live_vars_mostly_uniq_2_0_i7,
		STATIC(mercury__unique_modes__make_all_nondet_live_vars_mostly_uniq_2_0));
Define_label(mercury__unique_modes__make_all_nondet_live_vars_mostly_uniq_2_0_i7);
	update_prof_current_proc(LABEL(mercury__unique_modes__make_all_nondet_live_vars_mostly_uniq_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__unique_modes__DeforestationIn__pred__make_all_nondet_live_vars_mostly_uniq__176__0_3_0),
		STATIC(mercury__unique_modes__make_all_nondet_live_vars_mostly_uniq_2_0));
Define_label(mercury__unique_modes__make_all_nondet_live_vars_mostly_uniq_2_0_i4);
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE

Declare_entry(mercury__mode_info__mode_info_var_is_live_3_0);

BEGIN_MODULE(unique_modes_module6)
	init_entry(mercury__unique_modes__select_live_vars_3_0);
	init_label(mercury__unique_modes__select_live_vars_3_0_i1002);
	init_label(mercury__unique_modes__select_live_vars_3_0_i5);
	init_label(mercury__unique_modes__select_live_vars_3_0_i6);
	init_label(mercury__unique_modes__select_live_vars_3_0_i4);
	init_label(mercury__unique_modes__select_live_vars_3_0_i3);
BEGIN_CODE

/* code for predicate 'select_live_vars'/3 in mode 0 */
Define_static(mercury__unique_modes__select_live_vars_3_0);
	MR_incr_sp_push_msg(4, "unique_modes:select_live_vars/3");
	MR_stackvar(4) = (Word) MR_succip;
Define_label(mercury__unique_modes__select_live_vars_3_0_i1002);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unique_modes__select_live_vars_3_0_i3);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	r1 = r2;
	r2 = r3;
	call_localret(ENTRY(mercury__mode_info__mode_info_var_is_live_3_0),
		mercury__unique_modes__select_live_vars_3_0_i5,
		STATIC(mercury__unique_modes__select_live_vars_3_0));
Define_label(mercury__unique_modes__select_live_vars_3_0_i5);
	update_prof_current_proc(LABEL(mercury__unique_modes__select_live_vars_3_0));
	if (((Integer) 0 != (Integer) r1))
		GOTO_LABEL(mercury__unique_modes__select_live_vars_3_0_i4);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(1);
	localcall(mercury__unique_modes__select_live_vars_3_0,
		LABEL(mercury__unique_modes__select_live_vars_3_0_i6),
		STATIC(mercury__unique_modes__select_live_vars_3_0));
Define_label(mercury__unique_modes__select_live_vars_3_0_i6);
	update_prof_current_proc(LABEL(mercury__unique_modes__select_live_vars_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__unique_modes__select_live_vars_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__unique_modes__select_live_vars_3_0_i4);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(4);
	GOTO_LABEL(mercury__unique_modes__select_live_vars_3_0_i1002);
Define_label(mercury__unique_modes__select_live_vars_3_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE


BEGIN_MODULE(unique_modes_module7)
	init_entry(mercury__unique_modes__select_nondet_live_vars_3_0);
	init_label(mercury__unique_modes__select_nondet_live_vars_3_0_i1002);
	init_label(mercury__unique_modes__select_nondet_live_vars_3_0_i5);
	init_label(mercury__unique_modes__select_nondet_live_vars_3_0_i6);
	init_label(mercury__unique_modes__select_nondet_live_vars_3_0_i4);
	init_label(mercury__unique_modes__select_nondet_live_vars_3_0_i3);
BEGIN_CODE

/* code for predicate 'select_nondet_live_vars'/3 in mode 0 */
Define_static(mercury__unique_modes__select_nondet_live_vars_3_0);
	MR_incr_sp_push_msg(4, "unique_modes:select_nondet_live_vars/3");
	MR_stackvar(4) = (Word) MR_succip;
Define_label(mercury__unique_modes__select_nondet_live_vars_3_0_i1002);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unique_modes__select_nondet_live_vars_3_0_i3);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	r1 = r2;
	r2 = r3;
	call_localret(ENTRY(mercury__mode_info__mode_info_var_is_nondet_live_3_0),
		mercury__unique_modes__select_nondet_live_vars_3_0_i5,
		STATIC(mercury__unique_modes__select_nondet_live_vars_3_0));
Define_label(mercury__unique_modes__select_nondet_live_vars_3_0_i5);
	update_prof_current_proc(LABEL(mercury__unique_modes__select_nondet_live_vars_3_0));
	if (((Integer) 0 != (Integer) r1))
		GOTO_LABEL(mercury__unique_modes__select_nondet_live_vars_3_0_i4);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(1);
	localcall(mercury__unique_modes__select_nondet_live_vars_3_0,
		LABEL(mercury__unique_modes__select_nondet_live_vars_3_0_i6),
		STATIC(mercury__unique_modes__select_nondet_live_vars_3_0));
Define_label(mercury__unique_modes__select_nondet_live_vars_3_0_i6);
	update_prof_current_proc(LABEL(mercury__unique_modes__select_nondet_live_vars_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__unique_modes__select_nondet_live_vars_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__unique_modes__select_nondet_live_vars_3_0_i4);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(4);
	GOTO_LABEL(mercury__unique_modes__select_nondet_live_vars_3_0_i1002);
Define_label(mercury__unique_modes__select_nondet_live_vars_3_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE

Declare_entry(mercury__mode_info__mode_info_get_module_info_2_0);
Declare_entry(mercury__instmap__lookup_var_3_0);
Declare_entry(mercury__instmap__instmap_delta_is_reachable_1_0);
Declare_entry(mercury__instmap__instmap_delta_search_var_3_0);
Declare_entry(mercury__inst_match__inst_matches_final_3_0);

BEGIN_MODULE(unique_modes_module8)
	init_entry(mercury__unique_modes__select_changed_inst_vars_4_0);
	init_label(mercury__unique_modes__select_changed_inst_vars_4_0_i1004);
	init_label(mercury__unique_modes__select_changed_inst_vars_4_0_i4);
	init_label(mercury__unique_modes__select_changed_inst_vars_4_0_i5);
	init_label(mercury__unique_modes__select_changed_inst_vars_4_0_i6);
	init_label(mercury__unique_modes__select_changed_inst_vars_4_0_i8);
	init_label(mercury__unique_modes__select_changed_inst_vars_4_0_i10);
	init_label(mercury__unique_modes__select_changed_inst_vars_4_0_i14);
	init_label(mercury__unique_modes__select_changed_inst_vars_4_0_i16);
	init_label(mercury__unique_modes__select_changed_inst_vars_4_0_i7);
	init_label(mercury__unique_modes__select_changed_inst_vars_4_0_i3);
BEGIN_CODE

/* code for predicate 'select_changed_inst_vars'/4 in mode 0 */
Define_static(mercury__unique_modes__select_changed_inst_vars_4_0);
	MR_incr_sp_push_msg(7, "unique_modes:select_changed_inst_vars/4");
	MR_stackvar(7) = (Word) MR_succip;
Define_label(mercury__unique_modes__select_changed_inst_vars_4_0_i1004);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unique_modes__select_changed_inst_vars_4_0_i3);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = r3;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__mode_info__mode_info_get_module_info_2_0),
		mercury__unique_modes__select_changed_inst_vars_4_0_i4,
		STATIC(mercury__unique_modes__select_changed_inst_vars_4_0));
Define_label(mercury__unique_modes__select_changed_inst_vars_4_0_i4);
	update_prof_current_proc(LABEL(mercury__unique_modes__select_changed_inst_vars_4_0));
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__mode_info__mode_info_get_instmap_2_0),
		mercury__unique_modes__select_changed_inst_vars_4_0_i5,
		STATIC(mercury__unique_modes__select_changed_inst_vars_4_0));
Define_label(mercury__unique_modes__select_changed_inst_vars_4_0_i5);
	update_prof_current_proc(LABEL(mercury__unique_modes__select_changed_inst_vars_4_0));
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__instmap__lookup_var_3_0),
		mercury__unique_modes__select_changed_inst_vars_4_0_i6,
		STATIC(mercury__unique_modes__select_changed_inst_vars_4_0));
Define_label(mercury__unique_modes__select_changed_inst_vars_4_0_i6);
	update_prof_current_proc(LABEL(mercury__unique_modes__select_changed_inst_vars_4_0));
	MR_stackvar(6) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__instmap__instmap_delta_is_reachable_1_0),
		mercury__unique_modes__select_changed_inst_vars_4_0_i8,
		STATIC(mercury__unique_modes__select_changed_inst_vars_4_0));
Define_label(mercury__unique_modes__select_changed_inst_vars_4_0_i8);
	update_prof_current_proc(LABEL(mercury__unique_modes__select_changed_inst_vars_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__unique_modes__select_changed_inst_vars_4_0_i7);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__instmap__instmap_delta_search_var_3_0),
		mercury__unique_modes__select_changed_inst_vars_4_0_i10,
		STATIC(mercury__unique_modes__select_changed_inst_vars_4_0));
Define_label(mercury__unique_modes__select_changed_inst_vars_4_0_i10);
	update_prof_current_proc(LABEL(mercury__unique_modes__select_changed_inst_vars_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__unique_modes__select_changed_inst_vars_4_0_i7);
	r1 = r2;
	r2 = MR_stackvar(6);
	r3 = MR_stackvar(5);
	call_localret(ENTRY(mercury__inst_match__inst_matches_final_3_0),
		mercury__unique_modes__select_changed_inst_vars_4_0_i14,
		STATIC(mercury__unique_modes__select_changed_inst_vars_4_0));
Define_label(mercury__unique_modes__select_changed_inst_vars_4_0_i14);
	update_prof_current_proc(LABEL(mercury__unique_modes__select_changed_inst_vars_4_0));
	if (r1)
		GOTO_LABEL(mercury__unique_modes__select_changed_inst_vars_4_0_i7);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	localcall(mercury__unique_modes__select_changed_inst_vars_4_0,
		LABEL(mercury__unique_modes__select_changed_inst_vars_4_0_i16),
		STATIC(mercury__unique_modes__select_changed_inst_vars_4_0));
Define_label(mercury__unique_modes__select_changed_inst_vars_4_0_i16);
	update_prof_current_proc(LABEL(mercury__unique_modes__select_changed_inst_vars_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__unique_modes__select_changed_inst_vars_4_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
Define_label(mercury__unique_modes__select_changed_inst_vars_4_0_i7);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(7);
	GOTO_LABEL(mercury__unique_modes__select_changed_inst_vars_4_0_i1004);
Define_label(mercury__unique_modes__select_changed_inst_vars_4_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE

Declare_entry(mercury__list__member_2_0);
Declare_entry(mercury__inst_match__inst_expand_3_0);
Declare_entry(mercury__inst_util__make_mostly_uniq_inst_4_0);
Declare_entry(mercury__mode_info__mode_info_set_module_info_3_0);
Declare_entry(mercury__instmap__set_4_0);
Declare_entry(mercury__mode_info__mode_info_set_instmap_3_0);

BEGIN_MODULE(unique_modes_module9)
	init_entry(mercury__unique_modes__make_var_list_mostly_uniq_3_0);
	init_label(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i1008);
	init_label(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i4);
	init_label(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i5);
	init_label(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i7);
	init_label(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i9);
	init_label(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i10);
	init_label(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i12);
	init_label(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i13);
	init_label(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i17);
	init_label(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i19);
	init_label(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i16);
	init_label(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i23);
	init_label(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i24);
	init_label(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i25);
	init_label(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i26);
	init_label(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i6);
	init_label(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i3);
BEGIN_CODE

/* code for predicate 'make_var_list_mostly_uniq'/3 in mode 0 */
Define_static(mercury__unique_modes__make_var_list_mostly_uniq_3_0);
	MR_incr_sp_push_msg(7, "unique_modes:make_var_list_mostly_uniq/3");
	MR_stackvar(7) = (Word) MR_succip;
Define_label(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i1008);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i3);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = r2;
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__mode_info__mode_info_get_instmap_2_0),
		mercury__unique_modes__make_var_list_mostly_uniq_3_0_i4,
		STATIC(mercury__unique_modes__make_var_list_mostly_uniq_3_0));
Define_label(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i4);
	update_prof_current_proc(LABEL(mercury__unique_modes__make_var_list_mostly_uniq_3_0));
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__mode_info__mode_info_get_module_info_2_0),
		mercury__unique_modes__make_var_list_mostly_uniq_3_0_i5,
		STATIC(mercury__unique_modes__make_var_list_mostly_uniq_3_0));
Define_label(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i5);
	update_prof_current_proc(LABEL(mercury__unique_modes__make_var_list_mostly_uniq_3_0));
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__instmap__is_reachable_1_0),
		mercury__unique_modes__make_var_list_mostly_uniq_3_0_i7,
		STATIC(mercury__unique_modes__make_var_list_mostly_uniq_3_0));
Define_label(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i7);
	update_prof_current_proc(LABEL(mercury__unique_modes__make_var_list_mostly_uniq_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i6);
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__instmap__vars_list_2_0),
		mercury__unique_modes__make_var_list_mostly_uniq_3_0_i9,
		STATIC(mercury__unique_modes__make_var_list_mostly_uniq_3_0));
Define_label(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i9);
	update_prof_current_proc(LABEL(mercury__unique_modes__make_var_list_mostly_uniq_3_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unique_modes__common_0);
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__unique_modes__make_var_list_mostly_uniq_3_0_i10,
		STATIC(mercury__unique_modes__make_var_list_mostly_uniq_3_0));
Define_label(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i10);
	update_prof_current_proc(LABEL(mercury__unique_modes__make_var_list_mostly_uniq_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i6);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__instmap__lookup_var_3_0),
		mercury__unique_modes__make_var_list_mostly_uniq_3_0_i12,
		STATIC(mercury__unique_modes__make_var_list_mostly_uniq_3_0));
Define_label(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i12);
	update_prof_current_proc(LABEL(mercury__unique_modes__make_var_list_mostly_uniq_3_0));
	MR_stackvar(6) = r1;
	r2 = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__inst_match__inst_expand_3_0),
		mercury__unique_modes__make_var_list_mostly_uniq_3_0_i13,
		STATIC(mercury__unique_modes__make_var_list_mostly_uniq_3_0));
Define_label(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i13);
	update_prof_current_proc(LABEL(mercury__unique_modes__make_var_list_mostly_uniq_3_0));
	r2 = MR_tag(r1);
	if ((r2 != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i16);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i17) AND
		LABEL(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i19) AND
		LABEL(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i6) AND
		LABEL(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i6) AND
		LABEL(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i6));
Define_label(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i17);
	if (((Integer) MR_const_field(MR_mktag(3), r1, (Integer) 1) != (Integer) 1))
		GOTO_LABEL(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i6);
	r2 = MR_stackvar(5);
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__inst_util__make_mostly_uniq_inst_4_0),
		mercury__unique_modes__make_var_list_mostly_uniq_3_0_i23,
		STATIC(mercury__unique_modes__make_var_list_mostly_uniq_3_0));
Define_label(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i19);
	if (((Integer) MR_const_field(MR_mktag(3), r1, (Integer) 1) != (Integer) 1))
		GOTO_LABEL(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i6);
	r2 = MR_stackvar(5);
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__inst_util__make_mostly_uniq_inst_4_0),
		mercury__unique_modes__make_var_list_mostly_uniq_3_0_i23,
		STATIC(mercury__unique_modes__make_var_list_mostly_uniq_3_0));
Define_label(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i16);
	if ((r2 != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i6);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 0) != (Integer) 1))
		GOTO_LABEL(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i6);
	r2 = MR_stackvar(5);
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__inst_util__make_mostly_uniq_inst_4_0),
		mercury__unique_modes__make_var_list_mostly_uniq_3_0_i23,
		STATIC(mercury__unique_modes__make_var_list_mostly_uniq_3_0));
Define_label(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i23);
	update_prof_current_proc(LABEL(mercury__unique_modes__make_var_list_mostly_uniq_3_0));
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__mode_info__mode_info_set_module_info_3_0),
		mercury__unique_modes__make_var_list_mostly_uniq_3_0_i24,
		STATIC(mercury__unique_modes__make_var_list_mostly_uniq_3_0));
Define_label(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i24);
	update_prof_current_proc(LABEL(mercury__unique_modes__make_var_list_mostly_uniq_3_0));
	r2 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(4);
	r3 = MR_stackvar(5);
	call_localret(ENTRY(mercury__instmap__set_4_0),
		mercury__unique_modes__make_var_list_mostly_uniq_3_0_i25,
		STATIC(mercury__unique_modes__make_var_list_mostly_uniq_3_0));
Define_label(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i25);
	update_prof_current_proc(LABEL(mercury__unique_modes__make_var_list_mostly_uniq_3_0));
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__mode_info__mode_info_set_instmap_3_0),
		mercury__unique_modes__make_var_list_mostly_uniq_3_0_i26,
		STATIC(mercury__unique_modes__make_var_list_mostly_uniq_3_0));
Define_label(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i26);
	update_prof_current_proc(LABEL(mercury__unique_modes__make_var_list_mostly_uniq_3_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(7);
	GOTO_LABEL(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i1008);
Define_label(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i6);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(7);
	GOTO_LABEL(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i1008);
Define_label(mercury__unique_modes__make_var_list_mostly_uniq_3_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE

Declare_entry(mercury__mode_debug__mode_checkpoint_4_0);
Declare_entry(mercury__modes__mode_info_add_goals_live_vars_3_0);
Declare_entry(mercury__prog_out__sym_name_to_string_2_0);
Declare_entry(mercury__string__append_3_2);
Declare_entry(mercury__mode_info__mode_info_get_call_id_3_0);
Declare_entry(mercury__mode_info__mode_info_set_call_context_3_0);
Declare_entry(mercury__mode_info__mode_info_unset_call_context_2_0);
Declare_entry(mercury__hlds_goal__generic_call_id_2_0);
Declare_entry(mercury__hlds_data__determinism_components_3_0);
Declare_entry(mercury__hlds_data__determinism_to_code_model_2_0);
Declare_entry(mercury__instmap__init_unreachable_1_0);
Declare_entry(mercury__instmap__merge_5_0);
Declare_entry(mercury__modecheck_unify__modecheck_unification_8_0);
Declare_entry(mercury__mode_info__mode_info_add_live_vars_3_0);
Declare_entry(mercury__mode_info__mode_info_remove_live_vars_3_0);
Declare_entry(mercury__mode_info__mode_info_dcg_get_instmap_3_0);
Declare_entry(mercury__set__to_sorted_list_2_0);
Declare_entry(mercury__mode_info__mode_info_get_live_vars_2_0);
Declare_entry(mercury__mode_info__mode_info_set_live_vars_3_0);
Declare_entry(mercury__mode_info__mode_info_lock_vars_4_0);
Declare_entry(mercury__mode_info__mode_info_unlock_vars_4_0);
Declare_entry(mercury__hlds_goal__goal_info_get_instmap_delta_2_0);
Declare_entry(mercury__hlds_goal__true_goal_1_0);
Declare_entry(mercury__instmap__unify_4_0);
Declare_entry(mercury__require__error_1_0);

BEGIN_MODULE(unique_modes_module10)
	init_entry(mercury__unique_modes__check_goal_2_5_0);
	init_label(mercury__unique_modes__check_goal_2_5_0_i4);
	init_label(mercury__unique_modes__check_goal_2_5_0_i5);
	init_label(mercury__unique_modes__check_goal_2_5_0_i6);
	init_label(mercury__unique_modes__check_goal_2_5_0_i8);
	init_label(mercury__unique_modes__check_goal_2_5_0_i9);
	init_label(mercury__unique_modes__check_goal_2_5_0_i12);
	init_label(mercury__unique_modes__check_goal_2_5_0_i13);
	init_label(mercury__unique_modes__check_goal_2_5_0_i14);
	init_label(mercury__unique_modes__check_goal_2_5_0_i15);
	init_label(mercury__unique_modes__check_goal_2_5_0_i16);
	init_label(mercury__unique_modes__check_goal_2_5_0_i17);
	init_label(mercury__unique_modes__check_goal_2_5_0_i18);
	init_label(mercury__unique_modes__check_goal_2_5_0_i19);
	init_label(mercury__unique_modes__check_goal_2_5_0_i21);
	init_label(mercury__unique_modes__check_goal_2_5_0_i22);
	init_label(mercury__unique_modes__check_goal_2_5_0_i23);
	init_label(mercury__unique_modes__check_goal_2_5_0_i24);
	init_label(mercury__unique_modes__check_goal_2_5_0_i26);
	init_label(mercury__unique_modes__check_goal_2_5_0_i25);
	init_label(mercury__unique_modes__check_goal_2_5_0_i28);
	init_label(mercury__unique_modes__check_goal_2_5_0_i32);
	init_label(mercury__unique_modes__check_goal_2_5_0_i31);
	init_label(mercury__unique_modes__check_goal_2_5_0_i36);
	init_label(mercury__unique_modes__check_goal_2_5_0_i37);
	init_label(mercury__unique_modes__check_goal_2_5_0_i38);
	init_label(mercury__unique_modes__check_goal_2_5_0_i39);
	init_label(mercury__unique_modes__check_goal_2_5_0_i40);
	init_label(mercury__unique_modes__check_goal_2_5_0_i41);
	init_label(mercury__unique_modes__check_goal_2_5_0_i44);
	init_label(mercury__unique_modes__check_goal_2_5_0_i45);
	init_label(mercury__unique_modes__check_goal_2_5_0_i42);
	init_label(mercury__unique_modes__check_goal_2_5_0_i46);
	init_label(mercury__unique_modes__check_goal_2_5_0_i47);
	init_label(mercury__unique_modes__check_goal_2_5_0_i48);
	init_label(mercury__unique_modes__check_goal_2_5_0_i51);
	init_label(mercury__unique_modes__check_goal_2_5_0_i52);
	init_label(mercury__unique_modes__check_goal_2_5_0_i53);
	init_label(mercury__unique_modes__check_goal_2_5_0_i54);
	init_label(mercury__unique_modes__check_goal_2_5_0_i55);
	init_label(mercury__unique_modes__check_goal_2_5_0_i57);
	init_label(mercury__unique_modes__check_goal_2_5_0_i58);
	init_label(mercury__unique_modes__check_goal_2_5_0_i61);
	init_label(mercury__unique_modes__check_goal_2_5_0_i1041);
	init_label(mercury__unique_modes__check_goal_2_5_0_i59);
	init_label(mercury__unique_modes__check_goal_2_5_0_i63);
	init_label(mercury__unique_modes__check_goal_2_5_0_i64);
	init_label(mercury__unique_modes__check_goal_2_5_0_i67);
	init_label(mercury__unique_modes__check_goal_2_5_0_i68);
	init_label(mercury__unique_modes__check_goal_2_5_0_i69);
	init_label(mercury__unique_modes__check_goal_2_5_0_i65);
	init_label(mercury__unique_modes__check_goal_2_5_0_i70);
	init_label(mercury__unique_modes__check_goal_2_5_0_i71);
	init_label(mercury__unique_modes__check_goal_2_5_0_i1043);
	init_label(mercury__unique_modes__check_goal_2_5_0_i75);
	init_label(mercury__unique_modes__check_goal_2_5_0_i76);
	init_label(mercury__unique_modes__check_goal_2_5_0_i77);
	init_label(mercury__unique_modes__check_goal_2_5_0_i78);
	init_label(mercury__unique_modes__check_goal_2_5_0_i79);
	init_label(mercury__unique_modes__check_goal_2_5_0_i80);
	init_label(mercury__unique_modes__check_goal_2_5_0_i81);
	init_label(mercury__unique_modes__check_goal_2_5_0_i82);
	init_label(mercury__unique_modes__check_goal_2_5_0_i83);
	init_label(mercury__unique_modes__check_goal_2_5_0_i84);
	init_label(mercury__unique_modes__check_goal_2_5_0_i1044);
	init_label(mercury__unique_modes__check_goal_2_5_0_i86);
	init_label(mercury__unique_modes__check_goal_2_5_0_i87);
	init_label(mercury__unique_modes__check_goal_2_5_0_i88);
	init_label(mercury__unique_modes__check_goal_2_5_0_i90);
	init_label(mercury__unique_modes__check_goal_2_5_0_i91);
	init_label(mercury__unique_modes__check_goal_2_5_0_i92);
	init_label(mercury__unique_modes__check_goal_2_5_0_i94);
	init_label(mercury__unique_modes__check_goal_2_5_0_i95);
	init_label(mercury__unique_modes__check_goal_2_5_0_i96);
	init_label(mercury__unique_modes__check_goal_2_5_0_i97);
	init_label(mercury__unique_modes__check_goal_2_5_0_i98);
	init_label(mercury__unique_modes__check_goal_2_5_0_i99);
	init_label(mercury__unique_modes__check_goal_2_5_0_i100);
	init_label(mercury__unique_modes__check_goal_2_5_0_i101);
	init_label(mercury__unique_modes__check_goal_2_5_0_i102);
	init_label(mercury__unique_modes__check_goal_2_5_0_i103);
	init_label(mercury__unique_modes__check_goal_2_5_0_i104);
	init_label(mercury__unique_modes__check_goal_2_5_0_i105);
	init_label(mercury__unique_modes__check_goal_2_5_0_i106);
	init_label(mercury__unique_modes__check_goal_2_5_0_i107);
	init_label(mercury__unique_modes__check_goal_2_5_0_i108);
	init_label(mercury__unique_modes__check_goal_2_5_0_i109);
	init_label(mercury__unique_modes__check_goal_2_5_0_i110);
	init_label(mercury__unique_modes__check_goal_2_5_0_i111);
	init_label(mercury__unique_modes__check_goal_2_5_0_i112);
	init_label(mercury__unique_modes__check_goal_2_5_0_i113);
	init_label(mercury__unique_modes__check_goal_2_5_0_i116);
	init_label(mercury__unique_modes__check_goal_2_5_0_i118);
	init_label(mercury__unique_modes__check_goal_2_5_0_i119);
	init_label(mercury__unique_modes__check_goal_2_5_0_i114);
	init_label(mercury__unique_modes__check_goal_2_5_0_i120);
	init_label(mercury__unique_modes__check_goal_2_5_0_i121);
	init_label(mercury__unique_modes__check_goal_2_5_0_i122);
	init_label(mercury__unique_modes__check_goal_2_5_0_i123);
	init_label(mercury__unique_modes__check_goal_2_5_0_i124);
	init_label(mercury__unique_modes__check_goal_2_5_0_i125);
	init_label(mercury__unique_modes__check_goal_2_5_0_i126);
	init_label(mercury__unique_modes__check_goal_2_5_0_i128);
	init_label(mercury__unique_modes__check_goal_2_5_0_i129);
	init_label(mercury__unique_modes__check_goal_2_5_0_i130);
	init_label(mercury__unique_modes__check_goal_2_5_0_i131);
	init_label(mercury__unique_modes__check_goal_2_5_0_i132);
	init_label(mercury__unique_modes__check_goal_2_5_0_i133);
	init_label(mercury__unique_modes__check_goal_2_5_0_i135);
	init_label(mercury__unique_modes__check_goal_2_5_0_i136);
	init_label(mercury__unique_modes__check_goal_2_5_0_i137);
	init_label(mercury__unique_modes__check_goal_2_5_0_i138);
	init_label(mercury__unique_modes__check_goal_2_5_0_i139);
	init_label(mercury__unique_modes__check_goal_2_5_0_i1053);
	init_label(mercury__unique_modes__check_goal_2_5_0_i141);
	init_label(mercury__unique_modes__check_goal_2_5_0_i142);
	init_label(mercury__unique_modes__check_goal_2_5_0_i143);
	init_label(mercury__unique_modes__check_goal_2_5_0_i144);
	init_label(mercury__unique_modes__check_goal_2_5_0_i145);
BEGIN_CODE

/* code for predicate 'check_goal_2'/5 in mode 0 */
Define_static(mercury__unique_modes__check_goal_2_5_0);
	MR_incr_sp_push_msg(13, "unique_modes:check_goal_2/5");
	MR_stackvar(13) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__unique_modes__check_goal_2_5_0_i4) AND
		LABEL(mercury__unique_modes__check_goal_2_5_0_i12) AND
		LABEL(mercury__unique_modes__check_goal_2_5_0_i21) AND
		LABEL(mercury__unique_modes__check_goal_2_5_0_i39));
Define_label(mercury__unique_modes__check_goal_2_5_0_i4);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r1 = (Integer) 0;
	r2 = (Word) MR_string_const("conj", 4);
	call_localret(ENTRY(mercury__mode_debug__mode_checkpoint_4_0),
		mercury__unique_modes__check_goal_2_5_0_i5,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i5);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	if (((Integer) MR_stackvar(1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unique_modes__check_goal_2_5_0_i6);
	r3 = r1;
	r1 = (Integer) 1;
	r2 = (Word) MR_string_const("conj", 4);
	MR_stackvar(2) = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unique_modes__common_1);
	call_localret(ENTRY(mercury__mode_debug__mode_checkpoint_4_0),
		mercury__unique_modes__check_goal_2_5_0_i143,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i6);
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__modes__mode_info_add_goals_live_vars_3_0),
		mercury__unique_modes__check_goal_2_5_0_i8,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i8);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(STATIC(mercury__unique_modes__check_conj_4_0),
		mercury__unique_modes__check_goal_2_5_0_i9,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i9);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 1, mercury__unique_modes__check_goal_2_5_0, "origin_lost_in_value_number");
	r3 = r2;
	MR_stackvar(2) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r1;
	r1 = (Integer) 1;
	r2 = (Word) MR_string_const("conj", 4);
	call_localret(ENTRY(mercury__mode_debug__mode_checkpoint_4_0),
		mercury__unique_modes__check_goal_2_5_0_i143,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
	}
Define_label(mercury__unique_modes__check_goal_2_5_0_i12);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 2);
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r1, (Integer) 3);
	MR_stackvar(6) = MR_const_field(MR_mktag(1), r1, (Integer) 4);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 5);
	MR_stackvar(7) = r1;
	MR_stackvar(1) = r3;
	call_localret(ENTRY(mercury__prog_out__sym_name_to_string_2_0),
		mercury__unique_modes__check_goal_2_5_0_i13,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i13);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const("call ", 5);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__unique_modes__check_goal_2_5_0_i14,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i14);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r2 = r1;
	r1 = (Integer) 0;
	r3 = MR_stackvar(1);
	call_localret(ENTRY(mercury__mode_debug__mode_checkpoint_4_0),
		mercury__unique_modes__check_goal_2_5_0_i15,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i15);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	MR_stackvar(1) = r1;
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__mode_info__mode_info_get_call_id_3_0),
		mercury__unique_modes__check_goal_2_5_0_i16,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i16);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__unique_modes__check_goal_2_5_0, "mode_info:call_context/0");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 1, mercury__unique_modes__check_goal_2_5_0, "hlds_pred:call_id/0");
	MR_field(MR_mktag(0), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__mode_info__mode_info_set_call_context_3_0),
		mercury__unique_modes__check_goal_2_5_0_i17,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i17);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r4 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(4);
	call_localret(STATIC(mercury__unique_modes__check_call_6_0),
		mercury__unique_modes__check_goal_2_5_0_i18,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i18);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r3 = MR_stackvar(2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 6, mercury__unique_modes__check_goal_2_5_0, "origin_lost_in_value_number");
	MR_stackvar(2) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = r1;
	r1 = r2;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 5) = MR_stackvar(7);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 4) = MR_stackvar(6);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 3) = MR_stackvar(5);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 2) = MR_stackvar(4);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r3;
	call_localret(ENTRY(mercury__mode_info__mode_info_unset_call_context_2_0),
		mercury__unique_modes__check_goal_2_5_0_i19,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
	}
Define_label(mercury__unique_modes__check_goal_2_5_0_i19);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r3 = r1;
	r1 = (Integer) 1;
	r2 = (Word) MR_string_const("call", 4);
	call_localret(ENTRY(mercury__mode_debug__mode_checkpoint_4_0),
		mercury__unique_modes__check_goal_2_5_0_i143,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i21);
	MR_stackvar(1) = r1;
	MR_stackvar(3) = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(2), r1, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(2), r1, (Integer) 2);
	MR_stackvar(6) = MR_const_field(MR_mktag(2), r1, (Integer) 3);
	r1 = (Integer) 0;
	r2 = (Word) MR_string_const("generic_call", 12);
	call_localret(ENTRY(mercury__mode_debug__mode_checkpoint_4_0),
		mercury__unique_modes__check_goal_2_5_0_i22,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i22);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__hlds_goal__generic_call_id_2_0),
		mercury__unique_modes__check_goal_2_5_0_i23,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i23);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__unique_modes__check_goal_2_5_0, "mode_info:call_context/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__mode_info__mode_info_set_call_context_3_0),
		mercury__unique_modes__check_goal_2_5_0_i24,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i24);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	MR_stackvar(7) = r1;
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__hlds_data__determinism_components_3_0),
		mercury__unique_modes__check_goal_2_5_0_i26,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i26);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	if (((Integer) 0 != (Integer) r2))
		GOTO_LABEL(mercury__unique_modes__check_goal_2_5_0_i25);
	r1 = MR_stackvar(6);
	MR_stackvar(2) = (Integer) 1;
	call_localret(ENTRY(mercury__hlds_data__determinism_to_code_model_2_0),
		mercury__unique_modes__check_goal_2_5_0_i28,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i25);
	r1 = MR_stackvar(6);
	MR_stackvar(2) = (Integer) 0;
	call_localret(ENTRY(mercury__hlds_data__determinism_to_code_model_2_0),
		mercury__unique_modes__check_goal_2_5_0_i28,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i28);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r2 = MR_stackvar(3);
	r3 = MR_tag(r2);
	if ((r3 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__unique_modes__check_goal_2_5_0_i31);
	if ((r3 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__unique_modes__check_goal_2_5_0_i32);
	r4 = r1;
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(5);
	r3 = (Integer) 1;
	r5 = MR_stackvar(2);
	r6 = MR_stackvar(7);
	call_localret(STATIC(mercury__unique_modes__check_call_modes_7_0),
		mercury__unique_modes__check_goal_2_5_0_i36,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i32);
	if ((MR_tag(MR_const_field(MR_mktag(2), r2, (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__unique_modes__check_goal_2_5_0_i31);
	r3 = ((Integer) 0 - (Integer) MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(2), r2, (Integer) 1), (Integer) 1), (Integer) 1));
	r4 = r1;
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(5);
	r5 = MR_stackvar(2);
	r6 = MR_stackvar(7);
	call_localret(STATIC(mercury__unique_modes__check_call_modes_7_0),
		mercury__unique_modes__check_goal_2_5_0_i36,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i31);
	r4 = r1;
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(5);
	r3 = (Integer) 0;
	r5 = MR_stackvar(2);
	r6 = MR_stackvar(7);
	call_localret(STATIC(mercury__unique_modes__check_call_modes_7_0),
		mercury__unique_modes__check_goal_2_5_0_i36,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i36);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	MR_stackvar(2) = MR_stackvar(1);
	call_localret(ENTRY(mercury__mode_info__mode_info_unset_call_context_2_0),
		mercury__unique_modes__check_goal_2_5_0_i37,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i37);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r3 = r1;
	r1 = (Integer) 1;
	r2 = (Word) MR_string_const("generic_call", 12);
	call_localret(ENTRY(mercury__mode_debug__mode_checkpoint_4_0),
		mercury__unique_modes__check_goal_2_5_0_i38,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i38);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	proceed();
Define_label(mercury__unique_modes__check_goal_2_5_0_i39);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__unique_modes__check_goal_2_5_0_i40) AND
		LABEL(mercury__unique_modes__check_goal_2_5_0_i51) AND
		LABEL(mercury__unique_modes__check_goal_2_5_0_i57) AND
		LABEL(mercury__unique_modes__check_goal_2_5_0_i75) AND
		LABEL(mercury__unique_modes__check_goal_2_5_0_i90) AND
		LABEL(mercury__unique_modes__check_goal_2_5_0_i94) AND
		LABEL(mercury__unique_modes__check_goal_2_5_0_i128) AND
		LABEL(mercury__unique_modes__check_goal_2_5_0_i135) AND
		LABEL(mercury__unique_modes__check_goal_2_5_0_i144));
Define_label(mercury__unique_modes__check_goal_2_5_0_i40);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(4) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	MR_stackvar(5) = MR_const_field(MR_mktag(3), r1, (Integer) 4);
	r1 = (Integer) 0;
	r2 = (Word) MR_string_const("switch", 6);
	call_localret(ENTRY(mercury__mode_debug__mode_checkpoint_4_0),
		mercury__unique_modes__check_goal_2_5_0_i41,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i41);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	if (((Integer) MR_stackvar(4) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unique_modes__check_goal_2_5_0_i42);
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__instmap__init_unreachable_1_0),
		mercury__unique_modes__check_goal_2_5_0_i44,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i44);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__mode_info__mode_info_set_instmap_3_0),
		mercury__unique_modes__check_goal_2_5_0_i45,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i45);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r2 = MR_stackvar(2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 5, mercury__unique_modes__check_goal_2_5_0, "origin_lost_in_value_number");
	r3 = r1;
	MR_stackvar(2) = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r2;
	r1 = (Integer) 1;
	r2 = (Word) MR_string_const("switch", 6);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 4) = MR_stackvar(5);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 3) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_stackvar(3);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 0;
	call_localret(ENTRY(mercury__mode_debug__mode_checkpoint_4_0),
		mercury__unique_modes__check_goal_2_5_0_i143,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
	}
Define_label(mercury__unique_modes__check_goal_2_5_0_i42);
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_nonlocals_2_0),
		mercury__unique_modes__check_goal_2_5_0_i46,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i46);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r3 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(2);
	call_localret(STATIC(mercury__unique_modes__check_case_list_6_0),
		mercury__unique_modes__check_goal_2_5_0_i47,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i47);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	r4 = r3;
	r3 = (Integer) 0;
	call_localret(ENTRY(mercury__instmap__merge_5_0),
		mercury__unique_modes__check_goal_2_5_0_i48,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
	}
Define_label(mercury__unique_modes__check_goal_2_5_0_i48);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r2 = MR_stackvar(2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 5, mercury__unique_modes__check_goal_2_5_0, "origin_lost_in_value_number");
	r3 = r1;
	MR_stackvar(2) = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r2;
	r1 = (Integer) 1;
	r2 = (Word) MR_string_const("switch", 6);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 4) = MR_stackvar(5);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 3) = MR_stackvar(1);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_stackvar(3);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 0;
	call_localret(ENTRY(mercury__mode_debug__mode_checkpoint_4_0),
		mercury__unique_modes__check_goal_2_5_0_i143,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
	}
Define_label(mercury__unique_modes__check_goal_2_5_0_i51);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(4) = MR_const_field(MR_mktag(3), r1, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(3), r1, (Integer) 5);
	r1 = (Integer) 0;
	r2 = (Word) MR_string_const("unify", 5);
	call_localret(ENTRY(mercury__mode_debug__mode_checkpoint_4_0),
		mercury__unique_modes__check_goal_2_5_0_i52,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i52);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 1, mercury__unique_modes__check_goal_2_5_0, "mode_info:call_context/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(5);
	call_localret(ENTRY(mercury__mode_info__mode_info_set_call_context_3_0),
		mercury__unique_modes__check_goal_2_5_0_i53,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i53);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r6 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(5);
	r5 = MR_stackvar(1);
	call_localret(ENTRY(mercury__modecheck_unify__modecheck_unification_8_0),
		mercury__unique_modes__check_goal_2_5_0_i54,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i54);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	MR_stackvar(2) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__mode_info__mode_info_unset_call_context_2_0),
		mercury__unique_modes__check_goal_2_5_0_i55,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i55);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r3 = r1;
	r1 = (Integer) 1;
	r2 = (Word) MR_string_const("unify", 5);
	call_localret(ENTRY(mercury__mode_debug__mode_checkpoint_4_0),
		mercury__unique_modes__check_goal_2_5_0_i143,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i57);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = (Integer) 0;
	r2 = (Word) MR_string_const("disj", 4);
	call_localret(ENTRY(mercury__mode_debug__mode_checkpoint_4_0),
		mercury__unique_modes__check_goal_2_5_0_i58,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i58);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	if (((Integer) MR_stackvar(2) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unique_modes__check_goal_2_5_0_i59);
	MR_stackvar(4) = r1;
	call_localret(ENTRY(mercury__instmap__init_unreachable_1_0),
		mercury__unique_modes__check_goal_2_5_0_i61,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i61);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r2 = MR_stackvar(4);
	call_localret(ENTRY(mercury__mode_info__mode_info_set_instmap_3_0),
		mercury__unique_modes__check_goal_2_5_0_i1041,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i1041);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 3, mercury__unique_modes__check_goal_2_5_0, "origin_lost_in_value_number");
	r3 = r1;
	MR_stackvar(2) = MR_tempr1;
	r1 = (Integer) 1;
	r2 = (Word) MR_string_const("disj", 4);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_stackvar(3);
	call_localret(ENTRY(mercury__mode_debug__mode_checkpoint_4_0),
		mercury__unique_modes__check_goal_2_5_0_i143,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
	}
Define_label(mercury__unique_modes__check_goal_2_5_0_i59);
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_nonlocals_2_0),
		mercury__unique_modes__check_goal_2_5_0_i63,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i63);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_code_model_2_0),
		mercury__unique_modes__check_goal_2_5_0_i64,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i64);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	if (((Integer) r1 != (Integer) 2))
		GOTO_LABEL(mercury__unique_modes__check_goal_2_5_0_i65);
	r2 = MR_stackvar(4);
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__mode_info__mode_info_add_live_vars_3_0),
		mercury__unique_modes__check_goal_2_5_0_i67,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i67);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	call_localret(STATIC(mercury__unique_modes__make_all_nondet_live_vars_mostly_uniq_2_0),
		mercury__unique_modes__check_goal_2_5_0_i68,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i68);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__mode_info__mode_info_remove_live_vars_3_0),
		mercury__unique_modes__check_goal_2_5_0_i69,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i69);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r4 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(1);
	GOTO_LABEL(mercury__unique_modes__check_goal_2_5_0_i70);
Define_label(mercury__unique_modes__check_goal_2_5_0_i65);
	r2 = r1;
	r1 = MR_stackvar(2);
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(4);
Define_label(mercury__unique_modes__check_goal_2_5_0_i70);
	MR_stackvar(1) = r3;
	call_localret(STATIC(mercury__unique_modes__check_disj_7_0),
		mercury__unique_modes__check_goal_2_5_0_i71,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i71);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	r4 = r3;
	r3 = (Integer) 0;
	call_localret(ENTRY(mercury__instmap__merge_5_0),
		mercury__unique_modes__check_goal_2_5_0_i1043,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
	}
Define_label(mercury__unique_modes__check_goal_2_5_0_i1043);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 3, mercury__unique_modes__check_goal_2_5_0, "origin_lost_in_value_number");
	r3 = r1;
	MR_stackvar(2) = MR_tempr1;
	r1 = (Integer) 1;
	r2 = (Word) MR_string_const("disj", 4);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_stackvar(3);
	call_localret(ENTRY(mercury__mode_debug__mode_checkpoint_4_0),
		mercury__unique_modes__check_goal_2_5_0_i143,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
	}
Define_label(mercury__unique_modes__check_goal_2_5_0_i75);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r1 = (Integer) 0;
	r2 = (Word) MR_string_const("not", 3);
	call_localret(ENTRY(mercury__mode_debug__mode_checkpoint_4_0),
		mercury__unique_modes__check_goal_2_5_0_i76,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i76);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	call_localret(ENTRY(mercury__mode_info__mode_info_dcg_get_instmap_3_0),
		mercury__unique_modes__check_goal_2_5_0_i77,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i77);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	MR_stackvar(4) = r2;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_nonlocals_2_0),
		mercury__unique_modes__check_goal_2_5_0_i78,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i78);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	MR_stackvar(3) = r1;
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unique_modes__common_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__unique_modes__check_goal_2_5_0_i79,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i79);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r2 = MR_stackvar(4);
	call_localret(STATIC(mercury__unique_modes__select_live_vars_3_0),
		mercury__unique_modes__check_goal_2_5_0_i80,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i80);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r2 = MR_stackvar(4);
	call_localret(STATIC(mercury__unique_modes__make_var_list_mostly_uniq_3_0),
		mercury__unique_modes__check_goal_2_5_0_i81,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i81);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	MR_stackvar(4) = r2;
	call_localret(ENTRY(mercury__mode_info__mode_info_get_live_vars_2_0),
		mercury__unique_modes__check_goal_2_5_0_i82,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i82);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r2 = MR_stackvar(4);
	MR_stackvar(4) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__mode_info__mode_info_set_live_vars_3_0),
		mercury__unique_modes__check_goal_2_5_0_i83,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i83);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__mode_info__mode_info_lock_vars_4_0),
		mercury__unique_modes__check_goal_2_5_0_i84,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i84);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(STATIC(mercury__unique_modes__check_goal_4_0),
		mercury__unique_modes__check_goal_2_5_0_i1044,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i1044);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__unique_modes__check_goal_2_5_0, "origin_lost_in_value_number");
	r3 = r2;
	MR_stackvar(2) = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = MR_stackvar(3);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 3;
	call_localret(ENTRY(mercury__mode_info__mode_info_unlock_vars_4_0),
		mercury__unique_modes__check_goal_2_5_0_i86,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
	}
Define_label(mercury__unique_modes__check_goal_2_5_0_i86);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__mode_info__mode_info_set_live_vars_3_0),
		mercury__unique_modes__check_goal_2_5_0_i87,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i87);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__mode_info__mode_info_set_instmap_3_0),
		mercury__unique_modes__check_goal_2_5_0_i88,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i88);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r3 = r1;
	r1 = (Integer) 1;
	r2 = (Word) MR_string_const("not", 3);
	call_localret(ENTRY(mercury__mode_debug__mode_checkpoint_4_0),
		mercury__unique_modes__check_goal_2_5_0_i143,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i90);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	r1 = (Integer) 0;
	r2 = (Word) MR_string_const("some", 4);
	call_localret(ENTRY(mercury__mode_debug__mode_checkpoint_4_0),
		mercury__unique_modes__check_goal_2_5_0_i91,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i91);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	call_localret(STATIC(mercury__unique_modes__check_goal_4_0),
		mercury__unique_modes__check_goal_2_5_0_i92,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i92);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r3 = MR_stackvar(2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 4, mercury__unique_modes__check_goal_2_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = r3;
	r3 = r2;
	MR_stackvar(2) = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 3) = r1;
	r1 = (Integer) 1;
	r2 = (Word) MR_string_const("some", 4);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 4;
	call_localret(ENTRY(mercury__mode_debug__mode_checkpoint_4_0),
		mercury__unique_modes__check_goal_2_5_0_i143,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
	}
Define_label(mercury__unique_modes__check_goal_2_5_0_i94);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	MR_stackvar(5) = MR_const_field(MR_mktag(3), r1, (Integer) 4);
	MR_stackvar(6) = MR_const_field(MR_mktag(3), r1, (Integer) 5);
	r1 = (Integer) 0;
	r2 = (Word) MR_string_const("if-then-else", 12);
	call_localret(ENTRY(mercury__mode_debug__mode_checkpoint_4_0),
		mercury__unique_modes__check_goal_2_5_0_i95,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i95);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	MR_stackvar(9) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_nonlocals_2_0),
		mercury__unique_modes__check_goal_2_5_0_i96,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i96);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(2);
	call_localret(STATIC(mercury__unique_modes__goal_get_nonlocals_2_0),
		mercury__unique_modes__check_goal_2_5_0_i97,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i97);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	MR_stackvar(7) = r1;
	r1 = MR_stackvar(4);
	call_localret(STATIC(mercury__unique_modes__goal_get_nonlocals_2_0),
		mercury__unique_modes__check_goal_2_5_0_i98,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i98);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	MR_stackvar(8) = r1;
	r1 = MR_stackvar(5);
	call_localret(STATIC(mercury__unique_modes__goal_get_nonlocals_2_0),
		mercury__unique_modes__check_goal_2_5_0_i99,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i99);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r2 = r1;
	r1 = MR_stackvar(9);
	MR_stackvar(9) = r2;
	call_localret(ENTRY(mercury__mode_info__mode_info_dcg_get_instmap_3_0),
		mercury__unique_modes__check_goal_2_5_0_i100,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i100);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r3 = r2;
	MR_stackvar(10) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1));
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__mode_info__mode_info_lock_vars_4_0),
		mercury__unique_modes__check_goal_2_5_0_i101,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i101);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r2 = r1;
	r1 = MR_stackvar(9);
	call_localret(ENTRY(mercury__mode_info__mode_info_add_live_vars_3_0),
		mercury__unique_modes__check_goal_2_5_0_i102,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i102);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	MR_stackvar(11) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unique_modes__common_0);
	r2 = MR_stackvar(7);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__unique_modes__check_goal_2_5_0_i103,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i103);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r2 = MR_stackvar(11);
	call_localret(STATIC(mercury__unique_modes__select_live_vars_3_0),
		mercury__unique_modes__check_goal_2_5_0_i104,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i104);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	MR_stackvar(7) = r1;
	r1 = MR_const_field(MR_mktag(0), MR_stackvar(2), (Integer) 1);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_instmap_delta_2_0),
		mercury__unique_modes__check_goal_2_5_0_i105,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i105);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r2 = r1;
	r1 = MR_stackvar(7);
	r3 = MR_stackvar(11);
	call_localret(STATIC(mercury__unique_modes__select_changed_inst_vars_4_0),
		mercury__unique_modes__check_goal_2_5_0_i106,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i106);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r2 = MR_stackvar(11);
	call_localret(STATIC(mercury__unique_modes__make_var_list_mostly_uniq_3_0),
		mercury__unique_modes__check_goal_2_5_0_i107,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i107);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r2 = r1;
	r1 = MR_stackvar(9);
	call_localret(ENTRY(mercury__mode_info__mode_info_remove_live_vars_3_0),
		mercury__unique_modes__check_goal_2_5_0_i108,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i108);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r2 = r1;
	r1 = MR_stackvar(8);
	call_localret(ENTRY(mercury__mode_info__mode_info_add_live_vars_3_0),
		mercury__unique_modes__check_goal_2_5_0_i109,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i109);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(STATIC(mercury__unique_modes__check_goal_4_0),
		mercury__unique_modes__check_goal_2_5_0_i110,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i110);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	MR_stackvar(7) = r1;
	r1 = MR_stackvar(8);
	call_localret(ENTRY(mercury__mode_info__mode_info_remove_live_vars_3_0),
		mercury__unique_modes__check_goal_2_5_0_i111,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i111);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1));
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__mode_info__mode_info_unlock_vars_4_0),
		mercury__unique_modes__check_goal_2_5_0_i112,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i112);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	call_localret(ENTRY(mercury__mode_info__mode_info_dcg_get_instmap_3_0),
		mercury__unique_modes__check_goal_2_5_0_i113,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i113);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	MR_stackvar(8) = r1;
	MR_stackvar(12) = r2;
	call_localret(ENTRY(mercury__instmap__is_reachable_1_0),
		mercury__unique_modes__check_goal_2_5_0_i116,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i116);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__unique_modes__check_goal_2_5_0_i114);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(12);
	call_localret(STATIC(mercury__unique_modes__check_goal_4_0),
		mercury__unique_modes__check_goal_2_5_0_i118,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i118);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	MR_stackvar(2) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__mode_info__mode_info_dcg_get_instmap_3_0),
		mercury__unique_modes__check_goal_2_5_0_i119,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i119);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(10);
	GOTO_LABEL(mercury__unique_modes__check_goal_2_5_0_i121);
Define_label(mercury__unique_modes__check_goal_2_5_0_i114);
	call_localret(ENTRY(mercury__hlds_goal__true_goal_1_0),
		mercury__unique_modes__check_goal_2_5_0_i120,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i120);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(10);
	r2 = MR_stackvar(12);
	MR_stackvar(4) = MR_stackvar(8);
Define_label(mercury__unique_modes__check_goal_2_5_0_i121);
	MR_stackvar(10) = r1;
	call_localret(ENTRY(mercury__mode_info__mode_info_set_instmap_3_0),
		mercury__unique_modes__check_goal_2_5_0_i122,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i122);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r2 = r1;
	r1 = MR_stackvar(5);
	call_localret(STATIC(mercury__unique_modes__check_goal_4_0),
		mercury__unique_modes__check_goal_2_5_0_i123,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i123);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	MR_stackvar(9) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__mode_info__mode_info_dcg_get_instmap_3_0),
		mercury__unique_modes__check_goal_2_5_0_i124,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i124);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	MR_stackvar(11) = r1;
	r1 = MR_stackvar(10);
	call_localret(ENTRY(mercury__mode_info__mode_info_set_instmap_3_0),
		mercury__unique_modes__check_goal_2_5_0_i125,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i125);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__unique_modes__check_goal_2_5_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(4);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__unique_modes__check_goal_2_5_0, "origin_lost_in_value_number");
	r4 = r3;
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_tempr1;
	r3 = (Integer) 1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(11);
	call_localret(ENTRY(mercury__instmap__merge_5_0),
		mercury__unique_modes__check_goal_2_5_0_i126,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
	}
Define_label(mercury__unique_modes__check_goal_2_5_0_i126);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r2 = MR_stackvar(2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 6, mercury__unique_modes__check_goal_2_5_0, "origin_lost_in_value_number");
	r3 = r1;
	MR_stackvar(2) = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 3) = r2;
	r1 = (Integer) 1;
	r2 = (Word) MR_string_const("if-then-else", 12);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 4) = MR_stackvar(9);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_stackvar(7);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(3);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 5;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 5) = MR_stackvar(6);
	call_localret(ENTRY(mercury__mode_debug__mode_checkpoint_4_0),
		mercury__unique_modes__check_goal_2_5_0_i143,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
	}
Define_label(mercury__unique_modes__check_goal_2_5_0_i128);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(3), r1, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(3), r1, (Integer) 5);
	MR_stackvar(6) = MR_const_field(MR_mktag(3), r1, (Integer) 6);
	MR_stackvar(7) = MR_const_field(MR_mktag(3), r1, (Integer) 7);
	r1 = (Integer) 0;
	r2 = (Word) MR_string_const("pragma_c_code", 13);
	call_localret(ENTRY(mercury__mode_debug__mode_checkpoint_4_0),
		mercury__unique_modes__check_goal_2_5_0_i129,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i129);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	MR_stackvar(8) = r1;
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__mode_info__mode_info_get_call_id_3_0),
		mercury__unique_modes__check_goal_2_5_0_i130,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i130);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__unique_modes__check_goal_2_5_0, "mode_info:call_context/0");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 1, mercury__unique_modes__check_goal_2_5_0, "hlds_pred:call_id/0");
	MR_field(MR_mktag(0), r3, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	r2 = MR_stackvar(8);
	call_localret(ENTRY(mercury__mode_info__mode_info_set_call_context_3_0),
		mercury__unique_modes__check_goal_2_5_0_i131,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i131);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r4 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(4);
	call_localret(STATIC(mercury__unique_modes__check_call_6_0),
		mercury__unique_modes__check_goal_2_5_0_i132,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i132);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r3 = MR_stackvar(2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 8, mercury__unique_modes__check_goal_2_5_0, "origin_lost_in_value_number");
	MR_stackvar(2) = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 3) = r1;
	r1 = r2;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 7) = MR_stackvar(7);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 5) = MR_stackvar(5);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 4) = MR_stackvar(4);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = r3;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 6;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 6) = MR_stackvar(6);
	call_localret(ENTRY(mercury__mode_info__mode_info_unset_call_context_2_0),
		mercury__unique_modes__check_goal_2_5_0_i133,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
	}
Define_label(mercury__unique_modes__check_goal_2_5_0_i133);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r3 = r1;
	r1 = (Integer) 1;
	r2 = (Word) MR_string_const("pragma_c_code", 13);
	call_localret(ENTRY(mercury__mode_debug__mode_checkpoint_4_0),
		mercury__unique_modes__check_goal_2_5_0_i143,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i135);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = (Integer) 0;
	r2 = (Word) MR_string_const("par_conj", 8);
	call_localret(ENTRY(mercury__mode_debug__mode_checkpoint_4_0),
		mercury__unique_modes__check_goal_2_5_0_i136,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i136);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_nonlocals_2_0),
		mercury__unique_modes__check_goal_2_5_0_i137,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i137);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__mode_info__mode_info_add_live_vars_3_0),
		mercury__unique_modes__check_goal_2_5_0_i138,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i138);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(2);
	call_localret(STATIC(mercury__unique_modes__make_par_conj_nonlocal_multiset_2_0),
		mercury__unique_modes__check_goal_2_5_0_i139,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i139);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	r3 = MR_stackvar(4);
	call_localret(STATIC(mercury__unique_modes__check_par_conj_6_0),
		mercury__unique_modes__check_goal_2_5_0_i1053,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i1053);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 3, mercury__unique_modes__check_goal_2_5_0, "origin_lost_in_value_number");
	MR_stackvar(2) = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r1;
	r1 = MR_stackvar(1);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_stackvar(3);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 7;
	call_localret(ENTRY(mercury__instmap__unify_4_0),
		mercury__unique_modes__check_goal_2_5_0_i141,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
	}
Define_label(mercury__unique_modes__check_goal_2_5_0_i141);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__mode_info__mode_info_remove_live_vars_3_0),
		mercury__unique_modes__check_goal_2_5_0_i142,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i142);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r3 = r1;
	r1 = (Integer) 1;
	r2 = (Word) MR_string_const("par_conj", 8);
	call_localret(ENTRY(mercury__mode_debug__mode_checkpoint_4_0),
		mercury__unique_modes__check_goal_2_5_0_i143,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i143);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	proceed();
Define_label(mercury__unique_modes__check_goal_2_5_0_i144);
	MR_stackvar(1) = r3;
	r1 = (Word) MR_string_const("unique_modes__check_goal_2: unexpected bi_implication", 53);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__unique_modes__check_goal_2_5_0_i145,
		STATIC(mercury__unique_modes__check_goal_2_5_0));
Define_label(mercury__unique_modes__check_goal_2_5_0_i145);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_goal_2_5_0));
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	proceed();
END_MODULE

Declare_entry(mercury__mode_info__mode_info_get_errors_2_0);
Declare_entry(mercury__mode_info__mode_info_set_errors_3_0);
Declare_entry(mercury__hlds_module__module_info_pred_proc_info_5_0);
Declare_entry(mercury__modes__compute_arg_offset_2_0);
Declare_entry(mercury__hlds_pred__proc_info_argmodes_2_0);
Declare_entry(mercury__hlds_pred__proc_info_interface_code_model_2_0);
Declare_entry(mercury__hlds_pred__proc_info_never_succeeds_2_0);
Declare_entry(mercury__mode_util__mode_list_get_initial_insts_3_0);
Declare_entry(mercury__modes__modecheck_var_has_inst_list_5_0);
Declare_entry(mercury__mode_util__mode_list_get_final_insts_3_0);
Declare_entry(mercury__modes__modecheck_set_var_inst_list_8_0);
Declare_entry(mercury____Unify___list__list_1_0);
Declare_entry(mercury__mode_info__mode_info_get_may_change_called_proc_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_mode_errors__type_ctor_info_mode_error_info_0;
Declare_entry(mercury__list__append_3_1);
Declare_entry(mercury__hlds_pred__proc_info_inferred_determinism_2_0);
Declare_entry(mercury__modecheck_call__modecheck_call_pred_9_0);

BEGIN_MODULE(unique_modes_module11)
	init_entry(mercury__unique_modes__check_call_6_0);
	init_label(mercury__unique_modes__check_call_6_0_i2);
	init_label(mercury__unique_modes__check_call_6_0_i3);
	init_label(mercury__unique_modes__check_call_6_0_i4);
	init_label(mercury__unique_modes__check_call_6_0_i5);
	init_label(mercury__unique_modes__check_call_6_0_i6);
	init_label(mercury__unique_modes__check_call_6_0_i7);
	init_label(mercury__unique_modes__check_call_6_0_i8);
	init_label(mercury__unique_modes__check_call_6_0_i9);
	init_label(mercury__unique_modes__check_call_6_0_i10);
	init_label(mercury__unique_modes__check_call_6_0_i11);
	init_label(mercury__unique_modes__check_call_6_0_i12);
	init_label(mercury__unique_modes__check_call_6_0_i13);
	init_label(mercury__unique_modes__check_call_6_0_i14);
	init_label(mercury__unique_modes__check_call_6_0_i15);
	init_label(mercury__unique_modes__check_call_6_0_i17);
	init_label(mercury__unique_modes__check_call_6_0_i16);
	init_label(mercury__unique_modes__check_call_6_0_i21);
	init_label(mercury__unique_modes__check_call_6_0_i24);
	init_label(mercury__unique_modes__check_call_6_0_i22);
	init_label(mercury__unique_modes__check_call_6_0_i28);
	init_label(mercury__unique_modes__check_call_6_0_i31);
	init_label(mercury__unique_modes__check_call_6_0_i33);
	init_label(mercury__unique_modes__check_call_6_0_i26);
	init_label(mercury__unique_modes__check_call_6_0_i37);
	init_label(mercury__unique_modes__check_call_6_0_i38);
	init_label(mercury__unique_modes__check_call_6_0_i39);
	init_label(mercury__unique_modes__check_call_6_0_i40);
	init_label(mercury__unique_modes__check_call_6_0_i41);
	init_label(mercury__unique_modes__check_call_6_0_i45);
	init_label(mercury__unique_modes__check_call_6_0_i46);
	init_label(mercury__unique_modes__check_call_6_0_i43);
	init_label(mercury__unique_modes__check_call_6_0_i47);
	init_label(mercury__unique_modes__check_call_6_0_i48);
	init_label(mercury__unique_modes__check_call_6_0_i49);
	init_label(mercury__unique_modes__check_call_6_0_i51);
	init_label(mercury__unique_modes__check_call_6_0_i1007);
	init_label(mercury__unique_modes__check_call_6_0_i50);
BEGIN_CODE

/* code for predicate 'check_call'/6 in mode 0 */
Define_static(mercury__unique_modes__check_call_6_0);
	MR_incr_sp_push_msg(13, "unique_modes:check_call/6");
	MR_stackvar(13) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r4;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	call_localret(ENTRY(mercury__mode_info__mode_info_get_errors_2_0),
		mercury__unique_modes__check_call_6_0_i2,
		STATIC(mercury__unique_modes__check_call_6_0));
Define_label(mercury__unique_modes__check_call_6_0_i2);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_call_6_0));
	MR_stackvar(6) = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__mode_info__mode_info_get_instmap_2_0),
		mercury__unique_modes__check_call_6_0_i3,
		STATIC(mercury__unique_modes__check_call_6_0));
Define_label(mercury__unique_modes__check_call_6_0_i3);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_call_6_0));
	MR_stackvar(7) = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__mode_info__mode_info_get_module_info_2_0),
		mercury__unique_modes__check_call_6_0_i4,
		STATIC(mercury__unique_modes__check_call_6_0));
Define_label(mercury__unique_modes__check_call_6_0_i4);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_call_6_0));
	r2 = MR_stackvar(4);
	MR_stackvar(4) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__mode_info__mode_info_set_errors_3_0),
		mercury__unique_modes__check_call_6_0_i5,
		STATIC(mercury__unique_modes__check_call_6_0));
Define_label(mercury__unique_modes__check_call_6_0_i5);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_call_6_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_stackvar(4);
	MR_stackvar(4) = MR_tempr1;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__hlds_module__module_info_pred_proc_info_5_0),
		mercury__unique_modes__check_call_6_0_i6,
		STATIC(mercury__unique_modes__check_call_6_0));
	}
Define_label(mercury__unique_modes__check_call_6_0_i6);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_call_6_0));
	MR_stackvar(8) = r2;
	call_localret(ENTRY(mercury__modes__compute_arg_offset_2_0),
		mercury__unique_modes__check_call_6_0_i7,
		STATIC(mercury__unique_modes__check_call_6_0));
Define_label(mercury__unique_modes__check_call_6_0_i7);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_call_6_0));
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(8);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_argmodes_2_0),
		mercury__unique_modes__check_call_6_0_i8,
		STATIC(mercury__unique_modes__check_call_6_0));
Define_label(mercury__unique_modes__check_call_6_0_i8);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_call_6_0));
	MR_stackvar(9) = r1;
	r1 = MR_stackvar(8);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_interface_code_model_2_0),
		mercury__unique_modes__check_call_6_0_i9,
		STATIC(mercury__unique_modes__check_call_6_0));
Define_label(mercury__unique_modes__check_call_6_0_i9);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_call_6_0));
	MR_stackvar(10) = r1;
	r1 = MR_stackvar(8);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_never_succeeds_2_0),
		mercury__unique_modes__check_call_6_0_i10,
		STATIC(mercury__unique_modes__check_call_6_0));
Define_label(mercury__unique_modes__check_call_6_0_i10);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_call_6_0));
	MR_stackvar(11) = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__mode_info__mode_info_get_module_info_2_0),
		mercury__unique_modes__check_call_6_0_i11,
		STATIC(mercury__unique_modes__check_call_6_0));
Define_label(mercury__unique_modes__check_call_6_0_i11);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_call_6_0));
	MR_stackvar(12) = r1;
	r2 = r1;
	r1 = MR_stackvar(9);
	call_localret(ENTRY(mercury__mode_util__mode_list_get_initial_insts_3_0),
		mercury__unique_modes__check_call_6_0_i12,
		STATIC(mercury__unique_modes__check_call_6_0));
Define_label(mercury__unique_modes__check_call_6_0_i12);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_call_6_0));
	r4 = MR_stackvar(4);
	r2 = r1;
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(3);
	r3 = MR_stackvar(5);
	call_localret(ENTRY(mercury__modes__modecheck_var_has_inst_list_5_0),
		mercury__unique_modes__check_call_6_0_i13,
		STATIC(mercury__unique_modes__check_call_6_0));
Define_label(mercury__unique_modes__check_call_6_0_i13);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_call_6_0));
	r3 = r1;
	r1 = MR_stackvar(9);
	MR_stackvar(9) = r3;
	r2 = MR_stackvar(12);
	call_localret(ENTRY(mercury__mode_util__mode_list_get_final_insts_3_0),
		mercury__unique_modes__check_call_6_0_i14,
		STATIC(mercury__unique_modes__check_call_6_0));
Define_label(mercury__unique_modes__check_call_6_0_i14);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_call_6_0));
	r3 = r1;
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(4);
	r4 = MR_stackvar(5);
	r5 = MR_stackvar(9);
	call_localret(ENTRY(mercury__modes__modecheck_set_var_inst_list_8_0),
		mercury__unique_modes__check_call_6_0_i15,
		STATIC(mercury__unique_modes__check_call_6_0));
Define_label(mercury__unique_modes__check_call_6_0_i15);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_call_6_0));
	MR_stackvar(4) = r2;
	r2 = r1;
	MR_stackvar(12) = r3;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unique_modes__common_0);
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury__unique_modes__check_call_6_0_i17,
		STATIC(mercury__unique_modes__check_call_6_0));
Define_label(mercury__unique_modes__check_call_6_0_i17);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_call_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__unique_modes__check_call_6_0_i16);
	if (((Integer) MR_stackvar(4) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unique_modes__check_call_6_0_i21);
Define_label(mercury__unique_modes__check_call_6_0_i16);
	r1 = (Word) MR_string_const("unique_modes.m: call to implied mode?", 37);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__unique_modes__check_call_6_0_i21,
		STATIC(mercury__unique_modes__check_call_6_0));
Define_label(mercury__unique_modes__check_call_6_0_i21);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_call_6_0));
	if (((Integer) MR_stackvar(11) != (Integer) 1))
		GOTO_LABEL(mercury__unique_modes__check_call_6_0_i22);
	call_localret(ENTRY(mercury__instmap__init_unreachable_1_0),
		mercury__unique_modes__check_call_6_0_i24,
		STATIC(mercury__unique_modes__check_call_6_0));
Define_label(mercury__unique_modes__check_call_6_0_i24);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_call_6_0));
	r2 = MR_stackvar(12);
	call_localret(ENTRY(mercury__mode_info__mode_info_set_instmap_3_0),
		mercury__unique_modes__check_call_6_0_i37,
		STATIC(mercury__unique_modes__check_call_6_0));
Define_label(mercury__unique_modes__check_call_6_0_i22);
	if (((Integer) MR_stackvar(10) != (Integer) 2))
		GOTO_LABEL(mercury__unique_modes__check_call_6_0_i26);
	r1 = MR_stackvar(12);
	call_localret(ENTRY(mercury__mode_info__mode_info_get_instmap_2_0),
		mercury__unique_modes__check_call_6_0_i28,
		STATIC(mercury__unique_modes__check_call_6_0));
Define_label(mercury__unique_modes__check_call_6_0_i28);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_call_6_0));
	MR_stackvar(4) = r1;
	call_localret(ENTRY(mercury__instmap__is_reachable_1_0),
		mercury__unique_modes__check_call_6_0_i31,
		STATIC(mercury__unique_modes__check_call_6_0));
Define_label(mercury__unique_modes__check_call_6_0_i31);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_call_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__unique_modes__check_call_6_0_i26);
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__instmap__vars_list_2_0),
		mercury__unique_modes__check_call_6_0_i33,
		STATIC(mercury__unique_modes__check_call_6_0));
Define_label(mercury__unique_modes__check_call_6_0_i33);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_call_6_0));
	r2 = r1;
	r1 = MR_stackvar(12);
	call_localret(STATIC(mercury__unique_modes__DeforestationIn__pred__make_all_nondet_live_vars_mostly_uniq__176__0_3_0),
		mercury__unique_modes__check_call_6_0_i37,
		STATIC(mercury__unique_modes__check_call_6_0));
Define_label(mercury__unique_modes__check_call_6_0_i26);
	r1 = MR_stackvar(12);
Define_label(mercury__unique_modes__check_call_6_0_i37);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_call_6_0));
	MR_stackvar(4) = r1;
	call_localret(ENTRY(mercury__mode_info__mode_info_get_errors_2_0),
		mercury__unique_modes__check_call_6_0_i38,
		STATIC(mercury__unique_modes__check_call_6_0));
Define_label(mercury__unique_modes__check_call_6_0_i38);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_call_6_0));
	r2 = MR_stackvar(4);
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__mode_info__mode_info_set_errors_3_0),
		mercury__unique_modes__check_call_6_0_i39,
		STATIC(mercury__unique_modes__check_call_6_0));
Define_label(mercury__unique_modes__check_call_6_0_i39);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_call_6_0));
	MR_stackvar(5) = r1;
	call_localret(ENTRY(mercury__mode_info__mode_info_get_may_change_called_proc_2_0),
		mercury__unique_modes__check_call_6_0_i40,
		STATIC(mercury__unique_modes__check_call_6_0));
Define_label(mercury__unique_modes__check_call_6_0_i40);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_call_6_0));
	if (((Integer) MR_stackvar(4) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unique_modes__check_call_6_0_i41);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	proceed();
Define_label(mercury__unique_modes__check_call_6_0_i41);
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__unique_modes__check_call_6_0_i43);
	r3 = MR_stackvar(4);
	r1 = (Word) (Word *) &mercury_data_mode_errors__type_ctor_info_mode_error_info_0;
	r2 = MR_stackvar(6);
	MR_stackvar(4) = MR_stackvar(2);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__unique_modes__check_call_6_0_i45,
		STATIC(mercury__unique_modes__check_call_6_0));
Define_label(mercury__unique_modes__check_call_6_0_i45);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_call_6_0));
	r2 = MR_stackvar(5);
	call_localret(ENTRY(mercury__mode_info__mode_info_set_errors_3_0),
		mercury__unique_modes__check_call_6_0_i46,
		STATIC(mercury__unique_modes__check_call_6_0));
Define_label(mercury__unique_modes__check_call_6_0_i46);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_call_6_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	proceed();
Define_label(mercury__unique_modes__check_call_6_0_i43);
	r1 = MR_stackvar(7);
	r2 = MR_stackvar(5);
	call_localret(ENTRY(mercury__mode_info__mode_info_set_instmap_3_0),
		mercury__unique_modes__check_call_6_0_i47,
		STATIC(mercury__unique_modes__check_call_6_0));
Define_label(mercury__unique_modes__check_call_6_0_i47);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_call_6_0));
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(8);
	call_localret(ENTRY(mercury__hlds_pred__proc_info_inferred_determinism_2_0),
		mercury__unique_modes__check_call_6_0_i48,
		STATIC(mercury__unique_modes__check_call_6_0));
Define_label(mercury__unique_modes__check_call_6_0_i48);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_call_6_0));
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 1, mercury__unique_modes__check_call_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r4, (Integer) 0) = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r5 = MR_stackvar(4);
	call_localret(ENTRY(mercury__modecheck_call__modecheck_call_pred_9_0),
		mercury__unique_modes__check_call_6_0_i49,
		STATIC(mercury__unique_modes__check_call_6_0));
Define_label(mercury__unique_modes__check_call_6_0_i49);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_call_6_0));
	MR_stackvar(4) = r1;
	MR_stackvar(9) = r3;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unique_modes__common_0);
	r3 = MR_stackvar(3);
	MR_stackvar(5) = r4;
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury__unique_modes__check_call_6_0_i51,
		STATIC(mercury__unique_modes__check_call_6_0));
Define_label(mercury__unique_modes__check_call_6_0_i51);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_call_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__unique_modes__check_call_6_0_i50);
	if (((Integer) MR_stackvar(9) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unique_modes__check_call_6_0_i50);
Define_label(mercury__unique_modes__check_call_6_0_i1007);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_call_6_0));
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	proceed();
Define_label(mercury__unique_modes__check_call_6_0_i50);
	r1 = (Word) MR_string_const("unique_modes.m: call to implied mode?", 37);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__unique_modes__check_call_6_0_i1007,
		STATIC(mercury__unique_modes__check_call_6_0));
END_MODULE


BEGIN_MODULE(unique_modes_module12)
	init_entry(mercury__unique_modes__check_call_modes_7_0);
	init_label(mercury__unique_modes__check_call_modes_7_0_i2);
	init_label(mercury__unique_modes__check_call_modes_7_0_i3);
	init_label(mercury__unique_modes__check_call_modes_7_0_i4);
	init_label(mercury__unique_modes__check_call_modes_7_0_i5);
	init_label(mercury__unique_modes__check_call_modes_7_0_i6);
	init_label(mercury__unique_modes__check_call_modes_7_0_i8);
	init_label(mercury__unique_modes__check_call_modes_7_0_i7);
	init_label(mercury__unique_modes__check_call_modes_7_0_i12);
	init_label(mercury__unique_modes__check_call_modes_7_0_i15);
	init_label(mercury__unique_modes__check_call_modes_7_0_i13);
	init_label(mercury__unique_modes__check_call_modes_7_0_i19);
	init_label(mercury__unique_modes__check_call_modes_7_0_i22);
	init_label(mercury__unique_modes__check_call_modes_7_0_i24);
	init_label(mercury__unique_modes__check_call_modes_7_0_i17);
BEGIN_CODE

/* code for predicate 'check_call_modes'/7 in mode 0 */
Define_static(mercury__unique_modes__check_call_modes_7_0);
	MR_incr_sp_push_msg(8, "unique_modes:check_call_modes/7");
	MR_stackvar(8) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = r6;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r5;
	MR_stackvar(6) = r6;
	call_localret(ENTRY(mercury__mode_info__mode_info_get_module_info_2_0),
		mercury__unique_modes__check_call_modes_7_0_i2,
		STATIC(mercury__unique_modes__check_call_modes_7_0));
Define_label(mercury__unique_modes__check_call_modes_7_0_i2);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_call_modes_7_0));
	MR_stackvar(7) = r1;
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__mode_util__mode_list_get_initial_insts_3_0),
		mercury__unique_modes__check_call_modes_7_0_i3,
		STATIC(mercury__unique_modes__check_call_modes_7_0));
Define_label(mercury__unique_modes__check_call_modes_7_0_i3);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_call_modes_7_0));
	r4 = MR_stackvar(6);
	r2 = r1;
	MR_stackvar(6) = r1;
	r1 = MR_stackvar(1);
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury__modes__modecheck_var_has_inst_list_5_0),
		mercury__unique_modes__check_call_modes_7_0_i4,
		STATIC(mercury__unique_modes__check_call_modes_7_0));
Define_label(mercury__unique_modes__check_call_modes_7_0_i4);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_call_modes_7_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r3;
	r2 = MR_stackvar(7);
	call_localret(ENTRY(mercury__mode_util__mode_list_get_final_insts_3_0),
		mercury__unique_modes__check_call_modes_7_0_i5,
		STATIC(mercury__unique_modes__check_call_modes_7_0));
Define_label(mercury__unique_modes__check_call_modes_7_0_i5);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_call_modes_7_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(6);
	r4 = MR_stackvar(3);
	r5 = MR_stackvar(2);
	call_localret(ENTRY(mercury__modes__modecheck_set_var_inst_list_8_0),
		mercury__unique_modes__check_call_modes_7_0_i6,
		STATIC(mercury__unique_modes__check_call_modes_7_0));
Define_label(mercury__unique_modes__check_call_modes_7_0_i6);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_call_modes_7_0));
	MR_stackvar(2) = r3;
	r3 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unique_modes__common_0);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury__unique_modes__check_call_modes_7_0_i8,
		STATIC(mercury__unique_modes__check_call_modes_7_0));
Define_label(mercury__unique_modes__check_call_modes_7_0_i8);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_call_modes_7_0));
	if (!(r1))
		GOTO_LABEL(mercury__unique_modes__check_call_modes_7_0_i7);
	if (((Integer) MR_stackvar(1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unique_modes__check_call_modes_7_0_i12);
Define_label(mercury__unique_modes__check_call_modes_7_0_i7);
	r1 = (Word) MR_string_const("unique_modes.m: call to implied mode?", 37);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__unique_modes__check_call_modes_7_0_i12,
		STATIC(mercury__unique_modes__check_call_modes_7_0));
Define_label(mercury__unique_modes__check_call_modes_7_0_i12);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_call_modes_7_0));
	if (((Integer) MR_stackvar(5) != (Integer) 1))
		GOTO_LABEL(mercury__unique_modes__check_call_modes_7_0_i13);
	call_localret(ENTRY(mercury__instmap__init_unreachable_1_0),
		mercury__unique_modes__check_call_modes_7_0_i15,
		STATIC(mercury__unique_modes__check_call_modes_7_0));
Define_label(mercury__unique_modes__check_call_modes_7_0_i15);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_call_modes_7_0));
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	tailcall(ENTRY(mercury__mode_info__mode_info_set_instmap_3_0),
		STATIC(mercury__unique_modes__check_call_modes_7_0));
Define_label(mercury__unique_modes__check_call_modes_7_0_i13);
	if (((Integer) MR_stackvar(4) != (Integer) 2))
		GOTO_LABEL(mercury__unique_modes__check_call_modes_7_0_i17);
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__mode_info__mode_info_get_instmap_2_0),
		mercury__unique_modes__check_call_modes_7_0_i19,
		STATIC(mercury__unique_modes__check_call_modes_7_0));
Define_label(mercury__unique_modes__check_call_modes_7_0_i19);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_call_modes_7_0));
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__instmap__is_reachable_1_0),
		mercury__unique_modes__check_call_modes_7_0_i22,
		STATIC(mercury__unique_modes__check_call_modes_7_0));
Define_label(mercury__unique_modes__check_call_modes_7_0_i22);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_call_modes_7_0));
	if (!(r1))
		GOTO_LABEL(mercury__unique_modes__check_call_modes_7_0_i17);
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__instmap__vars_list_2_0),
		mercury__unique_modes__check_call_modes_7_0_i24,
		STATIC(mercury__unique_modes__check_call_modes_7_0));
Define_label(mercury__unique_modes__check_call_modes_7_0_i24);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_call_modes_7_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	tailcall(STATIC(mercury__unique_modes__DeforestationIn__pred__make_all_nondet_live_vars_mostly_uniq__176__0_3_0),
		STATIC(mercury__unique_modes__check_call_modes_7_0));
Define_label(mercury__unique_modes__check_call_modes_7_0_i17);
	r1 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
END_MODULE

Declare_entry(mercury__instmap__is_unreachable_1_0);
Declare_entry(mercury__modes__mode_info_remove_goals_live_vars_3_0);

BEGIN_MODULE(unique_modes_module13)
	init_entry(mercury__unique_modes__check_conj_4_0);
	init_label(mercury__unique_modes__check_conj_4_0_i3);
	init_label(mercury__unique_modes__check_conj_4_0_i4);
	init_label(mercury__unique_modes__check_conj_4_0_i5);
	init_label(mercury__unique_modes__check_conj_4_0_i6);
	init_label(mercury__unique_modes__check_conj_4_0_i7);
	init_label(mercury__unique_modes__check_conj_4_0_i10);
	init_label(mercury__unique_modes__check_conj_4_0_i12);
	init_label(mercury__unique_modes__check_conj_4_0_i8);
	init_label(mercury__unique_modes__check_conj_4_0_i13);
BEGIN_CODE

/* code for predicate 'check_conj'/4 in mode 0 */
Define_static(mercury__unique_modes__check_conj_4_0);
	MR_incr_sp_push_msg(4, "unique_modes:check_conj/4");
	MR_stackvar(4) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unique_modes__check_conj_4_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__unique_modes__check_conj_4_0_i3);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(2) = r3;
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_nonlocals_2_0),
		mercury__unique_modes__check_conj_4_0_i4,
		STATIC(mercury__unique_modes__check_conj_4_0));
Define_label(mercury__unique_modes__check_conj_4_0_i4);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_conj_4_0));
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__mode_info__mode_info_remove_live_vars_3_0),
		mercury__unique_modes__check_conj_4_0_i5,
		STATIC(mercury__unique_modes__check_conj_4_0));
Define_label(mercury__unique_modes__check_conj_4_0_i5);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_conj_4_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(STATIC(mercury__unique_modes__check_goal_4_0),
		mercury__unique_modes__check_conj_4_0_i6,
		STATIC(mercury__unique_modes__check_conj_4_0));
Define_label(mercury__unique_modes__check_conj_4_0_i6);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_conj_4_0));
	MR_stackvar(1) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__mode_info__mode_info_dcg_get_instmap_3_0),
		mercury__unique_modes__check_conj_4_0_i7,
		STATIC(mercury__unique_modes__check_conj_4_0));
Define_label(mercury__unique_modes__check_conj_4_0_i7);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_conj_4_0));
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__instmap__is_unreachable_1_0),
		mercury__unique_modes__check_conj_4_0_i10,
		STATIC(mercury__unique_modes__check_conj_4_0));
Define_label(mercury__unique_modes__check_conj_4_0_i10);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_conj_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__unique_modes__check_conj_4_0_i8);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__modes__mode_info_remove_goals_live_vars_3_0),
		mercury__unique_modes__check_conj_4_0_i12,
		STATIC(mercury__unique_modes__check_conj_4_0));
Define_label(mercury__unique_modes__check_conj_4_0_i12);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_conj_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__unique_modes__check_conj_4_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__unique_modes__check_conj_4_0_i8);
	r2 = MR_stackvar(2);
	r1 = MR_stackvar(3);
	localcall(mercury__unique_modes__check_conj_4_0,
		LABEL(mercury__unique_modes__check_conj_4_0_i13),
		STATIC(mercury__unique_modes__check_conj_4_0));
Define_label(mercury__unique_modes__check_conj_4_0_i13);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_conj_4_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__unique_modes__check_conj_4_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE

Declare_entry(mercury__bag__from_list_2_0);
Declare_entry(mercury__bag__union_3_0);
Declare_entry(mercury__bag__init_1_0);

BEGIN_MODULE(unique_modes_module14)
	init_entry(mercury__unique_modes__make_par_conj_nonlocal_multiset_2_0);
	init_label(mercury__unique_modes__make_par_conj_nonlocal_multiset_2_0_i4);
	init_label(mercury__unique_modes__make_par_conj_nonlocal_multiset_2_0_i5);
	init_label(mercury__unique_modes__make_par_conj_nonlocal_multiset_2_0_i6);
	init_label(mercury__unique_modes__make_par_conj_nonlocal_multiset_2_0_i7);
	init_label(mercury__unique_modes__make_par_conj_nonlocal_multiset_2_0_i3);
BEGIN_CODE

/* code for predicate 'make_par_conj_nonlocal_multiset'/2 in mode 0 */
Define_static(mercury__unique_modes__make_par_conj_nonlocal_multiset_2_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unique_modes__make_par_conj_nonlocal_multiset_2_0_i3);
	MR_incr_sp_push_msg(2, "unique_modes:make_par_conj_nonlocal_multiset/2");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	localcall(mercury__unique_modes__make_par_conj_nonlocal_multiset_2_0,
		LABEL(mercury__unique_modes__make_par_conj_nonlocal_multiset_2_0_i4),
		STATIC(mercury__unique_modes__make_par_conj_nonlocal_multiset_2_0));
Define_label(mercury__unique_modes__make_par_conj_nonlocal_multiset_2_0_i4);
	update_prof_current_proc(LABEL(mercury__unique_modes__make_par_conj_nonlocal_multiset_2_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r3 = r1;
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_nonlocals_2_0),
		mercury__unique_modes__make_par_conj_nonlocal_multiset_2_0_i5,
		STATIC(mercury__unique_modes__make_par_conj_nonlocal_multiset_2_0));
Define_label(mercury__unique_modes__make_par_conj_nonlocal_multiset_2_0_i5);
	update_prof_current_proc(LABEL(mercury__unique_modes__make_par_conj_nonlocal_multiset_2_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unique_modes__common_0);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__unique_modes__make_par_conj_nonlocal_multiset_2_0_i6,
		STATIC(mercury__unique_modes__make_par_conj_nonlocal_multiset_2_0));
Define_label(mercury__unique_modes__make_par_conj_nonlocal_multiset_2_0_i6);
	update_prof_current_proc(LABEL(mercury__unique_modes__make_par_conj_nonlocal_multiset_2_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unique_modes__common_0);
	call_localret(ENTRY(mercury__bag__from_list_2_0),
		mercury__unique_modes__make_par_conj_nonlocal_multiset_2_0_i7,
		STATIC(mercury__unique_modes__make_par_conj_nonlocal_multiset_2_0));
Define_label(mercury__unique_modes__make_par_conj_nonlocal_multiset_2_0_i7);
	update_prof_current_proc(LABEL(mercury__unique_modes__make_par_conj_nonlocal_multiset_2_0));
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unique_modes__common_0);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__bag__union_3_0),
		STATIC(mercury__unique_modes__make_par_conj_nonlocal_multiset_2_0));
Define_label(mercury__unique_modes__make_par_conj_nonlocal_multiset_2_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unique_modes__common_0);
	tailcall(ENTRY(mercury__bag__init_1_0),
		STATIC(mercury__unique_modes__make_par_conj_nonlocal_multiset_2_0));
END_MODULE

Declare_entry(mercury__bag__to_assoc_list_2_0);
Declare_entry(mercury__list__filter_map_3_0);
Declare_entry(mercury__instmap__lookup_vars_3_0);
Declare_entry(mercury__inst_util__make_shared_inst_list_4_0);
Declare_entry(mercury__instmap__set_vars_4_0);

BEGIN_MODULE(unique_modes_module15)
	init_entry(mercury__unique_modes__check_par_conj_6_0);
	init_label(mercury__unique_modes__check_par_conj_6_0_i2);
	init_label(mercury__unique_modes__check_par_conj_6_0_i3);
	init_label(mercury__unique_modes__check_par_conj_6_0_i4);
	init_label(mercury__unique_modes__check_par_conj_6_0_i5);
	init_label(mercury__unique_modes__check_par_conj_6_0_i6);
	init_label(mercury__unique_modes__check_par_conj_6_0_i7);
	init_label(mercury__unique_modes__check_par_conj_6_0_i8);
	init_label(mercury__unique_modes__check_par_conj_6_0_i9);
	init_label(mercury__unique_modes__check_par_conj_6_0_i10);
BEGIN_CODE

/* code for predicate 'check_par_conj'/6 in mode 0 */
Define_static(mercury__unique_modes__check_par_conj_6_0);
	MR_incr_sp_push_msg(6, "unique_modes:check_par_conj/6");
	MR_stackvar(6) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unique_modes__common_0);
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__bag__to_assoc_list_2_0),
		mercury__unique_modes__check_par_conj_6_0_i2,
		STATIC(mercury__unique_modes__check_par_conj_6_0));
Define_label(mercury__unique_modes__check_par_conj_6_0_i2);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_par_conj_6_0));
	r4 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unique_modes__common_2);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unique_modes__common_0);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_unique_modes__common_4);
	call_localret(ENTRY(mercury__list__filter_map_3_0),
		mercury__unique_modes__check_par_conj_6_0_i3,
		STATIC(mercury__unique_modes__check_par_conj_6_0));
Define_label(mercury__unique_modes__check_par_conj_6_0_i3);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_par_conj_6_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__mode_info__mode_info_dcg_get_instmap_3_0),
		mercury__unique_modes__check_par_conj_6_0_i4,
		STATIC(mercury__unique_modes__check_par_conj_6_0));
Define_label(mercury__unique_modes__check_par_conj_6_0_i4);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_par_conj_6_0));
	MR_stackvar(4) = r2;
	r2 = r1;
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__instmap__lookup_vars_3_0),
		mercury__unique_modes__check_par_conj_6_0_i5,
		STATIC(mercury__unique_modes__check_par_conj_6_0));
Define_label(mercury__unique_modes__check_par_conj_6_0_i5);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_par_conj_6_0));
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__mode_info__mode_info_get_module_info_2_0),
		mercury__unique_modes__check_par_conj_6_0_i6,
		STATIC(mercury__unique_modes__check_par_conj_6_0));
Define_label(mercury__unique_modes__check_par_conj_6_0_i6);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_par_conj_6_0));
	r2 = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__inst_util__make_shared_inst_list_4_0),
		mercury__unique_modes__check_par_conj_6_0_i7,
		STATIC(mercury__unique_modes__check_par_conj_6_0));
Define_label(mercury__unique_modes__check_par_conj_6_0_i7);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_par_conj_6_0));
	r3 = r1;
	r1 = MR_stackvar(4);
	MR_stackvar(4) = r3;
	call_localret(ENTRY(mercury__mode_info__mode_info_set_module_info_3_0),
		mercury__unique_modes__check_par_conj_6_0_i8,
		STATIC(mercury__unique_modes__check_par_conj_6_0));
Define_label(mercury__unique_modes__check_par_conj_6_0_i8);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_par_conj_6_0));
	r2 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(3);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__instmap__set_vars_4_0),
		mercury__unique_modes__check_par_conj_6_0_i9,
		STATIC(mercury__unique_modes__check_par_conj_6_0));
Define_label(mercury__unique_modes__check_par_conj_6_0_i9);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_par_conj_6_0));
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__mode_info__mode_info_set_instmap_3_0),
		mercury__unique_modes__check_par_conj_6_0_i10,
		STATIC(mercury__unique_modes__check_par_conj_6_0));
Define_label(mercury__unique_modes__check_par_conj_6_0_i10);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_par_conj_6_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(STATIC(mercury__unique_modes__check_par_conj_1_5_0),
		STATIC(mercury__unique_modes__check_par_conj_6_0));
END_MODULE


BEGIN_MODULE(unique_modes_module16)
	init_entry(mercury__unique_modes__check_par_conj_1_5_0);
	init_label(mercury__unique_modes__check_par_conj_1_5_0_i4);
	init_label(mercury__unique_modes__check_par_conj_1_5_0_i5);
	init_label(mercury__unique_modes__check_par_conj_1_5_0_i6);
	init_label(mercury__unique_modes__check_par_conj_1_5_0_i7);
	init_label(mercury__unique_modes__check_par_conj_1_5_0_i8);
	init_label(mercury__unique_modes__check_par_conj_1_5_0_i9);
	init_label(mercury__unique_modes__check_par_conj_1_5_0_i3);
BEGIN_CODE

/* code for predicate 'check_par_conj_1'/5 in mode 0 */
Define_static(mercury__unique_modes__check_par_conj_1_5_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unique_modes__check_par_conj_1_5_0_i3);
	MR_incr_sp_push_msg(5, "unique_modes:check_par_conj_1/5");
	MR_stackvar(5) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(2) = r3;
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_nonlocals_2_0),
		mercury__unique_modes__check_par_conj_1_5_0_i4,
		STATIC(mercury__unique_modes__check_par_conj_1_5_0));
Define_label(mercury__unique_modes__check_par_conj_1_5_0_i4);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_par_conj_1_5_0));
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__mode_info__mode_info_dcg_get_instmap_3_0),
		mercury__unique_modes__check_par_conj_1_5_0_i5,
		STATIC(mercury__unique_modes__check_par_conj_1_5_0));
Define_label(mercury__unique_modes__check_par_conj_1_5_0_i5);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_par_conj_1_5_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r3;
	call_localret(STATIC(mercury__unique_modes__check_goal_4_0),
		mercury__unique_modes__check_par_conj_1_5_0_i6,
		STATIC(mercury__unique_modes__check_par_conj_1_5_0));
Define_label(mercury__unique_modes__check_par_conj_1_5_0_i6);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_par_conj_1_5_0));
	MR_stackvar(1) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__mode_info__mode_info_dcg_get_instmap_3_0),
		mercury__unique_modes__check_par_conj_1_5_0_i7,
		STATIC(mercury__unique_modes__check_par_conj_1_5_0));
Define_label(mercury__unique_modes__check_par_conj_1_5_0_i7);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_par_conj_1_5_0));
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__unique_modes__check_par_conj_1_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 0) = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r3;
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(4);
	call_localret(ENTRY(mercury__mode_info__mode_info_set_instmap_3_0),
		mercury__unique_modes__check_par_conj_1_5_0_i8,
		STATIC(mercury__unique_modes__check_par_conj_1_5_0));
Define_label(mercury__unique_modes__check_par_conj_1_5_0_i8);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_par_conj_1_5_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	localcall(mercury__unique_modes__check_par_conj_1_5_0,
		LABEL(mercury__unique_modes__check_par_conj_1_5_0_i9),
		STATIC(mercury__unique_modes__check_par_conj_1_5_0));
Define_label(mercury__unique_modes__check_par_conj_1_5_0_i9);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_par_conj_1_5_0));
	r4 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__unique_modes__check_par_conj_1_5_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r4;
	r5 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__unique_modes__check_par_conj_1_5_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), r2, (Integer) 1) = r5;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__unique_modes__check_par_conj_1_5_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r3 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE

Declare_entry(mercury__hlds_goal__goal_info_get_determinism_2_0);

BEGIN_MODULE(unique_modes_module17)
	init_entry(mercury__unique_modes__check_disj_7_0);
	init_label(mercury__unique_modes__check_disj_7_0_i4);
	init_label(mercury__unique_modes__check_disj_7_0_i9);
	init_label(mercury__unique_modes__check_disj_7_0_i10);
	init_label(mercury__unique_modes__check_disj_7_0_i12);
	init_label(mercury__unique_modes__check_disj_7_0_i13);
	init_label(mercury__unique_modes__check_disj_7_0_i16);
	init_label(mercury__unique_modes__check_disj_7_0_i18);
	init_label(mercury__unique_modes__check_disj_7_0_i19);
	init_label(mercury__unique_modes__check_disj_7_0_i15);
	init_label(mercury__unique_modes__check_disj_7_0_i20);
	init_label(mercury__unique_modes__check_disj_7_0_i21);
	init_label(mercury__unique_modes__check_disj_7_0_i5);
	init_label(mercury__unique_modes__check_disj_7_0_i6);
	init_label(mercury__unique_modes__check_disj_7_0_i23);
	init_label(mercury__unique_modes__check_disj_7_0_i24);
	init_label(mercury__unique_modes__check_disj_7_0_i25);
	init_label(mercury__unique_modes__check_disj_7_0_i26);
	init_label(mercury__unique_modes__check_disj_7_0_i3);
BEGIN_CODE

/* code for predicate 'check_disj'/7 in mode 0 */
Define_static(mercury__unique_modes__check_disj_7_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unique_modes__check_disj_7_0_i3);
	MR_incr_sp_push_msg(10, "unique_modes:check_disj/7");
	MR_stackvar(10) = (Word) MR_succip;
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = r4;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__mode_info__mode_info_dcg_get_instmap_3_0),
		mercury__unique_modes__check_disj_7_0_i4,
		STATIC(mercury__unique_modes__check_disj_7_0));
Define_label(mercury__unique_modes__check_disj_7_0_i4);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_disj_7_0));
	if (((Integer) MR_stackvar(1) == (Integer) 2))
		GOTO_LABEL(mercury__unique_modes__check_disj_7_0_i6);
	MR_stackvar(7) = r1;
	r1 = MR_const_field(MR_mktag(0), MR_stackvar(3), (Integer) 1);
	MR_stackvar(8) = r2;
	call_localret(ENTRY(mercury__hlds_goal__goal_info_get_determinism_2_0),
		mercury__unique_modes__check_disj_7_0_i9,
		STATIC(mercury__unique_modes__check_disj_7_0));
Define_label(mercury__unique_modes__check_disj_7_0_i9);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_disj_7_0));
	call_localret(ENTRY(mercury__hlds_data__determinism_components_3_0),
		mercury__unique_modes__check_disj_7_0_i10,
		STATIC(mercury__unique_modes__check_disj_7_0));
Define_label(mercury__unique_modes__check_disj_7_0_i10);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_disj_7_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__unique_modes__check_disj_7_0_i5);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(8);
	call_localret(ENTRY(mercury__mode_info__mode_info_add_live_vars_3_0),
		mercury__unique_modes__check_disj_7_0_i12,
		STATIC(mercury__unique_modes__check_disj_7_0));
Define_label(mercury__unique_modes__check_disj_7_0_i12);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_disj_7_0));
	MR_stackvar(9) = r1;
	call_localret(ENTRY(mercury__mode_info__mode_info_get_instmap_2_0),
		mercury__unique_modes__check_disj_7_0_i13,
		STATIC(mercury__unique_modes__check_disj_7_0));
Define_label(mercury__unique_modes__check_disj_7_0_i13);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_disj_7_0));
	MR_stackvar(5) = r1;
	call_localret(ENTRY(mercury__instmap__is_reachable_1_0),
		mercury__unique_modes__check_disj_7_0_i16,
		STATIC(mercury__unique_modes__check_disj_7_0));
Define_label(mercury__unique_modes__check_disj_7_0_i16);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_disj_7_0));
	if (!(r1))
		GOTO_LABEL(mercury__unique_modes__check_disj_7_0_i15);
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__instmap__vars_list_2_0),
		mercury__unique_modes__check_disj_7_0_i18,
		STATIC(mercury__unique_modes__check_disj_7_0));
Define_label(mercury__unique_modes__check_disj_7_0_i18);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_disj_7_0));
	r2 = r1;
	r1 = MR_stackvar(9);
	call_localret(STATIC(mercury__unique_modes__DeforestationIn__pred__make_all_nondet_live_vars_mostly_uniq__176__0_3_0),
		mercury__unique_modes__check_disj_7_0_i19,
		STATIC(mercury__unique_modes__check_disj_7_0));
Define_label(mercury__unique_modes__check_disj_7_0_i19);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_disj_7_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	GOTO_LABEL(mercury__unique_modes__check_disj_7_0_i20);
Define_label(mercury__unique_modes__check_disj_7_0_i15);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(9);
Define_label(mercury__unique_modes__check_disj_7_0_i20);
	MR_stackvar(2) = r1;
	call_localret(ENTRY(mercury__mode_info__mode_info_remove_live_vars_3_0),
		mercury__unique_modes__check_disj_7_0_i21,
		STATIC(mercury__unique_modes__check_disj_7_0));
Define_label(mercury__unique_modes__check_disj_7_0_i21);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_disj_7_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	call_localret(STATIC(mercury__unique_modes__check_goal_4_0),
		mercury__unique_modes__check_disj_7_0_i23,
		STATIC(mercury__unique_modes__check_disj_7_0));
Define_label(mercury__unique_modes__check_disj_7_0_i5);
	r1 = MR_stackvar(7);
	r2 = MR_stackvar(8);
Define_label(mercury__unique_modes__check_disj_7_0_i6);
	MR_stackvar(7) = r1;
	r1 = MR_stackvar(3);
	call_localret(STATIC(mercury__unique_modes__check_goal_4_0),
		mercury__unique_modes__check_disj_7_0_i23,
		STATIC(mercury__unique_modes__check_disj_7_0));
Define_label(mercury__unique_modes__check_disj_7_0_i23);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_disj_7_0));
	MR_stackvar(5) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__mode_info__mode_info_dcg_get_instmap_3_0),
		mercury__unique_modes__check_disj_7_0_i24,
		STATIC(mercury__unique_modes__check_disj_7_0));
Define_label(mercury__unique_modes__check_disj_7_0_i24);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_disj_7_0));
	MR_stackvar(6) = r1;
	r1 = MR_stackvar(7);
	call_localret(ENTRY(mercury__mode_info__mode_info_set_instmap_3_0),
		mercury__unique_modes__check_disj_7_0_i25,
		STATIC(mercury__unique_modes__check_disj_7_0));
Define_label(mercury__unique_modes__check_disj_7_0_i25);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_disj_7_0));
	r4 = r1;
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	localcall(mercury__unique_modes__check_disj_7_0,
		LABEL(mercury__unique_modes__check_disj_7_0_i26),
		STATIC(mercury__unique_modes__check_disj_7_0));
Define_label(mercury__unique_modes__check_disj_7_0_i26);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_disj_7_0));
	r5 = r2;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__unique_modes__check_disj_7_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = r1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(5);
	r1 = MR_tempr1;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__unique_modes__check_disj_7_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(6);
	MR_field(MR_mktag(1), r2, (Integer) 1) = r5;
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
	}
Define_label(mercury__unique_modes__check_disj_7_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r3 = r4;
	proceed();
END_MODULE

Declare_entry(mercury__modes__modecheck_functor_test_4_0);
Declare_entry(mercury__mode_util__fixup_switch_var_5_0);

BEGIN_MODULE(unique_modes_module18)
	init_entry(mercury__unique_modes__check_case_list_6_0);
	init_label(mercury__unique_modes__check_case_list_6_0_i4);
	init_label(mercury__unique_modes__check_case_list_6_0_i5);
	init_label(mercury__unique_modes__check_case_list_6_0_i6);
	init_label(mercury__unique_modes__check_case_list_6_0_i9);
	init_label(mercury__unique_modes__check_case_list_6_0_i11);
	init_label(mercury__unique_modes__check_case_list_6_0_i7);
	init_label(mercury__unique_modes__check_case_list_6_0_i12);
	init_label(mercury__unique_modes__check_case_list_6_0_i14);
	init_label(mercury__unique_modes__check_case_list_6_0_i15);
	init_label(mercury__unique_modes__check_case_list_6_0_i16);
	init_label(mercury__unique_modes__check_case_list_6_0_i17);
	init_label(mercury__unique_modes__check_case_list_6_0_i3);
BEGIN_CODE

/* code for predicate 'check_case_list'/6 in mode 0 */
Define_static(mercury__unique_modes__check_case_list_6_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__unique_modes__check_case_list_6_0_i3);
	MR_incr_sp_push_msg(8, "unique_modes:check_case_list/6");
	MR_stackvar(8) = (Word) MR_succip;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r1 = r3;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__mode_info__mode_info_get_instmap_2_0),
		mercury__unique_modes__check_case_list_6_0_i4,
		STATIC(mercury__unique_modes__check_case_list_6_0));
	}
Define_label(mercury__unique_modes__check_case_list_6_0_i4);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_case_list_6_0));
	MR_stackvar(6) = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__modes__modecheck_functor_test_4_0),
		mercury__unique_modes__check_case_list_6_0_i5,
		STATIC(mercury__unique_modes__check_case_list_6_0));
Define_label(mercury__unique_modes__check_case_list_6_0_i5);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_case_list_6_0));
	call_localret(ENTRY(mercury__mode_info__mode_info_dcg_get_instmap_3_0),
		mercury__unique_modes__check_case_list_6_0_i6,
		STATIC(mercury__unique_modes__check_case_list_6_0));
Define_label(mercury__unique_modes__check_case_list_6_0_i6);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_case_list_6_0));
	MR_stackvar(7) = r2;
	call_localret(ENTRY(mercury__instmap__is_reachable_1_0),
		mercury__unique_modes__check_case_list_6_0_i9,
		STATIC(mercury__unique_modes__check_case_list_6_0));
Define_label(mercury__unique_modes__check_case_list_6_0_i9);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_case_list_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__unique_modes__check_case_list_6_0_i7);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(7);
	call_localret(STATIC(mercury__unique_modes__check_goal_4_0),
		mercury__unique_modes__check_case_list_6_0_i11,
		STATIC(mercury__unique_modes__check_case_list_6_0));
Define_label(mercury__unique_modes__check_case_list_6_0_i11);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_case_list_6_0));
	MR_stackvar(2) = r1;
	r1 = r2;
	call_localret(ENTRY(mercury__mode_info__mode_info_dcg_get_instmap_3_0),
		mercury__unique_modes__check_case_list_6_0_i14,
		STATIC(mercury__unique_modes__check_case_list_6_0));
Define_label(mercury__unique_modes__check_case_list_6_0_i7);
	call_localret(ENTRY(mercury__hlds_goal__true_goal_1_0),
		mercury__unique_modes__check_case_list_6_0_i12,
		STATIC(mercury__unique_modes__check_case_list_6_0));
Define_label(mercury__unique_modes__check_case_list_6_0_i12);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_case_list_6_0));
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(7);
	call_localret(ENTRY(mercury__mode_info__mode_info_dcg_get_instmap_3_0),
		mercury__unique_modes__check_case_list_6_0_i14,
		STATIC(mercury__unique_modes__check_case_list_6_0));
Define_label(mercury__unique_modes__check_case_list_6_0_i14);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_case_list_6_0));
	r4 = MR_stackvar(2);
	r3 = r1;
	MR_stackvar(2) = r2;
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(6);
	call_localret(ENTRY(mercury__mode_util__fixup_switch_var_5_0),
		mercury__unique_modes__check_case_list_6_0_i15,
		STATIC(mercury__unique_modes__check_case_list_6_0));
Define_label(mercury__unique_modes__check_case_list_6_0_i15);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_case_list_6_0));
	r2 = MR_stackvar(2);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__unique_modes__check_case_list_6_0, "origin_lost_in_value_number");
	MR_stackvar(2) = r3;
	MR_field(MR_mktag(0), r3, (Integer) 1) = r1;
	r1 = MR_stackvar(6);
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(5);
	call_localret(ENTRY(mercury__mode_info__mode_info_set_instmap_3_0),
		mercury__unique_modes__check_case_list_6_0_i16,
		STATIC(mercury__unique_modes__check_case_list_6_0));
Define_label(mercury__unique_modes__check_case_list_6_0_i16);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_case_list_6_0));
	r3 = r1;
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(1);
	localcall(mercury__unique_modes__check_case_list_6_0,
		LABEL(mercury__unique_modes__check_case_list_6_0_i17),
		STATIC(mercury__unique_modes__check_case_list_6_0));
Define_label(mercury__unique_modes__check_case_list_6_0_i17);
	update_prof_current_proc(LABEL(mercury__unique_modes__check_case_list_6_0));
	r4 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__unique_modes__check_case_list_6_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r4;
	r5 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__unique_modes__check_case_list_6_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(1), r2, (Integer) 1) = r5;
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__unique_modes__check_case_list_6_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE


BEGIN_MODULE(unique_modes_module19)
	init_entry(mercury__unique_modes__goal_get_nonlocals_2_0);
BEGIN_CODE

/* code for predicate 'goal_get_nonlocals'/2 in mode 0 */
Define_static(mercury__unique_modes__goal_get_nonlocals_2_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	tailcall(ENTRY(mercury__hlds_goal__goal_info_get_nonlocals_2_0),
		STATIC(mercury__unique_modes__goal_get_nonlocals_2_0));
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__unique_modes_maybe_bunch_0(void)
{
	unique_modes_module0();
	unique_modes_module1();
	unique_modes_module2();
	unique_modes_module3();
	unique_modes_module4();
	unique_modes_module5();
	unique_modes_module6();
	unique_modes_module7();
	unique_modes_module8();
	unique_modes_module9();
	unique_modes_module10();
	unique_modes_module11();
	unique_modes_module12();
	unique_modes_module13();
	unique_modes_module14();
	unique_modes_module15();
	unique_modes_module16();
	unique_modes_module17();
	unique_modes_module18();
	unique_modes_module19();
}

#endif

void mercury__unique_modes__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__unique_modes__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__unique_modes_maybe_bunch_0();
#endif

	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
