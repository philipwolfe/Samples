/*
** Automatically generated from `vn_cost.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__vn_cost__init
ENDINIT
*/

#include "mercury_imp.h"

Define_extern_entry(mercury__vn_cost__block_cost_6_0);
Define_extern_entry(mercury__vn_cost__lval_cost_3_0);
Declare_label(mercury__vn_cost__lval_cost_3_0_i10);
Declare_label(mercury__vn_cost__lval_cost_3_0_i13);
Declare_label(mercury__vn_cost__lval_cost_3_0_i12);
Declare_label(mercury__vn_cost__lval_cost_3_0_i17);
Declare_label(mercury__vn_cost__lval_cost_3_0_i21);
Declare_label(mercury__vn_cost__lval_cost_3_0_i24);
Declare_label(mercury__vn_cost__lval_cost_3_0_i1017);
Declare_label(mercury__vn_cost__lval_cost_3_0_i23);
Declare_label(mercury__vn_cost__lval_cost_3_0_i28);
Declare_label(mercury__vn_cost__lval_cost_3_0_i1012);
Declare_label(mercury__vn_cost__lval_cost_3_0_i29);
Declare_label(mercury__vn_cost__lval_cost_3_0_i32);
Declare_label(mercury__vn_cost__lval_cost_3_0_i35);
Declare_label(mercury__vn_cost__lval_cost_3_0_i37);
Declare_label(mercury__vn_cost__lval_cost_3_0_i38);
Declare_label(mercury__vn_cost__lval_cost_3_0_i40);
Declare_label(mercury__vn_cost__lval_cost_3_0_i41);
Declare_label(mercury__vn_cost__lval_cost_3_0_i43);
Declare_label(mercury__vn_cost__lval_cost_3_0_i44);
Declare_label(mercury__vn_cost__lval_cost_3_0_i46);
Declare_label(mercury__vn_cost__lval_cost_3_0_i47);
Declare_label(mercury__vn_cost__lval_cost_3_0_i49);
Declare_label(mercury__vn_cost__lval_cost_3_0_i50);
Declare_label(mercury__vn_cost__lval_cost_3_0_i51);
Declare_label(mercury__vn_cost__lval_cost_3_0_i52);
Declare_label(mercury__vn_cost__lval_cost_3_0_i53);
Declare_label(mercury__vn_cost__lval_cost_3_0_i54);
Declare_label(mercury__vn_cost__lval_cost_3_0_i55);
Declare_label(mercury__vn_cost__lval_cost_3_0_i56);
Declare_label(mercury__vn_cost__lval_cost_3_0_i57);
Declare_label(mercury__vn_cost__lval_cost_3_0_i58);
Declare_label(mercury__vn_cost__lval_cost_3_0_i59);
Define_extern_entry(mercury__vn_cost__rval_cost_3_0);
Declare_label(mercury__vn_cost__rval_cost_3_0_i1002);
Declare_label(mercury__vn_cost__rval_cost_3_0_i1003);
Declare_label(mercury__vn_cost__rval_cost_3_0_i9);
Declare_label(mercury__vn_cost__rval_cost_3_0_i10);
Declare_label(mercury__vn_cost__rval_cost_3_0_i11);
Declare_label(mercury__vn_cost__rval_cost_3_0_i1004);
Declare_label(mercury__vn_cost__rval_cost_3_0_i13);
Declare_label(mercury__vn_cost__rval_cost_3_0_i14);
Declare_label(mercury__vn_cost__rval_cost_3_0_i15);
Declare_label(mercury__vn_cost__rval_cost_3_0_i18);
Declare_label(mercury__vn_cost__rval_cost_3_0_i20);
Declare_label(mercury__vn_cost__rval_cost_3_0_i21);
Declare_label(mercury__vn_cost__rval_cost_3_0_i22);
Declare_label(mercury__vn_cost__rval_cost_3_0_i23);
Declare_label(mercury__vn_cost__rval_cost_3_0_i24);
Declare_label(mercury__vn_cost__rval_cost_3_0_i2);
Declare_static(mercury__vn_cost__block_cost_2_7_0);
Declare_label(mercury__vn_cost__block_cost_2_7_0_i1003);
Declare_label(mercury__vn_cost__block_cost_2_7_0_i4);
Declare_label(mercury__vn_cost__block_cost_2_7_0_i5);
Declare_label(mercury__vn_cost__block_cost_2_7_0_i7);
Declare_label(mercury__vn_cost__block_cost_2_7_0_i10);
Declare_label(mercury__vn_cost__block_cost_2_7_0_i8);
Declare_label(mercury__vn_cost__block_cost_2_7_0_i3);
Declare_static(mercury__vn_cost__instr_cost_3_0);
Declare_label(mercury__vn_cost__instr_cost_3_0_i7);
Declare_label(mercury__vn_cost__instr_cost_3_0_i8);
Declare_label(mercury__vn_cost__instr_cost_3_0_i10);
Declare_label(mercury__vn_cost__instr_cost_3_0_i11);
Declare_label(mercury__vn_cost__instr_cost_3_0_i12);
Declare_label(mercury__vn_cost__instr_cost_3_0_i13);
Declare_label(mercury__vn_cost__instr_cost_3_0_i14);
Declare_label(mercury__vn_cost__instr_cost_3_0_i22);
Declare_label(mercury__vn_cost__instr_cost_3_0_i24);
Declare_label(mercury__vn_cost__instr_cost_3_0_i18);
Declare_label(mercury__vn_cost__instr_cost_3_0_i17);
Declare_label(mercury__vn_cost__instr_cost_3_0_i34);
Declare_label(mercury__vn_cost__instr_cost_3_0_i38);
Declare_label(mercury__vn_cost__instr_cost_3_0_i39);
Declare_label(mercury__vn_cost__instr_cost_3_0_i40);
Declare_label(mercury__vn_cost__instr_cost_3_0_i41);
Declare_label(mercury__vn_cost__instr_cost_3_0_i43);
Declare_label(mercury__vn_cost__instr_cost_3_0_i44);
Declare_label(mercury__vn_cost__instr_cost_3_0_i53);
Declare_label(mercury__vn_cost__instr_cost_3_0_i55);
Declare_label(mercury__vn_cost__instr_cost_3_0_i1009);
Declare_label(mercury__vn_cost__instr_cost_3_0_i58);
Declare_label(mercury__vn_cost__instr_cost_3_0_i59);
Declare_label(mercury__vn_cost__instr_cost_3_0_i61);
Declare_label(mercury__vn_cost__instr_cost_3_0_i63);
Declare_label(mercury__vn_cost__instr_cost_3_0_i65);
Declare_label(mercury__vn_cost__instr_cost_3_0_i67);
Declare_static(mercury__vn_cost__mem_ref_cost_3_0);
Declare_label(mercury__vn_cost__mem_ref_cost_3_0_i1006);
Declare_label(mercury__vn_cost__mem_ref_cost_3_0_i6);
Declare_label(mercury__vn_cost__mem_ref_cost_3_0_i7);
Declare_label(mercury__vn_cost__mem_ref_cost_3_0_i8);


BEGIN_MODULE(vn_cost_module0)
	init_entry(mercury__vn_cost__block_cost_6_0);
BEGIN_CODE

/* code for predicate 'block_cost'/6 in mode 0 */
Define_entry(mercury__vn_cost__block_cost_6_0);
	r5 = r4;
	r4 = (Integer) 0;
	tailcall(STATIC(mercury__vn_cost__block_cost_2_7_0),
		ENTRY(mercury__vn_cost__block_cost_6_0));
END_MODULE

Declare_entry(mercury__vn_type__real_r_regs_2_0);
Declare_entry(mercury__vn_type__real_f_regs_2_0);
Declare_entry(mercury__vn_type__real_r_temps_2_0);
Declare_entry(mercury__vn_type__real_f_temps_2_0);
Declare_entry(mercury__vn_type__costof_stackref_2_0);
Declare_entry(mercury__vn_type__costof_heapref_2_0);
Declare_entry(mercury__require__error_1_0);

BEGIN_MODULE(vn_cost_module1)
	init_entry(mercury__vn_cost__lval_cost_3_0);
	init_label(mercury__vn_cost__lval_cost_3_0_i10);
	init_label(mercury__vn_cost__lval_cost_3_0_i13);
	init_label(mercury__vn_cost__lval_cost_3_0_i12);
	init_label(mercury__vn_cost__lval_cost_3_0_i17);
	init_label(mercury__vn_cost__lval_cost_3_0_i21);
	init_label(mercury__vn_cost__lval_cost_3_0_i24);
	init_label(mercury__vn_cost__lval_cost_3_0_i1017);
	init_label(mercury__vn_cost__lval_cost_3_0_i23);
	init_label(mercury__vn_cost__lval_cost_3_0_i28);
	init_label(mercury__vn_cost__lval_cost_3_0_i1012);
	init_label(mercury__vn_cost__lval_cost_3_0_i29);
	init_label(mercury__vn_cost__lval_cost_3_0_i32);
	init_label(mercury__vn_cost__lval_cost_3_0_i35);
	init_label(mercury__vn_cost__lval_cost_3_0_i37);
	init_label(mercury__vn_cost__lval_cost_3_0_i38);
	init_label(mercury__vn_cost__lval_cost_3_0_i40);
	init_label(mercury__vn_cost__lval_cost_3_0_i41);
	init_label(mercury__vn_cost__lval_cost_3_0_i43);
	init_label(mercury__vn_cost__lval_cost_3_0_i44);
	init_label(mercury__vn_cost__lval_cost_3_0_i46);
	init_label(mercury__vn_cost__lval_cost_3_0_i47);
	init_label(mercury__vn_cost__lval_cost_3_0_i49);
	init_label(mercury__vn_cost__lval_cost_3_0_i50);
	init_label(mercury__vn_cost__lval_cost_3_0_i51);
	init_label(mercury__vn_cost__lval_cost_3_0_i52);
	init_label(mercury__vn_cost__lval_cost_3_0_i53);
	init_label(mercury__vn_cost__lval_cost_3_0_i54);
	init_label(mercury__vn_cost__lval_cost_3_0_i55);
	init_label(mercury__vn_cost__lval_cost_3_0_i56);
	init_label(mercury__vn_cost__lval_cost_3_0_i57);
	init_label(mercury__vn_cost__lval_cost_3_0_i58);
	init_label(mercury__vn_cost__lval_cost_3_0_i59);
BEGIN_CODE

/* code for predicate 'lval_cost'/3 in mode 0 */
Define_entry(mercury__vn_cost__lval_cost_3_0);
	MR_incr_sp_push_msg(3, "vn_cost:lval_cost/3");
	MR_stackvar(3) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__vn_cost__lval_cost_3_0_i1012) AND
		LABEL(mercury__vn_cost__lval_cost_3_0_i10) AND
		LABEL(mercury__vn_cost__lval_cost_3_0_i21) AND
		LABEL(mercury__vn_cost__lval_cost_3_0_i32));
Define_label(mercury__vn_cost__lval_cost_3_0_i10);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__vn_cost__lval_cost_3_0_i12);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = r2;
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__vn_type__real_r_regs_2_0),
		mercury__vn_cost__lval_cost_3_0_i13,
		ENTRY(mercury__vn_cost__lval_cost_3_0));
Define_label(mercury__vn_cost__lval_cost_3_0_i13);
	update_prof_current_proc(LABEL(mercury__vn_cost__lval_cost_3_0));
	if (((Integer) MR_stackvar(2) > (Integer) r1))
		GOTO_LABEL(mercury__vn_cost__lval_cost_3_0_i29);
	r1 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_cost__lval_cost_3_0_i12);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = r2;
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__vn_type__real_f_regs_2_0),
		mercury__vn_cost__lval_cost_3_0_i17,
		ENTRY(mercury__vn_cost__lval_cost_3_0));
Define_label(mercury__vn_cost__lval_cost_3_0_i17);
	update_prof_current_proc(LABEL(mercury__vn_cost__lval_cost_3_0));
	if (((Integer) MR_stackvar(2) > (Integer) r1))
		GOTO_LABEL(mercury__vn_cost__lval_cost_3_0_i29);
	r1 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_cost__lval_cost_3_0_i21);
	if (((Integer) MR_const_field(MR_mktag(2), r1, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__vn_cost__lval_cost_3_0_i23);
	MR_stackvar(2) = MR_const_field(MR_mktag(2), r1, (Integer) 1);
	r1 = r2;
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__vn_type__real_r_temps_2_0),
		mercury__vn_cost__lval_cost_3_0_i24,
		ENTRY(mercury__vn_cost__lval_cost_3_0));
Define_label(mercury__vn_cost__lval_cost_3_0_i24);
	update_prof_current_proc(LABEL(mercury__vn_cost__lval_cost_3_0));
	if (((Integer) MR_stackvar(2) > (Integer) r1))
		GOTO_LABEL(mercury__vn_cost__lval_cost_3_0_i29);
Define_label(mercury__vn_cost__lval_cost_3_0_i1017);
	r1 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_cost__lval_cost_3_0_i23);
	MR_stackvar(2) = MR_const_field(MR_mktag(2), r1, (Integer) 1);
	r1 = r2;
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__vn_type__real_f_temps_2_0),
		mercury__vn_cost__lval_cost_3_0_i28,
		ENTRY(mercury__vn_cost__lval_cost_3_0));
Define_label(mercury__vn_cost__lval_cost_3_0_i28);
	update_prof_current_proc(LABEL(mercury__vn_cost__lval_cost_3_0));
	if (((Integer) MR_stackvar(2) > (Integer) r1))
		GOTO_LABEL(mercury__vn_cost__lval_cost_3_0_i29);
	GOTO_LABEL(mercury__vn_cost__lval_cost_3_0_i1017);
Define_label(mercury__vn_cost__lval_cost_3_0_i1012);
	r1 = (Integer) 0;
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_cost__lval_cost_3_0_i29);
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__vn_type__costof_stackref_2_0),
		ENTRY(mercury__vn_cost__lval_cost_3_0));
Define_label(mercury__vn_cost__lval_cost_3_0_i32);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__vn_cost__lval_cost_3_0_i35) AND
		LABEL(mercury__vn_cost__lval_cost_3_0_i35) AND
		LABEL(mercury__vn_cost__lval_cost_3_0_i37) AND
		LABEL(mercury__vn_cost__lval_cost_3_0_i40) AND
		LABEL(mercury__vn_cost__lval_cost_3_0_i43) AND
		LABEL(mercury__vn_cost__lval_cost_3_0_i46) AND
		LABEL(mercury__vn_cost__lval_cost_3_0_i49) AND
		LABEL(mercury__vn_cost__lval_cost_3_0_i52) AND
		LABEL(mercury__vn_cost__lval_cost_3_0_i56) AND
		LABEL(mercury__vn_cost__lval_cost_3_0_i59));
Define_label(mercury__vn_cost__lval_cost_3_0_i35);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__vn_type__costof_stackref_2_0),
		ENTRY(mercury__vn_cost__lval_cost_3_0));
Define_label(mercury__vn_cost__lval_cost_3_0_i37);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__vn_cost__rval_cost_3_0),
		mercury__vn_cost__lval_cost_3_0_i38,
		ENTRY(mercury__vn_cost__lval_cost_3_0));
Define_label(mercury__vn_cost__lval_cost_3_0_i38);
	update_prof_current_proc(LABEL(mercury__vn_cost__lval_cost_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__vn_type__costof_stackref_2_0),
		mercury__vn_cost__lval_cost_3_0_i58,
		ENTRY(mercury__vn_cost__lval_cost_3_0));
Define_label(mercury__vn_cost__lval_cost_3_0_i40);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r1 = r2;
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__vn_type__costof_stackref_2_0),
		mercury__vn_cost__lval_cost_3_0_i41,
		ENTRY(mercury__vn_cost__lval_cost_3_0));
Define_label(mercury__vn_cost__lval_cost_3_0_i41);
	update_prof_current_proc(LABEL(mercury__vn_cost__lval_cost_3_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(2);
	call_localret(STATIC(mercury__vn_cost__rval_cost_3_0),
		mercury__vn_cost__lval_cost_3_0_i51,
		ENTRY(mercury__vn_cost__lval_cost_3_0));
Define_label(mercury__vn_cost__lval_cost_3_0_i43);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r1 = r2;
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__vn_type__costof_stackref_2_0),
		mercury__vn_cost__lval_cost_3_0_i44,
		ENTRY(mercury__vn_cost__lval_cost_3_0));
Define_label(mercury__vn_cost__lval_cost_3_0_i44);
	update_prof_current_proc(LABEL(mercury__vn_cost__lval_cost_3_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(2);
	call_localret(STATIC(mercury__vn_cost__rval_cost_3_0),
		mercury__vn_cost__lval_cost_3_0_i51,
		ENTRY(mercury__vn_cost__lval_cost_3_0));
Define_label(mercury__vn_cost__lval_cost_3_0_i46);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r1 = r2;
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__vn_type__costof_stackref_2_0),
		mercury__vn_cost__lval_cost_3_0_i47,
		ENTRY(mercury__vn_cost__lval_cost_3_0));
Define_label(mercury__vn_cost__lval_cost_3_0_i47);
	update_prof_current_proc(LABEL(mercury__vn_cost__lval_cost_3_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(2);
	call_localret(STATIC(mercury__vn_cost__rval_cost_3_0),
		mercury__vn_cost__lval_cost_3_0_i51,
		ENTRY(mercury__vn_cost__lval_cost_3_0));
Define_label(mercury__vn_cost__lval_cost_3_0_i49);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r1 = r2;
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__vn_type__costof_stackref_2_0),
		mercury__vn_cost__lval_cost_3_0_i50,
		ENTRY(mercury__vn_cost__lval_cost_3_0));
Define_label(mercury__vn_cost__lval_cost_3_0_i50);
	update_prof_current_proc(LABEL(mercury__vn_cost__lval_cost_3_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(2);
	call_localret(STATIC(mercury__vn_cost__rval_cost_3_0),
		mercury__vn_cost__lval_cost_3_0_i51,
		ENTRY(mercury__vn_cost__lval_cost_3_0));
Define_label(mercury__vn_cost__lval_cost_3_0_i51);
	update_prof_current_proc(LABEL(mercury__vn_cost__lval_cost_3_0));
	r1 = ((Integer) r1 + (Integer) MR_stackvar(1));
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_cost__lval_cost_3_0_i52);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__vn_cost__rval_cost_3_0),
		mercury__vn_cost__lval_cost_3_0_i53,
		ENTRY(mercury__vn_cost__lval_cost_3_0));
Define_label(mercury__vn_cost__lval_cost_3_0_i53);
	update_prof_current_proc(LABEL(mercury__vn_cost__lval_cost_3_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r3;
	r2 = MR_stackvar(1);
	call_localret(STATIC(mercury__vn_cost__rval_cost_3_0),
		mercury__vn_cost__lval_cost_3_0_i54,
		ENTRY(mercury__vn_cost__lval_cost_3_0));
Define_label(mercury__vn_cost__lval_cost_3_0_i54);
	update_prof_current_proc(LABEL(mercury__vn_cost__lval_cost_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__vn_type__costof_heapref_2_0),
		mercury__vn_cost__lval_cost_3_0_i55,
		ENTRY(mercury__vn_cost__lval_cost_3_0));
Define_label(mercury__vn_cost__lval_cost_3_0_i55);
	update_prof_current_proc(LABEL(mercury__vn_cost__lval_cost_3_0));
	r1 = (((Integer) MR_stackvar(2) + (Integer) MR_stackvar(1)) + (Integer) r1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_cost__lval_cost_3_0_i56);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__vn_cost__rval_cost_3_0),
		mercury__vn_cost__lval_cost_3_0_i57,
		ENTRY(mercury__vn_cost__lval_cost_3_0));
Define_label(mercury__vn_cost__lval_cost_3_0_i57);
	update_prof_current_proc(LABEL(mercury__vn_cost__lval_cost_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__vn_type__costof_heapref_2_0),
		mercury__vn_cost__lval_cost_3_0_i58,
		ENTRY(mercury__vn_cost__lval_cost_3_0));
Define_label(mercury__vn_cost__lval_cost_3_0_i58);
	update_prof_current_proc(LABEL(mercury__vn_cost__lval_cost_3_0));
	r1 = ((Integer) MR_stackvar(1) + (Integer) r1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_cost__lval_cost_3_0_i59);
	r1 = (Word) MR_string_const("lvar found in lval_cost", 23);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__vn_cost__lval_cost_3_0));
END_MODULE

Declare_entry(mercury__vn_type__costof_intops_2_0);

BEGIN_MODULE(vn_cost_module2)
	init_entry(mercury__vn_cost__rval_cost_3_0);
	init_label(mercury__vn_cost__rval_cost_3_0_i1002);
	init_label(mercury__vn_cost__rval_cost_3_0_i1003);
	init_label(mercury__vn_cost__rval_cost_3_0_i9);
	init_label(mercury__vn_cost__rval_cost_3_0_i10);
	init_label(mercury__vn_cost__rval_cost_3_0_i11);
	init_label(mercury__vn_cost__rval_cost_3_0_i1004);
	init_label(mercury__vn_cost__rval_cost_3_0_i13);
	init_label(mercury__vn_cost__rval_cost_3_0_i14);
	init_label(mercury__vn_cost__rval_cost_3_0_i15);
	init_label(mercury__vn_cost__rval_cost_3_0_i18);
	init_label(mercury__vn_cost__rval_cost_3_0_i20);
	init_label(mercury__vn_cost__rval_cost_3_0_i21);
	init_label(mercury__vn_cost__rval_cost_3_0_i22);
	init_label(mercury__vn_cost__rval_cost_3_0_i23);
	init_label(mercury__vn_cost__rval_cost_3_0_i24);
	init_label(mercury__vn_cost__rval_cost_3_0_i2);
BEGIN_CODE

/* code for predicate 'rval_cost'/3 in mode 0 */
Define_entry(mercury__vn_cost__rval_cost_3_0);
	MR_incr_sp_push_msg(3, "vn_cost:rval_cost/3");
	MR_stackvar(3) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__vn_cost__rval_cost_3_0_i1002) AND
		LABEL(mercury__vn_cost__rval_cost_3_0_i1003) AND
		LABEL(mercury__vn_cost__rval_cost_3_0_i1004) AND
		LABEL(mercury__vn_cost__rval_cost_3_0_i9));
Define_label(mercury__vn_cost__rval_cost_3_0_i1002);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__vn_cost__lval_cost_3_0),
		ENTRY(mercury__vn_cost__rval_cost_3_0));
Define_label(mercury__vn_cost__rval_cost_3_0_i1003);
	r1 = (Word) MR_string_const("var found in rval_cost", 22);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__vn_cost__rval_cost_3_0));
Define_label(mercury__vn_cost__rval_cost_3_0_i9);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__vn_cost__rval_cost_3_0_i10) AND
		LABEL(mercury__vn_cost__rval_cost_3_0_i13) AND
		LABEL(mercury__vn_cost__rval_cost_3_0_i14) AND
		LABEL(mercury__vn_cost__rval_cost_3_0_i20) AND
		LABEL(mercury__vn_cost__rval_cost_3_0_i24));
Define_label(mercury__vn_cost__rval_cost_3_0_i10);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(1) = r2;
	localcall(mercury__vn_cost__rval_cost_3_0,
		LABEL(mercury__vn_cost__rval_cost_3_0_i11),
		ENTRY(mercury__vn_cost__rval_cost_3_0));
Define_label(mercury__vn_cost__rval_cost_3_0_i11);
	update_prof_current_proc(LABEL(mercury__vn_cost__rval_cost_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__vn_type__costof_intops_2_0),
		mercury__vn_cost__rval_cost_3_0_i18,
		ENTRY(mercury__vn_cost__rval_cost_3_0));
Define_label(mercury__vn_cost__rval_cost_3_0_i1004);
	r1 = (Integer) 0;
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_cost__rval_cost_3_0_i13);
	r1 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_cost__rval_cost_3_0_i14);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(1) = r2;
	localcall(mercury__vn_cost__rval_cost_3_0,
		LABEL(mercury__vn_cost__rval_cost_3_0_i15),
		ENTRY(mercury__vn_cost__rval_cost_3_0));
Define_label(mercury__vn_cost__rval_cost_3_0_i15);
	update_prof_current_proc(LABEL(mercury__vn_cost__rval_cost_3_0));
	if (((Integer) MR_stackvar(2) == (Integer) 6))
		GOTO_LABEL(mercury__vn_cost__rval_cost_3_0_i2);
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__vn_type__costof_intops_2_0),
		mercury__vn_cost__rval_cost_3_0_i18,
		ENTRY(mercury__vn_cost__rval_cost_3_0));
Define_label(mercury__vn_cost__rval_cost_3_0_i18);
	update_prof_current_proc(LABEL(mercury__vn_cost__rval_cost_3_0));
	r1 = ((Integer) MR_stackvar(1) + (Integer) r1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_cost__rval_cost_3_0_i20);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(1) = r2;
	localcall(mercury__vn_cost__rval_cost_3_0,
		LABEL(mercury__vn_cost__rval_cost_3_0_i21),
		ENTRY(mercury__vn_cost__rval_cost_3_0));
Define_label(mercury__vn_cost__rval_cost_3_0_i21);
	update_prof_current_proc(LABEL(mercury__vn_cost__rval_cost_3_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r3;
	r2 = MR_stackvar(1);
	localcall(mercury__vn_cost__rval_cost_3_0,
		LABEL(mercury__vn_cost__rval_cost_3_0_i22),
		ENTRY(mercury__vn_cost__rval_cost_3_0));
Define_label(mercury__vn_cost__rval_cost_3_0_i22);
	update_prof_current_proc(LABEL(mercury__vn_cost__rval_cost_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__vn_type__costof_intops_2_0),
		mercury__vn_cost__rval_cost_3_0_i23,
		ENTRY(mercury__vn_cost__rval_cost_3_0));
Define_label(mercury__vn_cost__rval_cost_3_0_i23);
	update_prof_current_proc(LABEL(mercury__vn_cost__rval_cost_3_0));
	r1 = (((Integer) MR_stackvar(2) + (Integer) MR_stackvar(1)) + (Integer) r1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_cost__rval_cost_3_0_i24);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__vn_cost__mem_ref_cost_3_0),
		ENTRY(mercury__vn_cost__rval_cost_3_0));
Define_label(mercury__vn_cost__rval_cost_3_0_i2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE

Declare_entry(mercury__vn_debug__cost_detail_msg_5_0);

BEGIN_MODULE(vn_cost_module3)
	init_entry(mercury__vn_cost__block_cost_2_7_0);
	init_label(mercury__vn_cost__block_cost_2_7_0_i1003);
	init_label(mercury__vn_cost__block_cost_2_7_0_i4);
	init_label(mercury__vn_cost__block_cost_2_7_0_i5);
	init_label(mercury__vn_cost__block_cost_2_7_0_i7);
	init_label(mercury__vn_cost__block_cost_2_7_0_i10);
	init_label(mercury__vn_cost__block_cost_2_7_0_i8);
	init_label(mercury__vn_cost__block_cost_2_7_0_i3);
BEGIN_CODE

/* code for predicate 'block_cost_2'/7 in mode 0 */
Define_static(mercury__vn_cost__block_cost_2_7_0);
	MR_incr_sp_push_msg(7, "vn_cost:block_cost_2/7");
	MR_stackvar(7) = (Word) MR_succip;
Define_label(mercury__vn_cost__block_cost_2_7_0_i1003);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_cost__block_cost_2_7_0_i3);
	MR_stackvar(5) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0);
	MR_stackvar(6) = r1;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	call_localret(STATIC(mercury__vn_cost__instr_cost_3_0),
		mercury__vn_cost__block_cost_2_7_0_i4,
		STATIC(mercury__vn_cost__block_cost_2_7_0));
Define_label(mercury__vn_cost__block_cost_2_7_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_cost__block_cost_2_7_0));
	if ((MR_tag(MR_stackvar(6)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__vn_cost__block_cost_2_7_0_i5);
	if (((Integer) MR_const_field(MR_mktag(3), MR_stackvar(6), (Integer) 0) != (Integer) 8))
		GOTO_LABEL(mercury__vn_cost__block_cost_2_7_0_i5);
	r6 = r1;
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = ((Integer) 2 * ((Integer) MR_stackvar(3) + (Integer) r6));
	r5 = MR_stackvar(4);
	GOTO_LABEL(mercury__vn_cost__block_cost_2_7_0_i7);
Define_label(mercury__vn_cost__block_cost_2_7_0_i5);
	r6 = r1;
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = ((Integer) MR_stackvar(3) + (Integer) r6);
	r5 = MR_stackvar(4);
Define_label(mercury__vn_cost__block_cost_2_7_0_i7);
	if (((Integer) r3 == (Integer) 0))
		GOTO_LABEL(mercury__vn_cost__block_cost_2_7_0_i8);
	MR_stackvar(2) = r3;
	r3 = r4;
	MR_stackvar(1) = r2;
	MR_stackvar(3) = r4;
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(6);
	r2 = r6;
	r4 = r5;
	call_localret(ENTRY(mercury__vn_debug__cost_detail_msg_5_0),
		mercury__vn_cost__block_cost_2_7_0_i10,
		STATIC(mercury__vn_cost__block_cost_2_7_0));
Define_label(mercury__vn_cost__block_cost_2_7_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_cost__block_cost_2_7_0));
	r5 = r1;
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
Define_label(mercury__vn_cost__block_cost_2_7_0_i8);
	MR_succip = (Code *) MR_stackvar(7);
	GOTO_LABEL(mercury__vn_cost__block_cost_2_7_0_i1003);
Define_label(mercury__vn_cost__block_cost_2_7_0_i3);
	r1 = r4;
	r2 = r5;
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE

Declare_entry(mercury__vn_type__costof_assign_2_0);

BEGIN_MODULE(vn_cost_module4)
	init_entry(mercury__vn_cost__instr_cost_3_0);
	init_label(mercury__vn_cost__instr_cost_3_0_i7);
	init_label(mercury__vn_cost__instr_cost_3_0_i8);
	init_label(mercury__vn_cost__instr_cost_3_0_i10);
	init_label(mercury__vn_cost__instr_cost_3_0_i11);
	init_label(mercury__vn_cost__instr_cost_3_0_i12);
	init_label(mercury__vn_cost__instr_cost_3_0_i13);
	init_label(mercury__vn_cost__instr_cost_3_0_i14);
	init_label(mercury__vn_cost__instr_cost_3_0_i22);
	init_label(mercury__vn_cost__instr_cost_3_0_i24);
	init_label(mercury__vn_cost__instr_cost_3_0_i18);
	init_label(mercury__vn_cost__instr_cost_3_0_i17);
	init_label(mercury__vn_cost__instr_cost_3_0_i34);
	init_label(mercury__vn_cost__instr_cost_3_0_i38);
	init_label(mercury__vn_cost__instr_cost_3_0_i39);
	init_label(mercury__vn_cost__instr_cost_3_0_i40);
	init_label(mercury__vn_cost__instr_cost_3_0_i41);
	init_label(mercury__vn_cost__instr_cost_3_0_i43);
	init_label(mercury__vn_cost__instr_cost_3_0_i44);
	init_label(mercury__vn_cost__instr_cost_3_0_i53);
	init_label(mercury__vn_cost__instr_cost_3_0_i55);
	init_label(mercury__vn_cost__instr_cost_3_0_i1009);
	init_label(mercury__vn_cost__instr_cost_3_0_i58);
	init_label(mercury__vn_cost__instr_cost_3_0_i59);
	init_label(mercury__vn_cost__instr_cost_3_0_i61);
	init_label(mercury__vn_cost__instr_cost_3_0_i63);
	init_label(mercury__vn_cost__instr_cost_3_0_i65);
	init_label(mercury__vn_cost__instr_cost_3_0_i67);
BEGIN_CODE

/* code for predicate 'instr_cost'/3 in mode 0 */
Define_static(mercury__vn_cost__instr_cost_3_0);
	MR_incr_sp_push_msg(6, "vn_cost:instr_cost/3");
	MR_stackvar(6) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__vn_cost__instr_cost_3_0_i1009) AND
		LABEL(mercury__vn_cost__instr_cost_3_0_i1009) AND
		LABEL(mercury__vn_cost__instr_cost_3_0_i1009) AND
		LABEL(mercury__vn_cost__instr_cost_3_0_i7));
Define_label(mercury__vn_cost__instr_cost_3_0_i7);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__vn_cost__instr_cost_3_0_i8) AND
		LABEL(mercury__vn_cost__instr_cost_3_0_i10) AND
		LABEL(mercury__vn_cost__instr_cost_3_0_i58) AND
		LABEL(mercury__vn_cost__instr_cost_3_0_i58) AND
		LABEL(mercury__vn_cost__instr_cost_3_0_i58) AND
		LABEL(mercury__vn_cost__instr_cost_3_0_i58) AND
		LABEL(mercury__vn_cost__instr_cost_3_0_i55) AND
		LABEL(mercury__vn_cost__instr_cost_3_0_i34) AND
		LABEL(mercury__vn_cost__instr_cost_3_0_i55) AND
		LABEL(mercury__vn_cost__instr_cost_3_0_i38) AND
		LABEL(mercury__vn_cost__instr_cost_3_0_i53) AND
		LABEL(mercury__vn_cost__instr_cost_3_0_i55) AND
		LABEL(mercury__vn_cost__instr_cost_3_0_i53) AND
		LABEL(mercury__vn_cost__instr_cost_3_0_i55) AND
		LABEL(mercury__vn_cost__instr_cost_3_0_i53) AND
		LABEL(mercury__vn_cost__instr_cost_3_0_i55) AND
		LABEL(mercury__vn_cost__instr_cost_3_0_i58) AND
		LABEL(mercury__vn_cost__instr_cost_3_0_i58) AND
		LABEL(mercury__vn_cost__instr_cost_3_0_i59) AND
		LABEL(mercury__vn_cost__instr_cost_3_0_i61) AND
		LABEL(mercury__vn_cost__instr_cost_3_0_i63) AND
		LABEL(mercury__vn_cost__instr_cost_3_0_i65) AND
		LABEL(mercury__vn_cost__instr_cost_3_0_i67));
Define_label(mercury__vn_cost__instr_cost_3_0_i8);
	r1 = (Word) MR_string_const("block found in vn_block_cost", 28);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__vn_cost__instr_cost_3_0));
Define_label(mercury__vn_cost__instr_cost_3_0_i10);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__vn_cost__lval_cost_3_0),
		mercury__vn_cost__instr_cost_3_0_i11,
		STATIC(mercury__vn_cost__instr_cost_3_0));
Define_label(mercury__vn_cost__instr_cost_3_0_i11);
	update_prof_current_proc(LABEL(mercury__vn_cost__instr_cost_3_0));
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(1);
	call_localret(STATIC(mercury__vn_cost__rval_cost_3_0),
		mercury__vn_cost__instr_cost_3_0_i12,
		STATIC(mercury__vn_cost__instr_cost_3_0));
Define_label(mercury__vn_cost__instr_cost_3_0_i12);
	update_prof_current_proc(LABEL(mercury__vn_cost__instr_cost_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__vn_type__costof_assign_2_0),
		mercury__vn_cost__instr_cost_3_0_i13,
		STATIC(mercury__vn_cost__instr_cost_3_0));
Define_label(mercury__vn_cost__instr_cost_3_0_i13);
	update_prof_current_proc(LABEL(mercury__vn_cost__instr_cost_3_0));
	if (((Integer) MR_stackvar(3) != (Integer) 0))
		GOTO_LABEL(mercury__vn_cost__instr_cost_3_0_i14);
	if ((MR_tag(MR_stackvar(2)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__vn_cost__instr_cost_3_0_i14);
	if (((Integer) MR_stackvar(1) <= (Integer) 0))
		GOTO_LABEL(mercury__vn_cost__instr_cost_3_0_i14);
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__vn_cost__instr_cost_3_0_i14);
	r2 = MR_stackvar(2);
	if ((MR_tag(r2) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__vn_cost__instr_cost_3_0_i17);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r2, (Integer) 0),
		LABEL(mercury__vn_cost__instr_cost_3_0_i18) AND
		LABEL(mercury__vn_cost__instr_cost_3_0_i17) AND
		LABEL(mercury__vn_cost__instr_cost_3_0_i22) AND
		LABEL(mercury__vn_cost__instr_cost_3_0_i24) AND
		LABEL(mercury__vn_cost__instr_cost_3_0_i17));
Define_label(mercury__vn_cost__instr_cost_3_0_i22);
	if (!((((Integer) 1 << (Unsigned)(MR_const_field(MR_mktag(3), r2, (Integer) 1))) & (Integer) 319)))
		GOTO_LABEL(mercury__vn_cost__instr_cost_3_0_i17);
	GOTO_LABEL(mercury__vn_cost__instr_cost_3_0_i18);
Define_label(mercury__vn_cost__instr_cost_3_0_i24);
	if (!((((Integer) 1 << (Unsigned)(MR_const_field(MR_mktag(3), r2, (Integer) 1))) & (Integer) 3583)))
		GOTO_LABEL(mercury__vn_cost__instr_cost_3_0_i17);
Define_label(mercury__vn_cost__instr_cost_3_0_i18);
	r1 = ((Integer) MR_stackvar(1) + (Integer) MR_stackvar(3));
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__vn_cost__instr_cost_3_0_i17);
	r1 = (((Integer) MR_stackvar(1) + (Integer) MR_stackvar(3)) + (Integer) r1);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__vn_cost__instr_cost_3_0_i34);
	r1 = (Word) MR_string_const("c_code found in vn_block_cost", 29);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__vn_cost__instr_cost_3_0));
Define_label(mercury__vn_cost__instr_cost_3_0_i38);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	r1 = r2;
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__vn_type__costof_assign_2_0),
		mercury__vn_cost__instr_cost_3_0_i39,
		STATIC(mercury__vn_cost__instr_cost_3_0));
Define_label(mercury__vn_cost__instr_cost_3_0_i39);
	update_prof_current_proc(LABEL(mercury__vn_cost__instr_cost_3_0));
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(1);
	call_localret(STATIC(mercury__vn_cost__lval_cost_3_0),
		mercury__vn_cost__instr_cost_3_0_i40,
		STATIC(mercury__vn_cost__instr_cost_3_0));
Define_label(mercury__vn_cost__instr_cost_3_0_i40);
	update_prof_current_proc(LABEL(mercury__vn_cost__instr_cost_3_0));
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(1);
	call_localret(STATIC(mercury__vn_cost__rval_cost_3_0),
		mercury__vn_cost__instr_cost_3_0_i41,
		STATIC(mercury__vn_cost__instr_cost_3_0));
Define_label(mercury__vn_cost__instr_cost_3_0_i41);
	update_prof_current_proc(LABEL(mercury__vn_cost__instr_cost_3_0));
	if (((Integer) MR_stackvar(2) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_cost__instr_cost_3_0_i43);
	r1 = (((Integer) r1 + (Integer) MR_stackvar(3)) + ((Integer) 3 * (Integer) MR_stackvar(5)));
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__vn_cost__instr_cost_3_0_i43);
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = (((Integer) r2 + (Integer) MR_stackvar(3)) + ((Integer) 3 * (Integer) MR_stackvar(5)));
	call_localret(ENTRY(mercury__vn_type__costof_intops_2_0),
		mercury__vn_cost__instr_cost_3_0_i44,
		STATIC(mercury__vn_cost__instr_cost_3_0));
Define_label(mercury__vn_cost__instr_cost_3_0_i44);
	update_prof_current_proc(LABEL(mercury__vn_cost__instr_cost_3_0));
	r1 = ((Integer) MR_stackvar(1) + (Integer) r1);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__vn_cost__instr_cost_3_0_i53);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(STATIC(mercury__vn_cost__lval_cost_3_0),
		STATIC(mercury__vn_cost__instr_cost_3_0));
Define_label(mercury__vn_cost__instr_cost_3_0_i55);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(STATIC(mercury__vn_cost__rval_cost_3_0),
		STATIC(mercury__vn_cost__instr_cost_3_0));
Define_label(mercury__vn_cost__instr_cost_3_0_i1009);
	r1 = (Integer) 0;
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__vn_cost__instr_cost_3_0_i58);
	r1 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__vn_cost__instr_cost_3_0_i59);
	r1 = (Word) MR_string_const("pragma_c found in vn_block_cost", 31);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__vn_cost__instr_cost_3_0));
Define_label(mercury__vn_cost__instr_cost_3_0_i61);
	r1 = (Word) MR_string_const("init_sync_term found in vn_block_cost", 37);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__vn_cost__instr_cost_3_0));
Define_label(mercury__vn_cost__instr_cost_3_0_i63);
	r1 = (Word) MR_string_const("fork found in vn_block_cost", 27);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__vn_cost__instr_cost_3_0));
Define_label(mercury__vn_cost__instr_cost_3_0_i65);
	r1 = (Word) MR_string_const("join_and_terminate found in vn_block_cost", 41);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__vn_cost__instr_cost_3_0));
Define_label(mercury__vn_cost__instr_cost_3_0_i67);
	r1 = (Word) MR_string_const("join_and_continue found in vn_block_cost", 40);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__vn_cost__instr_cost_3_0));
END_MODULE


BEGIN_MODULE(vn_cost_module5)
	init_entry(mercury__vn_cost__mem_ref_cost_3_0);
	init_label(mercury__vn_cost__mem_ref_cost_3_0_i1006);
	init_label(mercury__vn_cost__mem_ref_cost_3_0_i6);
	init_label(mercury__vn_cost__mem_ref_cost_3_0_i7);
	init_label(mercury__vn_cost__mem_ref_cost_3_0_i8);
BEGIN_CODE

/* code for predicate 'mem_ref_cost'/3 in mode 0 */
Define_static(mercury__vn_cost__mem_ref_cost_3_0);
	MR_incr_sp_push_msg(2, "vn_cost:mem_ref_cost/3");
	MR_stackvar(2) = (Word) MR_succip;
	r3 = MR_tag(r1);
	if ((r3 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_cost__mem_ref_cost_3_0_i1006);
	if ((r3 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_cost__mem_ref_cost_3_0_i6);
Define_label(mercury__vn_cost__mem_ref_cost_3_0_i1006);
	r1 = r2;
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__vn_type__costof_intops_2_0),
		STATIC(mercury__vn_cost__mem_ref_cost_3_0));
Define_label(mercury__vn_cost__mem_ref_cost_3_0_i6);
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__vn_cost__rval_cost_3_0),
		mercury__vn_cost__mem_ref_cost_3_0_i7,
		STATIC(mercury__vn_cost__mem_ref_cost_3_0));
Define_label(mercury__vn_cost__mem_ref_cost_3_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_cost__mem_ref_cost_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__vn_type__costof_intops_2_0),
		mercury__vn_cost__mem_ref_cost_3_0_i8,
		STATIC(mercury__vn_cost__mem_ref_cost_3_0));
Define_label(mercury__vn_cost__mem_ref_cost_3_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_cost__mem_ref_cost_3_0));
	r1 = ((Integer) MR_stackvar(1) + (Integer) r1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__vn_cost_maybe_bunch_0(void)
{
	vn_cost_module0();
	vn_cost_module1();
	vn_cost_module2();
	vn_cost_module3();
	vn_cost_module4();
	vn_cost_module5();
}

#endif

void mercury__vn_cost__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__vn_cost__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__vn_cost_maybe_bunch_0();
#endif

	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
