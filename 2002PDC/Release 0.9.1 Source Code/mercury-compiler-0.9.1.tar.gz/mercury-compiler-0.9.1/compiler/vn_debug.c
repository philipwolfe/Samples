/*
** Automatically generated from `vn_debug.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__vn_debug__init
ENDINIT
*/

#include "mercury_imp.h"

Define_extern_entry(mercury__vn_debug__tuple_msg_5_0);
Declare_label(mercury__vn_debug__tuple_msg_5_0_i2);
Declare_label(mercury__vn_debug__tuple_msg_5_0_i3);
Declare_label(mercury__vn_debug__tuple_msg_5_0_i5);
Declare_label(mercury__vn_debug__tuple_msg_5_0_i7);
Declare_label(mercury__vn_debug__tuple_msg_5_0_i10);
Declare_label(mercury__vn_debug__tuple_msg_5_0_i12);
Declare_label(mercury__vn_debug__tuple_msg_5_0_i13);
Declare_label(mercury__vn_debug__tuple_msg_5_0_i14);
Declare_label(mercury__vn_debug__tuple_msg_5_0_i15);
Define_extern_entry(mercury__vn_debug__livemap_msg_3_0);
Declare_label(mercury__vn_debug__livemap_msg_3_0_i2);
Declare_label(mercury__vn_debug__livemap_msg_3_0_i3);
Declare_label(mercury__vn_debug__livemap_msg_3_0_i5);
Declare_label(mercury__vn_debug__livemap_msg_3_0_i6);
Define_extern_entry(mercury__vn_debug__fragment_msg_3_0);
Declare_label(mercury__vn_debug__fragment_msg_3_0_i2);
Declare_label(mercury__vn_debug__fragment_msg_3_0_i3);
Declare_label(mercury__vn_debug__fragment_msg_3_0_i5);
Declare_label(mercury__vn_debug__fragment_msg_3_0_i6);
Define_extern_entry(mercury__vn_debug__failure_msg_4_0);
Declare_label(mercury__vn_debug__failure_msg_4_0_i2);
Declare_label(mercury__vn_debug__failure_msg_4_0_i3);
Declare_label(mercury__vn_debug__failure_msg_4_0_i5);
Declare_label(mercury__vn_debug__failure_msg_4_0_i6);
Declare_label(mercury__vn_debug__failure_msg_4_0_i7);
Declare_label(mercury__vn_debug__failure_msg_4_0_i8);
Declare_label(mercury__vn_debug__failure_msg_4_0_i9);
Declare_label(mercury__vn_debug__failure_msg_4_0_i10);
Define_extern_entry(mercury__vn_debug__parallel_msgs_3_0);
Declare_label(mercury__vn_debug__parallel_msgs_3_0_i1001);
Declare_label(mercury__vn_debug__parallel_msgs_3_0_i4);
Declare_label(mercury__vn_debug__parallel_msgs_3_0_i3);
Define_extern_entry(mercury__vn_debug__parallel_msg_3_0);
Declare_label(mercury__vn_debug__parallel_msg_3_0_i2);
Declare_label(mercury__vn_debug__parallel_msg_3_0_i3);
Declare_label(mercury__vn_debug__parallel_msg_3_0_i5);
Declare_label(mercury__vn_debug__parallel_msg_3_0_i6);
Declare_label(mercury__vn_debug__parallel_msg_3_0_i7);
Declare_label(mercury__vn_debug__parallel_msg_3_0_i8);
Declare_label(mercury__vn_debug__parallel_msg_3_0_i9);
Declare_label(mercury__vn_debug__parallel_msg_3_0_i10);
Declare_label(mercury__vn_debug__parallel_msg_3_0_i11);
Define_extern_entry(mercury__vn_debug__computed_goto_msg_5_0);
Declare_label(mercury__vn_debug__computed_goto_msg_5_0_i2);
Declare_label(mercury__vn_debug__computed_goto_msg_5_0_i3);
Declare_label(mercury__vn_debug__computed_goto_msg_5_0_i5);
Declare_label(mercury__vn_debug__computed_goto_msg_5_0_i6);
Declare_label(mercury__vn_debug__computed_goto_msg_5_0_i7);
Declare_label(mercury__vn_debug__computed_goto_msg_5_0_i8);
Declare_label(mercury__vn_debug__computed_goto_msg_5_0_i9);
Declare_label(mercury__vn_debug__computed_goto_msg_5_0_i10);
Define_extern_entry(mercury__vn_debug__order_start_msg_5_0);
Declare_label(mercury__vn_debug__order_start_msg_5_0_i2);
Declare_label(mercury__vn_debug__order_start_msg_5_0_i3);
Declare_label(mercury__vn_debug__order_start_msg_5_0_i5);
Declare_label(mercury__vn_debug__order_start_msg_5_0_i6);
Declare_label(mercury__vn_debug__order_start_msg_5_0_i7);
Declare_label(mercury__vn_debug__order_start_msg_5_0_i8);
Declare_label(mercury__vn_debug__order_start_msg_5_0_i9);
Declare_label(mercury__vn_debug__order_start_msg_5_0_i10);
Declare_label(mercury__vn_debug__order_start_msg_5_0_i11);
Define_extern_entry(mercury__vn_debug__order_sink_msg_3_0);
Declare_label(mercury__vn_debug__order_sink_msg_3_0_i2);
Declare_label(mercury__vn_debug__order_sink_msg_3_0_i3);
Declare_label(mercury__vn_debug__order_sink_msg_3_0_i5);
Declare_label(mercury__vn_debug__order_sink_msg_3_0_i6);
Declare_label(mercury__vn_debug__order_sink_msg_3_0_i7);
Define_extern_entry(mercury__vn_debug__order_link_msg_5_0);
Declare_label(mercury__vn_debug__order_link_msg_5_0_i2);
Declare_label(mercury__vn_debug__order_link_msg_5_0_i3);
Declare_label(mercury__vn_debug__order_link_msg_5_0_i6);
Declare_label(mercury__vn_debug__order_link_msg_5_0_i8);
Declare_label(mercury__vn_debug__order_link_msg_5_0_i9);
Declare_label(mercury__vn_debug__order_link_msg_5_0_i10);
Declare_label(mercury__vn_debug__order_link_msg_5_0_i11);
Declare_label(mercury__vn_debug__order_link_msg_5_0_i12);
Declare_label(mercury__vn_debug__order_link_msg_5_0_i13);
Define_extern_entry(mercury__vn_debug__order_antidep_msg_4_0);
Declare_label(mercury__vn_debug__order_antidep_msg_4_0_i2);
Declare_label(mercury__vn_debug__order_antidep_msg_4_0_i3);
Declare_label(mercury__vn_debug__order_antidep_msg_4_0_i5);
Declare_label(mercury__vn_debug__order_antidep_msg_4_0_i6);
Declare_label(mercury__vn_debug__order_antidep_msg_4_0_i7);
Declare_label(mercury__vn_debug__order_antidep_msg_4_0_i8);
Declare_label(mercury__vn_debug__order_antidep_msg_4_0_i9);
Declare_label(mercury__vn_debug__order_antidep_msg_4_0_i10);
Define_extern_entry(mercury__vn_debug__order_map_msg_6_0);
Declare_label(mercury__vn_debug__order_map_msg_6_0_i2);
Declare_label(mercury__vn_debug__order_map_msg_6_0_i3);
Declare_label(mercury__vn_debug__order_map_msg_6_0_i5);
Declare_label(mercury__vn_debug__order_map_msg_6_0_i6);
Declare_label(mercury__vn_debug__order_map_msg_6_0_i7);
Declare_label(mercury__vn_debug__order_map_msg_6_0_i8);
Declare_label(mercury__vn_debug__order_map_msg_6_0_i9);
Declare_label(mercury__vn_debug__order_map_msg_6_0_i10);
Declare_label(mercury__vn_debug__order_map_msg_6_0_i11);
Declare_label(mercury__vn_debug__order_map_msg_6_0_i12);
Declare_label(mercury__vn_debug__order_map_msg_6_0_i13);
Declare_label(mercury__vn_debug__order_map_msg_6_0_i14);
Declare_label(mercury__vn_debug__order_map_msg_6_0_i15);
Define_extern_entry(mercury__vn_debug__order_order_msg_3_0);
Declare_label(mercury__vn_debug__order_order_msg_3_0_i2);
Declare_label(mercury__vn_debug__order_order_msg_3_0_i3);
Declare_label(mercury__vn_debug__order_order_msg_3_0_i5);
Declare_label(mercury__vn_debug__order_order_msg_3_0_i6);
Declare_label(mercury__vn_debug__order_order_msg_3_0_i7);
Define_extern_entry(mercury__vn_debug__order_equals_msg_4_0);
Declare_label(mercury__vn_debug__order_equals_msg_4_0_i2);
Declare_label(mercury__vn_debug__order_equals_msg_4_0_i3);
Declare_label(mercury__vn_debug__order_equals_msg_4_0_i5);
Declare_label(mercury__vn_debug__order_equals_msg_4_0_i6);
Declare_label(mercury__vn_debug__order_equals_msg_4_0_i7);
Define_extern_entry(mercury__vn_debug__cost_header_msg_3_0);
Declare_label(mercury__vn_debug__cost_header_msg_3_0_i2);
Declare_label(mercury__vn_debug__cost_header_msg_3_0_i3);
Define_extern_entry(mercury__vn_debug__cost_msg_5_0);
Declare_label(mercury__vn_debug__cost_msg_5_0_i2);
Declare_label(mercury__vn_debug__cost_msg_5_0_i3);
Declare_label(mercury__vn_debug__cost_msg_5_0_i5);
Declare_label(mercury__vn_debug__cost_msg_5_0_i6);
Declare_label(mercury__vn_debug__cost_msg_5_0_i7);
Declare_label(mercury__vn_debug__cost_msg_5_0_i8);
Declare_label(mercury__vn_debug__cost_msg_5_0_i9);
Declare_label(mercury__vn_debug__cost_msg_5_0_i10);
Declare_label(mercury__vn_debug__cost_msg_5_0_i11);
Declare_label(mercury__vn_debug__cost_msg_5_0_i12);
Declare_label(mercury__vn_debug__cost_msg_5_0_i13);
Declare_label(mercury__vn_debug__cost_msg_5_0_i14);
Declare_label(mercury__vn_debug__cost_msg_5_0_i16);
Declare_label(mercury__vn_debug__cost_msg_5_0_i18);
Define_extern_entry(mercury__vn_debug__cost_detail_msg_5_0);
Declare_label(mercury__vn_debug__cost_detail_msg_5_0_i2);
Declare_label(mercury__vn_debug__cost_detail_msg_5_0_i3);
Declare_label(mercury__vn_debug__cost_detail_msg_5_0_i5);
Declare_label(mercury__vn_debug__cost_detail_msg_5_0_i6);
Declare_label(mercury__vn_debug__cost_detail_msg_5_0_i7);
Declare_label(mercury__vn_debug__cost_detail_msg_5_0_i8);
Declare_label(mercury__vn_debug__cost_detail_msg_5_0_i9);
Declare_label(mercury__vn_debug__cost_detail_msg_5_0_i10);
Define_extern_entry(mercury__vn_debug__restart_msg_3_0);
Declare_label(mercury__vn_debug__restart_msg_3_0_i2);
Declare_label(mercury__vn_debug__restart_msg_3_0_i3);
Declare_label(mercury__vn_debug__restart_msg_3_0_i5);
Declare_label(mercury__vn_debug__restart_msg_3_0_i6);
Declare_label(mercury__vn_debug__restart_msg_3_0_i7);
Define_extern_entry(mercury__vn_debug__divide_msg_3_0);
Declare_label(mercury__vn_debug__divide_msg_3_0_i2);
Declare_label(mercury__vn_debug__divide_msg_3_0_i3);
Declare_label(mercury__vn_debug__divide_msg_3_0_i5);
Declare_label(mercury__vn_debug__divide_msg_3_0_i6);
Declare_label(mercury__vn_debug__divide_msg_3_0_i7);
Define_extern_entry(mercury__vn_debug__flush_start_msg_3_0);
Declare_label(mercury__vn_debug__flush_start_msg_3_0_i2);
Declare_label(mercury__vn_debug__flush_start_msg_3_0_i3);
Declare_label(mercury__vn_debug__flush_start_msg_3_0_i5);
Declare_label(mercury__vn_debug__flush_start_msg_3_0_i6);
Declare_label(mercury__vn_debug__flush_start_msg_3_0_i7);
Define_extern_entry(mercury__vn_debug__flush_also_msg_3_0);
Declare_label(mercury__vn_debug__flush_also_msg_3_0_i2);
Declare_label(mercury__vn_debug__flush_also_msg_3_0_i3);
Declare_label(mercury__vn_debug__flush_also_msg_3_0_i5);
Declare_label(mercury__vn_debug__flush_also_msg_3_0_i6);
Declare_label(mercury__vn_debug__flush_also_msg_3_0_i7);
Define_extern_entry(mercury__vn_debug__flush_end_msg_4_0);
Declare_label(mercury__vn_debug__flush_end_msg_4_0_i2);
Declare_label(mercury__vn_debug__flush_end_msg_4_0_i3);
Declare_label(mercury__vn_debug__flush_end_msg_4_0_i5);
Declare_label(mercury__vn_debug__flush_end_msg_4_0_i6);
Declare_label(mercury__vn_debug__flush_end_msg_4_0_i7);
Declare_label(mercury__vn_debug__flush_end_msg_4_0_i8);
Declare_label(mercury__vn_debug__flush_end_msg_4_0_i9);
Define_extern_entry(mercury__vn_debug__dump_instrs_3_0);
Declare_label(mercury__vn_debug__dump_instrs_3_0_i2);
Declare_label(mercury__vn_debug__dump_instrs_3_0_i3);
Declare_label(mercury__vn_debug__dump_instrs_3_0_i6);
Declare_label(mercury__vn_debug__dump_instrs_3_0_i7);
Declare_label(mercury__vn_debug__dump_instrs_3_0_i10);
Declare_static(mercury__vn_debug__tuple_entries_6_0);
Declare_label(mercury__vn_debug__tuple_entries_6_0_i1001);
Declare_label(mercury__vn_debug__tuple_entries_6_0_i3);
Declare_label(mercury__vn_debug__tuple_entries_6_0_i4);
Declare_label(mercury__vn_debug__tuple_entries_6_0_i5);
Declare_label(mercury__vn_debug__tuple_entries_6_0_i6);
Declare_label(mercury__vn_debug__tuple_entries_6_0_i7);
Declare_label(mercury__vn_debug__tuple_entries_6_0_i8);
Declare_label(mercury__vn_debug__tuple_entries_6_0_i9);
Declare_label(mercury__vn_debug__tuple_entries_6_0_i2);
Declare_static(mercury__vn_debug__parentry_msg_3_0);
Declare_label(mercury__vn_debug__parentry_msg_3_0_i1001);
Declare_label(mercury__vn_debug__parentry_msg_3_0_i4);
Declare_label(mercury__vn_debug__parentry_msg_3_0_i5);
Declare_label(mercury__vn_debug__parentry_msg_3_0_i6);
Declare_label(mercury__vn_debug__parentry_msg_3_0_i7);
Declare_label(mercury__vn_debug__parentry_msg_3_0_i8);
Declare_label(mercury__vn_debug__parentry_msg_3_0_i9);
Declare_label(mercury__vn_debug__parentry_msg_3_0_i3);
Declare_static(mercury__vn_debug__dump_labels_3_0);
Declare_label(mercury__vn_debug__dump_labels_3_0_i1001);
Declare_label(mercury__vn_debug__dump_labels_3_0_i4);
Declare_label(mercury__vn_debug__dump_labels_3_0_i5);
Declare_label(mercury__vn_debug__dump_labels_3_0_i6);
Declare_label(mercury__vn_debug__dump_labels_3_0_i3);
Declare_static(mercury__vn_debug__dump_parallels_3_0);
Declare_label(mercury__vn_debug__dump_parallels_3_0_i1001);
Declare_label(mercury__vn_debug__dump_parallels_3_0_i4);
Declare_label(mercury__vn_debug__dump_parallels_3_0_i3);
Declare_static(mercury__vn_debug__dump_label_parallel_pairs_3_0);
Declare_label(mercury__vn_debug__dump_label_parallel_pairs_3_0_i1002);
Declare_label(mercury__vn_debug__dump_label_parallel_pairs_3_0_i4);
Declare_label(mercury__vn_debug__dump_label_parallel_pairs_3_0_i5);
Declare_label(mercury__vn_debug__dump_label_parallel_pairs_3_0_i6);
Declare_label(mercury__vn_debug__dump_label_parallel_pairs_3_0_i8);
Declare_label(mercury__vn_debug__dump_label_parallel_pairs_3_0_i10);
Declare_label(mercury__vn_debug__dump_label_parallel_pairs_3_0_i3);

static const struct mercury_data_vn_debug__common_0_struct {
	Word * f1;
	Word * f2;
}  mercury_data_vn_debug__common_0;

extern const struct MR_TypeCtorInfo_struct
	mercury_data_list__type_ctor_info_list_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_vn_type__type_ctor_info_parallel_0;
static const struct mercury_data_vn_debug__common_0_struct mercury_data_vn_debug__common_0 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data_vn_type__type_ctor_info_parallel_0
};

Declare_entry(mercury__globals__io_lookup_int_option_4_0);
Declare_entry(mercury__io__write_string_3_0);

BEGIN_MODULE(vn_debug_module0)
	init_entry(mercury__vn_debug__tuple_msg_5_0);
	init_label(mercury__vn_debug__tuple_msg_5_0_i2);
	init_label(mercury__vn_debug__tuple_msg_5_0_i3);
	init_label(mercury__vn_debug__tuple_msg_5_0_i5);
	init_label(mercury__vn_debug__tuple_msg_5_0_i7);
	init_label(mercury__vn_debug__tuple_msg_5_0_i10);
	init_label(mercury__vn_debug__tuple_msg_5_0_i12);
	init_label(mercury__vn_debug__tuple_msg_5_0_i13);
	init_label(mercury__vn_debug__tuple_msg_5_0_i14);
	init_label(mercury__vn_debug__tuple_msg_5_0_i15);
BEGIN_CODE

/* code for predicate 'tuple_msg'/5 in mode 0 */
Define_entry(mercury__vn_debug__tuple_msg_5_0);
	MR_incr_sp_push_msg(4, "vn_debug:tuple_msg/5");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Integer) 25;
	r2 = r4;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__globals__io_lookup_int_option_4_0),
		mercury__vn_debug__tuple_msg_5_0_i2,
		ENTRY(mercury__vn_debug__tuple_msg_5_0));
Define_label(mercury__vn_debug__tuple_msg_5_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_debug__tuple_msg_5_0));
	r3 = ((Integer) r1 & (Integer) 512);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__vn_debug__tuple_msg_5_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__vn_debug__tuple_msg_5_0_i3);
	r1 = (Word) MR_string_const("\nTuples from the ", 17);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__tuple_msg_5_0_i5,
		ENTRY(mercury__vn_debug__tuple_msg_5_0));
Define_label(mercury__vn_debug__tuple_msg_5_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_debug__tuple_msg_5_0));
	if (((Integer) MR_stackvar(1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_debug__tuple_msg_5_0_i7);
	r2 = r1;
	r1 = (Word) MR_string_const("final instruction sequence:\n\n", 29);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__tuple_msg_5_0_i12,
		ENTRY(mercury__vn_debug__tuple_msg_5_0));
Define_label(mercury__vn_debug__tuple_msg_5_0_i7);
	if (((Integer) MR_const_field(MR_mktag(1), MR_stackvar(1), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__vn_debug__tuple_msg_5_0_i10);
	r2 = r1;
	r1 = (Word) MR_string_const("intermediate instruction sequence:\n\n", 36);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__tuple_msg_5_0_i12,
		ENTRY(mercury__vn_debug__tuple_msg_5_0));
Define_label(mercury__vn_debug__tuple_msg_5_0_i10);
	r2 = r1;
	r1 = (Word) MR_string_const("stitched-together instruction sequence:\n\n", 41);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__tuple_msg_5_0_i12,
		ENTRY(mercury__vn_debug__tuple_msg_5_0));
Define_label(mercury__vn_debug__tuple_msg_5_0_i12);
	update_prof_current_proc(LABEL(mercury__vn_debug__tuple_msg_5_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(STATIC(mercury__vn_debug__dump_instrs_3_0),
		mercury__vn_debug__tuple_msg_5_0_i13,
		ENTRY(mercury__vn_debug__tuple_msg_5_0));
Define_label(mercury__vn_debug__tuple_msg_5_0_i13);
	update_prof_current_proc(LABEL(mercury__vn_debug__tuple_msg_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\nTuple data:\n\n", 14);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__tuple_msg_5_0_i14,
		ENTRY(mercury__vn_debug__tuple_msg_5_0));
Define_label(mercury__vn_debug__tuple_msg_5_0_i14);
	update_prof_current_proc(LABEL(mercury__vn_debug__tuple_msg_5_0));
	r5 = r1;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(3);
	r4 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 4);
	r3 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	r1 = (Integer) 0;
	call_localret(STATIC(mercury__vn_debug__tuple_entries_6_0),
		mercury__vn_debug__tuple_msg_5_0_i15,
		ENTRY(mercury__vn_debug__tuple_msg_5_0));
	}
Define_label(mercury__vn_debug__tuple_msg_5_0_i15);
	update_prof_current_proc(LABEL(mercury__vn_debug__tuple_msg_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\nTuple data ends\n\n", 18);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__vn_debug__tuple_msg_5_0));
END_MODULE

Declare_entry(mercury__opt_debug__dump_livemap_2_0);

BEGIN_MODULE(vn_debug_module1)
	init_entry(mercury__vn_debug__livemap_msg_3_0);
	init_label(mercury__vn_debug__livemap_msg_3_0_i2);
	init_label(mercury__vn_debug__livemap_msg_3_0_i3);
	init_label(mercury__vn_debug__livemap_msg_3_0_i5);
	init_label(mercury__vn_debug__livemap_msg_3_0_i6);
BEGIN_CODE

/* code for predicate 'livemap_msg'/3 in mode 0 */
Define_entry(mercury__vn_debug__livemap_msg_3_0);
	MR_incr_sp_push_msg(2, "vn_debug:livemap_msg/3");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = (Integer) 25;
	call_localret(ENTRY(mercury__globals__io_lookup_int_option_4_0),
		mercury__vn_debug__livemap_msg_3_0_i2,
		ENTRY(mercury__vn_debug__livemap_msg_3_0));
Define_label(mercury__vn_debug__livemap_msg_3_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_debug__livemap_msg_3_0));
	r3 = ((Integer) r1 & (Integer) 256);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__vn_debug__livemap_msg_3_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__vn_debug__livemap_msg_3_0_i3);
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__opt_debug__dump_livemap_2_0),
		mercury__vn_debug__livemap_msg_3_0_i5,
		ENTRY(mercury__vn_debug__livemap_msg_3_0));
Define_label(mercury__vn_debug__livemap_msg_3_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_debug__livemap_msg_3_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) MR_string_const("\n\nLivemap:\n\n", 12);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__livemap_msg_3_0_i6,
		ENTRY(mercury__vn_debug__livemap_msg_3_0));
Define_label(mercury__vn_debug__livemap_msg_3_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_debug__livemap_msg_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__vn_debug__livemap_msg_3_0));
END_MODULE

Declare_entry(mercury__llds_out__output_instruction_3_0);

BEGIN_MODULE(vn_debug_module2)
	init_entry(mercury__vn_debug__fragment_msg_3_0);
	init_label(mercury__vn_debug__fragment_msg_3_0_i2);
	init_label(mercury__vn_debug__fragment_msg_3_0_i3);
	init_label(mercury__vn_debug__fragment_msg_3_0_i5);
	init_label(mercury__vn_debug__fragment_msg_3_0_i6);
BEGIN_CODE

/* code for predicate 'fragment_msg'/3 in mode 0 */
Define_entry(mercury__vn_debug__fragment_msg_3_0);
	MR_incr_sp_push_msg(2, "vn_debug:fragment_msg/3");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = (Integer) 25;
	call_localret(ENTRY(mercury__globals__io_lookup_int_option_4_0),
		mercury__vn_debug__fragment_msg_3_0_i2,
		ENTRY(mercury__vn_debug__fragment_msg_3_0));
Define_label(mercury__vn_debug__fragment_msg_3_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_debug__fragment_msg_3_0));
	r3 = ((Integer) r1 & (Integer) 2);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__vn_debug__fragment_msg_3_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__vn_debug__fragment_msg_3_0_i3);
	r1 = (Word) MR_string_const("\nin value_number__optimize_fragment starting at\n", 48);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__fragment_msg_3_0_i5,
		ENTRY(mercury__vn_debug__fragment_msg_3_0));
Define_label(mercury__vn_debug__fragment_msg_3_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_debug__fragment_msg_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__llds_out__output_instruction_3_0),
		mercury__vn_debug__fragment_msg_3_0_i6,
		ENTRY(mercury__vn_debug__fragment_msg_3_0));
Define_label(mercury__vn_debug__fragment_msg_3_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_debug__fragment_msg_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\n", 1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__vn_debug__fragment_msg_3_0));
END_MODULE


BEGIN_MODULE(vn_debug_module3)
	init_entry(mercury__vn_debug__failure_msg_4_0);
	init_label(mercury__vn_debug__failure_msg_4_0_i2);
	init_label(mercury__vn_debug__failure_msg_4_0_i3);
	init_label(mercury__vn_debug__failure_msg_4_0_i5);
	init_label(mercury__vn_debug__failure_msg_4_0_i6);
	init_label(mercury__vn_debug__failure_msg_4_0_i7);
	init_label(mercury__vn_debug__failure_msg_4_0_i8);
	init_label(mercury__vn_debug__failure_msg_4_0_i9);
	init_label(mercury__vn_debug__failure_msg_4_0_i10);
BEGIN_CODE

/* code for predicate 'failure_msg'/4 in mode 0 */
Define_entry(mercury__vn_debug__failure_msg_4_0);
	MR_incr_sp_push_msg(3, "vn_debug:failure_msg/4");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Integer) 25;
	r2 = r3;
	call_localret(ENTRY(mercury__globals__io_lookup_int_option_4_0),
		mercury__vn_debug__failure_msg_4_0_i2,
		ENTRY(mercury__vn_debug__failure_msg_4_0));
Define_label(mercury__vn_debug__failure_msg_4_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_debug__failure_msg_4_0));
	r3 = ((Integer) r1 & (Integer) 1);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__vn_debug__failure_msg_4_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_debug__failure_msg_4_0_i3);
	r1 = (Word) MR_string_const("FAILURE of VN consistency check ", 32);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__failure_msg_4_0_i5,
		ENTRY(mercury__vn_debug__failure_msg_4_0));
Define_label(mercury__vn_debug__failure_msg_4_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_debug__failure_msg_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const("in fragment starting at\n", 24);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__failure_msg_4_0_i6,
		ENTRY(mercury__vn_debug__failure_msg_4_0));
Define_label(mercury__vn_debug__failure_msg_4_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_debug__failure_msg_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__llds_out__output_instruction_3_0),
		mercury__vn_debug__failure_msg_4_0_i7,
		ENTRY(mercury__vn_debug__failure_msg_4_0));
Define_label(mercury__vn_debug__failure_msg_4_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_debug__failure_msg_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\n", 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__failure_msg_4_0_i8,
		ENTRY(mercury__vn_debug__failure_msg_4_0));
Define_label(mercury__vn_debug__failure_msg_4_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_debug__failure_msg_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const("Cause: ", 7);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__failure_msg_4_0_i9,
		ENTRY(mercury__vn_debug__failure_msg_4_0));
Define_label(mercury__vn_debug__failure_msg_4_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_debug__failure_msg_4_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__failure_msg_4_0_i10,
		ENTRY(mercury__vn_debug__failure_msg_4_0));
Define_label(mercury__vn_debug__failure_msg_4_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_debug__failure_msg_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\n", 1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__vn_debug__failure_msg_4_0));
END_MODULE


BEGIN_MODULE(vn_debug_module4)
	init_entry(mercury__vn_debug__parallel_msgs_3_0);
	init_label(mercury__vn_debug__parallel_msgs_3_0_i1001);
	init_label(mercury__vn_debug__parallel_msgs_3_0_i4);
	init_label(mercury__vn_debug__parallel_msgs_3_0_i3);
BEGIN_CODE

/* code for predicate 'parallel_msgs'/3 in mode 0 */
Define_entry(mercury__vn_debug__parallel_msgs_3_0);
	MR_incr_sp_push_msg(2, "vn_debug:parallel_msgs/3");
	MR_stackvar(2) = (Word) MR_succip;
Define_label(mercury__vn_debug__parallel_msgs_3_0_i1001);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_debug__parallel_msgs_3_0_i3);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	call_localret(STATIC(mercury__vn_debug__parallel_msg_3_0),
		mercury__vn_debug__parallel_msgs_3_0_i4,
		ENTRY(mercury__vn_debug__parallel_msgs_3_0));
Define_label(mercury__vn_debug__parallel_msgs_3_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_debug__parallel_msgs_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	GOTO_LABEL(mercury__vn_debug__parallel_msgs_3_0_i1001);
Define_label(mercury__vn_debug__parallel_msgs_3_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE

Declare_entry(mercury__opt_debug__dump_label_2_0);

BEGIN_MODULE(vn_debug_module5)
	init_entry(mercury__vn_debug__parallel_msg_3_0);
	init_label(mercury__vn_debug__parallel_msg_3_0_i2);
	init_label(mercury__vn_debug__parallel_msg_3_0_i3);
	init_label(mercury__vn_debug__parallel_msg_3_0_i5);
	init_label(mercury__vn_debug__parallel_msg_3_0_i6);
	init_label(mercury__vn_debug__parallel_msg_3_0_i7);
	init_label(mercury__vn_debug__parallel_msg_3_0_i8);
	init_label(mercury__vn_debug__parallel_msg_3_0_i9);
	init_label(mercury__vn_debug__parallel_msg_3_0_i10);
	init_label(mercury__vn_debug__parallel_msg_3_0_i11);
BEGIN_CODE

/* code for predicate 'parallel_msg'/3 in mode 0 */
Define_entry(mercury__vn_debug__parallel_msg_3_0);
	MR_incr_sp_push_msg(5, "vn_debug:parallel_msg/3");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	r1 = (Integer) 25;
	call_localret(ENTRY(mercury__globals__io_lookup_int_option_4_0),
		mercury__vn_debug__parallel_msg_3_0_i2,
		ENTRY(mercury__vn_debug__parallel_msg_3_0));
Define_label(mercury__vn_debug__parallel_msg_3_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_debug__parallel_msg_3_0));
	r3 = ((Integer) r1 & (Integer) 128);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__vn_debug__parallel_msg_3_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_debug__parallel_msg_3_0_i3);
	MR_stackvar(4) = r2;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__opt_debug__dump_label_2_0),
		mercury__vn_debug__parallel_msg_3_0_i5,
		ENTRY(mercury__vn_debug__parallel_msg_3_0));
Define_label(mercury__vn_debug__parallel_msg_3_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_debug__parallel_msg_3_0));
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__opt_debug__dump_label_2_0),
		mercury__vn_debug__parallel_msg_3_0_i6,
		ENTRY(mercury__vn_debug__parallel_msg_3_0));
Define_label(mercury__vn_debug__parallel_msg_3_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_debug__parallel_msg_3_0));
	MR_stackvar(2) = r1;
	r1 = (Word) MR_string_const("\nparallel from ", 15);
	r2 = MR_stackvar(4);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__parallel_msg_3_0_i7,
		ENTRY(mercury__vn_debug__parallel_msg_3_0));
Define_label(mercury__vn_debug__parallel_msg_3_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_debug__parallel_msg_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__parallel_msg_3_0_i8,
		ENTRY(mercury__vn_debug__parallel_msg_3_0));
Define_label(mercury__vn_debug__parallel_msg_3_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_debug__parallel_msg_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const(" to ", 4);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__parallel_msg_3_0_i9,
		ENTRY(mercury__vn_debug__parallel_msg_3_0));
Define_label(mercury__vn_debug__parallel_msg_3_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_debug__parallel_msg_3_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__parallel_msg_3_0_i10,
		ENTRY(mercury__vn_debug__parallel_msg_3_0));
Define_label(mercury__vn_debug__parallel_msg_3_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_debug__parallel_msg_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\n", 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__parallel_msg_3_0_i11,
		ENTRY(mercury__vn_debug__parallel_msg_3_0));
Define_label(mercury__vn_debug__parallel_msg_3_0_i11);
	update_prof_current_proc(LABEL(mercury__vn_debug__parallel_msg_3_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(STATIC(mercury__vn_debug__parentry_msg_3_0),
		ENTRY(mercury__vn_debug__parallel_msg_3_0));
END_MODULE


BEGIN_MODULE(vn_debug_module6)
	init_entry(mercury__vn_debug__computed_goto_msg_5_0);
	init_label(mercury__vn_debug__computed_goto_msg_5_0_i2);
	init_label(mercury__vn_debug__computed_goto_msg_5_0_i3);
	init_label(mercury__vn_debug__computed_goto_msg_5_0_i5);
	init_label(mercury__vn_debug__computed_goto_msg_5_0_i6);
	init_label(mercury__vn_debug__computed_goto_msg_5_0_i7);
	init_label(mercury__vn_debug__computed_goto_msg_5_0_i8);
	init_label(mercury__vn_debug__computed_goto_msg_5_0_i9);
	init_label(mercury__vn_debug__computed_goto_msg_5_0_i10);
BEGIN_CODE

/* code for predicate 'computed_goto_msg'/5 in mode 0 */
Define_entry(mercury__vn_debug__computed_goto_msg_5_0);
	MR_incr_sp_push_msg(4, "vn_debug:computed_goto_msg/5");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Integer) 25;
	r2 = r4;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__globals__io_lookup_int_option_4_0),
		mercury__vn_debug__computed_goto_msg_5_0_i2,
		ENTRY(mercury__vn_debug__computed_goto_msg_5_0));
Define_label(mercury__vn_debug__computed_goto_msg_5_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_debug__computed_goto_msg_5_0));
	r3 = ((Integer) r1 & (Integer) 128);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__vn_debug__computed_goto_msg_5_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__vn_debug__computed_goto_msg_5_0_i3);
	r1 = (Word) MR_string_const("computed goto labels:\n", 22);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__computed_goto_msg_5_0_i5,
		ENTRY(mercury__vn_debug__computed_goto_msg_5_0));
Define_label(mercury__vn_debug__computed_goto_msg_5_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_debug__computed_goto_msg_5_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(STATIC(mercury__vn_debug__dump_labels_3_0),
		mercury__vn_debug__computed_goto_msg_5_0_i6,
		ENTRY(mercury__vn_debug__computed_goto_msg_5_0));
Define_label(mercury__vn_debug__computed_goto_msg_5_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_debug__computed_goto_msg_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const("computed goto parallels:\n", 25);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__computed_goto_msg_5_0_i7,
		ENTRY(mercury__vn_debug__computed_goto_msg_5_0));
Define_label(mercury__vn_debug__computed_goto_msg_5_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_debug__computed_goto_msg_5_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(STATIC(mercury__vn_debug__dump_parallels_3_0),
		mercury__vn_debug__computed_goto_msg_5_0_i8,
		ENTRY(mercury__vn_debug__computed_goto_msg_5_0));
Define_label(mercury__vn_debug__computed_goto_msg_5_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_debug__computed_goto_msg_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const("computed goto pairs:\n", 21);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__computed_goto_msg_5_0_i9,
		ENTRY(mercury__vn_debug__computed_goto_msg_5_0));
Define_label(mercury__vn_debug__computed_goto_msg_5_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_debug__computed_goto_msg_5_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	call_localret(STATIC(mercury__vn_debug__dump_label_parallel_pairs_3_0),
		mercury__vn_debug__computed_goto_msg_5_0_i10,
		ENTRY(mercury__vn_debug__computed_goto_msg_5_0));
Define_label(mercury__vn_debug__computed_goto_msg_5_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_debug__computed_goto_msg_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const("computed goto message end\n", 26);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__vn_debug__computed_goto_msg_5_0));
END_MODULE

Declare_entry(mercury__opt_debug__dump_ctrlmap_2_0);
Declare_entry(mercury__opt_debug__dump_flushmap_2_0);
Declare_entry(mercury__opt_debug__dump_tables_2_0);

BEGIN_MODULE(vn_debug_module7)
	init_entry(mercury__vn_debug__order_start_msg_5_0);
	init_label(mercury__vn_debug__order_start_msg_5_0_i2);
	init_label(mercury__vn_debug__order_start_msg_5_0_i3);
	init_label(mercury__vn_debug__order_start_msg_5_0_i5);
	init_label(mercury__vn_debug__order_start_msg_5_0_i6);
	init_label(mercury__vn_debug__order_start_msg_5_0_i7);
	init_label(mercury__vn_debug__order_start_msg_5_0_i8);
	init_label(mercury__vn_debug__order_start_msg_5_0_i9);
	init_label(mercury__vn_debug__order_start_msg_5_0_i10);
	init_label(mercury__vn_debug__order_start_msg_5_0_i11);
BEGIN_CODE

/* code for predicate 'order_start_msg'/5 in mode 0 */
Define_entry(mercury__vn_debug__order_start_msg_5_0);
	MR_incr_sp_push_msg(5, "vn_debug:order_start_msg/5");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Integer) 25;
	r2 = r4;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__globals__io_lookup_int_option_4_0),
		mercury__vn_debug__order_start_msg_5_0_i2,
		ENTRY(mercury__vn_debug__order_start_msg_5_0));
Define_label(mercury__vn_debug__order_start_msg_5_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_start_msg_5_0));
	r3 = ((Integer) r1 & (Integer) 32);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__vn_debug__order_start_msg_5_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_debug__order_start_msg_5_0_i3);
	MR_stackvar(4) = r2;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__opt_debug__dump_ctrlmap_2_0),
		mercury__vn_debug__order_start_msg_5_0_i5,
		ENTRY(mercury__vn_debug__order_start_msg_5_0));
Define_label(mercury__vn_debug__order_start_msg_5_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_start_msg_5_0));
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__opt_debug__dump_flushmap_2_0),
		mercury__vn_debug__order_start_msg_5_0_i6,
		ENTRY(mercury__vn_debug__order_start_msg_5_0));
Define_label(mercury__vn_debug__order_start_msg_5_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_start_msg_5_0));
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__opt_debug__dump_tables_2_0),
		mercury__vn_debug__order_start_msg_5_0_i7,
		ENTRY(mercury__vn_debug__order_start_msg_5_0));
Define_label(mercury__vn_debug__order_start_msg_5_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_start_msg_5_0));
	MR_stackvar(3) = r1;
	r1 = (Word) MR_string_const("\n\n", 2);
	r2 = MR_stackvar(4);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__order_start_msg_5_0_i8,
		ENTRY(mercury__vn_debug__order_start_msg_5_0));
Define_label(mercury__vn_debug__order_start_msg_5_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_start_msg_5_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__order_start_msg_5_0_i9,
		ENTRY(mercury__vn_debug__order_start_msg_5_0));
Define_label(mercury__vn_debug__order_start_msg_5_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_start_msg_5_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__order_start_msg_5_0_i10,
		ENTRY(mercury__vn_debug__order_start_msg_5_0));
Define_label(mercury__vn_debug__order_start_msg_5_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_start_msg_5_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__order_start_msg_5_0_i11,
		ENTRY(mercury__vn_debug__order_start_msg_5_0));
Define_label(mercury__vn_debug__order_start_msg_5_0_i11);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_start_msg_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\n", 1);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__vn_debug__order_start_msg_5_0));
END_MODULE

Declare_entry(mercury__opt_debug__dump_node_2_0);

BEGIN_MODULE(vn_debug_module8)
	init_entry(mercury__vn_debug__order_sink_msg_3_0);
	init_label(mercury__vn_debug__order_sink_msg_3_0_i2);
	init_label(mercury__vn_debug__order_sink_msg_3_0_i3);
	init_label(mercury__vn_debug__order_sink_msg_3_0_i5);
	init_label(mercury__vn_debug__order_sink_msg_3_0_i6);
	init_label(mercury__vn_debug__order_sink_msg_3_0_i7);
BEGIN_CODE

/* code for predicate 'order_sink_msg'/3 in mode 0 */
Define_entry(mercury__vn_debug__order_sink_msg_3_0);
	MR_incr_sp_push_msg(2, "vn_debug:order_sink_msg/3");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = (Integer) 25;
	call_localret(ENTRY(mercury__globals__io_lookup_int_option_4_0),
		mercury__vn_debug__order_sink_msg_3_0_i2,
		ENTRY(mercury__vn_debug__order_sink_msg_3_0));
Define_label(mercury__vn_debug__order_sink_msg_3_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_sink_msg_3_0));
	r3 = ((Integer) r1 & (Integer) 64);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__vn_debug__order_sink_msg_3_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__vn_debug__order_sink_msg_3_0_i3);
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__opt_debug__dump_node_2_0),
		mercury__vn_debug__order_sink_msg_3_0_i5,
		ENTRY(mercury__vn_debug__order_sink_msg_3_0));
Define_label(mercury__vn_debug__order_sink_msg_3_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_sink_msg_3_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) MR_string_const("sink_before_redef for node ", 27);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__order_sink_msg_3_0_i6,
		ENTRY(mercury__vn_debug__order_sink_msg_3_0));
Define_label(mercury__vn_debug__order_sink_msg_3_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_sink_msg_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__order_sink_msg_3_0_i7,
		ENTRY(mercury__vn_debug__order_sink_msg_3_0));
Define_label(mercury__vn_debug__order_sink_msg_3_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_sink_msg_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\n", 1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__vn_debug__order_sink_msg_3_0));
END_MODULE


BEGIN_MODULE(vn_debug_module9)
	init_entry(mercury__vn_debug__order_link_msg_5_0);
	init_label(mercury__vn_debug__order_link_msg_5_0_i2);
	init_label(mercury__vn_debug__order_link_msg_5_0_i3);
	init_label(mercury__vn_debug__order_link_msg_5_0_i6);
	init_label(mercury__vn_debug__order_link_msg_5_0_i8);
	init_label(mercury__vn_debug__order_link_msg_5_0_i9);
	init_label(mercury__vn_debug__order_link_msg_5_0_i10);
	init_label(mercury__vn_debug__order_link_msg_5_0_i11);
	init_label(mercury__vn_debug__order_link_msg_5_0_i12);
	init_label(mercury__vn_debug__order_link_msg_5_0_i13);
BEGIN_CODE

/* code for predicate 'order_link_msg'/5 in mode 0 */
Define_entry(mercury__vn_debug__order_link_msg_5_0);
	MR_incr_sp_push_msg(4, "vn_debug:order_link_msg/5");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Integer) 25;
	r2 = r4;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__globals__io_lookup_int_option_4_0),
		mercury__vn_debug__order_link_msg_5_0_i2,
		ENTRY(mercury__vn_debug__order_link_msg_5_0));
Define_label(mercury__vn_debug__order_link_msg_5_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_link_msg_5_0));
	r3 = ((Integer) r1 & (Integer) 64);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__vn_debug__order_link_msg_5_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__vn_debug__order_link_msg_5_0_i3);
	if (((Integer) MR_stackvar(3) != (Integer) 0))
		GOTO_LABEL(mercury__vn_debug__order_link_msg_5_0_i6);
	r1 = (Word) MR_string_const("adding alias link from ", 23);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__order_link_msg_5_0_i8,
		ENTRY(mercury__vn_debug__order_link_msg_5_0));
Define_label(mercury__vn_debug__order_link_msg_5_0_i6);
	r1 = (Word) MR_string_const("adding user link from ", 22);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__order_link_msg_5_0_i8,
		ENTRY(mercury__vn_debug__order_link_msg_5_0));
Define_label(mercury__vn_debug__order_link_msg_5_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_link_msg_5_0));
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__opt_debug__dump_node_2_0),
		mercury__vn_debug__order_link_msg_5_0_i9,
		ENTRY(mercury__vn_debug__order_link_msg_5_0));
Define_label(mercury__vn_debug__order_link_msg_5_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_link_msg_5_0));
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__opt_debug__dump_node_2_0),
		mercury__vn_debug__order_link_msg_5_0_i10,
		ENTRY(mercury__vn_debug__order_link_msg_5_0));
Define_label(mercury__vn_debug__order_link_msg_5_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_link_msg_5_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__order_link_msg_5_0_i11,
		ENTRY(mercury__vn_debug__order_link_msg_5_0));
Define_label(mercury__vn_debug__order_link_msg_5_0_i11);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_link_msg_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const(" to ", 4);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__order_link_msg_5_0_i12,
		ENTRY(mercury__vn_debug__order_link_msg_5_0));
Define_label(mercury__vn_debug__order_link_msg_5_0_i12);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_link_msg_5_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__order_link_msg_5_0_i13,
		ENTRY(mercury__vn_debug__order_link_msg_5_0));
Define_label(mercury__vn_debug__order_link_msg_5_0_i13);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_link_msg_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\n", 1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__vn_debug__order_link_msg_5_0));
END_MODULE


BEGIN_MODULE(vn_debug_module10)
	init_entry(mercury__vn_debug__order_antidep_msg_4_0);
	init_label(mercury__vn_debug__order_antidep_msg_4_0_i2);
	init_label(mercury__vn_debug__order_antidep_msg_4_0_i3);
	init_label(mercury__vn_debug__order_antidep_msg_4_0_i5);
	init_label(mercury__vn_debug__order_antidep_msg_4_0_i6);
	init_label(mercury__vn_debug__order_antidep_msg_4_0_i7);
	init_label(mercury__vn_debug__order_antidep_msg_4_0_i8);
	init_label(mercury__vn_debug__order_antidep_msg_4_0_i9);
	init_label(mercury__vn_debug__order_antidep_msg_4_0_i10);
BEGIN_CODE

/* code for predicate 'order_antidep_msg'/4 in mode 0 */
Define_entry(mercury__vn_debug__order_antidep_msg_4_0);
	MR_incr_sp_push_msg(3, "vn_debug:order_antidep_msg/4");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Integer) 25;
	r2 = r3;
	call_localret(ENTRY(mercury__globals__io_lookup_int_option_4_0),
		mercury__vn_debug__order_antidep_msg_4_0_i2,
		ENTRY(mercury__vn_debug__order_antidep_msg_4_0));
Define_label(mercury__vn_debug__order_antidep_msg_4_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_antidep_msg_4_0));
	r3 = ((Integer) r1 & (Integer) 64);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__vn_debug__order_antidep_msg_4_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_debug__order_antidep_msg_4_0_i3);
	r1 = (Word) MR_string_const("anti dependency from ", 21);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__order_antidep_msg_4_0_i5,
		ENTRY(mercury__vn_debug__order_antidep_msg_4_0));
Define_label(mercury__vn_debug__order_antidep_msg_4_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_antidep_msg_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__opt_debug__dump_node_2_0),
		mercury__vn_debug__order_antidep_msg_4_0_i6,
		ENTRY(mercury__vn_debug__order_antidep_msg_4_0));
Define_label(mercury__vn_debug__order_antidep_msg_4_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_antidep_msg_4_0));
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__order_antidep_msg_4_0_i7,
		ENTRY(mercury__vn_debug__order_antidep_msg_4_0));
Define_label(mercury__vn_debug__order_antidep_msg_4_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_antidep_msg_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const(" to ", 4);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__order_antidep_msg_4_0_i8,
		ENTRY(mercury__vn_debug__order_antidep_msg_4_0));
Define_label(mercury__vn_debug__order_antidep_msg_4_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_antidep_msg_4_0));
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__opt_debug__dump_node_2_0),
		mercury__vn_debug__order_antidep_msg_4_0_i9,
		ENTRY(mercury__vn_debug__order_antidep_msg_4_0));
Define_label(mercury__vn_debug__order_antidep_msg_4_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_antidep_msg_4_0));
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__order_antidep_msg_4_0_i10,
		ENTRY(mercury__vn_debug__order_antidep_msg_4_0));
Define_label(mercury__vn_debug__order_antidep_msg_4_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_antidep_msg_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\n", 1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__vn_debug__order_antidep_msg_4_0));
END_MODULE

Declare_entry(mercury__opt_debug__dump_node_relmap_2_0);

BEGIN_MODULE(vn_debug_module11)
	init_entry(mercury__vn_debug__order_map_msg_6_0);
	init_label(mercury__vn_debug__order_map_msg_6_0_i2);
	init_label(mercury__vn_debug__order_map_msg_6_0_i3);
	init_label(mercury__vn_debug__order_map_msg_6_0_i5);
	init_label(mercury__vn_debug__order_map_msg_6_0_i6);
	init_label(mercury__vn_debug__order_map_msg_6_0_i7);
	init_label(mercury__vn_debug__order_map_msg_6_0_i8);
	init_label(mercury__vn_debug__order_map_msg_6_0_i9);
	init_label(mercury__vn_debug__order_map_msg_6_0_i10);
	init_label(mercury__vn_debug__order_map_msg_6_0_i11);
	init_label(mercury__vn_debug__order_map_msg_6_0_i12);
	init_label(mercury__vn_debug__order_map_msg_6_0_i13);
	init_label(mercury__vn_debug__order_map_msg_6_0_i14);
	init_label(mercury__vn_debug__order_map_msg_6_0_i15);
BEGIN_CODE

/* code for predicate 'order_map_msg'/6 in mode 0 */
Define_entry(mercury__vn_debug__order_map_msg_6_0);
	MR_incr_sp_push_msg(6, "vn_debug:order_map_msg/6");
	MR_stackvar(6) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Integer) 25;
	r2 = r5;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	call_localret(ENTRY(mercury__globals__io_lookup_int_option_4_0),
		mercury__vn_debug__order_map_msg_6_0_i2,
		ENTRY(mercury__vn_debug__order_map_msg_6_0));
Define_label(mercury__vn_debug__order_map_msg_6_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_map_msg_6_0));
	r3 = ((Integer) r1 & (Integer) 16);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__vn_debug__order_map_msg_6_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__vn_debug__order_map_msg_6_0_i3);
	MR_stackvar(5) = r2;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__opt_debug__dump_node_relmap_2_0),
		mercury__vn_debug__order_map_msg_6_0_i5,
		ENTRY(mercury__vn_debug__order_map_msg_6_0));
Define_label(mercury__vn_debug__order_map_msg_6_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_map_msg_6_0));
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__opt_debug__dump_node_relmap_2_0),
		mercury__vn_debug__order_map_msg_6_0_i6,
		ENTRY(mercury__vn_debug__order_map_msg_6_0));
Define_label(mercury__vn_debug__order_map_msg_6_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_map_msg_6_0));
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__opt_debug__dump_node_relmap_2_0),
		mercury__vn_debug__order_map_msg_6_0_i7,
		ENTRY(mercury__vn_debug__order_map_msg_6_0));
Define_label(mercury__vn_debug__order_map_msg_6_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_map_msg_6_0));
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__opt_debug__dump_node_relmap_2_0),
		mercury__vn_debug__order_map_msg_6_0_i8,
		ENTRY(mercury__vn_debug__order_map_msg_6_0));
Define_label(mercury__vn_debug__order_map_msg_6_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_map_msg_6_0));
	MR_stackvar(4) = r1;
	r1 = (Word) MR_string_const("\nMustSuccmap:\n", 14);
	r2 = MR_stackvar(5);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__order_map_msg_6_0_i9,
		ENTRY(mercury__vn_debug__order_map_msg_6_0));
Define_label(mercury__vn_debug__order_map_msg_6_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_map_msg_6_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__order_map_msg_6_0_i10,
		ENTRY(mercury__vn_debug__order_map_msg_6_0));
Define_label(mercury__vn_debug__order_map_msg_6_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_map_msg_6_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\nMustPredmap:\n", 14);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__order_map_msg_6_0_i11,
		ENTRY(mercury__vn_debug__order_map_msg_6_0));
Define_label(mercury__vn_debug__order_map_msg_6_0_i11);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_map_msg_6_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__order_map_msg_6_0_i12,
		ENTRY(mercury__vn_debug__order_map_msg_6_0));
Define_label(mercury__vn_debug__order_map_msg_6_0_i12);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_map_msg_6_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\nSuccmap:\n", 10);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__order_map_msg_6_0_i13,
		ENTRY(mercury__vn_debug__order_map_msg_6_0));
Define_label(mercury__vn_debug__order_map_msg_6_0_i13);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_map_msg_6_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__order_map_msg_6_0_i14,
		ENTRY(mercury__vn_debug__order_map_msg_6_0));
Define_label(mercury__vn_debug__order_map_msg_6_0_i14);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_map_msg_6_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\nPredmap:\n", 10);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__order_map_msg_6_0_i15,
		ENTRY(mercury__vn_debug__order_map_msg_6_0));
Define_label(mercury__vn_debug__order_map_msg_6_0_i15);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_map_msg_6_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__vn_debug__order_map_msg_6_0));
END_MODULE

Declare_entry(mercury__opt_debug__dump_longnodelist_2_0);

BEGIN_MODULE(vn_debug_module12)
	init_entry(mercury__vn_debug__order_order_msg_3_0);
	init_label(mercury__vn_debug__order_order_msg_3_0_i2);
	init_label(mercury__vn_debug__order_order_msg_3_0_i3);
	init_label(mercury__vn_debug__order_order_msg_3_0_i5);
	init_label(mercury__vn_debug__order_order_msg_3_0_i6);
	init_label(mercury__vn_debug__order_order_msg_3_0_i7);
BEGIN_CODE

/* code for predicate 'order_order_msg'/3 in mode 0 */
Define_entry(mercury__vn_debug__order_order_msg_3_0);
	MR_incr_sp_push_msg(2, "vn_debug:order_order_msg/3");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = (Integer) 25;
	call_localret(ENTRY(mercury__globals__io_lookup_int_option_4_0),
		mercury__vn_debug__order_order_msg_3_0_i2,
		ENTRY(mercury__vn_debug__order_order_msg_3_0));
Define_label(mercury__vn_debug__order_order_msg_3_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_order_msg_3_0));
	r3 = ((Integer) r1 & (Integer) 32);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__vn_debug__order_order_msg_3_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__vn_debug__order_order_msg_3_0_i3);
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__opt_debug__dump_longnodelist_2_0),
		mercury__vn_debug__order_order_msg_3_0_i5,
		ENTRY(mercury__vn_debug__order_order_msg_3_0));
Define_label(mercury__vn_debug__order_order_msg_3_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_order_msg_3_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) MR_string_const("\nOrder:\n", 8);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__order_order_msg_3_0_i6,
		ENTRY(mercury__vn_debug__order_order_msg_3_0));
Define_label(mercury__vn_debug__order_order_msg_3_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_order_msg_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__order_order_msg_3_0_i7,
		ENTRY(mercury__vn_debug__order_order_msg_3_0));
Define_label(mercury__vn_debug__order_order_msg_3_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_order_msg_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\n", 1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__vn_debug__order_order_msg_3_0));
END_MODULE

Declare_entry(mercury__opt_debug__dump_nodelist_2_0);

BEGIN_MODULE(vn_debug_module13)
	init_entry(mercury__vn_debug__order_equals_msg_4_0);
	init_label(mercury__vn_debug__order_equals_msg_4_0_i2);
	init_label(mercury__vn_debug__order_equals_msg_4_0_i3);
	init_label(mercury__vn_debug__order_equals_msg_4_0_i5);
	init_label(mercury__vn_debug__order_equals_msg_4_0_i6);
	init_label(mercury__vn_debug__order_equals_msg_4_0_i7);
BEGIN_CODE

/* code for predicate 'order_equals_msg'/4 in mode 0 */
Define_entry(mercury__vn_debug__order_equals_msg_4_0);
	MR_incr_sp_push_msg(3, "vn_debug:order_equals_msg/4");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Integer) 25;
	r2 = r3;
	call_localret(ENTRY(mercury__globals__io_lookup_int_option_4_0),
		mercury__vn_debug__order_equals_msg_4_0_i2,
		ENTRY(mercury__vn_debug__order_equals_msg_4_0));
Define_label(mercury__vn_debug__order_equals_msg_4_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_equals_msg_4_0));
	r3 = ((Integer) r1 & (Integer) 32);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__vn_debug__order_equals_msg_4_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_debug__order_equals_msg_4_0_i3);
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__opt_debug__dump_nodelist_2_0),
		mercury__vn_debug__order_equals_msg_4_0_i5,
		ENTRY(mercury__vn_debug__order_equals_msg_4_0));
Define_label(mercury__vn_debug__order_equals_msg_4_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_equals_msg_4_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__order_equals_msg_4_0_i6,
		ENTRY(mercury__vn_debug__order_equals_msg_4_0));
Define_label(mercury__vn_debug__order_equals_msg_4_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_equals_msg_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__order_equals_msg_4_0_i7,
		ENTRY(mercury__vn_debug__order_equals_msg_4_0));
Define_label(mercury__vn_debug__order_equals_msg_4_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_debug__order_equals_msg_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\n", 1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__vn_debug__order_equals_msg_4_0));
END_MODULE

Declare_entry(mercury__opt_debug__msg_4_0);

BEGIN_MODULE(vn_debug_module14)
	init_entry(mercury__vn_debug__cost_header_msg_3_0);
	init_label(mercury__vn_debug__cost_header_msg_3_0_i2);
	init_label(mercury__vn_debug__cost_header_msg_3_0_i3);
BEGIN_CODE

/* code for predicate 'cost_header_msg'/3 in mode 0 */
Define_entry(mercury__vn_debug__cost_header_msg_3_0);
	MR_incr_sp_push_msg(2, "vn_debug:cost_header_msg/3");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = (Integer) 25;
	call_localret(ENTRY(mercury__globals__io_lookup_int_option_4_0),
		mercury__vn_debug__cost_header_msg_3_0_i2,
		ENTRY(mercury__vn_debug__cost_header_msg_3_0));
Define_label(mercury__vn_debug__cost_header_msg_3_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_debug__cost_header_msg_3_0));
	r3 = ((Integer) r1 & (Integer) 8);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__vn_debug__cost_header_msg_3_0_i3);
	r3 = r2;
	r1 = (Integer) 0;
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__opt_debug__msg_4_0),
		ENTRY(mercury__vn_debug__cost_header_msg_3_0));
Define_label(mercury__vn_debug__cost_header_msg_3_0_i3);
	r3 = r2;
	r1 = (Integer) 1;
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__opt_debug__msg_4_0),
		ENTRY(mercury__vn_debug__cost_header_msg_3_0));
END_MODULE

Declare_entry(mercury__string__int_to_string_2_0);

BEGIN_MODULE(vn_debug_module15)
	init_entry(mercury__vn_debug__cost_msg_5_0);
	init_label(mercury__vn_debug__cost_msg_5_0_i2);
	init_label(mercury__vn_debug__cost_msg_5_0_i3);
	init_label(mercury__vn_debug__cost_msg_5_0_i5);
	init_label(mercury__vn_debug__cost_msg_5_0_i6);
	init_label(mercury__vn_debug__cost_msg_5_0_i7);
	init_label(mercury__vn_debug__cost_msg_5_0_i8);
	init_label(mercury__vn_debug__cost_msg_5_0_i9);
	init_label(mercury__vn_debug__cost_msg_5_0_i10);
	init_label(mercury__vn_debug__cost_msg_5_0_i11);
	init_label(mercury__vn_debug__cost_msg_5_0_i12);
	init_label(mercury__vn_debug__cost_msg_5_0_i13);
	init_label(mercury__vn_debug__cost_msg_5_0_i14);
	init_label(mercury__vn_debug__cost_msg_5_0_i16);
	init_label(mercury__vn_debug__cost_msg_5_0_i18);
BEGIN_CODE

/* code for predicate 'cost_msg'/5 in mode 0 */
Define_entry(mercury__vn_debug__cost_msg_5_0);
	MR_incr_sp_push_msg(6, "vn_debug:cost_msg/5");
	MR_stackvar(6) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Integer) 25;
	r2 = r4;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__globals__io_lookup_int_option_4_0),
		mercury__vn_debug__cost_msg_5_0_i2,
		ENTRY(mercury__vn_debug__cost_msg_5_0));
Define_label(mercury__vn_debug__cost_msg_5_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_debug__cost_msg_5_0));
	r3 = ((Integer) r1 & (Integer) 8);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__vn_debug__cost_msg_5_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__vn_debug__cost_msg_5_0_i3);
	MR_stackvar(5) = r2;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__vn_debug__cost_msg_5_0_i5,
		ENTRY(mercury__vn_debug__cost_msg_5_0));
Define_label(mercury__vn_debug__cost_msg_5_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_debug__cost_msg_5_0));
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__vn_debug__cost_msg_5_0_i6,
		ENTRY(mercury__vn_debug__cost_msg_5_0));
Define_label(mercury__vn_debug__cost_msg_5_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_debug__cost_msg_5_0));
	r2 = MR_stackvar(5);
	MR_stackvar(5) = r1;
	r1 = (Word) MR_string_const("\n", 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__cost_msg_5_0_i7,
		ENTRY(mercury__vn_debug__cost_msg_5_0));
Define_label(mercury__vn_debug__cost_msg_5_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_debug__cost_msg_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const("Old cost: ", 10);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__cost_msg_5_0_i8,
		ENTRY(mercury__vn_debug__cost_msg_5_0));
Define_label(mercury__vn_debug__cost_msg_5_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_debug__cost_msg_5_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__cost_msg_5_0_i9,
		ENTRY(mercury__vn_debug__cost_msg_5_0));
Define_label(mercury__vn_debug__cost_msg_5_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_debug__cost_msg_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\n", 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__cost_msg_5_0_i10,
		ENTRY(mercury__vn_debug__cost_msg_5_0));
Define_label(mercury__vn_debug__cost_msg_5_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_debug__cost_msg_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const("New cost: ", 10);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__cost_msg_5_0_i11,
		ENTRY(mercury__vn_debug__cost_msg_5_0));
Define_label(mercury__vn_debug__cost_msg_5_0_i11);
	update_prof_current_proc(LABEL(mercury__vn_debug__cost_msg_5_0));
	r2 = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__cost_msg_5_0_i12,
		ENTRY(mercury__vn_debug__cost_msg_5_0));
Define_label(mercury__vn_debug__cost_msg_5_0_i12);
	update_prof_current_proc(LABEL(mercury__vn_debug__cost_msg_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\n", 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__cost_msg_5_0_i13,
		ENTRY(mercury__vn_debug__cost_msg_5_0));
Define_label(mercury__vn_debug__cost_msg_5_0_i13);
	update_prof_current_proc(LABEL(mercury__vn_debug__cost_msg_5_0));
	if (((Integer) MR_stackvar(3) >= (Integer) MR_stackvar(2)))
		GOTO_LABEL(mercury__vn_debug__cost_msg_5_0_i14);
	r2 = r1;
	r1 = (Word) MR_string_const("Result: cost improvement\n", 25);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__cost_msg_5_0_i16,
		ENTRY(mercury__vn_debug__cost_msg_5_0));
Define_label(mercury__vn_debug__cost_msg_5_0_i14);
	r2 = r1;
	r1 = (Word) MR_string_const("Result: no cost improvement\n", 28);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__cost_msg_5_0_i16,
		ENTRY(mercury__vn_debug__cost_msg_5_0));
Define_label(mercury__vn_debug__cost_msg_5_0_i16);
	update_prof_current_proc(LABEL(mercury__vn_debug__cost_msg_5_0));
	r2 = r1;
	if (((Integer) MR_stackvar(1) != (Integer) 1))
		GOTO_LABEL(mercury__vn_debug__cost_msg_5_0_i18);
	r1 = (Word) MR_string_const("Used: yes\n", 10);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__vn_debug__cost_msg_5_0));
Define_label(mercury__vn_debug__cost_msg_5_0_i18);
	r1 = (Word) MR_string_const("Used: no\n", 9);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__vn_debug__cost_msg_5_0));
END_MODULE


BEGIN_MODULE(vn_debug_module16)
	init_entry(mercury__vn_debug__cost_detail_msg_5_0);
	init_label(mercury__vn_debug__cost_detail_msg_5_0_i2);
	init_label(mercury__vn_debug__cost_detail_msg_5_0_i3);
	init_label(mercury__vn_debug__cost_detail_msg_5_0_i5);
	init_label(mercury__vn_debug__cost_detail_msg_5_0_i6);
	init_label(mercury__vn_debug__cost_detail_msg_5_0_i7);
	init_label(mercury__vn_debug__cost_detail_msg_5_0_i8);
	init_label(mercury__vn_debug__cost_detail_msg_5_0_i9);
	init_label(mercury__vn_debug__cost_detail_msg_5_0_i10);
BEGIN_CODE

/* code for predicate 'cost_detail_msg'/5 in mode 0 */
Define_entry(mercury__vn_debug__cost_detail_msg_5_0);
	MR_incr_sp_push_msg(5, "vn_debug:cost_detail_msg/5");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Integer) 25;
	r2 = r4;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__globals__io_lookup_int_option_4_0),
		mercury__vn_debug__cost_detail_msg_5_0_i2,
		ENTRY(mercury__vn_debug__cost_detail_msg_5_0));
Define_label(mercury__vn_debug__cost_detail_msg_5_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_debug__cost_detail_msg_5_0));
	r3 = ((Integer) r1 & (Integer) 8);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__vn_debug__cost_detail_msg_5_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_debug__cost_detail_msg_5_0_i3);
	MR_stackvar(4) = r2;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__vn_debug__cost_detail_msg_5_0_i5,
		ENTRY(mercury__vn_debug__cost_detail_msg_5_0));
Define_label(mercury__vn_debug__cost_detail_msg_5_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_debug__cost_detail_msg_5_0));
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__string__int_to_string_2_0),
		mercury__vn_debug__cost_detail_msg_5_0_i6,
		ENTRY(mercury__vn_debug__cost_detail_msg_5_0));
Define_label(mercury__vn_debug__cost_detail_msg_5_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_debug__cost_detail_msg_5_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r3;
	r2 = MR_stackvar(4);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__cost_detail_msg_5_0_i7,
		ENTRY(mercury__vn_debug__cost_detail_msg_5_0));
Define_label(mercury__vn_debug__cost_detail_msg_5_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_debug__cost_detail_msg_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\t", 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__cost_detail_msg_5_0_i8,
		ENTRY(mercury__vn_debug__cost_detail_msg_5_0));
Define_label(mercury__vn_debug__cost_detail_msg_5_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_debug__cost_detail_msg_5_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__cost_detail_msg_5_0_i9,
		ENTRY(mercury__vn_debug__cost_detail_msg_5_0));
Define_label(mercury__vn_debug__cost_detail_msg_5_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_debug__cost_detail_msg_5_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\t", 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__cost_detail_msg_5_0_i10,
		ENTRY(mercury__vn_debug__cost_detail_msg_5_0));
Define_label(mercury__vn_debug__cost_detail_msg_5_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_debug__cost_detail_msg_5_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury__llds_out__output_instruction_3_0),
		ENTRY(mercury__vn_debug__cost_detail_msg_5_0));
END_MODULE

Declare_entry(mercury__opt_debug__dump_fullinstr_2_0);

BEGIN_MODULE(vn_debug_module17)
	init_entry(mercury__vn_debug__restart_msg_3_0);
	init_label(mercury__vn_debug__restart_msg_3_0_i2);
	init_label(mercury__vn_debug__restart_msg_3_0_i3);
	init_label(mercury__vn_debug__restart_msg_3_0_i5);
	init_label(mercury__vn_debug__restart_msg_3_0_i6);
	init_label(mercury__vn_debug__restart_msg_3_0_i7);
BEGIN_CODE

/* code for predicate 'restart_msg'/3 in mode 0 */
Define_entry(mercury__vn_debug__restart_msg_3_0);
	MR_incr_sp_push_msg(2, "vn_debug:restart_msg/3");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = (Integer) 25;
	call_localret(ENTRY(mercury__globals__io_lookup_int_option_4_0),
		mercury__vn_debug__restart_msg_3_0_i2,
		ENTRY(mercury__vn_debug__restart_msg_3_0));
Define_label(mercury__vn_debug__restart_msg_3_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_debug__restart_msg_3_0));
	r3 = ((Integer) r1 & (Integer) 2);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__vn_debug__restart_msg_3_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__vn_debug__restart_msg_3_0_i3);
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__opt_debug__dump_fullinstr_2_0),
		mercury__vn_debug__restart_msg_3_0_i5,
		ENTRY(mercury__vn_debug__restart_msg_3_0));
Define_label(mercury__vn_debug__restart_msg_3_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_debug__restart_msg_3_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) MR_string_const("starting again at ", 18);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__restart_msg_3_0_i6,
		ENTRY(mercury__vn_debug__restart_msg_3_0));
Define_label(mercury__vn_debug__restart_msg_3_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_debug__restart_msg_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__restart_msg_3_0_i7,
		ENTRY(mercury__vn_debug__restart_msg_3_0));
Define_label(mercury__vn_debug__restart_msg_3_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_debug__restart_msg_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\n", 1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__vn_debug__restart_msg_3_0));
END_MODULE


BEGIN_MODULE(vn_debug_module18)
	init_entry(mercury__vn_debug__divide_msg_3_0);
	init_label(mercury__vn_debug__divide_msg_3_0_i2);
	init_label(mercury__vn_debug__divide_msg_3_0_i3);
	init_label(mercury__vn_debug__divide_msg_3_0_i5);
	init_label(mercury__vn_debug__divide_msg_3_0_i6);
	init_label(mercury__vn_debug__divide_msg_3_0_i7);
BEGIN_CODE

/* code for predicate 'divide_msg'/3 in mode 0 */
Define_entry(mercury__vn_debug__divide_msg_3_0);
	MR_incr_sp_push_msg(2, "vn_debug:divide_msg/3");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = (Integer) 25;
	call_localret(ENTRY(mercury__globals__io_lookup_int_option_4_0),
		mercury__vn_debug__divide_msg_3_0_i2,
		ENTRY(mercury__vn_debug__divide_msg_3_0));
Define_label(mercury__vn_debug__divide_msg_3_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_debug__divide_msg_3_0));
	r3 = ((Integer) r1 & (Integer) 2);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__vn_debug__divide_msg_3_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__vn_debug__divide_msg_3_0_i3);
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__opt_debug__dump_fullinstr_2_0),
		mercury__vn_debug__divide_msg_3_0_i5,
		ENTRY(mercury__vn_debug__divide_msg_3_0));
Define_label(mercury__vn_debug__divide_msg_3_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_debug__divide_msg_3_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) MR_string_const("dividing the block at ", 22);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__divide_msg_3_0_i6,
		ENTRY(mercury__vn_debug__divide_msg_3_0));
Define_label(mercury__vn_debug__divide_msg_3_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_debug__divide_msg_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__divide_msg_3_0_i7,
		ENTRY(mercury__vn_debug__divide_msg_3_0));
Define_label(mercury__vn_debug__divide_msg_3_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_debug__divide_msg_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\n", 1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__vn_debug__divide_msg_3_0));
END_MODULE


BEGIN_MODULE(vn_debug_module19)
	init_entry(mercury__vn_debug__flush_start_msg_3_0);
	init_label(mercury__vn_debug__flush_start_msg_3_0_i2);
	init_label(mercury__vn_debug__flush_start_msg_3_0_i3);
	init_label(mercury__vn_debug__flush_start_msg_3_0_i5);
	init_label(mercury__vn_debug__flush_start_msg_3_0_i6);
	init_label(mercury__vn_debug__flush_start_msg_3_0_i7);
BEGIN_CODE

/* code for predicate 'flush_start_msg'/3 in mode 0 */
Define_entry(mercury__vn_debug__flush_start_msg_3_0);
	MR_incr_sp_push_msg(2, "vn_debug:flush_start_msg/3");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = (Integer) 25;
	call_localret(ENTRY(mercury__globals__io_lookup_int_option_4_0),
		mercury__vn_debug__flush_start_msg_3_0_i2,
		ENTRY(mercury__vn_debug__flush_start_msg_3_0));
Define_label(mercury__vn_debug__flush_start_msg_3_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_debug__flush_start_msg_3_0));
	r3 = ((Integer) r1 & (Integer) 4);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__vn_debug__flush_start_msg_3_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__vn_debug__flush_start_msg_3_0_i3);
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__opt_debug__dump_node_2_0),
		mercury__vn_debug__flush_start_msg_3_0_i5,
		ENTRY(mercury__vn_debug__flush_start_msg_3_0));
Define_label(mercury__vn_debug__flush_start_msg_3_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_debug__flush_start_msg_3_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) MR_string_const("\nat node ", 9);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__flush_start_msg_3_0_i6,
		ENTRY(mercury__vn_debug__flush_start_msg_3_0));
Define_label(mercury__vn_debug__flush_start_msg_3_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_debug__flush_start_msg_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__flush_start_msg_3_0_i7,
		ENTRY(mercury__vn_debug__flush_start_msg_3_0));
Define_label(mercury__vn_debug__flush_start_msg_3_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_debug__flush_start_msg_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\n", 1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__vn_debug__flush_start_msg_3_0));
END_MODULE

Declare_entry(mercury__opt_debug__dump_vnlval_2_0);

BEGIN_MODULE(vn_debug_module20)
	init_entry(mercury__vn_debug__flush_also_msg_3_0);
	init_label(mercury__vn_debug__flush_also_msg_3_0_i2);
	init_label(mercury__vn_debug__flush_also_msg_3_0_i3);
	init_label(mercury__vn_debug__flush_also_msg_3_0_i5);
	init_label(mercury__vn_debug__flush_also_msg_3_0_i6);
	init_label(mercury__vn_debug__flush_also_msg_3_0_i7);
BEGIN_CODE

/* code for predicate 'flush_also_msg'/3 in mode 0 */
Define_entry(mercury__vn_debug__flush_also_msg_3_0);
	MR_incr_sp_push_msg(2, "vn_debug:flush_also_msg/3");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = (Integer) 25;
	call_localret(ENTRY(mercury__globals__io_lookup_int_option_4_0),
		mercury__vn_debug__flush_also_msg_3_0_i2,
		ENTRY(mercury__vn_debug__flush_also_msg_3_0));
Define_label(mercury__vn_debug__flush_also_msg_3_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_debug__flush_also_msg_3_0));
	r3 = ((Integer) r1 & (Integer) 4);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__vn_debug__flush_also_msg_3_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__vn_debug__flush_also_msg_3_0_i3);
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__opt_debug__dump_vnlval_2_0),
		mercury__vn_debug__flush_also_msg_3_0_i5,
		ENTRY(mercury__vn_debug__flush_also_msg_3_0));
Define_label(mercury__vn_debug__flush_also_msg_3_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_debug__flush_also_msg_3_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) MR_string_const("took care of node_lval for ", 27);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__flush_also_msg_3_0_i6,
		ENTRY(mercury__vn_debug__flush_also_msg_3_0));
Define_label(mercury__vn_debug__flush_also_msg_3_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_debug__flush_also_msg_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__flush_also_msg_3_0_i7,
		ENTRY(mercury__vn_debug__flush_also_msg_3_0));
Define_label(mercury__vn_debug__flush_also_msg_3_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_debug__flush_also_msg_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\n", 1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__vn_debug__flush_also_msg_3_0));
END_MODULE

Declare_entry(mercury__opt_debug__dump_fullinstrs_2_0);
Declare_entry(mercury__opt_debug__dump_useful_vns_2_0);

BEGIN_MODULE(vn_debug_module21)
	init_entry(mercury__vn_debug__flush_end_msg_4_0);
	init_label(mercury__vn_debug__flush_end_msg_4_0_i2);
	init_label(mercury__vn_debug__flush_end_msg_4_0_i3);
	init_label(mercury__vn_debug__flush_end_msg_4_0_i5);
	init_label(mercury__vn_debug__flush_end_msg_4_0_i6);
	init_label(mercury__vn_debug__flush_end_msg_4_0_i7);
	init_label(mercury__vn_debug__flush_end_msg_4_0_i8);
	init_label(mercury__vn_debug__flush_end_msg_4_0_i9);
BEGIN_CODE

/* code for predicate 'flush_end_msg'/4 in mode 0 */
Define_entry(mercury__vn_debug__flush_end_msg_4_0);
	MR_incr_sp_push_msg(4, "vn_debug:flush_end_msg/4");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Integer) 25;
	r2 = r3;
	call_localret(ENTRY(mercury__globals__io_lookup_int_option_4_0),
		mercury__vn_debug__flush_end_msg_4_0_i2,
		ENTRY(mercury__vn_debug__flush_end_msg_4_0));
Define_label(mercury__vn_debug__flush_end_msg_4_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_debug__flush_end_msg_4_0));
	r3 = ((Integer) r1 & (Integer) 4);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__vn_debug__flush_end_msg_4_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__vn_debug__flush_end_msg_4_0_i3);
	MR_stackvar(3) = r2;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__opt_debug__dump_fullinstrs_2_0),
		mercury__vn_debug__flush_end_msg_4_0_i5,
		ENTRY(mercury__vn_debug__flush_end_msg_4_0));
Define_label(mercury__vn_debug__flush_end_msg_4_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_debug__flush_end_msg_4_0));
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__opt_debug__dump_useful_vns_2_0),
		mercury__vn_debug__flush_end_msg_4_0_i6,
		ENTRY(mercury__vn_debug__flush_end_msg_4_0));
Define_label(mercury__vn_debug__flush_end_msg_4_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_debug__flush_end_msg_4_0));
	MR_stackvar(2) = r1;
	r1 = (Word) MR_string_const("generated instrs:\n", 18);
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__flush_end_msg_4_0_i7,
		ENTRY(mercury__vn_debug__flush_end_msg_4_0));
Define_label(mercury__vn_debug__flush_end_msg_4_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_debug__flush_end_msg_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__flush_end_msg_4_0_i8,
		ENTRY(mercury__vn_debug__flush_end_msg_4_0));
Define_label(mercury__vn_debug__flush_end_msg_4_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_debug__flush_end_msg_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const("new use info\n", 13);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__flush_end_msg_4_0_i9,
		ENTRY(mercury__vn_debug__flush_end_msg_4_0));
Define_label(mercury__vn_debug__flush_end_msg_4_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_debug__flush_end_msg_4_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__io__write_string_3_0),
		ENTRY(mercury__vn_debug__flush_end_msg_4_0));
END_MODULE

Declare_entry(mercury__bool__or_3_0);
Declare_entry(mercury__opt_debug__dump_instrs_4_0);

BEGIN_MODULE(vn_debug_module22)
	init_entry(mercury__vn_debug__dump_instrs_3_0);
	init_label(mercury__vn_debug__dump_instrs_3_0_i2);
	init_label(mercury__vn_debug__dump_instrs_3_0_i3);
	init_label(mercury__vn_debug__dump_instrs_3_0_i6);
	init_label(mercury__vn_debug__dump_instrs_3_0_i7);
	init_label(mercury__vn_debug__dump_instrs_3_0_i10);
BEGIN_CODE

/* code for predicate 'dump_instrs'/3 in mode 0 */
Define_entry(mercury__vn_debug__dump_instrs_3_0);
	MR_incr_sp_push_msg(3, "vn_debug:dump_instrs/3");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = (Integer) 25;
	call_localret(ENTRY(mercury__globals__io_lookup_int_option_4_0),
		mercury__vn_debug__dump_instrs_3_0_i2,
		ENTRY(mercury__vn_debug__dump_instrs_3_0));
Define_label(mercury__vn_debug__dump_instrs_3_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_debug__dump_instrs_3_0));
	r3 = ((Integer) r1 & (Integer) 128);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__vn_debug__dump_instrs_3_0_i3);
	MR_stackvar(2) = (Integer) 0;
	r1 = (Integer) 25;
	call_localret(ENTRY(mercury__globals__io_lookup_int_option_4_0),
		mercury__vn_debug__dump_instrs_3_0_i6,
		ENTRY(mercury__vn_debug__dump_instrs_3_0));
Define_label(mercury__vn_debug__dump_instrs_3_0_i3);
	MR_stackvar(2) = (Integer) 1;
	r1 = (Integer) 25;
	call_localret(ENTRY(mercury__globals__io_lookup_int_option_4_0),
		mercury__vn_debug__dump_instrs_3_0_i6,
		ENTRY(mercury__vn_debug__dump_instrs_3_0));
Define_label(mercury__vn_debug__dump_instrs_3_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_debug__dump_instrs_3_0));
	r3 = ((Integer) r1 & (Integer) 8);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__vn_debug__dump_instrs_3_0_i7);
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	r2 = (Integer) 0;
	call_localret(ENTRY(mercury__bool__or_3_0),
		mercury__vn_debug__dump_instrs_3_0_i10,
		ENTRY(mercury__vn_debug__dump_instrs_3_0));
Define_label(mercury__vn_debug__dump_instrs_3_0_i7);
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	r2 = (Integer) 1;
	call_localret(ENTRY(mercury__bool__or_3_0),
		mercury__vn_debug__dump_instrs_3_0_i10,
		ENTRY(mercury__vn_debug__dump_instrs_3_0));
Define_label(mercury__vn_debug__dump_instrs_3_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_debug__dump_instrs_3_0));
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__opt_debug__dump_instrs_4_0),
		ENTRY(mercury__vn_debug__dump_instrs_3_0));
END_MODULE

extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_int_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_vn_type__type_ctor_info_vn_instr_0;
Declare_entry(mercury__map__lookup_3_0);
Declare_entry(mercury__opt_debug__dump_vninstr_2_0);

BEGIN_MODULE(vn_debug_module23)
	init_entry(mercury__vn_debug__tuple_entries_6_0);
	init_label(mercury__vn_debug__tuple_entries_6_0_i1001);
	init_label(mercury__vn_debug__tuple_entries_6_0_i3);
	init_label(mercury__vn_debug__tuple_entries_6_0_i4);
	init_label(mercury__vn_debug__tuple_entries_6_0_i5);
	init_label(mercury__vn_debug__tuple_entries_6_0_i6);
	init_label(mercury__vn_debug__tuple_entries_6_0_i7);
	init_label(mercury__vn_debug__tuple_entries_6_0_i8);
	init_label(mercury__vn_debug__tuple_entries_6_0_i9);
	init_label(mercury__vn_debug__tuple_entries_6_0_i2);
BEGIN_CODE

/* code for predicate 'tuple_entries'/6 in mode 0 */
Define_static(mercury__vn_debug__tuple_entries_6_0);
	MR_incr_sp_push_msg(7, "vn_debug:tuple_entries/6");
	MR_stackvar(7) = (Word) MR_succip;
Define_label(mercury__vn_debug__tuple_entries_6_0_i1001);
	if (((Integer) r1 >= (Integer) r2))
		GOTO_LABEL(mercury__vn_debug__tuple_entries_6_0_i2);
	MR_stackvar(4) = r4;
	r4 = r1;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vn_instr_0;
	MR_stackvar(3) = r3;
	MR_stackvar(5) = r5;
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__vn_debug__tuple_entries_6_0_i3,
		STATIC(mercury__vn_debug__tuple_entries_6_0));
Define_label(mercury__vn_debug__tuple_entries_6_0_i3);
	update_prof_current_proc(LABEL(mercury__vn_debug__tuple_entries_6_0));
	MR_stackvar(6) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_debug__common_0);
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__vn_debug__tuple_entries_6_0_i4,
		STATIC(mercury__vn_debug__tuple_entries_6_0));
Define_label(mercury__vn_debug__tuple_entries_6_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_debug__tuple_entries_6_0));
	r2 = r1;
	r1 = MR_stackvar(6);
	MR_stackvar(6) = r2;
	call_localret(ENTRY(mercury__opt_debug__dump_vninstr_2_0),
		mercury__vn_debug__tuple_entries_6_0_i5,
		STATIC(mercury__vn_debug__tuple_entries_6_0));
Define_label(mercury__vn_debug__tuple_entries_6_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_debug__tuple_entries_6_0));
	r2 = MR_stackvar(5);
	MR_stackvar(5) = r1;
	r1 = (Word) MR_string_const("\n-----------\n", 13);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__tuple_entries_6_0_i6,
		STATIC(mercury__vn_debug__tuple_entries_6_0));
Define_label(mercury__vn_debug__tuple_entries_6_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_debug__tuple_entries_6_0));
	r2 = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__tuple_entries_6_0_i7,
		STATIC(mercury__vn_debug__tuple_entries_6_0));
Define_label(mercury__vn_debug__tuple_entries_6_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_debug__tuple_entries_6_0));
	r2 = r1;
	r1 = (Word) MR_string_const(":\n", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__tuple_entries_6_0_i8,
		STATIC(mercury__vn_debug__tuple_entries_6_0));
Define_label(mercury__vn_debug__tuple_entries_6_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_debug__tuple_entries_6_0));
	r2 = r1;
	r1 = MR_stackvar(6);
	call_localret(STATIC(mercury__vn_debug__parallel_msgs_3_0),
		mercury__vn_debug__tuple_entries_6_0_i9,
		STATIC(mercury__vn_debug__tuple_entries_6_0));
Define_label(mercury__vn_debug__tuple_entries_6_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_debug__tuple_entries_6_0));
	r5 = r1;
	r1 = ((Integer) MR_stackvar(1) + (Integer) 1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(7);
	GOTO_LABEL(mercury__vn_debug__tuple_entries_6_0_i1001);
Define_label(mercury__vn_debug__tuple_entries_6_0_i2);
	r1 = r5;
	MR_succip = (Code *) MR_stackvar(7);
	MR_decr_sp_pop_msg(7);
	proceed();
END_MODULE

Declare_entry(mercury__opt_debug__dump_lval_2_0);
Declare_entry(mercury__opt_debug__dump_rvals_2_0);

BEGIN_MODULE(vn_debug_module24)
	init_entry(mercury__vn_debug__parentry_msg_3_0);
	init_label(mercury__vn_debug__parentry_msg_3_0_i1001);
	init_label(mercury__vn_debug__parentry_msg_3_0_i4);
	init_label(mercury__vn_debug__parentry_msg_3_0_i5);
	init_label(mercury__vn_debug__parentry_msg_3_0_i6);
	init_label(mercury__vn_debug__parentry_msg_3_0_i7);
	init_label(mercury__vn_debug__parentry_msg_3_0_i8);
	init_label(mercury__vn_debug__parentry_msg_3_0_i9);
	init_label(mercury__vn_debug__parentry_msg_3_0_i3);
BEGIN_CODE

/* code for predicate 'parentry_msg'/3 in mode 0 */
Define_static(mercury__vn_debug__parentry_msg_3_0);
	MR_incr_sp_push_msg(4, "vn_debug:parentry_msg/3");
	MR_stackvar(4) = (Word) MR_succip;
Define_label(mercury__vn_debug__parentry_msg_3_0_i1001);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_debug__parentry_msg_3_0_i3);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__opt_debug__dump_lval_2_0),
		mercury__vn_debug__parentry_msg_3_0_i4,
		STATIC(mercury__vn_debug__parentry_msg_3_0));
Define_label(mercury__vn_debug__parentry_msg_3_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_debug__parentry_msg_3_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__opt_debug__dump_rvals_2_0),
		mercury__vn_debug__parentry_msg_3_0_i5,
		STATIC(mercury__vn_debug__parentry_msg_3_0));
Define_label(mercury__vn_debug__parentry_msg_3_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_debug__parentry_msg_3_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__parentry_msg_3_0_i6,
		STATIC(mercury__vn_debug__parentry_msg_3_0));
Define_label(mercury__vn_debug__parentry_msg_3_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_debug__parentry_msg_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const(" -> ", 4);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__parentry_msg_3_0_i7,
		STATIC(mercury__vn_debug__parentry_msg_3_0));
Define_label(mercury__vn_debug__parentry_msg_3_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_debug__parentry_msg_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__parentry_msg_3_0_i8,
		STATIC(mercury__vn_debug__parentry_msg_3_0));
Define_label(mercury__vn_debug__parentry_msg_3_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_debug__parentry_msg_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\n", 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__parentry_msg_3_0_i9,
		STATIC(mercury__vn_debug__parentry_msg_3_0));
Define_label(mercury__vn_debug__parentry_msg_3_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_debug__parentry_msg_3_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(4);
	GOTO_LABEL(mercury__vn_debug__parentry_msg_3_0_i1001);
Define_label(mercury__vn_debug__parentry_msg_3_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE


BEGIN_MODULE(vn_debug_module25)
	init_entry(mercury__vn_debug__dump_labels_3_0);
	init_label(mercury__vn_debug__dump_labels_3_0_i1001);
	init_label(mercury__vn_debug__dump_labels_3_0_i4);
	init_label(mercury__vn_debug__dump_labels_3_0_i5);
	init_label(mercury__vn_debug__dump_labels_3_0_i6);
	init_label(mercury__vn_debug__dump_labels_3_0_i3);
BEGIN_CODE

/* code for predicate 'dump_labels'/3 in mode 0 */
Define_static(mercury__vn_debug__dump_labels_3_0);
	MR_incr_sp_push_msg(3, "vn_debug:dump_labels/3");
	MR_stackvar(3) = (Word) MR_succip;
Define_label(mercury__vn_debug__dump_labels_3_0_i1001);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_debug__dump_labels_3_0_i3);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__opt_debug__dump_label_2_0),
		mercury__vn_debug__dump_labels_3_0_i4,
		STATIC(mercury__vn_debug__dump_labels_3_0));
Define_label(mercury__vn_debug__dump_labels_3_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_debug__dump_labels_3_0));
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__dump_labels_3_0_i5,
		STATIC(mercury__vn_debug__dump_labels_3_0));
Define_label(mercury__vn_debug__dump_labels_3_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_debug__dump_labels_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const("\n", 1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__dump_labels_3_0_i6,
		STATIC(mercury__vn_debug__dump_labels_3_0));
Define_label(mercury__vn_debug__dump_labels_3_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_debug__dump_labels_3_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	GOTO_LABEL(mercury__vn_debug__dump_labels_3_0_i1001);
Define_label(mercury__vn_debug__dump_labels_3_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(vn_debug_module26)
	init_entry(mercury__vn_debug__dump_parallels_3_0);
	init_label(mercury__vn_debug__dump_parallels_3_0_i1001);
	init_label(mercury__vn_debug__dump_parallels_3_0_i4);
	init_label(mercury__vn_debug__dump_parallels_3_0_i3);
BEGIN_CODE

/* code for predicate 'dump_parallels'/3 in mode 0 */
Define_static(mercury__vn_debug__dump_parallels_3_0);
	MR_incr_sp_push_msg(2, "vn_debug:dump_parallels/3");
	MR_stackvar(2) = (Word) MR_succip;
Define_label(mercury__vn_debug__dump_parallels_3_0_i1001);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_debug__dump_parallels_3_0_i3);
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	call_localret(STATIC(mercury__vn_debug__parallel_msg_3_0),
		mercury__vn_debug__dump_parallels_3_0_i4,
		STATIC(mercury__vn_debug__dump_parallels_3_0));
Define_label(mercury__vn_debug__dump_parallels_3_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_debug__dump_parallels_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	GOTO_LABEL(mercury__vn_debug__dump_parallels_3_0_i1001);
Define_label(mercury__vn_debug__dump_parallels_3_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE


BEGIN_MODULE(vn_debug_module27)
	init_entry(mercury__vn_debug__dump_label_parallel_pairs_3_0);
	init_label(mercury__vn_debug__dump_label_parallel_pairs_3_0_i1002);
	init_label(mercury__vn_debug__dump_label_parallel_pairs_3_0_i4);
	init_label(mercury__vn_debug__dump_label_parallel_pairs_3_0_i5);
	init_label(mercury__vn_debug__dump_label_parallel_pairs_3_0_i6);
	init_label(mercury__vn_debug__dump_label_parallel_pairs_3_0_i8);
	init_label(mercury__vn_debug__dump_label_parallel_pairs_3_0_i10);
	init_label(mercury__vn_debug__dump_label_parallel_pairs_3_0_i3);
BEGIN_CODE

/* code for predicate 'dump_label_parallel_pairs'/3 in mode 0 */
Define_static(mercury__vn_debug__dump_label_parallel_pairs_3_0);
	MR_incr_sp_push_msg(4, "vn_debug:dump_label_parallel_pairs/3");
	MR_stackvar(4) = (Word) MR_succip;
Define_label(mercury__vn_debug__dump_label_parallel_pairs_3_0_i1002);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_debug__dump_label_parallel_pairs_3_0_i3);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__opt_debug__dump_label_2_0),
		mercury__vn_debug__dump_label_parallel_pairs_3_0_i4,
		STATIC(mercury__vn_debug__dump_label_parallel_pairs_3_0));
Define_label(mercury__vn_debug__dump_label_parallel_pairs_3_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_debug__dump_label_parallel_pairs_3_0));
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__dump_label_parallel_pairs_3_0_i5,
		STATIC(mercury__vn_debug__dump_label_parallel_pairs_3_0));
Define_label(mercury__vn_debug__dump_label_parallel_pairs_3_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_debug__dump_label_parallel_pairs_3_0));
	r2 = r1;
	r1 = (Word) MR_string_const(": ", 2);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__dump_label_parallel_pairs_3_0_i6,
		STATIC(mercury__vn_debug__dump_label_parallel_pairs_3_0));
Define_label(mercury__vn_debug__dump_label_parallel_pairs_3_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_debug__dump_label_parallel_pairs_3_0));
	if (((Integer) MR_stackvar(2) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_debug__dump_label_parallel_pairs_3_0_i8);
	r2 = r1;
	r1 = (Word) MR_string_const("no\n", 3);
	call_localret(ENTRY(mercury__io__write_string_3_0),
		mercury__vn_debug__dump_label_parallel_pairs_3_0_i10,
		STATIC(mercury__vn_debug__dump_label_parallel_pairs_3_0));
Define_label(mercury__vn_debug__dump_label_parallel_pairs_3_0_i8);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(1), MR_stackvar(2), (Integer) 0);
	call_localret(STATIC(mercury__vn_debug__parallel_msg_3_0),
		mercury__vn_debug__dump_label_parallel_pairs_3_0_i10,
		STATIC(mercury__vn_debug__dump_label_parallel_pairs_3_0));
Define_label(mercury__vn_debug__dump_label_parallel_pairs_3_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_debug__dump_label_parallel_pairs_3_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(4);
	GOTO_LABEL(mercury__vn_debug__dump_label_parallel_pairs_3_0_i1002);
Define_label(mercury__vn_debug__dump_label_parallel_pairs_3_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__vn_debug_maybe_bunch_0(void)
{
	vn_debug_module0();
	vn_debug_module1();
	vn_debug_module2();
	vn_debug_module3();
	vn_debug_module4();
	vn_debug_module5();
	vn_debug_module6();
	vn_debug_module7();
	vn_debug_module8();
	vn_debug_module9();
	vn_debug_module10();
	vn_debug_module11();
	vn_debug_module12();
	vn_debug_module13();
	vn_debug_module14();
	vn_debug_module15();
	vn_debug_module16();
	vn_debug_module17();
	vn_debug_module18();
	vn_debug_module19();
	vn_debug_module20();
	vn_debug_module21();
	vn_debug_module22();
	vn_debug_module23();
	vn_debug_module24();
	vn_debug_module25();
	vn_debug_module26();
	vn_debug_module27();
}

#endif

void mercury__vn_debug__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__vn_debug__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__vn_debug_maybe_bunch_0();
#endif

	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
