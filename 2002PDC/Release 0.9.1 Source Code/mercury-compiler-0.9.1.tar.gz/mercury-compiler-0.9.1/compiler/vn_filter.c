/*
** Automatically generated from `vn_filter.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__vn_filter__init
ENDINIT
*/

#include "mercury_imp.h"

Define_extern_entry(mercury__vn_filter__block_2_0);
Declare_label(mercury__vn_filter__block_2_0_i1004);
Declare_label(mercury__vn_filter__block_2_0_i8);
Declare_label(mercury__vn_filter__block_2_0_i9);
Declare_label(mercury__vn_filter__block_2_0_i4);
Declare_label(mercury__vn_filter__block_2_0_i5);
Declare_label(mercury__vn_filter__block_2_0_i12);
Declare_label(mercury__vn_filter__block_2_0_i3);
Declare_static(mercury__vn_filter__can_substitute_5_0);
Declare_label(mercury__vn_filter__can_substitute_5_0_i3);
Declare_label(mercury__vn_filter__can_substitute_5_0_i5);
Declare_label(mercury__vn_filter__can_substitute_5_0_i7);
Declare_label(mercury__vn_filter__can_substitute_5_0_i8);
Declare_label(mercury__vn_filter__can_substitute_5_0_i11);
Declare_label(mercury__vn_filter__can_substitute_5_0_i14);
Declare_label(mercury__vn_filter__can_substitute_5_0_i16);
Declare_label(mercury__vn_filter__can_substitute_5_0_i17);
Declare_label(mercury__vn_filter__can_substitute_5_0_i13);
Declare_label(mercury__vn_filter__can_substitute_5_0_i19);
Declare_label(mercury__vn_filter__can_substitute_5_0_i20);
Declare_label(mercury__vn_filter__can_substitute_5_0_i4);
Declare_label(mercury__vn_filter__can_substitute_5_0_i23);
Declare_label(mercury__vn_filter__can_substitute_5_0_i27);
Declare_label(mercury__vn_filter__can_substitute_5_0_i25);
Declare_label(mercury__vn_filter__can_substitute_5_0_i30);
Declare_label(mercury__vn_filter__can_substitute_5_0_i1008);
Declare_label(mercury__vn_filter__can_substitute_5_0_i29);
Declare_label(mercury__vn_filter__can_substitute_5_0_i33);
Declare_label(mercury__vn_filter__can_substitute_5_0_i34);
Declare_label(mercury__vn_filter__can_substitute_5_0_i37);
Declare_label(mercury__vn_filter__can_substitute_5_0_i1032);
Declare_label(mercury__vn_filter__can_substitute_5_0_i40);
Declare_label(mercury__vn_filter__can_substitute_5_0_i32);
Declare_label(mercury__vn_filter__can_substitute_5_0_i42);
Declare_label(mercury__vn_filter__can_substitute_5_0_i22);
Declare_label(mercury__vn_filter__can_substitute_5_0_i47);
Declare_static(mercury__vn_filter__user_instr_2_0);
Declare_label(mercury__vn_filter__user_instr_2_0_i7);
Declare_label(mercury__vn_filter__user_instr_2_0_i10);
Declare_label(mercury__vn_filter__user_instr_2_0_i19);
Declare_label(mercury__vn_filter__user_instr_2_0_i25);
Declare_label(mercury__vn_filter__user_instr_2_0_i27);
Declare_label(mercury__vn_filter__user_instr_2_0_i28);
Declare_label(mercury__vn_filter__user_instr_2_0_i30);
Declare_label(mercury__vn_filter__user_instr_2_0_i32);
Declare_label(mercury__vn_filter__user_instr_2_0_i34);
Declare_label(mercury__vn_filter__user_instr_2_0_i36);
Declare_static(mercury__vn_filter__replace_in_user_instr_4_0);
Declare_label(mercury__vn_filter__replace_in_user_instr_4_0_i10);
Declare_label(mercury__vn_filter__replace_in_user_instr_4_0_i13);
Declare_label(mercury__vn_filter__replace_in_user_instr_4_0_i14);
Declare_label(mercury__vn_filter__replace_in_user_instr_4_0_i23);
Declare_label(mercury__vn_filter__replace_in_user_instr_4_0_i24);
Declare_label(mercury__vn_filter__replace_in_user_instr_4_0_i27);
Declare_label(mercury__vn_filter__replace_in_user_instr_4_0_i28);
Declare_label(mercury__vn_filter__replace_in_user_instr_4_0_i29);
Declare_label(mercury__vn_filter__replace_in_user_instr_4_0_i30);
Declare_label(mercury__vn_filter__replace_in_user_instr_4_0_i33);
Declare_label(mercury__vn_filter__replace_in_user_instr_4_0_i34);
Declare_label(mercury__vn_filter__replace_in_user_instr_4_0_i37);
Declare_label(mercury__vn_filter__replace_in_user_instr_4_0_i38);
Declare_label(mercury__vn_filter__replace_in_user_instr_4_0_i41);
Declare_label(mercury__vn_filter__replace_in_user_instr_4_0_i42);
Declare_label(mercury__vn_filter__replace_in_user_instr_4_0_i1009);
Declare_label(mercury__vn_filter__replace_in_user_instr_4_0_i45);
Declare_label(mercury__vn_filter__replace_in_user_instr_4_0_i47);
Declare_label(mercury__vn_filter__replace_in_user_instr_4_0_i49);
Declare_label(mercury__vn_filter__replace_in_user_instr_4_0_i51);
Declare_label(mercury__vn_filter__replace_in_user_instr_4_0_i53);
Declare_label(mercury__vn_filter__replace_in_user_instr_4_0_i55);
Declare_static(mercury__vn_filter__defining_instr_2_0);
Declare_label(mercury__vn_filter__defining_instr_2_0_i7);
Declare_label(mercury__vn_filter__defining_instr_2_0_i24);
Declare_label(mercury__vn_filter__defining_instr_2_0_i27);
Declare_label(mercury__vn_filter__defining_instr_2_0_i28);
Declare_label(mercury__vn_filter__defining_instr_2_0_i30);
Declare_label(mercury__vn_filter__defining_instr_2_0_i32);
Declare_label(mercury__vn_filter__defining_instr_2_0_i34);
Declare_label(mercury__vn_filter__defining_instr_2_0_i36);
Declare_static(mercury__vn_filter__replace_in_defining_instr_4_0);
Declare_label(mercury__vn_filter__replace_in_defining_instr_4_0_i10);
Declare_label(mercury__vn_filter__replace_in_defining_instr_4_0_i13);
Declare_label(mercury__vn_filter__replace_in_defining_instr_4_0_i14);
Declare_label(mercury__vn_filter__replace_in_defining_instr_4_0_i29);
Declare_label(mercury__vn_filter__replace_in_defining_instr_4_0_i30);
Declare_label(mercury__vn_filter__replace_in_defining_instr_4_0_i31);
Declare_label(mercury__vn_filter__replace_in_defining_instr_4_0_i32);
Declare_label(mercury__vn_filter__replace_in_defining_instr_4_0_i35);
Declare_label(mercury__vn_filter__replace_in_defining_instr_4_0_i36);
Declare_label(mercury__vn_filter__replace_in_defining_instr_4_0_i39);
Declare_label(mercury__vn_filter__replace_in_defining_instr_4_0_i40);
Declare_label(mercury__vn_filter__replace_in_defining_instr_4_0_i1007);
Declare_label(mercury__vn_filter__replace_in_defining_instr_4_0_i45);
Declare_label(mercury__vn_filter__replace_in_defining_instr_4_0_i47);
Declare_label(mercury__vn_filter__replace_in_defining_instr_4_0_i49);
Declare_label(mercury__vn_filter__replace_in_defining_instr_4_0_i51);
Declare_label(mercury__vn_filter__replace_in_defining_instr_4_0_i53);
Declare_label(mercury__vn_filter__replace_in_defining_instr_4_0_i55);
Declare_static(mercury__vn_filter__replace_in_lval_4_0);
Declare_label(mercury__vn_filter__replace_in_lval_4_0_i4);
Declare_label(mercury__vn_filter__replace_in_lval_4_0_i5);
Declare_label(mercury__vn_filter__replace_in_lval_4_0_i6);
Declare_label(mercury__vn_filter__replace_in_lval_4_0_i7);
Declare_label(mercury__vn_filter__replace_in_lval_4_0_i8);
Declare_label(mercury__vn_filter__replace_in_lval_4_0_i9);
Declare_label(mercury__vn_filter__replace_in_lval_4_0_i12);
Declare_label(mercury__vn_filter__replace_in_lval_4_0_i15);
Declare_label(mercury__vn_filter__replace_in_lval_4_0_i16);
Declare_label(mercury__vn_filter__replace_in_lval_4_0_i17);
Declare_label(mercury__vn_filter__replace_in_lval_4_0_i18);
Declare_label(mercury__vn_filter__replace_in_lval_4_0_i19);
Declare_label(mercury__vn_filter__replace_in_lval_4_0_i20);
Declare_label(mercury__vn_filter__replace_in_lval_4_0_i21);
Declare_label(mercury__vn_filter__replace_in_lval_4_0_i22);
Declare_label(mercury__vn_filter__replace_in_lval_4_0_i23);
Declare_label(mercury__vn_filter__replace_in_lval_4_0_i24);
Declare_label(mercury__vn_filter__replace_in_lval_4_0_i25);
Declare_label(mercury__vn_filter__replace_in_lval_4_0_i26);
Declare_label(mercury__vn_filter__replace_in_lval_4_0_i27);
Declare_label(mercury__vn_filter__replace_in_lval_4_0_i28);
Declare_label(mercury__vn_filter__replace_in_lval_4_0_i29);
Declare_label(mercury__vn_filter__replace_in_lval_4_0_i30);
Declare_label(mercury__vn_filter__replace_in_lval_4_0_i1009);
Declare_label(mercury__vn_filter__replace_in_lval_4_0_i2);
Declare_static(mercury__vn_filter__replace_in_rval_4_0);
Declare_label(mercury__vn_filter__replace_in_rval_4_0_i4);
Declare_label(mercury__vn_filter__replace_in_rval_4_0_i7);
Declare_label(mercury__vn_filter__replace_in_rval_4_0_i5);
Declare_label(mercury__vn_filter__replace_in_rval_4_0_i9);
Declare_label(mercury__vn_filter__replace_in_rval_4_0_i1007);
Declare_label(mercury__vn_filter__replace_in_rval_4_0_i14);
Declare_label(mercury__vn_filter__replace_in_rval_4_0_i15);
Declare_label(mercury__vn_filter__replace_in_rval_4_0_i16);
Declare_label(mercury__vn_filter__replace_in_rval_4_0_i18);
Declare_label(mercury__vn_filter__replace_in_rval_4_0_i19);
Declare_label(mercury__vn_filter__replace_in_rval_4_0_i20);
Declare_label(mercury__vn_filter__replace_in_rval_4_0_i21);
Declare_label(mercury__vn_filter__replace_in_rval_4_0_i22);
Declare_label(mercury__vn_filter__replace_in_rval_4_0_i23);
Declare_label(mercury__vn_filter__replace_in_rval_4_0_i24);
Declare_label(mercury__vn_filter__replace_in_rval_4_0_i1008);
Declare_label(mercury__vn_filter__replace_in_rval_4_0_i2);
Declare_static(mercury__vn_filter__replace_in_mem_ref_4_0);
Declare_label(mercury__vn_filter__replace_in_mem_ref_4_0_i6);
Declare_label(mercury__vn_filter__replace_in_mem_ref_4_0_i1004);
Declare_static(mercury__vn_filter__instrs_free_of_lval_2_0);
Declare_label(mercury__vn_filter__instrs_free_of_lval_2_0_i1011);
Declare_label(mercury__vn_filter__instrs_free_of_lval_2_0_i11);
Declare_label(mercury__vn_filter__instrs_free_of_lval_2_0_i12);
Declare_label(mercury__vn_filter__instrs_free_of_lval_2_0_i14);
Declare_label(mercury__vn_filter__instrs_free_of_lval_2_0_i20);
Declare_label(mercury__vn_filter__instrs_free_of_lval_2_0_i23);
Declare_label(mercury__vn_filter__instrs_free_of_lval_2_0_i29);
Declare_label(mercury__vn_filter__instrs_free_of_lval_2_0_i31);
Declare_label(mercury__vn_filter__instrs_free_of_lval_2_0_i32);
Declare_label(mercury__vn_filter__instrs_free_of_lval_2_0_i34);
Declare_label(mercury__vn_filter__instrs_free_of_lval_2_0_i36);
Declare_label(mercury__vn_filter__instrs_free_of_lval_2_0_i38);
Declare_label(mercury__vn_filter__instrs_free_of_lval_2_0_i40);
Declare_label(mercury__vn_filter__instrs_free_of_lval_2_0_i41);
Declare_label(mercury__vn_filter__instrs_free_of_lval_2_0_i6);
Declare_label(mercury__vn_filter__instrs_free_of_lval_2_0_i42);
Declare_label(mercury__vn_filter__instrs_free_of_lval_2_0_i43);
Declare_label(mercury__vn_filter__instrs_free_of_lval_2_0_i1014);
Declare_label(mercury__vn_filter__instrs_free_of_lval_2_0_i47);
Declare_label(mercury__vn_filter__instrs_free_of_lval_2_0_i51);
Declare_label(mercury__vn_filter__instrs_free_of_lval_2_0_i53);
Declare_label(mercury__vn_filter__instrs_free_of_lval_2_0_i54);
Declare_label(mercury__vn_filter__instrs_free_of_lval_2_0_i1005);
Declare_label(mercury__vn_filter__instrs_free_of_lval_2_0_i2);
Declare_label(mercury__vn_filter__instrs_free_of_lval_2_0_i1);

Declare_entry(mercury__code_util__lvals_in_rval_2_0);

BEGIN_MODULE(vn_filter_module0)
	init_entry(mercury__vn_filter__block_2_0);
	init_label(mercury__vn_filter__block_2_0_i1004);
	init_label(mercury__vn_filter__block_2_0_i8);
	init_label(mercury__vn_filter__block_2_0_i9);
	init_label(mercury__vn_filter__block_2_0_i4);
	init_label(mercury__vn_filter__block_2_0_i5);
	init_label(mercury__vn_filter__block_2_0_i12);
	init_label(mercury__vn_filter__block_2_0_i3);
BEGIN_CODE

/* code for predicate 'block'/2 in mode 0 */
Define_entry(mercury__vn_filter__block_2_0);
	MR_incr_sp_push_msg(5, "vn_filter:block/2");
	MR_stackvar(5) = (Word) MR_succip;
Define_label(mercury__vn_filter__block_2_0_i1004);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_filter__block_2_0_i3);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r4 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	if ((MR_tag(r4) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__vn_filter__block_2_0_i5);
	if (((Integer) MR_const_field(MR_mktag(3), r4, (Integer) 0) != (Integer) 1))
		GOTO_LABEL(mercury__vn_filter__block_2_0_i5);
	if ((MR_tag(MR_const_field(MR_mktag(3), r4, (Integer) 1)) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_filter__block_2_0_i5);
	MR_stackvar(1) = r3;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r4, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(3), r4, (Integer) 2);
	r5 = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__code_util__lvals_in_rval_2_0),
		mercury__vn_filter__block_2_0_i8,
		ENTRY(mercury__vn_filter__block_2_0));
Define_label(mercury__vn_filter__block_2_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_filter__block_2_0));
	r4 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(4);
	call_localret(STATIC(mercury__vn_filter__can_substitute_5_0),
		mercury__vn_filter__block_2_0_i9,
		ENTRY(mercury__vn_filter__block_2_0));
Define_label(mercury__vn_filter__block_2_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_filter__block_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_filter__block_2_0_i4);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(5);
	GOTO_LABEL(mercury__vn_filter__block_2_0_i1004);
Define_label(mercury__vn_filter__block_2_0_i4);
	r3 = MR_stackvar(1);
	r2 = MR_stackvar(2);
Define_label(mercury__vn_filter__block_2_0_i5);
	MR_stackvar(1) = r3;
	r1 = r2;
	localcall(mercury__vn_filter__block_2_0,
		LABEL(mercury__vn_filter__block_2_0_i12),
		ENTRY(mercury__vn_filter__block_2_0));
Define_label(mercury__vn_filter__block_2_0_i12);
	update_prof_current_proc(LABEL(mercury__vn_filter__block_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__vn_filter__block_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_filter__block_2_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE

extern const struct MR_TypeCtorInfo_struct
	mercury_data_llds__type_ctor_info_lval_0;
Declare_entry(mercury__list__delete_first_3_0);
Declare_entry(mercury__list__member_2_0);
Declare_entry(mercury__code_util__lvals_in_lval_2_0);
Declare_entry(mercury____Unify___llds__lval_0_0);

BEGIN_MODULE(vn_filter_module1)
	init_entry(mercury__vn_filter__can_substitute_5_0);
	init_label(mercury__vn_filter__can_substitute_5_0_i3);
	init_label(mercury__vn_filter__can_substitute_5_0_i5);
	init_label(mercury__vn_filter__can_substitute_5_0_i7);
	init_label(mercury__vn_filter__can_substitute_5_0_i8);
	init_label(mercury__vn_filter__can_substitute_5_0_i11);
	init_label(mercury__vn_filter__can_substitute_5_0_i14);
	init_label(mercury__vn_filter__can_substitute_5_0_i16);
	init_label(mercury__vn_filter__can_substitute_5_0_i17);
	init_label(mercury__vn_filter__can_substitute_5_0_i13);
	init_label(mercury__vn_filter__can_substitute_5_0_i19);
	init_label(mercury__vn_filter__can_substitute_5_0_i20);
	init_label(mercury__vn_filter__can_substitute_5_0_i4);
	init_label(mercury__vn_filter__can_substitute_5_0_i23);
	init_label(mercury__vn_filter__can_substitute_5_0_i27);
	init_label(mercury__vn_filter__can_substitute_5_0_i25);
	init_label(mercury__vn_filter__can_substitute_5_0_i30);
	init_label(mercury__vn_filter__can_substitute_5_0_i1008);
	init_label(mercury__vn_filter__can_substitute_5_0_i29);
	init_label(mercury__vn_filter__can_substitute_5_0_i33);
	init_label(mercury__vn_filter__can_substitute_5_0_i34);
	init_label(mercury__vn_filter__can_substitute_5_0_i37);
	init_label(mercury__vn_filter__can_substitute_5_0_i1032);
	init_label(mercury__vn_filter__can_substitute_5_0_i40);
	init_label(mercury__vn_filter__can_substitute_5_0_i32);
	init_label(mercury__vn_filter__can_substitute_5_0_i42);
	init_label(mercury__vn_filter__can_substitute_5_0_i22);
	init_label(mercury__vn_filter__can_substitute_5_0_i47);
BEGIN_CODE

/* code for predicate 'can_substitute'/5 in mode 0 */
Define_static(mercury__vn_filter__can_substitute_5_0);
	MR_incr_sp_push_msg(10, "vn_filter:can_substitute/5");
	MR_stackvar(10) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_filter__can_substitute_5_0_i3);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
Define_label(mercury__vn_filter__can_substitute_5_0_i3);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = r1;
	MR_stackvar(6) = MR_tempr1;
	MR_stackvar(7) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 1);
	MR_stackvar(8) = r1;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	call_localret(STATIC(mercury__vn_filter__user_instr_2_0),
		mercury__vn_filter__can_substitute_5_0_i5,
		STATIC(mercury__vn_filter__can_substitute_5_0));
	}
Define_label(mercury__vn_filter__can_substitute_5_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_filter__can_substitute_5_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_filter__can_substitute_5_0_i4);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	call_localret(ENTRY(mercury__code_util__lvals_in_rval_2_0),
		mercury__vn_filter__can_substitute_5_0_i7,
		STATIC(mercury__vn_filter__can_substitute_5_0));
Define_label(mercury__vn_filter__can_substitute_5_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_filter__can_substitute_5_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_lval_0;
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__list__delete_first_3_0),
		mercury__vn_filter__can_substitute_5_0_i8,
		STATIC(mercury__vn_filter__can_substitute_5_0));
Define_label(mercury__vn_filter__can_substitute_5_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_filter__can_substitute_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_filter__can_substitute_5_0_i4);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_lval_0;
	r3 = r2;
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__vn_filter__can_substitute_5_0_i11,
		STATIC(mercury__vn_filter__can_substitute_5_0));
Define_label(mercury__vn_filter__can_substitute_5_0_i11);
	update_prof_current_proc(LABEL(mercury__vn_filter__can_substitute_5_0));
	if (r1)
		GOTO_LABEL(mercury__vn_filter__can_substitute_5_0_i1008);
	r1 = MR_stackvar(8);
	call_localret(STATIC(mercury__vn_filter__defining_instr_2_0),
		mercury__vn_filter__can_substitute_5_0_i14,
		STATIC(mercury__vn_filter__can_substitute_5_0));
Define_label(mercury__vn_filter__can_substitute_5_0_i14);
	update_prof_current_proc(LABEL(mercury__vn_filter__can_substitute_5_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_filter__can_substitute_5_0_i13);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	call_localret(ENTRY(mercury__code_util__lvals_in_lval_2_0),
		mercury__vn_filter__can_substitute_5_0_i16,
		STATIC(mercury__vn_filter__can_substitute_5_0));
Define_label(mercury__vn_filter__can_substitute_5_0_i16);
	update_prof_current_proc(LABEL(mercury__vn_filter__can_substitute_5_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_lval_0;
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__vn_filter__can_substitute_5_0_i17,
		STATIC(mercury__vn_filter__can_substitute_5_0));
Define_label(mercury__vn_filter__can_substitute_5_0_i17);
	update_prof_current_proc(LABEL(mercury__vn_filter__can_substitute_5_0));
	if (r1)
		GOTO_LABEL(mercury__vn_filter__can_substitute_5_0_i1008);
Define_label(mercury__vn_filter__can_substitute_5_0_i13);
	r1 = MR_stackvar(8);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	call_localret(STATIC(mercury__vn_filter__replace_in_user_instr_4_0),
		mercury__vn_filter__can_substitute_5_0_i19,
		STATIC(mercury__vn_filter__can_substitute_5_0));
Define_label(mercury__vn_filter__can_substitute_5_0_i19);
	update_prof_current_proc(LABEL(mercury__vn_filter__can_substitute_5_0));
	tag_incr_hp_msg(MR_stackvar(5), MR_mktag(1), (Integer) 2, mercury__vn_filter__can_substitute_5_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__vn_filter__can_substitute_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 0) = r1;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(5);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r3;
	r1 = MR_tempr1;
	r2 = MR_stackvar(2);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = MR_stackvar(7);
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(9);
	call_localret(STATIC(mercury__vn_filter__instrs_free_of_lval_2_0),
		mercury__vn_filter__can_substitute_5_0_i20,
		STATIC(mercury__vn_filter__can_substitute_5_0));
	}
Define_label(mercury__vn_filter__can_substitute_5_0_i20);
	update_prof_current_proc(LABEL(mercury__vn_filter__can_substitute_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_filter__can_substitute_5_0_i1008);
	r2 = MR_stackvar(5);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
Define_label(mercury__vn_filter__can_substitute_5_0_i4);
	r1 = MR_stackvar(8);
	call_localret(STATIC(mercury__vn_filter__defining_instr_2_0),
		mercury__vn_filter__can_substitute_5_0_i23,
		STATIC(mercury__vn_filter__can_substitute_5_0));
Define_label(mercury__vn_filter__can_substitute_5_0_i23);
	update_prof_current_proc(LABEL(mercury__vn_filter__can_substitute_5_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_filter__can_substitute_5_0_i22);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(5) = r1;
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury____Unify___llds__lval_0_0),
		mercury__vn_filter__can_substitute_5_0_i27,
		STATIC(mercury__vn_filter__can_substitute_5_0));
Define_label(mercury__vn_filter__can_substitute_5_0_i27);
	update_prof_current_proc(LABEL(mercury__vn_filter__can_substitute_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_filter__can_substitute_5_0_i25);
	r2 = MR_stackvar(1);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
Define_label(mercury__vn_filter__can_substitute_5_0_i25);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_lval_0;
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__vn_filter__can_substitute_5_0_i30,
		STATIC(mercury__vn_filter__can_substitute_5_0));
Define_label(mercury__vn_filter__can_substitute_5_0_i30);
	update_prof_current_proc(LABEL(mercury__vn_filter__can_substitute_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_filter__can_substitute_5_0_i29);
Define_label(mercury__vn_filter__can_substitute_5_0_i1008);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
Define_label(mercury__vn_filter__can_substitute_5_0_i29);
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__code_util__lvals_in_lval_2_0),
		mercury__vn_filter__can_substitute_5_0_i33,
		STATIC(mercury__vn_filter__can_substitute_5_0));
Define_label(mercury__vn_filter__can_substitute_5_0_i33);
	update_prof_current_proc(LABEL(mercury__vn_filter__can_substitute_5_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_lval_0;
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__list__delete_first_3_0),
		mercury__vn_filter__can_substitute_5_0_i34,
		STATIC(mercury__vn_filter__can_substitute_5_0));
Define_label(mercury__vn_filter__can_substitute_5_0_i34);
	update_prof_current_proc(LABEL(mercury__vn_filter__can_substitute_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_filter__can_substitute_5_0_i32);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_lval_0;
	r3 = r2;
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__vn_filter__can_substitute_5_0_i37,
		STATIC(mercury__vn_filter__can_substitute_5_0));
Define_label(mercury__vn_filter__can_substitute_5_0_i37);
	update_prof_current_proc(LABEL(mercury__vn_filter__can_substitute_5_0));
	if (r1)
		GOTO_LABEL(mercury__vn_filter__can_substitute_5_0_i1008);
	r1 = MR_stackvar(8);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	call_localret(STATIC(mercury__vn_filter__replace_in_defining_instr_4_0),
		mercury__vn_filter__can_substitute_5_0_i1032,
		STATIC(mercury__vn_filter__can_substitute_5_0));
Define_label(mercury__vn_filter__can_substitute_5_0_i1032);
	update_prof_current_proc(LABEL(mercury__vn_filter__can_substitute_5_0));
	tag_incr_hp_msg(MR_stackvar(5), MR_mktag(1), (Integer) 2, mercury__vn_filter__can_substitute_5_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 2, mercury__vn_filter__can_substitute_5_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r3, (Integer) 0) = r1;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(5);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r3;
	r1 = MR_tempr1;
	r2 = MR_stackvar(2);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = MR_stackvar(7);
	MR_field(MR_mktag(0), r3, (Integer) 1) = MR_stackvar(9);
	call_localret(STATIC(mercury__vn_filter__instrs_free_of_lval_2_0),
		mercury__vn_filter__can_substitute_5_0_i40,
		STATIC(mercury__vn_filter__can_substitute_5_0));
	}
Define_label(mercury__vn_filter__can_substitute_5_0_i40);
	update_prof_current_proc(LABEL(mercury__vn_filter__can_substitute_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_filter__can_substitute_5_0_i1008);
	r2 = MR_stackvar(5);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
Define_label(mercury__vn_filter__can_substitute_5_0_i32);
	r1 = MR_stackvar(7);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	localcall(mercury__vn_filter__can_substitute_5_0,
		LABEL(mercury__vn_filter__can_substitute_5_0_i42),
		STATIC(mercury__vn_filter__can_substitute_5_0));
Define_label(mercury__vn_filter__can_substitute_5_0_i42);
	update_prof_current_proc(LABEL(mercury__vn_filter__can_substitute_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_filter__can_substitute_5_0_i1008);
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__vn_filter__can_substitute_5_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(6);
	MR_field(MR_mktag(1), r2, (Integer) 1) = r1;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
Define_label(mercury__vn_filter__can_substitute_5_0_i22);
	r1 = MR_stackvar(7);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	localcall(mercury__vn_filter__can_substitute_5_0,
		LABEL(mercury__vn_filter__can_substitute_5_0_i47),
		STATIC(mercury__vn_filter__can_substitute_5_0));
Define_label(mercury__vn_filter__can_substitute_5_0_i47);
	update_prof_current_proc(LABEL(mercury__vn_filter__can_substitute_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_filter__can_substitute_5_0_i1008);
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__vn_filter__can_substitute_5_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(6);
	MR_field(MR_mktag(1), r2, (Integer) 1) = r1;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
END_MODULE

Declare_entry(mercury__require__error_1_0);

BEGIN_MODULE(vn_filter_module2)
	init_entry(mercury__vn_filter__user_instr_2_0);
	init_label(mercury__vn_filter__user_instr_2_0_i7);
	init_label(mercury__vn_filter__user_instr_2_0_i10);
	init_label(mercury__vn_filter__user_instr_2_0_i19);
	init_label(mercury__vn_filter__user_instr_2_0_i25);
	init_label(mercury__vn_filter__user_instr_2_0_i27);
	init_label(mercury__vn_filter__user_instr_2_0_i28);
	init_label(mercury__vn_filter__user_instr_2_0_i30);
	init_label(mercury__vn_filter__user_instr_2_0_i32);
	init_label(mercury__vn_filter__user_instr_2_0_i34);
	init_label(mercury__vn_filter__user_instr_2_0_i36);
BEGIN_CODE

/* code for predicate 'user_instr'/2 in mode 0 */
Define_static(mercury__vn_filter__user_instr_2_0);
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__vn_filter__user_instr_2_0_i27) AND
		LABEL(mercury__vn_filter__user_instr_2_0_i27) AND
		LABEL(mercury__vn_filter__user_instr_2_0_i27) AND
		LABEL(mercury__vn_filter__user_instr_2_0_i7));
Define_label(mercury__vn_filter__user_instr_2_0_i7);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__vn_filter__user_instr_2_0_i28) AND
		LABEL(mercury__vn_filter__user_instr_2_0_i10) AND
		LABEL(mercury__vn_filter__user_instr_2_0_i27) AND
		LABEL(mercury__vn_filter__user_instr_2_0_i27) AND
		LABEL(mercury__vn_filter__user_instr_2_0_i27) AND
		LABEL(mercury__vn_filter__user_instr_2_0_i27) AND
		LABEL(mercury__vn_filter__user_instr_2_0_i25) AND
		LABEL(mercury__vn_filter__user_instr_2_0_i28) AND
		LABEL(mercury__vn_filter__user_instr_2_0_i25) AND
		LABEL(mercury__vn_filter__user_instr_2_0_i19) AND
		LABEL(mercury__vn_filter__user_instr_2_0_i27) AND
		LABEL(mercury__vn_filter__user_instr_2_0_i25) AND
		LABEL(mercury__vn_filter__user_instr_2_0_i27) AND
		LABEL(mercury__vn_filter__user_instr_2_0_i25) AND
		LABEL(mercury__vn_filter__user_instr_2_0_i27) AND
		LABEL(mercury__vn_filter__user_instr_2_0_i25) AND
		LABEL(mercury__vn_filter__user_instr_2_0_i27) AND
		LABEL(mercury__vn_filter__user_instr_2_0_i27) AND
		LABEL(mercury__vn_filter__user_instr_2_0_i28) AND
		LABEL(mercury__vn_filter__user_instr_2_0_i30) AND
		LABEL(mercury__vn_filter__user_instr_2_0_i32) AND
		LABEL(mercury__vn_filter__user_instr_2_0_i34) AND
		LABEL(mercury__vn_filter__user_instr_2_0_i36));
Define_label(mercury__vn_filter__user_instr_2_0_i10);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__vn_filter__user_instr_2_0, "std_util:maybe/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_const_field(MR_mktag(3), r2, (Integer) 2);
	proceed();
Define_label(mercury__vn_filter__user_instr_2_0_i19);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__vn_filter__user_instr_2_0, "std_util:maybe/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_const_field(MR_mktag(3), r2, (Integer) 3);
	proceed();
Define_label(mercury__vn_filter__user_instr_2_0_i25);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__vn_filter__user_instr_2_0, "std_util:maybe/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	proceed();
Define_label(mercury__vn_filter__user_instr_2_0_i27);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
Define_label(mercury__vn_filter__user_instr_2_0_i28);
	r1 = (Word) MR_string_const("inappropriate instruction in vn__filter", 39);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__vn_filter__user_instr_2_0));
Define_label(mercury__vn_filter__user_instr_2_0_i30);
	r1 = (Word) MR_string_const("init_sync_term instruction in vn__filter", 40);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__vn_filter__user_instr_2_0));
Define_label(mercury__vn_filter__user_instr_2_0_i32);
	r1 = (Word) MR_string_const("fork instruction in vn__filter", 30);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__vn_filter__user_instr_2_0));
Define_label(mercury__vn_filter__user_instr_2_0_i34);
	r1 = (Word) MR_string_const("join_and_terminate instruction in vn__filter", 44);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__vn_filter__user_instr_2_0));
Define_label(mercury__vn_filter__user_instr_2_0_i36);
	r1 = (Word) MR_string_const("join_and_continue instruction in vn__filter", 43);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__vn_filter__user_instr_2_0));
END_MODULE


BEGIN_MODULE(vn_filter_module3)
	init_entry(mercury__vn_filter__replace_in_user_instr_4_0);
	init_label(mercury__vn_filter__replace_in_user_instr_4_0_i10);
	init_label(mercury__vn_filter__replace_in_user_instr_4_0_i13);
	init_label(mercury__vn_filter__replace_in_user_instr_4_0_i14);
	init_label(mercury__vn_filter__replace_in_user_instr_4_0_i23);
	init_label(mercury__vn_filter__replace_in_user_instr_4_0_i24);
	init_label(mercury__vn_filter__replace_in_user_instr_4_0_i27);
	init_label(mercury__vn_filter__replace_in_user_instr_4_0_i28);
	init_label(mercury__vn_filter__replace_in_user_instr_4_0_i29);
	init_label(mercury__vn_filter__replace_in_user_instr_4_0_i30);
	init_label(mercury__vn_filter__replace_in_user_instr_4_0_i33);
	init_label(mercury__vn_filter__replace_in_user_instr_4_0_i34);
	init_label(mercury__vn_filter__replace_in_user_instr_4_0_i37);
	init_label(mercury__vn_filter__replace_in_user_instr_4_0_i38);
	init_label(mercury__vn_filter__replace_in_user_instr_4_0_i41);
	init_label(mercury__vn_filter__replace_in_user_instr_4_0_i42);
	init_label(mercury__vn_filter__replace_in_user_instr_4_0_i1009);
	init_label(mercury__vn_filter__replace_in_user_instr_4_0_i45);
	init_label(mercury__vn_filter__replace_in_user_instr_4_0_i47);
	init_label(mercury__vn_filter__replace_in_user_instr_4_0_i49);
	init_label(mercury__vn_filter__replace_in_user_instr_4_0_i51);
	init_label(mercury__vn_filter__replace_in_user_instr_4_0_i53);
	init_label(mercury__vn_filter__replace_in_user_instr_4_0_i55);
BEGIN_CODE

/* code for predicate 'replace_in_user_instr'/4 in mode 0 */
Define_static(mercury__vn_filter__replace_in_user_instr_4_0);
	MR_incr_sp_push_msg(4, "vn_filter:replace_in_user_instr/4");
	MR_stackvar(4) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__vn_filter__replace_in_user_instr_4_0_i1009) AND
		LABEL(mercury__vn_filter__replace_in_user_instr_4_0_i1009) AND
		LABEL(mercury__vn_filter__replace_in_user_instr_4_0_i1009) AND
		LABEL(mercury__vn_filter__replace_in_user_instr_4_0_i10));
Define_label(mercury__vn_filter__replace_in_user_instr_4_0_i10);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__vn_filter__replace_in_user_instr_4_0_i47) AND
		LABEL(mercury__vn_filter__replace_in_user_instr_4_0_i13) AND
		LABEL(mercury__vn_filter__replace_in_user_instr_4_0_i45) AND
		LABEL(mercury__vn_filter__replace_in_user_instr_4_0_i45) AND
		LABEL(mercury__vn_filter__replace_in_user_instr_4_0_i45) AND
		LABEL(mercury__vn_filter__replace_in_user_instr_4_0_i45) AND
		LABEL(mercury__vn_filter__replace_in_user_instr_4_0_i23) AND
		LABEL(mercury__vn_filter__replace_in_user_instr_4_0_i47) AND
		LABEL(mercury__vn_filter__replace_in_user_instr_4_0_i27) AND
		LABEL(mercury__vn_filter__replace_in_user_instr_4_0_i29) AND
		LABEL(mercury__vn_filter__replace_in_user_instr_4_0_i45) AND
		LABEL(mercury__vn_filter__replace_in_user_instr_4_0_i33) AND
		LABEL(mercury__vn_filter__replace_in_user_instr_4_0_i45) AND
		LABEL(mercury__vn_filter__replace_in_user_instr_4_0_i37) AND
		LABEL(mercury__vn_filter__replace_in_user_instr_4_0_i45) AND
		LABEL(mercury__vn_filter__replace_in_user_instr_4_0_i41) AND
		LABEL(mercury__vn_filter__replace_in_user_instr_4_0_i45) AND
		LABEL(mercury__vn_filter__replace_in_user_instr_4_0_i45) AND
		LABEL(mercury__vn_filter__replace_in_user_instr_4_0_i47) AND
		LABEL(mercury__vn_filter__replace_in_user_instr_4_0_i49) AND
		LABEL(mercury__vn_filter__replace_in_user_instr_4_0_i51) AND
		LABEL(mercury__vn_filter__replace_in_user_instr_4_0_i53) AND
		LABEL(mercury__vn_filter__replace_in_user_instr_4_0_i55));
Define_label(mercury__vn_filter__replace_in_user_instr_4_0_i13);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	call_localret(STATIC(mercury__vn_filter__replace_in_rval_4_0),
		mercury__vn_filter__replace_in_user_instr_4_0_i14,
		STATIC(mercury__vn_filter__replace_in_user_instr_4_0));
Define_label(mercury__vn_filter__replace_in_user_instr_4_0_i14);
	update_prof_current_proc(LABEL(mercury__vn_filter__replace_in_user_instr_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 3, mercury__vn_filter__replace_in_user_instr_4_0, "llds:instr/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), r1, (Integer) 2) = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__vn_filter__replace_in_user_instr_4_0_i23);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__vn_filter__replace_in_rval_4_0),
		mercury__vn_filter__replace_in_user_instr_4_0_i24,
		STATIC(mercury__vn_filter__replace_in_user_instr_4_0));
Define_label(mercury__vn_filter__replace_in_user_instr_4_0_i24);
	update_prof_current_proc(LABEL(mercury__vn_filter__replace_in_user_instr_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 3, mercury__vn_filter__replace_in_user_instr_4_0, "llds:instr/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 6;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r2;
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__vn_filter__replace_in_user_instr_4_0_i27);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__vn_filter__replace_in_rval_4_0),
		mercury__vn_filter__replace_in_user_instr_4_0_i28,
		STATIC(mercury__vn_filter__replace_in_user_instr_4_0));
Define_label(mercury__vn_filter__replace_in_user_instr_4_0_i28);
	update_prof_current_proc(LABEL(mercury__vn_filter__replace_in_user_instr_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 3, mercury__vn_filter__replace_in_user_instr_4_0, "llds:instr/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 8;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r2;
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__vn_filter__replace_in_user_instr_4_0_i29);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r1, (Integer) 4);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	call_localret(STATIC(mercury__vn_filter__replace_in_rval_4_0),
		mercury__vn_filter__replace_in_user_instr_4_0_i30,
		STATIC(mercury__vn_filter__replace_in_user_instr_4_0));
Define_label(mercury__vn_filter__replace_in_user_instr_4_0_i30);
	update_prof_current_proc(LABEL(mercury__vn_filter__replace_in_user_instr_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 5, mercury__vn_filter__replace_in_user_instr_4_0, "llds:instr/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 9;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(3), r1, (Integer) 3) = r2;
	MR_field(MR_mktag(3), r1, (Integer) 4) = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__vn_filter__replace_in_user_instr_4_0_i33);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__vn_filter__replace_in_rval_4_0),
		mercury__vn_filter__replace_in_user_instr_4_0_i34,
		STATIC(mercury__vn_filter__replace_in_user_instr_4_0));
Define_label(mercury__vn_filter__replace_in_user_instr_4_0_i34);
	update_prof_current_proc(LABEL(mercury__vn_filter__replace_in_user_instr_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__vn_filter__replace_in_user_instr_4_0, "llds:instr/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 11;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__vn_filter__replace_in_user_instr_4_0_i37);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__vn_filter__replace_in_rval_4_0),
		mercury__vn_filter__replace_in_user_instr_4_0_i38,
		STATIC(mercury__vn_filter__replace_in_user_instr_4_0));
Define_label(mercury__vn_filter__replace_in_user_instr_4_0_i38);
	update_prof_current_proc(LABEL(mercury__vn_filter__replace_in_user_instr_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 3, mercury__vn_filter__replace_in_user_instr_4_0, "llds:instr/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 13;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r2;
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__vn_filter__replace_in_user_instr_4_0_i41);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__vn_filter__replace_in_rval_4_0),
		mercury__vn_filter__replace_in_user_instr_4_0_i42,
		STATIC(mercury__vn_filter__replace_in_user_instr_4_0));
Define_label(mercury__vn_filter__replace_in_user_instr_4_0_i42);
	update_prof_current_proc(LABEL(mercury__vn_filter__replace_in_user_instr_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__vn_filter__replace_in_user_instr_4_0, "llds:instr/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 15;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__vn_filter__replace_in_user_instr_4_0_i1009);
	r1 = (Word) MR_string_const("non-user instruction in vn_filter__replace_in_user_instr", 56);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__vn_filter__replace_in_user_instr_4_0));
Define_label(mercury__vn_filter__replace_in_user_instr_4_0_i45);
	r1 = (Word) MR_string_const("non-user instruction in vn_filter__replace_in_user_instr", 56);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__vn_filter__replace_in_user_instr_4_0));
Define_label(mercury__vn_filter__replace_in_user_instr_4_0_i47);
	r1 = (Word) MR_string_const("inappropriate instruction in vn__filter", 39);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__vn_filter__replace_in_user_instr_4_0));
Define_label(mercury__vn_filter__replace_in_user_instr_4_0_i49);
	r1 = (Word) MR_string_const("init_sync_term instruction in vn__filter", 40);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__vn_filter__replace_in_user_instr_4_0));
Define_label(mercury__vn_filter__replace_in_user_instr_4_0_i51);
	r1 = (Word) MR_string_const("fork instruction in vn__filter", 30);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__vn_filter__replace_in_user_instr_4_0));
Define_label(mercury__vn_filter__replace_in_user_instr_4_0_i53);
	r1 = (Word) MR_string_const("join_and_terminate instruction in vn__filter", 44);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__vn_filter__replace_in_user_instr_4_0));
Define_label(mercury__vn_filter__replace_in_user_instr_4_0_i55);
	r1 = (Word) MR_string_const("join_and_continue instruction in vn__filter", 43);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__vn_filter__replace_in_user_instr_4_0));
END_MODULE


BEGIN_MODULE(vn_filter_module4)
	init_entry(mercury__vn_filter__defining_instr_2_0);
	init_label(mercury__vn_filter__defining_instr_2_0_i7);
	init_label(mercury__vn_filter__defining_instr_2_0_i24);
	init_label(mercury__vn_filter__defining_instr_2_0_i27);
	init_label(mercury__vn_filter__defining_instr_2_0_i28);
	init_label(mercury__vn_filter__defining_instr_2_0_i30);
	init_label(mercury__vn_filter__defining_instr_2_0_i32);
	init_label(mercury__vn_filter__defining_instr_2_0_i34);
	init_label(mercury__vn_filter__defining_instr_2_0_i36);
BEGIN_CODE

/* code for predicate 'defining_instr'/2 in mode 0 */
Define_static(mercury__vn_filter__defining_instr_2_0);
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__vn_filter__defining_instr_2_0_i27) AND
		LABEL(mercury__vn_filter__defining_instr_2_0_i27) AND
		LABEL(mercury__vn_filter__defining_instr_2_0_i27) AND
		LABEL(mercury__vn_filter__defining_instr_2_0_i7));
Define_label(mercury__vn_filter__defining_instr_2_0_i7);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__vn_filter__defining_instr_2_0_i28) AND
		LABEL(mercury__vn_filter__defining_instr_2_0_i24) AND
		LABEL(mercury__vn_filter__defining_instr_2_0_i27) AND
		LABEL(mercury__vn_filter__defining_instr_2_0_i27) AND
		LABEL(mercury__vn_filter__defining_instr_2_0_i27) AND
		LABEL(mercury__vn_filter__defining_instr_2_0_i27) AND
		LABEL(mercury__vn_filter__defining_instr_2_0_i27) AND
		LABEL(mercury__vn_filter__defining_instr_2_0_i28) AND
		LABEL(mercury__vn_filter__defining_instr_2_0_i27) AND
		LABEL(mercury__vn_filter__defining_instr_2_0_i24) AND
		LABEL(mercury__vn_filter__defining_instr_2_0_i24) AND
		LABEL(mercury__vn_filter__defining_instr_2_0_i27) AND
		LABEL(mercury__vn_filter__defining_instr_2_0_i24) AND
		LABEL(mercury__vn_filter__defining_instr_2_0_i27) AND
		LABEL(mercury__vn_filter__defining_instr_2_0_i24) AND
		LABEL(mercury__vn_filter__defining_instr_2_0_i27) AND
		LABEL(mercury__vn_filter__defining_instr_2_0_i27) AND
		LABEL(mercury__vn_filter__defining_instr_2_0_i27) AND
		LABEL(mercury__vn_filter__defining_instr_2_0_i28) AND
		LABEL(mercury__vn_filter__defining_instr_2_0_i30) AND
		LABEL(mercury__vn_filter__defining_instr_2_0_i32) AND
		LABEL(mercury__vn_filter__defining_instr_2_0_i34) AND
		LABEL(mercury__vn_filter__defining_instr_2_0_i36));
Define_label(mercury__vn_filter__defining_instr_2_0_i24);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__vn_filter__defining_instr_2_0, "std_util:maybe/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	proceed();
Define_label(mercury__vn_filter__defining_instr_2_0_i27);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
Define_label(mercury__vn_filter__defining_instr_2_0_i28);
	r1 = (Word) MR_string_const("inappropriate instruction in vn__filter", 39);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__vn_filter__defining_instr_2_0));
Define_label(mercury__vn_filter__defining_instr_2_0_i30);
	r1 = (Word) MR_string_const("init_sync_term instruction in vn__filter", 40);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__vn_filter__defining_instr_2_0));
Define_label(mercury__vn_filter__defining_instr_2_0_i32);
	r1 = (Word) MR_string_const("fork instruction in vn__filter", 30);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__vn_filter__defining_instr_2_0));
Define_label(mercury__vn_filter__defining_instr_2_0_i34);
	r1 = (Word) MR_string_const("join_and_terminate instruction in vn__filter", 44);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__vn_filter__defining_instr_2_0));
Define_label(mercury__vn_filter__defining_instr_2_0_i36);
	r1 = (Word) MR_string_const("join_and_continue instruction in vn__filter", 43);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__vn_filter__defining_instr_2_0));
END_MODULE


BEGIN_MODULE(vn_filter_module5)
	init_entry(mercury__vn_filter__replace_in_defining_instr_4_0);
	init_label(mercury__vn_filter__replace_in_defining_instr_4_0_i10);
	init_label(mercury__vn_filter__replace_in_defining_instr_4_0_i13);
	init_label(mercury__vn_filter__replace_in_defining_instr_4_0_i14);
	init_label(mercury__vn_filter__replace_in_defining_instr_4_0_i29);
	init_label(mercury__vn_filter__replace_in_defining_instr_4_0_i30);
	init_label(mercury__vn_filter__replace_in_defining_instr_4_0_i31);
	init_label(mercury__vn_filter__replace_in_defining_instr_4_0_i32);
	init_label(mercury__vn_filter__replace_in_defining_instr_4_0_i35);
	init_label(mercury__vn_filter__replace_in_defining_instr_4_0_i36);
	init_label(mercury__vn_filter__replace_in_defining_instr_4_0_i39);
	init_label(mercury__vn_filter__replace_in_defining_instr_4_0_i40);
	init_label(mercury__vn_filter__replace_in_defining_instr_4_0_i1007);
	init_label(mercury__vn_filter__replace_in_defining_instr_4_0_i45);
	init_label(mercury__vn_filter__replace_in_defining_instr_4_0_i47);
	init_label(mercury__vn_filter__replace_in_defining_instr_4_0_i49);
	init_label(mercury__vn_filter__replace_in_defining_instr_4_0_i51);
	init_label(mercury__vn_filter__replace_in_defining_instr_4_0_i53);
	init_label(mercury__vn_filter__replace_in_defining_instr_4_0_i55);
BEGIN_CODE

/* code for predicate 'replace_in_defining_instr'/4 in mode 0 */
Define_static(mercury__vn_filter__replace_in_defining_instr_4_0);
	MR_incr_sp_push_msg(4, "vn_filter:replace_in_defining_instr/4");
	MR_stackvar(4) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__vn_filter__replace_in_defining_instr_4_0_i1007) AND
		LABEL(mercury__vn_filter__replace_in_defining_instr_4_0_i1007) AND
		LABEL(mercury__vn_filter__replace_in_defining_instr_4_0_i1007) AND
		LABEL(mercury__vn_filter__replace_in_defining_instr_4_0_i10));
Define_label(mercury__vn_filter__replace_in_defining_instr_4_0_i10);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__vn_filter__replace_in_defining_instr_4_0_i47) AND
		LABEL(mercury__vn_filter__replace_in_defining_instr_4_0_i13) AND
		LABEL(mercury__vn_filter__replace_in_defining_instr_4_0_i45) AND
		LABEL(mercury__vn_filter__replace_in_defining_instr_4_0_i45) AND
		LABEL(mercury__vn_filter__replace_in_defining_instr_4_0_i45) AND
		LABEL(mercury__vn_filter__replace_in_defining_instr_4_0_i45) AND
		LABEL(mercury__vn_filter__replace_in_defining_instr_4_0_i45) AND
		LABEL(mercury__vn_filter__replace_in_defining_instr_4_0_i47) AND
		LABEL(mercury__vn_filter__replace_in_defining_instr_4_0_i45) AND
		LABEL(mercury__vn_filter__replace_in_defining_instr_4_0_i29) AND
		LABEL(mercury__vn_filter__replace_in_defining_instr_4_0_i31) AND
		LABEL(mercury__vn_filter__replace_in_defining_instr_4_0_i45) AND
		LABEL(mercury__vn_filter__replace_in_defining_instr_4_0_i35) AND
		LABEL(mercury__vn_filter__replace_in_defining_instr_4_0_i45) AND
		LABEL(mercury__vn_filter__replace_in_defining_instr_4_0_i39) AND
		LABEL(mercury__vn_filter__replace_in_defining_instr_4_0_i45) AND
		LABEL(mercury__vn_filter__replace_in_defining_instr_4_0_i45) AND
		LABEL(mercury__vn_filter__replace_in_defining_instr_4_0_i45) AND
		LABEL(mercury__vn_filter__replace_in_defining_instr_4_0_i47) AND
		LABEL(mercury__vn_filter__replace_in_defining_instr_4_0_i49) AND
		LABEL(mercury__vn_filter__replace_in_defining_instr_4_0_i51) AND
		LABEL(mercury__vn_filter__replace_in_defining_instr_4_0_i53) AND
		LABEL(mercury__vn_filter__replace_in_defining_instr_4_0_i55));
Define_label(mercury__vn_filter__replace_in_defining_instr_4_0_i13);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__vn_filter__replace_in_lval_4_0),
		mercury__vn_filter__replace_in_defining_instr_4_0_i14,
		STATIC(mercury__vn_filter__replace_in_defining_instr_4_0));
Define_label(mercury__vn_filter__replace_in_defining_instr_4_0_i14);
	update_prof_current_proc(LABEL(mercury__vn_filter__replace_in_defining_instr_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 3, mercury__vn_filter__replace_in_defining_instr_4_0, "llds:instr/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r2;
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__vn_filter__replace_in_defining_instr_4_0_i29);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r1, (Integer) 4);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__vn_filter__replace_in_lval_4_0),
		mercury__vn_filter__replace_in_defining_instr_4_0_i30,
		STATIC(mercury__vn_filter__replace_in_defining_instr_4_0));
Define_label(mercury__vn_filter__replace_in_defining_instr_4_0_i30);
	update_prof_current_proc(LABEL(mercury__vn_filter__replace_in_defining_instr_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 5, mercury__vn_filter__replace_in_defining_instr_4_0, "llds:instr/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 9;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r2;
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_stackvar(1);
	MR_field(MR_mktag(3), r1, (Integer) 3) = MR_stackvar(2);
	MR_field(MR_mktag(3), r1, (Integer) 4) = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__vn_filter__replace_in_defining_instr_4_0_i31);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__vn_filter__replace_in_lval_4_0),
		mercury__vn_filter__replace_in_defining_instr_4_0_i32,
		STATIC(mercury__vn_filter__replace_in_defining_instr_4_0));
Define_label(mercury__vn_filter__replace_in_defining_instr_4_0_i32);
	update_prof_current_proc(LABEL(mercury__vn_filter__replace_in_defining_instr_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__vn_filter__replace_in_defining_instr_4_0, "llds:instr/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 10;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__vn_filter__replace_in_defining_instr_4_0_i35);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__vn_filter__replace_in_lval_4_0),
		mercury__vn_filter__replace_in_defining_instr_4_0_i36,
		STATIC(mercury__vn_filter__replace_in_defining_instr_4_0));
Define_label(mercury__vn_filter__replace_in_defining_instr_4_0_i36);
	update_prof_current_proc(LABEL(mercury__vn_filter__replace_in_defining_instr_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__vn_filter__replace_in_defining_instr_4_0, "llds:instr/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 12;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__vn_filter__replace_in_defining_instr_4_0_i39);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__vn_filter__replace_in_lval_4_0),
		mercury__vn_filter__replace_in_defining_instr_4_0_i40,
		STATIC(mercury__vn_filter__replace_in_defining_instr_4_0));
Define_label(mercury__vn_filter__replace_in_defining_instr_4_0_i40);
	update_prof_current_proc(LABEL(mercury__vn_filter__replace_in_defining_instr_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__vn_filter__replace_in_defining_instr_4_0, "llds:instr/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 14;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__vn_filter__replace_in_defining_instr_4_0_i1007);
	r1 = (Word) MR_string_const("non-def instruction in vn_filter__replace_in_defining_instr", 59);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__vn_filter__replace_in_defining_instr_4_0));
Define_label(mercury__vn_filter__replace_in_defining_instr_4_0_i45);
	r1 = (Word) MR_string_const("non-def instruction in vn_filter__replace_in_defining_instr", 59);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__vn_filter__replace_in_defining_instr_4_0));
Define_label(mercury__vn_filter__replace_in_defining_instr_4_0_i47);
	r1 = (Word) MR_string_const("inappropriate instruction in vn__filter", 39);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__vn_filter__replace_in_defining_instr_4_0));
Define_label(mercury__vn_filter__replace_in_defining_instr_4_0_i49);
	r1 = (Word) MR_string_const("init_sync_term instruction in vn_filter__replace_in_defining_instr", 66);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__vn_filter__replace_in_defining_instr_4_0));
Define_label(mercury__vn_filter__replace_in_defining_instr_4_0_i51);
	r1 = (Word) MR_string_const("fork instruction in vn_filter__replace_in_defining_instr", 56);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__vn_filter__replace_in_defining_instr_4_0));
Define_label(mercury__vn_filter__replace_in_defining_instr_4_0_i53);
	r1 = (Word) MR_string_const("join_and_terminate instruction in vn_filter__replace_in_defining_instr", 70);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__vn_filter__replace_in_defining_instr_4_0));
Define_label(mercury__vn_filter__replace_in_defining_instr_4_0_i55);
	r1 = (Word) MR_string_const("join_and_continue instruction in vn_filter__replace_in_defining_instr", 69);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__vn_filter__replace_in_defining_instr_4_0));
END_MODULE


BEGIN_MODULE(vn_filter_module6)
	init_entry(mercury__vn_filter__replace_in_lval_4_0);
	init_label(mercury__vn_filter__replace_in_lval_4_0_i4);
	init_label(mercury__vn_filter__replace_in_lval_4_0_i5);
	init_label(mercury__vn_filter__replace_in_lval_4_0_i6);
	init_label(mercury__vn_filter__replace_in_lval_4_0_i7);
	init_label(mercury__vn_filter__replace_in_lval_4_0_i8);
	init_label(mercury__vn_filter__replace_in_lval_4_0_i9);
	init_label(mercury__vn_filter__replace_in_lval_4_0_i12);
	init_label(mercury__vn_filter__replace_in_lval_4_0_i15);
	init_label(mercury__vn_filter__replace_in_lval_4_0_i16);
	init_label(mercury__vn_filter__replace_in_lval_4_0_i17);
	init_label(mercury__vn_filter__replace_in_lval_4_0_i18);
	init_label(mercury__vn_filter__replace_in_lval_4_0_i19);
	init_label(mercury__vn_filter__replace_in_lval_4_0_i20);
	init_label(mercury__vn_filter__replace_in_lval_4_0_i21);
	init_label(mercury__vn_filter__replace_in_lval_4_0_i22);
	init_label(mercury__vn_filter__replace_in_lval_4_0_i23);
	init_label(mercury__vn_filter__replace_in_lval_4_0_i24);
	init_label(mercury__vn_filter__replace_in_lval_4_0_i25);
	init_label(mercury__vn_filter__replace_in_lval_4_0_i26);
	init_label(mercury__vn_filter__replace_in_lval_4_0_i27);
	init_label(mercury__vn_filter__replace_in_lval_4_0_i28);
	init_label(mercury__vn_filter__replace_in_lval_4_0_i29);
	init_label(mercury__vn_filter__replace_in_lval_4_0_i30);
	init_label(mercury__vn_filter__replace_in_lval_4_0_i1009);
	init_label(mercury__vn_filter__replace_in_lval_4_0_i2);
BEGIN_CODE

/* code for predicate 'replace_in_lval'/4 in mode 0 */
Define_static(mercury__vn_filter__replace_in_lval_4_0);
	MR_incr_sp_push_msg(5, "vn_filter:replace_in_lval/4");
	MR_stackvar(5) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__vn_filter__replace_in_lval_4_0_i4) AND
		LABEL(mercury__vn_filter__replace_in_lval_4_0_i1009) AND
		LABEL(mercury__vn_filter__replace_in_lval_4_0_i1009) AND
		LABEL(mercury__vn_filter__replace_in_lval_4_0_i12));
Define_label(mercury__vn_filter__replace_in_lval_4_0_i4);
	COMPUTED_GOTO((Unsigned) MR_unmkbody(r1),
		LABEL(mercury__vn_filter__replace_in_lval_4_0_i5) AND
		LABEL(mercury__vn_filter__replace_in_lval_4_0_i6) AND
		LABEL(mercury__vn_filter__replace_in_lval_4_0_i7) AND
		LABEL(mercury__vn_filter__replace_in_lval_4_0_i8) AND
		LABEL(mercury__vn_filter__replace_in_lval_4_0_i9));
Define_label(mercury__vn_filter__replace_in_lval_4_0_i5);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_filter__replace_in_lval_4_0_i6);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1));
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_filter__replace_in_lval_4_0_i7);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 2));
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_filter__replace_in_lval_4_0_i8);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 3));
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_filter__replace_in_lval_4_0_i9);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 4));
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_filter__replace_in_lval_4_0_i12);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__vn_filter__replace_in_lval_4_0_i2) AND
		LABEL(mercury__vn_filter__replace_in_lval_4_0_i2) AND
		LABEL(mercury__vn_filter__replace_in_lval_4_0_i15) AND
		LABEL(mercury__vn_filter__replace_in_lval_4_0_i17) AND
		LABEL(mercury__vn_filter__replace_in_lval_4_0_i19) AND
		LABEL(mercury__vn_filter__replace_in_lval_4_0_i21) AND
		LABEL(mercury__vn_filter__replace_in_lval_4_0_i23) AND
		LABEL(mercury__vn_filter__replace_in_lval_4_0_i25) AND
		LABEL(mercury__vn_filter__replace_in_lval_4_0_i28) AND
		LABEL(mercury__vn_filter__replace_in_lval_4_0_i30));
Define_label(mercury__vn_filter__replace_in_lval_4_0_i15);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__vn_filter__replace_in_rval_4_0),
		mercury__vn_filter__replace_in_lval_4_0_i16,
		STATIC(mercury__vn_filter__replace_in_lval_4_0));
Define_label(mercury__vn_filter__replace_in_lval_4_0_i16);
	update_prof_current_proc(LABEL(mercury__vn_filter__replace_in_lval_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__vn_filter__replace_in_lval_4_0, "llds:lval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_filter__replace_in_lval_4_0_i17);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__vn_filter__replace_in_rval_4_0),
		mercury__vn_filter__replace_in_lval_4_0_i18,
		STATIC(mercury__vn_filter__replace_in_lval_4_0));
Define_label(mercury__vn_filter__replace_in_lval_4_0_i18);
	update_prof_current_proc(LABEL(mercury__vn_filter__replace_in_lval_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__vn_filter__replace_in_lval_4_0, "llds:lval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_filter__replace_in_lval_4_0_i19);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__vn_filter__replace_in_rval_4_0),
		mercury__vn_filter__replace_in_lval_4_0_i20,
		STATIC(mercury__vn_filter__replace_in_lval_4_0));
Define_label(mercury__vn_filter__replace_in_lval_4_0_i20);
	update_prof_current_proc(LABEL(mercury__vn_filter__replace_in_lval_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__vn_filter__replace_in_lval_4_0, "llds:lval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_filter__replace_in_lval_4_0_i21);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__vn_filter__replace_in_rval_4_0),
		mercury__vn_filter__replace_in_lval_4_0_i22,
		STATIC(mercury__vn_filter__replace_in_lval_4_0));
Define_label(mercury__vn_filter__replace_in_lval_4_0_i22);
	update_prof_current_proc(LABEL(mercury__vn_filter__replace_in_lval_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__vn_filter__replace_in_lval_4_0, "llds:lval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 5;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_filter__replace_in_lval_4_0_i23);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__vn_filter__replace_in_rval_4_0),
		mercury__vn_filter__replace_in_lval_4_0_i24,
		STATIC(mercury__vn_filter__replace_in_lval_4_0));
Define_label(mercury__vn_filter__replace_in_lval_4_0_i24);
	update_prof_current_proc(LABEL(mercury__vn_filter__replace_in_lval_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__vn_filter__replace_in_lval_4_0, "llds:lval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 6;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_filter__replace_in_lval_4_0_i25);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	call_localret(STATIC(mercury__vn_filter__replace_in_rval_4_0),
		mercury__vn_filter__replace_in_lval_4_0_i26,
		STATIC(mercury__vn_filter__replace_in_lval_4_0));
Define_label(mercury__vn_filter__replace_in_lval_4_0_i26);
	update_prof_current_proc(LABEL(mercury__vn_filter__replace_in_lval_4_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(4);
	r3 = MR_stackvar(2);
	call_localret(STATIC(mercury__vn_filter__replace_in_rval_4_0),
		mercury__vn_filter__replace_in_lval_4_0_i27,
		STATIC(mercury__vn_filter__replace_in_lval_4_0));
Define_label(mercury__vn_filter__replace_in_lval_4_0_i27);
	update_prof_current_proc(LABEL(mercury__vn_filter__replace_in_lval_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__vn_filter__replace_in_lval_4_0, "llds:lval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 7;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_stackvar(3);
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_stackvar(1);
	MR_field(MR_mktag(3), r1, (Integer) 3) = r2;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_filter__replace_in_lval_4_0_i28);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__vn_filter__replace_in_rval_4_0),
		mercury__vn_filter__replace_in_lval_4_0_i29,
		STATIC(mercury__vn_filter__replace_in_lval_4_0));
Define_label(mercury__vn_filter__replace_in_lval_4_0_i29);
	update_prof_current_proc(LABEL(mercury__vn_filter__replace_in_lval_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__vn_filter__replace_in_lval_4_0, "llds:lval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 8;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_filter__replace_in_lval_4_0_i30);
	r1 = (Word) MR_string_const("found lvar in vn_filter__replace_in_lval", 40);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__vn_filter__replace_in_lval_4_0));
Define_label(mercury__vn_filter__replace_in_lval_4_0_i1009);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_filter__replace_in_lval_4_0_i2);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE


BEGIN_MODULE(vn_filter_module7)
	init_entry(mercury__vn_filter__replace_in_rval_4_0);
	init_label(mercury__vn_filter__replace_in_rval_4_0_i4);
	init_label(mercury__vn_filter__replace_in_rval_4_0_i7);
	init_label(mercury__vn_filter__replace_in_rval_4_0_i5);
	init_label(mercury__vn_filter__replace_in_rval_4_0_i9);
	init_label(mercury__vn_filter__replace_in_rval_4_0_i1007);
	init_label(mercury__vn_filter__replace_in_rval_4_0_i14);
	init_label(mercury__vn_filter__replace_in_rval_4_0_i15);
	init_label(mercury__vn_filter__replace_in_rval_4_0_i16);
	init_label(mercury__vn_filter__replace_in_rval_4_0_i18);
	init_label(mercury__vn_filter__replace_in_rval_4_0_i19);
	init_label(mercury__vn_filter__replace_in_rval_4_0_i20);
	init_label(mercury__vn_filter__replace_in_rval_4_0_i21);
	init_label(mercury__vn_filter__replace_in_rval_4_0_i22);
	init_label(mercury__vn_filter__replace_in_rval_4_0_i23);
	init_label(mercury__vn_filter__replace_in_rval_4_0_i24);
	init_label(mercury__vn_filter__replace_in_rval_4_0_i1008);
	init_label(mercury__vn_filter__replace_in_rval_4_0_i2);
BEGIN_CODE

/* code for predicate 'replace_in_rval'/4 in mode 0 */
Define_static(mercury__vn_filter__replace_in_rval_4_0);
	MR_incr_sp_push_msg(5, "vn_filter:replace_in_rval/4");
	MR_stackvar(5) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__vn_filter__replace_in_rval_4_0_i4) AND
		LABEL(mercury__vn_filter__replace_in_rval_4_0_i1007) AND
		LABEL(mercury__vn_filter__replace_in_rval_4_0_i1008) AND
		LABEL(mercury__vn_filter__replace_in_rval_4_0_i14));
Define_label(mercury__vn_filter__replace_in_rval_4_0_i4);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(3) = r1;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury____Unify___llds__lval_0_0),
		mercury__vn_filter__replace_in_rval_4_0_i7,
		STATIC(mercury__vn_filter__replace_in_rval_4_0));
Define_label(mercury__vn_filter__replace_in_rval_4_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_filter__replace_in_rval_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_filter__replace_in_rval_4_0_i5);
	r1 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_filter__replace_in_rval_4_0_i5);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	call_localret(STATIC(mercury__vn_filter__replace_in_lval_4_0),
		mercury__vn_filter__replace_in_rval_4_0_i9,
		STATIC(mercury__vn_filter__replace_in_rval_4_0));
Define_label(mercury__vn_filter__replace_in_rval_4_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_filter__replace_in_rval_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 1, mercury__vn_filter__replace_in_rval_4_0, "llds:rval/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_filter__replace_in_rval_4_0_i1007);
	r1 = (Word) MR_string_const("found var in vn_filter__replace_in_rval", 39);
	MR_decr_sp_pop_msg(5);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__vn_filter__replace_in_rval_4_0));
Define_label(mercury__vn_filter__replace_in_rval_4_0_i14);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__vn_filter__replace_in_rval_4_0_i15) AND
		LABEL(mercury__vn_filter__replace_in_rval_4_0_i2) AND
		LABEL(mercury__vn_filter__replace_in_rval_4_0_i18) AND
		LABEL(mercury__vn_filter__replace_in_rval_4_0_i20) AND
		LABEL(mercury__vn_filter__replace_in_rval_4_0_i23));
Define_label(mercury__vn_filter__replace_in_rval_4_0_i15);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	localcall(mercury__vn_filter__replace_in_rval_4_0,
		LABEL(mercury__vn_filter__replace_in_rval_4_0_i16),
		STATIC(mercury__vn_filter__replace_in_rval_4_0));
Define_label(mercury__vn_filter__replace_in_rval_4_0_i16);
	update_prof_current_proc(LABEL(mercury__vn_filter__replace_in_rval_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 3, mercury__vn_filter__replace_in_rval_4_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), r1, (Integer) 2) = r2;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_filter__replace_in_rval_4_0_i18);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	localcall(mercury__vn_filter__replace_in_rval_4_0,
		LABEL(mercury__vn_filter__replace_in_rval_4_0_i19),
		STATIC(mercury__vn_filter__replace_in_rval_4_0));
Define_label(mercury__vn_filter__replace_in_rval_4_0_i19);
	update_prof_current_proc(LABEL(mercury__vn_filter__replace_in_rval_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 3, mercury__vn_filter__replace_in_rval_4_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), r1, (Integer) 2) = r2;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_filter__replace_in_rval_4_0_i20);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	localcall(mercury__vn_filter__replace_in_rval_4_0,
		LABEL(mercury__vn_filter__replace_in_rval_4_0_i21),
		STATIC(mercury__vn_filter__replace_in_rval_4_0));
Define_label(mercury__vn_filter__replace_in_rval_4_0_i21);
	update_prof_current_proc(LABEL(mercury__vn_filter__replace_in_rval_4_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(4);
	r3 = MR_stackvar(2);
	localcall(mercury__vn_filter__replace_in_rval_4_0,
		LABEL(mercury__vn_filter__replace_in_rval_4_0_i22),
		STATIC(mercury__vn_filter__replace_in_rval_4_0));
Define_label(mercury__vn_filter__replace_in_rval_4_0_i22);
	update_prof_current_proc(LABEL(mercury__vn_filter__replace_in_rval_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__vn_filter__replace_in_rval_4_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_stackvar(3);
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_stackvar(1);
	MR_field(MR_mktag(3), r1, (Integer) 3) = r2;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_filter__replace_in_rval_4_0_i23);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__vn_filter__replace_in_mem_ref_4_0),
		mercury__vn_filter__replace_in_rval_4_0_i24,
		STATIC(mercury__vn_filter__replace_in_rval_4_0));
Define_label(mercury__vn_filter__replace_in_rval_4_0_i24);
	update_prof_current_proc(LABEL(mercury__vn_filter__replace_in_rval_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__vn_filter__replace_in_rval_4_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_filter__replace_in_rval_4_0_i1008);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_filter__replace_in_rval_4_0_i2);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE


BEGIN_MODULE(vn_filter_module8)
	init_entry(mercury__vn_filter__replace_in_mem_ref_4_0);
	init_label(mercury__vn_filter__replace_in_mem_ref_4_0_i6);
	init_label(mercury__vn_filter__replace_in_mem_ref_4_0_i1004);
BEGIN_CODE

/* code for predicate 'replace_in_mem_ref'/4 in mode 0 */
Define_static(mercury__vn_filter__replace_in_mem_ref_4_0);
	if ((MR_tag(r1) == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_filter__replace_in_mem_ref_4_0_i1004);
	if ((MR_tag(r1) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_filter__replace_in_mem_ref_4_0_i1004);
	MR_incr_sp_push_msg(3, "vn_filter:replace_in_mem_ref/4");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(2), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(2), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	call_localret(STATIC(mercury__vn_filter__replace_in_rval_4_0),
		mercury__vn_filter__replace_in_mem_ref_4_0_i6,
		STATIC(mercury__vn_filter__replace_in_mem_ref_4_0));
Define_label(mercury__vn_filter__replace_in_mem_ref_4_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_filter__replace_in_mem_ref_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 3, mercury__vn_filter__replace_in_mem_ref_4_0, "llds:mem_ref/0");
	MR_field(MR_mktag(2), r1, (Integer) 0) = r2;
	MR_field(MR_mktag(2), r1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(2), r1, (Integer) 2) = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_filter__replace_in_mem_ref_4_0_i1004);
	proceed();
END_MODULE

Declare_entry(mercury__opt_util__rval_free_of_lval_2_0);
Declare_entry(mercury__opt_util__lval_access_rvals_2_0);
Declare_entry(mercury__opt_util__rvals_free_of_lval_2_0);

BEGIN_MODULE(vn_filter_module9)
	init_entry(mercury__vn_filter__instrs_free_of_lval_2_0);
	init_label(mercury__vn_filter__instrs_free_of_lval_2_0_i1011);
	init_label(mercury__vn_filter__instrs_free_of_lval_2_0_i11);
	init_label(mercury__vn_filter__instrs_free_of_lval_2_0_i12);
	init_label(mercury__vn_filter__instrs_free_of_lval_2_0_i14);
	init_label(mercury__vn_filter__instrs_free_of_lval_2_0_i20);
	init_label(mercury__vn_filter__instrs_free_of_lval_2_0_i23);
	init_label(mercury__vn_filter__instrs_free_of_lval_2_0_i29);
	init_label(mercury__vn_filter__instrs_free_of_lval_2_0_i31);
	init_label(mercury__vn_filter__instrs_free_of_lval_2_0_i32);
	init_label(mercury__vn_filter__instrs_free_of_lval_2_0_i34);
	init_label(mercury__vn_filter__instrs_free_of_lval_2_0_i36);
	init_label(mercury__vn_filter__instrs_free_of_lval_2_0_i38);
	init_label(mercury__vn_filter__instrs_free_of_lval_2_0_i40);
	init_label(mercury__vn_filter__instrs_free_of_lval_2_0_i41);
	init_label(mercury__vn_filter__instrs_free_of_lval_2_0_i6);
	init_label(mercury__vn_filter__instrs_free_of_lval_2_0_i42);
	init_label(mercury__vn_filter__instrs_free_of_lval_2_0_i43);
	init_label(mercury__vn_filter__instrs_free_of_lval_2_0_i1014);
	init_label(mercury__vn_filter__instrs_free_of_lval_2_0_i47);
	init_label(mercury__vn_filter__instrs_free_of_lval_2_0_i51);
	init_label(mercury__vn_filter__instrs_free_of_lval_2_0_i53);
	init_label(mercury__vn_filter__instrs_free_of_lval_2_0_i54);
	init_label(mercury__vn_filter__instrs_free_of_lval_2_0_i1005);
	init_label(mercury__vn_filter__instrs_free_of_lval_2_0_i2);
	init_label(mercury__vn_filter__instrs_free_of_lval_2_0_i1);
BEGIN_CODE

/* code for predicate 'instrs_free_of_lval'/2 in mode 0 */
Define_static(mercury__vn_filter__instrs_free_of_lval_2_0);
	MR_incr_sp_push_msg(5, "vn_filter:instrs_free_of_lval/2");
	MR_stackvar(5) = (Word) MR_succip;
Define_label(mercury__vn_filter__instrs_free_of_lval_2_0_i1011);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_filter__instrs_free_of_lval_2_0_i2);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r4 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0);
	COMPUTED_GOTO((Unsigned) MR_tag(r4),
		LABEL(mercury__vn_filter__instrs_free_of_lval_2_0_i31) AND
		LABEL(mercury__vn_filter__instrs_free_of_lval_2_0_i31) AND
		LABEL(mercury__vn_filter__instrs_free_of_lval_2_0_i31) AND
		LABEL(mercury__vn_filter__instrs_free_of_lval_2_0_i11));
Define_label(mercury__vn_filter__instrs_free_of_lval_2_0_i11);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r4, (Integer) 0),
		LABEL(mercury__vn_filter__instrs_free_of_lval_2_0_i12) AND
		LABEL(mercury__vn_filter__instrs_free_of_lval_2_0_i14) AND
		LABEL(mercury__vn_filter__instrs_free_of_lval_2_0_i31) AND
		LABEL(mercury__vn_filter__instrs_free_of_lval_2_0_i31) AND
		LABEL(mercury__vn_filter__instrs_free_of_lval_2_0_i31) AND
		LABEL(mercury__vn_filter__instrs_free_of_lval_2_0_i31) AND
		LABEL(mercury__vn_filter__instrs_free_of_lval_2_0_i29) AND
		LABEL(mercury__vn_filter__instrs_free_of_lval_2_0_i20) AND
		LABEL(mercury__vn_filter__instrs_free_of_lval_2_0_i29) AND
		LABEL(mercury__vn_filter__instrs_free_of_lval_2_0_i23) AND
		LABEL(mercury__vn_filter__instrs_free_of_lval_2_0_i31) AND
		LABEL(mercury__vn_filter__instrs_free_of_lval_2_0_i29) AND
		LABEL(mercury__vn_filter__instrs_free_of_lval_2_0_i31) AND
		LABEL(mercury__vn_filter__instrs_free_of_lval_2_0_i29) AND
		LABEL(mercury__vn_filter__instrs_free_of_lval_2_0_i31) AND
		LABEL(mercury__vn_filter__instrs_free_of_lval_2_0_i29) AND
		LABEL(mercury__vn_filter__instrs_free_of_lval_2_0_i31) AND
		LABEL(mercury__vn_filter__instrs_free_of_lval_2_0_i31) AND
		LABEL(mercury__vn_filter__instrs_free_of_lval_2_0_i32) AND
		LABEL(mercury__vn_filter__instrs_free_of_lval_2_0_i34) AND
		LABEL(mercury__vn_filter__instrs_free_of_lval_2_0_i36) AND
		LABEL(mercury__vn_filter__instrs_free_of_lval_2_0_i38) AND
		LABEL(mercury__vn_filter__instrs_free_of_lval_2_0_i40));
Define_label(mercury__vn_filter__instrs_free_of_lval_2_0_i12);
	r1 = (Word) MR_string_const("inappropriate instruction in vn__filter", 39);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r4;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_filter__instrs_free_of_lval_2_0_i41,
		STATIC(mercury__vn_filter__instrs_free_of_lval_2_0));
Define_label(mercury__vn_filter__instrs_free_of_lval_2_0_i14);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__vn_filter__instrs_free_of_lval_2_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_const_field(MR_mktag(3), r4, (Integer) 2);
	MR_stackvar(3) = r3;
	MR_stackvar(2) = r4;
	GOTO_LABEL(mercury__vn_filter__instrs_free_of_lval_2_0_i6);
Define_label(mercury__vn_filter__instrs_free_of_lval_2_0_i20);
	r1 = (Word) MR_string_const("inappropriate instruction in vn__filter", 39);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r4;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_filter__instrs_free_of_lval_2_0_i41,
		STATIC(mercury__vn_filter__instrs_free_of_lval_2_0));
Define_label(mercury__vn_filter__instrs_free_of_lval_2_0_i23);
	MR_stackvar(2) = r4;
	MR_stackvar(3) = r3;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__vn_filter__instrs_free_of_lval_2_0, "std_util:maybe/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_const_field(MR_mktag(3), r4, (Integer) 3);
	GOTO_LABEL(mercury__vn_filter__instrs_free_of_lval_2_0_i6);
Define_label(mercury__vn_filter__instrs_free_of_lval_2_0_i29);
	MR_stackvar(2) = r4;
	MR_stackvar(3) = r3;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__vn_filter__instrs_free_of_lval_2_0, "std_util:maybe/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_const_field(MR_mktag(3), r4, (Integer) 1);
	GOTO_LABEL(mercury__vn_filter__instrs_free_of_lval_2_0_i6);
Define_label(mercury__vn_filter__instrs_free_of_lval_2_0_i31);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_stackvar(2) = r4;
	MR_stackvar(3) = r3;
	GOTO_LABEL(mercury__vn_filter__instrs_free_of_lval_2_0_i6);
Define_label(mercury__vn_filter__instrs_free_of_lval_2_0_i32);
	r1 = (Word) MR_string_const("inappropriate instruction in vn__filter", 39);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r4;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_filter__instrs_free_of_lval_2_0_i41,
		STATIC(mercury__vn_filter__instrs_free_of_lval_2_0));
Define_label(mercury__vn_filter__instrs_free_of_lval_2_0_i34);
	r1 = (Word) MR_string_const("init_sync_term instruction in vn__filter", 40);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r4;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_filter__instrs_free_of_lval_2_0_i41,
		STATIC(mercury__vn_filter__instrs_free_of_lval_2_0));
Define_label(mercury__vn_filter__instrs_free_of_lval_2_0_i36);
	r1 = (Word) MR_string_const("fork instruction in vn__filter", 30);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r4;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_filter__instrs_free_of_lval_2_0_i41,
		STATIC(mercury__vn_filter__instrs_free_of_lval_2_0));
Define_label(mercury__vn_filter__instrs_free_of_lval_2_0_i38);
	r1 = (Word) MR_string_const("join_and_terminate instruction in vn__filter", 44);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r4;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_filter__instrs_free_of_lval_2_0_i41,
		STATIC(mercury__vn_filter__instrs_free_of_lval_2_0));
Define_label(mercury__vn_filter__instrs_free_of_lval_2_0_i40);
	r1 = (Word) MR_string_const("join_and_continue instruction in vn__filter", 43);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r4;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_filter__instrs_free_of_lval_2_0_i41,
		STATIC(mercury__vn_filter__instrs_free_of_lval_2_0));
Define_label(mercury__vn_filter__instrs_free_of_lval_2_0_i41);
	update_prof_current_proc(LABEL(mercury__vn_filter__instrs_free_of_lval_2_0));
	r2 = MR_stackvar(1);
Define_label(mercury__vn_filter__instrs_free_of_lval_2_0_i6);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_filter__instrs_free_of_lval_2_0_i42);
	MR_stackvar(1) = r2;
	GOTO_LABEL(mercury__vn_filter__instrs_free_of_lval_2_0_i1014);
Define_label(mercury__vn_filter__instrs_free_of_lval_2_0_i42);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__opt_util__rval_free_of_lval_2_0),
		mercury__vn_filter__instrs_free_of_lval_2_0_i43,
		STATIC(mercury__vn_filter__instrs_free_of_lval_2_0));
Define_label(mercury__vn_filter__instrs_free_of_lval_2_0_i43);
	update_prof_current_proc(LABEL(mercury__vn_filter__instrs_free_of_lval_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_filter__instrs_free_of_lval_2_0_i1);
Define_label(mercury__vn_filter__instrs_free_of_lval_2_0_i1014);
	r1 = MR_stackvar(2);
	call_localret(STATIC(mercury__vn_filter__defining_instr_2_0),
		mercury__vn_filter__instrs_free_of_lval_2_0_i47,
		STATIC(mercury__vn_filter__instrs_free_of_lval_2_0));
Define_label(mercury__vn_filter__instrs_free_of_lval_2_0_i47);
	update_prof_current_proc(LABEL(mercury__vn_filter__instrs_free_of_lval_2_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_filter__instrs_free_of_lval_2_0_i1005);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(4) = r1;
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury____Unify___llds__lval_0_0),
		mercury__vn_filter__instrs_free_of_lval_2_0_i51,
		STATIC(mercury__vn_filter__instrs_free_of_lval_2_0));
Define_label(mercury__vn_filter__instrs_free_of_lval_2_0_i51);
	update_prof_current_proc(LABEL(mercury__vn_filter__instrs_free_of_lval_2_0));
	if (r1)
		GOTO_LABEL(mercury__vn_filter__instrs_free_of_lval_2_0_i1);
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__opt_util__lval_access_rvals_2_0),
		mercury__vn_filter__instrs_free_of_lval_2_0_i53,
		STATIC(mercury__vn_filter__instrs_free_of_lval_2_0));
Define_label(mercury__vn_filter__instrs_free_of_lval_2_0_i53);
	update_prof_current_proc(LABEL(mercury__vn_filter__instrs_free_of_lval_2_0));
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__opt_util__rvals_free_of_lval_2_0),
		mercury__vn_filter__instrs_free_of_lval_2_0_i54,
		STATIC(mercury__vn_filter__instrs_free_of_lval_2_0));
Define_label(mercury__vn_filter__instrs_free_of_lval_2_0_i54);
	update_prof_current_proc(LABEL(mercury__vn_filter__instrs_free_of_lval_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_filter__instrs_free_of_lval_2_0_i1);
Define_label(mercury__vn_filter__instrs_free_of_lval_2_0_i1005);
	r2 = MR_stackvar(1);
	r1 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(5);
	GOTO_LABEL(mercury__vn_filter__instrs_free_of_lval_2_0_i1011);
Define_label(mercury__vn_filter__instrs_free_of_lval_2_0_i2);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_filter__instrs_free_of_lval_2_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__vn_filter_maybe_bunch_0(void)
{
	vn_filter_module0();
	vn_filter_module1();
	vn_filter_module2();
	vn_filter_module3();
	vn_filter_module4();
	vn_filter_module5();
	vn_filter_module6();
	vn_filter_module7();
	vn_filter_module8();
	vn_filter_module9();
}

#endif

void mercury__vn_filter__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__vn_filter__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__vn_filter_maybe_bunch_0();
#endif

	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
