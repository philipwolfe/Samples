/*
** Automatically generated from `vn_flush.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__vn_flush__init
ENDINIT
*/

#include "mercury_imp.h"

Define_extern_entry(mercury__vn_flush__nodelist_8_0);
Declare_label(mercury__vn_flush__nodelist_8_0_i4);
Declare_label(mercury__vn_flush__nodelist_8_0_i6);
Declare_label(mercury__vn_flush__nodelist_8_0_i8);
Declare_label(mercury__vn_flush__nodelist_8_0_i9);
Declare_label(mercury__vn_flush__nodelist_8_0_i3);
Declare_static(mercury__vn_flush__node_12_0);
Declare_label(mercury__vn_flush__node_12_0_i2);
Declare_label(mercury__vn_flush__node_12_0_i5);
Declare_label(mercury__vn_flush__node_12_0_i7);
Declare_label(mercury__vn_flush__node_12_0_i8);
Declare_label(mercury__vn_flush__node_12_0_i6);
Declare_label(mercury__vn_flush__node_12_0_i10);
Declare_label(mercury__vn_flush__node_12_0_i12);
Declare_label(mercury__vn_flush__node_12_0_i14);
Declare_label(mercury__vn_flush__node_12_0_i15);
Declare_label(mercury__vn_flush__node_12_0_i11);
Declare_label(mercury__vn_flush__node_12_0_i16);
Declare_label(mercury__vn_flush__node_12_0_i18);
Declare_label(mercury__vn_flush__node_12_0_i20);
Declare_label(mercury__vn_flush__node_12_0_i1013);
Declare_label(mercury__vn_flush__node_12_0_i22);
Declare_label(mercury__vn_flush__node_12_0_i17);
Declare_label(mercury__vn_flush__node_12_0_i23);
Declare_label(mercury__vn_flush__node_12_0_i26);
Declare_label(mercury__vn_flush__node_12_0_i27);
Declare_label(mercury__vn_flush__node_12_0_i28);
Declare_label(mercury__vn_flush__node_12_0_i29);
Declare_label(mercury__vn_flush__node_12_0_i30);
Declare_label(mercury__vn_flush__node_12_0_i31);
Declare_label(mercury__vn_flush__node_12_0_i3);
Declare_label(mercury__vn_flush__node_12_0_i32);
Declare_static(mercury__vn_flush__lval_node_12_0);
Declare_label(mercury__vn_flush__lval_node_12_0_i2);
Declare_label(mercury__vn_flush__lval_node_12_0_i3);
Declare_label(mercury__vn_flush__lval_node_12_0_i6);
Declare_label(mercury__vn_flush__lval_node_12_0_i8);
Declare_label(mercury__vn_flush__lval_node_12_0_i9);
Declare_label(mercury__vn_flush__lval_node_12_0_i15);
Declare_label(mercury__vn_flush__lval_node_12_0_i16);
Declare_label(mercury__vn_flush__lval_node_12_0_i17);
Declare_label(mercury__vn_flush__lval_node_12_0_i18);
Declare_label(mercury__vn_flush__lval_node_12_0_i1021);
Declare_label(mercury__vn_flush__lval_node_12_0_i19);
Declare_label(mercury__vn_flush__lval_node_12_0_i20);
Declare_label(mercury__vn_flush__lval_node_12_0_i22);
Declare_label(mercury__vn_flush__lval_node_12_0_i24);
Declare_label(mercury__vn_flush__lval_node_12_0_i1025);
Declare_label(mercury__vn_flush__lval_node_12_0_i26);
Declare_label(mercury__vn_flush__lval_node_12_0_i21);
Declare_label(mercury__vn_flush__lval_node_12_0_i27);
Declare_label(mercury__vn_flush__lval_node_12_0_i29);
Declare_label(mercury__vn_flush__lval_node_12_0_i5);
Declare_label(mercury__vn_flush__lval_node_12_0_i31);
Declare_label(mercury__vn_flush__lval_node_12_0_i33);
Declare_label(mercury__vn_flush__lval_node_12_0_i1029);
Declare_label(mercury__vn_flush__lval_node_12_0_i35);
Declare_label(mercury__vn_flush__lval_node_12_0_i30);
Declare_label(mercury__vn_flush__lval_node_12_0_i36);
Declare_static(mercury__vn_flush__ctrl_node_8_0);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i1065);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i5);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i6);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i7);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i8);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i9);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i10);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i11);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i12);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i13);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i14);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i15);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i17);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i18);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i20);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i21);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i22);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i23);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i25);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i26);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i27);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i29);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i30);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i31);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i32);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i34);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i35);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i37);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i38);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i39);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i40);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i42);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i43);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i44);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i45);
Declare_label(mercury__vn_flush__ctrl_node_8_0_i46);
Declare_static(mercury__vn_flush__choose_loc_for_shared_vn_5_0);
Declare_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i3);
Declare_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i4);
Declare_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i6);
Declare_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i7);
Declare_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i11);
Declare_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i10);
Declare_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i12);
Declare_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i13);
Declare_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i16);
Declare_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i2);
Declare_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i21);
Declare_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i20);
Declare_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i24);
Declare_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i25);
Declare_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i27);
Declare_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i28);
Declare_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i32);
Declare_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i31);
Declare_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i33);
Declare_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i34);
Declare_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i36);
Declare_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i18);
Declare_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i38);
Declare_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i39);
Declare_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i40);
Declare_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i43);
Declare_static(mercury__vn_flush__find_cheap_users_3_0);
Declare_label(mercury__vn_flush__find_cheap_users_3_0_i4);
Declare_label(mercury__vn_flush__find_cheap_users_3_0_i3);
Declare_static(mercury__vn_flush__find_cheap_users_2_3_0);
Declare_label(mercury__vn_flush__find_cheap_users_2_3_0_i4);
Declare_label(mercury__vn_flush__find_cheap_users_2_3_0_i9);
Declare_label(mercury__vn_flush__find_cheap_users_2_3_0_i11);
Declare_label(mercury__vn_flush__find_cheap_users_2_3_0_i1003);
Declare_label(mercury__vn_flush__find_cheap_users_2_3_0_i12);
Declare_label(mercury__vn_flush__find_cheap_users_2_3_0_i18);
Declare_label(mercury__vn_flush__find_cheap_users_2_3_0_i22);
Declare_label(mercury__vn_flush__find_cheap_users_2_3_0_i25);
Declare_label(mercury__vn_flush__find_cheap_users_2_3_0_i1028);
Declare_label(mercury__vn_flush__find_cheap_users_2_3_0_i1029);
Declare_label(mercury__vn_flush__find_cheap_users_2_3_0_i1033);
Declare_label(mercury__vn_flush__find_cheap_users_2_3_0_i7);
Declare_label(mercury__vn_flush__find_cheap_users_2_3_0_i3);
Declare_label(mercury__vn_flush__find_cheap_users_2_3_0_i2);
Declare_static(mercury__vn_flush__ensure_assignment_9_0);
Declare_label(mercury__vn_flush__ensure_assignment_9_0_i3);
Declare_label(mercury__vn_flush__ensure_assignment_9_0_i5);
Declare_label(mercury__vn_flush__ensure_assignment_9_0_i1005);
Declare_label(mercury__vn_flush__ensure_assignment_9_0_i7);
Declare_label(mercury__vn_flush__ensure_assignment_9_0_i2);
Declare_label(mercury__vn_flush__ensure_assignment_9_0_i8);
Declare_static(mercury__vn_flush__generate_assignment_10_0);
Declare_label(mercury__vn_flush__generate_assignment_10_0_i4);
Declare_label(mercury__vn_flush__generate_assignment_10_0_i2);
Declare_label(mercury__vn_flush__generate_assignment_10_0_i5);
Declare_label(mercury__vn_flush__generate_assignment_10_0_i6);
Declare_label(mercury__vn_flush__generate_assignment_10_0_i7);
Declare_label(mercury__vn_flush__generate_assignment_10_0_i8);
Declare_label(mercury__vn_flush__generate_assignment_10_0_i11);
Declare_label(mercury__vn_flush__generate_assignment_10_0_i13);
Declare_label(mercury__vn_flush__generate_assignment_10_0_i14);
Declare_label(mercury__vn_flush__generate_assignment_10_0_i15);
Declare_label(mercury__vn_flush__generate_assignment_10_0_i9);
Declare_label(mercury__vn_flush__generate_assignment_10_0_i16);
Declare_label(mercury__vn_flush__generate_assignment_10_0_i18);
Declare_label(mercury__vn_flush__generate_assignment_10_0_i20);
Declare_label(mercury__vn_flush__generate_assignment_10_0_i17);
Declare_label(mercury__vn_flush__generate_assignment_10_0_i21);
Declare_label(mercury__vn_flush__generate_assignment_10_0_i23);
Declare_static(mercury__vn_flush__get_incr_hp_3_0);
Declare_label(mercury__vn_flush__get_incr_hp_3_0_i1004);
Declare_label(mercury__vn_flush__get_incr_hp_3_0_i5);
Declare_label(mercury__vn_flush__get_incr_hp_3_0_i7);
Declare_static(mercury__vn_flush__vn_10_0);
Declare_label(mercury__vn_flush__vn_10_0_i2);
Declare_label(mercury__vn_flush__vn_10_0_i4);
Declare_label(mercury__vn_flush__vn_10_0_i5);
Declare_label(mercury__vn_flush__vn_10_0_i6);
Declare_label(mercury__vn_flush__vn_10_0_i9);
Declare_label(mercury__vn_flush__vn_10_0_i10);
Declare_label(mercury__vn_flush__vn_10_0_i11);
Declare_label(mercury__vn_flush__vn_10_0_i14);
Declare_label(mercury__vn_flush__vn_10_0_i16);
Declare_label(mercury__vn_flush__vn_10_0_i23);
Declare_label(mercury__vn_flush__vn_10_0_i26);
Declare_label(mercury__vn_flush__vn_10_0_i27);
Declare_label(mercury__vn_flush__vn_10_0_i28);
Declare_label(mercury__vn_flush__vn_10_0_i31);
Declare_label(mercury__vn_flush__vn_10_0_i19);
Declare_label(mercury__vn_flush__vn_10_0_i20);
Declare_label(mercury__vn_flush__vn_10_0_i34);
Declare_label(mercury__vn_flush__vn_10_0_i12);
Declare_label(mercury__vn_flush__vn_10_0_i42);
Declare_label(mercury__vn_flush__vn_10_0_i43);
Declare_label(mercury__vn_flush__vn_10_0_i38);
Declare_label(mercury__vn_flush__vn_10_0_i8);
Declare_label(mercury__vn_flush__vn_10_0_i47);
Declare_label(mercury__vn_flush__vn_10_0_i48);
Declare_static(mercury__vn_flush__vn_value_10_0);
Declare_label(mercury__vn_flush__vn_value_10_0_i2);
Declare_label(mercury__vn_flush__vn_value_10_0_i5);
Declare_label(mercury__vn_flush__vn_value_10_0_i8);
Declare_label(mercury__vn_flush__vn_value_10_0_i6);
Declare_label(mercury__vn_flush__vn_value_10_0_i9);
Declare_label(mercury__vn_flush__vn_value_10_0_i10);
Declare_label(mercury__vn_flush__vn_value_10_0_i12);
Declare_label(mercury__vn_flush__vn_value_10_0_i11);
Declare_label(mercury__vn_flush__vn_value_10_0_i16);
Declare_label(mercury__vn_flush__vn_value_10_0_i15);
Declare_label(mercury__vn_flush__vn_value_10_0_i18);
Declare_label(mercury__vn_flush__vn_value_10_0_i19);
Declare_label(mercury__vn_flush__vn_value_10_0_i20);
Declare_label(mercury__vn_flush__vn_value_10_0_i22);
Declare_label(mercury__vn_flush__vn_value_10_0_i23);
Declare_label(mercury__vn_flush__vn_value_10_0_i25);
Declare_label(mercury__vn_flush__vn_value_10_0_i28);
Declare_label(mercury__vn_flush__vn_value_10_0_i29);
Declare_label(mercury__vn_flush__vn_value_10_0_i32);
Declare_label(mercury__vn_flush__vn_value_10_0_i1025);
Declare_label(mercury__vn_flush__vn_value_10_0_i24);
Declare_label(mercury__vn_flush__vn_value_10_0_i34);
Declare_label(mercury__vn_flush__vn_value_10_0_i36);
Declare_label(mercury__vn_flush__vn_value_10_0_i37);
Declare_label(mercury__vn_flush__vn_value_10_0_i38);
Declare_label(mercury__vn_flush__vn_value_10_0_i39);
Declare_label(mercury__vn_flush__vn_value_10_0_i40);
Declare_label(mercury__vn_flush__vn_value_10_0_i41);
Declare_label(mercury__vn_flush__vn_value_10_0_i42);
Declare_label(mercury__vn_flush__vn_value_10_0_i43);
Declare_label(mercury__vn_flush__vn_value_10_0_i44);
Declare_label(mercury__vn_flush__vn_value_10_0_i45);
Declare_label(mercury__vn_flush__vn_value_10_0_i46);
Declare_label(mercury__vn_flush__vn_value_10_0_i47);
Declare_label(mercury__vn_flush__vn_value_10_0_i48);
Declare_static(mercury__vn_flush__old_hp_9_0);
Declare_label(mercury__vn_flush__old_hp_9_0_i2);
Declare_label(mercury__vn_flush__old_hp_9_0_i3);
Declare_label(mercury__vn_flush__old_hp_9_0_i6);
Declare_label(mercury__vn_flush__old_hp_9_0_i5);
Declare_label(mercury__vn_flush__old_hp_9_0_i7);
Declare_label(mercury__vn_flush__old_hp_9_0_i8);
Declare_label(mercury__vn_flush__old_hp_9_0_i11);
Declare_label(mercury__vn_flush__old_hp_9_0_i18);
Declare_label(mercury__vn_flush__old_hp_9_0_i19);
Declare_label(mercury__vn_flush__old_hp_9_0_i20);
Declare_label(mercury__vn_flush__old_hp_9_0_i22);
Declare_label(mercury__vn_flush__old_hp_9_0_i23);
Declare_label(mercury__vn_flush__old_hp_9_0_i24);
Declare_label(mercury__vn_flush__old_hp_9_0_i25);
Declare_label(mercury__vn_flush__old_hp_9_0_i30);
Declare_label(mercury__vn_flush__old_hp_9_0_i35);
Declare_label(mercury__vn_flush__old_hp_9_0_i32);
Declare_label(mercury__vn_flush__old_hp_9_0_i37);
Declare_label(mercury__vn_flush__old_hp_9_0_i38);
Declare_label(mercury__vn_flush__old_hp_9_0_i41);
Declare_label(mercury__vn_flush__old_hp_9_0_i43);
Declare_label(mercury__vn_flush__old_hp_9_0_i36);
Declare_label(mercury__vn_flush__old_hp_9_0_i45);
Declare_label(mercury__vn_flush__old_hp_9_0_i46);
Declare_label(mercury__vn_flush__old_hp_9_0_i49);
Declare_label(mercury__vn_flush__old_hp_9_0_i48);
Declare_label(mercury__vn_flush__old_hp_9_0_i27);
Declare_label(mercury__vn_flush__old_hp_9_0_i52);
Declare_label(mercury__vn_flush__old_hp_9_0_i53);
Declare_label(mercury__vn_flush__old_hp_9_0_i56);
Declare_label(mercury__vn_flush__old_hp_9_0_i1028);
Declare_label(mercury__vn_flush__old_hp_9_0_i54);
Declare_label(mercury__vn_flush__old_hp_9_0_i57);
Declare_label(mercury__vn_flush__old_hp_9_0_i60);
Declare_label(mercury__vn_flush__old_hp_9_0_i62);
Declare_label(mercury__vn_flush__old_hp_9_0_i63);
Declare_label(mercury__vn_flush__old_hp_9_0_i64);
Declare_label(mercury__vn_flush__old_hp_9_0_i58);
Declare_label(mercury__vn_flush__old_hp_9_0_i66);
Declare_label(mercury__vn_flush__old_hp_9_0_i67);
Declare_static(mercury__vn_flush__hp_incr_10_0);
Declare_label(mercury__vn_flush__hp_incr_10_0_i3);
Declare_label(mercury__vn_flush__hp_incr_10_0_i4);
Declare_label(mercury__vn_flush__hp_incr_10_0_i5);
Declare_label(mercury__vn_flush__hp_incr_10_0_i6);
Declare_label(mercury__vn_flush__hp_incr_10_0_i7);
Declare_label(mercury__vn_flush__hp_incr_10_0_i10);
Declare_label(mercury__vn_flush__hp_incr_10_0_i12);
Declare_label(mercury__vn_flush__hp_incr_10_0_i2);
Declare_label(mercury__vn_flush__hp_incr_10_0_i13);
Declare_label(mercury__vn_flush__hp_incr_10_0_i16);
Declare_label(mercury__vn_flush__hp_incr_10_0_i17);
Declare_label(mercury__vn_flush__hp_incr_10_0_i21);
Declare_label(mercury__vn_flush__hp_incr_10_0_i23);
Declare_label(mercury__vn_flush__hp_incr_10_0_i24);
Declare_label(mercury__vn_flush__hp_incr_10_0_i28);
Declare_label(mercury__vn_flush__hp_incr_10_0_i29);
Declare_label(mercury__vn_flush__hp_incr_10_0_i31);
Declare_label(mercury__vn_flush__hp_incr_10_0_i33);
Declare_label(mercury__vn_flush__hp_incr_10_0_i34);
Declare_label(mercury__vn_flush__hp_incr_10_0_i35);
Declare_label(mercury__vn_flush__hp_incr_10_0_i36);
Declare_label(mercury__vn_flush__hp_incr_10_0_i40);
Declare_label(mercury__vn_flush__hp_incr_10_0_i42);
Declare_label(mercury__vn_flush__hp_incr_10_0_i38);
Declare_label(mercury__vn_flush__hp_incr_10_0_i48);
Declare_label(mercury__vn_flush__hp_incr_10_0_i47);
Declare_label(mercury__vn_flush__hp_incr_10_0_i52);
Declare_label(mercury__vn_flush__hp_incr_10_0_i54);
Declare_label(mercury__vn_flush__hp_incr_10_0_i56);
Declare_label(mercury__vn_flush__hp_incr_10_0_i57);
Declare_label(mercury__vn_flush__hp_incr_10_0_i14);
Declare_label(mercury__vn_flush__hp_incr_10_0_i58);
Declare_label(mercury__vn_flush__hp_incr_10_0_i60);
Declare_label(mercury__vn_flush__hp_incr_10_0_i62);
Declare_static(mercury__vn_flush__free_of_old_hp_2_0);
Declare_label(mercury__vn_flush__free_of_old_hp_2_0_i1002);
Declare_label(mercury__vn_flush__free_of_old_hp_2_0_i4);
Declare_label(mercury__vn_flush__free_of_old_hp_2_0_i5);
Declare_label(mercury__vn_flush__free_of_old_hp_2_0_i2);
Declare_label(mercury__vn_flush__free_of_old_hp_2_0_i1);
Declare_static(mercury__vn_flush__rec_find_ref_vns_list_3_0);
Declare_label(mercury__vn_flush__rec_find_ref_vns_list_3_0_i3);
Declare_label(mercury__vn_flush__rec_find_ref_vns_list_3_0_i4);
Declare_label(mercury__vn_flush__rec_find_ref_vns_list_3_0_i5);
Declare_label(mercury__vn_flush__rec_find_ref_vns_list_3_0_i6);
Declare_label(mercury__vn_flush__rec_find_ref_vns_list_3_0_i7);
Declare_static(mercury__vn_flush__access_path_10_0);
Declare_label(mercury__vn_flush__access_path_10_0_i4);
Declare_label(mercury__vn_flush__access_path_10_0_i5);
Declare_label(mercury__vn_flush__access_path_10_0_i6);
Declare_label(mercury__vn_flush__access_path_10_0_i7);
Declare_label(mercury__vn_flush__access_path_10_0_i8);
Declare_label(mercury__vn_flush__access_path_10_0_i9);
Declare_label(mercury__vn_flush__access_path_10_0_i1026);
Declare_label(mercury__vn_flush__access_path_10_0_i11);
Declare_label(mercury__vn_flush__access_path_10_0_i12);
Declare_label(mercury__vn_flush__access_path_10_0_i13);
Declare_label(mercury__vn_flush__access_path_10_0_i14);
Declare_label(mercury__vn_flush__access_path_10_0_i15);
Declare_label(mercury__vn_flush__access_path_10_0_i16);
Declare_label(mercury__vn_flush__access_path_10_0_i17);
Declare_label(mercury__vn_flush__access_path_10_0_i18);
Declare_label(mercury__vn_flush__access_path_10_0_i19);
Declare_label(mercury__vn_flush__access_path_10_0_i20);
Declare_label(mercury__vn_flush__access_path_10_0_i21);
Declare_label(mercury__vn_flush__access_path_10_0_i22);
Declare_label(mercury__vn_flush__access_path_10_0_i23);
Declare_label(mercury__vn_flush__access_path_10_0_i24);
Declare_label(mercury__vn_flush__access_path_10_0_i25);
Declare_label(mercury__vn_flush__access_path_10_0_i26);
Declare_label(mercury__vn_flush__access_path_10_0_i27);
Declare_label(mercury__vn_flush__access_path_10_0_i28);
Declare_label(mercury__vn_flush__access_path_10_0_i29);
Declare_label(mercury__vn_flush__access_path_10_0_i30);
Declare_static(mercury__vn_flush__maybe_save_prev_value_10_0);
Declare_label(mercury__vn_flush__maybe_save_prev_value_10_0_i3);
Declare_label(mercury__vn_flush__maybe_save_prev_value_10_0_i4);
Declare_label(mercury__vn_flush__maybe_save_prev_value_10_0_i6);
Declare_label(mercury__vn_flush__maybe_save_prev_value_10_0_i10);
Declare_label(mercury__vn_flush__maybe_save_prev_value_10_0_i11);
Declare_label(mercury__vn_flush__maybe_save_prev_value_10_0_i12);
Declare_label(mercury__vn_flush__maybe_save_prev_value_10_0_i13);
Declare_label(mercury__vn_flush__maybe_save_prev_value_10_0_i18);
Declare_label(mercury__vn_flush__maybe_save_prev_value_10_0_i17);
Declare_label(mercury__vn_flush__maybe_save_prev_value_10_0_i21);
Declare_label(mercury__vn_flush__maybe_save_prev_value_10_0_i22);
Declare_label(mercury__vn_flush__maybe_save_prev_value_10_0_i24);
Declare_label(mercury__vn_flush__maybe_save_prev_value_10_0_i27);
Declare_label(mercury__vn_flush__maybe_save_prev_value_10_0_i28);
Declare_label(mercury__vn_flush__maybe_save_prev_value_10_0_i26);
Declare_label(mercury__vn_flush__maybe_save_prev_value_10_0_i35);
Declare_label(mercury__vn_flush__maybe_save_prev_value_10_0_i37);
Declare_label(mercury__vn_flush__maybe_save_prev_value_10_0_i38);
Declare_label(mercury__vn_flush__maybe_save_prev_value_10_0_i34);
Declare_label(mercury__vn_flush__maybe_save_prev_value_10_0_i50);
Declare_label(mercury__vn_flush__maybe_save_prev_value_10_0_i51);
Declare_label(mercury__vn_flush__maybe_save_prev_value_10_0_i45);
Declare_label(mercury__vn_flush__maybe_save_prev_value_10_0_i15);
Declare_label(mercury__vn_flush__maybe_save_prev_value_10_0_i59);
Declare_label(mercury__vn_flush__maybe_save_prev_value_10_0_i60);
Declare_label(mercury__vn_flush__maybe_save_prev_value_10_0_i61);
Declare_label(mercury__vn_flush__maybe_save_prev_value_10_0_i64);
Declare_label(mercury__vn_flush__maybe_save_prev_value_10_0_i67);
Declare_label(mercury__vn_flush__maybe_save_prev_value_10_0_i68);
Declare_label(mercury__vn_flush__maybe_save_prev_value_10_0_i2);
Declare_static(mercury__vn_flush__no_good_copies_1_0);
Declare_label(mercury__vn_flush__no_good_copies_1_0_i1002);
Declare_label(mercury__vn_flush__no_good_copies_1_0_i2);
Declare_label(mercury__vn_flush__no_good_copies_1_0_i1);

static const struct mercury_data_vn_flush__common_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_vn_flush__common_0;

static const struct mercury_data_vn_flush__common_1_struct {
	Word * f1;
	String f2;
}  mercury_data_vn_flush__common_1;

static const struct mercury_data_vn_flush__common_2_struct {
	Word * f1;
	Word * f2;
}  mercury_data_vn_flush__common_2;

static const struct mercury_data_vn_flush__common_3_struct {
	Word * f1;
}  mercury_data_vn_flush__common_3;

static const struct mercury_data_vn_flush__common_4_struct {
	Integer f1;
	Word * f2;
}  mercury_data_vn_flush__common_4;

static const struct mercury_data_vn_flush__common_5_struct {
	Word * f1;
}  mercury_data_vn_flush__common_5;

static const struct mercury_data_vn_flush__common_6_struct {
	Integer f1;
}  mercury_data_vn_flush__common_6;

static const struct mercury_data_vn_flush__common_7_struct {
	Integer f1;
	Word * f2;
}  mercury_data_vn_flush__common_7;

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_pair_2;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_llds__type_ctor_info_instr_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_string_0;
static const struct mercury_data_vn_flush__common_0_struct mercury_data_vn_flush__common_0 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_llds__type_ctor_info_instr_0,
	(Word *) &mercury_data___type_ctor_info_string_0
};

static const struct mercury_data_vn_flush__common_1_struct mercury_data_vn_flush__common_1 = {
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	MR_string_const("", 0)
};

static const struct mercury_data_vn_flush__common_2_struct mercury_data_vn_flush__common_2 = {
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_flush__common_1),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_vn_flush__common_3_struct mercury_data_vn_flush__common_3 = {
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_vn_flush__common_4_struct mercury_data_vn_flush__common_4 = {
	(Integer) 3,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_flush__common_3)
};

static const struct mercury_data_vn_flush__common_5_struct mercury_data_vn_flush__common_5 = {
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 3))
};

static const struct mercury_data_vn_flush__common_6_struct mercury_data_vn_flush__common_6 = {
	(Integer) 42
};

static const struct mercury_data_vn_flush__common_7_struct mercury_data_vn_flush__common_7 = {
	(Integer) 1,
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_vn_flush__common_6)
};

Declare_entry(mercury__list__append_3_1);

BEGIN_MODULE(vn_flush_module0)
	init_entry(mercury__vn_flush__nodelist_8_0);
	init_label(mercury__vn_flush__nodelist_8_0_i4);
	init_label(mercury__vn_flush__nodelist_8_0_i6);
	init_label(mercury__vn_flush__nodelist_8_0_i8);
	init_label(mercury__vn_flush__nodelist_8_0_i9);
	init_label(mercury__vn_flush__nodelist_8_0_i3);
BEGIN_CODE

/* code for predicate 'nodelist'/8 in mode 0 */
Define_entry(mercury__vn_flush__nodelist_8_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_flush__nodelist_8_0_i3);
	MR_incr_sp_push_msg(3, "vn_flush:nodelist/8");
	MR_stackvar(3) = (Word) MR_succip;
	r7 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r8 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	if ((MR_tag(r8) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_flush__nodelist_8_0_i4);
	r1 = r7;
	MR_stackvar(1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	localcall(mercury__vn_flush__nodelist_8_0,
		LABEL(mercury__vn_flush__nodelist_8_0_i8),
		ENTRY(mercury__vn_flush__nodelist_8_0));
Define_label(mercury__vn_flush__nodelist_8_0_i4);
	MR_stackvar(2) = r5;
	{
	Word MR_tempr1;
	MR_tempr1 = r3;
	r3 = r7;
	r7 = r6;
	r6 = r5;
	r5 = r4;
	r4 = MR_tempr1;
	r1 = r8;
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__vn_flush__node_12_0),
		mercury__vn_flush__nodelist_8_0_i6,
		ENTRY(mercury__vn_flush__nodelist_8_0));
	}
Define_label(mercury__vn_flush__nodelist_8_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_flush__nodelist_8_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r2;
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r4;
	r4 = r3;
	r3 = MR_tempr1;
	r6 = r5;
	r5 = MR_stackvar(2);
	localcall(mercury__vn_flush__nodelist_8_0,
		LABEL(mercury__vn_flush__nodelist_8_0_i8),
		ENTRY(mercury__vn_flush__nodelist_8_0));
	}
Define_label(mercury__vn_flush__nodelist_8_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_flush__nodelist_8_0));
	{
	Word MR_tempr1;
	MR_tempr1 = r2;
	r2 = MR_stackvar(1);
	MR_stackvar(1) = MR_tempr1;
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_flush__common_0);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__vn_flush__nodelist_8_0_i9,
		ENTRY(mercury__vn_flush__nodelist_8_0));
	}
Define_label(mercury__vn_flush__nodelist_8_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_flush__nodelist_8_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_flush__nodelist_8_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r2 = r6;
	proceed();
END_MODULE

Declare_entry(mercury__vn_debug__flush_start_msg_3_0);
Declare_entry(mercury__vn_table__lookup_uses_4_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_vn_type__type_ctor_info_vn_src_0;
Declare_entry(mercury____Unify___list__list_1_0);
Declare_entry(mercury__vn_table__search_desired_value_3_0);
Declare_entry(mercury__vn_debug__flush_also_msg_3_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_vn_type__type_ctor_info_vn_node_0;
Declare_entry(mercury__list__delete_all_3_1);
Declare_entry(mercury__vn_table__search_current_value_3_0);
Declare_entry(mercury__vn_table__del_old_use_4_0);
Declare_entry(mercury__vn_util__vnlval_access_vns_2_0);
Declare_entry(mercury__vn_table__del_old_uses_4_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_int_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_vn_type__type_ctor_info_vn_instr_0;
Declare_entry(mercury__map__lookup_3_0);
Declare_entry(mercury__vn_debug__flush_end_msg_4_0);

BEGIN_MODULE(vn_flush_module1)
	init_entry(mercury__vn_flush__node_12_0);
	init_label(mercury__vn_flush__node_12_0_i2);
	init_label(mercury__vn_flush__node_12_0_i5);
	init_label(mercury__vn_flush__node_12_0_i7);
	init_label(mercury__vn_flush__node_12_0_i8);
	init_label(mercury__vn_flush__node_12_0_i6);
	init_label(mercury__vn_flush__node_12_0_i10);
	init_label(mercury__vn_flush__node_12_0_i12);
	init_label(mercury__vn_flush__node_12_0_i14);
	init_label(mercury__vn_flush__node_12_0_i15);
	init_label(mercury__vn_flush__node_12_0_i11);
	init_label(mercury__vn_flush__node_12_0_i16);
	init_label(mercury__vn_flush__node_12_0_i18);
	init_label(mercury__vn_flush__node_12_0_i20);
	init_label(mercury__vn_flush__node_12_0_i1013);
	init_label(mercury__vn_flush__node_12_0_i22);
	init_label(mercury__vn_flush__node_12_0_i17);
	init_label(mercury__vn_flush__node_12_0_i23);
	init_label(mercury__vn_flush__node_12_0_i26);
	init_label(mercury__vn_flush__node_12_0_i27);
	init_label(mercury__vn_flush__node_12_0_i28);
	init_label(mercury__vn_flush__node_12_0_i29);
	init_label(mercury__vn_flush__node_12_0_i30);
	init_label(mercury__vn_flush__node_12_0_i31);
	init_label(mercury__vn_flush__node_12_0_i3);
	init_label(mercury__vn_flush__node_12_0_i32);
BEGIN_CODE

/* code for predicate 'node'/12 in mode 0 */
Define_static(mercury__vn_flush__node_12_0);
	MR_incr_sp_push_msg(15, "vn_flush:node/12");
	MR_stackvar(15) = (Word) MR_succip;
	MR_stackvar(2) = r2;
	r2 = r7;
	MR_stackvar(1) = r1;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r5;
	MR_stackvar(7) = r6;
	call_localret(ENTRY(mercury__vn_debug__flush_start_msg_3_0),
		mercury__vn_flush__node_12_0_i2,
		STATIC(mercury__vn_flush__node_12_0));
Define_label(mercury__vn_flush__node_12_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_flush__node_12_0));
	r2 = MR_stackvar(1);
	COMPUTED_GOTO((Unsigned) MR_tag(r2),
		LABEL(mercury__vn_flush__node_12_0_i5) AND
		LABEL(mercury__vn_flush__node_12_0_i26) AND
		LABEL(mercury__vn_flush__node_12_0_i28) AND
		LABEL(mercury__vn_flush__node_12_0_i29));
Define_label(mercury__vn_flush__node_12_0_i5);
	MR_stackvar(10) = r1;
	r1 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(9) = r1;
	r2 = (Word) MR_string_const("vn_flush__shared_node", 21);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__vn_table__lookup_uses_4_0),
		mercury__vn_flush__node_12_0_i7,
		STATIC(mercury__vn_flush__node_12_0));
Define_label(mercury__vn_flush__node_12_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_flush__node_12_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vn_src_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury__vn_flush__node_12_0_i8,
		STATIC(mercury__vn_flush__node_12_0));
Define_label(mercury__vn_flush__node_12_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_flush__node_12_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_flush__node_12_0_i6);
	MR_stackvar(1) = MR_stackvar(3);
	r2 = MR_stackvar(4);
	MR_stackvar(6) = MR_stackvar(5);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r3 = MR_stackvar(10);
	GOTO_LABEL(mercury__vn_flush__node_12_0_i3);
Define_label(mercury__vn_flush__node_12_0_i6);
	r1 = MR_stackvar(9);
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(5);
	call_localret(STATIC(mercury__vn_flush__choose_loc_for_shared_vn_5_0),
		mercury__vn_flush__node_12_0_i10,
		STATIC(mercury__vn_flush__node_12_0));
Define_label(mercury__vn_flush__node_12_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_flush__node_12_0));
	MR_stackvar(13) = r2;
	r2 = MR_stackvar(4);
	MR_stackvar(12) = r1;
	call_localret(ENTRY(mercury__vn_table__search_desired_value_3_0),
		mercury__vn_flush__node_12_0_i12,
		STATIC(mercury__vn_flush__node_12_0));
Define_label(mercury__vn_flush__node_12_0_i12);
	update_prof_current_proc(LABEL(mercury__vn_flush__node_12_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_flush__node_12_0_i11);
	if ((MR_stackvar(9) != r2))
		GOTO_LABEL(mercury__vn_flush__node_12_0_i11);
	r1 = MR_stackvar(12);
	r2 = MR_stackvar(10);
	call_localret(ENTRY(mercury__vn_debug__flush_also_msg_3_0),
		mercury__vn_flush__node_12_0_i14,
		STATIC(mercury__vn_flush__node_12_0));
Define_label(mercury__vn_flush__node_12_0_i14);
	update_prof_current_proc(LABEL(mercury__vn_flush__node_12_0));
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__vn_flush__node_12_0, "origin_lost_in_value_number");
	MR_stackvar(11) = r1;
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vn_node_0;
	r2 = MR_stackvar(3);
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(12);
	call_localret(ENTRY(mercury__list__delete_all_3_1),
		mercury__vn_flush__node_12_0_i15,
		STATIC(mercury__vn_flush__node_12_0));
Define_label(mercury__vn_flush__node_12_0_i15);
	update_prof_current_proc(LABEL(mercury__vn_flush__node_12_0));
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(12);
	r2 = MR_stackvar(4);
	MR_stackvar(14) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	GOTO_LABEL(mercury__vn_flush__node_12_0_i16);
Define_label(mercury__vn_flush__node_12_0_i11);
	MR_stackvar(1) = MR_stackvar(3);
	r2 = MR_stackvar(4);
	MR_stackvar(11) = MR_stackvar(10);
	r1 = MR_stackvar(12);
	MR_stackvar(14) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
Define_label(mercury__vn_flush__node_12_0_i16);
	MR_stackvar(4) = r2;
	MR_stackvar(12) = r1;
	call_localret(ENTRY(mercury__vn_table__search_current_value_3_0),
		mercury__vn_flush__node_12_0_i18,
		STATIC(mercury__vn_flush__node_12_0));
Define_label(mercury__vn_flush__node_12_0_i18);
	update_prof_current_proc(LABEL(mercury__vn_flush__node_12_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_flush__node_12_0_i17);
	if ((MR_stackvar(9) != r2))
		GOTO_LABEL(mercury__vn_flush__node_12_0_i17);
	r1 = MR_stackvar(9);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__vn_flush__node_12_0, "vn_type:vn_src/0");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(12);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__vn_table__del_old_use_4_0),
		mercury__vn_flush__node_12_0_i20,
		STATIC(mercury__vn_flush__node_12_0));
Define_label(mercury__vn_flush__node_12_0_i20);
	update_prof_current_proc(LABEL(mercury__vn_flush__node_12_0));
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(12);
	call_localret(ENTRY(mercury__vn_util__vnlval_access_vns_2_0),
		mercury__vn_flush__node_12_0_i1013,
		STATIC(mercury__vn_flush__node_12_0));
Define_label(mercury__vn_flush__node_12_0_i1013);
	update_prof_current_proc(LABEL(mercury__vn_flush__node_12_0));
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 1, mercury__vn_flush__node_12_0, "vn_type:vn_src/0");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_stackvar(12);
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__vn_table__del_old_uses_4_0),
		mercury__vn_flush__node_12_0_i22,
		STATIC(mercury__vn_flush__node_12_0));
Define_label(mercury__vn_flush__node_12_0_i22);
	update_prof_current_proc(LABEL(mercury__vn_flush__node_12_0));
	r2 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r3 = MR_stackvar(11);
	MR_stackvar(6) = MR_stackvar(13);
	GOTO_LABEL(mercury__vn_flush__node_12_0_i3);
Define_label(mercury__vn_flush__node_12_0_i17);
	r1 = MR_stackvar(12);
	r2 = MR_stackvar(9);
	r3 = MR_stackvar(14);
	r4 = MR_stackvar(4);
	r5 = MR_stackvar(13);
	r6 = MR_stackvar(7);
	call_localret(STATIC(mercury__vn_flush__generate_assignment_10_0),
		mercury__vn_flush__node_12_0_i23,
		STATIC(mercury__vn_flush__node_12_0));
Define_label(mercury__vn_flush__node_12_0_i23);
	update_prof_current_proc(LABEL(mercury__vn_flush__node_12_0));
	MR_stackvar(6) = r2;
	r2 = r1;
	r1 = r4;
	r3 = MR_stackvar(11);
	GOTO_LABEL(mercury__vn_flush__node_12_0_i3);
Define_label(mercury__vn_flush__node_12_0_i26);
	r7 = r1;
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	r5 = MR_stackvar(5);
	r6 = MR_stackvar(7);
	call_localret(STATIC(mercury__vn_flush__lval_node_12_0),
		mercury__vn_flush__node_12_0_i27,
		STATIC(mercury__vn_flush__node_12_0));
Define_label(mercury__vn_flush__node_12_0_i27);
	update_prof_current_proc(LABEL(mercury__vn_flush__node_12_0));
	MR_stackvar(1) = r1;
	MR_stackvar(6) = r3;
	r1 = r4;
	r3 = r5;
	GOTO_LABEL(mercury__vn_flush__node_12_0_i3);
Define_label(mercury__vn_flush__node_12_0_i28);
	MR_stackvar(1) = MR_stackvar(3);
	r2 = MR_stackvar(4);
	MR_stackvar(6) = MR_stackvar(5);
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	GOTO_LABEL(mercury__vn_flush__node_12_0_i3);
Define_label(mercury__vn_flush__node_12_0_i29);
	r3 = MR_stackvar(2);
	r4 = MR_const_field(MR_mktag(3), r2, (Integer) 0);
	MR_stackvar(2) = r4;
	MR_stackvar(10) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vn_instr_0;
	MR_stackvar(1) = MR_stackvar(3);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__vn_flush__node_12_0_i30,
		STATIC(mercury__vn_flush__node_12_0));
Define_label(mercury__vn_flush__node_12_0_i30);
	update_prof_current_proc(LABEL(mercury__vn_flush__node_12_0));
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(5);
	r5 = MR_stackvar(7);
	call_localret(STATIC(mercury__vn_flush__ctrl_node_8_0),
		mercury__vn_flush__node_12_0_i31,
		STATIC(mercury__vn_flush__node_12_0));
Define_label(mercury__vn_flush__node_12_0_i31);
	update_prof_current_proc(LABEL(mercury__vn_flush__node_12_0));
	MR_stackvar(6) = r2;
	r2 = r1;
	r1 = r3;
	r3 = MR_stackvar(10);
Define_label(mercury__vn_flush__node_12_0_i3);
	MR_stackvar(2) = r2;
	MR_stackvar(8) = r1;
	call_localret(ENTRY(mercury__vn_debug__flush_end_msg_4_0),
		mercury__vn_flush__node_12_0_i32,
		STATIC(mercury__vn_flush__node_12_0));
Define_label(mercury__vn_flush__node_12_0_i32);
	update_prof_current_proc(LABEL(mercury__vn_flush__node_12_0));
	r5 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(6);
	r4 = MR_stackvar(8);
	MR_succip = (Code *) MR_stackvar(15);
	MR_decr_sp_pop_msg(15);
	proceed();
END_MODULE

Declare_entry(mercury__vn_table__lookup_desired_value_4_0);
Declare_entry(mercury__vn_table__lookup_current_value_4_0);
Declare_entry(mercury__vn_util__real_uses_3_0);

BEGIN_MODULE(vn_flush_module2)
	init_entry(mercury__vn_flush__lval_node_12_0);
	init_label(mercury__vn_flush__lval_node_12_0_i2);
	init_label(mercury__vn_flush__lval_node_12_0_i3);
	init_label(mercury__vn_flush__lval_node_12_0_i6);
	init_label(mercury__vn_flush__lval_node_12_0_i8);
	init_label(mercury__vn_flush__lval_node_12_0_i9);
	init_label(mercury__vn_flush__lval_node_12_0_i15);
	init_label(mercury__vn_flush__lval_node_12_0_i16);
	init_label(mercury__vn_flush__lval_node_12_0_i17);
	init_label(mercury__vn_flush__lval_node_12_0_i18);
	init_label(mercury__vn_flush__lval_node_12_0_i1021);
	init_label(mercury__vn_flush__lval_node_12_0_i19);
	init_label(mercury__vn_flush__lval_node_12_0_i20);
	init_label(mercury__vn_flush__lval_node_12_0_i22);
	init_label(mercury__vn_flush__lval_node_12_0_i24);
	init_label(mercury__vn_flush__lval_node_12_0_i1025);
	init_label(mercury__vn_flush__lval_node_12_0_i26);
	init_label(mercury__vn_flush__lval_node_12_0_i21);
	init_label(mercury__vn_flush__lval_node_12_0_i27);
	init_label(mercury__vn_flush__lval_node_12_0_i29);
	init_label(mercury__vn_flush__lval_node_12_0_i5);
	init_label(mercury__vn_flush__lval_node_12_0_i31);
	init_label(mercury__vn_flush__lval_node_12_0_i33);
	init_label(mercury__vn_flush__lval_node_12_0_i1029);
	init_label(mercury__vn_flush__lval_node_12_0_i35);
	init_label(mercury__vn_flush__lval_node_12_0_i30);
	init_label(mercury__vn_flush__lval_node_12_0_i36);
BEGIN_CODE

/* code for predicate 'lval_node'/12 in mode 0 */
Define_static(mercury__vn_flush__lval_node_12_0);
	MR_incr_sp_push_msg(16, "vn_flush:lval_node/12");
	MR_stackvar(16) = (Word) MR_succip;
	MR_stackvar(3) = r3;
	MR_stackvar(2) = r2;
	r2 = (Word) MR_string_const("vn_flush__lval_node", 19);
	r3 = r4;
	MR_stackvar(1) = r1;
	MR_stackvar(4) = r4;
	MR_stackvar(6) = r5;
	MR_stackvar(8) = r6;
	MR_stackvar(9) = r7;
	call_localret(ENTRY(mercury__vn_table__lookup_desired_value_4_0),
		mercury__vn_flush__lval_node_12_0_i2,
		STATIC(mercury__vn_flush__lval_node_12_0));
Define_label(mercury__vn_flush__lval_node_12_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_flush__lval_node_12_0));
	MR_stackvar(11) = r1;
	r1 = MR_stackvar(1);
	r2 = (Word) MR_string_const("vn_flush__lval_node", 19);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__vn_table__lookup_current_value_4_0),
		mercury__vn_flush__lval_node_12_0_i3,
		STATIC(mercury__vn_flush__lval_node_12_0));
Define_label(mercury__vn_flush__lval_node_12_0_i3);
	update_prof_current_proc(LABEL(mercury__vn_flush__lval_node_12_0));
	if ((r1 != MR_stackvar(11)))
		GOTO_LABEL(mercury__vn_flush__lval_node_12_0_i5);
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__vn_util__vnlval_access_vns_2_0),
		mercury__vn_flush__lval_node_12_0_i6,
		STATIC(mercury__vn_flush__lval_node_12_0));
Define_label(mercury__vn_flush__lval_node_12_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_flush__lval_node_12_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_flush__lval_node_12_0_i5);
	r1 = MR_stackvar(11);
	r2 = (Word) MR_string_const("vn_flush__lval_node", 19);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__vn_table__lookup_uses_4_0),
		mercury__vn_flush__lval_node_12_0_i8,
		STATIC(mercury__vn_flush__lval_node_12_0));
Define_label(mercury__vn_flush__lval_node_12_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_flush__lval_node_12_0));
	r2 = MR_stackvar(4);
	call_localret(ENTRY(mercury__vn_util__real_uses_3_0),
		mercury__vn_flush__lval_node_12_0_i9,
		STATIC(mercury__vn_flush__lval_node_12_0));
Define_label(mercury__vn_flush__lval_node_12_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_flush__lval_node_12_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_flush__lval_node_12_0_i5);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_flush__lval_node_12_0_i5);
	r3 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	if ((MR_tag(r3) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_flush__lval_node_12_0_i1021);
	if (((Integer) MR_const_field(MR_mktag(1), r2, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_flush__lval_node_12_0_i1021);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__vn_flush__lval_node_12_0, "origin_lost_in_value_number");
	MR_stackvar(5) = r1;
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	r2 = MR_stackvar(9);
	call_localret(ENTRY(mercury__vn_debug__flush_start_msg_3_0),
		mercury__vn_flush__lval_node_12_0_i15,
		STATIC(mercury__vn_flush__lval_node_12_0));
Define_label(mercury__vn_flush__lval_node_12_0_i15);
	update_prof_current_proc(LABEL(mercury__vn_flush__lval_node_12_0));
	r7 = r1;
	r1 = MR_const_field(MR_mktag(1), MR_stackvar(5), (Integer) 0);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	r5 = MR_stackvar(6);
	r6 = MR_stackvar(8);
	localcall(mercury__vn_flush__lval_node_12_0,
		LABEL(mercury__vn_flush__lval_node_12_0_i16),
		STATIC(mercury__vn_flush__lval_node_12_0));
Define_label(mercury__vn_flush__lval_node_12_0_i16);
	update_prof_current_proc(LABEL(mercury__vn_flush__lval_node_12_0));
	MR_stackvar(2) = r1;
	MR_stackvar(13) = r3;
	r1 = r4;
	r3 = r5;
	MR_stackvar(12) = r2;
	MR_stackvar(14) = r4;
	call_localret(ENTRY(mercury__vn_debug__flush_end_msg_4_0),
		mercury__vn_flush__lval_node_12_0_i17,
		STATIC(mercury__vn_flush__lval_node_12_0));
Define_label(mercury__vn_flush__lval_node_12_0_i17);
	update_prof_current_proc(LABEL(mercury__vn_flush__lval_node_12_0));
	MR_stackvar(10) = r1;
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vn_node_0;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(5);
	call_localret(ENTRY(mercury__list__delete_all_3_1),
		mercury__vn_flush__lval_node_12_0_i18,
		STATIC(mercury__vn_flush__lval_node_12_0));
Define_label(mercury__vn_flush__lval_node_12_0_i18);
	update_prof_current_proc(LABEL(mercury__vn_flush__lval_node_12_0));
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(12);
	MR_stackvar(15) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	GOTO_LABEL(mercury__vn_flush__lval_node_12_0_i20);
Define_label(mercury__vn_flush__lval_node_12_0_i1021);
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 1, mercury__vn_flush__lval_node_12_0, "vn_type:vn_node/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(11);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	r5 = MR_stackvar(6);
	r6 = MR_stackvar(8);
	r7 = MR_stackvar(9);
	call_localret(STATIC(mercury__vn_flush__node_12_0),
		mercury__vn_flush__lval_node_12_0_i19,
		STATIC(mercury__vn_flush__lval_node_12_0));
Define_label(mercury__vn_flush__lval_node_12_0_i19);
	update_prof_current_proc(LABEL(mercury__vn_flush__lval_node_12_0));
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(10) = r5;
	MR_stackvar(13) = r3;
	MR_stackvar(14) = r4;
	MR_stackvar(15) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
Define_label(mercury__vn_flush__lval_node_12_0_i20);
	MR_stackvar(1) = r1;
	MR_stackvar(12) = r2;
	call_localret(ENTRY(mercury__vn_table__search_current_value_3_0),
		mercury__vn_flush__lval_node_12_0_i22,
		STATIC(mercury__vn_flush__lval_node_12_0));
Define_label(mercury__vn_flush__lval_node_12_0_i22);
	update_prof_current_proc(LABEL(mercury__vn_flush__lval_node_12_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_flush__lval_node_12_0_i21);
	if ((MR_stackvar(11) != r2))
		GOTO_LABEL(mercury__vn_flush__lval_node_12_0_i21);
	r1 = MR_stackvar(11);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__vn_flush__lval_node_12_0, "vn_type:vn_src/0");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(1);
	r3 = MR_stackvar(12);
	call_localret(ENTRY(mercury__vn_table__del_old_use_4_0),
		mercury__vn_flush__lval_node_12_0_i24,
		STATIC(mercury__vn_flush__lval_node_12_0));
Define_label(mercury__vn_flush__lval_node_12_0_i24);
	update_prof_current_proc(LABEL(mercury__vn_flush__lval_node_12_0));
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__vn_util__vnlval_access_vns_2_0),
		mercury__vn_flush__lval_node_12_0_i1025,
		STATIC(mercury__vn_flush__lval_node_12_0));
Define_label(mercury__vn_flush__lval_node_12_0_i1025);
	update_prof_current_proc(LABEL(mercury__vn_flush__lval_node_12_0));
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 1, mercury__vn_flush__lval_node_12_0, "vn_type:vn_src/0");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_stackvar(1);
	r3 = MR_stackvar(5);
	call_localret(ENTRY(mercury__vn_table__del_old_uses_4_0),
		mercury__vn_flush__lval_node_12_0_i26,
		STATIC(mercury__vn_flush__lval_node_12_0));
Define_label(mercury__vn_flush__lval_node_12_0_i26);
	update_prof_current_proc(LABEL(mercury__vn_flush__lval_node_12_0));
	MR_stackvar(5) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_flush__common_0);
	r2 = MR_stackvar(14);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_stackvar(7) = MR_stackvar(13);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__vn_flush__lval_node_12_0_i29,
		STATIC(mercury__vn_flush__lval_node_12_0));
Define_label(mercury__vn_flush__lval_node_12_0_i21);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(11);
	r3 = MR_stackvar(15);
	r4 = MR_stackvar(12);
	r5 = MR_stackvar(13);
	r6 = MR_stackvar(8);
	call_localret(STATIC(mercury__vn_flush__generate_assignment_10_0),
		mercury__vn_flush__lval_node_12_0_i27,
		STATIC(mercury__vn_flush__lval_node_12_0));
Define_label(mercury__vn_flush__lval_node_12_0_i27);
	update_prof_current_proc(LABEL(mercury__vn_flush__lval_node_12_0));
	MR_stackvar(5) = r1;
	MR_stackvar(7) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_flush__common_0);
	r2 = MR_stackvar(14);
	r3 = r4;
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__vn_flush__lval_node_12_0_i29,
		STATIC(mercury__vn_flush__lval_node_12_0));
Define_label(mercury__vn_flush__lval_node_12_0_i29);
	update_prof_current_proc(LABEL(mercury__vn_flush__lval_node_12_0));
	r4 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(7);
	r5 = MR_stackvar(10);
	MR_succip = (Code *) MR_stackvar(16);
	MR_decr_sp_pop_msg(16);
	proceed();
Define_label(mercury__vn_flush__lval_node_12_0_i5);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(4);
	call_localret(ENTRY(mercury__vn_table__search_current_value_3_0),
		mercury__vn_flush__lval_node_12_0_i31,
		STATIC(mercury__vn_flush__lval_node_12_0));
Define_label(mercury__vn_flush__lval_node_12_0_i31);
	update_prof_current_proc(LABEL(mercury__vn_flush__lval_node_12_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_flush__lval_node_12_0_i30);
	if ((MR_stackvar(11) != r2))
		GOTO_LABEL(mercury__vn_flush__lval_node_12_0_i30);
	r1 = MR_stackvar(11);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__vn_flush__lval_node_12_0, "vn_type:vn_src/0");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(1);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__vn_table__del_old_use_4_0),
		mercury__vn_flush__lval_node_12_0_i33,
		STATIC(mercury__vn_flush__lval_node_12_0));
Define_label(mercury__vn_flush__lval_node_12_0_i33);
	update_prof_current_proc(LABEL(mercury__vn_flush__lval_node_12_0));
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__vn_util__vnlval_access_vns_2_0),
		mercury__vn_flush__lval_node_12_0_i1029,
		STATIC(mercury__vn_flush__lval_node_12_0));
Define_label(mercury__vn_flush__lval_node_12_0_i1029);
	update_prof_current_proc(LABEL(mercury__vn_flush__lval_node_12_0));
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 1, mercury__vn_flush__lval_node_12_0, "vn_type:vn_src/0");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_stackvar(1);
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__vn_table__del_old_uses_4_0),
		mercury__vn_flush__lval_node_12_0_i35,
		STATIC(mercury__vn_flush__lval_node_12_0));
Define_label(mercury__vn_flush__lval_node_12_0_i35);
	update_prof_current_proc(LABEL(mercury__vn_flush__lval_node_12_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	r3 = MR_stackvar(6);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r5 = MR_stackvar(9);
	MR_succip = (Code *) MR_stackvar(16);
	MR_decr_sp_pop_msg(16);
	proceed();
Define_label(mercury__vn_flush__lval_node_12_0_i30);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(11);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r4 = MR_stackvar(4);
	r5 = MR_stackvar(6);
	r6 = MR_stackvar(8);
	call_localret(STATIC(mercury__vn_flush__generate_assignment_10_0),
		mercury__vn_flush__lval_node_12_0_i36,
		STATIC(mercury__vn_flush__lval_node_12_0));
Define_label(mercury__vn_flush__lval_node_12_0_i36);
	update_prof_current_proc(LABEL(mercury__vn_flush__lval_node_12_0));
	r3 = r2;
	r2 = r1;
	r1 = MR_stackvar(3);
	r5 = MR_stackvar(9);
	MR_succip = (Code *) MR_stackvar(16);
	MR_decr_sp_pop_msg(16);
	proceed();
END_MODULE

Declare_entry(mercury__vn_util__rval_to_vn_4_0);
Declare_entry(mercury__vn_util__lval_to_vnlval_4_0);
Declare_entry(mercury__vn_table__set_current_value_4_0);
Declare_entry(mercury__vn_table__lookup_assigned_vn_4_0);

BEGIN_MODULE(vn_flush_module3)
	init_entry(mercury__vn_flush__ctrl_node_8_0);
	init_label(mercury__vn_flush__ctrl_node_8_0_i1065);
	init_label(mercury__vn_flush__ctrl_node_8_0_i5);
	init_label(mercury__vn_flush__ctrl_node_8_0_i6);
	init_label(mercury__vn_flush__ctrl_node_8_0_i7);
	init_label(mercury__vn_flush__ctrl_node_8_0_i8);
	init_label(mercury__vn_flush__ctrl_node_8_0_i9);
	init_label(mercury__vn_flush__ctrl_node_8_0_i10);
	init_label(mercury__vn_flush__ctrl_node_8_0_i11);
	init_label(mercury__vn_flush__ctrl_node_8_0_i12);
	init_label(mercury__vn_flush__ctrl_node_8_0_i13);
	init_label(mercury__vn_flush__ctrl_node_8_0_i14);
	init_label(mercury__vn_flush__ctrl_node_8_0_i15);
	init_label(mercury__vn_flush__ctrl_node_8_0_i17);
	init_label(mercury__vn_flush__ctrl_node_8_0_i18);
	init_label(mercury__vn_flush__ctrl_node_8_0_i20);
	init_label(mercury__vn_flush__ctrl_node_8_0_i21);
	init_label(mercury__vn_flush__ctrl_node_8_0_i22);
	init_label(mercury__vn_flush__ctrl_node_8_0_i23);
	init_label(mercury__vn_flush__ctrl_node_8_0_i25);
	init_label(mercury__vn_flush__ctrl_node_8_0_i26);
	init_label(mercury__vn_flush__ctrl_node_8_0_i27);
	init_label(mercury__vn_flush__ctrl_node_8_0_i29);
	init_label(mercury__vn_flush__ctrl_node_8_0_i30);
	init_label(mercury__vn_flush__ctrl_node_8_0_i31);
	init_label(mercury__vn_flush__ctrl_node_8_0_i32);
	init_label(mercury__vn_flush__ctrl_node_8_0_i34);
	init_label(mercury__vn_flush__ctrl_node_8_0_i35);
	init_label(mercury__vn_flush__ctrl_node_8_0_i37);
	init_label(mercury__vn_flush__ctrl_node_8_0_i38);
	init_label(mercury__vn_flush__ctrl_node_8_0_i39);
	init_label(mercury__vn_flush__ctrl_node_8_0_i40);
	init_label(mercury__vn_flush__ctrl_node_8_0_i42);
	init_label(mercury__vn_flush__ctrl_node_8_0_i43);
	init_label(mercury__vn_flush__ctrl_node_8_0_i44);
	init_label(mercury__vn_flush__ctrl_node_8_0_i45);
	init_label(mercury__vn_flush__ctrl_node_8_0_i46);
BEGIN_CODE

/* code for predicate 'ctrl_node'/8 in mode 0 */
Define_static(mercury__vn_flush__ctrl_node_8_0);
	MR_incr_sp_push_msg(6, "vn_flush:ctrl_node/8");
	MR_stackvar(6) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__vn_flush__ctrl_node_8_0_i1065) AND
		LABEL(mercury__vn_flush__ctrl_node_8_0_i5) AND
		LABEL(mercury__vn_flush__ctrl_node_8_0_i6) AND
		LABEL(mercury__vn_flush__ctrl_node_8_0_i7));
Define_label(mercury__vn_flush__ctrl_node_8_0_i1065);
	r1 = r3;
	r2 = r4;
	r3 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_vn_flush__common_2);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__vn_flush__ctrl_node_8_0_i5);
	r2 = r4;
	r5 = r1;
	r1 = r3;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__vn_flush__ctrl_node_8_0, "origin_lost_in_value_number");
	tag_incr_hp_msg(r7, MR_mktag(0), (Integer) 2, mercury__vn_flush__ctrl_node_8_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__vn_flush__ctrl_node_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r7, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(1), r5, (Integer) 0);
	MR_field(MR_mktag(1), r3, (Integer) 0) = r7;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r7, (Integer) 1) = (Word) MR_string_const("", 0);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
	}
Define_label(mercury__vn_flush__ctrl_node_8_0_i6);
	r5 = r1;
	r1 = r3;
	r2 = r4;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__vn_flush__ctrl_node_8_0, "list:list/1");
	tag_incr_hp_msg(r7, MR_mktag(0), (Integer) 2, mercury__vn_flush__ctrl_node_8_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 6, mercury__vn_flush__ctrl_node_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r7, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 5) = MR_const_field(MR_mktag(2), r5, (Integer) 4);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 4) = MR_const_field(MR_mktag(2), r5, (Integer) 3);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_const_field(MR_mktag(2), r5, (Integer) 1);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_const_field(MR_mktag(2), r5, (Integer) 0);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 3) = MR_const_field(MR_mktag(2), r5, (Integer) 2);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r3, (Integer) 0) = r7;
	MR_field(MR_mktag(0), r7, (Integer) 1) = (Word) MR_string_const("", 0);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
	}
Define_label(mercury__vn_flush__ctrl_node_8_0_i7);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__vn_flush__ctrl_node_8_0_i8) AND
		LABEL(mercury__vn_flush__ctrl_node_8_0_i12) AND
		LABEL(mercury__vn_flush__ctrl_node_8_0_i13) AND
		LABEL(mercury__vn_flush__ctrl_node_8_0_i14) AND
		LABEL(mercury__vn_flush__ctrl_node_8_0_i17) AND
		LABEL(mercury__vn_flush__ctrl_node_8_0_i20) AND
		LABEL(mercury__vn_flush__ctrl_node_8_0_i25) AND
		LABEL(mercury__vn_flush__ctrl_node_8_0_i29) AND
		LABEL(mercury__vn_flush__ctrl_node_8_0_i34) AND
		LABEL(mercury__vn_flush__ctrl_node_8_0_i37) AND
		LABEL(mercury__vn_flush__ctrl_node_8_0_i42) AND
		LABEL(mercury__vn_flush__ctrl_node_8_0_i45) AND
		LABEL(mercury__vn_flush__ctrl_node_8_0_i46));
Define_label(mercury__vn_flush__ctrl_node_8_0_i8);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(1) = r4;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__vn_flush__ctrl_node_8_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 1;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__vn_flush__ctrl_node_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_tempr1;
	r2 = r3;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(3);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 2;
	call_localret(ENTRY(mercury__vn_util__rval_to_vn_4_0),
		mercury__vn_flush__ctrl_node_8_0_i9,
		STATIC(mercury__vn_flush__ctrl_node_8_0));
	}
Define_label(mercury__vn_flush__ctrl_node_8_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_flush__ctrl_node_8_0));
	MR_stackvar(4) = r1;
	r1 = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_vn_flush__common_4);
	call_localret(ENTRY(mercury__vn_util__lval_to_vnlval_4_0),
		mercury__vn_flush__ctrl_node_8_0_i10,
		STATIC(mercury__vn_flush__ctrl_node_8_0));
Define_label(mercury__vn_flush__ctrl_node_8_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_flush__ctrl_node_8_0));
	r3 = r2;
	r2 = MR_stackvar(4);
	call_localret(ENTRY(mercury__vn_table__set_current_value_4_0),
		mercury__vn_flush__ctrl_node_8_0_i11,
		STATIC(mercury__vn_flush__ctrl_node_8_0));
Define_label(mercury__vn_flush__ctrl_node_8_0_i11);
	update_prof_current_proc(LABEL(mercury__vn_flush__ctrl_node_8_0));
	r2 = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__vn_flush__ctrl_node_8_0, "list:list/1");
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 2, mercury__vn_flush__ctrl_node_8_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 3, mercury__vn_flush__ctrl_node_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r4, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_stackvar(3);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r3, (Integer) 0) = r4;
	MR_field(MR_mktag(0), r4, (Integer) 1) = (Word) MR_string_const("", 0);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
	}
Define_label(mercury__vn_flush__ctrl_node_8_0_i12);
	r5 = r1;
	r1 = r3;
	r2 = r4;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__vn_flush__ctrl_node_8_0, "list:list/1");
	tag_incr_hp_msg(r7, MR_mktag(0), (Integer) 2, mercury__vn_flush__ctrl_node_8_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__vn_flush__ctrl_node_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r7, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_const_field(MR_mktag(3), r5, (Integer) 1);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r3, (Integer) 0) = r7;
	MR_field(MR_mktag(0), r7, (Integer) 1) = (Word) MR_string_const("", 0);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
	}
Define_label(mercury__vn_flush__ctrl_node_8_0_i13);
	r5 = r1;
	r1 = r3;
	r2 = r4;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__vn_flush__ctrl_node_8_0, "list:list/1");
	tag_incr_hp_msg(r7, MR_mktag(0), (Integer) 2, mercury__vn_flush__ctrl_node_8_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__vn_flush__ctrl_node_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r7, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_const_field(MR_mktag(3), r5, (Integer) 1);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 5;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r3, (Integer) 0) = r7;
	MR_field(MR_mktag(0), r7, (Integer) 1) = (Word) MR_string_const("", 0);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
	}
Define_label(mercury__vn_flush__ctrl_node_8_0_i14);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r7 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__vn_flush__ctrl_node_8_0, "list:list/1");
	r6 = r5;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 1, mercury__vn_flush__ctrl_node_8_0, "origin_lost_in_value_number");
	r5 = r4;
	r4 = r3;
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_tempr1;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r7;
	call_localret(STATIC(mercury__vn_flush__vn_10_0),
		mercury__vn_flush__ctrl_node_8_0_i15,
		STATIC(mercury__vn_flush__ctrl_node_8_0));
	}
Define_label(mercury__vn_flush__ctrl_node_8_0_i15);
	update_prof_current_proc(LABEL(mercury__vn_flush__ctrl_node_8_0));
	r5 = MR_stackvar(1);
	r6 = r1;
	MR_stackvar(1) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_flush__common_0);
	r2 = r4;
	MR_stackvar(2) = r3;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__vn_flush__ctrl_node_8_0, "list:list/1");
	tag_incr_hp_msg(r8, MR_mktag(0), (Integer) 2, mercury__vn_flush__ctrl_node_8_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 3, mercury__vn_flush__ctrl_node_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r8, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = r5;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r6;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 6;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r3, (Integer) 0) = r8;
	MR_field(MR_mktag(0), r8, (Integer) 1) = (Word) MR_string_const("", 0);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__vn_flush__ctrl_node_8_0_i44,
		STATIC(mercury__vn_flush__ctrl_node_8_0));
	}
Define_label(mercury__vn_flush__ctrl_node_8_0_i17);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r7 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__vn_flush__ctrl_node_8_0, "list:list/1");
	r6 = r5;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 1, mercury__vn_flush__ctrl_node_8_0, "origin_lost_in_value_number");
	r5 = r4;
	r4 = r3;
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_tempr1;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r7;
	call_localret(STATIC(mercury__vn_flush__vn_10_0),
		mercury__vn_flush__ctrl_node_8_0_i18,
		STATIC(mercury__vn_flush__ctrl_node_8_0));
	}
Define_label(mercury__vn_flush__ctrl_node_8_0_i18);
	update_prof_current_proc(LABEL(mercury__vn_flush__ctrl_node_8_0));
	r5 = MR_stackvar(1);
	r6 = r1;
	MR_stackvar(1) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_flush__common_0);
	r2 = r4;
	MR_stackvar(2) = r3;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__vn_flush__ctrl_node_8_0, "list:list/1");
	tag_incr_hp_msg(r8, MR_mktag(0), (Integer) 2, mercury__vn_flush__ctrl_node_8_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 3, mercury__vn_flush__ctrl_node_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r8, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = r5;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r6;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 8;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r3, (Integer) 0) = r8;
	MR_field(MR_mktag(0), r8, (Integer) 1) = (Word) MR_string_const("", 0);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__vn_flush__ctrl_node_8_0_i44,
		STATIC(mercury__vn_flush__ctrl_node_8_0));
	}
Define_label(mercury__vn_flush__ctrl_node_8_0_i20);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(1) = r1;
	r7 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__vn_flush__ctrl_node_8_0, "list:list/1");
	r6 = r5;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 1, mercury__vn_flush__ctrl_node_8_0, "origin_lost_in_value_number");
	r5 = r4;
	r4 = r3;
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_tempr1;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r7;
	call_localret(STATIC(mercury__vn_flush__access_path_10_0),
		mercury__vn_flush__ctrl_node_8_0_i21,
		STATIC(mercury__vn_flush__ctrl_node_8_0));
	}
Define_label(mercury__vn_flush__ctrl_node_8_0_i21);
	update_prof_current_proc(LABEL(mercury__vn_flush__ctrl_node_8_0));
	MR_stackvar(2) = r3;
	r3 = r2;
	MR_stackvar(3) = r1;
	MR_stackvar(4) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_flush__common_5);
	r2 = (Word) MR_string_const("vn_flush__ctrl_node", 19);
	MR_stackvar(5) = r4;
	call_localret(ENTRY(mercury__vn_table__lookup_assigned_vn_4_0),
		mercury__vn_flush__ctrl_node_8_0_i22,
		STATIC(mercury__vn_flush__ctrl_node_8_0));
Define_label(mercury__vn_flush__ctrl_node_8_0_i22);
	update_prof_current_proc(LABEL(mercury__vn_flush__ctrl_node_8_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__vn_table__set_current_value_4_0),
		mercury__vn_flush__ctrl_node_8_0_i23,
		STATIC(mercury__vn_flush__ctrl_node_8_0));
Define_label(mercury__vn_flush__ctrl_node_8_0_i23);
	update_prof_current_proc(LABEL(mercury__vn_flush__ctrl_node_8_0));
	MR_stackvar(1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_flush__common_0);
	r2 = MR_stackvar(5);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__vn_flush__ctrl_node_8_0, "list:list/1");
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__vn_flush__ctrl_node_8_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__vn_flush__ctrl_node_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r5, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(3);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 10;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r3, (Integer) 0) = r5;
	MR_field(MR_mktag(0), r5, (Integer) 1) = (Word) MR_string_const("", 0);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__vn_flush__ctrl_node_8_0_i44,
		STATIC(mercury__vn_flush__ctrl_node_8_0));
	}
Define_label(mercury__vn_flush__ctrl_node_8_0_i25);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(1) = r1;
	r7 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__vn_flush__ctrl_node_8_0, "list:list/1");
	r6 = r5;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 1, mercury__vn_flush__ctrl_node_8_0, "origin_lost_in_value_number");
	r5 = r4;
	r4 = r3;
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_tempr1;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r7;
	call_localret(STATIC(mercury__vn_flush__vn_10_0),
		mercury__vn_flush__ctrl_node_8_0_i26,
		STATIC(mercury__vn_flush__ctrl_node_8_0));
	}
Define_label(mercury__vn_flush__ctrl_node_8_0_i26);
	update_prof_current_proc(LABEL(mercury__vn_flush__ctrl_node_8_0));
	MR_stackvar(2) = r3;
	r3 = r2;
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 3));
	MR_stackvar(3) = r4;
	call_localret(ENTRY(mercury__vn_table__set_current_value_4_0),
		mercury__vn_flush__ctrl_node_8_0_i27,
		STATIC(mercury__vn_flush__ctrl_node_8_0));
Define_label(mercury__vn_flush__ctrl_node_8_0_i27);
	update_prof_current_proc(LABEL(mercury__vn_flush__ctrl_node_8_0));
	r4 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_flush__common_0);
	r2 = MR_stackvar(3);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__vn_flush__ctrl_node_8_0, "list:list/1");
	tag_incr_hp_msg(r6, MR_mktag(0), (Integer) 2, mercury__vn_flush__ctrl_node_8_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__vn_flush__ctrl_node_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r6, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r4;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 11;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r3, (Integer) 0) = r6;
	MR_field(MR_mktag(0), r6, (Integer) 1) = (Word) MR_string_const("", 0);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__vn_flush__ctrl_node_8_0_i44,
		STATIC(mercury__vn_flush__ctrl_node_8_0));
	}
Define_label(mercury__vn_flush__ctrl_node_8_0_i29);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(4) = r1;
	r7 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__vn_flush__ctrl_node_8_0, "list:list/1");
	r6 = r5;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 1, mercury__vn_flush__ctrl_node_8_0, "origin_lost_in_value_number");
	r5 = r4;
	r4 = r3;
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_tempr1;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r7;
	call_localret(STATIC(mercury__vn_flush__access_path_10_0),
		mercury__vn_flush__ctrl_node_8_0_i30,
		STATIC(mercury__vn_flush__ctrl_node_8_0));
	}
Define_label(mercury__vn_flush__ctrl_node_8_0_i30);
	update_prof_current_proc(LABEL(mercury__vn_flush__ctrl_node_8_0));
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(5) = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 1, mercury__vn_flush__ctrl_node_8_0, "origin_lost_in_value_number");
	r3 = r2;
	r2 = (Word) MR_string_const("vn_flush__ctrl_node", 19);
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(4);
	call_localret(ENTRY(mercury__vn_table__lookup_assigned_vn_4_0),
		mercury__vn_flush__ctrl_node_8_0_i31,
		STATIC(mercury__vn_flush__ctrl_node_8_0));
Define_label(mercury__vn_flush__ctrl_node_8_0_i31);
	update_prof_current_proc(LABEL(mercury__vn_flush__ctrl_node_8_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	r3 = MR_stackvar(1);
	call_localret(ENTRY(mercury__vn_table__set_current_value_4_0),
		mercury__vn_flush__ctrl_node_8_0_i32,
		STATIC(mercury__vn_flush__ctrl_node_8_0));
Define_label(mercury__vn_flush__ctrl_node_8_0_i32);
	update_prof_current_proc(LABEL(mercury__vn_flush__ctrl_node_8_0));
	MR_stackvar(1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_flush__common_0);
	r2 = MR_stackvar(3);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__vn_flush__ctrl_node_8_0, "list:list/1");
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__vn_flush__ctrl_node_8_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__vn_flush__ctrl_node_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r5, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(5);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 12;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r3, (Integer) 0) = r5;
	MR_field(MR_mktag(0), r5, (Integer) 1) = (Word) MR_string_const("", 0);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__vn_flush__ctrl_node_8_0_i44,
		STATIC(mercury__vn_flush__ctrl_node_8_0));
	}
Define_label(mercury__vn_flush__ctrl_node_8_0_i34);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r7 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__vn_flush__ctrl_node_8_0, "list:list/1");
	r6 = r5;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 1, mercury__vn_flush__ctrl_node_8_0, "origin_lost_in_value_number");
	r5 = r4;
	r4 = r3;
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_tempr1;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r7;
	call_localret(STATIC(mercury__vn_flush__vn_10_0),
		mercury__vn_flush__ctrl_node_8_0_i35,
		STATIC(mercury__vn_flush__ctrl_node_8_0));
	}
Define_label(mercury__vn_flush__ctrl_node_8_0_i35);
	update_prof_current_proc(LABEL(mercury__vn_flush__ctrl_node_8_0));
	r5 = MR_stackvar(1);
	r6 = r1;
	MR_stackvar(1) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_flush__common_0);
	r2 = r4;
	MR_stackvar(2) = r3;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__vn_flush__ctrl_node_8_0, "list:list/1");
	tag_incr_hp_msg(r8, MR_mktag(0), (Integer) 2, mercury__vn_flush__ctrl_node_8_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 3, mercury__vn_flush__ctrl_node_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r8, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = r5;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r6;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 13;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r3, (Integer) 0) = r8;
	MR_field(MR_mktag(0), r8, (Integer) 1) = (Word) MR_string_const("", 0);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__vn_flush__ctrl_node_8_0_i44,
		STATIC(mercury__vn_flush__ctrl_node_8_0));
	}
Define_label(mercury__vn_flush__ctrl_node_8_0_i37);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(4) = r1;
	r7 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__vn_flush__ctrl_node_8_0, "list:list/1");
	r6 = r5;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 1, mercury__vn_flush__ctrl_node_8_0, "origin_lost_in_value_number");
	r5 = r4;
	r4 = r3;
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_tempr1;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r7;
	call_localret(STATIC(mercury__vn_flush__access_path_10_0),
		mercury__vn_flush__ctrl_node_8_0_i38,
		STATIC(mercury__vn_flush__ctrl_node_8_0));
	}
Define_label(mercury__vn_flush__ctrl_node_8_0_i38);
	update_prof_current_proc(LABEL(mercury__vn_flush__ctrl_node_8_0));
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	MR_stackvar(5) = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 1, mercury__vn_flush__ctrl_node_8_0, "origin_lost_in_value_number");
	r3 = r2;
	r2 = (Word) MR_string_const("vn_flush__ctrl_node", 19);
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(4);
	call_localret(ENTRY(mercury__vn_table__lookup_assigned_vn_4_0),
		mercury__vn_flush__ctrl_node_8_0_i39,
		STATIC(mercury__vn_flush__ctrl_node_8_0));
Define_label(mercury__vn_flush__ctrl_node_8_0_i39);
	update_prof_current_proc(LABEL(mercury__vn_flush__ctrl_node_8_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	r3 = MR_stackvar(1);
	call_localret(ENTRY(mercury__vn_table__set_current_value_4_0),
		mercury__vn_flush__ctrl_node_8_0_i40,
		STATIC(mercury__vn_flush__ctrl_node_8_0));
Define_label(mercury__vn_flush__ctrl_node_8_0_i40);
	update_prof_current_proc(LABEL(mercury__vn_flush__ctrl_node_8_0));
	MR_stackvar(1) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_flush__common_0);
	r2 = MR_stackvar(3);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__vn_flush__ctrl_node_8_0, "list:list/1");
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__vn_flush__ctrl_node_8_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__vn_flush__ctrl_node_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r5, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(5);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 14;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r3, (Integer) 0) = r5;
	MR_field(MR_mktag(0), r5, (Integer) 1) = (Word) MR_string_const("", 0);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__vn_flush__ctrl_node_8_0_i44,
		STATIC(mercury__vn_flush__ctrl_node_8_0));
	}
Define_label(mercury__vn_flush__ctrl_node_8_0_i42);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r6 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__vn_flush__ctrl_node_8_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 1, mercury__vn_flush__ctrl_node_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r6;
	r6 = r5;
	r5 = r4;
	r4 = r3;
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_tempr1;
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(STATIC(mercury__vn_flush__vn_10_0),
		mercury__vn_flush__ctrl_node_8_0_i43,
		STATIC(mercury__vn_flush__ctrl_node_8_0));
	}
Define_label(mercury__vn_flush__ctrl_node_8_0_i43);
	update_prof_current_proc(LABEL(mercury__vn_flush__ctrl_node_8_0));
	r5 = r1;
	MR_stackvar(1) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_flush__common_0);
	r2 = r4;
	MR_stackvar(2) = r3;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__vn_flush__ctrl_node_8_0, "list:list/1");
	tag_incr_hp_msg(r7, MR_mktag(0), (Integer) 2, mercury__vn_flush__ctrl_node_8_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__vn_flush__ctrl_node_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r7, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r5;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 15;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r3, (Integer) 0) = r7;
	MR_field(MR_mktag(0), r7, (Integer) 1) = (Word) MR_string_const("", 0);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__vn_flush__ctrl_node_8_0_i44,
		STATIC(mercury__vn_flush__ctrl_node_8_0));
	}
Define_label(mercury__vn_flush__ctrl_node_8_0_i44);
	update_prof_current_proc(LABEL(mercury__vn_flush__ctrl_node_8_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__vn_flush__ctrl_node_8_0_i45);
	r5 = r1;
	r1 = r3;
	r2 = r4;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__vn_flush__ctrl_node_8_0, "list:list/1");
	tag_incr_hp_msg(r7, MR_mktag(0), (Integer) 2, mercury__vn_flush__ctrl_node_8_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 3, mercury__vn_flush__ctrl_node_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r7, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_const_field(MR_mktag(3), r5, (Integer) 2);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_const_field(MR_mktag(3), r5, (Integer) 1);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 16;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r3, (Integer) 0) = r7;
	MR_field(MR_mktag(0), r7, (Integer) 1) = (Word) MR_string_const("", 0);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
	}
Define_label(mercury__vn_flush__ctrl_node_8_0_i46);
	r5 = r1;
	r1 = r3;
	r2 = r4;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__vn_flush__ctrl_node_8_0, "list:list/1");
	tag_incr_hp_msg(r7, MR_mktag(0), (Integer) 2, mercury__vn_flush__ctrl_node_8_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__vn_flush__ctrl_node_8_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r7, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_const_field(MR_mktag(3), r5, (Integer) 1);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 17;
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r3, (Integer) 0) = r7;
	MR_field(MR_mktag(0), r7, (Integer) 1) = (Word) MR_string_const("", 0);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
	}
END_MODULE

Declare_entry(mercury__vn_table__lookup_current_locs_4_0);
Declare_entry(mercury__vn_util__choose_cheapest_loc_2_0);
Declare_entry(mercury__vn_util__classify_loc_cost_2_0);
Declare_entry(mercury__list__delete_first_3_0);
Declare_entry(mercury__vn_table__search_uses_3_0);
Declare_entry(mercury__vn_table__lookup_defn_4_0);
Declare_entry(mercury__vn_type__vnrval_type_2_0);
Declare_entry(mercury__vn_temploc__next_tempf_3_0);
Declare_entry(mercury__vn_temploc__next_tempr_3_0);

BEGIN_MODULE(vn_flush_module4)
	init_entry(mercury__vn_flush__choose_loc_for_shared_vn_5_0);
	init_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i3);
	init_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i4);
	init_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i6);
	init_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i7);
	init_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i11);
	init_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i10);
	init_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i12);
	init_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i13);
	init_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i16);
	init_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i2);
	init_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i21);
	init_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i20);
	init_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i24);
	init_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i25);
	init_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i27);
	init_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i28);
	init_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i32);
	init_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i31);
	init_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i33);
	init_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i34);
	init_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i36);
	init_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i18);
	init_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i38);
	init_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i39);
	init_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i40);
	init_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i43);
BEGIN_CODE

/* code for predicate 'choose_loc_for_shared_vn'/5 in mode 0 */
Define_static(mercury__vn_flush__choose_loc_for_shared_vn_5_0);
	MR_incr_sp_push_msg(5, "vn_flush:choose_loc_for_shared_vn/5");
	MR_stackvar(5) = (Word) MR_succip;
	MR_stackvar(3) = r3;
	r3 = r2;
	MR_stackvar(2) = r2;
	r2 = (Word) MR_string_const("vn_flush__choose_loc_for_shared_vn", 34);
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__vn_table__lookup_current_locs_4_0),
		mercury__vn_flush__choose_loc_for_shared_vn_5_0_i3,
		STATIC(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
Define_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i3);
	update_prof_current_proc(LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
	call_localret(ENTRY(mercury__vn_util__choose_cheapest_loc_2_0),
		mercury__vn_flush__choose_loc_for_shared_vn_5_0_i4,
		STATIC(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
Define_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i2);
	MR_stackvar(4) = r2;
	r1 = r2;
	call_localret(ENTRY(mercury__vn_util__vnlval_access_vns_2_0),
		mercury__vn_flush__choose_loc_for_shared_vn_5_0_i6,
		STATIC(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
Define_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury__vn_flush__choose_loc_for_shared_vn_5_0_i7,
		STATIC(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
Define_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i2);
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__vn_util__classify_loc_cost_2_0),
		mercury__vn_flush__choose_loc_for_shared_vn_5_0_i11,
		STATIC(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
Define_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i11);
	update_prof_current_proc(LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
	if (((Integer) 0 != (Integer) r1))
		GOTO_LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i10);
	r2 = MR_stackvar(3);
	r1 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i10);
	r1 = MR_stackvar(1);
	r2 = (Word) MR_string_const("vn_flush__choose_loc_for_shared_vn", 34);
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__vn_table__lookup_uses_4_0),
		mercury__vn_flush__choose_loc_for_shared_vn_5_0_i12,
		STATIC(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
Define_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i12);
	update_prof_current_proc(LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vn_src_0;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__vn_flush__choose_loc_for_shared_vn_5_0, "vn_type:vn_src/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(4);
	call_localret(ENTRY(mercury__list__delete_first_3_0),
		mercury__vn_flush__choose_loc_for_shared_vn_5_0_i13,
		STATIC(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
Define_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i13);
	update_prof_current_proc(LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i2);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i16);
	r2 = MR_stackvar(3);
	r1 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i16);
	if (((Integer) MR_const_field(MR_mktag(1), r2, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i2);
	r2 = MR_stackvar(3);
	r1 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i2);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__vn_table__search_uses_3_0),
		mercury__vn_flush__choose_loc_for_shared_vn_5_0_i21,
		STATIC(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
Define_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i21);
	update_prof_current_proc(LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i20);
	r1 = r2;
	r2 = MR_stackvar(2);
	call_localret(STATIC(mercury__vn_flush__find_cheap_users_2_3_0),
		mercury__vn_flush__choose_loc_for_shared_vn_5_0_i24,
		STATIC(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
Define_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i20);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
Define_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i24);
	update_prof_current_proc(LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
	call_localret(ENTRY(mercury__vn_util__choose_cheapest_loc_2_0),
		mercury__vn_flush__choose_loc_for_shared_vn_5_0_i25,
		STATIC(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
Define_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i25);
	update_prof_current_proc(LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i18);
	MR_stackvar(4) = r2;
	r1 = r2;
	call_localret(ENTRY(mercury__vn_util__vnlval_access_vns_2_0),
		mercury__vn_flush__choose_loc_for_shared_vn_5_0_i27,
		STATIC(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
Define_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i27);
	update_prof_current_proc(LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury__vn_flush__choose_loc_for_shared_vn_5_0_i28,
		STATIC(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
Define_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i28);
	update_prof_current_proc(LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i18);
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__vn_util__classify_loc_cost_2_0),
		mercury__vn_flush__choose_loc_for_shared_vn_5_0_i32,
		STATIC(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
Define_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i32);
	update_prof_current_proc(LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
	if (((Integer) 0 != (Integer) r1))
		GOTO_LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i31);
	r2 = MR_stackvar(3);
	r1 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i31);
	r1 = MR_stackvar(1);
	r2 = (Word) MR_string_const("vn_flush__choose_loc_for_shared_vn", 34);
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__vn_table__lookup_uses_4_0),
		mercury__vn_flush__choose_loc_for_shared_vn_5_0_i33,
		STATIC(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
Define_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i33);
	update_prof_current_proc(LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vn_src_0;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__vn_flush__choose_loc_for_shared_vn_5_0, "vn_type:vn_src/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(4);
	call_localret(ENTRY(mercury__list__delete_first_3_0),
		mercury__vn_flush__choose_loc_for_shared_vn_5_0_i34,
		STATIC(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
Define_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i34);
	update_prof_current_proc(LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i18);
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vn_src_0;
	r3 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury__vn_flush__choose_loc_for_shared_vn_5_0_i36,
		STATIC(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
Define_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i36);
	update_prof_current_proc(LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i18);
	r2 = MR_stackvar(3);
	r1 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i18);
	r1 = MR_stackvar(1);
	r2 = (Word) MR_string_const("vn_flush__choose_temp", 21);
	r3 = MR_stackvar(2);
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_flush__choose_loc_for_shared_vn_5_0_i38,
		STATIC(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
Define_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i38);
	update_prof_current_proc(LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
	call_localret(ENTRY(mercury__vn_type__vnrval_type_2_0),
		mercury__vn_flush__choose_loc_for_shared_vn_5_0_i39,
		STATIC(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
Define_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i39);
	update_prof_current_proc(LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
	if (((Integer) r1 != (Integer) 9))
		GOTO_LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i40);
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__vn_temploc__next_tempf_3_0),
		mercury__vn_flush__choose_loc_for_shared_vn_5_0_i43,
		STATIC(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
Define_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i40);
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__vn_temploc__next_tempr_3_0),
		mercury__vn_flush__choose_loc_for_shared_vn_5_0_i43,
		STATIC(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
Define_label(mercury__vn_flush__choose_loc_for_shared_vn_5_0_i43);
	update_prof_current_proc(LABEL(mercury__vn_flush__choose_loc_for_shared_vn_5_0));
	r3 = r1;
	r1 = r2;
	r2 = r3;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE


BEGIN_MODULE(vn_flush_module5)
	init_entry(mercury__vn_flush__find_cheap_users_3_0);
	init_label(mercury__vn_flush__find_cheap_users_3_0_i4);
	init_label(mercury__vn_flush__find_cheap_users_3_0_i3);
BEGIN_CODE

/* code for predicate 'find_cheap_users'/3 in mode 0 */
Define_static(mercury__vn_flush__find_cheap_users_3_0);
	MR_incr_sp_push_msg(2, "vn_flush:find_cheap_users/3");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__vn_table__search_uses_3_0),
		mercury__vn_flush__find_cheap_users_3_0_i4,
		STATIC(mercury__vn_flush__find_cheap_users_3_0));
Define_label(mercury__vn_flush__find_cheap_users_3_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_flush__find_cheap_users_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_flush__find_cheap_users_3_0_i3);
	r1 = r2;
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__vn_flush__find_cheap_users_2_3_0),
		STATIC(mercury__vn_flush__find_cheap_users_3_0));
Define_label(mercury__vn_flush__find_cheap_users_3_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE

Declare_entry(mercury__list__member_2_1);
Declare_entry(do_redo);

BEGIN_MODULE(vn_flush_module6)
	init_entry(mercury__vn_flush__find_cheap_users_2_3_0);
	init_label(mercury__vn_flush__find_cheap_users_2_3_0_i4);
	init_label(mercury__vn_flush__find_cheap_users_2_3_0_i9);
	init_label(mercury__vn_flush__find_cheap_users_2_3_0_i11);
	init_label(mercury__vn_flush__find_cheap_users_2_3_0_i1003);
	init_label(mercury__vn_flush__find_cheap_users_2_3_0_i12);
	init_label(mercury__vn_flush__find_cheap_users_2_3_0_i18);
	init_label(mercury__vn_flush__find_cheap_users_2_3_0_i22);
	init_label(mercury__vn_flush__find_cheap_users_2_3_0_i25);
	init_label(mercury__vn_flush__find_cheap_users_2_3_0_i1028);
	init_label(mercury__vn_flush__find_cheap_users_2_3_0_i1029);
	init_label(mercury__vn_flush__find_cheap_users_2_3_0_i1033);
	init_label(mercury__vn_flush__find_cheap_users_2_3_0_i7);
	init_label(mercury__vn_flush__find_cheap_users_2_3_0_i3);
	init_label(mercury__vn_flush__find_cheap_users_2_3_0_i2);
BEGIN_CODE

/* code for predicate 'find_cheap_users_2'/3 in mode 0 */
Define_static(mercury__vn_flush__find_cheap_users_2_3_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_flush__find_cheap_users_2_3_0_i3);
	MR_incr_sp_push_msg(8, "vn_flush:find_cheap_users_2/3");
	MR_stackvar(8) = (Word) MR_succip;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(1) = r2;
	localcall(mercury__vn_flush__find_cheap_users_2_3_0,
		LABEL(mercury__vn_flush__find_cheap_users_2_3_0_i4),
		STATIC(mercury__vn_flush__find_cheap_users_2_3_0));
Define_label(mercury__vn_flush__find_cheap_users_2_3_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_flush__find_cheap_users_2_3_0));
	if ((MR_tag(MR_stackvar(2)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_flush__find_cheap_users_2_3_0_i2);
	r3 = MR_const_field(MR_mktag(1), MR_stackvar(2), (Integer) 0);
	MR_stackvar(3) = r3;
	MR_stackvar(2) = r1;
	r1 = r3;
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__vn_table__search_current_value_3_0),
		mercury__vn_flush__find_cheap_users_2_3_0_i9,
		STATIC(mercury__vn_flush__find_cheap_users_2_3_0));
Define_label(mercury__vn_flush__find_cheap_users_2_3_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_flush__find_cheap_users_2_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_flush__find_cheap_users_2_3_0_i7);
	r1 = r2;
	r2 = (Word) MR_string_const("vn_flush__find_cheap_users_2", 28);
	r3 = MR_stackvar(1);
	call_localret(ENTRY(mercury__vn_table__lookup_uses_4_0),
		mercury__vn_flush__find_cheap_users_2_3_0_i11,
		STATIC(mercury__vn_flush__find_cheap_users_2_3_0));
Define_label(mercury__vn_flush__find_cheap_users_2_3_0_i11);
	update_prof_current_proc(LABEL(mercury__vn_flush__find_cheap_users_2_3_0));
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_flush__find_cheap_users_2_3_0_i12);
Define_label(mercury__vn_flush__find_cheap_users_2_3_0_i1003);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__vn_flush__find_cheap_users_2_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__vn_flush__find_cheap_users_2_3_0_i12);
	MR_stackvar(5) = (Word) MR_redoip_slot(MR_maxfr);
	MR_stackvar(6) = (Word) MR_redofr_slot(MR_maxfr);
	MR_stackvar(7) = (Word) MR_maxfr;
	MR_redofr_slot(MR_maxfr) = MR_curfr;
	MR_redoip_slot(MR_maxfr) = LABEL(mercury__vn_flush__find_cheap_users_2_3_0_i1033);
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vn_src_0;
	call_localret(ENTRY(mercury__list__member_2_1),
		mercury__vn_flush__find_cheap_users_2_3_0_i18,
		STATIC(mercury__vn_flush__find_cheap_users_2_3_0));
Define_label(mercury__vn_flush__find_cheap_users_2_3_0_i18);
	update_prof_current_proc(LABEL(mercury__vn_flush__find_cheap_users_2_3_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_flush__find_cheap_users_2_3_0_i1029);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(4) = r1;
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__vn_table__search_current_value_3_0),
		mercury__vn_flush__find_cheap_users_2_3_0_i22,
		STATIC(mercury__vn_flush__find_cheap_users_2_3_0));
Define_label(mercury__vn_flush__find_cheap_users_2_3_0_i22);
	update_prof_current_proc(LABEL(mercury__vn_flush__find_cheap_users_2_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_flush__find_cheap_users_2_3_0_i1029);
	if ((MR_tag(MR_stackvar(4)) != MR_mktag((Integer) 1)))
		GOTO(ENTRY(do_redo));
	r1 = r2;
	r2 = (Word) MR_string_const("vn_flush__find_cheap_users_2", 28);
	r3 = MR_stackvar(1);
	call_localret(ENTRY(mercury__vn_table__lookup_uses_4_0),
		mercury__vn_flush__find_cheap_users_2_3_0_i25,
		STATIC(mercury__vn_flush__find_cheap_users_2_3_0));
Define_label(mercury__vn_flush__find_cheap_users_2_3_0_i25);
	update_prof_current_proc(LABEL(mercury__vn_flush__find_cheap_users_2_3_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vn_src_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury__vn_flush__find_cheap_users_2_3_0_i1028,
		STATIC(mercury__vn_flush__find_cheap_users_2_3_0));
Define_label(mercury__vn_flush__find_cheap_users_2_3_0_i1028);
	update_prof_current_proc(LABEL(mercury__vn_flush__find_cheap_users_2_3_0));
	if (!(r1))
		GOTO(ENTRY(do_redo));
Define_label(mercury__vn_flush__find_cheap_users_2_3_0_i1029);
	MR_maxfr = (Word *) MR_stackvar(7);
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(5);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(6);
	GOTO_LABEL(mercury__vn_flush__find_cheap_users_2_3_0_i1003);
Define_label(mercury__vn_flush__find_cheap_users_2_3_0_i1033);
	update_prof_current_proc(LABEL(mercury__vn_flush__find_cheap_users_2_3_0));
	MR_redoip_slot(MR_maxfr) = (Code *) MR_stackvar(5);
	MR_redofr_slot(MR_maxfr) = (Word *) MR_stackvar(6);
	r1 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__vn_flush__find_cheap_users_2_3_0_i7);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(2);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__vn_flush__find_cheap_users_2_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__vn_flush__find_cheap_users_2_3_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
Define_label(mercury__vn_flush__find_cheap_users_2_3_0_i2);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
END_MODULE


BEGIN_MODULE(vn_flush_module7)
	init_entry(mercury__vn_flush__ensure_assignment_9_0);
	init_label(mercury__vn_flush__ensure_assignment_9_0_i3);
	init_label(mercury__vn_flush__ensure_assignment_9_0_i5);
	init_label(mercury__vn_flush__ensure_assignment_9_0_i1005);
	init_label(mercury__vn_flush__ensure_assignment_9_0_i7);
	init_label(mercury__vn_flush__ensure_assignment_9_0_i2);
	init_label(mercury__vn_flush__ensure_assignment_9_0_i8);
BEGIN_CODE

/* code for predicate 'ensure_assignment'/9 in mode 0 */
Define_static(mercury__vn_flush__ensure_assignment_9_0);
	MR_incr_sp_push_msg(8, "vn_flush:ensure_assignment/9");
	MR_stackvar(8) = (Word) MR_succip;
	MR_stackvar(2) = r2;
	r2 = r4;
	MR_stackvar(1) = r1;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r5;
	MR_stackvar(6) = r6;
	call_localret(ENTRY(mercury__vn_table__search_current_value_3_0),
		mercury__vn_flush__ensure_assignment_9_0_i3,
		STATIC(mercury__vn_flush__ensure_assignment_9_0));
Define_label(mercury__vn_flush__ensure_assignment_9_0_i3);
	update_prof_current_proc(LABEL(mercury__vn_flush__ensure_assignment_9_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_flush__ensure_assignment_9_0_i2);
	if ((MR_stackvar(2) != r2))
		GOTO_LABEL(mercury__vn_flush__ensure_assignment_9_0_i2);
	r1 = MR_stackvar(2);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__vn_flush__ensure_assignment_9_0, "vn_type:vn_src/0");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(1);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__vn_table__del_old_use_4_0),
		mercury__vn_flush__ensure_assignment_9_0_i5,
		STATIC(mercury__vn_flush__ensure_assignment_9_0));
Define_label(mercury__vn_flush__ensure_assignment_9_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_flush__ensure_assignment_9_0));
	MR_stackvar(7) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__vn_util__vnlval_access_vns_2_0),
		mercury__vn_flush__ensure_assignment_9_0_i1005,
		STATIC(mercury__vn_flush__ensure_assignment_9_0));
Define_label(mercury__vn_flush__ensure_assignment_9_0_i1005);
	update_prof_current_proc(LABEL(mercury__vn_flush__ensure_assignment_9_0));
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 1, mercury__vn_flush__ensure_assignment_9_0, "vn_type:vn_src/0");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_stackvar(1);
	r3 = MR_stackvar(7);
	call_localret(ENTRY(mercury__vn_table__del_old_uses_4_0),
		mercury__vn_flush__ensure_assignment_9_0_i7,
		STATIC(mercury__vn_flush__ensure_assignment_9_0));
Define_label(mercury__vn_flush__ensure_assignment_9_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_flush__ensure_assignment_9_0));
	r2 = MR_stackvar(5);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
Define_label(mercury__vn_flush__ensure_assignment_9_0_i2);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	r5 = MR_stackvar(5);
	r6 = MR_stackvar(6);
	call_localret(STATIC(mercury__vn_flush__generate_assignment_10_0),
		mercury__vn_flush__ensure_assignment_9_0_i8,
		STATIC(mercury__vn_flush__ensure_assignment_9_0));
Define_label(mercury__vn_flush__ensure_assignment_9_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_flush__ensure_assignment_9_0));
	r3 = r4;
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
END_MODULE

Declare_entry(mercury__require__error_1_0);
Declare_entry(mercury__vn_temploc__no_temploc_3_0);
Declare_entry(mercury__vn_util__find_lvals_in_rval_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_llds__type_ctor_info_lval_0;
Declare_entry(mercury__list__condense_2_0);

BEGIN_MODULE(vn_flush_module8)
	init_entry(mercury__vn_flush__generate_assignment_10_0);
	init_label(mercury__vn_flush__generate_assignment_10_0_i4);
	init_label(mercury__vn_flush__generate_assignment_10_0_i2);
	init_label(mercury__vn_flush__generate_assignment_10_0_i5);
	init_label(mercury__vn_flush__generate_assignment_10_0_i6);
	init_label(mercury__vn_flush__generate_assignment_10_0_i7);
	init_label(mercury__vn_flush__generate_assignment_10_0_i8);
	init_label(mercury__vn_flush__generate_assignment_10_0_i11);
	init_label(mercury__vn_flush__generate_assignment_10_0_i13);
	init_label(mercury__vn_flush__generate_assignment_10_0_i14);
	init_label(mercury__vn_flush__generate_assignment_10_0_i15);
	init_label(mercury__vn_flush__generate_assignment_10_0_i9);
	init_label(mercury__vn_flush__generate_assignment_10_0_i16);
	init_label(mercury__vn_flush__generate_assignment_10_0_i18);
	init_label(mercury__vn_flush__generate_assignment_10_0_i20);
	init_label(mercury__vn_flush__generate_assignment_10_0_i17);
	init_label(mercury__vn_flush__generate_assignment_10_0_i21);
	init_label(mercury__vn_flush__generate_assignment_10_0_i23);
BEGIN_CODE

/* code for predicate 'generate_assignment'/10 in mode 0 */
Define_static(mercury__vn_flush__generate_assignment_10_0);
	MR_incr_sp_push_msg(13, "vn_flush:generate_assignment/10");
	MR_stackvar(13) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 3))))
		GOTO_LABEL(mercury__vn_flush__generate_assignment_10_0_i2);
	MR_stackvar(1) = r1;
	r1 = (Word) MR_string_const("vn_hp should never need to be explicitly flushed", 48);
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r5;
	MR_stackvar(6) = r6;
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_flush__generate_assignment_10_0_i4,
		STATIC(mercury__vn_flush__generate_assignment_10_0));
Define_label(mercury__vn_flush__generate_assignment_10_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_flush__generate_assignment_10_0));
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(5);
	GOTO_LABEL(mercury__vn_flush__generate_assignment_10_0_i5);
Define_label(mercury__vn_flush__generate_assignment_10_0_i2);
	MR_stackvar(2) = r2;
	r2 = r5;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	MR_stackvar(6) = r6;
Define_label(mercury__vn_flush__generate_assignment_10_0_i5);
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__vn_temploc__no_temploc_3_0),
		mercury__vn_flush__generate_assignment_10_0_i6,
		STATIC(mercury__vn_flush__generate_assignment_10_0));
Define_label(mercury__vn_flush__generate_assignment_10_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_flush__generate_assignment_10_0));
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__vn_flush__generate_assignment_10_0, "origin_lost_in_value_number");
	r3 = r1;
	r1 = MR_stackvar(1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__vn_flush__generate_assignment_10_0, "origin_lost_in_value_number");
	r5 = r3;
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_tempr1;
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	r6 = MR_stackvar(6);
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = r1;
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(STATIC(mercury__vn_flush__access_path_10_0),
		mercury__vn_flush__generate_assignment_10_0_i7,
		STATIC(mercury__vn_flush__generate_assignment_10_0));
	}
Define_label(mercury__vn_flush__generate_assignment_10_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_flush__generate_assignment_10_0));
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(2);
	r6 = r2;
	MR_stackvar(7) = r4;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__vn_flush__generate_assignment_10_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__vn_flush__generate_assignment_10_0, "origin_lost_in_value_number");
	r4 = r6;
	r5 = r3;
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_tempr1;
	r3 = MR_stackvar(3);
	r6 = MR_stackvar(6);
	MR_field(MR_mktag(1), r2, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_stackvar(1);
	call_localret(STATIC(mercury__vn_flush__vn_10_0),
		mercury__vn_flush__generate_assignment_10_0_i8,
		STATIC(mercury__vn_flush__generate_assignment_10_0));
	}
Define_label(mercury__vn_flush__generate_assignment_10_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_flush__generate_assignment_10_0));
	MR_stackvar(8) = r1;
	MR_stackvar(9) = r2;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(4);
	MR_stackvar(10) = r3;
	MR_stackvar(11) = r4;
	call_localret(ENTRY(mercury__vn_table__search_current_value_3_0),
		mercury__vn_flush__generate_assignment_10_0_i11,
		STATIC(mercury__vn_flush__generate_assignment_10_0));
Define_label(mercury__vn_flush__generate_assignment_10_0_i11);
	update_prof_current_proc(LABEL(mercury__vn_flush__generate_assignment_10_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_flush__generate_assignment_10_0_i9);
	MR_stackvar(4) = r2;
	r1 = MR_stackvar(8);
	call_localret(ENTRY(mercury__vn_util__find_lvals_in_rval_2_0),
		mercury__vn_flush__generate_assignment_10_0_i13,
		STATIC(mercury__vn_flush__generate_assignment_10_0));
Define_label(mercury__vn_flush__generate_assignment_10_0_i13);
	update_prof_current_proc(LABEL(mercury__vn_flush__generate_assignment_10_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_lval_0;
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__vn_flush__generate_assignment_10_0_i14,
		STATIC(mercury__vn_flush__generate_assignment_10_0));
Define_label(mercury__vn_flush__generate_assignment_10_0_i14);
	update_prof_current_proc(LABEL(mercury__vn_flush__generate_assignment_10_0));
	r4 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(2);
	r5 = MR_stackvar(9);
	r6 = MR_stackvar(10);
	r7 = MR_stackvar(6);
	call_localret(STATIC(mercury__vn_flush__maybe_save_prev_value_10_0),
		mercury__vn_flush__generate_assignment_10_0_i15,
		STATIC(mercury__vn_flush__generate_assignment_10_0));
Define_label(mercury__vn_flush__generate_assignment_10_0_i15);
	update_prof_current_proc(LABEL(mercury__vn_flush__generate_assignment_10_0));
	MR_stackvar(4) = r2;
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(12) = r3;
	GOTO_LABEL(mercury__vn_flush__generate_assignment_10_0_i16);
Define_label(mercury__vn_flush__generate_assignment_10_0_i9);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(9);
	MR_stackvar(4) = MR_stackvar(10);
	MR_stackvar(12) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
Define_label(mercury__vn_flush__generate_assignment_10_0_i16);
	MR_stackvar(1) = r1;
	MR_stackvar(6) = r2;
	call_localret(ENTRY(mercury__vn_table__search_current_value_3_0),
		mercury__vn_flush__generate_assignment_10_0_i18,
		STATIC(mercury__vn_flush__generate_assignment_10_0));
Define_label(mercury__vn_flush__generate_assignment_10_0_i18);
	update_prof_current_proc(LABEL(mercury__vn_flush__generate_assignment_10_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_flush__generate_assignment_10_0_i17);
	if ((MR_stackvar(2) != r2))
		GOTO_LABEL(mercury__vn_flush__generate_assignment_10_0_i17);
	r1 = MR_stackvar(11);
	call_localret(STATIC(mercury__vn_flush__get_incr_hp_3_0),
		mercury__vn_flush__generate_assignment_10_0_i20,
		STATIC(mercury__vn_flush__generate_assignment_10_0));
Define_label(mercury__vn_flush__generate_assignment_10_0_i20);
	update_prof_current_proc(LABEL(mercury__vn_flush__generate_assignment_10_0));
	MR_stackvar(3) = MR_stackvar(6);
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__vn_flush__generate_assignment_10_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(7);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__vn_flush__generate_assignment_10_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = r3;
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__vn_flush__generate_assignment_10_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_stackvar(12);
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__vn_flush__generate_assignment_10_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__vn_flush__generate_assignment_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r6, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_flush__common_0);
	MR_field(MR_mktag(1), r2, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__list__condense_2_0),
		mercury__vn_flush__generate_assignment_10_0_i23,
		STATIC(mercury__vn_flush__generate_assignment_10_0));
Define_label(mercury__vn_flush__generate_assignment_10_0_i17);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(6);
	call_localret(ENTRY(mercury__vn_table__set_current_value_4_0),
		mercury__vn_flush__generate_assignment_10_0_i21,
		STATIC(mercury__vn_flush__generate_assignment_10_0));
Define_label(mercury__vn_flush__generate_assignment_10_0_i21);
	update_prof_current_proc(LABEL(mercury__vn_flush__generate_assignment_10_0));
	MR_stackvar(3) = r1;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__vn_flush__generate_assignment_10_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(7);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__vn_flush__generate_assignment_10_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(11);
	tag_incr_hp_msg(r4, MR_mktag(1), (Integer) 2, mercury__vn_flush__generate_assignment_10_0, "list:list/1");
	MR_field(MR_mktag(1), r4, (Integer) 0) = MR_stackvar(12);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__vn_flush__generate_assignment_10_0, "list:list/1");
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__vn_flush__generate_assignment_10_0, "list:list/1");
	tag_incr_hp_msg(r7, MR_mktag(0), (Integer) 2, mercury__vn_flush__generate_assignment_10_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 3, mercury__vn_flush__generate_assignment_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r7, (Integer) 0) = MR_tempr1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_flush__common_0);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_stackvar(8);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(5);
	MR_field(MR_mktag(1), r2, (Integer) 1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r4;
	MR_field(MR_mktag(1), r4, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 0) = r6;
	MR_field(MR_mktag(1), r5, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r6, (Integer) 0) = r7;
	MR_field(MR_mktag(1), r6, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(0), r7, (Integer) 1) = (Word) MR_string_const("vn flush", 8);
	call_localret(ENTRY(mercury__list__condense_2_0),
		mercury__vn_flush__generate_assignment_10_0_i23,
		STATIC(mercury__vn_flush__generate_assignment_10_0));
	}
Define_label(mercury__vn_flush__generate_assignment_10_0_i23);
	update_prof_current_proc(LABEL(mercury__vn_flush__generate_assignment_10_0));
	r4 = r1;
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	proceed();
END_MODULE


BEGIN_MODULE(vn_flush_module9)
	init_entry(mercury__vn_flush__get_incr_hp_3_0);
	init_label(mercury__vn_flush__get_incr_hp_3_0_i1004);
	init_label(mercury__vn_flush__get_incr_hp_3_0_i5);
	init_label(mercury__vn_flush__get_incr_hp_3_0_i7);
BEGIN_CODE

/* code for predicate 'get_incr_hp'/3 in mode 0 */
Define_static(mercury__vn_flush__get_incr_hp_3_0);
	MR_incr_sp_push_msg(2, "vn_flush:get_incr_hp/3");
	MR_stackvar(2) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_flush__get_incr_hp_3_0_i1004);
	r1 = (Word) MR_string_const("could not find incr_hp", 22);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__vn_flush__get_incr_hp_3_0));
Define_label(mercury__vn_flush__get_incr_hp_3_0_i1004);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	if ((MR_tag(MR_tempr1) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__vn_flush__get_incr_hp_3_0_i5);
	if (((Integer) MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 0) != (Integer) 9))
		GOTO_LABEL(mercury__vn_flush__get_incr_hp_3_0_i5);
	r1 = r3;
	MR_decr_sp_pop_msg(2);
	proceed();
	}
Define_label(mercury__vn_flush__get_incr_hp_3_0_i5);
	MR_stackvar(1) = r3;
	r1 = r2;
	localcall(mercury__vn_flush__get_incr_hp_3_0,
		LABEL(mercury__vn_flush__get_incr_hp_3_0_i7),
		STATIC(mercury__vn_flush__get_incr_hp_3_0));
Define_label(mercury__vn_flush__get_incr_hp_3_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_flush__get_incr_hp_3_0));
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__vn_flush__get_incr_hp_3_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r2, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE

Declare_entry(mercury__vn_util__is_const_expr_3_0);

BEGIN_MODULE(vn_flush_module10)
	init_entry(mercury__vn_flush__vn_10_0);
	init_label(mercury__vn_flush__vn_10_0_i2);
	init_label(mercury__vn_flush__vn_10_0_i4);
	init_label(mercury__vn_flush__vn_10_0_i5);
	init_label(mercury__vn_flush__vn_10_0_i6);
	init_label(mercury__vn_flush__vn_10_0_i9);
	init_label(mercury__vn_flush__vn_10_0_i10);
	init_label(mercury__vn_flush__vn_10_0_i11);
	init_label(mercury__vn_flush__vn_10_0_i14);
	init_label(mercury__vn_flush__vn_10_0_i16);
	init_label(mercury__vn_flush__vn_10_0_i23);
	init_label(mercury__vn_flush__vn_10_0_i26);
	init_label(mercury__vn_flush__vn_10_0_i27);
	init_label(mercury__vn_flush__vn_10_0_i28);
	init_label(mercury__vn_flush__vn_10_0_i31);
	init_label(mercury__vn_flush__vn_10_0_i19);
	init_label(mercury__vn_flush__vn_10_0_i20);
	init_label(mercury__vn_flush__vn_10_0_i34);
	init_label(mercury__vn_flush__vn_10_0_i12);
	init_label(mercury__vn_flush__vn_10_0_i42);
	init_label(mercury__vn_flush__vn_10_0_i43);
	init_label(mercury__vn_flush__vn_10_0_i38);
	init_label(mercury__vn_flush__vn_10_0_i8);
	init_label(mercury__vn_flush__vn_10_0_i47);
	init_label(mercury__vn_flush__vn_10_0_i48);
BEGIN_CODE

/* code for predicate 'vn'/10 in mode 0 */
Define_static(mercury__vn_flush__vn_10_0);
	MR_incr_sp_push_msg(13, "vn_flush:vn/10");
	MR_stackvar(13) = (Word) MR_succip;
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_flush__vn_10_0_i2);
	MR_stackvar(2) = r2;
	MR_stackvar(10) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r2 = r4;
	MR_stackvar(3) = r3;
	MR_stackvar(6) = r5;
	MR_stackvar(8) = r6;
	GOTO_LABEL(mercury__vn_flush__vn_10_0_i5);
Define_label(mercury__vn_flush__vn_10_0_i2);
	MR_stackvar(1) = r1;
	r1 = (Word) MR_string_const("empty source list in flush_vn", 29);
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	MR_stackvar(5) = r4;
	MR_stackvar(6) = r5;
	MR_stackvar(8) = r6;
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_flush__vn_10_0_i4,
		STATIC(mercury__vn_flush__vn_10_0));
Define_label(mercury__vn_flush__vn_10_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_10_0));
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(5);
Define_label(mercury__vn_flush__vn_10_0_i5);
	MR_stackvar(1) = r1;
	MR_stackvar(5) = r2;
	call_localret(ENTRY(mercury__vn_util__is_const_expr_3_0),
		mercury__vn_flush__vn_10_0_i6,
		STATIC(mercury__vn_flush__vn_10_0));
Define_label(mercury__vn_flush__vn_10_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_10_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__vn_flush__vn_10_0_i8);
	r1 = MR_stackvar(1);
	r2 = (Word) MR_string_const("vn_flush__vn", 12);
	r3 = MR_stackvar(5);
	call_localret(ENTRY(mercury__vn_table__lookup_current_locs_4_0),
		mercury__vn_flush__vn_10_0_i9,
		STATIC(mercury__vn_flush__vn_10_0));
Define_label(mercury__vn_flush__vn_10_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_10_0));
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(1);
	r2 = (Word) MR_string_const("vn_flush__vn", 12);
	r3 = MR_stackvar(5);
	call_localret(ENTRY(mercury__vn_table__lookup_uses_4_0),
		mercury__vn_flush__vn_10_0_i10,
		STATIC(mercury__vn_flush__vn_10_0));
Define_label(mercury__vn_flush__vn_10_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_10_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vn_src_0;
	r3 = MR_stackvar(10);
	call_localret(ENTRY(mercury__list__delete_all_3_1),
		mercury__vn_flush__vn_10_0_i11,
		STATIC(mercury__vn_flush__vn_10_0));
Define_label(mercury__vn_flush__vn_10_0_i11);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_10_0));
	MR_stackvar(11) = r1;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__vn_util__choose_cheapest_loc_2_0),
		mercury__vn_flush__vn_10_0_i14,
		STATIC(mercury__vn_flush__vn_10_0));
Define_label(mercury__vn_flush__vn_10_0_i14);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_10_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_flush__vn_10_0_i12);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 3))))
		GOTO_LABEL(mercury__vn_flush__vn_10_0_i16);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(5);
	r4 = MR_stackvar(6);
	r5 = MR_stackvar(8);
	call_localret(STATIC(mercury__vn_flush__old_hp_9_0),
		mercury__vn_flush__vn_10_0_i47,
		STATIC(mercury__vn_flush__vn_10_0));
Define_label(mercury__vn_flush__vn_10_0_i16);
	r3 = MR_stackvar(11);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_flush__vn_10_0_i20);
	if (((Integer) MR_const_field(MR_mktag(1), r3, (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_flush__vn_10_0_i20);
	r1 = r2;
	MR_stackvar(12) = r2;
	call_localret(ENTRY(mercury__vn_util__classify_loc_cost_2_0),
		mercury__vn_flush__vn_10_0_i23,
		STATIC(mercury__vn_flush__vn_10_0));
Define_label(mercury__vn_flush__vn_10_0_i23);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_10_0));
	if (((Integer) r1 <= (Integer) 0))
		GOTO_LABEL(mercury__vn_flush__vn_10_0_i19);
	if ((MR_tag(MR_stackvar(10)) == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_flush__vn_10_0_i19);
	r1 = MR_stackvar(1);
	r2 = (Word) MR_string_const("vn_flush__choose_temp", 21);
	r3 = MR_stackvar(5);
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_flush__vn_10_0_i26,
		STATIC(mercury__vn_flush__vn_10_0));
Define_label(mercury__vn_flush__vn_10_0_i26);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_10_0));
	call_localret(ENTRY(mercury__vn_type__vnrval_type_2_0),
		mercury__vn_flush__vn_10_0_i27,
		STATIC(mercury__vn_flush__vn_10_0));
Define_label(mercury__vn_flush__vn_10_0_i27);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_10_0));
	if (((Integer) r1 != (Integer) 9))
		GOTO_LABEL(mercury__vn_flush__vn_10_0_i28);
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__vn_temploc__next_tempf_3_0),
		mercury__vn_flush__vn_10_0_i31,
		STATIC(mercury__vn_flush__vn_10_0));
Define_label(mercury__vn_flush__vn_10_0_i28);
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__vn_temploc__next_tempr_3_0),
		mercury__vn_flush__vn_10_0_i31,
		STATIC(mercury__vn_flush__vn_10_0));
Define_label(mercury__vn_flush__vn_10_0_i31);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_10_0));
	r5 = r1;
	r1 = r2;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(5);
	r6 = MR_stackvar(8);
	call_localret(STATIC(mercury__vn_flush__generate_assignment_10_0),
		mercury__vn_flush__vn_10_0_i43,
		STATIC(mercury__vn_flush__vn_10_0));
Define_label(mercury__vn_flush__vn_10_0_i19);
	r2 = MR_stackvar(12);
Define_label(mercury__vn_flush__vn_10_0_i20);
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__vn_flush__vn_10_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 1, mercury__vn_flush__vn_10_0, "vn_type:vn_src/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r2, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(5);
	r5 = MR_stackvar(6);
	r6 = MR_stackvar(8);
	call_localret(STATIC(mercury__vn_flush__access_path_10_0),
		mercury__vn_flush__vn_10_0_i34,
		STATIC(mercury__vn_flush__vn_10_0));
Define_label(mercury__vn_flush__vn_10_0_i34);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_10_0));
	r5 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(7) = r3;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 1, mercury__vn_flush__vn_10_0, "origin_lost_in_value_number");
	r3 = r2;
	MR_stackvar(4) = MR_tempr1;
	r2 = MR_stackvar(10);
	MR_stackvar(9) = r4;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r5;
	call_localret(ENTRY(mercury__vn_table__del_old_use_4_0),
		mercury__vn_flush__vn_10_0_i48,
		STATIC(mercury__vn_flush__vn_10_0));
	}
Define_label(mercury__vn_flush__vn_10_0_i12);
	r1 = MR_stackvar(11);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_flush__vn_10_0_i38);
	if ((MR_tag(MR_stackvar(10)) == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_flush__vn_10_0_i38);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(6);
	call_localret(STATIC(mercury__vn_flush__choose_loc_for_shared_vn_5_0),
		mercury__vn_flush__vn_10_0_i42,
		STATIC(mercury__vn_flush__vn_10_0));
Define_label(mercury__vn_flush__vn_10_0_i42);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_10_0));
	r5 = r2;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(5);
	r6 = MR_stackvar(8);
	call_localret(STATIC(mercury__vn_flush__generate_assignment_10_0),
		mercury__vn_flush__vn_10_0_i43,
		STATIC(mercury__vn_flush__vn_10_0));
Define_label(mercury__vn_flush__vn_10_0_i43);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_10_0));
	r5 = r1;
	r1 = MR_stackvar(1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 1, mercury__vn_flush__vn_10_0, "origin_lost_in_value_number");
	MR_stackvar(4) = MR_tempr1;
	MR_stackvar(7) = r2;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r3;
	r2 = MR_stackvar(10);
	r3 = r5;
	MR_stackvar(9) = r4;
	call_localret(ENTRY(mercury__vn_table__del_old_use_4_0),
		mercury__vn_flush__vn_10_0_i48,
		STATIC(mercury__vn_flush__vn_10_0));
	}
Define_label(mercury__vn_flush__vn_10_0_i38);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(5);
	r5 = MR_stackvar(6);
	r6 = MR_stackvar(8);
	call_localret(STATIC(mercury__vn_flush__vn_value_10_0),
		mercury__vn_flush__vn_10_0_i47,
		STATIC(mercury__vn_flush__vn_10_0));
Define_label(mercury__vn_flush__vn_10_0_i8);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(5);
	r5 = MR_stackvar(6);
	r6 = MR_stackvar(8);
	call_localret(STATIC(mercury__vn_flush__vn_value_10_0),
		mercury__vn_flush__vn_10_0_i47,
		STATIC(mercury__vn_flush__vn_10_0));
Define_label(mercury__vn_flush__vn_10_0_i47);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_10_0));
	MR_stackvar(7) = r3;
	r3 = r2;
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(10);
	MR_stackvar(9) = r4;
	call_localret(ENTRY(mercury__vn_table__del_old_use_4_0),
		mercury__vn_flush__vn_10_0_i48,
		STATIC(mercury__vn_flush__vn_10_0));
Define_label(mercury__vn_flush__vn_10_0_i48);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_10_0));
	r2 = r1;
	r1 = MR_stackvar(4);
	r3 = MR_stackvar(7);
	r4 = MR_stackvar(9);
	MR_succip = (Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	proceed();
END_MODULE

Declare_entry(mercury__opt_debug__dump_vnlval_2_0);
Declare_entry(mercury__string__append_3_2);

BEGIN_MODULE(vn_flush_module11)
	init_entry(mercury__vn_flush__vn_value_10_0);
	init_label(mercury__vn_flush__vn_value_10_0_i2);
	init_label(mercury__vn_flush__vn_value_10_0_i5);
	init_label(mercury__vn_flush__vn_value_10_0_i8);
	init_label(mercury__vn_flush__vn_value_10_0_i6);
	init_label(mercury__vn_flush__vn_value_10_0_i9);
	init_label(mercury__vn_flush__vn_value_10_0_i10);
	init_label(mercury__vn_flush__vn_value_10_0_i12);
	init_label(mercury__vn_flush__vn_value_10_0_i11);
	init_label(mercury__vn_flush__vn_value_10_0_i16);
	init_label(mercury__vn_flush__vn_value_10_0_i15);
	init_label(mercury__vn_flush__vn_value_10_0_i18);
	init_label(mercury__vn_flush__vn_value_10_0_i19);
	init_label(mercury__vn_flush__vn_value_10_0_i20);
	init_label(mercury__vn_flush__vn_value_10_0_i22);
	init_label(mercury__vn_flush__vn_value_10_0_i23);
	init_label(mercury__vn_flush__vn_value_10_0_i25);
	init_label(mercury__vn_flush__vn_value_10_0_i28);
	init_label(mercury__vn_flush__vn_value_10_0_i29);
	init_label(mercury__vn_flush__vn_value_10_0_i32);
	init_label(mercury__vn_flush__vn_value_10_0_i1025);
	init_label(mercury__vn_flush__vn_value_10_0_i24);
	init_label(mercury__vn_flush__vn_value_10_0_i34);
	init_label(mercury__vn_flush__vn_value_10_0_i36);
	init_label(mercury__vn_flush__vn_value_10_0_i37);
	init_label(mercury__vn_flush__vn_value_10_0_i38);
	init_label(mercury__vn_flush__vn_value_10_0_i39);
	init_label(mercury__vn_flush__vn_value_10_0_i40);
	init_label(mercury__vn_flush__vn_value_10_0_i41);
	init_label(mercury__vn_flush__vn_value_10_0_i42);
	init_label(mercury__vn_flush__vn_value_10_0_i43);
	init_label(mercury__vn_flush__vn_value_10_0_i44);
	init_label(mercury__vn_flush__vn_value_10_0_i45);
	init_label(mercury__vn_flush__vn_value_10_0_i46);
	init_label(mercury__vn_flush__vn_value_10_0_i47);
	init_label(mercury__vn_flush__vn_value_10_0_i48);
BEGIN_CODE

/* code for predicate 'vn_value'/10 in mode 0 */
Define_static(mercury__vn_flush__vn_value_10_0);
	MR_incr_sp_push_msg(13, "vn_flush:vn_value/10");
	MR_stackvar(13) = (Word) MR_succip;
	MR_stackvar(3) = r3;
	MR_stackvar(2) = r2;
	r2 = (Word) MR_string_const("vn_flush__vn_value", 18);
	r3 = r4;
	MR_stackvar(1) = r1;
	MR_stackvar(4) = r4;
	MR_stackvar(6) = r5;
	MR_stackvar(8) = r6;
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_flush__vn_value_10_0_i2,
		STATIC(mercury__vn_flush__vn_value_10_0));
Define_label(mercury__vn_flush__vn_value_10_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_value_10_0));
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__vn_flush__vn_value_10_0_i5) AND
		LABEL(mercury__vn_flush__vn_value_10_0_i23) AND
		LABEL(mercury__vn_flush__vn_value_10_0_i36) AND
		LABEL(mercury__vn_flush__vn_value_10_0_i37));
Define_label(mercury__vn_flush__vn_value_10_0_i5);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 3))))
		GOTO_LABEL(mercury__vn_flush__vn_value_10_0_i6);
	MR_stackvar(5) = r2;
	r1 = (Word) MR_string_const("vn_hp found in flush_vn_value", 29);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_flush__vn_value_10_0_i8,
		STATIC(mercury__vn_flush__vn_value_10_0));
Define_label(mercury__vn_flush__vn_value_10_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_value_10_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	r3 = MR_stackvar(4);
	GOTO_LABEL(mercury__vn_flush__vn_value_10_0_i9);
Define_label(mercury__vn_flush__vn_value_10_0_i6);
	MR_stackvar(5) = r2;
	r1 = MR_stackvar(1);
	r2 = (Word) MR_string_const("vn_flush__vn_value", 18);
	r3 = MR_stackvar(4);
Define_label(mercury__vn_flush__vn_value_10_0_i9);
	MR_stackvar(1) = r1;
	MR_stackvar(4) = r3;
	call_localret(ENTRY(mercury__vn_table__lookup_current_locs_4_0),
		mercury__vn_flush__vn_value_10_0_i10,
		STATIC(mercury__vn_flush__vn_value_10_0));
Define_label(mercury__vn_flush__vn_value_10_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_value_10_0));
	MR_stackvar(7) = r1;
	r1 = MR_stackvar(5);
	r2 = (Word) MR_string_const("vn_flush__vn_value", 18);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__vn_table__lookup_current_value_4_0),
		mercury__vn_flush__vn_value_10_0_i12,
		STATIC(mercury__vn_flush__vn_value_10_0));
Define_label(mercury__vn_flush__vn_value_10_0_i12);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_value_10_0));
	if ((MR_stackvar(1) != r1))
		GOTO_LABEL(mercury__vn_flush__vn_value_10_0_i11);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__vn_flush__vn_value_10_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(5);
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_stackvar(7);
	call_localret(ENTRY(mercury__vn_util__choose_cheapest_loc_2_0),
		mercury__vn_flush__vn_value_10_0_i16,
		STATIC(mercury__vn_flush__vn_value_10_0));
Define_label(mercury__vn_flush__vn_value_10_0_i11);
	r1 = MR_stackvar(7);
	call_localret(ENTRY(mercury__vn_util__choose_cheapest_loc_2_0),
		mercury__vn_flush__vn_value_10_0_i16,
		STATIC(mercury__vn_flush__vn_value_10_0));
Define_label(mercury__vn_flush__vn_value_10_0_i16);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_value_10_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_flush__vn_value_10_0_i15);
	r1 = r2;
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	r5 = MR_stackvar(6);
	r6 = MR_stackvar(8);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__vn_flush__vn_value_10_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 1, mercury__vn_flush__vn_value_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_stackvar(2);
	call_localret(STATIC(mercury__vn_flush__access_path_10_0),
		mercury__vn_flush__vn_value_10_0_i22,
		STATIC(mercury__vn_flush__vn_value_10_0));
	}
Define_label(mercury__vn_flush__vn_value_10_0_i15);
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__opt_debug__dump_vnlval_2_0),
		mercury__vn_flush__vn_value_10_0_i18,
		STATIC(mercury__vn_flush__vn_value_10_0));
Define_label(mercury__vn_flush__vn_value_10_0_i18);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_value_10_0));
	r2 = r1;
	r1 = (Word) MR_string_const("cannot find copy of an origlval: ", 33);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__vn_flush__vn_value_10_0_i19,
		STATIC(mercury__vn_flush__vn_value_10_0));
Define_label(mercury__vn_flush__vn_value_10_0_i19);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_value_10_0));
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_flush__vn_value_10_0_i20,
		STATIC(mercury__vn_flush__vn_value_10_0));
Define_label(mercury__vn_flush__vn_value_10_0_i20);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_value_10_0));
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	r5 = MR_stackvar(6);
	r6 = MR_stackvar(8);
	call_localret(STATIC(mercury__vn_flush__access_path_10_0),
		mercury__vn_flush__vn_value_10_0_i22,
		STATIC(mercury__vn_flush__vn_value_10_0));
Define_label(mercury__vn_flush__vn_value_10_0_i22);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_value_10_0));
	r5 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 1, mercury__vn_flush__vn_value_10_0, "llds:rval/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = r5;
	MR_succip = (Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	proceed();
Define_label(mercury__vn_flush__vn_value_10_0_i23);
	MR_stackvar(10) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(11) = r1;
	r2 = (Word) MR_string_const("vn_flush__vn_value", 18);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_flush__vn_value_10_0_i25,
		STATIC(mercury__vn_flush__vn_value_10_0));
Define_label(mercury__vn_flush__vn_value_10_0_i25);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_value_10_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__vn_flush__vn_value_10_0_i24);
	if (((Integer) MR_const_field(MR_mktag(0), r1, (Integer) 0) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 3))))
		GOTO_LABEL(mercury__vn_flush__vn_value_10_0_i24);
	r1 = MR_stackvar(11);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__vn_flush__vn_value_10_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 1, mercury__vn_flush__vn_value_10_0, "vn_type:vn_src/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r2, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	r5 = MR_stackvar(6);
	r6 = MR_stackvar(8);
	call_localret(STATIC(mercury__vn_flush__vn_10_0),
		mercury__vn_flush__vn_value_10_0_i28,
		STATIC(mercury__vn_flush__vn_value_10_0));
Define_label(mercury__vn_flush__vn_value_10_0_i28);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_value_10_0));
	MR_stackvar(7) = r3;
	r3 = r2;
	MR_stackvar(5) = r2;
	MR_stackvar(12) = r1;
	r1 = MR_stackvar(1);
	r2 = (Word) MR_string_const("vn_flush__vn_value", 18);
	MR_stackvar(9) = r4;
	call_localret(ENTRY(mercury__vn_table__lookup_current_locs_4_0),
		mercury__vn_flush__vn_value_10_0_i29,
		STATIC(mercury__vn_flush__vn_value_10_0));
Define_label(mercury__vn_flush__vn_value_10_0_i29);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_value_10_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_flush__vn_value_10_0_i1025);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(5);
	r5 = MR_stackvar(6);
	r6 = MR_stackvar(8);
	call_localret(STATIC(mercury__vn_flush__access_path_10_0),
		mercury__vn_flush__vn_value_10_0_i32,
		STATIC(mercury__vn_flush__vn_value_10_0));
Define_label(mercury__vn_flush__vn_value_10_0_i32);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_value_10_0));
	r5 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 1, mercury__vn_flush__vn_value_10_0, "origin_lost_in_value_number");
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(7);
	r4 = MR_stackvar(9);
	MR_field(MR_mktag(0), r1, (Integer) 0) = r5;
	MR_succip = (Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	proceed();
Define_label(mercury__vn_flush__vn_value_10_0_i1025);
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 3, mercury__vn_flush__vn_value_10_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_stackvar(10);
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_stackvar(12);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(7);
	r4 = MR_stackvar(9);
	MR_succip = (Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	proceed();
Define_label(mercury__vn_flush__vn_value_10_0_i24);
	r1 = MR_stackvar(11);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__vn_flush__vn_value_10_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 1, mercury__vn_flush__vn_value_10_0, "vn_type:vn_src/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r2, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	r5 = MR_stackvar(6);
	r6 = MR_stackvar(8);
	call_localret(STATIC(mercury__vn_flush__vn_10_0),
		mercury__vn_flush__vn_value_10_0_i34,
		STATIC(mercury__vn_flush__vn_value_10_0));
Define_label(mercury__vn_flush__vn_value_10_0_i34);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_value_10_0));
	r5 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 3, mercury__vn_flush__vn_value_10_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_stackvar(10);
	MR_field(MR_mktag(3), r1, (Integer) 2) = r5;
	MR_succip = (Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	proceed();
Define_label(mercury__vn_flush__vn_value_10_0_i36);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__vn_flush__vn_value_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_const_field(MR_mktag(2), r2, (Integer) 0);
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(6);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 1;
	MR_succip = (Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	proceed();
Define_label(mercury__vn_flush__vn_value_10_0_i37);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__vn_flush__vn_value_10_0_i38) AND
		LABEL(mercury__vn_flush__vn_value_10_0_i39) AND
		LABEL(mercury__vn_flush__vn_value_10_0_i41) AND
		LABEL(mercury__vn_flush__vn_value_10_0_i45) AND
		LABEL(mercury__vn_flush__vn_value_10_0_i46) AND
		LABEL(mercury__vn_flush__vn_value_10_0_i47));
Define_label(mercury__vn_flush__vn_value_10_0_i38);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 6, mercury__vn_flush__vn_value_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), r1, (Integer) 5) = MR_const_field(MR_mktag(3), r2, (Integer) 6);
	MR_field(MR_mktag(2), r1, (Integer) 4) = MR_const_field(MR_mktag(3), r2, (Integer) 5);
	MR_field(MR_mktag(2), r1, (Integer) 3) = MR_const_field(MR_mktag(3), r2, (Integer) 4);
	MR_field(MR_mktag(2), r1, (Integer) 2) = MR_const_field(MR_mktag(3), r2, (Integer) 3);
	MR_field(MR_mktag(2), r1, (Integer) 0) = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	MR_field(MR_mktag(2), r1, (Integer) 1) = MR_const_field(MR_mktag(3), r2, (Integer) 2);
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(6);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	proceed();
Define_label(mercury__vn_flush__vn_value_10_0_i39);
	r4 = MR_stackvar(1);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__vn_flush__vn_value_10_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 1, mercury__vn_flush__vn_value_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = r4;
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_tempr1;
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	r5 = MR_stackvar(6);
	r6 = MR_stackvar(8);
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_stackvar(2);
	call_localret(STATIC(mercury__vn_flush__vn_10_0),
		mercury__vn_flush__vn_value_10_0_i40,
		STATIC(mercury__vn_flush__vn_value_10_0));
	}
Define_label(mercury__vn_flush__vn_value_10_0_i40);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_value_10_0));
	r5 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 3, mercury__vn_flush__vn_value_10_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), r1, (Integer) 2) = r5;
	MR_succip = (Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	proceed();
Define_label(mercury__vn_flush__vn_value_10_0_i41);
	r2 = MR_stackvar(1);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r3 = MR_stackvar(2);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	r4 = MR_stackvar(4);
	tag_incr_hp_msg(MR_stackvar(4), MR_mktag(1), (Integer) 2, mercury__vn_flush__vn_value_10_0, "list:list/1");
	{
	Word MR_tempr1, MR_tempr2;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 1, mercury__vn_flush__vn_value_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = r2;
	MR_tempr2 = MR_stackvar(4);
	MR_field(MR_mktag(1), MR_tempr2, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr2, (Integer) 1) = r3;
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r2 = MR_tempr2;
	r3 = MR_stackvar(3);
	r5 = MR_stackvar(6);
	r6 = MR_stackvar(8);
	call_localret(STATIC(mercury__vn_flush__vn_10_0),
		mercury__vn_flush__vn_value_10_0_i42,
		STATIC(mercury__vn_flush__vn_value_10_0));
	}
Define_label(mercury__vn_flush__vn_value_10_0_i42);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_value_10_0));
	r5 = r3;
	r3 = MR_stackvar(3);
	MR_stackvar(3) = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r4;
	r4 = r2;
	r2 = MR_stackvar(4);
	r6 = MR_stackvar(8);
	call_localret(STATIC(mercury__vn_flush__vn_10_0),
		mercury__vn_flush__vn_value_10_0_i43,
		STATIC(mercury__vn_flush__vn_value_10_0));
Define_label(mercury__vn_flush__vn_value_10_0_i43);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_value_10_0));
	r5 = MR_stackvar(1);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 4, mercury__vn_flush__vn_value_10_0, "origin_lost_in_value_number");
	MR_stackvar(1) = MR_tempr1;
	MR_stackvar(5) = r2;
	MR_stackvar(7) = r3;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 3) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_flush__common_0);
	r2 = MR_stackvar(2);
	r3 = r4;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_stackvar(3);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = r5;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 3;
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__vn_flush__vn_value_10_0_i44,
		STATIC(mercury__vn_flush__vn_value_10_0));
	}
Define_label(mercury__vn_flush__vn_value_10_0_i44);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_value_10_0));
	r4 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(7);
	MR_succip = (Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	proceed();
Define_label(mercury__vn_flush__vn_value_10_0_i45);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__vn_flush__vn_value_10_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 4;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 1, mercury__vn_flush__vn_value_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(6);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	proceed();
	}
Define_label(mercury__vn_flush__vn_value_10_0_i46);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__vn_flush__vn_value_10_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 4;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__vn_flush__vn_value_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(6);
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	proceed();
	}
Define_label(mercury__vn_flush__vn_value_10_0_i47);
	r3 = MR_stackvar(2);
	r5 = MR_stackvar(1);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__vn_flush__vn_value_10_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 1, mercury__vn_flush__vn_value_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = r5;
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), r2, (Integer) 1) = r3;
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	r5 = MR_stackvar(6);
	r6 = MR_stackvar(8);
	call_localret(STATIC(mercury__vn_flush__vn_10_0),
		mercury__vn_flush__vn_value_10_0_i48,
		STATIC(mercury__vn_flush__vn_value_10_0));
	}
Define_label(mercury__vn_flush__vn_value_10_0_i48);
	update_prof_current_proc(LABEL(mercury__vn_flush__vn_value_10_0));
	r5 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__vn_flush__vn_value_10_0, "llds:rval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 4;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 3, mercury__vn_flush__vn_value_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 2) = MR_stackvar(1);
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = MR_stackvar(2);
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = r5;
	MR_succip = (Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	proceed();
	}
END_MODULE

Declare_entry(mercury__vn_type__bytes_per_word_2_0);
Declare_entry(mercury__vn_util__no_access_vnlval_to_lval_2_0);

BEGIN_MODULE(vn_flush_module12)
	init_entry(mercury__vn_flush__old_hp_9_0);
	init_label(mercury__vn_flush__old_hp_9_0_i2);
	init_label(mercury__vn_flush__old_hp_9_0_i3);
	init_label(mercury__vn_flush__old_hp_9_0_i6);
	init_label(mercury__vn_flush__old_hp_9_0_i5);
	init_label(mercury__vn_flush__old_hp_9_0_i7);
	init_label(mercury__vn_flush__old_hp_9_0_i8);
	init_label(mercury__vn_flush__old_hp_9_0_i11);
	init_label(mercury__vn_flush__old_hp_9_0_i18);
	init_label(mercury__vn_flush__old_hp_9_0_i19);
	init_label(mercury__vn_flush__old_hp_9_0_i20);
	init_label(mercury__vn_flush__old_hp_9_0_i22);
	init_label(mercury__vn_flush__old_hp_9_0_i23);
	init_label(mercury__vn_flush__old_hp_9_0_i24);
	init_label(mercury__vn_flush__old_hp_9_0_i25);
	init_label(mercury__vn_flush__old_hp_9_0_i30);
	init_label(mercury__vn_flush__old_hp_9_0_i35);
	init_label(mercury__vn_flush__old_hp_9_0_i32);
	init_label(mercury__vn_flush__old_hp_9_0_i37);
	init_label(mercury__vn_flush__old_hp_9_0_i38);
	init_label(mercury__vn_flush__old_hp_9_0_i41);
	init_label(mercury__vn_flush__old_hp_9_0_i43);
	init_label(mercury__vn_flush__old_hp_9_0_i36);
	init_label(mercury__vn_flush__old_hp_9_0_i45);
	init_label(mercury__vn_flush__old_hp_9_0_i46);
	init_label(mercury__vn_flush__old_hp_9_0_i49);
	init_label(mercury__vn_flush__old_hp_9_0_i48);
	init_label(mercury__vn_flush__old_hp_9_0_i27);
	init_label(mercury__vn_flush__old_hp_9_0_i52);
	init_label(mercury__vn_flush__old_hp_9_0_i53);
	init_label(mercury__vn_flush__old_hp_9_0_i56);
	init_label(mercury__vn_flush__old_hp_9_0_i1028);
	init_label(mercury__vn_flush__old_hp_9_0_i54);
	init_label(mercury__vn_flush__old_hp_9_0_i57);
	init_label(mercury__vn_flush__old_hp_9_0_i60);
	init_label(mercury__vn_flush__old_hp_9_0_i62);
	init_label(mercury__vn_flush__old_hp_9_0_i63);
	init_label(mercury__vn_flush__old_hp_9_0_i64);
	init_label(mercury__vn_flush__old_hp_9_0_i58);
	init_label(mercury__vn_flush__old_hp_9_0_i66);
	init_label(mercury__vn_flush__old_hp_9_0_i67);
BEGIN_CODE

/* code for predicate 'old_hp'/9 in mode 0 */
Define_static(mercury__vn_flush__old_hp_9_0);
	MR_incr_sp_push_msg(17, "vn_flush:old_hp/9");
	MR_stackvar(17) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 3));
	r2 = (Word) MR_string_const("vn_flush__old_hp", 16);
	MR_stackvar(3) = r3;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r5;
	call_localret(ENTRY(mercury__vn_table__lookup_desired_value_4_0),
		mercury__vn_flush__old_hp_9_0_i2,
		STATIC(mercury__vn_flush__old_hp_9_0));
Define_label(mercury__vn_flush__old_hp_9_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_flush__old_hp_9_0));
	r4 = MR_stackvar(3);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r5 = MR_stackvar(4);
	r6 = MR_stackvar(5);
	MR_stackvar(3) = r1;
	call_localret(STATIC(mercury__vn_flush__hp_incr_10_0),
		mercury__vn_flush__old_hp_9_0_i3,
		STATIC(mercury__vn_flush__old_hp_9_0));
Define_label(mercury__vn_flush__old_hp_9_0_i3);
	update_prof_current_proc(LABEL(mercury__vn_flush__old_hp_9_0));
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i5);
	MR_stackvar(4) = r2;
	MR_stackvar(6) = r3;
	MR_stackvar(7) = r4;
	r1 = (Word) MR_string_const("empty expression for hp increment", 33);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_flush__old_hp_9_0_i6,
		STATIC(mercury__vn_flush__old_hp_9_0));
Define_label(mercury__vn_flush__old_hp_9_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_flush__old_hp_9_0));
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__vn_table__set_current_value_4_0),
		mercury__vn_flush__old_hp_9_0_i18,
		STATIC(mercury__vn_flush__old_hp_9_0));
Define_label(mercury__vn_flush__old_hp_9_0_i5);
	MR_stackvar(8) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_stackvar(5);
	MR_stackvar(4) = r2;
	MR_stackvar(6) = r3;
	MR_stackvar(7) = r4;
	call_localret(ENTRY(mercury__vn_type__bytes_per_word_2_0),
		mercury__vn_flush__old_hp_9_0_i7,
		STATIC(mercury__vn_flush__old_hp_9_0));
Define_label(mercury__vn_flush__old_hp_9_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_flush__old_hp_9_0));
	if ((MR_tag(MR_stackvar(8)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i8);
	if (((Integer) MR_const_field(MR_mktag(3), MR_stackvar(8), (Integer) 0) != (Integer) 1))
		GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i8);
	r2 = MR_const_field(MR_mktag(3), MR_stackvar(8), (Integer) 1);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i8);
	r3 = MR_stackvar(4);
	r4 = r2;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__vn_flush__old_hp_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	r2 = MR_stackvar(3);
	MR_stackvar(8) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__vn_flush__old_hp_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_stackvar(8), (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = ((Integer) MR_const_field(MR_mktag(1), r4, (Integer) 0) / (Integer) r1);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 3));
	call_localret(ENTRY(mercury__vn_table__set_current_value_4_0),
		mercury__vn_flush__old_hp_9_0_i18,
		STATIC(mercury__vn_flush__old_hp_9_0));
	}
Define_label(mercury__vn_flush__old_hp_9_0_i8);
	if ((MR_tag(MR_stackvar(8)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i11);
	if (((Integer) MR_const_field(MR_mktag(3), MR_stackvar(8), (Integer) 0) != (Integer) 3))
		GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i11);
	r2 = MR_const_field(MR_mktag(3), MR_stackvar(8), (Integer) 1);
	if (((Integer) r2 != (Integer) 2))
		GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i11);
	r2 = MR_const_field(MR_mktag(3), MR_stackvar(8), (Integer) 3);
	if ((MR_tag(r2) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i11);
	if (((Integer) MR_const_field(MR_mktag(3), r2, (Integer) 0) != (Integer) 1))
		GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i11);
	if ((MR_tag(MR_const_field(MR_mktag(3), r2, (Integer) 1)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i11);
	if ((r1 != MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(3), r2, (Integer) 1), (Integer) 0)))
		GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i11);
	MR_stackvar(8) = MR_const_field(MR_mktag(3), MR_stackvar(8), (Integer) 2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 3));
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__vn_table__set_current_value_4_0),
		mercury__vn_flush__old_hp_9_0_i18,
		STATIC(mercury__vn_flush__old_hp_9_0));
Define_label(mercury__vn_flush__old_hp_9_0_i11);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(8);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 4, mercury__vn_flush__old_hp_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = r4;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = (Integer) 3;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 3;
	MR_stackvar(8) = MR_tempr1;
	tag_incr_hp_msg(r5, MR_mktag(3), (Integer) 2, mercury__vn_flush__old_hp_9_0, "llds:rval/0");
	MR_field(MR_mktag(3), r5, (Integer) 0) = (Integer) 1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__vn_flush__old_hp_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r5, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 3));
	MR_field(MR_mktag(3), MR_stackvar(8), (Integer) 3) = r5;
	call_localret(ENTRY(mercury__vn_table__set_current_value_4_0),
		mercury__vn_flush__old_hp_9_0_i18,
		STATIC(mercury__vn_flush__old_hp_9_0));
	}
Define_label(mercury__vn_flush__old_hp_9_0_i18);
	update_prof_current_proc(LABEL(mercury__vn_flush__old_hp_9_0));
	r3 = r1;
	MR_stackvar(9) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_flush__common_5);
	r2 = (Word) MR_string_const("vn_flush__old_hp", 16);
	call_localret(ENTRY(mercury__vn_table__lookup_assigned_vn_4_0),
		mercury__vn_flush__old_hp_9_0_i19,
		STATIC(mercury__vn_flush__old_hp_9_0));
Define_label(mercury__vn_flush__old_hp_9_0_i19);
	update_prof_current_proc(LABEL(mercury__vn_flush__old_hp_9_0));
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(1);
	if (((Integer) MR_tempr1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i20);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 1);
	r2 = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	r3 = MR_stackvar(9);
	GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i23);
	}
Define_label(mercury__vn_flush__old_hp_9_0_i20);
	MR_stackvar(10) = r1;
	r1 = (Word) MR_string_const("empty src list in vn_flush__old_hp", 34);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_flush__old_hp_9_0_i22,
		STATIC(mercury__vn_flush__old_hp_9_0));
Define_label(mercury__vn_flush__old_hp_9_0_i22);
	update_prof_current_proc(LABEL(mercury__vn_flush__old_hp_9_0));
	r3 = MR_stackvar(9);
	r1 = MR_stackvar(10);
	r2 = MR_stackvar(1);
Define_label(mercury__vn_flush__old_hp_9_0_i23);
	MR_stackvar(9) = r3;
	MR_stackvar(10) = r1;
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__vn_table__del_old_use_4_0),
		mercury__vn_flush__old_hp_9_0_i24,
		STATIC(mercury__vn_flush__old_hp_9_0));
Define_label(mercury__vn_flush__old_hp_9_0_i24);
	update_prof_current_proc(LABEL(mercury__vn_flush__old_hp_9_0));
	r3 = r1;
	MR_stackvar(11) = r1;
	r1 = MR_stackvar(10);
	r2 = (Word) MR_string_const("vn_flush__old_hp", 16);
	call_localret(ENTRY(mercury__vn_table__lookup_uses_4_0),
		mercury__vn_flush__old_hp_9_0_i25,
		STATIC(mercury__vn_flush__old_hp_9_0));
Define_label(mercury__vn_flush__old_hp_9_0_i25);
	update_prof_current_proc(LABEL(mercury__vn_flush__old_hp_9_0));
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(1);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i27);
	if ((MR_tag(MR_tempr1) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i27);
	r1 = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 0);
	MR_stackvar(1) = r1;
	r2 = (Word) MR_string_const("vn_flush__old_hp", 16);
	r3 = MR_stackvar(11);
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_flush__old_hp_9_0_i30,
		STATIC(mercury__vn_flush__old_hp_9_0));
	}
Define_label(mercury__vn_flush__old_hp_9_0_i30);
	update_prof_current_proc(LABEL(mercury__vn_flush__old_hp_9_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i27);
	if ((MR_stackvar(10) != MR_const_field(MR_mktag(1), r1, (Integer) 1)))
		GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i27);
	r2 = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__vn_flush__old_hp_9_0, "std_util:maybe/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	if (((Integer) MR_stackvar(3) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i32);
	if ((MR_tag(MR_const_field(MR_mktag(1), MR_stackvar(3), (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i32);
	MR_stackvar(12) = r3;
	MR_stackvar(13) = r2;
	r1 = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), MR_stackvar(3), (Integer) 0), (Integer) 0);
	MR_stackvar(14) = r1;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(11);
	r5 = MR_stackvar(6);
	r6 = MR_stackvar(5);
	call_localret(STATIC(mercury__vn_flush__access_path_10_0),
		mercury__vn_flush__old_hp_9_0_i35,
		STATIC(mercury__vn_flush__old_hp_9_0));
Define_label(mercury__vn_flush__old_hp_9_0_i35);
	update_prof_current_proc(LABEL(mercury__vn_flush__old_hp_9_0));
	MR_stackvar(15) = r1;
	r1 = MR_stackvar(14);
	r2 = MR_stackvar(11);
	MR_stackvar(1) = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_vn_flush__common_7);
	MR_stackvar(16) = MR_stackvar(6);
	GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i57);
Define_label(mercury__vn_flush__old_hp_9_0_i32);
	MR_stackvar(13) = r2;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(11);
	MR_stackvar(12) = r3;
	call_localret(STATIC(mercury__vn_flush__find_cheap_users_3_0),
		mercury__vn_flush__old_hp_9_0_i37,
		STATIC(mercury__vn_flush__old_hp_9_0));
Define_label(mercury__vn_flush__old_hp_9_0_i37);
	update_prof_current_proc(LABEL(mercury__vn_flush__old_hp_9_0));
	call_localret(ENTRY(mercury__vn_util__choose_cheapest_loc_2_0),
		mercury__vn_flush__old_hp_9_0_i38,
		STATIC(mercury__vn_flush__old_hp_9_0));
Define_label(mercury__vn_flush__old_hp_9_0_i38);
	update_prof_current_proc(LABEL(mercury__vn_flush__old_hp_9_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i36);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i36);
	MR_stackvar(14) = r2;
	r1 = r2;
	call_localret(ENTRY(mercury__vn_util__no_access_vnlval_to_lval_2_0),
		mercury__vn_flush__old_hp_9_0_i41,
		STATIC(mercury__vn_flush__old_hp_9_0));
Define_label(mercury__vn_flush__old_hp_9_0_i41);
	update_prof_current_proc(LABEL(mercury__vn_flush__old_hp_9_0));
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i43);
	r1 = (Word) MR_string_const("register needs access path", 26);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_flush__old_hp_9_0_i49,
		STATIC(mercury__vn_flush__old_hp_9_0));
Define_label(mercury__vn_flush__old_hp_9_0_i43);
	MR_stackvar(15) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_stackvar(14);
	r2 = MR_stackvar(11);
	MR_stackvar(1) = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_vn_flush__common_7);
	MR_stackvar(16) = MR_stackvar(6);
	GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i57);
Define_label(mercury__vn_flush__old_hp_9_0_i36);
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__vn_temploc__next_tempr_3_0),
		mercury__vn_flush__old_hp_9_0_i45,
		STATIC(mercury__vn_flush__old_hp_9_0));
Define_label(mercury__vn_flush__old_hp_9_0_i45);
	update_prof_current_proc(LABEL(mercury__vn_flush__old_hp_9_0));
	MR_stackvar(16) = r1;
	r1 = r2;
	MR_stackvar(14) = r2;
	call_localret(ENTRY(mercury__vn_util__no_access_vnlval_to_lval_2_0),
		mercury__vn_flush__old_hp_9_0_i46,
		STATIC(mercury__vn_flush__old_hp_9_0));
Define_label(mercury__vn_flush__old_hp_9_0_i46);
	update_prof_current_proc(LABEL(mercury__vn_flush__old_hp_9_0));
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i48);
	r1 = (Word) MR_string_const("temploc needs access path", 25);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_flush__old_hp_9_0_i49,
		STATIC(mercury__vn_flush__old_hp_9_0));
Define_label(mercury__vn_flush__old_hp_9_0_i49);
	update_prof_current_proc(LABEL(mercury__vn_flush__old_hp_9_0));
	r2 = MR_stackvar(11);
	r1 = MR_stackvar(14);
	GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i57);
Define_label(mercury__vn_flush__old_hp_9_0_i48);
	MR_stackvar(15) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_stackvar(14);
	r2 = MR_stackvar(11);
	MR_stackvar(1) = (Word) MR_mkword(MR_mktag(3), (Word *) &mercury_data_vn_flush__common_7);
	GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i57);
Define_label(mercury__vn_flush__old_hp_9_0_i27);
	MR_stackvar(13) = MR_stackvar(10);
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__vn_temploc__next_tempr_3_0),
		mercury__vn_flush__old_hp_9_0_i52,
		STATIC(mercury__vn_flush__old_hp_9_0));
Define_label(mercury__vn_flush__old_hp_9_0_i52);
	update_prof_current_proc(LABEL(mercury__vn_flush__old_hp_9_0));
	MR_stackvar(16) = r1;
	r1 = r2;
	MR_stackvar(14) = r2;
	call_localret(ENTRY(mercury__vn_util__no_access_vnlval_to_lval_2_0),
		mercury__vn_flush__old_hp_9_0_i53,
		STATIC(mercury__vn_flush__old_hp_9_0));
Define_label(mercury__vn_flush__old_hp_9_0_i53);
	update_prof_current_proc(LABEL(mercury__vn_flush__old_hp_9_0));
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i1028);
	r1 = (Word) MR_string_const("temploc needs access path", 25);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_flush__old_hp_9_0_i56,
		STATIC(mercury__vn_flush__old_hp_9_0));
Define_label(mercury__vn_flush__old_hp_9_0_i56);
	update_prof_current_proc(LABEL(mercury__vn_flush__old_hp_9_0));
	r2 = MR_stackvar(11);
	r1 = MR_stackvar(14);
	GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i54);
Define_label(mercury__vn_flush__old_hp_9_0_i1028);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_stackvar(11);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(0), (Integer) 1, mercury__vn_flush__old_hp_9_0, "origin_lost_in_value_number");
	MR_stackvar(15) = r3;
	MR_field(MR_mktag(0), MR_tempr1, (Integer) 0) = r3;
	r1 = MR_stackvar(14);
	MR_stackvar(1) = MR_tempr1;
	}
Define_label(mercury__vn_flush__old_hp_9_0_i54);
	MR_stackvar(12) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
Define_label(mercury__vn_flush__old_hp_9_0_i57);
	MR_stackvar(11) = r2;
	MR_stackvar(14) = r1;
	call_localret(ENTRY(mercury__vn_table__search_current_value_3_0),
		mercury__vn_flush__old_hp_9_0_i60,
		STATIC(mercury__vn_flush__old_hp_9_0));
Define_label(mercury__vn_flush__old_hp_9_0_i60);
	update_prof_current_proc(LABEL(mercury__vn_flush__old_hp_9_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_flush__old_hp_9_0_i58);
	MR_stackvar(3) = r2;
	r1 = MR_stackvar(8);
	call_localret(ENTRY(mercury__vn_util__find_lvals_in_rval_2_0),
		mercury__vn_flush__old_hp_9_0_i62,
		STATIC(mercury__vn_flush__old_hp_9_0));
Define_label(mercury__vn_flush__old_hp_9_0_i62);
	update_prof_current_proc(LABEL(mercury__vn_flush__old_hp_9_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_lval_0;
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__vn_flush__old_hp_9_0_i63,
		STATIC(mercury__vn_flush__old_hp_9_0));
Define_label(mercury__vn_flush__old_hp_9_0_i63);
	update_prof_current_proc(LABEL(mercury__vn_flush__old_hp_9_0));
	r4 = r1;
	r1 = MR_stackvar(14);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(13);
	r5 = MR_stackvar(11);
	r6 = MR_stackvar(16);
	r7 = MR_stackvar(5);
	call_localret(STATIC(mercury__vn_flush__maybe_save_prev_value_10_0),
		mercury__vn_flush__old_hp_9_0_i64,
		STATIC(mercury__vn_flush__old_hp_9_0));
Define_label(mercury__vn_flush__old_hp_9_0_i64);
	update_prof_current_proc(LABEL(mercury__vn_flush__old_hp_9_0));
	MR_stackvar(3) = r3;
	r3 = r1;
	MR_stackvar(4) = r2;
	r1 = MR_stackvar(14);
	r2 = MR_stackvar(13);
	call_localret(ENTRY(mercury__vn_table__set_current_value_4_0),
		mercury__vn_flush__old_hp_9_0_i66,
		STATIC(mercury__vn_flush__old_hp_9_0));
Define_label(mercury__vn_flush__old_hp_9_0_i58);
	r1 = MR_stackvar(14);
	MR_stackvar(4) = MR_stackvar(16);
	r2 = MR_stackvar(13);
	r3 = MR_stackvar(9);
	MR_stackvar(3) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__vn_table__set_current_value_4_0),
		mercury__vn_flush__old_hp_9_0_i66,
		STATIC(mercury__vn_flush__old_hp_9_0));
Define_label(mercury__vn_flush__old_hp_9_0_i66);
	update_prof_current_proc(LABEL(mercury__vn_flush__old_hp_9_0));
	r4 = MR_stackvar(3);
	MR_stackvar(3) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_flush__common_0);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__vn_flush__old_hp_9_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(7);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__vn_flush__old_hp_9_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = r4;
	tag_incr_hp_msg(r6, MR_mktag(1), (Integer) 2, mercury__vn_flush__old_hp_9_0, "list:list/1");
	tag_incr_hp_msg(r7, MR_mktag(1), (Integer) 2, mercury__vn_flush__old_hp_9_0, "list:list/1");
	tag_incr_hp_msg(r8, MR_mktag(0), (Integer) 2, mercury__vn_flush__old_hp_9_0, "std_util:pair/2");
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 5, mercury__vn_flush__old_hp_9_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r8, (Integer) 0) = r3;
	MR_field(MR_mktag(3), r3, (Integer) 4) = (Word) MR_string_const("origin_lost_in_value_number", 27);
	MR_field(MR_mktag(3), r3, (Integer) 3) = MR_stackvar(8);
	MR_field(MR_mktag(3), r3, (Integer) 2) = MR_stackvar(12);
	MR_field(MR_mktag(3), r3, (Integer) 1) = MR_stackvar(15);
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 9;
	MR_field(MR_mktag(1), r2, (Integer) 1) = r5;
	MR_field(MR_mktag(1), r5, (Integer) 1) = r6;
	MR_field(MR_mktag(1), r6, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r6, (Integer) 0) = r7;
	MR_field(MR_mktag(1), r7, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r7, (Integer) 0) = r8;
	MR_field(MR_mktag(0), r8, (Integer) 1) = (Word) MR_string_const("", 0);
	call_localret(ENTRY(mercury__list__condense_2_0),
		mercury__vn_flush__old_hp_9_0_i67,
		STATIC(mercury__vn_flush__old_hp_9_0));
Define_label(mercury__vn_flush__old_hp_9_0_i67);
	update_prof_current_proc(LABEL(mercury__vn_flush__old_hp_9_0));
	r4 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(17);
	MR_decr_sp_pop_msg(17);
	proceed();
END_MODULE

Declare_entry(mercury__vn_util__find_sub_vns_2_0);

BEGIN_MODULE(vn_flush_module13)
	init_entry(mercury__vn_flush__hp_incr_10_0);
	init_label(mercury__vn_flush__hp_incr_10_0_i3);
	init_label(mercury__vn_flush__hp_incr_10_0_i4);
	init_label(mercury__vn_flush__hp_incr_10_0_i5);
	init_label(mercury__vn_flush__hp_incr_10_0_i6);
	init_label(mercury__vn_flush__hp_incr_10_0_i7);
	init_label(mercury__vn_flush__hp_incr_10_0_i10);
	init_label(mercury__vn_flush__hp_incr_10_0_i12);
	init_label(mercury__vn_flush__hp_incr_10_0_i2);
	init_label(mercury__vn_flush__hp_incr_10_0_i13);
	init_label(mercury__vn_flush__hp_incr_10_0_i16);
	init_label(mercury__vn_flush__hp_incr_10_0_i17);
	init_label(mercury__vn_flush__hp_incr_10_0_i21);
	init_label(mercury__vn_flush__hp_incr_10_0_i23);
	init_label(mercury__vn_flush__hp_incr_10_0_i24);
	init_label(mercury__vn_flush__hp_incr_10_0_i28);
	init_label(mercury__vn_flush__hp_incr_10_0_i29);
	init_label(mercury__vn_flush__hp_incr_10_0_i31);
	init_label(mercury__vn_flush__hp_incr_10_0_i33);
	init_label(mercury__vn_flush__hp_incr_10_0_i34);
	init_label(mercury__vn_flush__hp_incr_10_0_i35);
	init_label(mercury__vn_flush__hp_incr_10_0_i36);
	init_label(mercury__vn_flush__hp_incr_10_0_i40);
	init_label(mercury__vn_flush__hp_incr_10_0_i42);
	init_label(mercury__vn_flush__hp_incr_10_0_i38);
	init_label(mercury__vn_flush__hp_incr_10_0_i48);
	init_label(mercury__vn_flush__hp_incr_10_0_i47);
	init_label(mercury__vn_flush__hp_incr_10_0_i52);
	init_label(mercury__vn_flush__hp_incr_10_0_i54);
	init_label(mercury__vn_flush__hp_incr_10_0_i56);
	init_label(mercury__vn_flush__hp_incr_10_0_i57);
	init_label(mercury__vn_flush__hp_incr_10_0_i14);
	init_label(mercury__vn_flush__hp_incr_10_0_i58);
	init_label(mercury__vn_flush__hp_incr_10_0_i60);
	init_label(mercury__vn_flush__hp_incr_10_0_i62);
BEGIN_CODE

/* code for predicate 'hp_incr'/10 in mode 0 */
Define_static(mercury__vn_flush__hp_incr_10_0);
	MR_incr_sp_push_msg(8, "vn_flush:hp_incr/10");
	MR_stackvar(8) = (Word) MR_succip;
	MR_stackvar(3) = r3;
	MR_stackvar(2) = r2;
	r2 = (Word) MR_string_const("vn_flush__rec_find_ref_vns", 26);
	r3 = r4;
	MR_stackvar(1) = r1;
	MR_stackvar(4) = r4;
	MR_stackvar(5) = r5;
	MR_stackvar(6) = r6;
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_flush__hp_incr_10_0_i3,
		STATIC(mercury__vn_flush__hp_incr_10_0));
Define_label(mercury__vn_flush__hp_incr_10_0_i3);
	update_prof_current_proc(LABEL(mercury__vn_flush__hp_incr_10_0));
	call_localret(ENTRY(mercury__vn_util__find_sub_vns_2_0),
		mercury__vn_flush__hp_incr_10_0_i4,
		STATIC(mercury__vn_flush__hp_incr_10_0));
Define_label(mercury__vn_flush__hp_incr_10_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_flush__hp_incr_10_0));
	r2 = MR_stackvar(4);
	call_localret(STATIC(mercury__vn_flush__rec_find_ref_vns_list_3_0),
		mercury__vn_flush__hp_incr_10_0_i5,
		STATIC(mercury__vn_flush__hp_incr_10_0));
Define_label(mercury__vn_flush__hp_incr_10_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_flush__hp_incr_10_0));
	MR_stackvar(7) = r1;
	r1 = MR_stackvar(1);
	r2 = (Word) MR_string_const("vn_flush__free_of_old_hp", 24);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_flush__hp_incr_10_0_i6,
		STATIC(mercury__vn_flush__hp_incr_10_0));
Define_label(mercury__vn_flush__hp_incr_10_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_flush__hp_incr_10_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__vn_flush__hp_incr_10_0_i7);
	if (((Integer) MR_const_field(MR_mktag(0), r1, (Integer) 0) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 3))))
		GOTO_LABEL(mercury__vn_flush__hp_incr_10_0_i2);
Define_label(mercury__vn_flush__hp_incr_10_0_i7);
	r1 = MR_stackvar(7);
	r2 = MR_stackvar(4);
	call_localret(STATIC(mercury__vn_flush__free_of_old_hp_2_0),
		mercury__vn_flush__hp_incr_10_0_i10,
		STATIC(mercury__vn_flush__hp_incr_10_0));
Define_label(mercury__vn_flush__hp_incr_10_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_flush__hp_incr_10_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_flush__hp_incr_10_0_i2);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	r5 = MR_stackvar(5);
	r6 = MR_stackvar(6);
	call_localret(STATIC(mercury__vn_flush__vn_10_0),
		mercury__vn_flush__hp_incr_10_0_i12,
		STATIC(mercury__vn_flush__hp_incr_10_0));
Define_label(mercury__vn_flush__hp_incr_10_0_i12);
	update_prof_current_proc(LABEL(mercury__vn_flush__hp_incr_10_0));
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__vn_flush__hp_incr_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r1;
	r1 = MR_tempr1;
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
	}
Define_label(mercury__vn_flush__hp_incr_10_0_i2);
	r1 = MR_stackvar(1);
	r2 = (Word) MR_string_const("vn_flush__hp_incr", 17);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_flush__hp_incr_10_0_i13,
		STATIC(mercury__vn_flush__hp_incr_10_0));
Define_label(mercury__vn_flush__hp_incr_10_0_i13);
	update_prof_current_proc(LABEL(mercury__vn_flush__hp_incr_10_0));
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__vn_flush__hp_incr_10_0_i16) AND
		LABEL(mercury__vn_flush__hp_incr_10_0_i21) AND
		LABEL(mercury__vn_flush__hp_incr_10_0_i23) AND
		LABEL(mercury__vn_flush__hp_incr_10_0_i28));
Define_label(mercury__vn_flush__hp_incr_10_0_i16);
	if (((Integer) MR_const_field(MR_mktag(0), r1, (Integer) 0) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 3))))
		GOTO_LABEL(mercury__vn_flush__hp_incr_10_0_i17);
	r1 = MR_stackvar(1);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_stackvar(3) = MR_stackvar(5);
	r3 = MR_stackvar(4);
	MR_stackvar(4) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	GOTO_LABEL(mercury__vn_flush__hp_incr_10_0_i14);
Define_label(mercury__vn_flush__hp_incr_10_0_i17);
	r1 = (Word) MR_string_const("non-hp origlval in flush_hp_incr", 32);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_flush__hp_incr_10_0_i57,
		STATIC(mercury__vn_flush__hp_incr_10_0));
Define_label(mercury__vn_flush__hp_incr_10_0_i21);
	r1 = (Word) MR_string_const("mkword in calculation of new hp", 31);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_flush__hp_incr_10_0_i57,
		STATIC(mercury__vn_flush__hp_incr_10_0));
Define_label(mercury__vn_flush__hp_incr_10_0_i23);
	r2 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_flush__hp_incr_10_0_i24);
	r3 = r1;
	r1 = MR_stackvar(1);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__vn_flush__hp_incr_10_0, "std_util:maybe/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 2, mercury__vn_flush__hp_incr_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_const_field(MR_mktag(2), r3, (Integer) 0);
	MR_stackvar(3) = MR_stackvar(5);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 1;
	r3 = MR_stackvar(4);
	MR_stackvar(4) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_tempr1;
	GOTO_LABEL(mercury__vn_flush__hp_incr_10_0_i14);
	}
Define_label(mercury__vn_flush__hp_incr_10_0_i24);
	r1 = (Word) MR_string_const("non-int const in flush_hp_incr", 30);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_flush__hp_incr_10_0_i57,
		STATIC(mercury__vn_flush__hp_incr_10_0));
Define_label(mercury__vn_flush__hp_incr_10_0_i28);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__vn_flush__hp_incr_10_0_i29) AND
		LABEL(mercury__vn_flush__hp_incr_10_0_i31) AND
		LABEL(mercury__vn_flush__hp_incr_10_0_i33) AND
		LABEL(mercury__vn_flush__hp_incr_10_0_i52) AND
		LABEL(mercury__vn_flush__hp_incr_10_0_i54) AND
		LABEL(mercury__vn_flush__hp_incr_10_0_i56));
Define_label(mercury__vn_flush__hp_incr_10_0_i29);
	r1 = (Word) MR_string_const("create in calculation of new hp", 31);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_flush__hp_incr_10_0_i57,
		STATIC(mercury__vn_flush__hp_incr_10_0));
Define_label(mercury__vn_flush__hp_incr_10_0_i31);
	r1 = (Word) MR_string_const("unop in calculation of new hp", 29);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_flush__hp_incr_10_0_i57,
		STATIC(mercury__vn_flush__hp_incr_10_0));
Define_label(mercury__vn_flush__hp_incr_10_0_i33);
	r2 = MR_stackvar(4);
	MR_stackvar(4) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r3 = MR_stackvar(5);
	MR_stackvar(5) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	tag_incr_hp_msg(MR_stackvar(7), MR_mktag(1), (Integer) 2, mercury__vn_flush__hp_incr_10_0, "list:list/1");
	r4 = r2;
	{
	Word MR_tempr1, MR_tempr2;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 1, mercury__vn_flush__hp_incr_10_0, "origin_lost_in_value_number");
	r5 = r3;
	MR_tempr2 = MR_stackvar(7);
	MR_field(MR_mktag(1), MR_tempr2, (Integer) 0) = MR_tempr1;
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r2 = MR_tempr2;
	r3 = MR_stackvar(3);
	r6 = MR_stackvar(6);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), MR_tempr2, (Integer) 1) = MR_stackvar(2);
	localcall(mercury__vn_flush__hp_incr_10_0,
		LABEL(mercury__vn_flush__hp_incr_10_0_i34),
		STATIC(mercury__vn_flush__hp_incr_10_0));
	}
Define_label(mercury__vn_flush__hp_incr_10_0_i34);
	update_prof_current_proc(LABEL(mercury__vn_flush__hp_incr_10_0));
	r5 = r3;
	r6 = MR_stackvar(6);
	r3 = MR_stackvar(3);
	MR_stackvar(3) = r4;
	r4 = r2;
	MR_stackvar(6) = r1;
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(7);
	localcall(mercury__vn_flush__hp_incr_10_0,
		LABEL(mercury__vn_flush__hp_incr_10_0_i35),
		STATIC(mercury__vn_flush__hp_incr_10_0));
Define_label(mercury__vn_flush__hp_incr_10_0_i35);
	update_prof_current_proc(LABEL(mercury__vn_flush__hp_incr_10_0));
	MR_stackvar(5) = r2;
	r2 = MR_stackvar(3);
	MR_stackvar(3) = r3;
	MR_stackvar(7) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_flush__common_0);
	r3 = r4;
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__vn_flush__hp_incr_10_0_i36,
		STATIC(mercury__vn_flush__hp_incr_10_0));
Define_label(mercury__vn_flush__hp_incr_10_0_i36);
	update_prof_current_proc(LABEL(mercury__vn_flush__hp_incr_10_0));
	if (((Integer) MR_stackvar(6) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_flush__hp_incr_10_0_i38);
	if (((Integer) MR_stackvar(7) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_flush__hp_incr_10_0_i40);
	MR_stackvar(4) = r1;
	r1 = (Word) MR_string_const("two 'no's in flush_hp_incr", 26);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_flush__hp_incr_10_0_i57,
		STATIC(mercury__vn_flush__hp_incr_10_0));
Define_label(mercury__vn_flush__hp_incr_10_0_i40);
	if (((Integer) MR_stackvar(4) != (Integer) 0))
		GOTO_LABEL(mercury__vn_flush__hp_incr_10_0_i42);
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(7);
	r3 = MR_stackvar(5);
	GOTO_LABEL(mercury__vn_flush__hp_incr_10_0_i14);
Define_label(mercury__vn_flush__hp_incr_10_0_i42);
	MR_stackvar(4) = r1;
	r1 = (Word) MR_string_const("non-+ op on hp", 14);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_flush__hp_incr_10_0_i57,
		STATIC(mercury__vn_flush__hp_incr_10_0));
Define_label(mercury__vn_flush__hp_incr_10_0_i38);
	if (((Integer) MR_stackvar(7) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_flush__hp_incr_10_0_i47);
	if (((Integer) MR_stackvar(4) != (Integer) 0))
		GOTO_LABEL(mercury__vn_flush__hp_incr_10_0_i48);
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(6);
	r3 = MR_stackvar(5);
	GOTO_LABEL(mercury__vn_flush__hp_incr_10_0_i14);
Define_label(mercury__vn_flush__hp_incr_10_0_i48);
	MR_stackvar(4) = r1;
	r1 = (Word) MR_string_const("non-+ op on hp", 14);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_flush__hp_incr_10_0_i57,
		STATIC(mercury__vn_flush__hp_incr_10_0));
Define_label(mercury__vn_flush__hp_incr_10_0_i47);
	r3 = r1;
	r1 = MR_stackvar(1);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__vn_flush__hp_incr_10_0, "std_util:maybe/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 4, mercury__vn_flush__hp_incr_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 3) = MR_const_field(MR_mktag(1), MR_stackvar(7), (Integer) 0);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = MR_const_field(MR_mktag(1), MR_stackvar(6), (Integer) 0);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(4);
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 3;
	MR_stackvar(4) = r3;
	r3 = MR_stackvar(5);
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_tempr1;
	GOTO_LABEL(mercury__vn_flush__hp_incr_10_0_i14);
	}
Define_label(mercury__vn_flush__hp_incr_10_0_i52);
	r1 = (Word) MR_string_const("stackvar_addr in calculation of new hp", 38);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_flush__hp_incr_10_0_i57,
		STATIC(mercury__vn_flush__hp_incr_10_0));
Define_label(mercury__vn_flush__hp_incr_10_0_i54);
	r1 = (Word) MR_string_const("framevar_addr in calculation of new hp", 38);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_flush__hp_incr_10_0_i57,
		STATIC(mercury__vn_flush__hp_incr_10_0));
Define_label(mercury__vn_flush__hp_incr_10_0_i56);
	r1 = (Word) MR_string_const("heap_addr in calculation of new hp", 34);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_flush__hp_incr_10_0_i57,
		STATIC(mercury__vn_flush__hp_incr_10_0));
Define_label(mercury__vn_flush__hp_incr_10_0_i57);
	update_prof_current_proc(LABEL(mercury__vn_flush__hp_incr_10_0));
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(5);
Define_label(mercury__vn_flush__hp_incr_10_0_i14);
	if (((Integer) MR_stackvar(2) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_flush__hp_incr_10_0_i58);
	{
	Word MR_tempr1;
	MR_tempr1 = r2;
	r2 = MR_const_field(MR_mktag(1), MR_stackvar(2), (Integer) 0);
	MR_stackvar(2) = MR_tempr1;
	call_localret(ENTRY(mercury__vn_table__del_old_use_4_0),
		mercury__vn_flush__hp_incr_10_0_i62,
		STATIC(mercury__vn_flush__hp_incr_10_0));
	}
Define_label(mercury__vn_flush__hp_incr_10_0_i58);
	MR_stackvar(1) = r1;
	r1 = (Word) MR_string_const("empty source list in flush_vn", 29);
	MR_stackvar(2) = r2;
	MR_stackvar(5) = r3;
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_flush__hp_incr_10_0_i60,
		STATIC(mercury__vn_flush__hp_incr_10_0));
Define_label(mercury__vn_flush__hp_incr_10_0_i60);
	update_prof_current_proc(LABEL(mercury__vn_flush__hp_incr_10_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	r3 = MR_stackvar(5);
	call_localret(ENTRY(mercury__vn_table__del_old_use_4_0),
		mercury__vn_flush__hp_incr_10_0_i62,
		STATIC(mercury__vn_flush__hp_incr_10_0));
Define_label(mercury__vn_flush__hp_incr_10_0_i62);
	update_prof_current_proc(LABEL(mercury__vn_flush__hp_incr_10_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
END_MODULE


BEGIN_MODULE(vn_flush_module14)
	init_entry(mercury__vn_flush__free_of_old_hp_2_0);
	init_label(mercury__vn_flush__free_of_old_hp_2_0_i1002);
	init_label(mercury__vn_flush__free_of_old_hp_2_0_i4);
	init_label(mercury__vn_flush__free_of_old_hp_2_0_i5);
	init_label(mercury__vn_flush__free_of_old_hp_2_0_i2);
	init_label(mercury__vn_flush__free_of_old_hp_2_0_i1);
BEGIN_CODE

/* code for predicate 'free_of_old_hp'/2 in mode 0 */
Define_static(mercury__vn_flush__free_of_old_hp_2_0);
	MR_incr_sp_push_msg(3, "vn_flush:free_of_old_hp/2");
	MR_stackvar(3) = (Word) MR_succip;
Define_label(mercury__vn_flush__free_of_old_hp_2_0_i1002);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_flush__free_of_old_hp_2_0_i2);
	r3 = r2;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = (Word) MR_string_const("vn_flush__free_of_old_hp", 24);
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_flush__free_of_old_hp_2_0_i4,
		STATIC(mercury__vn_flush__free_of_old_hp_2_0));
Define_label(mercury__vn_flush__free_of_old_hp_2_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_flush__free_of_old_hp_2_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__vn_flush__free_of_old_hp_2_0_i5);
	if (((Integer) MR_const_field(MR_mktag(0), r1, (Integer) 0) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 3))))
		GOTO_LABEL(mercury__vn_flush__free_of_old_hp_2_0_i1);
Define_label(mercury__vn_flush__free_of_old_hp_2_0_i5);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	GOTO_LABEL(mercury__vn_flush__free_of_old_hp_2_0_i1002);
Define_label(mercury__vn_flush__free_of_old_hp_2_0_i2);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_flush__free_of_old_hp_2_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(vn_flush_module15)
	init_entry(mercury__vn_flush__rec_find_ref_vns_list_3_0);
	init_label(mercury__vn_flush__rec_find_ref_vns_list_3_0_i3);
	init_label(mercury__vn_flush__rec_find_ref_vns_list_3_0_i4);
	init_label(mercury__vn_flush__rec_find_ref_vns_list_3_0_i5);
	init_label(mercury__vn_flush__rec_find_ref_vns_list_3_0_i6);
	init_label(mercury__vn_flush__rec_find_ref_vns_list_3_0_i7);
BEGIN_CODE

/* code for predicate 'rec_find_ref_vns_list'/3 in mode 0 */
Define_static(mercury__vn_flush__rec_find_ref_vns_list_3_0);
	MR_incr_sp_push_msg(4, "vn_flush:rec_find_ref_vns_list/3");
	MR_stackvar(4) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_flush__rec_find_ref_vns_list_3_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__vn_flush__rec_find_ref_vns_list_3_0_i3);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r3 = r2;
	MR_stackvar(1) = r2;
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(2) = r1;
	r2 = (Word) MR_string_const("vn_flush__rec_find_ref_vns", 26);
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_flush__rec_find_ref_vns_list_3_0_i4,
		STATIC(mercury__vn_flush__rec_find_ref_vns_list_3_0));
Define_label(mercury__vn_flush__rec_find_ref_vns_list_3_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_flush__rec_find_ref_vns_list_3_0));
	call_localret(ENTRY(mercury__vn_util__find_sub_vns_2_0),
		mercury__vn_flush__rec_find_ref_vns_list_3_0_i5,
		STATIC(mercury__vn_flush__rec_find_ref_vns_list_3_0));
Define_label(mercury__vn_flush__rec_find_ref_vns_list_3_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_flush__rec_find_ref_vns_list_3_0));
	r2 = MR_stackvar(1);
	localcall(mercury__vn_flush__rec_find_ref_vns_list_3_0,
		LABEL(mercury__vn_flush__rec_find_ref_vns_list_3_0_i6),
		STATIC(mercury__vn_flush__rec_find_ref_vns_list_3_0));
Define_label(mercury__vn_flush__rec_find_ref_vns_list_3_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_flush__rec_find_ref_vns_list_3_0));
	r2 = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__vn_flush__rec_find_ref_vns_list_3_0, "origin_lost_in_value_number");
	MR_stackvar(1) = r3;
	MR_field(MR_mktag(1), r3, (Integer) 1) = r1;
	r1 = MR_stackvar(3);
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(2);
	localcall(mercury__vn_flush__rec_find_ref_vns_list_3_0,
		LABEL(mercury__vn_flush__rec_find_ref_vns_list_3_0_i7),
		STATIC(mercury__vn_flush__rec_find_ref_vns_list_3_0));
Define_label(mercury__vn_flush__rec_find_ref_vns_list_3_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_flush__rec_find_ref_vns_list_3_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(ENTRY(mercury__list__append_3_1),
		STATIC(mercury__vn_flush__rec_find_ref_vns_list_3_0));
END_MODULE


BEGIN_MODULE(vn_flush_module16)
	init_entry(mercury__vn_flush__access_path_10_0);
	init_label(mercury__vn_flush__access_path_10_0_i4);
	init_label(mercury__vn_flush__access_path_10_0_i5);
	init_label(mercury__vn_flush__access_path_10_0_i6);
	init_label(mercury__vn_flush__access_path_10_0_i7);
	init_label(mercury__vn_flush__access_path_10_0_i8);
	init_label(mercury__vn_flush__access_path_10_0_i9);
	init_label(mercury__vn_flush__access_path_10_0_i1026);
	init_label(mercury__vn_flush__access_path_10_0_i11);
	init_label(mercury__vn_flush__access_path_10_0_i12);
	init_label(mercury__vn_flush__access_path_10_0_i13);
	init_label(mercury__vn_flush__access_path_10_0_i14);
	init_label(mercury__vn_flush__access_path_10_0_i15);
	init_label(mercury__vn_flush__access_path_10_0_i16);
	init_label(mercury__vn_flush__access_path_10_0_i17);
	init_label(mercury__vn_flush__access_path_10_0_i18);
	init_label(mercury__vn_flush__access_path_10_0_i19);
	init_label(mercury__vn_flush__access_path_10_0_i20);
	init_label(mercury__vn_flush__access_path_10_0_i21);
	init_label(mercury__vn_flush__access_path_10_0_i22);
	init_label(mercury__vn_flush__access_path_10_0_i23);
	init_label(mercury__vn_flush__access_path_10_0_i24);
	init_label(mercury__vn_flush__access_path_10_0_i25);
	init_label(mercury__vn_flush__access_path_10_0_i26);
	init_label(mercury__vn_flush__access_path_10_0_i27);
	init_label(mercury__vn_flush__access_path_10_0_i28);
	init_label(mercury__vn_flush__access_path_10_0_i29);
	init_label(mercury__vn_flush__access_path_10_0_i30);
BEGIN_CODE

/* code for predicate 'access_path'/10 in mode 0 */
Define_static(mercury__vn_flush__access_path_10_0);
	MR_incr_sp_push_msg(6, "vn_flush:access_path/10");
	MR_stackvar(6) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__vn_flush__access_path_10_0_i4) AND
		LABEL(mercury__vn_flush__access_path_10_0_i1026) AND
		LABEL(mercury__vn_flush__access_path_10_0_i11) AND
		LABEL(mercury__vn_flush__access_path_10_0_i12));
Define_label(mercury__vn_flush__access_path_10_0_i4);
	COMPUTED_GOTO((Unsigned) MR_unmkbody(r1),
		LABEL(mercury__vn_flush__access_path_10_0_i5) AND
		LABEL(mercury__vn_flush__access_path_10_0_i6) AND
		LABEL(mercury__vn_flush__access_path_10_0_i7) AND
		LABEL(mercury__vn_flush__access_path_10_0_i8) AND
		LABEL(mercury__vn_flush__access_path_10_0_i9));
Define_label(mercury__vn_flush__access_path_10_0_i5);
	r2 = r4;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r3 = r5;
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__vn_flush__access_path_10_0_i6);
	r2 = r4;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1));
	r3 = r5;
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__vn_flush__access_path_10_0_i7);
	r2 = r4;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 2));
	r3 = r5;
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__vn_flush__access_path_10_0_i8);
	r2 = r4;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 3));
	r3 = r5;
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__vn_flush__access_path_10_0_i9);
	r2 = r4;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 4));
	r3 = r5;
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__vn_flush__access_path_10_0_i1026);
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__vn_flush__access_path_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 1);
	r2 = r4;
	r3 = r5;
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_decr_sp_pop_msg(6);
	proceed();
	}
Define_label(mercury__vn_flush__access_path_10_0_i11);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 2, mercury__vn_flush__access_path_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), r1, (Integer) 1) = MR_const_field(MR_mktag(2), r2, (Integer) 1);
	MR_field(MR_mktag(2), r1, (Integer) 0) = MR_const_field(MR_mktag(2), r2, (Integer) 0);
	r2 = r4;
	r3 = r5;
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__vn_flush__access_path_10_0_i12);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__vn_flush__access_path_10_0_i13) AND
		LABEL(mercury__vn_flush__access_path_10_0_i14) AND
		LABEL(mercury__vn_flush__access_path_10_0_i15) AND
		LABEL(mercury__vn_flush__access_path_10_0_i17) AND
		LABEL(mercury__vn_flush__access_path_10_0_i19) AND
		LABEL(mercury__vn_flush__access_path_10_0_i21) AND
		LABEL(mercury__vn_flush__access_path_10_0_i23) AND
		LABEL(mercury__vn_flush__access_path_10_0_i25) AND
		LABEL(mercury__vn_flush__access_path_10_0_i29));
Define_label(mercury__vn_flush__access_path_10_0_i13);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__vn_flush__access_path_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	r2 = r4;
	r3 = r5;
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__vn_flush__access_path_10_0_i14);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__vn_flush__access_path_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	r2 = r4;
	r3 = r5;
	r4 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 1;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__vn_flush__access_path_10_0_i15);
	r7 = r1;
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r8 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__vn_flush__access_path_10_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__vn_flush__access_path_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = r7;
	MR_field(MR_mktag(1), r2, (Integer) 1) = r8;
	call_localret(STATIC(mercury__vn_flush__vn_10_0),
		mercury__vn_flush__access_path_10_0_i16,
		STATIC(mercury__vn_flush__access_path_10_0));
	}
Define_label(mercury__vn_flush__access_path_10_0_i16);
	update_prof_current_proc(LABEL(mercury__vn_flush__access_path_10_0));
	r5 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__vn_flush__access_path_10_0, "llds:lval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 5;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r5;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__vn_flush__access_path_10_0_i17);
	r7 = r1;
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r8 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__vn_flush__access_path_10_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__vn_flush__access_path_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = r7;
	MR_field(MR_mktag(1), r2, (Integer) 1) = r8;
	call_localret(STATIC(mercury__vn_flush__vn_10_0),
		mercury__vn_flush__access_path_10_0_i18,
		STATIC(mercury__vn_flush__access_path_10_0));
	}
Define_label(mercury__vn_flush__access_path_10_0_i18);
	update_prof_current_proc(LABEL(mercury__vn_flush__access_path_10_0));
	r5 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__vn_flush__access_path_10_0, "llds:lval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 6;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r5;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__vn_flush__access_path_10_0_i19);
	r7 = r1;
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r8 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__vn_flush__access_path_10_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__vn_flush__access_path_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = r7;
	MR_field(MR_mktag(1), r2, (Integer) 1) = r8;
	call_localret(STATIC(mercury__vn_flush__vn_10_0),
		mercury__vn_flush__access_path_10_0_i20,
		STATIC(mercury__vn_flush__access_path_10_0));
	}
Define_label(mercury__vn_flush__access_path_10_0_i20);
	update_prof_current_proc(LABEL(mercury__vn_flush__access_path_10_0));
	r5 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__vn_flush__access_path_10_0, "llds:lval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r5;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__vn_flush__access_path_10_0_i21);
	r7 = r1;
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r8 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__vn_flush__access_path_10_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__vn_flush__access_path_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = r7;
	MR_field(MR_mktag(1), r2, (Integer) 1) = r8;
	call_localret(STATIC(mercury__vn_flush__vn_10_0),
		mercury__vn_flush__access_path_10_0_i22,
		STATIC(mercury__vn_flush__access_path_10_0));
	}
Define_label(mercury__vn_flush__access_path_10_0_i22);
	update_prof_current_proc(LABEL(mercury__vn_flush__access_path_10_0));
	r5 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__vn_flush__access_path_10_0, "llds:lval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r5;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__vn_flush__access_path_10_0_i23);
	r7 = r1;
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r8 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__vn_flush__access_path_10_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__vn_flush__access_path_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = r7;
	MR_field(MR_mktag(1), r2, (Integer) 1) = r8;
	call_localret(STATIC(mercury__vn_flush__vn_10_0),
		mercury__vn_flush__access_path_10_0_i24,
		STATIC(mercury__vn_flush__access_path_10_0));
	}
Define_label(mercury__vn_flush__access_path_10_0_i24);
	update_prof_current_proc(LABEL(mercury__vn_flush__access_path_10_0));
	r5 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__vn_flush__access_path_10_0, "llds:lval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r5;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__vn_flush__access_path_10_0_i25);
	MR_stackvar(1) = r3;
	MR_stackvar(2) = r6;
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	{
	Word MR_tempr1, MR_tempr2;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__vn_flush__access_path_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = r2;
	MR_stackvar(5) = MR_tempr1;
	tag_incr_hp_msg(MR_tempr2, MR_mktag(2), (Integer) 1, mercury__vn_flush__access_path_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr2, (Integer) 0) = r1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_tempr2;
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r2 = MR_tempr1;
	call_localret(STATIC(mercury__vn_flush__vn_10_0),
		mercury__vn_flush__access_path_10_0_i26,
		STATIC(mercury__vn_flush__access_path_10_0));
	}
Define_label(mercury__vn_flush__access_path_10_0_i26);
	update_prof_current_proc(LABEL(mercury__vn_flush__access_path_10_0));
	r5 = r3;
	r6 = MR_stackvar(2);
	r3 = MR_stackvar(1);
	MR_stackvar(2) = r4;
	r4 = r2;
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(5);
	call_localret(STATIC(mercury__vn_flush__vn_10_0),
		mercury__vn_flush__access_path_10_0_i27,
		STATIC(mercury__vn_flush__access_path_10_0));
Define_label(mercury__vn_flush__access_path_10_0_i27);
	update_prof_current_proc(LABEL(mercury__vn_flush__access_path_10_0));
	r5 = MR_stackvar(1);
	{
	Word MR_tempr1, MR_tempr2;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 4, mercury__vn_flush__access_path_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 1) = MR_stackvar(3);
	MR_tempr2 = r2;
	r2 = MR_stackvar(2);
	MR_stackvar(2) = MR_tempr2;
	MR_stackvar(1) = MR_tempr1;
	MR_stackvar(3) = r3;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 3) = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_flush__common_0);
	r3 = r4;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 2) = r5;
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = (Integer) 7;
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__vn_flush__access_path_10_0_i28,
		STATIC(mercury__vn_flush__access_path_10_0));
	}
Define_label(mercury__vn_flush__access_path_10_0_i28);
	update_prof_current_proc(LABEL(mercury__vn_flush__access_path_10_0));
	r4 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__vn_flush__access_path_10_0_i29);
	r7 = r1;
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r8 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__vn_flush__access_path_10_0, "list:list/1");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__vn_flush__access_path_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = r7;
	MR_field(MR_mktag(1), r2, (Integer) 1) = r8;
	call_localret(STATIC(mercury__vn_flush__vn_10_0),
		mercury__vn_flush__access_path_10_0_i30,
		STATIC(mercury__vn_flush__access_path_10_0));
	}
Define_label(mercury__vn_flush__access_path_10_0_i30);
	update_prof_current_proc(LABEL(mercury__vn_flush__access_path_10_0));
	r5 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__vn_flush__access_path_10_0, "llds:lval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 8;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r5;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE

extern const struct MR_TypeCtorInfo_struct
	mercury_data_vn_type__type_ctor_info_vnlval_0;
Declare_entry(mercury__list__member_2_0);
Declare_entry(mercury__opt_debug__dump_uses_list_2_0);

BEGIN_MODULE(vn_flush_module17)
	init_entry(mercury__vn_flush__maybe_save_prev_value_10_0);
	init_label(mercury__vn_flush__maybe_save_prev_value_10_0_i3);
	init_label(mercury__vn_flush__maybe_save_prev_value_10_0_i4);
	init_label(mercury__vn_flush__maybe_save_prev_value_10_0_i6);
	init_label(mercury__vn_flush__maybe_save_prev_value_10_0_i10);
	init_label(mercury__vn_flush__maybe_save_prev_value_10_0_i11);
	init_label(mercury__vn_flush__maybe_save_prev_value_10_0_i12);
	init_label(mercury__vn_flush__maybe_save_prev_value_10_0_i13);
	init_label(mercury__vn_flush__maybe_save_prev_value_10_0_i18);
	init_label(mercury__vn_flush__maybe_save_prev_value_10_0_i17);
	init_label(mercury__vn_flush__maybe_save_prev_value_10_0_i21);
	init_label(mercury__vn_flush__maybe_save_prev_value_10_0_i22);
	init_label(mercury__vn_flush__maybe_save_prev_value_10_0_i24);
	init_label(mercury__vn_flush__maybe_save_prev_value_10_0_i27);
	init_label(mercury__vn_flush__maybe_save_prev_value_10_0_i28);
	init_label(mercury__vn_flush__maybe_save_prev_value_10_0_i26);
	init_label(mercury__vn_flush__maybe_save_prev_value_10_0_i35);
	init_label(mercury__vn_flush__maybe_save_prev_value_10_0_i37);
	init_label(mercury__vn_flush__maybe_save_prev_value_10_0_i38);
	init_label(mercury__vn_flush__maybe_save_prev_value_10_0_i34);
	init_label(mercury__vn_flush__maybe_save_prev_value_10_0_i50);
	init_label(mercury__vn_flush__maybe_save_prev_value_10_0_i51);
	init_label(mercury__vn_flush__maybe_save_prev_value_10_0_i45);
	init_label(mercury__vn_flush__maybe_save_prev_value_10_0_i15);
	init_label(mercury__vn_flush__maybe_save_prev_value_10_0_i59);
	init_label(mercury__vn_flush__maybe_save_prev_value_10_0_i60);
	init_label(mercury__vn_flush__maybe_save_prev_value_10_0_i61);
	init_label(mercury__vn_flush__maybe_save_prev_value_10_0_i64);
	init_label(mercury__vn_flush__maybe_save_prev_value_10_0_i67);
	init_label(mercury__vn_flush__maybe_save_prev_value_10_0_i68);
	init_label(mercury__vn_flush__maybe_save_prev_value_10_0_i2);
BEGIN_CODE

/* code for predicate 'maybe_save_prev_value'/10 in mode 0 */
Define_static(mercury__vn_flush__maybe_save_prev_value_10_0);
	MR_incr_sp_push_msg(11, "vn_flush:maybe_save_prev_value/10");
	MR_stackvar(11) = (Word) MR_succip;
	MR_stackvar(2) = r2;
	r2 = r3;
	r3 = r5;
	MR_stackvar(1) = r1;
	MR_stackvar(3) = r4;
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r6;
	MR_stackvar(7) = r7;
	call_localret(ENTRY(mercury__vn_table__set_current_value_4_0),
		mercury__vn_flush__maybe_save_prev_value_10_0_i3,
		STATIC(mercury__vn_flush__maybe_save_prev_value_10_0));
Define_label(mercury__vn_flush__maybe_save_prev_value_10_0_i3);
	update_prof_current_proc(LABEL(mercury__vn_flush__maybe_save_prev_value_10_0));
	MR_stackvar(6) = r1;
	r2 = r1;
	r1 = MR_stackvar(2);
	call_localret(ENTRY(mercury__vn_table__search_uses_3_0),
		mercury__vn_flush__maybe_save_prev_value_10_0_i4,
		STATIC(mercury__vn_flush__maybe_save_prev_value_10_0));
Define_label(mercury__vn_flush__maybe_save_prev_value_10_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_flush__maybe_save_prev_value_10_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_flush__maybe_save_prev_value_10_0_i2);
	r1 = r2;
	r2 = MR_stackvar(6);
	call_localret(ENTRY(mercury__vn_util__real_uses_3_0),
		mercury__vn_flush__maybe_save_prev_value_10_0_i6,
		STATIC(mercury__vn_flush__maybe_save_prev_value_10_0));
Define_label(mercury__vn_flush__maybe_save_prev_value_10_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_flush__maybe_save_prev_value_10_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_flush__maybe_save_prev_value_10_0_i2);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_flush__maybe_save_prev_value_10_0_i2);
	MR_stackvar(8) = r2;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(4);
	call_localret(ENTRY(mercury__vn_util__is_const_expr_3_0),
		mercury__vn_flush__maybe_save_prev_value_10_0_i10,
		STATIC(mercury__vn_flush__maybe_save_prev_value_10_0));
Define_label(mercury__vn_flush__maybe_save_prev_value_10_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_flush__maybe_save_prev_value_10_0));
	if (((Integer) 0 != (Integer) r1))
		GOTO_LABEL(mercury__vn_flush__maybe_save_prev_value_10_0_i2);
	r1 = MR_stackvar(2);
	r2 = (Word) MR_string_const("vn_flush__maybe_save_prev_value", 31);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__vn_table__lookup_current_locs_4_0),
		mercury__vn_flush__maybe_save_prev_value_10_0_i11,
		STATIC(mercury__vn_flush__maybe_save_prev_value_10_0));
Define_label(mercury__vn_flush__maybe_save_prev_value_10_0_i11);
	update_prof_current_proc(LABEL(mercury__vn_flush__maybe_save_prev_value_10_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0;
	r3 = MR_stackvar(1);
	call_localret(ENTRY(mercury__list__delete_all_3_1),
		mercury__vn_flush__maybe_save_prev_value_10_0_i12,
		STATIC(mercury__vn_flush__maybe_save_prev_value_10_0));
Define_label(mercury__vn_flush__maybe_save_prev_value_10_0_i12);
	update_prof_current_proc(LABEL(mercury__vn_flush__maybe_save_prev_value_10_0));
	call_localret(STATIC(mercury__vn_flush__no_good_copies_1_0),
		mercury__vn_flush__maybe_save_prev_value_10_0_i13,
		STATIC(mercury__vn_flush__maybe_save_prev_value_10_0));
Define_label(mercury__vn_flush__maybe_save_prev_value_10_0_i13);
	update_prof_current_proc(LABEL(mercury__vn_flush__maybe_save_prev_value_10_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_flush__maybe_save_prev_value_10_0_i2);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(4);
	call_localret(ENTRY(mercury__vn_table__search_uses_3_0),
		mercury__vn_flush__maybe_save_prev_value_10_0_i18,
		STATIC(mercury__vn_flush__maybe_save_prev_value_10_0));
Define_label(mercury__vn_flush__maybe_save_prev_value_10_0_i18);
	update_prof_current_proc(LABEL(mercury__vn_flush__maybe_save_prev_value_10_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_flush__maybe_save_prev_value_10_0_i17);
	r1 = r2;
	r2 = MR_stackvar(4);
	call_localret(STATIC(mercury__vn_flush__find_cheap_users_2_3_0),
		mercury__vn_flush__maybe_save_prev_value_10_0_i21,
		STATIC(mercury__vn_flush__maybe_save_prev_value_10_0));
Define_label(mercury__vn_flush__maybe_save_prev_value_10_0_i17);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
Define_label(mercury__vn_flush__maybe_save_prev_value_10_0_i21);
	update_prof_current_proc(LABEL(mercury__vn_flush__maybe_save_prev_value_10_0));
	call_localret(ENTRY(mercury__vn_util__choose_cheapest_loc_2_0),
		mercury__vn_flush__maybe_save_prev_value_10_0_i22,
		STATIC(mercury__vn_flush__maybe_save_prev_value_10_0));
Define_label(mercury__vn_flush__maybe_save_prev_value_10_0_i22);
	update_prof_current_proc(LABEL(mercury__vn_flush__maybe_save_prev_value_10_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_flush__maybe_save_prev_value_10_0_i15);
	MR_stackvar(9) = r2;
	r1 = r2;
	call_localret(ENTRY(mercury__vn_util__no_access_vnlval_to_lval_2_0),
		mercury__vn_flush__maybe_save_prev_value_10_0_i24,
		STATIC(mercury__vn_flush__maybe_save_prev_value_10_0));
Define_label(mercury__vn_flush__maybe_save_prev_value_10_0_i24);
	update_prof_current_proc(LABEL(mercury__vn_flush__maybe_save_prev_value_10_0));
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_flush__maybe_save_prev_value_10_0_i26);
	r1 = MR_stackvar(2);
	r2 = (Word) MR_string_const("vn_flush__choose_temp", 21);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_flush__maybe_save_prev_value_10_0_i27,
		STATIC(mercury__vn_flush__maybe_save_prev_value_10_0));
Define_label(mercury__vn_flush__maybe_save_prev_value_10_0_i27);
	update_prof_current_proc(LABEL(mercury__vn_flush__maybe_save_prev_value_10_0));
	call_localret(ENTRY(mercury__vn_type__vnrval_type_2_0),
		mercury__vn_flush__maybe_save_prev_value_10_0_i28,
		STATIC(mercury__vn_flush__maybe_save_prev_value_10_0));
Define_label(mercury__vn_flush__maybe_save_prev_value_10_0_i28);
	update_prof_current_proc(LABEL(mercury__vn_flush__maybe_save_prev_value_10_0));
	if (((Integer) r1 != (Integer) 9))
		GOTO_LABEL(mercury__vn_flush__maybe_save_prev_value_10_0_i61);
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__vn_temploc__next_tempf_3_0),
		mercury__vn_flush__maybe_save_prev_value_10_0_i64,
		STATIC(mercury__vn_flush__maybe_save_prev_value_10_0));
Define_label(mercury__vn_flush__maybe_save_prev_value_10_0_i26);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_lval_0;
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__vn_flush__maybe_save_prev_value_10_0_i35,
		STATIC(mercury__vn_flush__maybe_save_prev_value_10_0));
Define_label(mercury__vn_flush__maybe_save_prev_value_10_0_i35);
	update_prof_current_proc(LABEL(mercury__vn_flush__maybe_save_prev_value_10_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_flush__maybe_save_prev_value_10_0_i34);
	r1 = MR_stackvar(2);
	r2 = (Word) MR_string_const("vn_flush__choose_temp", 21);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_flush__maybe_save_prev_value_10_0_i37,
		STATIC(mercury__vn_flush__maybe_save_prev_value_10_0));
Define_label(mercury__vn_flush__maybe_save_prev_value_10_0_i37);
	update_prof_current_proc(LABEL(mercury__vn_flush__maybe_save_prev_value_10_0));
	call_localret(ENTRY(mercury__vn_type__vnrval_type_2_0),
		mercury__vn_flush__maybe_save_prev_value_10_0_i38,
		STATIC(mercury__vn_flush__maybe_save_prev_value_10_0));
Define_label(mercury__vn_flush__maybe_save_prev_value_10_0_i38);
	update_prof_current_proc(LABEL(mercury__vn_flush__maybe_save_prev_value_10_0));
	if (((Integer) r1 != (Integer) 9))
		GOTO_LABEL(mercury__vn_flush__maybe_save_prev_value_10_0_i61);
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__vn_temploc__next_tempf_3_0),
		mercury__vn_flush__maybe_save_prev_value_10_0_i64,
		STATIC(mercury__vn_flush__maybe_save_prev_value_10_0));
Define_label(mercury__vn_flush__maybe_save_prev_value_10_0_i34);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(8);
	if (((Integer) MR_tempr1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_flush__maybe_save_prev_value_10_0_i45);
	if (((Integer) MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_flush__maybe_save_prev_value_10_0_i45);
	if ((MR_tag(MR_stackvar(9)) == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_flush__maybe_save_prev_value_10_0_i45);
	r1 = MR_stackvar(2);
	r2 = (Word) MR_string_const("vn_flush__choose_temp", 21);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_flush__maybe_save_prev_value_10_0_i50,
		STATIC(mercury__vn_flush__maybe_save_prev_value_10_0));
	}
Define_label(mercury__vn_flush__maybe_save_prev_value_10_0_i50);
	update_prof_current_proc(LABEL(mercury__vn_flush__maybe_save_prev_value_10_0));
	call_localret(ENTRY(mercury__vn_type__vnrval_type_2_0),
		mercury__vn_flush__maybe_save_prev_value_10_0_i51,
		STATIC(mercury__vn_flush__maybe_save_prev_value_10_0));
Define_label(mercury__vn_flush__maybe_save_prev_value_10_0_i51);
	update_prof_current_proc(LABEL(mercury__vn_flush__maybe_save_prev_value_10_0));
	if (((Integer) r1 != (Integer) 9))
		GOTO_LABEL(mercury__vn_flush__maybe_save_prev_value_10_0_i61);
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__vn_temploc__next_tempf_3_0),
		mercury__vn_flush__maybe_save_prev_value_10_0_i64,
		STATIC(mercury__vn_flush__maybe_save_prev_value_10_0));
Define_label(mercury__vn_flush__maybe_save_prev_value_10_0_i45);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	r6 = MR_stackvar(7);
	r5 = MR_stackvar(5);
	r1 = MR_stackvar(9);
	call_localret(STATIC(mercury__vn_flush__ensure_assignment_9_0),
		mercury__vn_flush__maybe_save_prev_value_10_0_i67,
		STATIC(mercury__vn_flush__maybe_save_prev_value_10_0));
Define_label(mercury__vn_flush__maybe_save_prev_value_10_0_i15);
	r1 = MR_stackvar(2);
	r2 = (Word) MR_string_const("vn_flush__choose_temp", 21);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_flush__maybe_save_prev_value_10_0_i59,
		STATIC(mercury__vn_flush__maybe_save_prev_value_10_0));
Define_label(mercury__vn_flush__maybe_save_prev_value_10_0_i59);
	update_prof_current_proc(LABEL(mercury__vn_flush__maybe_save_prev_value_10_0));
	call_localret(ENTRY(mercury__vn_type__vnrval_type_2_0),
		mercury__vn_flush__maybe_save_prev_value_10_0_i60,
		STATIC(mercury__vn_flush__maybe_save_prev_value_10_0));
Define_label(mercury__vn_flush__maybe_save_prev_value_10_0_i60);
	update_prof_current_proc(LABEL(mercury__vn_flush__maybe_save_prev_value_10_0));
	if (((Integer) r1 != (Integer) 9))
		GOTO_LABEL(mercury__vn_flush__maybe_save_prev_value_10_0_i61);
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__vn_temploc__next_tempf_3_0),
		mercury__vn_flush__maybe_save_prev_value_10_0_i64,
		STATIC(mercury__vn_flush__maybe_save_prev_value_10_0));
Define_label(mercury__vn_flush__maybe_save_prev_value_10_0_i61);
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__vn_temploc__next_tempr_3_0),
		mercury__vn_flush__maybe_save_prev_value_10_0_i64,
		STATIC(mercury__vn_flush__maybe_save_prev_value_10_0));
Define_label(mercury__vn_flush__maybe_save_prev_value_10_0_i64);
	update_prof_current_proc(LABEL(mercury__vn_flush__maybe_save_prev_value_10_0));
	r5 = r1;
	r1 = r2;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(4);
	r6 = MR_stackvar(7);
	call_localret(STATIC(mercury__vn_flush__ensure_assignment_9_0),
		mercury__vn_flush__maybe_save_prev_value_10_0_i67,
		STATIC(mercury__vn_flush__maybe_save_prev_value_10_0));
Define_label(mercury__vn_flush__maybe_save_prev_value_10_0_i67);
	update_prof_current_proc(LABEL(mercury__vn_flush__maybe_save_prev_value_10_0));
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(8);
	MR_stackvar(6) = r2;
	MR_stackvar(10) = r3;
	call_localret(ENTRY(mercury__opt_debug__dump_uses_list_2_0),
		mercury__vn_flush__maybe_save_prev_value_10_0_i68,
		STATIC(mercury__vn_flush__maybe_save_prev_value_10_0));
Define_label(mercury__vn_flush__maybe_save_prev_value_10_0_i68);
	update_prof_current_proc(LABEL(mercury__vn_flush__maybe_save_prev_value_10_0));
	r2 = MR_stackvar(6);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__vn_flush__maybe_save_prev_value_10_0, "origin_lost_in_value_number");
	r4 = r1;
	r1 = MR_stackvar(1);
	tag_incr_hp_msg(r5, MR_mktag(0), (Integer) 2, mercury__vn_flush__maybe_save_prev_value_10_0, "std_util:pair/2");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__vn_flush__maybe_save_prev_value_10_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r5, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), r3, (Integer) 0) = r5;
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_stackvar(10);
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r4;
	MR_field(MR_mktag(0), r5, (Integer) 1) = (Word) MR_string_const("", 0);
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	proceed();
	}
Define_label(mercury__vn_flush__maybe_save_prev_value_10_0_i2);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(5);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	proceed();
END_MODULE


BEGIN_MODULE(vn_flush_module18)
	init_entry(mercury__vn_flush__no_good_copies_1_0);
	init_label(mercury__vn_flush__no_good_copies_1_0_i1002);
	init_label(mercury__vn_flush__no_good_copies_1_0_i2);
	init_label(mercury__vn_flush__no_good_copies_1_0_i1);
BEGIN_CODE

/* code for predicate 'no_good_copies'/1 in mode 0 */
Define_static(mercury__vn_flush__no_good_copies_1_0);
	MR_incr_sp_push_msg(1, "vn_flush:no_good_copies/1");
	MR_stackvar(1) = (Word) MR_succip;
Define_label(mercury__vn_flush__no_good_copies_1_0_i1002);
	while (1) {
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_flush__no_good_copies_1_0_i2);
	if ((MR_tag(MR_const_field(MR_mktag(1), r1, (Integer) 0)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__vn_flush__no_good_copies_1_0_i1);
	if (((Integer) MR_const_field(MR_mktag(3), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0) != (Integer) 7))
		GOTO_LABEL(mercury__vn_flush__no_good_copies_1_0_i1);
	r2 = r1;
	r1 = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	/* continue */ } /* end while */
Define_label(mercury__vn_flush__no_good_copies_1_0_i2);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
Define_label(mercury__vn_flush__no_good_copies_1_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(1);
	MR_decr_sp_pop_msg(1);
	proceed();
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__vn_flush_maybe_bunch_0(void)
{
	vn_flush_module0();
	vn_flush_module1();
	vn_flush_module2();
	vn_flush_module3();
	vn_flush_module4();
	vn_flush_module5();
	vn_flush_module6();
	vn_flush_module7();
	vn_flush_module8();
	vn_flush_module9();
	vn_flush_module10();
	vn_flush_module11();
	vn_flush_module12();
	vn_flush_module13();
	vn_flush_module14();
	vn_flush_module15();
	vn_flush_module16();
	vn_flush_module17();
	vn_flush_module18();
}

#endif

void mercury__vn_flush__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__vn_flush__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__vn_flush_maybe_bunch_0();
#endif

	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
