/*
** Automatically generated from `vn_table.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__vn_table__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury____Index___vn_table__vn_tables_0__ua0_2_0);
Define_extern_entry(mercury__vn_table__init_tables_1_0);
Declare_label(mercury__vn_table__init_tables_1_0_i2);
Declare_label(mercury__vn_table__init_tables_1_0_i3);
Declare_label(mercury__vn_table__init_tables_1_0_i4);
Declare_label(mercury__vn_table__init_tables_1_0_i5);
Declare_label(mercury__vn_table__init_tables_1_0_i6);
Declare_label(mercury__vn_table__init_tables_1_0_i7);
Define_extern_entry(mercury__vn_table__get_next_vn_2_0);
Define_extern_entry(mercury__vn_table__get_lval_to_vn_table_2_0);
Define_extern_entry(mercury__vn_table__get_rval_to_vn_table_2_0);
Define_extern_entry(mercury__vn_table__get_vn_to_rval_table_2_0);
Define_extern_entry(mercury__vn_table__get_vn_to_uses_table_2_0);
Define_extern_entry(mercury__vn_table__get_vn_to_locs_table_2_0);
Define_extern_entry(mercury__vn_table__get_loc_to_vn_table_2_0);
Define_extern_entry(mercury__vn_table__lookup_desired_value_4_0);
Declare_label(mercury__vn_table__lookup_desired_value_4_0_i3);
Declare_label(mercury__vn_table__lookup_desired_value_4_0_i2);
Declare_label(mercury__vn_table__lookup_desired_value_4_0_i5);
Declare_label(mercury__vn_table__lookup_desired_value_4_0_i6);
Define_extern_entry(mercury__vn_table__lookup_assigned_vn_4_0);
Declare_label(mercury__vn_table__lookup_assigned_vn_4_0_i3);
Declare_label(mercury__vn_table__lookup_assigned_vn_4_0_i2);
Declare_label(mercury__vn_table__lookup_assigned_vn_4_0_i5);
Declare_label(mercury__vn_table__lookup_assigned_vn_4_0_i6);
Define_extern_entry(mercury__vn_table__lookup_defn_4_0);
Declare_label(mercury__vn_table__lookup_defn_4_0_i3);
Declare_label(mercury__vn_table__lookup_defn_4_0_i2);
Declare_label(mercury__vn_table__lookup_defn_4_0_i5);
Declare_label(mercury__vn_table__lookup_defn_4_0_i6);
Define_extern_entry(mercury__vn_table__lookup_uses_4_0);
Declare_label(mercury__vn_table__lookup_uses_4_0_i3);
Declare_label(mercury__vn_table__lookup_uses_4_0_i2);
Declare_label(mercury__vn_table__lookup_uses_4_0_i5);
Declare_label(mercury__vn_table__lookup_uses_4_0_i6);
Define_extern_entry(mercury__vn_table__lookup_current_locs_4_0);
Declare_label(mercury__vn_table__lookup_current_locs_4_0_i3);
Declare_label(mercury__vn_table__lookup_current_locs_4_0_i2);
Declare_label(mercury__vn_table__lookup_current_locs_4_0_i5);
Declare_label(mercury__vn_table__lookup_current_locs_4_0_i6);
Define_extern_entry(mercury__vn_table__lookup_current_value_4_0);
Declare_label(mercury__vn_table__lookup_current_value_4_0_i3);
Declare_label(mercury__vn_table__lookup_current_value_4_0_i2);
Declare_label(mercury__vn_table__lookup_current_value_4_0_i5);
Declare_label(mercury__vn_table__lookup_current_value_4_0_i6);
Define_extern_entry(mercury__vn_table__search_desired_value_3_0);
Define_extern_entry(mercury__vn_table__search_assigned_vn_3_0);
Define_extern_entry(mercury__vn_table__search_defn_3_0);
Define_extern_entry(mercury__vn_table__search_uses_3_0);
Define_extern_entry(mercury__vn_table__search_current_locs_3_0);
Define_extern_entry(mercury__vn_table__search_current_value_3_0);
Define_extern_entry(mercury__vn_table__get_vnlval_vn_list_2_0);
Define_extern_entry(mercury__vn_table__add_new_use_4_0);
Declare_label(mercury__vn_table__add_new_use_4_0_i3);
Declare_label(mercury__vn_table__add_new_use_4_0_i2);
Declare_label(mercury__vn_table__add_new_use_4_0_i5);
Declare_label(mercury__vn_table__add_new_use_4_0_i7);
Define_extern_entry(mercury__vn_table__del_old_use_4_0);
Declare_label(mercury__vn_table__del_old_use_4_0_i3);
Declare_label(mercury__vn_table__del_old_use_4_0_i2);
Declare_label(mercury__vn_table__del_old_use_4_0_i5);
Declare_label(mercury__vn_table__del_old_use_4_0_i6);
Declare_label(mercury__vn_table__del_old_use_4_0_i8);
Declare_label(mercury__vn_table__del_old_use_4_0_i7);
Declare_label(mercury__vn_table__del_old_use_4_0_i11);
Define_extern_entry(mercury__vn_table__del_old_uses_4_0);
Declare_label(mercury__vn_table__del_old_uses_4_0_i1001);
Declare_label(mercury__vn_table__del_old_uses_4_0_i4);
Declare_label(mercury__vn_table__del_old_uses_4_0_i3);
Define_extern_entry(mercury__vn_table__record_first_vnrval_4_0);
Declare_label(mercury__vn_table__record_first_vnrval_4_0_i2);
Declare_label(mercury__vn_table__record_first_vnrval_4_0_i3);
Declare_label(mercury__vn_table__record_first_vnrval_4_0_i4);
Declare_label(mercury__vn_table__record_first_vnrval_4_0_i5);
Define_extern_entry(mercury__vn_table__record_new_vnrval_4_0);
Declare_label(mercury__vn_table__record_new_vnrval_4_0_i3);
Declare_label(mercury__vn_table__record_new_vnrval_4_0_i2);
Declare_label(mercury__vn_table__record_new_vnrval_4_0_i5);
Declare_label(mercury__vn_table__record_new_vnrval_4_0_i6);
Declare_label(mercury__vn_table__record_new_vnrval_4_0_i7);
Declare_label(mercury__vn_table__record_new_vnrval_4_0_i8);
Define_extern_entry(mercury__vn_table__record_first_vnlval_4_0);
Declare_label(mercury__vn_table__record_first_vnlval_4_0_i2);
Declare_label(mercury__vn_table__record_first_vnlval_4_0_i3);
Declare_label(mercury__vn_table__record_first_vnlval_4_0_i4);
Declare_label(mercury__vn_table__record_first_vnlval_4_0_i5);
Declare_label(mercury__vn_table__record_first_vnlval_4_0_i6);
Declare_label(mercury__vn_table__record_first_vnlval_4_0_i7);
Define_extern_entry(mercury__vn_table__set_desired_value_4_0);
Declare_label(mercury__vn_table__set_desired_value_4_0_i3);
Declare_label(mercury__vn_table__set_desired_value_4_0_i5);
Declare_label(mercury__vn_table__set_desired_value_4_0_i2);
Declare_label(mercury__vn_table__set_desired_value_4_0_i6);
Declare_label(mercury__vn_table__set_desired_value_4_0_i7);
Define_extern_entry(mercury__vn_table__set_current_value_4_0);
Declare_label(mercury__vn_table__set_current_value_4_0_i3);
Declare_label(mercury__vn_table__set_current_value_4_0_i5);
Declare_label(mercury__vn_table__set_current_value_4_0_i6);
Declare_label(mercury__vn_table__set_current_value_4_0_i7);
Declare_label(mercury__vn_table__set_current_value_4_0_i8);
Declare_label(mercury__vn_table__set_current_value_4_0_i9);
Declare_label(mercury__vn_table__set_current_value_4_0_i10);
Declare_label(mercury__vn_table__set_current_value_4_0_i11);
Declare_label(mercury__vn_table__set_current_value_4_0_i2);
Declare_label(mercury__vn_table__set_current_value_4_0_i12);
Declare_label(mercury__vn_table__set_current_value_4_0_i13);
Declare_label(mercury__vn_table__set_current_value_4_0_i14);
Declare_label(mercury__vn_table__set_current_value_4_0_i15);
Define_extern_entry(mercury__vn_table__set_parallel_value_4_0);
Declare_label(mercury__vn_table__set_parallel_value_4_0_i2);
Define_extern_entry(mercury__vn_table__get_all_vnrvals_2_0);
Define_extern_entry(mercury____Unify___vn_table__vn_tables_0_0);
Declare_label(mercury____Unify___vn_table__vn_tables_0_0_i2);
Declare_label(mercury____Unify___vn_table__vn_tables_0_0_i4);
Declare_label(mercury____Unify___vn_table__vn_tables_0_0_i6);
Declare_label(mercury____Unify___vn_table__vn_tables_0_0_i8);
Declare_label(mercury____Unify___vn_table__vn_tables_0_0_i10);
Declare_label(mercury____Unify___vn_table__vn_tables_0_0_i1007);
Declare_label(mercury____Unify___vn_table__vn_tables_0_0_i1);
Define_extern_entry(mercury____Index___vn_table__vn_tables_0_0);
Define_extern_entry(mercury____Compare___vn_table__vn_tables_0_0);
Declare_label(mercury____Compare___vn_table__vn_tables_0_0_i3);
Declare_label(mercury____Compare___vn_table__vn_tables_0_0_i7);
Declare_label(mercury____Compare___vn_table__vn_tables_0_0_i11);
Declare_label(mercury____Compare___vn_table__vn_tables_0_0_i15);
Declare_label(mercury____Compare___vn_table__vn_tables_0_0_i19);
Declare_label(mercury____Compare___vn_table__vn_tables_0_0_i23);
Declare_label(mercury____Compare___vn_table__vn_tables_0_0_i32);
Define_extern_entry(mercury____Unify___vn_table__lval_to_vn_table_0_0);
Define_extern_entry(mercury____Index___vn_table__lval_to_vn_table_0_0);
Define_extern_entry(mercury____Compare___vn_table__lval_to_vn_table_0_0);
Define_extern_entry(mercury____Unify___vn_table__rval_to_vn_table_0_0);
Define_extern_entry(mercury____Index___vn_table__rval_to_vn_table_0_0);
Define_extern_entry(mercury____Compare___vn_table__rval_to_vn_table_0_0);
Define_extern_entry(mercury____Unify___vn_table__vn_to_rval_table_0_0);
Define_extern_entry(mercury____Index___vn_table__vn_to_rval_table_0_0);
Define_extern_entry(mercury____Compare___vn_table__vn_to_rval_table_0_0);
Define_extern_entry(mercury____Unify___vn_table__vn_to_uses_table_0_0);
Define_extern_entry(mercury____Index___vn_table__vn_to_uses_table_0_0);
Define_extern_entry(mercury____Compare___vn_table__vn_to_uses_table_0_0);
Define_extern_entry(mercury____Unify___vn_table__vn_to_locs_table_0_0);
Define_extern_entry(mercury____Index___vn_table__vn_to_locs_table_0_0);
Define_extern_entry(mercury____Compare___vn_table__vn_to_locs_table_0_0);
Define_extern_entry(mercury____Unify___vn_table__loc_to_vn_table_0_0);
Define_extern_entry(mercury____Index___vn_table__loc_to_vn_table_0_0);
Define_extern_entry(mercury____Compare___vn_table__loc_to_vn_table_0_0);

const struct MR_TypeCtorInfo_struct mercury_data_vn_table__type_ctor_info_loc_to_vn_table_0;

const struct MR_TypeCtorInfo_struct mercury_data_vn_table__type_ctor_info_lval_to_vn_table_0;

const struct MR_TypeCtorInfo_struct mercury_data_vn_table__type_ctor_info_rval_to_vn_table_0;

const struct MR_TypeCtorInfo_struct mercury_data_vn_table__type_ctor_info_vn_tables_0;

const struct MR_TypeCtorInfo_struct mercury_data_vn_table__type_ctor_info_vn_to_locs_table_0;

const struct MR_TypeCtorInfo_struct mercury_data_vn_table__type_ctor_info_vn_to_rval_table_0;

const struct MR_TypeCtorInfo_struct mercury_data_vn_table__type_ctor_info_vn_to_uses_table_0;

static const struct mercury_data_vn_table__common_0_struct {
	Word * f1;
	Word * f2;
}  mercury_data_vn_table__common_0;

static const struct mercury_data_vn_table__common_1_struct {
	Word * f1;
	Word * f2;
}  mercury_data_vn_table__common_1;

static const struct mercury_data_vn_table__common_2_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_vn_table__common_2;

static const struct mercury_data_vn_table__common_3_struct {
	Integer f1;
	Word * f2;
}  mercury_data_vn_table__common_3;

static const struct mercury_data_vn_table__common_4_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_vn_table__common_4;

static const struct mercury_data_vn_table__common_5_struct {
	Integer f1;
	Word * f2;
}  mercury_data_vn_table__common_5;

static const struct mercury_data_vn_table__common_6_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_vn_table__common_6;

static const struct mercury_data_vn_table__common_7_struct {
	Integer f1;
	Word * f2;
}  mercury_data_vn_table__common_7;

static const struct mercury_data_vn_table__common_8_struct {
	Word * f1;
}  mercury_data_vn_table__common_8;

static const struct mercury_data_vn_table__common_9_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_vn_table__common_9;

static const struct mercury_data_vn_table__common_10_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_vn_table__common_10;

static const struct mercury_data_vn_table__common_11_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	Word * f5;
	Word * f6;
	Word * f7;
	Word * f8;
	String f9;
	Word * f10;
	Integer f11;
	Integer f12;
}  mercury_data_vn_table__common_11;

static const struct mercury_data_vn_table__common_12_struct {
	Integer f1;
	Word * f2;
}  mercury_data_vn_table__common_12;

static const struct mercury_data_vn_table__common_13_struct {
	Integer f1;
	Word * f2;
}  mercury_data_vn_table__common_13;

static const struct mercury_data_vn_table__type_ctor_functors_vn_to_uses_table_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_vn_table__type_ctor_functors_vn_to_uses_table_0;

static const struct mercury_data_vn_table__type_ctor_layout_vn_to_uses_table_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_vn_table__type_ctor_layout_vn_to_uses_table_0;

static const struct mercury_data_vn_table__type_ctor_functors_vn_to_rval_table_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_vn_table__type_ctor_functors_vn_to_rval_table_0;

static const struct mercury_data_vn_table__type_ctor_layout_vn_to_rval_table_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_vn_table__type_ctor_layout_vn_to_rval_table_0;

static const struct mercury_data_vn_table__type_ctor_functors_vn_to_locs_table_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_vn_table__type_ctor_functors_vn_to_locs_table_0;

static const struct mercury_data_vn_table__type_ctor_layout_vn_to_locs_table_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_vn_table__type_ctor_layout_vn_to_locs_table_0;

static const struct mercury_data_vn_table__type_ctor_functors_vn_tables_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_vn_table__type_ctor_functors_vn_tables_0;

static const struct mercury_data_vn_table__type_ctor_layout_vn_tables_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_vn_table__type_ctor_layout_vn_tables_0;

static const struct mercury_data_vn_table__type_ctor_functors_rval_to_vn_table_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_vn_table__type_ctor_functors_rval_to_vn_table_0;

static const struct mercury_data_vn_table__type_ctor_layout_rval_to_vn_table_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_vn_table__type_ctor_layout_rval_to_vn_table_0;

static const struct mercury_data_vn_table__type_ctor_functors_lval_to_vn_table_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_vn_table__type_ctor_functors_lval_to_vn_table_0;

static const struct mercury_data_vn_table__type_ctor_layout_lval_to_vn_table_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_vn_table__type_ctor_layout_lval_to_vn_table_0;

static const struct mercury_data_vn_table__type_ctor_functors_loc_to_vn_table_0_struct {
	Integer f1;
	Word * f2;
}  mercury_data_vn_table__type_ctor_functors_loc_to_vn_table_0;

static const struct mercury_data_vn_table__type_ctor_layout_loc_to_vn_table_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_vn_table__type_ctor_layout_loc_to_vn_table_0;

const struct MR_TypeCtorInfo_struct mercury_data_vn_table__type_ctor_info_loc_to_vn_table_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___vn_table__loc_to_vn_table_0_0),
	ENTRY(mercury____Index___vn_table__loc_to_vn_table_0_0),
	ENTRY(mercury____Compare___vn_table__loc_to_vn_table_0_0),
	(Integer) 6,
	(Word *) &mercury_data_vn_table__type_ctor_functors_loc_to_vn_table_0,
	(Word *) &mercury_data_vn_table__type_ctor_layout_loc_to_vn_table_0,
	MR_string_const("vn_table", 8),
	MR_string_const("loc_to_vn_table", 15),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_vn_table__type_ctor_info_lval_to_vn_table_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___vn_table__lval_to_vn_table_0_0),
	ENTRY(mercury____Index___vn_table__lval_to_vn_table_0_0),
	ENTRY(mercury____Compare___vn_table__lval_to_vn_table_0_0),
	(Integer) 6,
	(Word *) &mercury_data_vn_table__type_ctor_functors_lval_to_vn_table_0,
	(Word *) &mercury_data_vn_table__type_ctor_layout_lval_to_vn_table_0,
	MR_string_const("vn_table", 8),
	MR_string_const("lval_to_vn_table", 16),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_vn_table__type_ctor_info_rval_to_vn_table_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___vn_table__rval_to_vn_table_0_0),
	ENTRY(mercury____Index___vn_table__rval_to_vn_table_0_0),
	ENTRY(mercury____Compare___vn_table__rval_to_vn_table_0_0),
	(Integer) 6,
	(Word *) &mercury_data_vn_table__type_ctor_functors_rval_to_vn_table_0,
	(Word *) &mercury_data_vn_table__type_ctor_layout_rval_to_vn_table_0,
	MR_string_const("vn_table", 8),
	MR_string_const("rval_to_vn_table", 16),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_vn_table__type_ctor_info_vn_tables_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___vn_table__vn_tables_0_0),
	ENTRY(mercury____Index___vn_table__vn_tables_0_0),
	ENTRY(mercury____Compare___vn_table__vn_tables_0_0),
	(Integer) 2,
	(Word *) &mercury_data_vn_table__type_ctor_functors_vn_tables_0,
	(Word *) &mercury_data_vn_table__type_ctor_layout_vn_tables_0,
	MR_string_const("vn_table", 8),
	MR_string_const("vn_tables", 9),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_vn_table__type_ctor_info_vn_to_locs_table_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___vn_table__vn_to_locs_table_0_0),
	ENTRY(mercury____Index___vn_table__vn_to_locs_table_0_0),
	ENTRY(mercury____Compare___vn_table__vn_to_locs_table_0_0),
	(Integer) 6,
	(Word *) &mercury_data_vn_table__type_ctor_functors_vn_to_locs_table_0,
	(Word *) &mercury_data_vn_table__type_ctor_layout_vn_to_locs_table_0,
	MR_string_const("vn_table", 8),
	MR_string_const("vn_to_locs_table", 16),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_vn_table__type_ctor_info_vn_to_rval_table_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___vn_table__vn_to_rval_table_0_0),
	ENTRY(mercury____Index___vn_table__vn_to_rval_table_0_0),
	ENTRY(mercury____Compare___vn_table__vn_to_rval_table_0_0),
	(Integer) 6,
	(Word *) &mercury_data_vn_table__type_ctor_functors_vn_to_rval_table_0,
	(Word *) &mercury_data_vn_table__type_ctor_layout_vn_to_rval_table_0,
	MR_string_const("vn_table", 8),
	MR_string_const("vn_to_rval_table", 16),
	(Integer) 3
};

const struct MR_TypeCtorInfo_struct mercury_data_vn_table__type_ctor_info_vn_to_uses_table_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___vn_table__vn_to_uses_table_0_0),
	ENTRY(mercury____Index___vn_table__vn_to_uses_table_0_0),
	ENTRY(mercury____Compare___vn_table__vn_to_uses_table_0_0),
	(Integer) 6,
	(Word *) &mercury_data_vn_table__type_ctor_functors_vn_to_uses_table_0,
	(Word *) &mercury_data_vn_table__type_ctor_layout_vn_to_uses_table_0,
	MR_string_const("vn_table", 8),
	MR_string_const("vn_to_uses_table", 16),
	(Integer) 3
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_list__type_ctor_info_list_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_vn_type__type_ctor_info_vn_src_0;
static const struct mercury_data_vn_table__common_0_struct mercury_data_vn_table__common_0 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data_vn_type__type_ctor_info_vn_src_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_vn_type__type_ctor_info_vnlval_0;
static const struct mercury_data_vn_table__common_1_struct mercury_data_vn_table__common_1 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_tree234__type_ctor_info_tree234_2;
extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_int_0;
static const struct mercury_data_vn_table__common_2_struct mercury_data_vn_table__common_2 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	(Word *) &mercury_data___type_ctor_info_int_0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_table__common_0)
};

static const struct mercury_data_vn_table__common_3_struct mercury_data_vn_table__common_3 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_table__common_2)
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_vn_type__type_ctor_info_vnrval_0;
static const struct mercury_data_vn_table__common_4_struct mercury_data_vn_table__common_4 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	(Word *) &mercury_data___type_ctor_info_int_0,
	(Word *) &mercury_data_vn_type__type_ctor_info_vnrval_0
};

static const struct mercury_data_vn_table__common_5_struct mercury_data_vn_table__common_5 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_table__common_4)
};

static const struct mercury_data_vn_table__common_6_struct mercury_data_vn_table__common_6 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	(Word *) &mercury_data___type_ctor_info_int_0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_table__common_1)
};

static const struct mercury_data_vn_table__common_7_struct mercury_data_vn_table__common_7 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_table__common_6)
};

static const struct mercury_data_vn_table__common_8_struct mercury_data_vn_table__common_8 = {
	(Word *) &mercury_data___type_ctor_info_int_0
};

static const struct mercury_data_vn_table__common_9_struct mercury_data_vn_table__common_9 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	(Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0,
	(Word *) &mercury_data___type_ctor_info_int_0
};

static const struct mercury_data_vn_table__common_10_struct mercury_data_vn_table__common_10 = {
	(Word *) &mercury_data_tree234__type_ctor_info_tree234_2,
	(Word *) &mercury_data_vn_type__type_ctor_info_vnrval_0,
	(Word *) &mercury_data___type_ctor_info_int_0
};

static const struct mercury_data_vn_table__common_11_struct mercury_data_vn_table__common_11 = {
	(Integer) 7,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_table__common_8),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_table__common_9),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_table__common_10),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_table__common_4),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_table__common_2),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_table__common_6),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_table__common_9),
	MR_string_const("vn_tables", 9),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_vn_table__common_12_struct mercury_data_vn_table__common_12 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_table__common_10)
};

static const struct mercury_data_vn_table__common_13_struct mercury_data_vn_table__common_13 = {
	(Integer) 0,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_table__common_9)
};

static const struct mercury_data_vn_table__type_ctor_functors_vn_to_uses_table_0_struct mercury_data_vn_table__type_ctor_functors_vn_to_uses_table_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_table__common_2)
};

static const struct mercury_data_vn_table__type_ctor_layout_vn_to_uses_table_0_struct mercury_data_vn_table__type_ctor_layout_vn_to_uses_table_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_vn_table__common_3),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_vn_table__common_3),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_vn_table__common_3),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_vn_table__common_3)
};

static const struct mercury_data_vn_table__type_ctor_functors_vn_to_rval_table_0_struct mercury_data_vn_table__type_ctor_functors_vn_to_rval_table_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_table__common_4)
};

static const struct mercury_data_vn_table__type_ctor_layout_vn_to_rval_table_0_struct mercury_data_vn_table__type_ctor_layout_vn_to_rval_table_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_vn_table__common_5),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_vn_table__common_5),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_vn_table__common_5),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_vn_table__common_5)
};

static const struct mercury_data_vn_table__type_ctor_functors_vn_to_locs_table_0_struct mercury_data_vn_table__type_ctor_functors_vn_to_locs_table_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_table__common_6)
};

static const struct mercury_data_vn_table__type_ctor_layout_vn_to_locs_table_0_struct mercury_data_vn_table__type_ctor_layout_vn_to_locs_table_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_vn_table__common_7),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_vn_table__common_7),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_vn_table__common_7),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_vn_table__common_7)
};

static const struct mercury_data_vn_table__type_ctor_functors_vn_tables_0_struct mercury_data_vn_table__type_ctor_functors_vn_tables_0 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_table__common_11)
};

static const struct mercury_data_vn_table__type_ctor_layout_vn_tables_0_struct mercury_data_vn_table__type_ctor_layout_vn_tables_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_vn_table__common_11),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_vn_table__type_ctor_functors_rval_to_vn_table_0_struct mercury_data_vn_table__type_ctor_functors_rval_to_vn_table_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_table__common_10)
};

static const struct mercury_data_vn_table__type_ctor_layout_rval_to_vn_table_0_struct mercury_data_vn_table__type_ctor_layout_rval_to_vn_table_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_vn_table__common_12),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_vn_table__common_12),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_vn_table__common_12),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_vn_table__common_12)
};

static const struct mercury_data_vn_table__type_ctor_functors_lval_to_vn_table_0_struct mercury_data_vn_table__type_ctor_functors_lval_to_vn_table_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_table__common_9)
};

static const struct mercury_data_vn_table__type_ctor_layout_lval_to_vn_table_0_struct mercury_data_vn_table__type_ctor_layout_lval_to_vn_table_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_vn_table__common_13),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_vn_table__common_13),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_vn_table__common_13),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_vn_table__common_13)
};

static const struct mercury_data_vn_table__type_ctor_functors_loc_to_vn_table_0_struct mercury_data_vn_table__type_ctor_functors_loc_to_vn_table_0 = {
	(Integer) 2,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_table__common_9)
};

static const struct mercury_data_vn_table__type_ctor_layout_loc_to_vn_table_0_struct mercury_data_vn_table__type_ctor_layout_loc_to_vn_table_0 = {
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_vn_table__common_13),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_vn_table__common_13),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_vn_table__common_13),
	MR_mkword(MR_mktag(3), (Word *) &mercury_data_vn_table__common_13)
};


BEGIN_MODULE(vn_table_module0)
	init_entry(mercury____Index___vn_table__vn_tables_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___vn_table__vn_tables_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___vn_table__vn_tables_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE

Declare_entry(mercury__map__init_1_0);

BEGIN_MODULE(vn_table_module1)
	init_entry(mercury__vn_table__init_tables_1_0);
	init_label(mercury__vn_table__init_tables_1_0_i2);
	init_label(mercury__vn_table__init_tables_1_0_i3);
	init_label(mercury__vn_table__init_tables_1_0_i4);
	init_label(mercury__vn_table__init_tables_1_0_i5);
	init_label(mercury__vn_table__init_tables_1_0_i6);
	init_label(mercury__vn_table__init_tables_1_0_i7);
BEGIN_CODE

/* code for predicate 'init_tables'/1 in mode 0 */
Define_entry(mercury__vn_table__init_tables_1_0);
	MR_incr_sp_push_msg(6, "vn_table:init_tables/1");
	MR_stackvar(6) = (Word) MR_succip;
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__vn_table__init_tables_1_0_i2,
		ENTRY(mercury__vn_table__init_tables_1_0));
Define_label(mercury__vn_table__init_tables_1_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_table__init_tables_1_0));
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnrval_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__vn_table__init_tables_1_0_i3,
		ENTRY(mercury__vn_table__init_tables_1_0));
Define_label(mercury__vn_table__init_tables_1_0_i3);
	update_prof_current_proc(LABEL(mercury__vn_table__init_tables_1_0));
	MR_stackvar(2) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnrval_0;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__vn_table__init_tables_1_0_i4,
		ENTRY(mercury__vn_table__init_tables_1_0));
Define_label(mercury__vn_table__init_tables_1_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_table__init_tables_1_0));
	MR_stackvar(3) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_table__common_0);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__vn_table__init_tables_1_0_i5,
		ENTRY(mercury__vn_table__init_tables_1_0));
Define_label(mercury__vn_table__init_tables_1_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_table__init_tables_1_0));
	MR_stackvar(4) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_table__common_1);
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__vn_table__init_tables_1_0_i6,
		ENTRY(mercury__vn_table__init_tables_1_0));
Define_label(mercury__vn_table__init_tables_1_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_table__init_tables_1_0));
	MR_stackvar(5) = r1;
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__vn_table__init_tables_1_0_i7,
		ENTRY(mercury__vn_table__init_tables_1_0));
Define_label(mercury__vn_table__init_tables_1_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_table__init_tables_1_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 7, mercury__vn_table__init_tables_1_0, "vn_table:vn_tables/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_stackvar(3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_stackvar(4);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_stackvar(5);
	MR_field(MR_mktag(0), r1, (Integer) 6) = r2;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE


BEGIN_MODULE(vn_table_module2)
	init_entry(mercury__vn_table__get_next_vn_2_0);
BEGIN_CODE

/* code for predicate 'get_next_vn'/2 in mode 0 */
Define_entry(mercury__vn_table__get_next_vn_2_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	proceed();
END_MODULE


BEGIN_MODULE(vn_table_module3)
	init_entry(mercury__vn_table__get_lval_to_vn_table_2_0);
BEGIN_CODE

/* code for predicate 'get_lval_to_vn_table'/2 in mode 0 */
Define_entry(mercury__vn_table__get_lval_to_vn_table_2_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	proceed();
END_MODULE


BEGIN_MODULE(vn_table_module4)
	init_entry(mercury__vn_table__get_rval_to_vn_table_2_0);
BEGIN_CODE

/* code for predicate 'get_rval_to_vn_table'/2 in mode 0 */
Define_entry(mercury__vn_table__get_rval_to_vn_table_2_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	proceed();
END_MODULE


BEGIN_MODULE(vn_table_module5)
	init_entry(mercury__vn_table__get_vn_to_rval_table_2_0);
BEGIN_CODE

/* code for predicate 'get_vn_to_rval_table'/2 in mode 0 */
Define_entry(mercury__vn_table__get_vn_to_rval_table_2_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	proceed();
END_MODULE


BEGIN_MODULE(vn_table_module6)
	init_entry(mercury__vn_table__get_vn_to_uses_table_2_0);
BEGIN_CODE

/* code for predicate 'get_vn_to_uses_table'/2 in mode 0 */
Define_entry(mercury__vn_table__get_vn_to_uses_table_2_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	proceed();
END_MODULE


BEGIN_MODULE(vn_table_module7)
	init_entry(mercury__vn_table__get_vn_to_locs_table_2_0);
BEGIN_CODE

/* code for predicate 'get_vn_to_locs_table'/2 in mode 0 */
Define_entry(mercury__vn_table__get_vn_to_locs_table_2_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 5);
	proceed();
END_MODULE


BEGIN_MODULE(vn_table_module8)
	init_entry(mercury__vn_table__get_loc_to_vn_table_2_0);
BEGIN_CODE

/* code for predicate 'get_loc_to_vn_table'/2 in mode 0 */
Define_entry(mercury__vn_table__get_loc_to_vn_table_2_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 6);
	proceed();
END_MODULE

Declare_entry(mercury__map__search_3_1);
Declare_entry(mercury__opt_debug__dump_vnlval_2_0);
Declare_entry(mercury__string__append_list_2_0);
Declare_entry(mercury__require__error_1_0);

BEGIN_MODULE(vn_table_module9)
	init_entry(mercury__vn_table__lookup_desired_value_4_0);
	init_label(mercury__vn_table__lookup_desired_value_4_0_i3);
	init_label(mercury__vn_table__lookup_desired_value_4_0_i2);
	init_label(mercury__vn_table__lookup_desired_value_4_0_i5);
	init_label(mercury__vn_table__lookup_desired_value_4_0_i6);
BEGIN_CODE

/* code for predicate 'lookup_desired_value'/4 in mode 0 */
Define_entry(mercury__vn_table__lookup_desired_value_4_0);
	MR_incr_sp_push_msg(3, "vn_table:lookup_desired_value/4");
	MR_stackvar(3) = (Word) MR_succip;
	r4 = r1;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r3 = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__vn_table__lookup_desired_value_4_0_i3,
		ENTRY(mercury__vn_table__lookup_desired_value_4_0));
Define_label(mercury__vn_table__lookup_desired_value_4_0_i3);
	update_prof_current_proc(LABEL(mercury__vn_table__lookup_desired_value_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_table__lookup_desired_value_4_0_i2);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_table__lookup_desired_value_4_0_i2);
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__opt_debug__dump_vnlval_2_0),
		mercury__vn_table__lookup_desired_value_4_0_i5,
		ENTRY(mercury__vn_table__lookup_desired_value_4_0));
Define_label(mercury__vn_table__lookup_desired_value_4_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_table__lookup_desired_value_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__vn_table__lookup_desired_value_4_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__vn_table__lookup_desired_value_4_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const(": cannot find desired value for ", 32);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__vn_table__lookup_desired_value_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__vn_table__lookup_desired_value_4_0_i6,
		ENTRY(mercury__vn_table__lookup_desired_value_4_0));
	}
Define_label(mercury__vn_table__lookup_desired_value_4_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_table__lookup_desired_value_4_0));
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__vn_table__lookup_desired_value_4_0));
END_MODULE

Declare_entry(mercury__opt_debug__dump_vnrval_2_0);

BEGIN_MODULE(vn_table_module10)
	init_entry(mercury__vn_table__lookup_assigned_vn_4_0);
	init_label(mercury__vn_table__lookup_assigned_vn_4_0_i3);
	init_label(mercury__vn_table__lookup_assigned_vn_4_0_i2);
	init_label(mercury__vn_table__lookup_assigned_vn_4_0_i5);
	init_label(mercury__vn_table__lookup_assigned_vn_4_0_i6);
BEGIN_CODE

/* code for predicate 'lookup_assigned_vn'/4 in mode 0 */
Define_entry(mercury__vn_table__lookup_assigned_vn_4_0);
	MR_incr_sp_push_msg(3, "vn_table:lookup_assigned_vn/4");
	MR_stackvar(3) = (Word) MR_succip;
	r4 = r1;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r3 = MR_const_field(MR_mktag(0), r3, (Integer) 2);
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnrval_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__vn_table__lookup_assigned_vn_4_0_i3,
		ENTRY(mercury__vn_table__lookup_assigned_vn_4_0));
Define_label(mercury__vn_table__lookup_assigned_vn_4_0_i3);
	update_prof_current_proc(LABEL(mercury__vn_table__lookup_assigned_vn_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_table__lookup_assigned_vn_4_0_i2);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_table__lookup_assigned_vn_4_0_i2);
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__opt_debug__dump_vnrval_2_0),
		mercury__vn_table__lookup_assigned_vn_4_0_i5,
		ENTRY(mercury__vn_table__lookup_assigned_vn_4_0));
Define_label(mercury__vn_table__lookup_assigned_vn_4_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_table__lookup_assigned_vn_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__vn_table__lookup_assigned_vn_4_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__vn_table__lookup_assigned_vn_4_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const(": cannot find assigned vn for ", 30);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__vn_table__lookup_assigned_vn_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__vn_table__lookup_assigned_vn_4_0_i6,
		ENTRY(mercury__vn_table__lookup_assigned_vn_4_0));
	}
Define_label(mercury__vn_table__lookup_assigned_vn_4_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_table__lookup_assigned_vn_4_0));
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__vn_table__lookup_assigned_vn_4_0));
END_MODULE

Declare_entry(mercury__opt_debug__dump_vn_2_0);

BEGIN_MODULE(vn_table_module11)
	init_entry(mercury__vn_table__lookup_defn_4_0);
	init_label(mercury__vn_table__lookup_defn_4_0_i3);
	init_label(mercury__vn_table__lookup_defn_4_0_i2);
	init_label(mercury__vn_table__lookup_defn_4_0_i5);
	init_label(mercury__vn_table__lookup_defn_4_0_i6);
BEGIN_CODE

/* code for predicate 'lookup_defn'/4 in mode 0 */
Define_entry(mercury__vn_table__lookup_defn_4_0);
	MR_incr_sp_push_msg(3, "vn_table:lookup_defn/4");
	MR_stackvar(3) = (Word) MR_succip;
	r4 = r1;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r3 = MR_const_field(MR_mktag(0), r3, (Integer) 3);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnrval_0;
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__vn_table__lookup_defn_4_0_i3,
		ENTRY(mercury__vn_table__lookup_defn_4_0));
Define_label(mercury__vn_table__lookup_defn_4_0_i3);
	update_prof_current_proc(LABEL(mercury__vn_table__lookup_defn_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_table__lookup_defn_4_0_i2);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_table__lookup_defn_4_0_i2);
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__opt_debug__dump_vn_2_0),
		mercury__vn_table__lookup_defn_4_0_i5,
		ENTRY(mercury__vn_table__lookup_defn_4_0));
Define_label(mercury__vn_table__lookup_defn_4_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_table__lookup_defn_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__vn_table__lookup_defn_4_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__vn_table__lookup_defn_4_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const(": cannot find definition for ", 29);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__vn_table__lookup_defn_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__vn_table__lookup_defn_4_0_i6,
		ENTRY(mercury__vn_table__lookup_defn_4_0));
	}
Define_label(mercury__vn_table__lookup_defn_4_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_table__lookup_defn_4_0));
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__vn_table__lookup_defn_4_0));
END_MODULE


BEGIN_MODULE(vn_table_module12)
	init_entry(mercury__vn_table__lookup_uses_4_0);
	init_label(mercury__vn_table__lookup_uses_4_0_i3);
	init_label(mercury__vn_table__lookup_uses_4_0_i2);
	init_label(mercury__vn_table__lookup_uses_4_0_i5);
	init_label(mercury__vn_table__lookup_uses_4_0_i6);
BEGIN_CODE

/* code for predicate 'lookup_uses'/4 in mode 0 */
Define_entry(mercury__vn_table__lookup_uses_4_0);
	MR_incr_sp_push_msg(3, "vn_table:lookup_uses/4");
	MR_stackvar(3) = (Word) MR_succip;
	r4 = r1;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r3 = MR_const_field(MR_mktag(0), r3, (Integer) 4);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_table__common_0);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__vn_table__lookup_uses_4_0_i3,
		ENTRY(mercury__vn_table__lookup_uses_4_0));
Define_label(mercury__vn_table__lookup_uses_4_0_i3);
	update_prof_current_proc(LABEL(mercury__vn_table__lookup_uses_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_table__lookup_uses_4_0_i2);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_table__lookup_uses_4_0_i2);
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__opt_debug__dump_vn_2_0),
		mercury__vn_table__lookup_uses_4_0_i5,
		ENTRY(mercury__vn_table__lookup_uses_4_0));
Define_label(mercury__vn_table__lookup_uses_4_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_table__lookup_uses_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__vn_table__lookup_uses_4_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__vn_table__lookup_uses_4_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const(": cannot find uses for ", 23);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__vn_table__lookup_uses_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__vn_table__lookup_uses_4_0_i6,
		ENTRY(mercury__vn_table__lookup_uses_4_0));
	}
Define_label(mercury__vn_table__lookup_uses_4_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_table__lookup_uses_4_0));
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__vn_table__lookup_uses_4_0));
END_MODULE


BEGIN_MODULE(vn_table_module13)
	init_entry(mercury__vn_table__lookup_current_locs_4_0);
	init_label(mercury__vn_table__lookup_current_locs_4_0_i3);
	init_label(mercury__vn_table__lookup_current_locs_4_0_i2);
	init_label(mercury__vn_table__lookup_current_locs_4_0_i5);
	init_label(mercury__vn_table__lookup_current_locs_4_0_i6);
BEGIN_CODE

/* code for predicate 'lookup_current_locs'/4 in mode 0 */
Define_entry(mercury__vn_table__lookup_current_locs_4_0);
	MR_incr_sp_push_msg(3, "vn_table:lookup_current_locs/4");
	MR_stackvar(3) = (Word) MR_succip;
	r4 = r1;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r3 = MR_const_field(MR_mktag(0), r3, (Integer) 5);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_table__common_1);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__vn_table__lookup_current_locs_4_0_i3,
		ENTRY(mercury__vn_table__lookup_current_locs_4_0));
Define_label(mercury__vn_table__lookup_current_locs_4_0_i3);
	update_prof_current_proc(LABEL(mercury__vn_table__lookup_current_locs_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_table__lookup_current_locs_4_0_i2);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_table__lookup_current_locs_4_0_i2);
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__opt_debug__dump_vn_2_0),
		mercury__vn_table__lookup_current_locs_4_0_i5,
		ENTRY(mercury__vn_table__lookup_current_locs_4_0));
Define_label(mercury__vn_table__lookup_current_locs_4_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_table__lookup_current_locs_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__vn_table__lookup_current_locs_4_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__vn_table__lookup_current_locs_4_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const(": cannot find current locs for ", 31);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__vn_table__lookup_current_locs_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__vn_table__lookup_current_locs_4_0_i6,
		ENTRY(mercury__vn_table__lookup_current_locs_4_0));
	}
Define_label(mercury__vn_table__lookup_current_locs_4_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_table__lookup_current_locs_4_0));
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__vn_table__lookup_current_locs_4_0));
END_MODULE


BEGIN_MODULE(vn_table_module14)
	init_entry(mercury__vn_table__lookup_current_value_4_0);
	init_label(mercury__vn_table__lookup_current_value_4_0_i3);
	init_label(mercury__vn_table__lookup_current_value_4_0_i2);
	init_label(mercury__vn_table__lookup_current_value_4_0_i5);
	init_label(mercury__vn_table__lookup_current_value_4_0_i6);
BEGIN_CODE

/* code for predicate 'lookup_current_value'/4 in mode 0 */
Define_entry(mercury__vn_table__lookup_current_value_4_0);
	MR_incr_sp_push_msg(3, "vn_table:lookup_current_value/4");
	MR_stackvar(3) = (Word) MR_succip;
	r4 = r1;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r3 = MR_const_field(MR_mktag(0), r3, (Integer) 6);
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__vn_table__lookup_current_value_4_0_i3,
		ENTRY(mercury__vn_table__lookup_current_value_4_0));
Define_label(mercury__vn_table__lookup_current_value_4_0_i3);
	update_prof_current_proc(LABEL(mercury__vn_table__lookup_current_value_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_table__lookup_current_value_4_0_i2);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_table__lookup_current_value_4_0_i2);
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__opt_debug__dump_vnlval_2_0),
		mercury__vn_table__lookup_current_value_4_0_i5,
		ENTRY(mercury__vn_table__lookup_current_value_4_0));
Define_label(mercury__vn_table__lookup_current_value_4_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_table__lookup_current_value_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__vn_table__lookup_current_value_4_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(2);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__vn_table__lookup_current_value_4_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = (Word) MR_string_const(": cannot find current value for ", 32);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__vn_table__lookup_current_value_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_tempr1;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r2;
	call_localret(ENTRY(mercury__string__append_list_2_0),
		mercury__vn_table__lookup_current_value_4_0_i6,
		ENTRY(mercury__vn_table__lookup_current_value_4_0));
	}
Define_label(mercury__vn_table__lookup_current_value_4_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_table__lookup_current_value_4_0));
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__vn_table__lookup_current_value_4_0));
END_MODULE


BEGIN_MODULE(vn_table_module15)
	init_entry(mercury__vn_table__search_desired_value_3_0);
BEGIN_CODE

/* code for predicate 'search_desired_value'/3 in mode 0 */
Define_entry(mercury__vn_table__search_desired_value_3_0);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	tailcall(ENTRY(mercury__map__search_3_1),
		ENTRY(mercury__vn_table__search_desired_value_3_0));
END_MODULE


BEGIN_MODULE(vn_table_module16)
	init_entry(mercury__vn_table__search_assigned_vn_3_0);
BEGIN_CODE

/* code for predicate 'search_assigned_vn'/3 in mode 0 */
Define_entry(mercury__vn_table__search_assigned_vn_3_0);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnrval_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	tailcall(ENTRY(mercury__map__search_3_1),
		ENTRY(mercury__vn_table__search_assigned_vn_3_0));
END_MODULE


BEGIN_MODULE(vn_table_module17)
	init_entry(mercury__vn_table__search_defn_3_0);
BEGIN_CODE

/* code for predicate 'search_defn'/3 in mode 0 */
Define_entry(mercury__vn_table__search_defn_3_0);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnrval_0;
	tailcall(ENTRY(mercury__map__search_3_1),
		ENTRY(mercury__vn_table__search_defn_3_0));
END_MODULE


BEGIN_MODULE(vn_table_module18)
	init_entry(mercury__vn_table__search_uses_3_0);
BEGIN_CODE

/* code for predicate 'search_uses'/3 in mode 0 */
Define_entry(mercury__vn_table__search_uses_3_0);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_table__common_0);
	tailcall(ENTRY(mercury__map__search_3_1),
		ENTRY(mercury__vn_table__search_uses_3_0));
END_MODULE


BEGIN_MODULE(vn_table_module19)
	init_entry(mercury__vn_table__search_current_locs_3_0);
BEGIN_CODE

/* code for predicate 'search_current_locs'/3 in mode 0 */
Define_entry(mercury__vn_table__search_current_locs_3_0);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_table__common_1);
	tailcall(ENTRY(mercury__map__search_3_1),
		ENTRY(mercury__vn_table__search_current_locs_3_0));
END_MODULE


BEGIN_MODULE(vn_table_module20)
	init_entry(mercury__vn_table__search_current_value_3_0);
BEGIN_CODE

/* code for predicate 'search_current_value'/3 in mode 0 */
Define_entry(mercury__vn_table__search_current_value_3_0);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	r4 = r1;
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	tailcall(ENTRY(mercury__map__search_3_1),
		ENTRY(mercury__vn_table__search_current_value_3_0));
END_MODULE

Declare_entry(mercury__map__to_assoc_list_2_0);

BEGIN_MODULE(vn_table_module21)
	init_entry(mercury__vn_table__get_vnlval_vn_list_2_0);
BEGIN_CODE

/* code for predicate 'get_vnlval_vn_list'/2 in mode 0 */
Define_entry(mercury__vn_table__get_vnlval_vn_list_2_0);
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	tailcall(ENTRY(mercury__map__to_assoc_list_2_0),
		ENTRY(mercury__vn_table__get_vnlval_vn_list_2_0));
END_MODULE

Declare_entry(mercury__map__det_update_4_0);

BEGIN_MODULE(vn_table_module22)
	init_entry(mercury__vn_table__add_new_use_4_0);
	init_label(mercury__vn_table__add_new_use_4_0_i3);
	init_label(mercury__vn_table__add_new_use_4_0_i2);
	init_label(mercury__vn_table__add_new_use_4_0_i5);
	init_label(mercury__vn_table__add_new_use_4_0_i7);
BEGIN_CODE

/* code for predicate 'add_new_use'/4 in mode 0 */
Define_entry(mercury__vn_table__add_new_use_4_0);
	MR_incr_sp_push_msg(10, "vn_table:add_new_use/4");
	MR_stackvar(10) = (Word) MR_succip;
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r3, (Integer) 2);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r3, (Integer) 3);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r3, (Integer) 5);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r3, (Integer) 6);
	r4 = r1;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r3 = MR_const_field(MR_mktag(0), r3, (Integer) 4);
	MR_stackvar(7) = r3;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_table__common_0);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__vn_table__add_new_use_4_0_i3,
		ENTRY(mercury__vn_table__add_new_use_4_0));
Define_label(mercury__vn_table__add_new_use_4_0_i3);
	update_prof_current_proc(LABEL(mercury__vn_table__add_new_use_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_table__add_new_use_4_0_i2);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__vn_table__add_new_use_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), r5, (Integer) 1) = r2;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_table__common_0);
	r3 = MR_stackvar(7);
	r4 = MR_stackvar(1);
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__vn_table__add_new_use_4_0_i7,
		ENTRY(mercury__vn_table__add_new_use_4_0));
Define_label(mercury__vn_table__add_new_use_4_0_i2);
	r1 = (Word) MR_string_const("cannot find old use set in add_new_use", 38);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_table__add_new_use_4_0_i5,
		ENTRY(mercury__vn_table__add_new_use_4_0));
Define_label(mercury__vn_table__add_new_use_4_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_table__add_new_use_4_0));
	r5 = r1;
	r1 = r2;
	r2 = r3;
	r3 = MR_stackvar(7);
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__vn_table__add_new_use_4_0_i7,
		ENTRY(mercury__vn_table__add_new_use_4_0));
Define_label(mercury__vn_table__add_new_use_4_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_table__add_new_use_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 7, mercury__vn_table__add_new_use_4_0, "vn_table:vn_tables/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(4);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_stackvar(5);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_stackvar(6);
	MR_field(MR_mktag(0), r1, (Integer) 4) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_stackvar(8);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_stackvar(9);
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
END_MODULE

Declare_entry(mercury__list__delete_first_3_0);

BEGIN_MODULE(vn_table_module23)
	init_entry(mercury__vn_table__del_old_use_4_0);
	init_label(mercury__vn_table__del_old_use_4_0_i3);
	init_label(mercury__vn_table__del_old_use_4_0_i2);
	init_label(mercury__vn_table__del_old_use_4_0_i5);
	init_label(mercury__vn_table__del_old_use_4_0_i6);
	init_label(mercury__vn_table__del_old_use_4_0_i8);
	init_label(mercury__vn_table__del_old_use_4_0_i7);
	init_label(mercury__vn_table__del_old_use_4_0_i11);
BEGIN_CODE

/* code for predicate 'del_old_use'/4 in mode 0 */
Define_entry(mercury__vn_table__del_old_use_4_0);
	MR_incr_sp_push_msg(11, "vn_table:del_old_use/4");
	MR_stackvar(11) = (Word) MR_succip;
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r3, (Integer) 2);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r3, (Integer) 3);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r3, (Integer) 5);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r3, (Integer) 6);
	r4 = r1;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r3 = MR_const_field(MR_mktag(0), r3, (Integer) 4);
	MR_stackvar(7) = r3;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_table__common_0);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__vn_table__del_old_use_4_0_i3,
		ENTRY(mercury__vn_table__del_old_use_4_0));
Define_label(mercury__vn_table__del_old_use_4_0_i3);
	update_prof_current_proc(LABEL(mercury__vn_table__del_old_use_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_table__del_old_use_4_0_i2);
	r3 = MR_stackvar(2);
	GOTO_LABEL(mercury__vn_table__del_old_use_4_0_i6);
Define_label(mercury__vn_table__del_old_use_4_0_i2);
	r1 = (Word) MR_string_const("cannot find old use set in add_new_use", 38);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_table__del_old_use_4_0_i5,
		ENTRY(mercury__vn_table__del_old_use_4_0));
Define_label(mercury__vn_table__del_old_use_4_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_table__del_old_use_4_0));
	r3 = MR_stackvar(2);
	r2 = MR_stackvar(10);
Define_label(mercury__vn_table__del_old_use_4_0_i6);
	MR_stackvar(10) = r2;
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vn_src_0;
	call_localret(ENTRY(mercury__list__delete_first_3_0),
		mercury__vn_table__del_old_use_4_0_i8,
		ENTRY(mercury__vn_table__del_old_use_4_0));
Define_label(mercury__vn_table__del_old_use_4_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_table__del_old_use_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_table__del_old_use_4_0_i7);
	r5 = r2;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_table__common_0);
	r3 = MR_stackvar(7);
	r4 = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__vn_table__del_old_use_4_0_i11,
		ENTRY(mercury__vn_table__del_old_use_4_0));
Define_label(mercury__vn_table__del_old_use_4_0_i7);
	r4 = MR_stackvar(1);
	r3 = MR_stackvar(7);
	r5 = MR_stackvar(10);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_table__common_0);
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__vn_table__del_old_use_4_0_i11,
		ENTRY(mercury__vn_table__del_old_use_4_0));
Define_label(mercury__vn_table__del_old_use_4_0_i11);
	update_prof_current_proc(LABEL(mercury__vn_table__del_old_use_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 7, mercury__vn_table__del_old_use_4_0, "vn_table:vn_tables/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(4);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_stackvar(5);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_stackvar(6);
	MR_field(MR_mktag(0), r1, (Integer) 4) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_stackvar(8);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_stackvar(9);
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	proceed();
END_MODULE


BEGIN_MODULE(vn_table_module24)
	init_entry(mercury__vn_table__del_old_uses_4_0);
	init_label(mercury__vn_table__del_old_uses_4_0_i1001);
	init_label(mercury__vn_table__del_old_uses_4_0_i4);
	init_label(mercury__vn_table__del_old_uses_4_0_i3);
BEGIN_CODE

/* code for predicate 'del_old_uses'/4 in mode 0 */
Define_entry(mercury__vn_table__del_old_uses_4_0);
	MR_incr_sp_push_msg(3, "vn_table:del_old_uses/4");
	MR_stackvar(3) = (Word) MR_succip;
Define_label(mercury__vn_table__del_old_uses_4_0_i1001);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_table__del_old_uses_4_0_i3);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__vn_table__del_old_use_4_0),
		mercury__vn_table__del_old_uses_4_0_i4,
		ENTRY(mercury__vn_table__del_old_uses_4_0));
Define_label(mercury__vn_table__del_old_uses_4_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_table__del_old_uses_4_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	GOTO_LABEL(mercury__vn_table__del_old_uses_4_0_i1001);
Define_label(mercury__vn_table__del_old_uses_4_0_i3);
	r1 = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE

Declare_entry(mercury__map__det_insert_4_0);

BEGIN_MODULE(vn_table_module25)
	init_entry(mercury__vn_table__record_first_vnrval_4_0);
	init_label(mercury__vn_table__record_first_vnrval_4_0_i2);
	init_label(mercury__vn_table__record_first_vnrval_4_0_i3);
	init_label(mercury__vn_table__record_first_vnrval_4_0_i4);
	init_label(mercury__vn_table__record_first_vnrval_4_0_i5);
BEGIN_CODE

/* code for predicate 'record_first_vnrval'/4 in mode 0 */
Define_entry(mercury__vn_table__record_first_vnrval_4_0);
	MR_incr_sp_push_msg(9, "vn_table:record_first_vnrval/4");
	MR_stackvar(9) = (Word) MR_succip;
	r5 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	r4 = r1;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r5;
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnrval_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	MR_stackvar(8) = ((Integer) r5 + (Integer) 1);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__vn_table__record_first_vnrval_4_0_i2,
		ENTRY(mercury__vn_table__record_first_vnrval_4_0));
Define_label(mercury__vn_table__record_first_vnrval_4_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_table__record_first_vnrval_4_0));
	r5 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnrval_0;
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__vn_table__record_first_vnrval_4_0_i3,
		ENTRY(mercury__vn_table__record_first_vnrval_4_0));
Define_label(mercury__vn_table__record_first_vnrval_4_0_i3);
	update_prof_current_proc(LABEL(mercury__vn_table__record_first_vnrval_4_0));
	MR_stackvar(4) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_table__common_0);
	r3 = MR_stackvar(5);
	r4 = MR_stackvar(2);
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__vn_table__record_first_vnrval_4_0_i4,
		ENTRY(mercury__vn_table__record_first_vnrval_4_0));
Define_label(mercury__vn_table__record_first_vnrval_4_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_table__record_first_vnrval_4_0));
	MR_stackvar(5) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_table__common_1);
	r3 = MR_stackvar(6);
	r4 = MR_stackvar(2);
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__vn_table__record_first_vnrval_4_0_i5,
		ENTRY(mercury__vn_table__record_first_vnrval_4_0));
Define_label(mercury__vn_table__record_first_vnrval_4_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_table__record_first_vnrval_4_0));
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 7, mercury__vn_table__record_first_vnrval_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 5) = r1;
	r1 = MR_stackvar(2);
	MR_field(MR_mktag(0), r2, (Integer) 6) = MR_stackvar(7);
	MR_field(MR_mktag(0), r2, (Integer) 4) = MR_stackvar(5);
	MR_field(MR_mktag(0), r2, (Integer) 3) = MR_stackvar(4);
	MR_field(MR_mktag(0), r2, (Integer) 2) = MR_stackvar(1);
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_stackvar(3);
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(8);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE

Declare_entry(mercury__map__insert_4_0);

BEGIN_MODULE(vn_table_module26)
	init_entry(mercury__vn_table__record_new_vnrval_4_0);
	init_label(mercury__vn_table__record_new_vnrval_4_0_i3);
	init_label(mercury__vn_table__record_new_vnrval_4_0_i2);
	init_label(mercury__vn_table__record_new_vnrval_4_0_i5);
	init_label(mercury__vn_table__record_new_vnrval_4_0_i6);
	init_label(mercury__vn_table__record_new_vnrval_4_0_i7);
	init_label(mercury__vn_table__record_new_vnrval_4_0_i8);
BEGIN_CODE

/* code for predicate 'record_new_vnrval'/4 in mode 0 */
Define_entry(mercury__vn_table__record_new_vnrval_4_0);
	MR_incr_sp_push_msg(13, "vn_table:record_new_vnrval/4");
	MR_stackvar(13) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	r5 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(4) = r3;
	r4 = r1;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r5;
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnrval_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	MR_stackvar(9) = ((Integer) r5 + (Integer) 1);
	call_localret(ENTRY(mercury__map__insert_4_0),
		mercury__vn_table__record_new_vnrval_4_0_i3,
		ENTRY(mercury__vn_table__record_new_vnrval_4_0));
Define_label(mercury__vn_table__record_new_vnrval_4_0_i3);
	update_prof_current_proc(LABEL(mercury__vn_table__record_new_vnrval_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_table__record_new_vnrval_4_0_i2);
	MR_stackvar(10) = r2;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnrval_0;
	r3 = MR_stackvar(5);
	r4 = MR_stackvar(2);
	r5 = MR_stackvar(1);
	GOTO_LABEL(mercury__vn_table__record_new_vnrval_4_0_i5);
Define_label(mercury__vn_table__record_new_vnrval_4_0_i2);
	r5 = MR_stackvar(1);
	r4 = MR_stackvar(2);
	r3 = MR_stackvar(5);
	MR_stackvar(10) = MR_stackvar(4);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnrval_0;
Define_label(mercury__vn_table__record_new_vnrval_4_0_i5);
	MR_stackvar(2) = r4;
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__vn_table__record_new_vnrval_4_0_i6,
		ENTRY(mercury__vn_table__record_new_vnrval_4_0));
Define_label(mercury__vn_table__record_new_vnrval_4_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_table__record_new_vnrval_4_0));
	MR_stackvar(11) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_table__common_0);
	r3 = MR_stackvar(6);
	r4 = MR_stackvar(2);
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__vn_table__record_new_vnrval_4_0_i7,
		ENTRY(mercury__vn_table__record_new_vnrval_4_0));
Define_label(mercury__vn_table__record_new_vnrval_4_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_table__record_new_vnrval_4_0));
	MR_stackvar(12) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_table__common_1);
	r3 = MR_stackvar(7);
	r4 = MR_stackvar(2);
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__vn_table__record_new_vnrval_4_0_i8,
		ENTRY(mercury__vn_table__record_new_vnrval_4_0));
Define_label(mercury__vn_table__record_new_vnrval_4_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_table__record_new_vnrval_4_0));
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 7, mercury__vn_table__record_new_vnrval_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r2, (Integer) 5) = r1;
	r1 = MR_stackvar(2);
	MR_field(MR_mktag(0), r2, (Integer) 6) = MR_stackvar(8);
	MR_field(MR_mktag(0), r2, (Integer) 4) = MR_stackvar(12);
	MR_field(MR_mktag(0), r2, (Integer) 3) = MR_stackvar(11);
	MR_field(MR_mktag(0), r2, (Integer) 2) = MR_stackvar(10);
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_stackvar(3);
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(9);
	MR_succip = (Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	proceed();
END_MODULE


BEGIN_MODULE(vn_table_module27)
	init_entry(mercury__vn_table__record_first_vnlval_4_0);
	init_label(mercury__vn_table__record_first_vnlval_4_0_i2);
	init_label(mercury__vn_table__record_first_vnlval_4_0_i3);
	init_label(mercury__vn_table__record_first_vnlval_4_0_i4);
	init_label(mercury__vn_table__record_first_vnlval_4_0_i5);
	init_label(mercury__vn_table__record_first_vnlval_4_0_i6);
	init_label(mercury__vn_table__record_first_vnlval_4_0_i7);
BEGIN_CODE

/* code for predicate 'record_first_vnlval'/4 in mode 0 */
Define_entry(mercury__vn_table__record_first_vnlval_4_0);
	MR_incr_sp_push_msg(10, "vn_table:record_first_vnlval/4");
	MR_stackvar(10) = (Word) MR_succip;
	r5 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r4 = r1;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r5;
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	MR_stackvar(8) = ((Integer) r5 + (Integer) 1);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__vn_table__record_first_vnlval_4_0_i2,
		ENTRY(mercury__vn_table__record_first_vnlval_4_0));
Define_label(mercury__vn_table__record_first_vnlval_4_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_table__record_first_vnlval_4_0));
	r3 = MR_stackvar(3);
	tag_incr_hp_msg(r4, MR_mktag(0), (Integer) 1, mercury__vn_table__record_first_vnlval_4_0, "origin_lost_in_value_number");
	MR_stackvar(3) = r1;
	MR_stackvar(9) = r4;
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnrval_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r5 = MR_stackvar(2);
	MR_field(MR_mktag(0), r4, (Integer) 0) = MR_stackvar(1);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__vn_table__record_first_vnlval_4_0_i3,
		ENTRY(mercury__vn_table__record_first_vnlval_4_0));
Define_label(mercury__vn_table__record_first_vnlval_4_0_i3);
	update_prof_current_proc(LABEL(mercury__vn_table__record_first_vnlval_4_0));
	r3 = MR_stackvar(4);
	MR_stackvar(4) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnrval_0;
	r4 = MR_stackvar(2);
	r5 = MR_stackvar(9);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__vn_table__record_first_vnlval_4_0_i4,
		ENTRY(mercury__vn_table__record_first_vnlval_4_0));
Define_label(mercury__vn_table__record_first_vnlval_4_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_table__record_first_vnlval_4_0));
	r3 = MR_stackvar(5);
	MR_stackvar(5) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_table__common_0);
	r4 = MR_stackvar(2);
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__vn_table__record_first_vnlval_4_0_i5,
		ENTRY(mercury__vn_table__record_first_vnlval_4_0));
Define_label(mercury__vn_table__record_first_vnlval_4_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_table__record_first_vnlval_4_0));
	r3 = MR_stackvar(6);
	MR_stackvar(6) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_table__common_1);
	r4 = MR_stackvar(2);
	tag_incr_hp_msg(r5, MR_mktag(1), (Integer) 2, mercury__vn_table__record_first_vnlval_4_0, "list:list/1");
	MR_field(MR_mktag(1), r5, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r5, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__vn_table__record_first_vnlval_4_0_i6,
		ENTRY(mercury__vn_table__record_first_vnlval_4_0));
Define_label(mercury__vn_table__record_first_vnlval_4_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_table__record_first_vnlval_4_0));
	r4 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = MR_stackvar(7);
	r5 = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__vn_table__record_first_vnlval_4_0_i7,
		ENTRY(mercury__vn_table__record_first_vnlval_4_0));
Define_label(mercury__vn_table__record_first_vnlval_4_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_table__record_first_vnlval_4_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 7, mercury__vn_table__record_first_vnlval_4_0, "vn_table:vn_tables/0");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(8);
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_stackvar(3);
	MR_field(MR_mktag(0), r2, (Integer) 2) = MR_stackvar(4);
	MR_field(MR_mktag(0), r2, (Integer) 3) = MR_stackvar(5);
	MR_field(MR_mktag(0), r2, (Integer) 4) = MR_stackvar(6);
	MR_field(MR_mktag(0), r2, (Integer) 5) = MR_stackvar(1);
	MR_field(MR_mktag(0), r2, (Integer) 6) = r3;
	MR_succip = (Code *) MR_stackvar(10);
	MR_decr_sp_pop_msg(10);
	proceed();
END_MODULE

Declare_entry(mercury__map__set_4_1);

BEGIN_MODULE(vn_table_module28)
	init_entry(mercury__vn_table__set_desired_value_4_0);
	init_label(mercury__vn_table__set_desired_value_4_0_i3);
	init_label(mercury__vn_table__set_desired_value_4_0_i5);
	init_label(mercury__vn_table__set_desired_value_4_0_i2);
	init_label(mercury__vn_table__set_desired_value_4_0_i6);
	init_label(mercury__vn_table__set_desired_value_4_0_i7);
BEGIN_CODE

/* code for predicate 'set_desired_value'/4 in mode 0 */
Define_entry(mercury__vn_table__set_desired_value_4_0);
	MR_incr_sp_push_msg(11, "vn_table:set_desired_value/4");
	MR_stackvar(11) = (Word) MR_succip;
	MR_stackvar(3) = r3;
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r3, (Integer) 2);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r3, (Integer) 3);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r3, (Integer) 4);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r3, (Integer) 5);
	r4 = r1;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r3 = MR_const_field(MR_mktag(0), r3, (Integer) 6);
	MR_stackvar(10) = r3;
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__vn_table__set_desired_value_4_0_i3,
		ENTRY(mercury__vn_table__set_desired_value_4_0));
Define_label(mercury__vn_table__set_desired_value_4_0_i3);
	update_prof_current_proc(LABEL(mercury__vn_table__set_desired_value_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_table__set_desired_value_4_0_i2);
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = MR_stackvar(5);
	r4 = MR_stackvar(1);
	r5 = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__vn_table__set_desired_value_4_0_i5,
		ENTRY(mercury__vn_table__set_desired_value_4_0));
Define_label(mercury__vn_table__set_desired_value_4_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_table__set_desired_value_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 7, mercury__vn_table__set_desired_value_4_0, "vn_table:vn_tables/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(0), r1, (Integer) 1) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_stackvar(6);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_stackvar(7);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_stackvar(8);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_stackvar(9);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_stackvar(10);
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	proceed();
Define_label(mercury__vn_table__set_desired_value_4_0_i2);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(3);
	call_localret(STATIC(mercury__vn_table__record_first_vnlval_4_0),
		mercury__vn_table__set_desired_value_4_0_i6,
		ENTRY(mercury__vn_table__set_desired_value_4_0));
Define_label(mercury__vn_table__set_desired_value_4_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_table__set_desired_value_4_0));
	r4 = MR_stackvar(1);
	r5 = MR_stackvar(2);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__vn_table__set_desired_value_4_0_i7,
		ENTRY(mercury__vn_table__set_desired_value_4_0));
Define_label(mercury__vn_table__set_desired_value_4_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_table__set_desired_value_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 7, mercury__vn_table__set_desired_value_4_0, "vn_table:vn_tables/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(0), r1, (Integer) 1) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_stackvar(3);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_stackvar(4);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_stackvar(5);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	proceed();
END_MODULE

Declare_entry(mercury__map__lookup_3_0);
Declare_entry(mercury__list__delete_all_3_1);
Declare_entry(mercury__list__append_3_1);

BEGIN_MODULE(vn_table_module29)
	init_entry(mercury__vn_table__set_current_value_4_0);
	init_label(mercury__vn_table__set_current_value_4_0_i3);
	init_label(mercury__vn_table__set_current_value_4_0_i5);
	init_label(mercury__vn_table__set_current_value_4_0_i6);
	init_label(mercury__vn_table__set_current_value_4_0_i7);
	init_label(mercury__vn_table__set_current_value_4_0_i8);
	init_label(mercury__vn_table__set_current_value_4_0_i9);
	init_label(mercury__vn_table__set_current_value_4_0_i10);
	init_label(mercury__vn_table__set_current_value_4_0_i11);
	init_label(mercury__vn_table__set_current_value_4_0_i2);
	init_label(mercury__vn_table__set_current_value_4_0_i12);
	init_label(mercury__vn_table__set_current_value_4_0_i13);
	init_label(mercury__vn_table__set_current_value_4_0_i14);
	init_label(mercury__vn_table__set_current_value_4_0_i15);
BEGIN_CODE

/* code for predicate 'set_current_value'/4 in mode 0 */
Define_entry(mercury__vn_table__set_current_value_4_0);
	MR_incr_sp_push_msg(12, "vn_table:set_current_value/4");
	MR_stackvar(12) = (Word) MR_succip;
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r3, (Integer) 1);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r3, (Integer) 2);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r3, (Integer) 3);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r3, (Integer) 4);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r3, (Integer) 5);
	r4 = r1;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r3 = MR_const_field(MR_mktag(0), r3, (Integer) 6);
	MR_stackvar(9) = r3;
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__vn_table__set_current_value_4_0_i3,
		ENTRY(mercury__vn_table__set_current_value_4_0));
Define_label(mercury__vn_table__set_current_value_4_0_i3);
	update_prof_current_proc(LABEL(mercury__vn_table__set_current_value_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_table__set_current_value_4_0_i2);
	MR_stackvar(10) = r2;
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = MR_stackvar(9);
	r4 = MR_stackvar(1);
	r5 = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__vn_table__set_current_value_4_0_i5,
		ENTRY(mercury__vn_table__set_current_value_4_0));
Define_label(mercury__vn_table__set_current_value_4_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_table__set_current_value_4_0));
	MR_stackvar(11) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_table__common_1);
	r3 = MR_stackvar(8);
	r4 = MR_stackvar(10);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__vn_table__set_current_value_4_0_i6,
		ENTRY(mercury__vn_table__set_current_value_4_0));
Define_label(mercury__vn_table__set_current_value_4_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_table__set_current_value_4_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0;
	r3 = MR_stackvar(1);
	call_localret(ENTRY(mercury__list__delete_all_3_1),
		mercury__vn_table__set_current_value_4_0_i7,
		ENTRY(mercury__vn_table__set_current_value_4_0));
Define_label(mercury__vn_table__set_current_value_4_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_table__set_current_value_4_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_table__common_1);
	r3 = MR_stackvar(8);
	r4 = MR_stackvar(10);
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__vn_table__set_current_value_4_0_i8,
		ENTRY(mercury__vn_table__set_current_value_4_0));
Define_label(mercury__vn_table__set_current_value_4_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_table__set_current_value_4_0));
	r3 = r1;
	MR_stackvar(10) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_table__common_1);
	r4 = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__vn_table__set_current_value_4_0_i9,
		ENTRY(mercury__vn_table__set_current_value_4_0));
Define_label(mercury__vn_table__set_current_value_4_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_table__set_current_value_4_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__vn_table__set_current_value_4_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__vn_table__set_current_value_4_0_i10,
		ENTRY(mercury__vn_table__set_current_value_4_0));
Define_label(mercury__vn_table__set_current_value_4_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_table__set_current_value_4_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_table__common_1);
	r3 = MR_stackvar(10);
	r4 = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__vn_table__set_current_value_4_0_i11,
		ENTRY(mercury__vn_table__set_current_value_4_0));
Define_label(mercury__vn_table__set_current_value_4_0_i11);
	update_prof_current_proc(LABEL(mercury__vn_table__set_current_value_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 7, mercury__vn_table__set_current_value_4_0, "vn_table:vn_tables/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(4);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_stackvar(5);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_stackvar(6);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_stackvar(7);
	MR_field(MR_mktag(0), r1, (Integer) 5) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_stackvar(11);
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	proceed();
Define_label(mercury__vn_table__set_current_value_4_0_i2);
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = MR_stackvar(9);
	r4 = MR_stackvar(1);
	r5 = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__det_insert_4_0),
		mercury__vn_table__set_current_value_4_0_i12,
		ENTRY(mercury__vn_table__set_current_value_4_0));
Define_label(mercury__vn_table__set_current_value_4_0_i12);
	update_prof_current_proc(LABEL(mercury__vn_table__set_current_value_4_0));
	MR_stackvar(9) = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_table__common_1);
	r3 = MR_stackvar(8);
	r4 = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__lookup_3_0),
		mercury__vn_table__set_current_value_4_0_i13,
		ENTRY(mercury__vn_table__set_current_value_4_0));
Define_label(mercury__vn_table__set_current_value_4_0_i13);
	update_prof_current_proc(LABEL(mercury__vn_table__set_current_value_4_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__vn_table__set_current_value_4_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__vn_table__set_current_value_4_0_i14,
		ENTRY(mercury__vn_table__set_current_value_4_0));
Define_label(mercury__vn_table__set_current_value_4_0_i14);
	update_prof_current_proc(LABEL(mercury__vn_table__set_current_value_4_0));
	r5 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_table__common_1);
	r3 = MR_stackvar(8);
	r4 = MR_stackvar(2);
	call_localret(ENTRY(mercury__map__det_update_4_0),
		mercury__vn_table__set_current_value_4_0_i15,
		ENTRY(mercury__vn_table__set_current_value_4_0));
Define_label(mercury__vn_table__set_current_value_4_0_i15);
	update_prof_current_proc(LABEL(mercury__vn_table__set_current_value_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 7, mercury__vn_table__set_current_value_4_0, "vn_table:vn_tables/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(3);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(4);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_stackvar(5);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_stackvar(6);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_stackvar(7);
	MR_field(MR_mktag(0), r1, (Integer) 5) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_stackvar(9);
	MR_succip = (Code *) MR_stackvar(12);
	MR_decr_sp_pop_msg(12);
	proceed();
END_MODULE


BEGIN_MODULE(vn_table_module30)
	init_entry(mercury__vn_table__set_parallel_value_4_0);
	init_label(mercury__vn_table__set_parallel_value_4_0_i2);
BEGIN_CODE

/* code for predicate 'set_parallel_value'/4 in mode 0 */
Define_entry(mercury__vn_table__set_parallel_value_4_0);
	MR_incr_sp_push_msg(3, "vn_table:set_parallel_value/4");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	call_localret(STATIC(mercury__vn_table__set_desired_value_4_0),
		mercury__vn_table__set_parallel_value_4_0_i2,
		ENTRY(mercury__vn_table__set_parallel_value_4_0));
Define_label(mercury__vn_table__set_parallel_value_4_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_table__set_parallel_value_4_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__vn_table__set_current_value_4_0),
		ENTRY(mercury__vn_table__set_parallel_value_4_0));
END_MODULE

Declare_entry(mercury__map__keys_2_0);

BEGIN_MODULE(vn_table_module31)
	init_entry(mercury__vn_table__get_all_vnrvals_2_0);
BEGIN_CODE

/* code for predicate 'get_all_vnrvals'/2 in mode 0 */
Define_entry(mercury__vn_table__get_all_vnrvals_2_0);
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnrval_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	tailcall(ENTRY(mercury__map__keys_2_0),
		ENTRY(mercury__vn_table__get_all_vnrvals_2_0));
END_MODULE

Declare_entry(mercury____Unify___tree234__tree234_2_0);

BEGIN_MODULE(vn_table_module32)
	init_entry(mercury____Unify___vn_table__vn_tables_0_0);
	init_label(mercury____Unify___vn_table__vn_tables_0_0_i2);
	init_label(mercury____Unify___vn_table__vn_tables_0_0_i4);
	init_label(mercury____Unify___vn_table__vn_tables_0_0_i6);
	init_label(mercury____Unify___vn_table__vn_tables_0_0_i8);
	init_label(mercury____Unify___vn_table__vn_tables_0_0_i10);
	init_label(mercury____Unify___vn_table__vn_tables_0_0_i1007);
	init_label(mercury____Unify___vn_table__vn_tables_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___vn_table__vn_tables_0_0);
	MR_incr_sp_push_msg(11, "vn_table:__Unify__/2");
	MR_stackvar(11) = (Word) MR_succip;
	if ((MR_const_field(MR_mktag(0), r1, (Integer) 0) != MR_const_field(MR_mktag(0), r2, (Integer) 0)))
		GOTO_LABEL(mercury____Unify___vn_table__vn_tables_0_0_i1007);
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r4 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 5);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 6);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___vn_table__vn_tables_0_0_i2,
		ENTRY(mercury____Unify___vn_table__vn_tables_0_0));
Define_label(mercury____Unify___vn_table__vn_tables_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___vn_table__vn_tables_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___vn_table__vn_tables_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnrval_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(6);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___vn_table__vn_tables_0_0_i4,
		ENTRY(mercury____Unify___vn_table__vn_tables_0_0));
Define_label(mercury____Unify___vn_table__vn_tables_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___vn_table__vn_tables_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___vn_table__vn_tables_0_0_i1);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnrval_0;
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(7);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___vn_table__vn_tables_0_0_i6,
		ENTRY(mercury____Unify___vn_table__vn_tables_0_0));
Define_label(mercury____Unify___vn_table__vn_tables_0_0_i6);
	update_prof_current_proc(LABEL(mercury____Unify___vn_table__vn_tables_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___vn_table__vn_tables_0_0_i1);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_table__common_0);
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(8);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___vn_table__vn_tables_0_0_i8,
		ENTRY(mercury____Unify___vn_table__vn_tables_0_0));
Define_label(mercury____Unify___vn_table__vn_tables_0_0_i8);
	update_prof_current_proc(LABEL(mercury____Unify___vn_table__vn_tables_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___vn_table__vn_tables_0_0_i1);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_table__common_1);
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(9);
	call_localret(ENTRY(mercury____Unify___tree234__tree234_2_0),
		mercury____Unify___vn_table__vn_tables_0_0_i10,
		ENTRY(mercury____Unify___vn_table__vn_tables_0_0));
Define_label(mercury____Unify___vn_table__vn_tables_0_0_i10);
	update_prof_current_proc(LABEL(mercury____Unify___vn_table__vn_tables_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___vn_table__vn_tables_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = MR_stackvar(5);
	r4 = MR_stackvar(10);
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___vn_table__vn_tables_0_0));
Define_label(mercury____Unify___vn_table__vn_tables_0_0_i1007);
	r1 = FALSE;
	MR_decr_sp_pop_msg(11);
	proceed();
Define_label(mercury____Unify___vn_table__vn_tables_0_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	proceed();
END_MODULE


BEGIN_MODULE(vn_table_module33)
	init_entry(mercury____Index___vn_table__vn_tables_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___vn_table__vn_tables_0_0);
	tailcall(STATIC(mercury____Index___vn_table__vn_tables_0__ua0_2_0),
		ENTRY(mercury____Index___vn_table__vn_tables_0_0));
END_MODULE

Declare_entry(mercury__builtin_compare_int_3_0);
Declare_entry(mercury____Compare___tree234__tree234_2_0);

BEGIN_MODULE(vn_table_module34)
	init_entry(mercury____Compare___vn_table__vn_tables_0_0);
	init_label(mercury____Compare___vn_table__vn_tables_0_0_i3);
	init_label(mercury____Compare___vn_table__vn_tables_0_0_i7);
	init_label(mercury____Compare___vn_table__vn_tables_0_0_i11);
	init_label(mercury____Compare___vn_table__vn_tables_0_0_i15);
	init_label(mercury____Compare___vn_table__vn_tables_0_0_i19);
	init_label(mercury____Compare___vn_table__vn_tables_0_0_i23);
	init_label(mercury____Compare___vn_table__vn_tables_0_0_i32);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___vn_table__vn_tables_0_0);
	MR_incr_sp_push_msg(13, "vn_table:__Compare__/3");
	MR_stackvar(13) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 5);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r1, (Integer) 6);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(11) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_stackvar(12) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___vn_table__vn_tables_0_0_i3,
		ENTRY(mercury____Compare___vn_table__vn_tables_0_0));
Define_label(mercury____Compare___vn_table__vn_tables_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___vn_table__vn_tables_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___vn_table__vn_tables_0_0_i32);
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = MR_stackvar(1);
	r4 = MR_stackvar(7);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___vn_table__vn_tables_0_0_i7,
		ENTRY(mercury____Compare___vn_table__vn_tables_0_0));
Define_label(mercury____Compare___vn_table__vn_tables_0_0_i7);
	update_prof_current_proc(LABEL(mercury____Compare___vn_table__vn_tables_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___vn_table__vn_tables_0_0_i32);
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnrval_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(8);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___vn_table__vn_tables_0_0_i11,
		ENTRY(mercury____Compare___vn_table__vn_tables_0_0));
Define_label(mercury____Compare___vn_table__vn_tables_0_0_i11);
	update_prof_current_proc(LABEL(mercury____Compare___vn_table__vn_tables_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___vn_table__vn_tables_0_0_i32);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnrval_0;
	r3 = MR_stackvar(3);
	r4 = MR_stackvar(9);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___vn_table__vn_tables_0_0_i15,
		ENTRY(mercury____Compare___vn_table__vn_tables_0_0));
Define_label(mercury____Compare___vn_table__vn_tables_0_0_i15);
	update_prof_current_proc(LABEL(mercury____Compare___vn_table__vn_tables_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___vn_table__vn_tables_0_0_i32);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_table__common_0);
	r3 = MR_stackvar(4);
	r4 = MR_stackvar(10);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___vn_table__vn_tables_0_0_i19,
		ENTRY(mercury____Compare___vn_table__vn_tables_0_0));
Define_label(mercury____Compare___vn_table__vn_tables_0_0_i19);
	update_prof_current_proc(LABEL(mercury____Compare___vn_table__vn_tables_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___vn_table__vn_tables_0_0_i32);
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_table__common_1);
	r3 = MR_stackvar(5);
	r4 = MR_stackvar(11);
	call_localret(ENTRY(mercury____Compare___tree234__tree234_2_0),
		mercury____Compare___vn_table__vn_tables_0_0_i23,
		ENTRY(mercury____Compare___vn_table__vn_tables_0_0));
Define_label(mercury____Compare___vn_table__vn_tables_0_0_i23);
	update_prof_current_proc(LABEL(mercury____Compare___vn_table__vn_tables_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___vn_table__vn_tables_0_0_i32);
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r3 = MR_stackvar(6);
	r4 = MR_stackvar(12);
	MR_succip = (Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___vn_table__vn_tables_0_0));
Define_label(mercury____Compare___vn_table__vn_tables_0_0_i32);
	MR_succip = (Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	proceed();
END_MODULE


BEGIN_MODULE(vn_table_module35)
	init_entry(mercury____Unify___vn_table__lval_to_vn_table_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___vn_table__lval_to_vn_table_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0;
	r4 = r2;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___vn_table__lval_to_vn_table_0_0));
END_MODULE

Declare_entry(mercury____Index___tree234__tree234_2_0);

BEGIN_MODULE(vn_table_module36)
	init_entry(mercury____Index___vn_table__lval_to_vn_table_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___vn_table__lval_to_vn_table_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		ENTRY(mercury____Index___vn_table__lval_to_vn_table_0_0));
END_MODULE


BEGIN_MODULE(vn_table_module37)
	init_entry(mercury____Compare___vn_table__lval_to_vn_table_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___vn_table__lval_to_vn_table_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0;
	r4 = r2;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___vn_table__lval_to_vn_table_0_0));
END_MODULE


BEGIN_MODULE(vn_table_module38)
	init_entry(mercury____Unify___vn_table__rval_to_vn_table_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___vn_table__rval_to_vn_table_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnrval_0;
	r4 = r2;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___vn_table__rval_to_vn_table_0_0));
END_MODULE


BEGIN_MODULE(vn_table_module39)
	init_entry(mercury____Index___vn_table__rval_to_vn_table_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___vn_table__rval_to_vn_table_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnrval_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		ENTRY(mercury____Index___vn_table__rval_to_vn_table_0_0));
END_MODULE


BEGIN_MODULE(vn_table_module40)
	init_entry(mercury____Compare___vn_table__rval_to_vn_table_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___vn_table__rval_to_vn_table_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnrval_0;
	r4 = r2;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___vn_table__rval_to_vn_table_0_0));
END_MODULE


BEGIN_MODULE(vn_table_module41)
	init_entry(mercury____Unify___vn_table__vn_to_rval_table_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___vn_table__vn_to_rval_table_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r4 = r2;
	r2 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnrval_0;
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___vn_table__vn_to_rval_table_0_0));
END_MODULE


BEGIN_MODULE(vn_table_module42)
	init_entry(mercury____Index___vn_table__vn_to_rval_table_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___vn_table__vn_to_rval_table_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnrval_0;
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		ENTRY(mercury____Index___vn_table__vn_to_rval_table_0_0));
END_MODULE


BEGIN_MODULE(vn_table_module43)
	init_entry(mercury____Compare___vn_table__vn_to_rval_table_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___vn_table__vn_to_rval_table_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r4 = r2;
	r2 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnrval_0;
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___vn_table__vn_to_rval_table_0_0));
END_MODULE


BEGIN_MODULE(vn_table_module44)
	init_entry(mercury____Unify___vn_table__vn_to_uses_table_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___vn_table__vn_to_uses_table_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_table__common_0);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___vn_table__vn_to_uses_table_0_0));
END_MODULE


BEGIN_MODULE(vn_table_module45)
	init_entry(mercury____Index___vn_table__vn_to_uses_table_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___vn_table__vn_to_uses_table_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_table__common_0);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		ENTRY(mercury____Index___vn_table__vn_to_uses_table_0_0));
END_MODULE


BEGIN_MODULE(vn_table_module46)
	init_entry(mercury____Compare___vn_table__vn_to_uses_table_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___vn_table__vn_to_uses_table_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_table__common_0);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___vn_table__vn_to_uses_table_0_0));
END_MODULE


BEGIN_MODULE(vn_table_module47)
	init_entry(mercury____Unify___vn_table__vn_to_locs_table_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___vn_table__vn_to_locs_table_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_table__common_1);
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___vn_table__vn_to_locs_table_0_0));
END_MODULE


BEGIN_MODULE(vn_table_module48)
	init_entry(mercury____Index___vn_table__vn_to_locs_table_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___vn_table__vn_to_locs_table_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_table__common_1);
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		ENTRY(mercury____Index___vn_table__vn_to_locs_table_0_0));
END_MODULE


BEGIN_MODULE(vn_table_module49)
	init_entry(mercury____Compare___vn_table__vn_to_locs_table_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___vn_table__vn_to_locs_table_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r4 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_table__common_1);
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___vn_table__vn_to_locs_table_0_0));
END_MODULE


BEGIN_MODULE(vn_table_module50)
	init_entry(mercury____Unify___vn_table__loc_to_vn_table_0_0);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___vn_table__loc_to_vn_table_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0;
	r4 = r2;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	tailcall(ENTRY(mercury____Unify___tree234__tree234_2_0),
		ENTRY(mercury____Unify___vn_table__loc_to_vn_table_0_0));
END_MODULE


BEGIN_MODULE(vn_table_module51)
	init_entry(mercury____Index___vn_table__loc_to_vn_table_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___vn_table__loc_to_vn_table_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	tailcall(ENTRY(mercury____Index___tree234__tree234_2_0),
		ENTRY(mercury____Index___vn_table__loc_to_vn_table_0_0));
END_MODULE


BEGIN_MODULE(vn_table_module52)
	init_entry(mercury____Compare___vn_table__loc_to_vn_table_0_0);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___vn_table__loc_to_vn_table_0_0);
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0;
	r4 = r2;
	r2 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	tailcall(ENTRY(mercury____Compare___tree234__tree234_2_0),
		ENTRY(mercury____Compare___vn_table__loc_to_vn_table_0_0));
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__vn_table_maybe_bunch_0(void)
{
	vn_table_module0();
	vn_table_module1();
	vn_table_module2();
	vn_table_module3();
	vn_table_module4();
	vn_table_module5();
	vn_table_module6();
	vn_table_module7();
	vn_table_module8();
	vn_table_module9();
	vn_table_module10();
	vn_table_module11();
	vn_table_module12();
	vn_table_module13();
	vn_table_module14();
	vn_table_module15();
	vn_table_module16();
	vn_table_module17();
	vn_table_module18();
	vn_table_module19();
	vn_table_module20();
	vn_table_module21();
	vn_table_module22();
	vn_table_module23();
	vn_table_module24();
	vn_table_module25();
	vn_table_module26();
	vn_table_module27();
	vn_table_module28();
	vn_table_module29();
	vn_table_module30();
	vn_table_module31();
	vn_table_module32();
	vn_table_module33();
	vn_table_module34();
	vn_table_module35();
	vn_table_module36();
	vn_table_module37();
	vn_table_module38();
	vn_table_module39();
}

static void mercury__vn_table_maybe_bunch_1(void)
{
	vn_table_module40();
	vn_table_module41();
	vn_table_module42();
	vn_table_module43();
	vn_table_module44();
	vn_table_module45();
	vn_table_module46();
	vn_table_module47();
	vn_table_module48();
	vn_table_module49();
	vn_table_module50();
	vn_table_module51();
	vn_table_module52();
}

#endif

void mercury__vn_table__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__vn_table__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__vn_table_maybe_bunch_0();
		mercury__vn_table_maybe_bunch_1();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_vn_table__type_ctor_info_loc_to_vn_table_0,
			vn_table__loc_to_vn_table_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_vn_table__type_ctor_info_lval_to_vn_table_0,
			vn_table__lval_to_vn_table_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_vn_table__type_ctor_info_rval_to_vn_table_0,
			vn_table__rval_to_vn_table_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_vn_table__type_ctor_info_vn_tables_0,
			vn_table__vn_tables_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_vn_table__type_ctor_info_vn_to_locs_table_0,
			vn_table__vn_to_locs_table_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_vn_table__type_ctor_info_vn_to_rval_table_0,
			vn_table__vn_to_rval_table_0_0);
		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_vn_table__type_ctor_info_vn_to_uses_table_0,
			vn_table__vn_to_uses_table_0_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
