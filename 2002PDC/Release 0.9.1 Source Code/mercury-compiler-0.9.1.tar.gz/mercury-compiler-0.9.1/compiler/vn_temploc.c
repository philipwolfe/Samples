/*
** Automatically generated from `vn_temploc.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__vn_temploc__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury____Index___vn_temploc__templocs_0__ua0_2_0);
Define_extern_entry(mercury__vn_temploc__init_templocs_4_0);
Declare_label(mercury__vn_temploc__init_templocs_4_0_i2);
Declare_label(mercury__vn_temploc__init_templocs_4_0_i3);
Declare_label(mercury__vn_temploc__init_templocs_4_0_i4);
Declare_label(mercury__vn_temploc__init_templocs_4_0_i5);
Declare_label(mercury__vn_temploc__init_templocs_4_0_i6);
Declare_label(mercury__vn_temploc__init_templocs_4_0_i7);
Declare_label(mercury__vn_temploc__init_templocs_4_0_i8);
Declare_label(mercury__vn_temploc__init_templocs_4_0_i9);
Declare_label(mercury__vn_temploc__init_templocs_4_0_i10);
Declare_label(mercury__vn_temploc__init_templocs_4_0_i11);
Define_extern_entry(mercury__vn_temploc__next_tempr_3_0);
Declare_label(mercury__vn_temploc__next_tempr_3_0_i2);
Declare_label(mercury__vn_temploc__next_tempr_3_0_i4);
Declare_label(mercury__vn_temploc__next_tempr_3_0_i5);
Define_extern_entry(mercury__vn_temploc__next_tempf_3_0);
Declare_label(mercury__vn_temploc__next_tempf_3_0_i2);
Declare_label(mercury__vn_temploc__next_tempf_3_0_i4);
Declare_label(mercury__vn_temploc__next_tempf_3_0_i5);
Define_extern_entry(mercury__vn_temploc__no_temploc_3_0);
Declare_label(mercury__vn_temploc__no_temploc_3_0_i2);
Declare_label(mercury__vn_temploc__no_temploc_3_0_i3);
Define_extern_entry(mercury__vn_temploc__reuse_templocs_3_0);
Declare_label(mercury__vn_temploc__reuse_templocs_3_0_i1011);
Declare_label(mercury__vn_temploc__reuse_templocs_3_0_i5);
Declare_label(mercury__vn_temploc__reuse_templocs_3_0_i1001);
Declare_label(mercury__vn_temploc__reuse_templocs_3_0_i4);
Declare_label(mercury__vn_temploc__reuse_templocs_3_0_i9);
Declare_label(mercury__vn_temploc__reuse_templocs_3_0_i8);
Declare_label(mercury__vn_temploc__reuse_templocs_3_0_i13);
Declare_label(mercury__vn_temploc__reuse_templocs_3_0_i7);
Declare_label(mercury__vn_temploc__reuse_templocs_3_0_i16);
Declare_label(mercury__vn_temploc__reuse_templocs_3_0_i15);
Declare_label(mercury__vn_temploc__reuse_templocs_3_0_i20);
Declare_label(mercury__vn_temploc__reuse_templocs_3_0_i3);
Define_extern_entry(mercury__vn_temploc__max_tempr_2_0);
Define_extern_entry(mercury__vn_temploc__max_tempf_2_0);
Declare_static(mercury__vn_temploc__find_free_r_regs_5_0);
Declare_label(mercury__vn_temploc__find_free_r_regs_5_0_i2);
Declare_label(mercury__vn_temploc__find_free_r_regs_5_0_i3);
Declare_label(mercury__vn_temploc__find_free_r_regs_5_0_i5);
Declare_label(mercury__vn_temploc__find_free_r_regs_5_0_i1010);
Declare_label(mercury__vn_temploc__find_free_r_regs_5_0_i8);
Declare_label(mercury__vn_temploc__find_free_r_regs_5_0_i11);
Declare_label(mercury__vn_temploc__find_free_r_regs_5_0_i1015);
Declare_static(mercury__vn_temploc__find_free_f_regs_5_0);
Declare_label(mercury__vn_temploc__find_free_f_regs_5_0_i2);
Declare_label(mercury__vn_temploc__find_free_f_regs_5_0_i3);
Declare_label(mercury__vn_temploc__find_free_f_regs_5_0_i5);
Declare_label(mercury__vn_temploc__find_free_f_regs_5_0_i1010);
Declare_label(mercury__vn_temploc__find_free_f_regs_5_0_i8);
Declare_label(mercury__vn_temploc__find_free_f_regs_5_0_i11);
Declare_label(mercury__vn_temploc__find_free_f_regs_5_0_i1015);
Declare_static(mercury__vn_temploc__get_n_r_temps_3_0);
Declare_label(mercury__vn_temploc__get_n_r_temps_3_0_i2);
Declare_label(mercury__vn_temploc__get_n_r_temps_3_0_i3);
Declare_static(mercury__vn_temploc__get_n_f_temps_3_0);
Declare_label(mercury__vn_temploc__get_n_f_temps_3_0_i2);
Declare_label(mercury__vn_temploc__get_n_f_temps_3_0_i3);
Define_extern_entry(mercury____Unify___vn_temploc__templocs_0_0);
Declare_label(mercury____Unify___vn_temploc__templocs_0_0_i2);
Declare_label(mercury____Unify___vn_temploc__templocs_0_0_i4);
Declare_label(mercury____Unify___vn_temploc__templocs_0_0_i6);
Declare_label(mercury____Unify___vn_temploc__templocs_0_0_i1);
Define_extern_entry(mercury____Index___vn_temploc__templocs_0_0);
Define_extern_entry(mercury____Compare___vn_temploc__templocs_0_0);
Declare_label(mercury____Compare___vn_temploc__templocs_0_0_i3);
Declare_label(mercury____Compare___vn_temploc__templocs_0_0_i7);
Declare_label(mercury____Compare___vn_temploc__templocs_0_0_i11);
Declare_label(mercury____Compare___vn_temploc__templocs_0_0_i15);
Declare_label(mercury____Compare___vn_temploc__templocs_0_0_i19);
Declare_label(mercury____Compare___vn_temploc__templocs_0_0_i23);
Declare_label(mercury____Compare___vn_temploc__templocs_0_0_i32);

const struct MR_TypeCtorInfo_struct mercury_data_vn_temploc__type_ctor_info_templocs_0;

static const struct mercury_data_vn_temploc__common_0_struct {
	Word * f1;
	Word * f2;
}  mercury_data_vn_temploc__common_0;

static const struct mercury_data_vn_temploc__common_1_struct {
	Word * f1;
	Word * f2;
}  mercury_data_vn_temploc__common_1;

static const struct mercury_data_vn_temploc__common_2_struct {
	Word * f1;
}  mercury_data_vn_temploc__common_2;

static const struct mercury_data_vn_temploc__common_3_struct {
	Integer f1;
	Word * f2;
	Word * f3;
	Word * f4;
	Word * f5;
	Word * f6;
	Word * f7;
	Word * f8;
	String f9;
	Word * f10;
	Integer f11;
	Integer f12;
}  mercury_data_vn_temploc__common_3;

static const struct mercury_data_vn_temploc__type_ctor_functors_templocs_0_struct {
	Integer f1;
	Integer f2;
	Word * f3;
}  mercury_data_vn_temploc__type_ctor_functors_templocs_0;

static const struct mercury_data_vn_temploc__type_ctor_layout_templocs_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
	Word * f4;
}  mercury_data_vn_temploc__type_ctor_layout_templocs_0;

const struct MR_TypeCtorInfo_struct mercury_data_vn_temploc__type_ctor_info_templocs_0 = {
	(Integer) 0,
	ENTRY(mercury____Unify___vn_temploc__templocs_0_0),
	ENTRY(mercury____Index___vn_temploc__templocs_0_0),
	ENTRY(mercury____Compare___vn_temploc__templocs_0_0),
	(Integer) 2,
	(Word *) &mercury_data_vn_temploc__type_ctor_functors_templocs_0,
	(Word *) &mercury_data_vn_temploc__type_ctor_layout_templocs_0,
	MR_string_const("vn_temploc", 10),
	MR_string_const("templocs", 8),
	(Integer) 3
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_set__type_ctor_info_set_1;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_vn_type__type_ctor_info_vnlval_0;
static const struct mercury_data_vn_temploc__common_0_struct mercury_data_vn_temploc__common_0 = {
	(Word *) &mercury_data_set__type_ctor_info_set_1,
	(Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data_list__type_ctor_info_list_1;
static const struct mercury_data_vn_temploc__common_1_struct mercury_data_vn_temploc__common_1 = {
	(Word *) &mercury_data_list__type_ctor_info_list_1,
	(Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0
};

extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_int_0;
static const struct mercury_data_vn_temploc__common_2_struct mercury_data_vn_temploc__common_2 = {
	(Word *) &mercury_data___type_ctor_info_int_0
};

static const struct mercury_data_vn_temploc__common_3_struct mercury_data_vn_temploc__common_3 = {
	(Integer) 7,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_temploc__common_0),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_temploc__common_1),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_temploc__common_1),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_temploc__common_2),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_temploc__common_2),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_temploc__common_2),
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_temploc__common_2),
	MR_string_const("templocs", 8),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	(Integer) 0,
	(Integer) 0
};

static const struct mercury_data_vn_temploc__type_ctor_functors_templocs_0_struct mercury_data_vn_temploc__type_ctor_functors_templocs_0 = {
	(Integer) 0,
	(Integer) 1,
	MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_temploc__common_3)
};

static const struct mercury_data_vn_temploc__type_ctor_layout_templocs_0_struct mercury_data_vn_temploc__type_ctor_layout_templocs_0 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_vn_temploc__common_3),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};


BEGIN_MODULE(vn_temploc_module0)
	init_entry(mercury____Index___vn_temploc__templocs_0__ua0_2_0);
BEGIN_CODE

/* code for predicate '__Index___vn_temploc__templocs_0__ua0'/2 in mode 0 */
Define_static(mercury____Index___vn_temploc__templocs_0__ua0_2_0);
	r1 = (Integer) 0;
	proceed();
END_MODULE

Declare_entry(mercury__vn_type__real_r_regs_2_0);
Declare_entry(mercury__vn_type__real_f_regs_2_0);
Declare_entry(mercury__vn_type__real_r_temps_2_0);
Declare_entry(mercury__vn_type__real_f_temps_2_0);
Declare_entry(mercury__list__append_3_1);

BEGIN_MODULE(vn_temploc_module1)
	init_entry(mercury__vn_temploc__init_templocs_4_0);
	init_label(mercury__vn_temploc__init_templocs_4_0_i2);
	init_label(mercury__vn_temploc__init_templocs_4_0_i3);
	init_label(mercury__vn_temploc__init_templocs_4_0_i4);
	init_label(mercury__vn_temploc__init_templocs_4_0_i5);
	init_label(mercury__vn_temploc__init_templocs_4_0_i6);
	init_label(mercury__vn_temploc__init_templocs_4_0_i7);
	init_label(mercury__vn_temploc__init_templocs_4_0_i8);
	init_label(mercury__vn_temploc__init_templocs_4_0_i9);
	init_label(mercury__vn_temploc__init_templocs_4_0_i10);
	init_label(mercury__vn_temploc__init_templocs_4_0_i11);
BEGIN_CODE

/* code for predicate 'init_templocs'/4 in mode 0 */
Define_entry(mercury__vn_temploc__init_templocs_4_0);
	MR_incr_sp_push_msg(8, "vn_temploc:init_templocs/4");
	MR_stackvar(8) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__vn_type__real_r_regs_2_0),
		mercury__vn_temploc__init_templocs_4_0_i2,
		ENTRY(mercury__vn_temploc__init_templocs_4_0));
Define_label(mercury__vn_temploc__init_templocs_4_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_temploc__init_templocs_4_0));
	MR_stackvar(4) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__vn_type__real_f_regs_2_0),
		mercury__vn_temploc__init_templocs_4_0_i3,
		ENTRY(mercury__vn_temploc__init_templocs_4_0));
Define_label(mercury__vn_temploc__init_templocs_4_0_i3);
	update_prof_current_proc(LABEL(mercury__vn_temploc__init_templocs_4_0));
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(1);
	call_localret(ENTRY(mercury__vn_type__real_r_temps_2_0),
		mercury__vn_temploc__init_templocs_4_0_i4,
		ENTRY(mercury__vn_temploc__init_templocs_4_0));
Define_label(mercury__vn_temploc__init_templocs_4_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_temploc__init_templocs_4_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__vn_type__real_f_temps_2_0),
		mercury__vn_temploc__init_templocs_4_0_i5,
		ENTRY(mercury__vn_temploc__init_templocs_4_0));
Define_label(mercury__vn_temploc__init_templocs_4_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_temploc__init_templocs_4_0));
	MR_stackvar(6) = r1;
	r1 = (Integer) 1;
	r2 = MR_stackvar(1);
	call_localret(STATIC(mercury__vn_temploc__get_n_r_temps_3_0),
		mercury__vn_temploc__init_templocs_4_0_i6,
		ENTRY(mercury__vn_temploc__init_templocs_4_0));
Define_label(mercury__vn_temploc__init_templocs_4_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_temploc__init_templocs_4_0));
	MR_stackvar(7) = r1;
	r1 = (Integer) 1;
	r2 = MR_stackvar(6);
	call_localret(STATIC(mercury__vn_temploc__get_n_f_temps_3_0),
		mercury__vn_temploc__init_templocs_4_0_i7,
		ENTRY(mercury__vn_temploc__init_templocs_4_0));
Define_label(mercury__vn_temploc__init_templocs_4_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_temploc__init_templocs_4_0));
	r2 = MR_stackvar(4);
	MR_stackvar(4) = r1;
	r1 = (Integer) 1;
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	call_localret(STATIC(mercury__vn_temploc__find_free_r_regs_5_0),
		mercury__vn_temploc__init_templocs_4_0_i8,
		ENTRY(mercury__vn_temploc__init_templocs_4_0));
Define_label(mercury__vn_temploc__init_templocs_4_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_temploc__init_templocs_4_0));
	r4 = MR_stackvar(3);
	MR_stackvar(3) = r1;
	r1 = (Integer) 1;
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(2);
	call_localret(STATIC(mercury__vn_temploc__find_free_f_regs_5_0),
		mercury__vn_temploc__init_templocs_4_0_i9,
		ENTRY(mercury__vn_temploc__init_templocs_4_0));
Define_label(mercury__vn_temploc__init_templocs_4_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_temploc__init_templocs_4_0));
	r2 = MR_stackvar(3);
	MR_stackvar(3) = r1;
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0;
	r3 = MR_stackvar(7);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__vn_temploc__init_templocs_4_0_i10,
		ENTRY(mercury__vn_temploc__init_templocs_4_0));
Define_label(mercury__vn_temploc__init_templocs_4_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_temploc__init_templocs_4_0));
	r2 = MR_stackvar(3);
	MR_stackvar(3) = r1;
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0;
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__vn_temploc__init_templocs_4_0_i11,
		ENTRY(mercury__vn_temploc__init_templocs_4_0));
Define_label(mercury__vn_temploc__init_templocs_4_0_i11);
	update_prof_current_proc(LABEL(mercury__vn_temploc__init_templocs_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 7, mercury__vn_temploc__init_templocs_4_0, "vn_temploc:templocs/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(3);
	MR_field(MR_mktag(0), r1, (Integer) 2) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 3) = (Integer) 0;
	MR_field(MR_mktag(0), r1, (Integer) 4) = ((Integer) MR_stackvar(1) + (Integer) 1);
	MR_field(MR_mktag(0), r1, (Integer) 5) = (Integer) 0;
	MR_field(MR_mktag(0), r1, (Integer) 6) = ((Integer) MR_stackvar(6) + (Integer) 1);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
END_MODULE

Declare_entry(mercury__int__max_3_0);

BEGIN_MODULE(vn_temploc_module2)
	init_entry(mercury__vn_temploc__next_tempr_3_0);
	init_label(mercury__vn_temploc__next_tempr_3_0_i2);
	init_label(mercury__vn_temploc__next_tempr_3_0_i4);
	init_label(mercury__vn_temploc__next_tempr_3_0_i5);
BEGIN_CODE

/* code for predicate 'next_tempr'/3 in mode 0 */
Define_entry(mercury__vn_temploc__next_tempr_3_0);
	MR_incr_sp_push_msg(8, "vn_temploc:next_tempr/3");
	MR_stackvar(8) = (Word) MR_succip;
	r8 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r7 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r6 = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	r5 = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	r4 = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 5);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 6);
	if (((Integer) r7 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_temploc__next_tempr_3_0_i2);
	MR_stackvar(2) = r8;
	MR_stackvar(3) = r6;
	MR_stackvar(4) = r3;
	MR_stackvar(5) = r2;
	MR_stackvar(7) = r4;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r7, (Integer) 0);
	MR_stackvar(6) = MR_const_field(MR_mktag(1), r7, (Integer) 1);
	r1 = r5;
	GOTO_LABEL(mercury__vn_temploc__next_tempr_3_0_i4);
Define_label(mercury__vn_temploc__next_tempr_3_0_i2);
	r1 = r5;
	MR_stackvar(2) = r8;
	MR_stackvar(3) = r6;
	MR_stackvar(4) = r3;
	MR_stackvar(5) = r2;
	MR_stackvar(6) = r7;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 2, mercury__vn_temploc__next_tempr_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = (Integer) 0;
	MR_stackvar(1) = MR_tempr1;
	MR_stackvar(7) = ((Integer) r4 + (Integer) 1);
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = r4;
	}
Define_label(mercury__vn_temploc__next_tempr_3_0_i4);
	r3 = MR_stackvar(1);
	if ((MR_tag(r3) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_temploc__next_tempr_3_0_i5);
	if (((Integer) MR_const_field(MR_mktag(2), r3, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__vn_temploc__next_tempr_3_0_i5);
	r2 = MR_const_field(MR_mktag(2), r3, (Integer) 1);
	call_localret(ENTRY(mercury__int__max_3_0),
		mercury__vn_temploc__next_tempr_3_0_i5,
		ENTRY(mercury__vn_temploc__next_tempr_3_0));
Define_label(mercury__vn_temploc__next_tempr_3_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_temploc__next_tempr_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 7, mercury__vn_temploc__next_tempr_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r1, (Integer) 3) = r2;
	r2 = MR_stackvar(1);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_stackvar(5);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_stackvar(4);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_stackvar(7);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_stackvar(3);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(6);
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
END_MODULE


BEGIN_MODULE(vn_temploc_module3)
	init_entry(mercury__vn_temploc__next_tempf_3_0);
	init_label(mercury__vn_temploc__next_tempf_3_0_i2);
	init_label(mercury__vn_temploc__next_tempf_3_0_i4);
	init_label(mercury__vn_temploc__next_tempf_3_0_i5);
BEGIN_CODE

/* code for predicate 'next_tempf'/3 in mode 0 */
Define_entry(mercury__vn_temploc__next_tempf_3_0);
	MR_incr_sp_push_msg(8, "vn_temploc:next_tempf/3");
	MR_stackvar(8) = (Word) MR_succip;
	r8 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	r7 = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	r6 = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	r5 = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	r4 = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	r3 = MR_const_field(MR_mktag(0), r1, (Integer) 5);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 6);
	if (((Integer) r6 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_temploc__next_tempf_3_0_i2);
	MR_stackvar(2) = r8;
	MR_stackvar(3) = r7;
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r4;
	MR_stackvar(7) = r2;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r6, (Integer) 0);
	MR_stackvar(6) = MR_const_field(MR_mktag(1), r6, (Integer) 1);
	r1 = r3;
	GOTO_LABEL(mercury__vn_temploc__next_tempf_3_0_i4);
Define_label(mercury__vn_temploc__next_tempf_3_0_i2);
	r1 = r3;
	MR_stackvar(2) = r8;
	MR_stackvar(3) = r7;
	MR_stackvar(4) = r5;
	MR_stackvar(5) = r4;
	MR_stackvar(6) = r6;
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 2, mercury__vn_temploc__next_tempf_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = (Integer) 1;
	MR_stackvar(1) = MR_tempr1;
	MR_stackvar(7) = ((Integer) r2 + (Integer) 1);
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 1) = r2;
	}
Define_label(mercury__vn_temploc__next_tempf_3_0_i4);
	r3 = MR_stackvar(1);
	if ((MR_tag(r3) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_temploc__next_tempf_3_0_i5);
	if (((Integer) MR_const_field(MR_mktag(2), r3, (Integer) 0) != (Integer) 1))
		GOTO_LABEL(mercury__vn_temploc__next_tempf_3_0_i5);
	r2 = MR_const_field(MR_mktag(2), r3, (Integer) 1);
	call_localret(ENTRY(mercury__int__max_3_0),
		mercury__vn_temploc__next_tempf_3_0_i5,
		ENTRY(mercury__vn_temploc__next_tempf_3_0));
Define_label(mercury__vn_temploc__next_tempf_3_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_temploc__next_tempf_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 7, mercury__vn_temploc__next_tempf_3_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(0), r1, (Integer) 5) = r2;
	r2 = MR_stackvar(1);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_stackvar(7);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_stackvar(5);
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_stackvar(4);
	MR_field(MR_mktag(0), r1, (Integer) 2) = MR_stackvar(6);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(3);
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
END_MODULE

Declare_entry(mercury__list__delete_all_3_1);

BEGIN_MODULE(vn_temploc_module4)
	init_entry(mercury__vn_temploc__no_temploc_3_0);
	init_label(mercury__vn_temploc__no_temploc_3_0_i2);
	init_label(mercury__vn_temploc__no_temploc_3_0_i3);
BEGIN_CODE

/* code for predicate 'no_temploc'/3 in mode 0 */
Define_entry(mercury__vn_temploc__no_temploc_3_0);
	MR_incr_sp_push_msg(8, "vn_temploc:no_temploc/3");
	MR_stackvar(8) = (Word) MR_succip;
	r3 = r1;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	r2 = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0;
	call_localret(ENTRY(mercury__list__delete_all_3_1),
		mercury__vn_temploc__no_temploc_3_0_i2,
		ENTRY(mercury__vn_temploc__no_temploc_3_0));
Define_label(mercury__vn_temploc__no_temploc_3_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_temploc__no_temploc_3_0));
	r3 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0;
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__list__delete_all_3_1),
		mercury__vn_temploc__no_temploc_3_0_i3,
		ENTRY(mercury__vn_temploc__no_temploc_3_0));
Define_label(mercury__vn_temploc__no_temploc_3_0_i3);
	update_prof_current_proc(LABEL(mercury__vn_temploc__no_temploc_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 7, mercury__vn_temploc__no_temploc_3_0, "vn_temploc:templocs/0");
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(0), r1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(0), r1, (Integer) 2) = r2;
	MR_field(MR_mktag(0), r1, (Integer) 3) = MR_stackvar(4);
	MR_field(MR_mktag(0), r1, (Integer) 4) = MR_stackvar(5);
	MR_field(MR_mktag(0), r1, (Integer) 5) = MR_stackvar(6);
	MR_field(MR_mktag(0), r1, (Integer) 6) = MR_stackvar(7);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
END_MODULE

Declare_entry(mercury__set__member_2_0);

BEGIN_MODULE(vn_temploc_module5)
	init_entry(mercury__vn_temploc__reuse_templocs_3_0);
	init_label(mercury__vn_temploc__reuse_templocs_3_0_i1011);
	init_label(mercury__vn_temploc__reuse_templocs_3_0_i5);
	init_label(mercury__vn_temploc__reuse_templocs_3_0_i1001);
	init_label(mercury__vn_temploc__reuse_templocs_3_0_i4);
	init_label(mercury__vn_temploc__reuse_templocs_3_0_i9);
	init_label(mercury__vn_temploc__reuse_templocs_3_0_i8);
	init_label(mercury__vn_temploc__reuse_templocs_3_0_i13);
	init_label(mercury__vn_temploc__reuse_templocs_3_0_i7);
	init_label(mercury__vn_temploc__reuse_templocs_3_0_i16);
	init_label(mercury__vn_temploc__reuse_templocs_3_0_i15);
	init_label(mercury__vn_temploc__reuse_templocs_3_0_i20);
	init_label(mercury__vn_temploc__reuse_templocs_3_0_i3);
BEGIN_CODE

/* code for predicate 'reuse_templocs'/3 in mode 0 */
Define_entry(mercury__vn_temploc__reuse_templocs_3_0);
	MR_incr_sp_push_msg(11, "vn_temploc:reuse_templocs/3");
	MR_stackvar(11) = (Word) MR_succip;
Define_label(mercury__vn_temploc__reuse_templocs_3_0_i1011);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_temploc__reuse_templocs_3_0_i3);
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(1) = r2;
	MR_stackvar(4) = r3;
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	r2 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(2) = r2;
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0;
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__vn_temploc__reuse_templocs_3_0_i5,
		ENTRY(mercury__vn_temploc__reuse_templocs_3_0));
Define_label(mercury__vn_temploc__reuse_templocs_3_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_temploc__reuse_templocs_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_temploc__reuse_templocs_3_0_i4);
Define_label(mercury__vn_temploc__reuse_templocs_3_0_i1001);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(11);
	GOTO_LABEL(mercury__vn_temploc__reuse_templocs_3_0_i1011);
Define_label(mercury__vn_temploc__reuse_templocs_3_0_i4);
	r1 = MR_stackvar(2);
	if ((MR_tag(r1) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_temploc__reuse_templocs_3_0_i9);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__vn_temploc__reuse_templocs_3_0_i7);
	r2 = MR_stackvar(5);
	GOTO_LABEL(mercury__vn_temploc__reuse_templocs_3_0_i8);
Define_label(mercury__vn_temploc__reuse_templocs_3_0_i9);
	r1 = MR_stackvar(2);
	if ((MR_tag(r1) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_temploc__reuse_templocs_3_0_i7);
	r3 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__vn_temploc__reuse_templocs_3_0_i7);
	r2 = MR_stackvar(5);
Define_label(mercury__vn_temploc__reuse_templocs_3_0_i8);
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__vn_temploc__reuse_templocs_3_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__vn_temploc__reuse_templocs_3_0_i13,
		ENTRY(mercury__vn_temploc__reuse_templocs_3_0));
Define_label(mercury__vn_temploc__reuse_templocs_3_0_i13);
	update_prof_current_proc(LABEL(mercury__vn_temploc__reuse_templocs_3_0));
	r3 = r1;
	r1 = MR_stackvar(3);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 7, mercury__vn_temploc__reuse_templocs_3_0, "vn_temploc:templocs/0");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(0), r2, (Integer) 1) = r3;
	MR_field(MR_mktag(0), r2, (Integer) 2) = MR_stackvar(6);
	MR_field(MR_mktag(0), r2, (Integer) 3) = MR_stackvar(7);
	MR_field(MR_mktag(0), r2, (Integer) 4) = MR_stackvar(8);
	MR_field(MR_mktag(0), r2, (Integer) 5) = MR_stackvar(9);
	MR_field(MR_mktag(0), r2, (Integer) 6) = MR_stackvar(10);
	MR_succip = (Code *) MR_stackvar(11);
	GOTO_LABEL(mercury__vn_temploc__reuse_templocs_3_0_i1011);
Define_label(mercury__vn_temploc__reuse_templocs_3_0_i7);
	r1 = MR_stackvar(2);
	if ((MR_tag(r1) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_temploc__reuse_templocs_3_0_i16);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	if (((Integer) r3 != (Integer) 1))
		GOTO_LABEL(mercury__vn_temploc__reuse_templocs_3_0_i1001);
	r2 = MR_stackvar(6);
	GOTO_LABEL(mercury__vn_temploc__reuse_templocs_3_0_i15);
Define_label(mercury__vn_temploc__reuse_templocs_3_0_i16);
	r1 = MR_stackvar(2);
	if ((MR_tag(r1) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_temploc__reuse_templocs_3_0_i1001);
	r3 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	if (((Integer) r3 != (Integer) 1))
		GOTO_LABEL(mercury__vn_temploc__reuse_templocs_3_0_i1001);
	r2 = MR_stackvar(6);
Define_label(mercury__vn_temploc__reuse_templocs_3_0_i15);
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0;
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__vn_temploc__reuse_templocs_3_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__vn_temploc__reuse_templocs_3_0_i20,
		ENTRY(mercury__vn_temploc__reuse_templocs_3_0));
Define_label(mercury__vn_temploc__reuse_templocs_3_0_i20);
	update_prof_current_proc(LABEL(mercury__vn_temploc__reuse_templocs_3_0));
	r3 = r1;
	r1 = MR_stackvar(3);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 7, mercury__vn_temploc__reuse_templocs_3_0, "vn_temploc:templocs/0");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(4);
	MR_field(MR_mktag(0), r2, (Integer) 1) = MR_stackvar(5);
	MR_field(MR_mktag(0), r2, (Integer) 2) = r3;
	MR_field(MR_mktag(0), r2, (Integer) 3) = MR_stackvar(7);
	MR_field(MR_mktag(0), r2, (Integer) 4) = MR_stackvar(8);
	MR_field(MR_mktag(0), r2, (Integer) 5) = MR_stackvar(9);
	MR_field(MR_mktag(0), r2, (Integer) 6) = MR_stackvar(10);
	MR_succip = (Code *) MR_stackvar(11);
	GOTO_LABEL(mercury__vn_temploc__reuse_templocs_3_0_i1011);
Define_label(mercury__vn_temploc__reuse_templocs_3_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(11);
	MR_decr_sp_pop_msg(11);
	proceed();
END_MODULE


BEGIN_MODULE(vn_temploc_module6)
	init_entry(mercury__vn_temploc__max_tempr_2_0);
BEGIN_CODE

/* code for predicate 'max_tempr'/2 in mode 0 */
Define_entry(mercury__vn_temploc__max_tempr_2_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	proceed();
END_MODULE


BEGIN_MODULE(vn_temploc_module7)
	init_entry(mercury__vn_temploc__max_tempf_2_0);
BEGIN_CODE

/* code for predicate 'max_tempf'/2 in mode 0 */
Define_entry(mercury__vn_temploc__max_tempf_2_0);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 5);
	proceed();
END_MODULE

Declare_entry(mercury__vn_table__search_assigned_vn_3_0);
Declare_entry(mercury__vn_table__search_uses_3_0);

BEGIN_MODULE(vn_temploc_module8)
	init_entry(mercury__vn_temploc__find_free_r_regs_5_0);
	init_label(mercury__vn_temploc__find_free_r_regs_5_0_i2);
	init_label(mercury__vn_temploc__find_free_r_regs_5_0_i3);
	init_label(mercury__vn_temploc__find_free_r_regs_5_0_i5);
	init_label(mercury__vn_temploc__find_free_r_regs_5_0_i1010);
	init_label(mercury__vn_temploc__find_free_r_regs_5_0_i8);
	init_label(mercury__vn_temploc__find_free_r_regs_5_0_i11);
	init_label(mercury__vn_temploc__find_free_r_regs_5_0_i1015);
BEGIN_CODE

/* code for predicate 'find_free_r_regs'/5 in mode 0 */
Define_static(mercury__vn_temploc__find_free_r_regs_5_0);
	MR_incr_sp_push_msg(4, "vn_temploc:find_free_r_regs/5");
	MR_stackvar(4) = (Word) MR_succip;
	if (((Integer) r1 <= (Integer) r2))
		GOTO_LABEL(mercury__vn_temploc__find_free_r_regs_5_0_i2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__vn_temploc__find_free_r_regs_5_0_i2);
	MR_stackvar(1) = r1;
	r1 = ((Integer) r1 + (Integer) 1);
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	localcall(mercury__vn_temploc__find_free_r_regs_5_0,
		LABEL(mercury__vn_temploc__find_free_r_regs_5_0_i3),
		STATIC(mercury__vn_temploc__find_free_r_regs_5_0));
Define_label(mercury__vn_temploc__find_free_r_regs_5_0_i3);
	update_prof_current_proc(LABEL(mercury__vn_temploc__find_free_r_regs_5_0));
	r3 = MR_stackvar(2);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__vn_temploc__find_free_r_regs_5_0, "origin_lost_in_value_number");
	MR_stackvar(2) = r1;
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0;
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(1), r2, (Integer) 0) = (Integer) 0;
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__vn_temploc__find_free_r_regs_5_0_i5,
		STATIC(mercury__vn_temploc__find_free_r_regs_5_0));
Define_label(mercury__vn_temploc__find_free_r_regs_5_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_temploc__find_free_r_regs_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_temploc__find_free_r_regs_5_0_i1010);
	r1 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__vn_temploc__find_free_r_regs_5_0_i1010);
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 1, mercury__vn_temploc__find_free_r_regs_5_0, "vn_type:vnrval/0");
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__vn_temploc__find_free_r_regs_5_0, "vn_type:vnlval/0");
	MR_field(MR_mktag(1), r2, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(0), r1, (Integer) 0) = r2;
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__vn_table__search_assigned_vn_3_0),
		mercury__vn_temploc__find_free_r_regs_5_0_i8,
		STATIC(mercury__vn_temploc__find_free_r_regs_5_0));
Define_label(mercury__vn_temploc__find_free_r_regs_5_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_temploc__find_free_r_regs_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_temploc__find_free_r_regs_5_0_i1015);
	r1 = r2;
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__vn_table__search_uses_3_0),
		mercury__vn_temploc__find_free_r_regs_5_0_i11,
		STATIC(mercury__vn_temploc__find_free_r_regs_5_0));
Define_label(mercury__vn_temploc__find_free_r_regs_5_0_i11);
	update_prof_current_proc(LABEL(mercury__vn_temploc__find_free_r_regs_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_temploc__find_free_r_regs_5_0_i1015);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_temploc__find_free_r_regs_5_0_i1015);
	r1 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__vn_temploc__find_free_r_regs_5_0_i1015);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__vn_temploc__find_free_r_regs_5_0, "list:list/1");
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__vn_temploc__find_free_r_regs_5_0, "vn_type:vnlval/0");
	MR_field(MR_mktag(1), r2, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE


BEGIN_MODULE(vn_temploc_module9)
	init_entry(mercury__vn_temploc__find_free_f_regs_5_0);
	init_label(mercury__vn_temploc__find_free_f_regs_5_0_i2);
	init_label(mercury__vn_temploc__find_free_f_regs_5_0_i3);
	init_label(mercury__vn_temploc__find_free_f_regs_5_0_i5);
	init_label(mercury__vn_temploc__find_free_f_regs_5_0_i1010);
	init_label(mercury__vn_temploc__find_free_f_regs_5_0_i8);
	init_label(mercury__vn_temploc__find_free_f_regs_5_0_i11);
	init_label(mercury__vn_temploc__find_free_f_regs_5_0_i1015);
BEGIN_CODE

/* code for predicate 'find_free_f_regs'/5 in mode 0 */
Define_static(mercury__vn_temploc__find_free_f_regs_5_0);
	MR_incr_sp_push_msg(4, "vn_temploc:find_free_f_regs/5");
	MR_stackvar(4) = (Word) MR_succip;
	if (((Integer) r1 <= (Integer) r2))
		GOTO_LABEL(mercury__vn_temploc__find_free_f_regs_5_0_i2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__vn_temploc__find_free_f_regs_5_0_i2);
	MR_stackvar(1) = r1;
	r1 = ((Integer) r1 + (Integer) 1);
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	localcall(mercury__vn_temploc__find_free_f_regs_5_0,
		LABEL(mercury__vn_temploc__find_free_f_regs_5_0_i3),
		STATIC(mercury__vn_temploc__find_free_f_regs_5_0));
Define_label(mercury__vn_temploc__find_free_f_regs_5_0_i3);
	update_prof_current_proc(LABEL(mercury__vn_temploc__find_free_f_regs_5_0));
	r3 = MR_stackvar(2);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__vn_temploc__find_free_f_regs_5_0, "origin_lost_in_value_number");
	MR_stackvar(2) = r1;
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0;
	MR_field(MR_mktag(1), r2, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_stackvar(1);
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__vn_temploc__find_free_f_regs_5_0_i5,
		STATIC(mercury__vn_temploc__find_free_f_regs_5_0));
Define_label(mercury__vn_temploc__find_free_f_regs_5_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_temploc__find_free_f_regs_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_temploc__find_free_f_regs_5_0_i1010);
	r1 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__vn_temploc__find_free_f_regs_5_0_i1010);
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 1, mercury__vn_temploc__find_free_f_regs_5_0, "vn_type:vnrval/0");
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__vn_temploc__find_free_f_regs_5_0, "vn_type:vnlval/0");
	MR_field(MR_mktag(1), r2, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(0), r1, (Integer) 0) = r2;
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__vn_table__search_assigned_vn_3_0),
		mercury__vn_temploc__find_free_f_regs_5_0_i8,
		STATIC(mercury__vn_temploc__find_free_f_regs_5_0));
Define_label(mercury__vn_temploc__find_free_f_regs_5_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_temploc__find_free_f_regs_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_temploc__find_free_f_regs_5_0_i1015);
	r1 = r2;
	r2 = MR_stackvar(3);
	call_localret(ENTRY(mercury__vn_table__search_uses_3_0),
		mercury__vn_temploc__find_free_f_regs_5_0_i11,
		STATIC(mercury__vn_temploc__find_free_f_regs_5_0));
Define_label(mercury__vn_temploc__find_free_f_regs_5_0_i11);
	update_prof_current_proc(LABEL(mercury__vn_temploc__find_free_f_regs_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_temploc__find_free_f_regs_5_0_i1015);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_temploc__find_free_f_regs_5_0_i1015);
	r1 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__vn_temploc__find_free_f_regs_5_0_i1015);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__vn_temploc__find_free_f_regs_5_0, "list:list/1");
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__vn_temploc__find_free_f_regs_5_0, "vn_type:vnlval/0");
	MR_field(MR_mktag(1), r2, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE


BEGIN_MODULE(vn_temploc_module10)
	init_entry(mercury__vn_temploc__get_n_r_temps_3_0);
	init_label(mercury__vn_temploc__get_n_r_temps_3_0_i2);
	init_label(mercury__vn_temploc__get_n_r_temps_3_0_i3);
BEGIN_CODE

/* code for predicate 'get_n_r_temps'/3 in mode 0 */
Define_static(mercury__vn_temploc__get_n_r_temps_3_0);
	MR_incr_sp_push_msg(2, "vn_temploc:get_n_r_temps/3");
	MR_stackvar(2) = (Word) MR_succip;
	if (((Integer) r1 <= (Integer) r2))
		GOTO_LABEL(mercury__vn_temploc__get_n_r_temps_3_0_i2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__vn_temploc__get_n_r_temps_3_0_i2);
	MR_stackvar(1) = r1;
	r1 = ((Integer) r1 + (Integer) 1);
	localcall(mercury__vn_temploc__get_n_r_temps_3_0,
		LABEL(mercury__vn_temploc__get_n_r_temps_3_0_i3),
		STATIC(mercury__vn_temploc__get_n_r_temps_3_0));
Define_label(mercury__vn_temploc__get_n_r_temps_3_0_i3);
	update_prof_current_proc(LABEL(mercury__vn_temploc__get_n_r_temps_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__vn_temploc__get_n_r_temps_3_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(2), (Integer) 2, mercury__vn_temploc__get_n_r_temps_3_0, "vn_type:vnlval/0");
	MR_field(MR_mktag(2), r3, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(2), r3, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE


BEGIN_MODULE(vn_temploc_module11)
	init_entry(mercury__vn_temploc__get_n_f_temps_3_0);
	init_label(mercury__vn_temploc__get_n_f_temps_3_0_i2);
	init_label(mercury__vn_temploc__get_n_f_temps_3_0_i3);
BEGIN_CODE

/* code for predicate 'get_n_f_temps'/3 in mode 0 */
Define_static(mercury__vn_temploc__get_n_f_temps_3_0);
	MR_incr_sp_push_msg(2, "vn_temploc:get_n_f_temps/3");
	MR_stackvar(2) = (Word) MR_succip;
	if (((Integer) r1 <= (Integer) r2))
		GOTO_LABEL(mercury__vn_temploc__get_n_f_temps_3_0_i2);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__vn_temploc__get_n_f_temps_3_0_i2);
	MR_stackvar(1) = r1;
	r1 = ((Integer) r1 + (Integer) 1);
	localcall(mercury__vn_temploc__get_n_f_temps_3_0,
		LABEL(mercury__vn_temploc__get_n_f_temps_3_0_i3),
		STATIC(mercury__vn_temploc__get_n_f_temps_3_0));
Define_label(mercury__vn_temploc__get_n_f_temps_3_0_i3);
	update_prof_current_proc(LABEL(mercury__vn_temploc__get_n_f_temps_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__vn_temploc__get_n_f_temps_3_0, "list:list/1");
	tag_incr_hp_msg(r3, MR_mktag(2), (Integer) 2, mercury__vn_temploc__get_n_f_temps_3_0, "vn_type:vnlval/0");
	MR_field(MR_mktag(2), r3, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(2), r3, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
END_MODULE

Declare_entry(mercury____Unify___set__set_1_0);
Declare_entry(mercury____Unify___list__list_1_0);

BEGIN_MODULE(vn_temploc_module12)
	init_entry(mercury____Unify___vn_temploc__templocs_0_0);
	init_label(mercury____Unify___vn_temploc__templocs_0_0_i2);
	init_label(mercury____Unify___vn_temploc__templocs_0_0_i4);
	init_label(mercury____Unify___vn_temploc__templocs_0_0_i6);
	init_label(mercury____Unify___vn_temploc__templocs_0_0_i1);
BEGIN_CODE

/* code for predicate '__Unify__'/2 in mode 0 */
Define_entry(mercury____Unify___vn_temploc__templocs_0_0);
	MR_incr_sp_push_msg(13, "vn_temploc:__Unify__/2");
	MR_stackvar(13) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(11) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_stackvar(12) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 5);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r1, (Integer) 6);
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0;
	call_localret(ENTRY(mercury____Unify___set__set_1_0),
		mercury____Unify___vn_temploc__templocs_0_0_i2,
		ENTRY(mercury____Unify___vn_temploc__templocs_0_0));
Define_label(mercury____Unify___vn_temploc__templocs_0_0_i2);
	update_prof_current_proc(LABEL(mercury____Unify___vn_temploc__templocs_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___vn_temploc__templocs_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(7);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury____Unify___vn_temploc__templocs_0_0_i4,
		ENTRY(mercury____Unify___vn_temploc__templocs_0_0));
Define_label(mercury____Unify___vn_temploc__templocs_0_0_i4);
	update_prof_current_proc(LABEL(mercury____Unify___vn_temploc__templocs_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___vn_temploc__templocs_0_0_i1);
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(8);
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury____Unify___vn_temploc__templocs_0_0_i6,
		ENTRY(mercury____Unify___vn_temploc__templocs_0_0));
Define_label(mercury____Unify___vn_temploc__templocs_0_0_i6);
	update_prof_current_proc(LABEL(mercury____Unify___vn_temploc__templocs_0_0));
	if (!(r1))
		GOTO_LABEL(mercury____Unify___vn_temploc__templocs_0_0_i1);
	if ((MR_stackvar(3) != MR_stackvar(9)))
		GOTO_LABEL(mercury____Unify___vn_temploc__templocs_0_0_i1);
	if ((MR_stackvar(4) != MR_stackvar(10)))
		GOTO_LABEL(mercury____Unify___vn_temploc__templocs_0_0_i1);
	if ((MR_stackvar(5) != MR_stackvar(11)))
		GOTO_LABEL(mercury____Unify___vn_temploc__templocs_0_0_i1);
	if ((MR_stackvar(6) != MR_stackvar(12)))
		GOTO_LABEL(mercury____Unify___vn_temploc__templocs_0_0_i1);
	MR_succip = (Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	r1 = TRUE;
	proceed();
Define_label(mercury____Unify___vn_temploc__templocs_0_0_i1);
	MR_succip = (Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(vn_temploc_module13)
	init_entry(mercury____Index___vn_temploc__templocs_0_0);
BEGIN_CODE

/* code for predicate '__Index__'/2 in mode 0 */
Define_entry(mercury____Index___vn_temploc__templocs_0_0);
	tailcall(STATIC(mercury____Index___vn_temploc__templocs_0__ua0_2_0),
		ENTRY(mercury____Index___vn_temploc__templocs_0_0));
END_MODULE

Declare_entry(mercury____Compare___set__set_1_0);
Declare_entry(mercury____Compare___list__list_1_0);
Declare_entry(mercury__builtin_compare_int_3_0);

BEGIN_MODULE(vn_temploc_module14)
	init_entry(mercury____Compare___vn_temploc__templocs_0_0);
	init_label(mercury____Compare___vn_temploc__templocs_0_0_i3);
	init_label(mercury____Compare___vn_temploc__templocs_0_0_i7);
	init_label(mercury____Compare___vn_temploc__templocs_0_0_i11);
	init_label(mercury____Compare___vn_temploc__templocs_0_0_i15);
	init_label(mercury____Compare___vn_temploc__templocs_0_0_i19);
	init_label(mercury____Compare___vn_temploc__templocs_0_0_i23);
	init_label(mercury____Compare___vn_temploc__templocs_0_0_i32);
BEGIN_CODE

/* code for predicate '__Compare__'/3 in mode 0 */
Define_entry(mercury____Compare___vn_temploc__templocs_0_0);
	MR_incr_sp_push_msg(13, "vn_temploc:__Compare__/3");
	MR_stackvar(13) = (Word) MR_succip;
	r3 = MR_const_field(MR_mktag(0), r2, (Integer) 0);
	MR_stackvar(7) = MR_const_field(MR_mktag(0), r2, (Integer) 1);
	MR_stackvar(8) = MR_const_field(MR_mktag(0), r2, (Integer) 2);
	MR_stackvar(9) = MR_const_field(MR_mktag(0), r2, (Integer) 3);
	MR_stackvar(10) = MR_const_field(MR_mktag(0), r2, (Integer) 4);
	MR_stackvar(11) = MR_const_field(MR_mktag(0), r2, (Integer) 5);
	MR_stackvar(12) = MR_const_field(MR_mktag(0), r2, (Integer) 6);
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(1) = MR_const_field(MR_mktag(0), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(0), r1, (Integer) 2);
	MR_stackvar(3) = MR_const_field(MR_mktag(0), r1, (Integer) 3);
	MR_stackvar(4) = MR_const_field(MR_mktag(0), r1, (Integer) 4);
	MR_stackvar(5) = MR_const_field(MR_mktag(0), r1, (Integer) 5);
	MR_stackvar(6) = MR_const_field(MR_mktag(0), r1, (Integer) 6);
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0;
	call_localret(ENTRY(mercury____Compare___set__set_1_0),
		mercury____Compare___vn_temploc__templocs_0_0_i3,
		ENTRY(mercury____Compare___vn_temploc__templocs_0_0));
Define_label(mercury____Compare___vn_temploc__templocs_0_0_i3);
	update_prof_current_proc(LABEL(mercury____Compare___vn_temploc__templocs_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___vn_temploc__templocs_0_0_i32);
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0;
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(7);
	call_localret(ENTRY(mercury____Compare___list__list_1_0),
		mercury____Compare___vn_temploc__templocs_0_0_i7,
		ENTRY(mercury____Compare___vn_temploc__templocs_0_0));
Define_label(mercury____Compare___vn_temploc__templocs_0_0_i7);
	update_prof_current_proc(LABEL(mercury____Compare___vn_temploc__templocs_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___vn_temploc__templocs_0_0_i32);
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(8);
	call_localret(ENTRY(mercury____Compare___list__list_1_0),
		mercury____Compare___vn_temploc__templocs_0_0_i11,
		ENTRY(mercury____Compare___vn_temploc__templocs_0_0));
Define_label(mercury____Compare___vn_temploc__templocs_0_0_i11);
	update_prof_current_proc(LABEL(mercury____Compare___vn_temploc__templocs_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___vn_temploc__templocs_0_0_i32);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(9);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___vn_temploc__templocs_0_0_i15,
		ENTRY(mercury____Compare___vn_temploc__templocs_0_0));
Define_label(mercury____Compare___vn_temploc__templocs_0_0_i15);
	update_prof_current_proc(LABEL(mercury____Compare___vn_temploc__templocs_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___vn_temploc__templocs_0_0_i32);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(10);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___vn_temploc__templocs_0_0_i19,
		ENTRY(mercury____Compare___vn_temploc__templocs_0_0));
Define_label(mercury____Compare___vn_temploc__templocs_0_0_i19);
	update_prof_current_proc(LABEL(mercury____Compare___vn_temploc__templocs_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___vn_temploc__templocs_0_0_i32);
	r1 = MR_stackvar(5);
	r2 = MR_stackvar(11);
	call_localret(ENTRY(mercury__builtin_compare_int_3_0),
		mercury____Compare___vn_temploc__templocs_0_0_i23,
		ENTRY(mercury____Compare___vn_temploc__templocs_0_0));
Define_label(mercury____Compare___vn_temploc__templocs_0_0_i23);
	update_prof_current_proc(LABEL(mercury____Compare___vn_temploc__templocs_0_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury____Compare___vn_temploc__templocs_0_0_i32);
	r1 = MR_stackvar(6);
	r2 = MR_stackvar(12);
	MR_succip = (Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	tailcall(ENTRY(mercury__builtin_compare_int_3_0),
		ENTRY(mercury____Compare___vn_temploc__templocs_0_0));
Define_label(mercury____Compare___vn_temploc__templocs_0_0_i32);
	MR_succip = (Code *) MR_stackvar(13);
	MR_decr_sp_pop_msg(13);
	proceed();
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__vn_temploc_maybe_bunch_0(void)
{
	vn_temploc_module0();
	vn_temploc_module1();
	vn_temploc_module2();
	vn_temploc_module3();
	vn_temploc_module4();
	vn_temploc_module5();
	vn_temploc_module6();
	vn_temploc_module7();
	vn_temploc_module8();
	vn_temploc_module9();
	vn_temploc_module10();
	vn_temploc_module11();
	vn_temploc_module12();
	vn_temploc_module13();
	vn_temploc_module14();
}

#endif

void mercury__vn_temploc__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__vn_temploc__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__vn_temploc_maybe_bunch_0();
#endif

		MR_INIT_TYPE_CTOR_INFO(
		mercury_data_vn_temploc__type_ctor_info_templocs_0,
			vn_temploc__templocs_0_0);
	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
