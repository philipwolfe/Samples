/*
** Automatically generated from `vn_util.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__vn_util__init
ENDINIT
*/

#include "mercury_imp.h"

Declare_static(mercury__vn_util__simplify_int_compare_op__ho8__ua0_7_0);
Declare_label(mercury__vn_util__simplify_int_compare_op__ho8__ua0_7_0_i7);
Declare_label(mercury__vn_util__simplify_int_compare_op__ho8__ua0_7_0_i2);
Declare_label(mercury__vn_util__simplify_int_compare_op__ho8__ua0_7_0_i1);
Declare_static(mercury__vn_util__simplify_int_compare_op__ho7__ua0_7_0);
Declare_label(mercury__vn_util__simplify_int_compare_op__ho7__ua0_7_0_i7);
Declare_label(mercury__vn_util__simplify_int_compare_op__ho7__ua0_7_0_i2);
Declare_label(mercury__vn_util__simplify_int_compare_op__ho7__ua0_7_0_i1);
Declare_static(mercury__vn_util__simplify_int_compare_op__ho6__ua0_7_0);
Declare_label(mercury__vn_util__simplify_int_compare_op__ho6__ua0_7_0_i7);
Declare_label(mercury__vn_util__simplify_int_compare_op__ho6__ua0_7_0_i2);
Declare_label(mercury__vn_util__simplify_int_compare_op__ho6__ua0_7_0_i1);
Declare_static(mercury__vn_util__simplify_int_compare_op__ho5__ua0_7_0);
Declare_label(mercury__vn_util__simplify_int_compare_op__ho5__ua0_7_0_i7);
Declare_label(mercury__vn_util__simplify_int_compare_op__ho5__ua0_7_0_i2);
Declare_label(mercury__vn_util__simplify_int_compare_op__ho5__ua0_7_0_i1);
Declare_static(mercury__vn_util__simplify_float_compare_op__ho4__ua0_7_0);
Declare_label(mercury__vn_util__simplify_float_compare_op__ho4__ua0_7_0_i8);
Declare_label(mercury__vn_util__simplify_float_compare_op__ho4__ua0_7_0_i2);
Declare_label(mercury__vn_util__simplify_float_compare_op__ho4__ua0_7_0_i1);
Declare_static(mercury__vn_util__simplify_float_compare_op__ho3__ua0_7_0);
Declare_label(mercury__vn_util__simplify_float_compare_op__ho3__ua0_7_0_i7);
Declare_label(mercury__vn_util__simplify_float_compare_op__ho3__ua0_7_0_i2);
Declare_label(mercury__vn_util__simplify_float_compare_op__ho3__ua0_7_0_i1);
Declare_static(mercury__vn_util__simplify_float_compare_op__ho2__ua0_7_0);
Declare_label(mercury__vn_util__simplify_float_compare_op__ho2__ua0_7_0_i7);
Declare_label(mercury__vn_util__simplify_float_compare_op__ho2__ua0_7_0_i2);
Declare_label(mercury__vn_util__simplify_float_compare_op__ho2__ua0_7_0_i1);
Declare_static(mercury__vn_util__simplify_float_compare_op__ho1__ua0_7_0);
Declare_label(mercury__vn_util__simplify_float_compare_op__ho1__ua0_7_0_i7);
Declare_label(mercury__vn_util__simplify_float_compare_op__ho1__ua0_7_0_i2);
Declare_label(mercury__vn_util__simplify_float_compare_op__ho1__ua0_7_0_i1);
Declare_static(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0);
Declare_label(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0_i4);
Declare_label(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0_i15);
Declare_label(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0_i1003);
Declare_label(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0_i16);
Declare_label(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0_i27);
Declare_label(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0_i29);
Declare_label(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0_i30);
Declare_label(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0_i32);
Declare_label(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0_i1002);
Declare_label(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0_i2);
Declare_static(mercury__vn_util__DeforestationIn__pred__record_access__1008__0_4_0);
Declare_label(mercury__vn_util__DeforestationIn__pred__record_access__1008__0_4_0_i1003);
Declare_label(mercury__vn_util__DeforestationIn__pred__record_access__1008__0_4_0_i13);
Declare_label(mercury__vn_util__DeforestationIn__pred__record_access__1008__0_4_0_i24);
Declare_label(mercury__vn_util__DeforestationIn__pred__record_access__1008__0_4_0_i26);
Declare_label(mercury__vn_util__DeforestationIn__pred__record_access__1008__0_4_0_i27);
Declare_label(mercury__vn_util__DeforestationIn__pred__record_access__1008__0_4_0_i29);
Declare_label(mercury__vn_util__DeforestationIn__pred__record_access__1008__0_4_0_i1002);
Declare_label(mercury__vn_util__DeforestationIn__pred__record_access__1008__0_4_0_i2);
Define_extern_entry(mercury__vn_util__find_specials_2_0);
Declare_label(mercury__vn_util__find_specials_2_0_i4);
Declare_label(mercury__vn_util__find_specials_2_0_i5);
Declare_label(mercury__vn_util__find_specials_2_0_i6);
Declare_label(mercury__vn_util__find_specials_2_0_i7);
Declare_label(mercury__vn_util__find_specials_2_0_i8);
Declare_label(mercury__vn_util__find_specials_2_0_i9);
Declare_label(mercury__vn_util__find_specials_2_0_i12);
Declare_label(mercury__vn_util__find_specials_2_0_i19);
Declare_label(mercury__vn_util__find_specials_2_0_i21);
Define_extern_entry(mercury__vn_util__convert_to_vnlval_and_insert_3_0);
Declare_label(mercury__vn_util__convert_to_vnlval_and_insert_3_0_i1002);
Declare_label(mercury__vn_util__convert_to_vnlval_and_insert_3_0_i4);
Declare_label(mercury__vn_util__convert_to_vnlval_and_insert_3_0_i6);
Declare_label(mercury__vn_util__convert_to_vnlval_and_insert_3_0_i7);
Declare_label(mercury__vn_util__convert_to_vnlval_and_insert_3_0_i3);
Define_extern_entry(mercury__vn_util__rval_to_vn_4_0);
Declare_label(mercury__vn_util__rval_to_vn_4_0_i1005);
Declare_label(mercury__vn_util__rval_to_vn_4_0_i1006);
Declare_label(mercury__vn_util__rval_to_vn_4_0_i1007);
Declare_label(mercury__vn_util__rval_to_vn_4_0_i10);
Declare_label(mercury__vn_util__rval_to_vn_4_0_i11);
Declare_label(mercury__vn_util__rval_to_vn_4_0_i12);
Declare_label(mercury__vn_util__rval_to_vn_4_0_i14);
Declare_label(mercury__vn_util__rval_to_vn_4_0_i16);
Declare_label(mercury__vn_util__rval_to_vn_4_0_i17);
Declare_label(mercury__vn_util__rval_to_vn_4_0_i19);
Declare_label(mercury__vn_util__rval_to_vn_4_0_i20);
Declare_label(mercury__vn_util__rval_to_vn_4_0_i21);
Declare_label(mercury__vn_util__rval_to_vn_4_0_i23);
Define_extern_entry(mercury__vn_util__lval_to_vn_4_0);
Declare_label(mercury__vn_util__lval_to_vn_4_0_i2);
Declare_label(mercury__vn_util__lval_to_vn_4_0_i5);
Declare_label(mercury__vn_util__lval_to_vn_4_0_i3);
Define_extern_entry(mercury__vn_util__lval_to_vnlval_4_0);
Declare_label(mercury__vn_util__lval_to_vnlval_4_0_i2);
Declare_label(mercury__vn_util__lval_to_vnlval_4_0_i3);
Declare_label(mercury__vn_util__lval_to_vnlval_4_0_i7);
Declare_label(mercury__vn_util__lval_to_vnlval_4_0_i8);
Declare_label(mercury__vn_util__lval_to_vnlval_4_0_i5);
Declare_label(mercury__vn_util__lval_to_vnlval_4_0_i11);
Declare_label(mercury__vn_util__lval_to_vnlval_4_0_i1022);
Declare_label(mercury__vn_util__lval_to_vnlval_4_0_i1023);
Declare_label(mercury__vn_util__lval_to_vnlval_4_0_i14);
Declare_label(mercury__vn_util__lval_to_vnlval_4_0_i12);
Declare_label(mercury__vn_util__lval_to_vnlval_4_0_i17);
Declare_label(mercury__vn_util__lval_to_vnlval_4_0_i1026);
Declare_label(mercury__vn_util__lval_to_vnlval_4_0_i1027);
Declare_label(mercury__vn_util__lval_to_vnlval_4_0_i20);
Declare_label(mercury__vn_util__lval_to_vnlval_4_0_i18);
Declare_label(mercury__vn_util__lval_to_vnlval_4_0_i23);
Declare_label(mercury__vn_util__lval_to_vnlval_4_0_i1030);
Declare_label(mercury__vn_util__lval_to_vnlval_4_0_i1031);
Declare_label(mercury__vn_util__lval_to_vnlval_4_0_i26);
Declare_label(mercury__vn_util__lval_to_vnlval_4_0_i24);
Define_extern_entry(mercury__vn_util__is_const_expr_3_0);
Declare_label(mercury__vn_util__is_const_expr_3_0_i1000);
Declare_label(mercury__vn_util__is_const_expr_3_0_i2);
Declare_label(mercury__vn_util__is_const_expr_3_0_i6);
Declare_label(mercury__vn_util__is_const_expr_3_0_i9);
Declare_label(mercury__vn_util__is_const_expr_3_0_i10);
Declare_label(mercury__vn_util__is_const_expr_3_0_i11);
Declare_label(mercury__vn_util__is_const_expr_3_0_i13);
Declare_label(mercury__vn_util__is_const_expr_3_0_i14);
Declare_label(mercury__vn_util__is_const_expr_3_0_i15);
Declare_label(mercury__vn_util__is_const_expr_3_0_i19);
Define_extern_entry(mercury__vn_util__vnlval_access_vns_2_0);
Declare_label(mercury__vn_util__vnlval_access_vns_2_0_i12);
Declare_label(mercury__vn_util__vnlval_access_vns_2_0_i14);
Declare_label(mercury__vn_util__vnlval_access_vns_2_0_i20);
Declare_label(mercury__vn_util__vnlval_access_vns_2_0_i21);
Define_extern_entry(mercury__vn_util__no_access_vnlval_to_lval_2_0);
Declare_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i4);
Declare_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i5);
Declare_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i6);
Declare_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i7);
Declare_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i8);
Declare_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i9);
Declare_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i10);
Declare_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i11);
Declare_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i12);
Declare_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i13);
Declare_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i14);
Declare_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i21);
Define_extern_entry(mercury__vn_util__no_access_lval_to_vnlval_2_0);
Declare_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i4);
Declare_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i5);
Declare_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i6);
Declare_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i7);
Declare_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i8);
Declare_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i9);
Declare_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i10);
Declare_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i11);
Declare_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i12);
Declare_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i13);
Declare_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i14);
Declare_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i21);
Declare_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i22);
Define_extern_entry(mercury__vn_util__find_sub_vns_2_0);
Declare_label(mercury__vn_util__find_sub_vns_2_0_i4);
Declare_label(mercury__vn_util__find_sub_vns_2_0_i8);
Declare_label(mercury__vn_util__find_sub_vns_2_0_i10);
Declare_label(mercury__vn_util__find_sub_vns_2_0_i11);
Declare_label(mercury__vn_util__find_sub_vns_2_0_i13);
Declare_label(mercury__vn_util__find_sub_vns_2_0_i14);
Define_extern_entry(mercury__vn_util__find_lvals_in_rval_2_0);
Declare_label(mercury__vn_util__find_lvals_in_rval_2_0_i4);
Declare_label(mercury__vn_util__find_lvals_in_rval_2_0_i5);
Declare_label(mercury__vn_util__find_lvals_in_rval_2_0_i6);
Declare_label(mercury__vn_util__find_lvals_in_rval_2_0_i7);
Declare_label(mercury__vn_util__find_lvals_in_rval_2_0_i10);
Declare_label(mercury__vn_util__find_lvals_in_rval_2_0_i13);
Declare_label(mercury__vn_util__find_lvals_in_rval_2_0_i14);
Declare_label(mercury__vn_util__find_lvals_in_rval_2_0_i16);
Declare_label(mercury__vn_util__find_lvals_in_rval_2_0_i17);
Declare_label(mercury__vn_util__find_lvals_in_rval_2_0_i18);
Declare_label(mercury__vn_util__find_lvals_in_rval_2_0_i20);
Define_extern_entry(mercury__vn_util__find_lvals_in_rvals_2_0);
Declare_label(mercury__vn_util__find_lvals_in_rvals_2_0_i4);
Declare_label(mercury__vn_util__find_lvals_in_rvals_2_0_i5);
Declare_label(mercury__vn_util__find_lvals_in_rvals_2_0_i3);
Define_extern_entry(mercury__vn_util__is_vn_shared_4_0);
Declare_label(mercury__vn_util__is_vn_shared_4_0_i2);
Declare_label(mercury__vn_util__is_vn_shared_4_0_i3);
Declare_label(mercury__vn_util__is_vn_shared_4_0_i6);
Declare_label(mercury__vn_util__is_vn_shared_4_0_i1);
Define_extern_entry(mercury__vn_util__real_uses_3_0);
Declare_label(mercury__vn_util__real_uses_3_0_i3);
Declare_label(mercury__vn_util__real_uses_3_0_i4);
Declare_label(mercury__vn_util__real_uses_3_0_i7);
Declare_label(mercury__vn_util__real_uses_3_0_i6);
Declare_label(mercury__vn_util__real_uses_3_0_i12);
Declare_label(mercury__vn_util__real_uses_3_0_i14);
Declare_label(mercury__vn_util__real_uses_3_0_i1035);
Declare_label(mercury__vn_util__real_uses_3_0_i20);
Declare_label(mercury__vn_util__real_uses_3_0_i22);
Declare_label(mercury__vn_util__real_uses_3_0_i26);
Declare_label(mercury__vn_util__real_uses_3_0_i30);
Declare_label(mercury__vn_util__real_uses_3_0_i32);
Declare_label(mercury__vn_util__real_uses_3_0_i29);
Declare_label(mercury__vn_util__real_uses_3_0_i34);
Declare_label(mercury__vn_util__real_uses_3_0_i36);
Declare_label(mercury__vn_util__real_uses_3_0_i38);
Declare_label(mercury__vn_util__real_uses_3_0_i1016);
Declare_label(mercury__vn_util__real_uses_3_0_i1053);
Declare_label(mercury__vn_util__real_uses_3_0_i1);
Define_extern_entry(mercury__vn_util__choose_cheapest_loc_2_0);
Define_extern_entry(mercury__vn_util__classify_loc_cost_2_0);
Declare_label(mercury__vn_util__classify_loc_cost_2_0_i11);
Declare_label(mercury__vn_util__classify_loc_cost_2_0_i12);
Declare_label(mercury__vn_util__classify_loc_cost_2_0_i19);
Declare_label(mercury__vn_util__classify_loc_cost_2_0_i21);
Declare_static(mercury__vn_util__mem_ref_to_vn_4_0);
Declare_label(mercury__vn_util__mem_ref_to_vn_4_0_i6);
Declare_label(mercury__vn_util__mem_ref_to_vn_4_0_i7);
Declare_label(mercury__vn_util__mem_ref_to_vn_4_0_i4);
Declare_static(mercury__vn_util__vnrval_to_vn_4_0);
Declare_label(mercury__vn_util__vnrval_to_vn_4_0_i2);
Declare_label(mercury__vn_util__vnrval_to_vn_4_0_i5);
Declare_label(mercury__vn_util__vnrval_to_vn_4_0_i9);
Declare_label(mercury__vn_util__vnrval_to_vn_4_0_i8);
Declare_label(mercury__vn_util__vnrval_to_vn_4_0_i3);
Declare_static(mercury__vn_util__simplify_vnrval_4_0);
Declare_label(mercury__vn_util__simplify_vnrval_4_0_i5);
Declare_label(mercury__vn_util__simplify_vnrval_4_0_i2);
Declare_label(mercury__vn_util__simplify_vnrval_4_0_i1004);
Declare_static(mercury__vn_util__simplify_vnrval_binop_6_0);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i2);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i3);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i5);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i6);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i17);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i20);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i11);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i12);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i21);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i30);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i26);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i27);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i40);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i45);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i48);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i49);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i36);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i37);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i54);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i59);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i50);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i51);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i69);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i73);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i70);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i81);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i82);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i76);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i84);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i91);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i92);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i97);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i106);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i108);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i120);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i121);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i130);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i131);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i140);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i141);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i146);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i150);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i157);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i158);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i163);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i167);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i175);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i176);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i179);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i182);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i190);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i191);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i194);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i197);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i205);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i206);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i207);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i214);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i218);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i219);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i220);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i227);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i232);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i233);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i235);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i236);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i238);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i239);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i241);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i242);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i244);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i245);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i247);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i248);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i250);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i251);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i253);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i254);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i256);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i257);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i259);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i260);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i262);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i263);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i274);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i277);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i268);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i269);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i278);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i287);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i283);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i284);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i297);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i302);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i305);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i306);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i293);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i294);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i311);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i316);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i307);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i308);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i326);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i330);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i327);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i338);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i339);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i340);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i333);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i341);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i348);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i349);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i354);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i363);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i365);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i376);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i377);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i379);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i380);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i382);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i383);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i385);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i386);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i388);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i389);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i391);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i392);
Declare_label(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
Declare_static(mercury__vn_util__const_if_equal_vns_4_0);
Declare_label(mercury__vn_util__const_if_equal_vns_4_0_i1);
Declare_static(mercury__vn_util__find_lvals_in_mem_ref_2_0);
Declare_label(mercury__vn_util__find_lvals_in_mem_ref_2_0_i1001);
Declare_label(mercury__vn_util__find_lvals_in_mem_ref_2_0_i5);
Declare_static(mercury__vn_util__choose_cheapest_loc_2_4_0);
Declare_label(mercury__vn_util__choose_cheapest_loc_2_4_0_i1005);
Declare_label(mercury__vn_util__choose_cheapest_loc_2_4_0_i4);
Declare_label(mercury__vn_util__choose_cheapest_loc_2_4_0_i3);
Declare_label(mercury__vn_util__choose_cheapest_loc_2_4_0_i8);
Declare_label(mercury__vn_util__choose_cheapest_loc_2_4_0_i9);
Declare_label(mercury__vn_util__choose_cheapest_loc_2_4_0_i11);
Declare_label(mercury__vn_util__choose_cheapest_loc_2_4_0_i1);
Define_extern_entry(mercury__vn_util__build_uses_4_0);
Declare_label(mercury__vn_util__build_uses_4_0_i2);
Declare_label(mercury__vn_util__build_uses_4_0_i3);
Declare_static(mercury__vn_util__build_uses_from_ctrl_4_0);
Declare_label(mercury__vn_util__build_uses_from_ctrl_4_0_i1001);
Declare_label(mercury__vn_util__build_uses_from_ctrl_4_0_i3);
Declare_label(mercury__vn_util__build_uses_from_ctrl_4_0_i10);
Declare_label(mercury__vn_util__build_uses_from_ctrl_4_0_i14);
Declare_label(mercury__vn_util__build_uses_from_ctrl_4_0_i16);
Declare_label(mercury__vn_util__build_uses_from_ctrl_4_0_i18);
Declare_label(mercury__vn_util__build_uses_from_ctrl_4_0_i20);
Declare_label(mercury__vn_util__build_uses_from_ctrl_4_0_i24);
Declare_label(mercury__vn_util__build_uses_from_ctrl_4_0_i26);
Declare_label(mercury__vn_util__build_uses_from_ctrl_4_0_i28);
Declare_label(mercury__vn_util__build_uses_from_ctrl_4_0_i29);
Declare_label(mercury__vn_util__build_uses_from_ctrl_4_0_i31);
Declare_label(mercury__vn_util__build_uses_from_ctrl_4_0_i2);
Declare_static(mercury__vn_util__build_uses_from_livevals_3_0);
Declare_label(mercury__vn_util__build_uses_from_livevals_3_0_i1002);
Declare_label(mercury__vn_util__build_uses_from_livevals_3_0_i6);
Declare_label(mercury__vn_util__build_uses_from_livevals_3_0_i4);
Declare_label(mercury__vn_util__build_uses_from_livevals_3_0_i8);
Declare_label(mercury__vn_util__build_uses_from_livevals_3_0_i10);
Declare_label(mercury__vn_util__build_uses_from_livevals_3_0_i11);
Declare_label(mercury__vn_util__build_uses_from_livevals_3_0_i3);
Declare_static(mercury__vn_util__record_use_4_0);
Declare_label(mercury__vn_util__record_use_4_0_i1001);
Declare_label(mercury__vn_util__record_use_4_0_i2);
Declare_label(mercury__vn_util__record_use_4_0_i3);
Declare_label(mercury__vn_util__record_use_4_0_i6);
Declare_label(mercury__vn_util__record_use_4_0_i9);
Declare_label(mercury__vn_util__record_use_4_0_i14);
Declare_label(mercury__vn_util__record_use_4_0_i16);
Declare_label(mercury__vn_util__record_use_4_0_i18);
Declare_label(mercury__vn_util__record_use_4_0_i19);
Declare_label(mercury__vn_util__record_use_4_0_i22);
Declare_label(mercury__vn_util__record_use_4_0_i23);
Declare_label(mercury__vn_util__record_use_4_0_i25);
Declare_static(mercury__vn_util__record_use_list_4_0);
Declare_label(mercury__vn_util__record_use_list_4_0_i1001);
Declare_label(mercury__vn_util__record_use_list_4_0_i4);
Declare_label(mercury__vn_util__record_use_list_4_0_i3);

static const struct mercury_data_vn_util__common_0_struct {
	Word * f1;
}  mercury_data_vn_util__common_0;

static const struct mercury_data_vn_util__common_1_struct {
	Word * f1;
}  mercury_data_vn_util__common_1;

static const struct mercury_data_vn_util__common_2_struct {
	Word * f1;
	Word * f2;
}  mercury_data_vn_util__common_2;

static const struct mercury_data_vn_util__common_3_struct {
	Word * f1;
	Word * f2;
}  mercury_data_vn_util__common_3;

static const struct mercury_data_vn_util__common_4_struct {
	Word * f1;
	Word * f2;
}  mercury_data_vn_util__common_4;

static const struct mercury_data_vn_util__common_5_struct {
	Word * f1;
	Word * f2;
}  mercury_data_vn_util__common_5;

static const struct mercury_data_vn_util__common_6_struct {
	Word * f1;
	Word * f2;
}  mercury_data_vn_util__common_6;

static const struct mercury_data_vn_util__common_7_struct {
	Word * f1;
}  mercury_data_vn_util__common_7;

static const struct mercury_data_vn_util__common_8_struct {
	Word * f1;
}  mercury_data_vn_util__common_8;

static const struct mercury_data_vn_util__common_9_struct {
	Word * f1;
}  mercury_data_vn_util__common_9;

static const struct mercury_data_vn_util__common_10_struct {
	Integer f1;
}  mercury_data_vn_util__common_10;

static const struct mercury_data_vn_util__common_11_struct {
	Word * f1;
}  mercury_data_vn_util__common_11;

static const struct mercury_data_vn_util__common_12_struct {
	Word * f1;
}  mercury_data_vn_util__common_12;

static const struct mercury_data_vn_util__common_13_struct {
	Word * f1;
}  mercury_data_vn_util__common_13;

static const struct mercury_data_vn_util__common_0_struct mercury_data_vn_util__common_0 = {
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_vn_util__common_1_struct mercury_data_vn_util__common_1 = {
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))
};

static const struct mercury_data_vn_util__common_2_struct mercury_data_vn_util__common_2 = {
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_vn_util__common_3_struct mercury_data_vn_util__common_3 = {
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_vn_util__common_4_struct mercury_data_vn_util__common_4 = {
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 2)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_vn_util__common_5_struct mercury_data_vn_util__common_5 = {
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 3)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_vn_util__common_6_struct mercury_data_vn_util__common_6 = {
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 4)),
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))
};

static const struct mercury_data_vn_util__common_7_struct mercury_data_vn_util__common_7 = {
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 2))
};

static const struct mercury_data_vn_util__common_8_struct mercury_data_vn_util__common_8 = {
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 3))
};

static const struct mercury_data_vn_util__common_9_struct mercury_data_vn_util__common_9 = {
	MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 4))
};

static const struct mercury_data_vn_util__common_10_struct mercury_data_vn_util__common_10 = {
	(Integer) 0
};

static const struct mercury_data_vn_util__common_11_struct mercury_data_vn_util__common_11 = {
	MR_mkword(MR_mktag(1), (Word *) &mercury_data_vn_util__common_10)
};

static const Float mercury_float_const_0pt00000000000000 = 0.00000000000000;
static const struct mercury_data_vn_util__common_12_struct mercury_data_vn_util__common_12 = {
	(Word *) &mercury_float_const_0pt00000000000000
};

static const struct mercury_data_vn_util__common_13_struct mercury_data_vn_util__common_13 = {
	MR_mkword(MR_mktag(2), (Word *) &mercury_data_vn_util__common_12)
};


BEGIN_MODULE(vn_util_module0)
	init_entry(mercury__vn_util__simplify_int_compare_op__ho8__ua0_7_0);
	init_label(mercury__vn_util__simplify_int_compare_op__ho8__ua0_7_0_i7);
	init_label(mercury__vn_util__simplify_int_compare_op__ho8__ua0_7_0_i2);
	init_label(mercury__vn_util__simplify_int_compare_op__ho8__ua0_7_0_i1);
BEGIN_CODE

/* code for predicate 'simplify_int_compare_op__ho8__ua0'/7 in mode 0 */
Define_static(mercury__vn_util__simplify_int_compare_op__ho8__ua0_7_0);
	if ((MR_tag(r2) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_int_compare_op__ho8__ua0_7_0_i2);
	if ((MR_tag(MR_const_field(MR_mktag(2), r2, (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__simplify_int_compare_op__ho8__ua0_7_0_i2);
	if ((MR_tag(r4) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_int_compare_op__ho8__ua0_7_0_i2);
	if ((MR_tag(MR_const_field(MR_mktag(2), r4, (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__simplify_int_compare_op__ho8__ua0_7_0_i2);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(2), r2, (Integer) 0), (Integer) 0) >= (Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(2), r4, (Integer) 0), (Integer) 0)))
		GOTO_LABEL(mercury__vn_util__simplify_int_compare_op__ho8__ua0_7_0_i7);
	r2 = (Word) MR_mkword(MR_mktag(2), (Word *) &mercury_data_vn_util__common_0);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_int_compare_op__ho8__ua0_7_0_i7);
	r2 = (Word) MR_mkword(MR_mktag(2), (Word *) &mercury_data_vn_util__common_1);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_int_compare_op__ho8__ua0_7_0_i2);
	if ((r1 != r3))
		GOTO_LABEL(mercury__vn_util__simplify_int_compare_op__ho8__ua0_7_0_i1);
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 1, mercury__vn_util__simplify_int_compare_op__ho8__ua0_7_0, "vn_type:vnrval/0");
	MR_field(MR_mktag(2), r2, (Integer) 0) = r5;
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_int_compare_op__ho8__ua0_7_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(vn_util_module1)
	init_entry(mercury__vn_util__simplify_int_compare_op__ho7__ua0_7_0);
	init_label(mercury__vn_util__simplify_int_compare_op__ho7__ua0_7_0_i7);
	init_label(mercury__vn_util__simplify_int_compare_op__ho7__ua0_7_0_i2);
	init_label(mercury__vn_util__simplify_int_compare_op__ho7__ua0_7_0_i1);
BEGIN_CODE

/* code for predicate 'simplify_int_compare_op__ho7__ua0'/7 in mode 0 */
Define_static(mercury__vn_util__simplify_int_compare_op__ho7__ua0_7_0);
	if ((MR_tag(r2) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_int_compare_op__ho7__ua0_7_0_i2);
	if ((MR_tag(MR_const_field(MR_mktag(2), r2, (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__simplify_int_compare_op__ho7__ua0_7_0_i2);
	if ((MR_tag(r4) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_int_compare_op__ho7__ua0_7_0_i2);
	if ((MR_tag(MR_const_field(MR_mktag(2), r4, (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__simplify_int_compare_op__ho7__ua0_7_0_i2);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(2), r2, (Integer) 0), (Integer) 0) <= (Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(2), r4, (Integer) 0), (Integer) 0)))
		GOTO_LABEL(mercury__vn_util__simplify_int_compare_op__ho7__ua0_7_0_i7);
	r2 = (Word) MR_mkword(MR_mktag(2), (Word *) &mercury_data_vn_util__common_0);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_int_compare_op__ho7__ua0_7_0_i7);
	r2 = (Word) MR_mkword(MR_mktag(2), (Word *) &mercury_data_vn_util__common_1);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_int_compare_op__ho7__ua0_7_0_i2);
	if ((r1 != r3))
		GOTO_LABEL(mercury__vn_util__simplify_int_compare_op__ho7__ua0_7_0_i1);
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 1, mercury__vn_util__simplify_int_compare_op__ho7__ua0_7_0, "vn_type:vnrval/0");
	MR_field(MR_mktag(2), r2, (Integer) 0) = r5;
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_int_compare_op__ho7__ua0_7_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(vn_util_module2)
	init_entry(mercury__vn_util__simplify_int_compare_op__ho6__ua0_7_0);
	init_label(mercury__vn_util__simplify_int_compare_op__ho6__ua0_7_0_i7);
	init_label(mercury__vn_util__simplify_int_compare_op__ho6__ua0_7_0_i2);
	init_label(mercury__vn_util__simplify_int_compare_op__ho6__ua0_7_0_i1);
BEGIN_CODE

/* code for predicate 'simplify_int_compare_op__ho6__ua0'/7 in mode 0 */
Define_static(mercury__vn_util__simplify_int_compare_op__ho6__ua0_7_0);
	if ((MR_tag(r2) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_int_compare_op__ho6__ua0_7_0_i2);
	if ((MR_tag(MR_const_field(MR_mktag(2), r2, (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__simplify_int_compare_op__ho6__ua0_7_0_i2);
	if ((MR_tag(r4) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_int_compare_op__ho6__ua0_7_0_i2);
	if ((MR_tag(MR_const_field(MR_mktag(2), r4, (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__simplify_int_compare_op__ho6__ua0_7_0_i2);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(2), r2, (Integer) 0), (Integer) 0) > (Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(2), r4, (Integer) 0), (Integer) 0)))
		GOTO_LABEL(mercury__vn_util__simplify_int_compare_op__ho6__ua0_7_0_i7);
	r2 = (Word) MR_mkword(MR_mktag(2), (Word *) &mercury_data_vn_util__common_0);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_int_compare_op__ho6__ua0_7_0_i7);
	r2 = (Word) MR_mkword(MR_mktag(2), (Word *) &mercury_data_vn_util__common_1);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_int_compare_op__ho6__ua0_7_0_i2);
	if ((r1 != r3))
		GOTO_LABEL(mercury__vn_util__simplify_int_compare_op__ho6__ua0_7_0_i1);
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 1, mercury__vn_util__simplify_int_compare_op__ho6__ua0_7_0, "vn_type:vnrval/0");
	MR_field(MR_mktag(2), r2, (Integer) 0) = r5;
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_int_compare_op__ho6__ua0_7_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(vn_util_module3)
	init_entry(mercury__vn_util__simplify_int_compare_op__ho5__ua0_7_0);
	init_label(mercury__vn_util__simplify_int_compare_op__ho5__ua0_7_0_i7);
	init_label(mercury__vn_util__simplify_int_compare_op__ho5__ua0_7_0_i2);
	init_label(mercury__vn_util__simplify_int_compare_op__ho5__ua0_7_0_i1);
BEGIN_CODE

/* code for predicate 'simplify_int_compare_op__ho5__ua0'/7 in mode 0 */
Define_static(mercury__vn_util__simplify_int_compare_op__ho5__ua0_7_0);
	if ((MR_tag(r2) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_int_compare_op__ho5__ua0_7_0_i2);
	if ((MR_tag(MR_const_field(MR_mktag(2), r2, (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__simplify_int_compare_op__ho5__ua0_7_0_i2);
	if ((MR_tag(r4) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_int_compare_op__ho5__ua0_7_0_i2);
	if ((MR_tag(MR_const_field(MR_mktag(2), r4, (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__simplify_int_compare_op__ho5__ua0_7_0_i2);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(2), r2, (Integer) 0), (Integer) 0) < (Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(2), r4, (Integer) 0), (Integer) 0)))
		GOTO_LABEL(mercury__vn_util__simplify_int_compare_op__ho5__ua0_7_0_i7);
	r2 = (Word) MR_mkword(MR_mktag(2), (Word *) &mercury_data_vn_util__common_0);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_int_compare_op__ho5__ua0_7_0_i7);
	r2 = (Word) MR_mkword(MR_mktag(2), (Word *) &mercury_data_vn_util__common_1);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_int_compare_op__ho5__ua0_7_0_i2);
	if ((r1 != r3))
		GOTO_LABEL(mercury__vn_util__simplify_int_compare_op__ho5__ua0_7_0_i1);
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 1, mercury__vn_util__simplify_int_compare_op__ho5__ua0_7_0, "vn_type:vnrval/0");
	MR_field(MR_mktag(2), r2, (Integer) 0) = r5;
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_int_compare_op__ho5__ua0_7_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(vn_util_module4)
	init_entry(mercury__vn_util__simplify_float_compare_op__ho4__ua0_7_0);
	init_label(mercury__vn_util__simplify_float_compare_op__ho4__ua0_7_0_i8);
	init_label(mercury__vn_util__simplify_float_compare_op__ho4__ua0_7_0_i2);
	init_label(mercury__vn_util__simplify_float_compare_op__ho4__ua0_7_0_i1);
BEGIN_CODE

/* code for predicate 'simplify_float_compare_op__ho4__ua0'/7 in mode 0 */
Define_static(mercury__vn_util__simplify_float_compare_op__ho4__ua0_7_0);
	if ((MR_tag(r2) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_float_compare_op__ho4__ua0_7_0_i2);
	if ((MR_tag(MR_const_field(MR_mktag(2), r2, (Integer) 0)) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_float_compare_op__ho4__ua0_7_0_i2);
	if ((MR_tag(r4) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_float_compare_op__ho4__ua0_7_0_i2);
	if ((MR_tag(MR_const_field(MR_mktag(2), r4, (Integer) 0)) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_float_compare_op__ho4__ua0_7_0_i2);
	if ((word_to_float(MR_const_field(MR_mktag(2), MR_const_field(MR_mktag(2), r2, (Integer) 0), (Integer) 0)) == word_to_float(MR_const_field(MR_mktag(2), MR_const_field(MR_mktag(2), r4, (Integer) 0), (Integer) 0))))
		GOTO_LABEL(mercury__vn_util__simplify_float_compare_op__ho4__ua0_7_0_i8);
	r2 = (Word) MR_mkword(MR_mktag(2), (Word *) &mercury_data_vn_util__common_0);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_float_compare_op__ho4__ua0_7_0_i8);
	r2 = (Word) MR_mkword(MR_mktag(2), (Word *) &mercury_data_vn_util__common_1);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_float_compare_op__ho4__ua0_7_0_i2);
	if ((r1 != r3))
		GOTO_LABEL(mercury__vn_util__simplify_float_compare_op__ho4__ua0_7_0_i1);
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 1, mercury__vn_util__simplify_float_compare_op__ho4__ua0_7_0, "vn_type:vnrval/0");
	MR_field(MR_mktag(2), r2, (Integer) 0) = r5;
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_float_compare_op__ho4__ua0_7_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(vn_util_module5)
	init_entry(mercury__vn_util__simplify_float_compare_op__ho3__ua0_7_0);
	init_label(mercury__vn_util__simplify_float_compare_op__ho3__ua0_7_0_i7);
	init_label(mercury__vn_util__simplify_float_compare_op__ho3__ua0_7_0_i2);
	init_label(mercury__vn_util__simplify_float_compare_op__ho3__ua0_7_0_i1);
BEGIN_CODE

/* code for predicate 'simplify_float_compare_op__ho3__ua0'/7 in mode 0 */
Define_static(mercury__vn_util__simplify_float_compare_op__ho3__ua0_7_0);
	if ((MR_tag(r2) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_float_compare_op__ho3__ua0_7_0_i2);
	if ((MR_tag(MR_const_field(MR_mktag(2), r2, (Integer) 0)) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_float_compare_op__ho3__ua0_7_0_i2);
	if ((MR_tag(r4) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_float_compare_op__ho3__ua0_7_0_i2);
	if ((MR_tag(MR_const_field(MR_mktag(2), r4, (Integer) 0)) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_float_compare_op__ho3__ua0_7_0_i2);
	if ((word_to_float(MR_const_field(MR_mktag(2), MR_const_field(MR_mktag(2), r2, (Integer) 0), (Integer) 0)) > word_to_float(MR_const_field(MR_mktag(2), MR_const_field(MR_mktag(2), r4, (Integer) 0), (Integer) 0))))
		GOTO_LABEL(mercury__vn_util__simplify_float_compare_op__ho3__ua0_7_0_i7);
	r2 = (Word) MR_mkword(MR_mktag(2), (Word *) &mercury_data_vn_util__common_0);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_float_compare_op__ho3__ua0_7_0_i7);
	r2 = (Word) MR_mkword(MR_mktag(2), (Word *) &mercury_data_vn_util__common_1);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_float_compare_op__ho3__ua0_7_0_i2);
	if ((r1 != r3))
		GOTO_LABEL(mercury__vn_util__simplify_float_compare_op__ho3__ua0_7_0_i1);
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 1, mercury__vn_util__simplify_float_compare_op__ho3__ua0_7_0, "vn_type:vnrval/0");
	MR_field(MR_mktag(2), r2, (Integer) 0) = r5;
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_float_compare_op__ho3__ua0_7_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(vn_util_module6)
	init_entry(mercury__vn_util__simplify_float_compare_op__ho2__ua0_7_0);
	init_label(mercury__vn_util__simplify_float_compare_op__ho2__ua0_7_0_i7);
	init_label(mercury__vn_util__simplify_float_compare_op__ho2__ua0_7_0_i2);
	init_label(mercury__vn_util__simplify_float_compare_op__ho2__ua0_7_0_i1);
BEGIN_CODE

/* code for predicate 'simplify_float_compare_op__ho2__ua0'/7 in mode 0 */
Define_static(mercury__vn_util__simplify_float_compare_op__ho2__ua0_7_0);
	if ((MR_tag(r2) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_float_compare_op__ho2__ua0_7_0_i2);
	if ((MR_tag(MR_const_field(MR_mktag(2), r2, (Integer) 0)) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_float_compare_op__ho2__ua0_7_0_i2);
	if ((MR_tag(r4) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_float_compare_op__ho2__ua0_7_0_i2);
	if ((MR_tag(MR_const_field(MR_mktag(2), r4, (Integer) 0)) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_float_compare_op__ho2__ua0_7_0_i2);
	if ((word_to_float(MR_const_field(MR_mktag(2), MR_const_field(MR_mktag(2), r2, (Integer) 0), (Integer) 0)) < word_to_float(MR_const_field(MR_mktag(2), MR_const_field(MR_mktag(2), r4, (Integer) 0), (Integer) 0))))
		GOTO_LABEL(mercury__vn_util__simplify_float_compare_op__ho2__ua0_7_0_i7);
	r2 = (Word) MR_mkword(MR_mktag(2), (Word *) &mercury_data_vn_util__common_0);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_float_compare_op__ho2__ua0_7_0_i7);
	r2 = (Word) MR_mkword(MR_mktag(2), (Word *) &mercury_data_vn_util__common_1);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_float_compare_op__ho2__ua0_7_0_i2);
	if ((r1 != r3))
		GOTO_LABEL(mercury__vn_util__simplify_float_compare_op__ho2__ua0_7_0_i1);
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 1, mercury__vn_util__simplify_float_compare_op__ho2__ua0_7_0, "vn_type:vnrval/0");
	MR_field(MR_mktag(2), r2, (Integer) 0) = r5;
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_float_compare_op__ho2__ua0_7_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(vn_util_module7)
	init_entry(mercury__vn_util__simplify_float_compare_op__ho1__ua0_7_0);
	init_label(mercury__vn_util__simplify_float_compare_op__ho1__ua0_7_0_i7);
	init_label(mercury__vn_util__simplify_float_compare_op__ho1__ua0_7_0_i2);
	init_label(mercury__vn_util__simplify_float_compare_op__ho1__ua0_7_0_i1);
BEGIN_CODE

/* code for predicate 'simplify_float_compare_op__ho1__ua0'/7 in mode 0 */
Define_static(mercury__vn_util__simplify_float_compare_op__ho1__ua0_7_0);
	if ((MR_tag(r2) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_float_compare_op__ho1__ua0_7_0_i2);
	if ((MR_tag(MR_const_field(MR_mktag(2), r2, (Integer) 0)) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_float_compare_op__ho1__ua0_7_0_i2);
	if ((MR_tag(r4) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_float_compare_op__ho1__ua0_7_0_i2);
	if ((MR_tag(MR_const_field(MR_mktag(2), r4, (Integer) 0)) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_float_compare_op__ho1__ua0_7_0_i2);
	if ((word_to_float(MR_const_field(MR_mktag(2), MR_const_field(MR_mktag(2), r4, (Integer) 0), (Integer) 0)) != word_to_float(MR_const_field(MR_mktag(2), MR_const_field(MR_mktag(2), r2, (Integer) 0), (Integer) 0))))
		GOTO_LABEL(mercury__vn_util__simplify_float_compare_op__ho1__ua0_7_0_i7);
	r2 = (Word) MR_mkword(MR_mktag(2), (Word *) &mercury_data_vn_util__common_0);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_float_compare_op__ho1__ua0_7_0_i7);
	r2 = (Word) MR_mkword(MR_mktag(2), (Word *) &mercury_data_vn_util__common_1);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_float_compare_op__ho1__ua0_7_0_i2);
	if ((r1 != r3))
		GOTO_LABEL(mercury__vn_util__simplify_float_compare_op__ho1__ua0_7_0_i1);
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 1, mercury__vn_util__simplify_float_compare_op__ho1__ua0_7_0, "vn_type:vnrval/0");
	MR_field(MR_mktag(2), r2, (Integer) 0) = r5;
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_float_compare_op__ho1__ua0_7_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(vn_util_module8)
	init_entry(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0);
	init_label(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0_i4);
	init_label(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0_i15);
	init_label(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0_i1003);
	init_label(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0_i16);
	init_label(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0_i27);
	init_label(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0_i29);
	init_label(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0_i30);
	init_label(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0_i32);
	init_label(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0_i1002);
	init_label(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0_i2);
BEGIN_CODE

/* code for predicate 'DeforestationIn__pred__build_uses_from_ctrl__1008__1'/4 in mode 0 */
Define_static(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0);
	MR_incr_sp_push_msg(3, "vn_util:DeforestationIn__pred__build_uses_from_ctrl__1008__1/4");
	MR_stackvar(3) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r2),
		LABEL(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0_i4) AND
		LABEL(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0_i1002) AND
		LABEL(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0_i1003) AND
		LABEL(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0_i15));
Define_label(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0_i4);
	COMPUTED_GOTO((Unsigned) MR_unmkbody(r2),
		LABEL(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0_i16) AND
		LABEL(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0_i2) AND
		LABEL(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0_i2) AND
		LABEL(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0_i2) AND
		LABEL(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0_i16));
Define_label(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0_i15);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r2, (Integer) 0),
		LABEL(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0_i16) AND
		LABEL(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0_i2) AND
		LABEL(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0_i27) AND
		LABEL(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0_i32) AND
		LABEL(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0_i32) AND
		LABEL(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0_i32) AND
		LABEL(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0_i27) AND
		LABEL(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0_i29) AND
		LABEL(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0_i32));
Define_label(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0_i1003);
	r2 = r3;
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__vn_util__record_use_list_4_0),
		STATIC(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0));
Define_label(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0_i16);
	r2 = r3;
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__vn_util__record_use_list_4_0),
		STATIC(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0));
Define_label(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0_i27);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	r2 = r3;
	r3 = r1;
	r1 = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__vn_util__record_use_list_4_0),
		STATIC(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0));
	}
Define_label(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0_i29);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r2, (Integer) 3);
	MR_stackvar(1) = r3;
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_const_field(MR_mktag(3), r2, (Integer) 2);
	r2 = r3;
	r3 = MR_tempr1;
	call_localret(STATIC(mercury__vn_util__record_use_4_0),
		mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0_i30,
		STATIC(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0));
	}
Define_label(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0_i30);
	update_prof_current_proc(LABEL(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__vn_util__record_use_4_0),
		STATIC(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0));
Define_label(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0_i32);
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	r2 = r3;
	r3 = MR_tempr1;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__vn_util__record_use_4_0),
		STATIC(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0));
	}
Define_label(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0_i1002);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0_i2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(vn_util_module9)
	init_entry(mercury__vn_util__DeforestationIn__pred__record_access__1008__0_4_0);
	init_label(mercury__vn_util__DeforestationIn__pred__record_access__1008__0_4_0_i1003);
	init_label(mercury__vn_util__DeforestationIn__pred__record_access__1008__0_4_0_i13);
	init_label(mercury__vn_util__DeforestationIn__pred__record_access__1008__0_4_0_i24);
	init_label(mercury__vn_util__DeforestationIn__pred__record_access__1008__0_4_0_i26);
	init_label(mercury__vn_util__DeforestationIn__pred__record_access__1008__0_4_0_i27);
	init_label(mercury__vn_util__DeforestationIn__pred__record_access__1008__0_4_0_i29);
	init_label(mercury__vn_util__DeforestationIn__pred__record_access__1008__0_4_0_i1002);
	init_label(mercury__vn_util__DeforestationIn__pred__record_access__1008__0_4_0_i2);
BEGIN_CODE

/* code for predicate 'DeforestationIn__pred__record_access__1008__0'/4 in mode 0 */
Define_static(mercury__vn_util__DeforestationIn__pred__record_access__1008__0_4_0);
	MR_incr_sp_push_msg(3, "vn_util:DeforestationIn__pred__record_access__1008__0/4");
	MR_stackvar(3) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r2),
		LABEL(mercury__vn_util__DeforestationIn__pred__record_access__1008__0_4_0_i1002) AND
		LABEL(mercury__vn_util__DeforestationIn__pred__record_access__1008__0_4_0_i1002) AND
		LABEL(mercury__vn_util__DeforestationIn__pred__record_access__1008__0_4_0_i1003) AND
		LABEL(mercury__vn_util__DeforestationIn__pred__record_access__1008__0_4_0_i13));
Define_label(mercury__vn_util__DeforestationIn__pred__record_access__1008__0_4_0_i1003);
	r2 = r3;
	r3 = r1;
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__vn_util__record_use_list_4_0),
		STATIC(mercury__vn_util__DeforestationIn__pred__record_access__1008__0_4_0));
Define_label(mercury__vn_util__DeforestationIn__pred__record_access__1008__0_4_0_i13);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r2, (Integer) 0),
		LABEL(mercury__vn_util__DeforestationIn__pred__record_access__1008__0_4_0_i2) AND
		LABEL(mercury__vn_util__DeforestationIn__pred__record_access__1008__0_4_0_i2) AND
		LABEL(mercury__vn_util__DeforestationIn__pred__record_access__1008__0_4_0_i29) AND
		LABEL(mercury__vn_util__DeforestationIn__pred__record_access__1008__0_4_0_i29) AND
		LABEL(mercury__vn_util__DeforestationIn__pred__record_access__1008__0_4_0_i29) AND
		LABEL(mercury__vn_util__DeforestationIn__pred__record_access__1008__0_4_0_i29) AND
		LABEL(mercury__vn_util__DeforestationIn__pred__record_access__1008__0_4_0_i24) AND
		LABEL(mercury__vn_util__DeforestationIn__pred__record_access__1008__0_4_0_i26) AND
		LABEL(mercury__vn_util__DeforestationIn__pred__record_access__1008__0_4_0_i29));
Define_label(mercury__vn_util__DeforestationIn__pred__record_access__1008__0_4_0_i24);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 2, mercury__vn_util__DeforestationIn__pred__record_access__1008__0_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	r2 = r3;
	r3 = r1;
	r1 = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__vn_util__record_use_list_4_0),
		STATIC(mercury__vn_util__DeforestationIn__pred__record_access__1008__0_4_0));
	}
Define_label(mercury__vn_util__DeforestationIn__pred__record_access__1008__0_4_0_i26);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r2, (Integer) 3);
	MR_stackvar(1) = r3;
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_const_field(MR_mktag(3), r2, (Integer) 2);
	r2 = r3;
	r3 = MR_tempr1;
	call_localret(STATIC(mercury__vn_util__record_use_4_0),
		mercury__vn_util__DeforestationIn__pred__record_access__1008__0_4_0_i27,
		STATIC(mercury__vn_util__DeforestationIn__pred__record_access__1008__0_4_0));
	}
Define_label(mercury__vn_util__DeforestationIn__pred__record_access__1008__0_4_0_i27);
	update_prof_current_proc(LABEL(mercury__vn_util__DeforestationIn__pred__record_access__1008__0_4_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__vn_util__record_use_4_0),
		STATIC(mercury__vn_util__DeforestationIn__pred__record_access__1008__0_4_0));
Define_label(mercury__vn_util__DeforestationIn__pred__record_access__1008__0_4_0_i29);
	{
	Word MR_tempr1;
	MR_tempr1 = r1;
	r1 = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	r2 = r3;
	r3 = MR_tempr1;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__vn_util__record_use_4_0),
		STATIC(mercury__vn_util__DeforestationIn__pred__record_access__1008__0_4_0));
	}
Define_label(mercury__vn_util__DeforestationIn__pred__record_access__1008__0_4_0_i1002);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_util__DeforestationIn__pred__record_access__1008__0_4_0_i2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(vn_util_module10)
	init_entry(mercury__vn_util__find_specials_2_0);
	init_label(mercury__vn_util__find_specials_2_0_i4);
	init_label(mercury__vn_util__find_specials_2_0_i5);
	init_label(mercury__vn_util__find_specials_2_0_i6);
	init_label(mercury__vn_util__find_specials_2_0_i7);
	init_label(mercury__vn_util__find_specials_2_0_i8);
	init_label(mercury__vn_util__find_specials_2_0_i9);
	init_label(mercury__vn_util__find_specials_2_0_i12);
	init_label(mercury__vn_util__find_specials_2_0_i19);
	init_label(mercury__vn_util__find_specials_2_0_i21);
BEGIN_CODE

/* code for predicate 'find_specials'/2 in mode 0 */
Define_entry(mercury__vn_util__find_specials_2_0);
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__vn_util__find_specials_2_0_i4) AND
		LABEL(mercury__vn_util__find_specials_2_0_i21) AND
		LABEL(mercury__vn_util__find_specials_2_0_i21) AND
		LABEL(mercury__vn_util__find_specials_2_0_i12));
Define_label(mercury__vn_util__find_specials_2_0_i4);
	COMPUTED_GOTO((Unsigned) MR_unmkbody(r1),
		LABEL(mercury__vn_util__find_specials_2_0_i5) AND
		LABEL(mercury__vn_util__find_specials_2_0_i6) AND
		LABEL(mercury__vn_util__find_specials_2_0_i7) AND
		LABEL(mercury__vn_util__find_specials_2_0_i8) AND
		LABEL(mercury__vn_util__find_specials_2_0_i9));
Define_label(mercury__vn_util__find_specials_2_0_i5);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_vn_util__common_2);
	proceed();
Define_label(mercury__vn_util__find_specials_2_0_i6);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_vn_util__common_3);
	proceed();
Define_label(mercury__vn_util__find_specials_2_0_i7);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_vn_util__common_4);
	proceed();
Define_label(mercury__vn_util__find_specials_2_0_i8);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_vn_util__common_5);
	proceed();
Define_label(mercury__vn_util__find_specials_2_0_i9);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_vn_util__common_6);
	proceed();
Define_label(mercury__vn_util__find_specials_2_0_i12);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__vn_util__find_specials_2_0_i21) AND
		LABEL(mercury__vn_util__find_specials_2_0_i21) AND
		LABEL(mercury__vn_util__find_specials_2_0_i19) AND
		LABEL(mercury__vn_util__find_specials_2_0_i19) AND
		LABEL(mercury__vn_util__find_specials_2_0_i19) AND
		LABEL(mercury__vn_util__find_specials_2_0_i19) AND
		LABEL(mercury__vn_util__find_specials_2_0_i19) AND
		LABEL(mercury__vn_util__find_specials_2_0_i21) AND
		LABEL(mercury__vn_util__find_specials_2_0_i21));
Define_label(mercury__vn_util__find_specials_2_0_i19);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__vn_util__find_specials_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	MR_field(MR_mktag(1), r1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
Define_label(mercury__vn_util__find_specials_2_0_i21);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE

extern const struct MR_TypeCtorInfo_struct
	mercury_data_vn_type__type_ctor_info_vnlval_0;
Declare_entry(mercury__set__insert_3_1);

BEGIN_MODULE(vn_util_module11)
	init_entry(mercury__vn_util__convert_to_vnlval_and_insert_3_0);
	init_label(mercury__vn_util__convert_to_vnlval_and_insert_3_0_i1002);
	init_label(mercury__vn_util__convert_to_vnlval_and_insert_3_0_i4);
	init_label(mercury__vn_util__convert_to_vnlval_and_insert_3_0_i6);
	init_label(mercury__vn_util__convert_to_vnlval_and_insert_3_0_i7);
	init_label(mercury__vn_util__convert_to_vnlval_and_insert_3_0_i3);
BEGIN_CODE

/* code for predicate 'convert_to_vnlval_and_insert'/3 in mode 0 */
Define_entry(mercury__vn_util__convert_to_vnlval_and_insert_3_0);
	MR_incr_sp_push_msg(3, "vn_util:convert_to_vnlval_and_insert/3");
	MR_stackvar(3) = (Word) MR_succip;
Define_label(mercury__vn_util__convert_to_vnlval_and_insert_3_0_i1002);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_util__convert_to_vnlval_and_insert_3_0_i3);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__vn_util__no_access_lval_to_vnlval_2_0),
		mercury__vn_util__convert_to_vnlval_and_insert_3_0_i4,
		ENTRY(mercury__vn_util__convert_to_vnlval_and_insert_3_0));
Define_label(mercury__vn_util__convert_to_vnlval_and_insert_3_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_util__convert_to_vnlval_and_insert_3_0));
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_util__convert_to_vnlval_and_insert_3_0_i6);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	GOTO_LABEL(mercury__vn_util__convert_to_vnlval_and_insert_3_0_i1002);
Define_label(mercury__vn_util__convert_to_vnlval_and_insert_3_0_i6);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0;
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__vn_util__convert_to_vnlval_and_insert_3_0_i7,
		ENTRY(mercury__vn_util__convert_to_vnlval_and_insert_3_0));
Define_label(mercury__vn_util__convert_to_vnlval_and_insert_3_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_util__convert_to_vnlval_and_insert_3_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	GOTO_LABEL(mercury__vn_util__convert_to_vnlval_and_insert_3_0_i1002);
Define_label(mercury__vn_util__convert_to_vnlval_and_insert_3_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE

Declare_entry(mercury__require__error_1_0);

BEGIN_MODULE(vn_util_module12)
	init_entry(mercury__vn_util__rval_to_vn_4_0);
	init_label(mercury__vn_util__rval_to_vn_4_0_i1005);
	init_label(mercury__vn_util__rval_to_vn_4_0_i1006);
	init_label(mercury__vn_util__rval_to_vn_4_0_i1007);
	init_label(mercury__vn_util__rval_to_vn_4_0_i10);
	init_label(mercury__vn_util__rval_to_vn_4_0_i11);
	init_label(mercury__vn_util__rval_to_vn_4_0_i12);
	init_label(mercury__vn_util__rval_to_vn_4_0_i14);
	init_label(mercury__vn_util__rval_to_vn_4_0_i16);
	init_label(mercury__vn_util__rval_to_vn_4_0_i17);
	init_label(mercury__vn_util__rval_to_vn_4_0_i19);
	init_label(mercury__vn_util__rval_to_vn_4_0_i20);
	init_label(mercury__vn_util__rval_to_vn_4_0_i21);
	init_label(mercury__vn_util__rval_to_vn_4_0_i23);
BEGIN_CODE

/* code for predicate 'rval_to_vn'/4 in mode 0 */
Define_entry(mercury__vn_util__rval_to_vn_4_0);
	MR_incr_sp_push_msg(3, "vn_util:rval_to_vn/4");
	MR_stackvar(3) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__vn_util__rval_to_vn_4_0_i1005) AND
		LABEL(mercury__vn_util__rval_to_vn_4_0_i1006) AND
		LABEL(mercury__vn_util__rval_to_vn_4_0_i1007) AND
		LABEL(mercury__vn_util__rval_to_vn_4_0_i10));
Define_label(mercury__vn_util__rval_to_vn_4_0_i1005);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__vn_util__lval_to_vn_4_0),
		ENTRY(mercury__vn_util__rval_to_vn_4_0));
Define_label(mercury__vn_util__rval_to_vn_4_0_i1006);
	r1 = (Word) MR_string_const("value_number should never get rval: var", 39);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__vn_util__rval_to_vn_4_0));
Define_label(mercury__vn_util__rval_to_vn_4_0_i1007);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 7, mercury__vn_util__rval_to_vn_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), r1, (Integer) 6) = MR_const_field(MR_mktag(2), r3, (Integer) 5);
	MR_field(MR_mktag(3), r1, (Integer) 5) = MR_const_field(MR_mktag(2), r3, (Integer) 4);
	MR_field(MR_mktag(3), r1, (Integer) 4) = MR_const_field(MR_mktag(2), r3, (Integer) 3);
	MR_field(MR_mktag(3), r1, (Integer) 3) = MR_const_field(MR_mktag(2), r3, (Integer) 2);
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_const_field(MR_mktag(2), r3, (Integer) 1);
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_const_field(MR_mktag(2), r3, (Integer) 0);
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 0;
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__vn_util__vnrval_to_vn_4_0),
		ENTRY(mercury__vn_util__rval_to_vn_4_0));
Define_label(mercury__vn_util__rval_to_vn_4_0_i10);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__vn_util__rval_to_vn_4_0_i11) AND
		LABEL(mercury__vn_util__rval_to_vn_4_0_i14) AND
		LABEL(mercury__vn_util__rval_to_vn_4_0_i16) AND
		LABEL(mercury__vn_util__rval_to_vn_4_0_i19) AND
		LABEL(mercury__vn_util__rval_to_vn_4_0_i23));
Define_label(mercury__vn_util__rval_to_vn_4_0_i11);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	localcall(mercury__vn_util__rval_to_vn_4_0,
		LABEL(mercury__vn_util__rval_to_vn_4_0_i12),
		ENTRY(mercury__vn_util__rval_to_vn_4_0));
Define_label(mercury__vn_util__rval_to_vn_4_0_i12);
	update_prof_current_proc(LABEL(mercury__vn_util__rval_to_vn_4_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__vn_util__rval_to_vn_4_0, "vn_type:vnrval/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__vn_util__vnrval_to_vn_4_0),
		ENTRY(mercury__vn_util__rval_to_vn_4_0));
Define_label(mercury__vn_util__rval_to_vn_4_0_i14);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 1, mercury__vn_util__rval_to_vn_4_0, "vn_type:vnrval/0");
	MR_field(MR_mktag(2), r1, (Integer) 0) = MR_const_field(MR_mktag(3), r3, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__vn_util__vnrval_to_vn_4_0),
		ENTRY(mercury__vn_util__rval_to_vn_4_0));
Define_label(mercury__vn_util__rval_to_vn_4_0_i16);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	localcall(mercury__vn_util__rval_to_vn_4_0,
		LABEL(mercury__vn_util__rval_to_vn_4_0_i17),
		ENTRY(mercury__vn_util__rval_to_vn_4_0));
Define_label(mercury__vn_util__rval_to_vn_4_0_i17);
	update_prof_current_proc(LABEL(mercury__vn_util__rval_to_vn_4_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 3, mercury__vn_util__rval_to_vn_4_0, "vn_type:vnrval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), r1, (Integer) 2) = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__vn_util__vnrval_to_vn_4_0),
		ENTRY(mercury__vn_util__rval_to_vn_4_0));
Define_label(mercury__vn_util__rval_to_vn_4_0_i19);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	localcall(mercury__vn_util__rval_to_vn_4_0,
		LABEL(mercury__vn_util__rval_to_vn_4_0_i20),
		ENTRY(mercury__vn_util__rval_to_vn_4_0));
Define_label(mercury__vn_util__rval_to_vn_4_0_i20);
	update_prof_current_proc(LABEL(mercury__vn_util__rval_to_vn_4_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r3;
	localcall(mercury__vn_util__rval_to_vn_4_0,
		LABEL(mercury__vn_util__rval_to_vn_4_0_i21),
		ENTRY(mercury__vn_util__rval_to_vn_4_0));
Define_label(mercury__vn_util__rval_to_vn_4_0_i21);
	update_prof_current_proc(LABEL(mercury__vn_util__rval_to_vn_4_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__vn_util__rval_to_vn_4_0, "vn_type:vnrval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(3), r1, (Integer) 3) = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__vn_util__vnrval_to_vn_4_0),
		ENTRY(mercury__vn_util__rval_to_vn_4_0));
Define_label(mercury__vn_util__rval_to_vn_4_0_i23);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__vn_util__mem_ref_to_vn_4_0),
		ENTRY(mercury__vn_util__rval_to_vn_4_0));
END_MODULE

Declare_entry(mercury__vn_table__search_desired_value_3_0);
Declare_entry(mercury__vn_table__record_first_vnlval_4_0);

BEGIN_MODULE(vn_util_module13)
	init_entry(mercury__vn_util__lval_to_vn_4_0);
	init_label(mercury__vn_util__lval_to_vn_4_0_i2);
	init_label(mercury__vn_util__lval_to_vn_4_0_i5);
	init_label(mercury__vn_util__lval_to_vn_4_0_i3);
BEGIN_CODE

/* code for predicate 'lval_to_vn'/4 in mode 0 */
Define_entry(mercury__vn_util__lval_to_vn_4_0);
	MR_incr_sp_push_msg(3, "vn_util:lval_to_vn/4");
	MR_stackvar(3) = (Word) MR_succip;
	call_localret(STATIC(mercury__vn_util__lval_to_vnlval_4_0),
		mercury__vn_util__lval_to_vn_4_0_i2,
		ENTRY(mercury__vn_util__lval_to_vn_4_0));
Define_label(mercury__vn_util__lval_to_vn_4_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_util__lval_to_vn_4_0));
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__vn_table__search_desired_value_3_0),
		mercury__vn_util__lval_to_vn_4_0_i5,
		ENTRY(mercury__vn_util__lval_to_vn_4_0));
Define_label(mercury__vn_util__lval_to_vn_4_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_util__lval_to_vn_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_util__lval_to_vn_4_0_i3);
	r1 = r2;
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_util__lval_to_vn_4_0_i3);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__vn_table__record_first_vnlval_4_0),
		ENTRY(mercury__vn_util__lval_to_vn_4_0));
END_MODULE


BEGIN_MODULE(vn_util_module14)
	init_entry(mercury__vn_util__lval_to_vnlval_4_0);
	init_label(mercury__vn_util__lval_to_vnlval_4_0_i2);
	init_label(mercury__vn_util__lval_to_vnlval_4_0_i3);
	init_label(mercury__vn_util__lval_to_vnlval_4_0_i7);
	init_label(mercury__vn_util__lval_to_vnlval_4_0_i8);
	init_label(mercury__vn_util__lval_to_vnlval_4_0_i5);
	init_label(mercury__vn_util__lval_to_vnlval_4_0_i11);
	init_label(mercury__vn_util__lval_to_vnlval_4_0_i1022);
	init_label(mercury__vn_util__lval_to_vnlval_4_0_i1023);
	init_label(mercury__vn_util__lval_to_vnlval_4_0_i14);
	init_label(mercury__vn_util__lval_to_vnlval_4_0_i12);
	init_label(mercury__vn_util__lval_to_vnlval_4_0_i17);
	init_label(mercury__vn_util__lval_to_vnlval_4_0_i1026);
	init_label(mercury__vn_util__lval_to_vnlval_4_0_i1027);
	init_label(mercury__vn_util__lval_to_vnlval_4_0_i20);
	init_label(mercury__vn_util__lval_to_vnlval_4_0_i18);
	init_label(mercury__vn_util__lval_to_vnlval_4_0_i23);
	init_label(mercury__vn_util__lval_to_vnlval_4_0_i1030);
	init_label(mercury__vn_util__lval_to_vnlval_4_0_i1031);
	init_label(mercury__vn_util__lval_to_vnlval_4_0_i26);
	init_label(mercury__vn_util__lval_to_vnlval_4_0_i24);
BEGIN_CODE

/* code for predicate 'lval_to_vnlval'/4 in mode 0 */
Define_entry(mercury__vn_util__lval_to_vnlval_4_0);
	MR_incr_sp_push_msg(3, "vn_util:lval_to_vnlval/4");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	call_localret(STATIC(mercury__vn_util__no_access_lval_to_vnlval_2_0),
		mercury__vn_util__lval_to_vnlval_4_0_i2,
		ENTRY(mercury__vn_util__lval_to_vnlval_4_0));
Define_label(mercury__vn_util__lval_to_vnlval_4_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_util__lval_to_vnlval_4_0));
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_util__lval_to_vnlval_4_0_i3);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_util__lval_to_vnlval_4_0_i3);
	if ((MR_tag(MR_stackvar(1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__vn_util__lval_to_vnlval_4_0_i5);
	if (((Integer) MR_const_field(MR_mktag(3), MR_stackvar(1), (Integer) 0) != (Integer) 7))
		GOTO_LABEL(mercury__vn_util__lval_to_vnlval_4_0_i5);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(1);
	r1 = MR_const_field(MR_mktag(3), r3, (Integer) 2);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r3, (Integer) 3);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r3, (Integer) 1);
	call_localret(STATIC(mercury__vn_util__rval_to_vn_4_0),
		mercury__vn_util__lval_to_vnlval_4_0_i7,
		ENTRY(mercury__vn_util__lval_to_vnlval_4_0));
Define_label(mercury__vn_util__lval_to_vnlval_4_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_util__lval_to_vnlval_4_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	MR_stackvar(2) = r3;
	call_localret(STATIC(mercury__vn_util__rval_to_vn_4_0),
		mercury__vn_util__lval_to_vnlval_4_0_i8,
		ENTRY(mercury__vn_util__lval_to_vnlval_4_0));
Define_label(mercury__vn_util__lval_to_vnlval_4_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_util__lval_to_vnlval_4_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__vn_util__lval_to_vnlval_4_0, "vn_type:vnlval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 7;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_stackvar(1);
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(3), r1, (Integer) 3) = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_util__lval_to_vnlval_4_0_i5);
	r3 = MR_stackvar(1);
	if ((MR_tag(r3) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__vn_util__lval_to_vnlval_4_0_i1022);
	if (((Integer) MR_const_field(MR_mktag(3), r3, (Integer) 0) != (Integer) 8))
		GOTO_LABEL(mercury__vn_util__lval_to_vnlval_4_0_i1023);
	r1 = MR_const_field(MR_mktag(3), r3, (Integer) 1);
	r2 = MR_stackvar(2);
	call_localret(STATIC(mercury__vn_util__rval_to_vn_4_0),
		mercury__vn_util__lval_to_vnlval_4_0_i11,
		ENTRY(mercury__vn_util__lval_to_vnlval_4_0));
Define_label(mercury__vn_util__lval_to_vnlval_4_0_i11);
	update_prof_current_proc(LABEL(mercury__vn_util__lval_to_vnlval_4_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__vn_util__lval_to_vnlval_4_0, "vn_type:vnlval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 8;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_util__lval_to_vnlval_4_0_i1022);
	if ((MR_tag(r3) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__vn_util__lval_to_vnlval_4_0_i12);
	r3 = MR_const_field(MR_mktag(3), r3, (Integer) 0);
	if (((Integer) r3 != (Integer) 6))
		GOTO_LABEL(mercury__vn_util__lval_to_vnlval_4_0_i12);
	r1 = MR_const_field(MR_mktag(3), MR_stackvar(1), (Integer) 1);
	r2 = MR_stackvar(2);
	call_localret(STATIC(mercury__vn_util__rval_to_vn_4_0),
		mercury__vn_util__lval_to_vnlval_4_0_i14,
		ENTRY(mercury__vn_util__lval_to_vnlval_4_0));
Define_label(mercury__vn_util__lval_to_vnlval_4_0_i1023);
	if ((MR_tag(r3) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__vn_util__lval_to_vnlval_4_0_i12);
	r3 = MR_const_field(MR_mktag(3), r3, (Integer) 0);
	if (((Integer) r3 != (Integer) 6))
		GOTO_LABEL(mercury__vn_util__lval_to_vnlval_4_0_i12);
	r1 = MR_const_field(MR_mktag(3), MR_stackvar(1), (Integer) 1);
	r2 = MR_stackvar(2);
	call_localret(STATIC(mercury__vn_util__rval_to_vn_4_0),
		mercury__vn_util__lval_to_vnlval_4_0_i14,
		ENTRY(mercury__vn_util__lval_to_vnlval_4_0));
Define_label(mercury__vn_util__lval_to_vnlval_4_0_i14);
	update_prof_current_proc(LABEL(mercury__vn_util__lval_to_vnlval_4_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__vn_util__lval_to_vnlval_4_0, "vn_type:vnlval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_util__lval_to_vnlval_4_0_i12);
	r3 = MR_stackvar(1);
	if ((MR_tag(r3) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__vn_util__lval_to_vnlval_4_0_i1026);
	if (((Integer) MR_const_field(MR_mktag(3), r3, (Integer) 0) != (Integer) 3))
		GOTO_LABEL(mercury__vn_util__lval_to_vnlval_4_0_i1027);
	r1 = MR_const_field(MR_mktag(3), r3, (Integer) 1);
	r2 = MR_stackvar(2);
	call_localret(STATIC(mercury__vn_util__rval_to_vn_4_0),
		mercury__vn_util__lval_to_vnlval_4_0_i17,
		ENTRY(mercury__vn_util__lval_to_vnlval_4_0));
Define_label(mercury__vn_util__lval_to_vnlval_4_0_i17);
	update_prof_current_proc(LABEL(mercury__vn_util__lval_to_vnlval_4_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__vn_util__lval_to_vnlval_4_0, "vn_type:vnlval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 5;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_util__lval_to_vnlval_4_0_i1026);
	if ((MR_tag(r3) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__vn_util__lval_to_vnlval_4_0_i18);
	r3 = MR_const_field(MR_mktag(3), r3, (Integer) 0);
	if (((Integer) r3 != (Integer) 4))
		GOTO_LABEL(mercury__vn_util__lval_to_vnlval_4_0_i18);
	r1 = MR_const_field(MR_mktag(3), MR_stackvar(1), (Integer) 1);
	r2 = MR_stackvar(2);
	call_localret(STATIC(mercury__vn_util__rval_to_vn_4_0),
		mercury__vn_util__lval_to_vnlval_4_0_i20,
		ENTRY(mercury__vn_util__lval_to_vnlval_4_0));
Define_label(mercury__vn_util__lval_to_vnlval_4_0_i1027);
	if ((MR_tag(r3) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__vn_util__lval_to_vnlval_4_0_i18);
	r3 = MR_const_field(MR_mktag(3), r3, (Integer) 0);
	if (((Integer) r3 != (Integer) 4))
		GOTO_LABEL(mercury__vn_util__lval_to_vnlval_4_0_i18);
	r1 = MR_const_field(MR_mktag(3), MR_stackvar(1), (Integer) 1);
	r2 = MR_stackvar(2);
	call_localret(STATIC(mercury__vn_util__rval_to_vn_4_0),
		mercury__vn_util__lval_to_vnlval_4_0_i20,
		ENTRY(mercury__vn_util__lval_to_vnlval_4_0));
Define_label(mercury__vn_util__lval_to_vnlval_4_0_i20);
	update_prof_current_proc(LABEL(mercury__vn_util__lval_to_vnlval_4_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__vn_util__lval_to_vnlval_4_0, "vn_type:vnlval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_util__lval_to_vnlval_4_0_i18);
	r3 = MR_stackvar(1);
	if ((MR_tag(r3) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__vn_util__lval_to_vnlval_4_0_i1030);
	if (((Integer) MR_const_field(MR_mktag(3), r3, (Integer) 0) != (Integer) 2))
		GOTO_LABEL(mercury__vn_util__lval_to_vnlval_4_0_i1031);
	r1 = MR_const_field(MR_mktag(3), r3, (Integer) 1);
	r2 = MR_stackvar(2);
	call_localret(STATIC(mercury__vn_util__rval_to_vn_4_0),
		mercury__vn_util__lval_to_vnlval_4_0_i23,
		ENTRY(mercury__vn_util__lval_to_vnlval_4_0));
Define_label(mercury__vn_util__lval_to_vnlval_4_0_i23);
	update_prof_current_proc(LABEL(mercury__vn_util__lval_to_vnlval_4_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__vn_util__lval_to_vnlval_4_0, "vn_type:vnlval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 6;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_util__lval_to_vnlval_4_0_i1030);
	if ((MR_tag(r3) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__vn_util__lval_to_vnlval_4_0_i24);
	r3 = MR_const_field(MR_mktag(3), r3, (Integer) 0);
	if (((Integer) r3 != (Integer) 5))
		GOTO_LABEL(mercury__vn_util__lval_to_vnlval_4_0_i24);
	r1 = MR_const_field(MR_mktag(3), MR_stackvar(1), (Integer) 1);
	r2 = MR_stackvar(2);
	call_localret(STATIC(mercury__vn_util__rval_to_vn_4_0),
		mercury__vn_util__lval_to_vnlval_4_0_i26,
		ENTRY(mercury__vn_util__lval_to_vnlval_4_0));
Define_label(mercury__vn_util__lval_to_vnlval_4_0_i1031);
	if ((MR_tag(r3) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__vn_util__lval_to_vnlval_4_0_i24);
	r3 = MR_const_field(MR_mktag(3), r3, (Integer) 0);
	if (((Integer) r3 != (Integer) 5))
		GOTO_LABEL(mercury__vn_util__lval_to_vnlval_4_0_i24);
	r1 = MR_const_field(MR_mktag(3), MR_stackvar(1), (Integer) 1);
	r2 = MR_stackvar(2);
	call_localret(STATIC(mercury__vn_util__rval_to_vn_4_0),
		mercury__vn_util__lval_to_vnlval_4_0_i26,
		ENTRY(mercury__vn_util__lval_to_vnlval_4_0));
Define_label(mercury__vn_util__lval_to_vnlval_4_0_i26);
	update_prof_current_proc(LABEL(mercury__vn_util__lval_to_vnlval_4_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__vn_util__lval_to_vnlval_4_0, "vn_type:vnlval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_util__lval_to_vnlval_4_0_i24);
	r1 = (Word) MR_string_const("unexpected lval in vn_util__lval_to_vnlval", 42);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__vn_util__lval_to_vnlval_4_0));
END_MODULE

Declare_entry(mercury__vn_table__lookup_defn_4_0);
Declare_entry(mercury__bool__and_3_0);

BEGIN_MODULE(vn_util_module15)
	init_entry(mercury__vn_util__is_const_expr_3_0);
	init_label(mercury__vn_util__is_const_expr_3_0_i1000);
	init_label(mercury__vn_util__is_const_expr_3_0_i2);
	init_label(mercury__vn_util__is_const_expr_3_0_i6);
	init_label(mercury__vn_util__is_const_expr_3_0_i9);
	init_label(mercury__vn_util__is_const_expr_3_0_i10);
	init_label(mercury__vn_util__is_const_expr_3_0_i11);
	init_label(mercury__vn_util__is_const_expr_3_0_i13);
	init_label(mercury__vn_util__is_const_expr_3_0_i14);
	init_label(mercury__vn_util__is_const_expr_3_0_i15);
	init_label(mercury__vn_util__is_const_expr_3_0_i19);
BEGIN_CODE

/* code for predicate 'is_const_expr'/3 in mode 0 */
Define_entry(mercury__vn_util__is_const_expr_3_0);
	MR_incr_sp_push_msg(3, "vn_util:is_const_expr/3");
	MR_stackvar(3) = (Word) MR_succip;
Define_label(mercury__vn_util__is_const_expr_3_0_i1000);
	MR_stackvar(1) = r2;
	r3 = r2;
	r2 = (Word) MR_string_const("vn_util__is_const_expr", 22);
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_util__is_const_expr_3_0_i2,
		ENTRY(mercury__vn_util__is_const_expr_3_0));
Define_label(mercury__vn_util__is_const_expr_3_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_util__is_const_expr_3_0));
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__vn_util__is_const_expr_3_0_i19) AND
		LABEL(mercury__vn_util__is_const_expr_3_0_i6) AND
		LABEL(mercury__vn_util__is_const_expr_3_0_i10) AND
		LABEL(mercury__vn_util__is_const_expr_3_0_i9));
Define_label(mercury__vn_util__is_const_expr_3_0_i6);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	GOTO_LABEL(mercury__vn_util__is_const_expr_3_0_i1000);
Define_label(mercury__vn_util__is_const_expr_3_0_i9);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__vn_util__is_const_expr_3_0_i10) AND
		LABEL(mercury__vn_util__is_const_expr_3_0_i11) AND
		LABEL(mercury__vn_util__is_const_expr_3_0_i13) AND
		LABEL(mercury__vn_util__is_const_expr_3_0_i19) AND
		LABEL(mercury__vn_util__is_const_expr_3_0_i19) AND
		LABEL(mercury__vn_util__is_const_expr_3_0_i19));
Define_label(mercury__vn_util__is_const_expr_3_0_i10);
	r1 = (Integer) 1;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_util__is_const_expr_3_0_i11);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	GOTO_LABEL(mercury__vn_util__is_const_expr_3_0_i1000);
Define_label(mercury__vn_util__is_const_expr_3_0_i13);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r2 = MR_stackvar(1);
	localcall(mercury__vn_util__is_const_expr_3_0,
		LABEL(mercury__vn_util__is_const_expr_3_0_i14),
		ENTRY(mercury__vn_util__is_const_expr_3_0));
Define_label(mercury__vn_util__is_const_expr_3_0_i14);
	update_prof_current_proc(LABEL(mercury__vn_util__is_const_expr_3_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(2);
	localcall(mercury__vn_util__is_const_expr_3_0,
		LABEL(mercury__vn_util__is_const_expr_3_0_i15),
		ENTRY(mercury__vn_util__is_const_expr_3_0));
Define_label(mercury__vn_util__is_const_expr_3_0_i15);
	update_prof_current_proc(LABEL(mercury__vn_util__is_const_expr_3_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__bool__and_3_0),
		ENTRY(mercury__vn_util__is_const_expr_3_0));
Define_label(mercury__vn_util__is_const_expr_3_0_i19);
	r1 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(vn_util_module16)
	init_entry(mercury__vn_util__vnlval_access_vns_2_0);
	init_label(mercury__vn_util__vnlval_access_vns_2_0_i12);
	init_label(mercury__vn_util__vnlval_access_vns_2_0_i14);
	init_label(mercury__vn_util__vnlval_access_vns_2_0_i20);
	init_label(mercury__vn_util__vnlval_access_vns_2_0_i21);
BEGIN_CODE

/* code for predicate 'vnlval_access_vns'/2 in mode 0 */
Define_entry(mercury__vn_util__vnlval_access_vns_2_0);
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__vn_util__vnlval_access_vns_2_0_i14) AND
		LABEL(mercury__vn_util__vnlval_access_vns_2_0_i14) AND
		LABEL(mercury__vn_util__vnlval_access_vns_2_0_i14) AND
		LABEL(mercury__vn_util__vnlval_access_vns_2_0_i12));
Define_label(mercury__vn_util__vnlval_access_vns_2_0_i12);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__vn_util__vnlval_access_vns_2_0_i14) AND
		LABEL(mercury__vn_util__vnlval_access_vns_2_0_i14) AND
		LABEL(mercury__vn_util__vnlval_access_vns_2_0_i21) AND
		LABEL(mercury__vn_util__vnlval_access_vns_2_0_i21) AND
		LABEL(mercury__vn_util__vnlval_access_vns_2_0_i21) AND
		LABEL(mercury__vn_util__vnlval_access_vns_2_0_i21) AND
		LABEL(mercury__vn_util__vnlval_access_vns_2_0_i21) AND
		LABEL(mercury__vn_util__vnlval_access_vns_2_0_i20) AND
		LABEL(mercury__vn_util__vnlval_access_vns_2_0_i21));
Define_label(mercury__vn_util__vnlval_access_vns_2_0_i14);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
Define_label(mercury__vn_util__vnlval_access_vns_2_0_i20);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__vn_util__vnlval_access_vns_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_const_field(MR_mktag(3), r2, (Integer) 2);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__vn_util__vnlval_access_vns_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_const_field(MR_mktag(3), r2, (Integer) 3);
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	proceed();
Define_label(mercury__vn_util__vnlval_access_vns_2_0_i21);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__vn_util__vnlval_access_vns_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE


BEGIN_MODULE(vn_util_module17)
	init_entry(mercury__vn_util__no_access_vnlval_to_lval_2_0);
	init_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i4);
	init_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i5);
	init_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i6);
	init_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i7);
	init_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i8);
	init_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i9);
	init_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i10);
	init_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i11);
	init_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i12);
	init_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i13);
	init_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i14);
	init_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i21);
BEGIN_CODE

/* code for predicate 'no_access_vnlval_to_lval'/2 in mode 0 */
Define_entry(mercury__vn_util__no_access_vnlval_to_lval_2_0);
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__vn_util__no_access_vnlval_to_lval_2_0_i4) AND
		LABEL(mercury__vn_util__no_access_vnlval_to_lval_2_0_i10) AND
		LABEL(mercury__vn_util__no_access_vnlval_to_lval_2_0_i11) AND
		LABEL(mercury__vn_util__no_access_vnlval_to_lval_2_0_i12));
Define_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i4);
	COMPUTED_GOTO((Unsigned) MR_unmkbody(r1),
		LABEL(mercury__vn_util__no_access_vnlval_to_lval_2_0_i5) AND
		LABEL(mercury__vn_util__no_access_vnlval_to_lval_2_0_i6) AND
		LABEL(mercury__vn_util__no_access_vnlval_to_lval_2_0_i7) AND
		LABEL(mercury__vn_util__no_access_vnlval_to_lval_2_0_i8) AND
		LABEL(mercury__vn_util__no_access_vnlval_to_lval_2_0_i9));
Define_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i5);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_vn_util__common_0);
	proceed();
Define_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i6);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_vn_util__common_1);
	proceed();
Define_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i7);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_vn_util__common_7);
	proceed();
Define_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i8);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_vn_util__common_8);
	proceed();
Define_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i9);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_vn_util__common_9);
	proceed();
Define_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i10);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__vn_util__no_access_vnlval_to_lval_2_0, "std_util:maybe/1");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__vn_util__no_access_vnlval_to_lval_2_0, "llds:lval/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	proceed();
Define_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i11);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__vn_util__no_access_vnlval_to_lval_2_0, "std_util:maybe/1");
	tag_incr_hp_msg(r3, MR_mktag(2), (Integer) 2, mercury__vn_util__no_access_vnlval_to_lval_2_0, "llds:lval/0");
	MR_field(MR_mktag(2), r3, (Integer) 0) = MR_const_field(MR_mktag(2), r2, (Integer) 0);
	MR_field(MR_mktag(2), r3, (Integer) 1) = MR_const_field(MR_mktag(2), r2, (Integer) 1);
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	proceed();
Define_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i12);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__vn_util__no_access_vnlval_to_lval_2_0_i13) AND
		LABEL(mercury__vn_util__no_access_vnlval_to_lval_2_0_i14) AND
		LABEL(mercury__vn_util__no_access_vnlval_to_lval_2_0_i21) AND
		LABEL(mercury__vn_util__no_access_vnlval_to_lval_2_0_i21) AND
		LABEL(mercury__vn_util__no_access_vnlval_to_lval_2_0_i21) AND
		LABEL(mercury__vn_util__no_access_vnlval_to_lval_2_0_i21) AND
		LABEL(mercury__vn_util__no_access_vnlval_to_lval_2_0_i21) AND
		LABEL(mercury__vn_util__no_access_vnlval_to_lval_2_0_i21) AND
		LABEL(mercury__vn_util__no_access_vnlval_to_lval_2_0_i21));
Define_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i13);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__vn_util__no_access_vnlval_to_lval_2_0, "std_util:maybe/1");
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 2, mercury__vn_util__no_access_vnlval_to_lval_2_0, "llds:lval/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(3), r3, (Integer) 1) = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	proceed();
Define_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i14);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__vn_util__no_access_vnlval_to_lval_2_0, "std_util:maybe/1");
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 2, mercury__vn_util__no_access_vnlval_to_lval_2_0, "llds:lval/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r3, (Integer) 1) = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	proceed();
Define_label(mercury__vn_util__no_access_vnlval_to_lval_2_0_i21);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE


BEGIN_MODULE(vn_util_module18)
	init_entry(mercury__vn_util__no_access_lval_to_vnlval_2_0);
	init_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i4);
	init_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i5);
	init_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i6);
	init_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i7);
	init_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i8);
	init_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i9);
	init_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i10);
	init_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i11);
	init_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i12);
	init_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i13);
	init_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i14);
	init_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i21);
	init_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i22);
BEGIN_CODE

/* code for predicate 'no_access_lval_to_vnlval'/2 in mode 0 */
Define_entry(mercury__vn_util__no_access_lval_to_vnlval_2_0);
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__vn_util__no_access_lval_to_vnlval_2_0_i4) AND
		LABEL(mercury__vn_util__no_access_lval_to_vnlval_2_0_i10) AND
		LABEL(mercury__vn_util__no_access_lval_to_vnlval_2_0_i11) AND
		LABEL(mercury__vn_util__no_access_lval_to_vnlval_2_0_i12));
Define_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i4);
	COMPUTED_GOTO((Unsigned) MR_unmkbody(r1),
		LABEL(mercury__vn_util__no_access_lval_to_vnlval_2_0_i5) AND
		LABEL(mercury__vn_util__no_access_lval_to_vnlval_2_0_i6) AND
		LABEL(mercury__vn_util__no_access_lval_to_vnlval_2_0_i7) AND
		LABEL(mercury__vn_util__no_access_lval_to_vnlval_2_0_i8) AND
		LABEL(mercury__vn_util__no_access_lval_to_vnlval_2_0_i9));
Define_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i5);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_vn_util__common_0);
	proceed();
Define_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i6);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_vn_util__common_1);
	proceed();
Define_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i7);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_vn_util__common_7);
	proceed();
Define_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i8);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_vn_util__common_8);
	proceed();
Define_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i9);
	r1 = (Word) MR_mkword(MR_mktag(1), (Word *) &mercury_data_vn_util__common_9);
	proceed();
Define_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i10);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__vn_util__no_access_lval_to_vnlval_2_0, "std_util:maybe/1");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__vn_util__no_access_lval_to_vnlval_2_0, "vn_type:vnlval/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	proceed();
Define_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i11);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__vn_util__no_access_lval_to_vnlval_2_0, "std_util:maybe/1");
	tag_incr_hp_msg(r3, MR_mktag(2), (Integer) 2, mercury__vn_util__no_access_lval_to_vnlval_2_0, "vn_type:vnlval/0");
	MR_field(MR_mktag(2), r3, (Integer) 0) = MR_const_field(MR_mktag(2), r2, (Integer) 0);
	MR_field(MR_mktag(2), r3, (Integer) 1) = MR_const_field(MR_mktag(2), r2, (Integer) 1);
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	proceed();
Define_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i12);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__vn_util__no_access_lval_to_vnlval_2_0_i13) AND
		LABEL(mercury__vn_util__no_access_lval_to_vnlval_2_0_i14) AND
		LABEL(mercury__vn_util__no_access_lval_to_vnlval_2_0_i21) AND
		LABEL(mercury__vn_util__no_access_lval_to_vnlval_2_0_i21) AND
		LABEL(mercury__vn_util__no_access_lval_to_vnlval_2_0_i21) AND
		LABEL(mercury__vn_util__no_access_lval_to_vnlval_2_0_i21) AND
		LABEL(mercury__vn_util__no_access_lval_to_vnlval_2_0_i21) AND
		LABEL(mercury__vn_util__no_access_lval_to_vnlval_2_0_i21) AND
		LABEL(mercury__vn_util__no_access_lval_to_vnlval_2_0_i21) AND
		LABEL(mercury__vn_util__no_access_lval_to_vnlval_2_0_i22));
Define_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i13);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__vn_util__no_access_lval_to_vnlval_2_0, "std_util:maybe/1");
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 2, mercury__vn_util__no_access_lval_to_vnlval_2_0, "vn_type:vnlval/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(3), r3, (Integer) 1) = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	proceed();
Define_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i14);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__vn_util__no_access_lval_to_vnlval_2_0, "std_util:maybe/1");
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 2, mercury__vn_util__no_access_lval_to_vnlval_2_0, "vn_type:vnlval/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r3, (Integer) 1) = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	MR_field(MR_mktag(1), r1, (Integer) 0) = r3;
	proceed();
Define_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i21);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
Define_label(mercury__vn_util__no_access_lval_to_vnlval_2_0_i22);
	r1 = (Word) MR_string_const("lvar detected in value_number", 29);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__vn_util__no_access_lval_to_vnlval_2_0));
END_MODULE


BEGIN_MODULE(vn_util_module19)
	init_entry(mercury__vn_util__find_sub_vns_2_0);
	init_label(mercury__vn_util__find_sub_vns_2_0_i4);
	init_label(mercury__vn_util__find_sub_vns_2_0_i8);
	init_label(mercury__vn_util__find_sub_vns_2_0_i10);
	init_label(mercury__vn_util__find_sub_vns_2_0_i11);
	init_label(mercury__vn_util__find_sub_vns_2_0_i13);
	init_label(mercury__vn_util__find_sub_vns_2_0_i14);
BEGIN_CODE

/* code for predicate 'find_sub_vns'/2 in mode 0 */
Define_entry(mercury__vn_util__find_sub_vns_2_0);
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__vn_util__find_sub_vns_2_0_i4) AND
		LABEL(mercury__vn_util__find_sub_vns_2_0_i14) AND
		LABEL(mercury__vn_util__find_sub_vns_2_0_i13) AND
		LABEL(mercury__vn_util__find_sub_vns_2_0_i8));
Define_label(mercury__vn_util__find_sub_vns_2_0_i4);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	tailcall(STATIC(mercury__vn_util__vnlval_access_vns_2_0),
		ENTRY(mercury__vn_util__find_sub_vns_2_0));
Define_label(mercury__vn_util__find_sub_vns_2_0_i8);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__vn_util__find_sub_vns_2_0_i13) AND
		LABEL(mercury__vn_util__find_sub_vns_2_0_i10) AND
		LABEL(mercury__vn_util__find_sub_vns_2_0_i11) AND
		LABEL(mercury__vn_util__find_sub_vns_2_0_i13) AND
		LABEL(mercury__vn_util__find_sub_vns_2_0_i13) AND
		LABEL(mercury__vn_util__find_sub_vns_2_0_i14));
Define_label(mercury__vn_util__find_sub_vns_2_0_i10);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__vn_util__find_sub_vns_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_const_field(MR_mktag(3), r2, (Integer) 2);
	MR_field(MR_mktag(1), r1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
Define_label(mercury__vn_util__find_sub_vns_2_0_i11);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__vn_util__find_sub_vns_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_const_field(MR_mktag(3), r2, (Integer) 2);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__vn_util__find_sub_vns_2_0, "list:list/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_const_field(MR_mktag(3), r2, (Integer) 3);
	MR_field(MR_mktag(1), r3, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_field(MR_mktag(1), r1, (Integer) 1) = r3;
	proceed();
Define_label(mercury__vn_util__find_sub_vns_2_0_i13);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
Define_label(mercury__vn_util__find_sub_vns_2_0_i14);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__vn_util__find_sub_vns_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_const_mask_field(r2, (Integer) 1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE

Declare_entry(mercury__opt_util__lval_access_rvals_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_llds__type_ctor_info_lval_0;
Declare_entry(mercury__list__append_3_1);

BEGIN_MODULE(vn_util_module20)
	init_entry(mercury__vn_util__find_lvals_in_rval_2_0);
	init_label(mercury__vn_util__find_lvals_in_rval_2_0_i4);
	init_label(mercury__vn_util__find_lvals_in_rval_2_0_i5);
	init_label(mercury__vn_util__find_lvals_in_rval_2_0_i6);
	init_label(mercury__vn_util__find_lvals_in_rval_2_0_i7);
	init_label(mercury__vn_util__find_lvals_in_rval_2_0_i10);
	init_label(mercury__vn_util__find_lvals_in_rval_2_0_i13);
	init_label(mercury__vn_util__find_lvals_in_rval_2_0_i14);
	init_label(mercury__vn_util__find_lvals_in_rval_2_0_i16);
	init_label(mercury__vn_util__find_lvals_in_rval_2_0_i17);
	init_label(mercury__vn_util__find_lvals_in_rval_2_0_i18);
	init_label(mercury__vn_util__find_lvals_in_rval_2_0_i20);
BEGIN_CODE

/* code for predicate 'find_lvals_in_rval'/2 in mode 0 */
Define_entry(mercury__vn_util__find_lvals_in_rval_2_0);
	MR_incr_sp_push_msg(2, "vn_util:find_lvals_in_rval/2");
	MR_stackvar(2) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__vn_util__find_lvals_in_rval_2_0_i4) AND
		LABEL(mercury__vn_util__find_lvals_in_rval_2_0_i7) AND
		LABEL(mercury__vn_util__find_lvals_in_rval_2_0_i13) AND
		LABEL(mercury__vn_util__find_lvals_in_rval_2_0_i10));
Define_label(mercury__vn_util__find_lvals_in_rval_2_0_i4);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(1) = r1;
	call_localret(ENTRY(mercury__opt_util__lval_access_rvals_2_0),
		mercury__vn_util__find_lvals_in_rval_2_0_i5,
		ENTRY(mercury__vn_util__find_lvals_in_rval_2_0));
Define_label(mercury__vn_util__find_lvals_in_rval_2_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_util__find_lvals_in_rval_2_0));
	call_localret(STATIC(mercury__vn_util__find_lvals_in_rvals_2_0),
		mercury__vn_util__find_lvals_in_rval_2_0_i6,
		ENTRY(mercury__vn_util__find_lvals_in_rval_2_0));
Define_label(mercury__vn_util__find_lvals_in_rval_2_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_util__find_lvals_in_rval_2_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__vn_util__find_lvals_in_rval_2_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__vn_util__find_lvals_in_rval_2_0_i7);
	r1 = (Word) MR_string_const("var found in vn_util__find_lvals_in_rval", 40);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__require__error_1_0),
		ENTRY(mercury__vn_util__find_lvals_in_rval_2_0));
Define_label(mercury__vn_util__find_lvals_in_rval_2_0_i10);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__vn_util__find_lvals_in_rval_2_0_i14) AND
		LABEL(mercury__vn_util__find_lvals_in_rval_2_0_i13) AND
		LABEL(mercury__vn_util__find_lvals_in_rval_2_0_i14) AND
		LABEL(mercury__vn_util__find_lvals_in_rval_2_0_i16) AND
		LABEL(mercury__vn_util__find_lvals_in_rval_2_0_i20));
Define_label(mercury__vn_util__find_lvals_in_rval_2_0_i13);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	proceed();
Define_label(mercury__vn_util__find_lvals_in_rval_2_0_i14);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_succip = (Code *) MR_stackvar(2);
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__vn_util__find_lvals_in_rval_2_0_i4) AND
		LABEL(mercury__vn_util__find_lvals_in_rval_2_0_i7) AND
		LABEL(mercury__vn_util__find_lvals_in_rval_2_0_i13) AND
		LABEL(mercury__vn_util__find_lvals_in_rval_2_0_i10));
Define_label(mercury__vn_util__find_lvals_in_rval_2_0_i16);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	localcall(mercury__vn_util__find_lvals_in_rval_2_0,
		LABEL(mercury__vn_util__find_lvals_in_rval_2_0_i17),
		ENTRY(mercury__vn_util__find_lvals_in_rval_2_0));
Define_label(mercury__vn_util__find_lvals_in_rval_2_0_i17);
	update_prof_current_proc(LABEL(mercury__vn_util__find_lvals_in_rval_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	localcall(mercury__vn_util__find_lvals_in_rval_2_0,
		LABEL(mercury__vn_util__find_lvals_in_rval_2_0_i18),
		ENTRY(mercury__vn_util__find_lvals_in_rval_2_0));
Define_label(mercury__vn_util__find_lvals_in_rval_2_0_i18);
	update_prof_current_proc(LABEL(mercury__vn_util__find_lvals_in_rval_2_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_lval_0;
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__list__append_3_1),
		ENTRY(mercury__vn_util__find_lvals_in_rval_2_0));
Define_label(mercury__vn_util__find_lvals_in_rval_2_0_i20);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__vn_util__find_lvals_in_mem_ref_2_0),
		ENTRY(mercury__vn_util__find_lvals_in_rval_2_0));
END_MODULE


BEGIN_MODULE(vn_util_module21)
	init_entry(mercury__vn_util__find_lvals_in_rvals_2_0);
	init_label(mercury__vn_util__find_lvals_in_rvals_2_0_i4);
	init_label(mercury__vn_util__find_lvals_in_rvals_2_0_i5);
	init_label(mercury__vn_util__find_lvals_in_rvals_2_0_i3);
BEGIN_CODE

/* code for predicate 'find_lvals_in_rvals'/2 in mode 0 */
Define_entry(mercury__vn_util__find_lvals_in_rvals_2_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_util__find_lvals_in_rvals_2_0_i3);
	MR_incr_sp_push_msg(2, "vn_util:find_lvals_in_rvals/2");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	call_localret(STATIC(mercury__vn_util__find_lvals_in_rval_2_0),
		mercury__vn_util__find_lvals_in_rvals_2_0_i4,
		ENTRY(mercury__vn_util__find_lvals_in_rvals_2_0));
Define_label(mercury__vn_util__find_lvals_in_rvals_2_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_util__find_lvals_in_rvals_2_0));
	r2 = r1;
	r1 = MR_stackvar(1);
	MR_stackvar(1) = r2;
	localcall(mercury__vn_util__find_lvals_in_rvals_2_0,
		LABEL(mercury__vn_util__find_lvals_in_rvals_2_0_i5),
		ENTRY(mercury__vn_util__find_lvals_in_rvals_2_0));
Define_label(mercury__vn_util__find_lvals_in_rvals_2_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_util__find_lvals_in_rvals_2_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_lval_0;
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(ENTRY(mercury__list__append_3_1),
		ENTRY(mercury__vn_util__find_lvals_in_rvals_2_0));
Define_label(mercury__vn_util__find_lvals_in_rvals_2_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE


BEGIN_MODULE(vn_util_module22)
	init_entry(mercury__vn_util__is_vn_shared_4_0);
	init_label(mercury__vn_util__is_vn_shared_4_0_i2);
	init_label(mercury__vn_util__is_vn_shared_4_0_i3);
	init_label(mercury__vn_util__is_vn_shared_4_0_i6);
	init_label(mercury__vn_util__is_vn_shared_4_0_i1);
BEGIN_CODE

/* code for predicate 'is_vn_shared'/4 in mode 0 */
Define_entry(mercury__vn_util__is_vn_shared_4_0);
	MR_incr_sp_push_msg(4, "vn_util:is_vn_shared/4");
	MR_stackvar(4) = (Word) MR_succip;
	MR_stackvar(1) = r2;
	r2 = r4;
	MR_stackvar(2) = r3;
	MR_stackvar(3) = r4;
	call_localret(STATIC(mercury__vn_util__is_const_expr_3_0),
		mercury__vn_util__is_vn_shared_4_0_i2,
		ENTRY(mercury__vn_util__is_vn_shared_4_0));
Define_label(mercury__vn_util__is_vn_shared_4_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_util__is_vn_shared_4_0));
	if (((Integer) 0 != (Integer) r1))
		GOTO_LABEL(mercury__vn_util__is_vn_shared_4_0_i1);
	if ((MR_tag(MR_stackvar(1)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__vn_util__is_vn_shared_4_0_i3);
	if (((Integer) MR_const_field(MR_mktag(0), MR_stackvar(1), (Integer) 0) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 3))))
		GOTO_LABEL(mercury__vn_util__is_vn_shared_4_0_i1);
Define_label(mercury__vn_util__is_vn_shared_4_0_i3);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(3);
	call_localret(STATIC(mercury__vn_util__real_uses_3_0),
		mercury__vn_util__is_vn_shared_4_0_i6,
		ENTRY(mercury__vn_util__is_vn_shared_4_0));
Define_label(mercury__vn_util__is_vn_shared_4_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_util__is_vn_shared_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_util__is_vn_shared_4_0_i1);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_util__is_vn_shared_4_0_i1);
	if (((Integer) MR_const_field(MR_mktag(1), r2, (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_util__is_vn_shared_4_0_i1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__is_vn_shared_4_0_i1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	r1 = FALSE;
	proceed();
END_MODULE

extern const struct MR_TypeCtorInfo_struct
	mercury_data_vn_type__type_ctor_info_vn_src_0;
Declare_entry(mercury__list__member_2_0);
Declare_entry(mercury__vn_table__search_current_value_3_0);
Declare_entry(mercury__vn_table__search_uses_3_0);
Declare_entry(mercury____Unify___list__list_1_0);
Declare_entry(mercury__vn_table__search_current_locs_3_0);

BEGIN_MODULE(vn_util_module23)
	init_entry(mercury__vn_util__real_uses_3_0);
	init_label(mercury__vn_util__real_uses_3_0_i3);
	init_label(mercury__vn_util__real_uses_3_0_i4);
	init_label(mercury__vn_util__real_uses_3_0_i7);
	init_label(mercury__vn_util__real_uses_3_0_i6);
	init_label(mercury__vn_util__real_uses_3_0_i12);
	init_label(mercury__vn_util__real_uses_3_0_i14);
	init_label(mercury__vn_util__real_uses_3_0_i1035);
	init_label(mercury__vn_util__real_uses_3_0_i20);
	init_label(mercury__vn_util__real_uses_3_0_i22);
	init_label(mercury__vn_util__real_uses_3_0_i26);
	init_label(mercury__vn_util__real_uses_3_0_i30);
	init_label(mercury__vn_util__real_uses_3_0_i32);
	init_label(mercury__vn_util__real_uses_3_0_i29);
	init_label(mercury__vn_util__real_uses_3_0_i34);
	init_label(mercury__vn_util__real_uses_3_0_i36);
	init_label(mercury__vn_util__real_uses_3_0_i38);
	init_label(mercury__vn_util__real_uses_3_0_i1016);
	init_label(mercury__vn_util__real_uses_3_0_i1053);
	init_label(mercury__vn_util__real_uses_3_0_i1);
BEGIN_CODE

/* code for predicate 'real_uses'/3 in mode 0 */
Define_entry(mercury__vn_util__real_uses_3_0);
	MR_incr_sp_push_msg(5, "vn_util:real_uses/3");
	MR_stackvar(5) = (Word) MR_succip;
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_util__real_uses_3_0_i3);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_util__real_uses_3_0_i3);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(1) = r2;
	localcall(mercury__vn_util__real_uses_3_0,
		LABEL(mercury__vn_util__real_uses_3_0_i4),
		ENTRY(mercury__vn_util__real_uses_3_0));
Define_label(mercury__vn_util__real_uses_3_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_util__real_uses_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_util__real_uses_3_0_i1);
	MR_stackvar(3) = r2;
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vn_src_0;
	r3 = r2;
	r2 = MR_stackvar(2);
	call_localret(ENTRY(mercury__list__member_2_0),
		mercury__vn_util__real_uses_3_0_i7,
		ENTRY(mercury__vn_util__real_uses_3_0));
Define_label(mercury__vn_util__real_uses_3_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_util__real_uses_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_util__real_uses_3_0_i6);
	r2 = MR_stackvar(3);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_util__real_uses_3_0_i6);
	r3 = MR_stackvar(2);
	if ((MR_tag(r3) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__real_uses_3_0_i1035);
	r1 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_stackvar(4) = r1;
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__vn_table__search_desired_value_3_0),
		mercury__vn_util__real_uses_3_0_i12,
		ENTRY(mercury__vn_util__real_uses_3_0));
Define_label(mercury__vn_util__real_uses_3_0_i12);
	update_prof_current_proc(LABEL(mercury__vn_util__real_uses_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_util__real_uses_3_0_i1053);
	r3 = r2;
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r3;
	r1 = MR_stackvar(4);
	call_localret(ENTRY(mercury__vn_table__search_current_value_3_0),
		mercury__vn_util__real_uses_3_0_i14,
		ENTRY(mercury__vn_util__real_uses_3_0));
Define_label(mercury__vn_util__real_uses_3_0_i14);
	update_prof_current_proc(LABEL(mercury__vn_util__real_uses_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_util__real_uses_3_0_i1053);
	if ((MR_stackvar(1) != r2))
		GOTO_LABEL(mercury__vn_util__real_uses_3_0_i1053);
	r2 = MR_stackvar(3);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_util__real_uses_3_0_i1035);
	if ((MR_tag(r3) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__real_uses_3_0_i1053);
	r1 = MR_const_field(MR_mktag(2), r3, (Integer) 0);
	MR_stackvar(4) = r1;
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__vn_table__search_desired_value_3_0),
		mercury__vn_util__real_uses_3_0_i20,
		ENTRY(mercury__vn_util__real_uses_3_0));
Define_label(mercury__vn_util__real_uses_3_0_i20);
	update_prof_current_proc(LABEL(mercury__vn_util__real_uses_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_util__real_uses_3_0_i1053);
	r1 = MR_stackvar(4);
	MR_stackvar(4) = r2;
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__vn_table__search_current_value_3_0),
		mercury__vn_util__real_uses_3_0_i22,
		ENTRY(mercury__vn_util__real_uses_3_0));
Define_label(mercury__vn_util__real_uses_3_0_i22);
	update_prof_current_proc(LABEL(mercury__vn_util__real_uses_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_util__real_uses_3_0_i1053);
	if ((MR_stackvar(4) != r2))
		GOTO_LABEL(mercury__vn_util__real_uses_3_0_i1053);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__vn_table__search_uses_3_0),
		mercury__vn_util__real_uses_3_0_i26,
		ENTRY(mercury__vn_util__real_uses_3_0));
Define_label(mercury__vn_util__real_uses_3_0_i26);
	update_prof_current_proc(LABEL(mercury__vn_util__real_uses_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_util__real_uses_3_0_i1016);
	r1 = r2;
	r2 = MR_stackvar(1);
	localcall(mercury__vn_util__real_uses_3_0,
		LABEL(mercury__vn_util__real_uses_3_0_i30),
		ENTRY(mercury__vn_util__real_uses_3_0));
Define_label(mercury__vn_util__real_uses_3_0_i30);
	update_prof_current_proc(LABEL(mercury__vn_util__real_uses_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_util__real_uses_3_0_i29);
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vn_src_0;
	r3 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(ENTRY(mercury____Unify___list__list_1_0),
		mercury__vn_util__real_uses_3_0_i32,
		ENTRY(mercury__vn_util__real_uses_3_0));
Define_label(mercury__vn_util__real_uses_3_0_i32);
	update_prof_current_proc(LABEL(mercury__vn_util__real_uses_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_util__real_uses_3_0_i29);
	r2 = MR_stackvar(3);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_util__real_uses_3_0_i29);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__vn_table__search_current_locs_3_0),
		mercury__vn_util__real_uses_3_0_i34,
		ENTRY(mercury__vn_util__real_uses_3_0));
Define_label(mercury__vn_util__real_uses_3_0_i34);
	update_prof_current_proc(LABEL(mercury__vn_util__real_uses_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_util__real_uses_3_0_i1053);
	r1 = r2;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(STATIC(mercury__vn_util__choose_cheapest_loc_2_4_0),
		mercury__vn_util__real_uses_3_0_i36,
		ENTRY(mercury__vn_util__real_uses_3_0));
Define_label(mercury__vn_util__real_uses_3_0_i36);
	update_prof_current_proc(LABEL(mercury__vn_util__real_uses_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_util__real_uses_3_0_i1053);
	r1 = r2;
	call_localret(STATIC(mercury__vn_util__classify_loc_cost_2_0),
		mercury__vn_util__real_uses_3_0_i38,
		ENTRY(mercury__vn_util__real_uses_3_0));
Define_label(mercury__vn_util__real_uses_3_0_i38);
	update_prof_current_proc(LABEL(mercury__vn_util__real_uses_3_0));
	if (((Integer) 0 != (Integer) r1))
		GOTO_LABEL(mercury__vn_util__real_uses_3_0_i1053);
Define_label(mercury__vn_util__real_uses_3_0_i1016);
	r2 = MR_stackvar(3);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_util__real_uses_3_0_i1053);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 2, mercury__vn_util__real_uses_3_0, "list:list/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(2);
	MR_field(MR_mktag(1), r2, (Integer) 1) = MR_stackvar(3);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_util__real_uses_3_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE


BEGIN_MODULE(vn_util_module24)
	init_entry(mercury__vn_util__choose_cheapest_loc_2_0);
BEGIN_CODE

/* code for predicate 'choose_cheapest_loc'/2 in mode 0 */
Define_entry(mercury__vn_util__choose_cheapest_loc_2_0);
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	tailcall(STATIC(mercury__vn_util__choose_cheapest_loc_2_4_0),
		ENTRY(mercury__vn_util__choose_cheapest_loc_2_0));
END_MODULE


BEGIN_MODULE(vn_util_module25)
	init_entry(mercury__vn_util__classify_loc_cost_2_0);
	init_label(mercury__vn_util__classify_loc_cost_2_0_i11);
	init_label(mercury__vn_util__classify_loc_cost_2_0_i12);
	init_label(mercury__vn_util__classify_loc_cost_2_0_i19);
	init_label(mercury__vn_util__classify_loc_cost_2_0_i21);
BEGIN_CODE

/* code for predicate 'classify_loc_cost'/2 in mode 0 */
Define_entry(mercury__vn_util__classify_loc_cost_2_0);
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__vn_util__classify_loc_cost_2_0_i11) AND
		LABEL(mercury__vn_util__classify_loc_cost_2_0_i11) AND
		LABEL(mercury__vn_util__classify_loc_cost_2_0_i11) AND
		LABEL(mercury__vn_util__classify_loc_cost_2_0_i12));
Define_label(mercury__vn_util__classify_loc_cost_2_0_i11);
	r1 = (Integer) 0;
	proceed();
Define_label(mercury__vn_util__classify_loc_cost_2_0_i12);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__vn_util__classify_loc_cost_2_0_i19) AND
		LABEL(mercury__vn_util__classify_loc_cost_2_0_i19) AND
		LABEL(mercury__vn_util__classify_loc_cost_2_0_i19) AND
		LABEL(mercury__vn_util__classify_loc_cost_2_0_i19) AND
		LABEL(mercury__vn_util__classify_loc_cost_2_0_i19) AND
		LABEL(mercury__vn_util__classify_loc_cost_2_0_i19) AND
		LABEL(mercury__vn_util__classify_loc_cost_2_0_i19) AND
		LABEL(mercury__vn_util__classify_loc_cost_2_0_i21) AND
		LABEL(mercury__vn_util__classify_loc_cost_2_0_i21));
Define_label(mercury__vn_util__classify_loc_cost_2_0_i19);
	r1 = (Integer) 1;
	proceed();
Define_label(mercury__vn_util__classify_loc_cost_2_0_i21);
	r1 = (Integer) 2;
	proceed();
END_MODULE


BEGIN_MODULE(vn_util_module26)
	init_entry(mercury__vn_util__mem_ref_to_vn_4_0);
	init_label(mercury__vn_util__mem_ref_to_vn_4_0_i6);
	init_label(mercury__vn_util__mem_ref_to_vn_4_0_i7);
	init_label(mercury__vn_util__mem_ref_to_vn_4_0_i4);
BEGIN_CODE

/* code for predicate 'mem_ref_to_vn'/4 in mode 0 */
Define_static(mercury__vn_util__mem_ref_to_vn_4_0);
	r3 = MR_tag(r1);
	if ((r3 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__mem_ref_to_vn_4_0_i4);
	MR_incr_sp_push_msg(3, "vn_util:mem_ref_to_vn/4");
	MR_stackvar(3) = (Word) MR_succip;
	if ((r3 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__mem_ref_to_vn_4_0_i6);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__vn_util__mem_ref_to_vn_4_0, "vn_type:vnrval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_const_field(MR_mktag(0), r3, (Integer) 0);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__vn_util__vnrval_to_vn_4_0),
		STATIC(mercury__vn_util__mem_ref_to_vn_4_0));
Define_label(mercury__vn_util__mem_ref_to_vn_4_0_i6);
	MR_stackvar(1) = MR_const_field(MR_mktag(2), r1, (Integer) 1);
	MR_stackvar(2) = MR_const_field(MR_mktag(2), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	call_localret(STATIC(mercury__vn_util__rval_to_vn_4_0),
		mercury__vn_util__mem_ref_to_vn_4_0_i7,
		STATIC(mercury__vn_util__mem_ref_to_vn_4_0));
Define_label(mercury__vn_util__mem_ref_to_vn_4_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_util__mem_ref_to_vn_4_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__vn_util__mem_ref_to_vn_4_0, "vn_type:vnrval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 5;
	MR_field(MR_mktag(3), r1, (Integer) 1) = r3;
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_stackvar(1);
	MR_field(MR_mktag(3), r1, (Integer) 3) = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__vn_util__vnrval_to_vn_4_0),
		STATIC(mercury__vn_util__mem_ref_to_vn_4_0));
Define_label(mercury__vn_util__mem_ref_to_vn_4_0_i4);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__vn_util__mem_ref_to_vn_4_0, "vn_type:vnrval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	tailcall(STATIC(mercury__vn_util__vnrval_to_vn_4_0),
		STATIC(mercury__vn_util__mem_ref_to_vn_4_0));
END_MODULE

Declare_entry(mercury__vn_table__search_assigned_vn_3_0);
Declare_entry(mercury__vn_table__record_new_vnrval_4_0);
Declare_entry(mercury__vn_table__record_first_vnrval_4_0);

BEGIN_MODULE(vn_util_module27)
	init_entry(mercury__vn_util__vnrval_to_vn_4_0);
	init_label(mercury__vn_util__vnrval_to_vn_4_0_i2);
	init_label(mercury__vn_util__vnrval_to_vn_4_0_i5);
	init_label(mercury__vn_util__vnrval_to_vn_4_0_i9);
	init_label(mercury__vn_util__vnrval_to_vn_4_0_i8);
	init_label(mercury__vn_util__vnrval_to_vn_4_0_i3);
BEGIN_CODE

/* code for predicate 'vnrval_to_vn'/4 in mode 0 */
Define_static(mercury__vn_util__vnrval_to_vn_4_0);
	MR_incr_sp_push_msg(3, "vn_util:vnrval_to_vn/4");
	MR_stackvar(3) = (Word) MR_succip;
	call_localret(STATIC(mercury__vn_util__simplify_vnrval_4_0),
		mercury__vn_util__vnrval_to_vn_4_0_i2,
		STATIC(mercury__vn_util__vnrval_to_vn_4_0));
Define_label(mercury__vn_util__vnrval_to_vn_4_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_util__vnrval_to_vn_4_0));
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	call_localret(ENTRY(mercury__vn_table__search_assigned_vn_3_0),
		mercury__vn_util__vnrval_to_vn_4_0_i5,
		STATIC(mercury__vn_util__vnrval_to_vn_4_0));
Define_label(mercury__vn_util__vnrval_to_vn_4_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_util__vnrval_to_vn_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_util__vnrval_to_vn_4_0_i3);
	if ((MR_tag(MR_stackvar(1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__vn_util__vnrval_to_vn_4_0_i9);
	if (((Integer) MR_const_field(MR_mktag(3), MR_stackvar(1), (Integer) 0) != (Integer) 1))
		GOTO_LABEL(mercury__vn_util__vnrval_to_vn_4_0_i9);
	r1 = MR_const_field(MR_mktag(3), MR_stackvar(1), (Integer) 1);
	if (((Integer) r1 == (Integer) 6))
		GOTO_LABEL(mercury__vn_util__vnrval_to_vn_4_0_i8);
Define_label(mercury__vn_util__vnrval_to_vn_4_0_i9);
	r1 = r2;
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_util__vnrval_to_vn_4_0_i8);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__vn_table__record_new_vnrval_4_0),
		STATIC(mercury__vn_util__vnrval_to_vn_4_0));
Define_label(mercury__vn_util__vnrval_to_vn_4_0_i3);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__vn_table__record_first_vnrval_4_0),
		STATIC(mercury__vn_util__vnrval_to_vn_4_0));
END_MODULE


BEGIN_MODULE(vn_util_module28)
	init_entry(mercury__vn_util__simplify_vnrval_4_0);
	init_label(mercury__vn_util__simplify_vnrval_4_0_i5);
	init_label(mercury__vn_util__simplify_vnrval_4_0_i2);
	init_label(mercury__vn_util__simplify_vnrval_4_0_i1004);
BEGIN_CODE

/* code for predicate 'simplify_vnrval'/4 in mode 0 */
Define_static(mercury__vn_util__simplify_vnrval_4_0);
	if ((MR_tag(r1) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_4_0_i1004);
	if (((Integer) MR_const_field(MR_mktag(3), r1, (Integer) 0) != (Integer) 2))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_4_0_i1004);
	MR_incr_sp_push_msg(3, "vn_util:simplify_vnrval/4");
	MR_stackvar(3) = (Word) MR_succip;
	r4 = r2;
	MR_stackvar(2) = r2;
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r3 = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	MR_stackvar(1) = r1;
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	call_localret(STATIC(mercury__vn_util__simplify_vnrval_binop_6_0),
		mercury__vn_util__simplify_vnrval_4_0_i5,
		STATIC(mercury__vn_util__simplify_vnrval_4_0));
Define_label(mercury__vn_util__simplify_vnrval_4_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_4_0_i2);
	r1 = r2;
	r2 = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_4_0_i2);
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_4_0_i1004);
	proceed();
END_MODULE

static const Float mercury_float_const_1pt00000000000000 = 1.00000000000000;

BEGIN_MODULE(vn_util_module29)
	init_entry(mercury__vn_util__simplify_vnrval_binop_6_0);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i2);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i3);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i5);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i6);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i17);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i20);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i11);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i12);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i21);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i30);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i26);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i27);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i40);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i45);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i48);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i49);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i36);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i37);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i54);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i59);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i50);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i51);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i69);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i73);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i70);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i81);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i82);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i76);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i84);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i91);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i92);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i97);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i106);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i108);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i120);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i121);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i130);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i131);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i140);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i141);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i146);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i150);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i157);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i158);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i163);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i167);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i175);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i176);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i179);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i182);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i190);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i191);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i194);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i197);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i205);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i206);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i207);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i214);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i218);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i219);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i220);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i227);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i232);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i233);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i235);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i236);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i238);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i239);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i241);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i242);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i244);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i245);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i247);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i248);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i250);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i251);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i253);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i254);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i256);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i257);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i259);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i260);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i262);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i263);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i274);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i277);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i268);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i269);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i278);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i287);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i283);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i284);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i297);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i302);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i305);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i306);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i293);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i294);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i311);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i316);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i307);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i308);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i326);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i330);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i327);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i338);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i339);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i340);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i333);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i341);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i348);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i349);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i354);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i363);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i365);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i376);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i377);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i379);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i380);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i382);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i383);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i385);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i386);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i388);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i389);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i391);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i392);
	init_label(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
BEGIN_CODE

/* code for predicate 'simplify_vnrval_binop'/6 in mode 0 */
Define_static(mercury__vn_util__simplify_vnrval_binop_6_0);
	MR_incr_sp_push_msg(8, "vn_util:simplify_vnrval_binop/6");
	MR_stackvar(8) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	MR_stackvar(3) = r3;
	r1 = r2;
	MR_stackvar(2) = r2;
	r2 = (Word) MR_string_const("vn_util__simplify_vnrval_binop", 30);
	r3 = r4;
	MR_stackvar(4) = r4;
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i2,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	MR_stackvar(5) = r1;
	r1 = MR_stackvar(3);
	r2 = (Word) MR_string_const("vn_util__simplify_vnrval_binop", 30);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i3,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i3);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	COMPUTED_GOTO((Unsigned) MR_stackvar(1),
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i5) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i69) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i91) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i106) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i120) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i130) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i140) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i157) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i175) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i190) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i205) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i218) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i232) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i235) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i238) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i241) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i244) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i247) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i250) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i253) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i256) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i259) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i262) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i326) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i348) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i363) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i376) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i379) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i382) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i385) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i388) AND
		LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i391));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i5);
	if ((MR_tag(MR_stackvar(5)) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i6);
	r2 = MR_const_field(MR_mktag(2), MR_stackvar(5), (Integer) 0);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i6);
	if ((MR_tag(r1) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i6);
	r3 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	if ((MR_tag(r3) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i6);
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 1, mercury__vn_util__simplify_vnrval_binop_6_0, "vn_type:vnrval/0");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__vn_util__simplify_vnrval_binop_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = ((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 0) + (Integer) MR_const_field(MR_mktag(1), r3, (Integer) 0));
	r1 = TRUE;
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
	}
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i6);
	if ((MR_tag(MR_stackvar(5)) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i12);
	r2 = MR_const_field(MR_mktag(2), MR_stackvar(5), (Integer) 0);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i12);
	if ((MR_tag(r1) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i12);
	if (((Integer) MR_const_field(MR_mktag(3), r1, (Integer) 0) != (Integer) 2))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i12);
	r3 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	if (((Integer) r3 != (Integer) 0))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i12);
	MR_stackvar(1) = r1;
	MR_stackvar(6) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(7) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	r2 = (Word) MR_string_const("vn_util__simplify_vnrval", 24);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i17,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i17);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i11);
	if ((MR_tag(MR_const_field(MR_mktag(2), r1, (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i11);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 1, mercury__vn_util__simplify_vnrval_binop_6_0, "vn_type:vnrval/0");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__vn_util__simplify_vnrval_binop_6_0, "llds:rval_const/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = ((Integer) MR_stackvar(7) + (Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(2), r2, (Integer) 0), (Integer) 0));
	MR_field(MR_mktag(2), r1, (Integer) 0) = r3;
	r2 = MR_stackvar(4);
	call_localret(STATIC(mercury__vn_util__vnrval_to_vn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i20,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i20);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 4, mercury__vn_util__simplify_vnrval_binop_6_0, "vn_type:vnrval/0");
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r2, (Integer) 1) = (Integer) 0;
	MR_field(MR_mktag(3), r2, (Integer) 2) = MR_stackvar(6);
	MR_field(MR_mktag(3), r2, (Integer) 3) = r1;
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i11);
	r1 = MR_stackvar(1);
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i12);
	r2 = MR_stackvar(5);
	if ((MR_tag(r2) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i21);
	r3 = MR_const_field(MR_mktag(2), r2, (Integer) 0);
	if ((MR_tag(r3) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i21);
	if ((MR_tag(r1) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i21);
	if (((Integer) MR_const_field(MR_mktag(3), r1, (Integer) 0) != (Integer) 2))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i21);
	if (((Integer) MR_const_field(MR_mktag(3), r1, (Integer) 1) != (Integer) 0))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i21);
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 4, mercury__vn_util__simplify_vnrval_binop_6_0, "vn_type:vnrval/0");
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r2, (Integer) 1) = (Integer) 0;
	MR_field(MR_mktag(3), r2, (Integer) 2) = MR_stackvar(3);
	MR_field(MR_mktag(3), r2, (Integer) 3) = MR_stackvar(2);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i21);
	if ((MR_tag(MR_stackvar(5)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i27);
	if (((Integer) MR_const_field(MR_mktag(3), MR_stackvar(5), (Integer) 0) != (Integer) 2))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i27);
	r2 = MR_const_field(MR_mktag(3), MR_stackvar(5), (Integer) 1);
	if (((Integer) r2 != (Integer) 0))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i27);
	MR_stackvar(1) = r1;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(5);
	r1 = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 3);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 2);
	r2 = (Word) MR_string_const("vn_util__simplify_vnrval", 24);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i30,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
	}
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i30);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i26);
	if ((MR_tag(MR_const_field(MR_mktag(2), r1, (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i26);
	if ((MR_tag(MR_stackvar(1)) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i26);
	r2 = MR_const_field(MR_mktag(2), MR_stackvar(1), (Integer) 0);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i26);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 1, mercury__vn_util__simplify_vnrval_binop_6_0, "vn_type:vnrval/0");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__vn_util__simplify_vnrval_binop_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), r1, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = ((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(2), r3, (Integer) 0), (Integer) 0) + (Integer) MR_const_field(MR_mktag(1), r2, (Integer) 0));
	r2 = MR_stackvar(4);
	call_localret(STATIC(mercury__vn_util__vnrval_to_vn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i49,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
	}
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i26);
	r1 = MR_stackvar(1);
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i27);
	if ((MR_tag(MR_stackvar(5)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i37);
	if (((Integer) MR_const_field(MR_mktag(3), MR_stackvar(5), (Integer) 0) != (Integer) 2))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i37);
	r2 = MR_const_field(MR_mktag(3), MR_stackvar(5), (Integer) 1);
	if (((Integer) r2 != (Integer) 0))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i37);
	MR_stackvar(1) = r1;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(5);
	r1 = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 3);
	MR_stackvar(6) = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 2);
	r2 = (Word) MR_string_const("vn_util__simplify_vnrval", 24);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i40,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
	}
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i40);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i36);
	{
	Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	if ((MR_tag(MR_tempr1) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i36);
	MR_tempr2 = MR_stackvar(1);
	if ((MR_tag(MR_tempr2) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i36);
	if (((Integer) MR_const_field(MR_mktag(3), MR_tempr2, (Integer) 0) != (Integer) 2))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i36);
	if (((Integer) MR_const_field(MR_mktag(3), MR_tempr2, (Integer) 1) != (Integer) 0))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i36);
	r1 = MR_const_field(MR_mktag(3), MR_tempr2, (Integer) 3);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), MR_tempr2, (Integer) 2);
	MR_stackvar(7) = MR_const_field(MR_mktag(1), MR_tempr1, (Integer) 0);
	r2 = (Word) MR_string_const("vn_util__simplify_vnrval", 24);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i45,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
	}
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i45);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i36);
	r3 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	if ((MR_tag(r3) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i36);
	r2 = MR_stackvar(2);
	MR_stackvar(2) = ((Integer) MR_stackvar(7) + (Integer) MR_const_field(MR_mktag(1), r3, (Integer) 0));
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__vn_util__simplify_vnrval_binop_6_0, "vn_type:vnrval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Integer) 0;
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_stackvar(6);
	MR_field(MR_mktag(3), r1, (Integer) 3) = r2;
	r2 = MR_stackvar(4);
	call_localret(STATIC(mercury__vn_util__vnrval_to_vn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i48,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i48);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	r3 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 1, mercury__vn_util__simplify_vnrval_binop_6_0, "vn_type:vnrval/0");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__vn_util__simplify_vnrval_binop_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), r1, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = r3;
	call_localret(STATIC(mercury__vn_util__vnrval_to_vn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i49,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
	}
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i49);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 4, mercury__vn_util__simplify_vnrval_binop_6_0, "vn_type:vnrval/0");
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r2, (Integer) 1) = (Integer) 0;
	MR_field(MR_mktag(3), r2, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(3), r2, (Integer) 3) = r1;
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i36);
	r1 = MR_stackvar(1);
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i37);
	if ((MR_tag(MR_stackvar(5)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i51);
	if (((Integer) MR_const_field(MR_mktag(3), MR_stackvar(5), (Integer) 0) != (Integer) 2))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i51);
	r2 = MR_const_field(MR_mktag(3), MR_stackvar(5), (Integer) 1);
	if (((Integer) r2 != (Integer) 0))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i51);
	MR_stackvar(1) = r1;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(5);
	r1 = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 3);
	MR_stackvar(6) = r1;
	MR_stackvar(2) = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 2);
	r2 = (Word) MR_string_const("vn_util__simplify_vnrval", 24);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i54,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
	}
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i54);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i50);
	if ((MR_tag(MR_const_field(MR_mktag(2), r1, (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i50);
	if ((MR_tag(MR_stackvar(1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i50);
	if (((Integer) MR_const_field(MR_mktag(3), MR_stackvar(1), (Integer) 0) != (Integer) 2))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i50);
	r1 = MR_const_field(MR_mktag(3), MR_stackvar(1), (Integer) 1);
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i50);
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__vn_util__simplify_vnrval_binop_6_0, "vn_type:vnrval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Integer) 0;
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(3), r1, (Integer) 3) = MR_stackvar(3);
	r2 = MR_stackvar(4);
	call_localret(STATIC(mercury__vn_util__vnrval_to_vn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i59,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i59);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 4, mercury__vn_util__simplify_vnrval_binop_6_0, "vn_type:vnrval/0");
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r2, (Integer) 1) = (Integer) 0;
	MR_field(MR_mktag(3), r2, (Integer) 2) = r1;
	MR_field(MR_mktag(3), r2, (Integer) 3) = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i50);
	r1 = MR_stackvar(1);
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i51);
	if ((MR_tag(r1) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if ((MR_tag(MR_const_field(MR_mktag(2), r1, (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(2), r1, (Integer) 0), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i69);
	if ((MR_tag(r1) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i70);
	r2 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i70);
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 1, mercury__vn_util__simplify_vnrval_binop_6_0, "vn_type:vnrval/0");
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__vn_util__simplify_vnrval_binop_6_0, "llds:rval_const/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = ((Integer) 0 - (Integer) MR_const_field(MR_mktag(1), r2, (Integer) 0));
	MR_field(MR_mktag(2), r1, (Integer) 0) = r3;
	r2 = MR_stackvar(4);
	call_localret(STATIC(mercury__vn_util__vnrval_to_vn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i73,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i73);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__vn_util__simplify_vnrval_binop_6_0, "vn_type:vnrval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Integer) 0;
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(3), r1, (Integer) 3) = r3;
	call_localret(STATIC(mercury__vn_util__simplify_vnrval_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i340,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i70);
	if ((MR_tag(MR_stackvar(5)) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i76);
	r2 = MR_const_field(MR_mktag(2), MR_stackvar(5), (Integer) 0);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i76);
	if (((Integer) MR_const_field(MR_mktag(1), r2, (Integer) 0) == (Integer) 0))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i76);
	r1 = (Word) MR_mkword(MR_mktag(2), (Word *) &mercury_data_vn_util__common_11);
	r2 = MR_stackvar(4);
	call_localret(STATIC(mercury__vn_util__vnrval_to_vn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i81,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i81);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__vn_util__simplify_vnrval_binop_6_0, "vn_type:vnrval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Integer) 1;
	MR_field(MR_mktag(3), r1, (Integer) 2) = r3;
	MR_field(MR_mktag(3), r1, (Integer) 3) = MR_stackvar(3);
	call_localret(STATIC(mercury__vn_util__vnrval_to_vn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i82,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i82);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__vn_util__simplify_vnrval_binop_6_0, "vn_type:vnrval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Integer) 0;
	MR_field(MR_mktag(3), r1, (Integer) 2) = r3;
	MR_field(MR_mktag(3), r1, (Integer) 3) = MR_stackvar(2);
	call_localret(STATIC(mercury__vn_util__simplify_vnrval_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i340,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i76);
	if ((MR_stackvar(2) != MR_stackvar(3)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i84);
	r2 = (Word) MR_mkword(MR_mktag(2), (Word *) &mercury_data_vn_util__common_11);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i84);
	if ((MR_tag(r1) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if ((MR_tag(MR_const_field(MR_mktag(2), r1, (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(2), r1, (Integer) 0), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i91);
	if ((MR_tag(MR_stackvar(5)) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i92);
	r2 = MR_const_field(MR_mktag(2), MR_stackvar(5), (Integer) 0);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i92);
	if ((MR_tag(r1) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i92);
	r3 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	if ((MR_tag(r3) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i92);
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 1, mercury__vn_util__simplify_vnrval_binop_6_0, "vn_type:vnrval/0");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__vn_util__simplify_vnrval_binop_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = ((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 0) * (Integer) MR_const_field(MR_mktag(1), r3, (Integer) 0));
	r1 = TRUE;
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
	}
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i92);
	if ((MR_tag(r1) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i97);
	r2 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i97);
	if (((Integer) MR_const_field(MR_mktag(1), r2, (Integer) 0) != (Integer) 1))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i97);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i97);
	if ((MR_tag(MR_stackvar(5)) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if ((MR_tag(MR_const_field(MR_mktag(2), MR_stackvar(5), (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(2), MR_stackvar(5), (Integer) 0), (Integer) 0) != (Integer) 1))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	r2 = r1;
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i106);
	if ((MR_tag(MR_stackvar(5)) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i108);
	r2 = MR_const_field(MR_mktag(2), MR_stackvar(5), (Integer) 0);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i108);
	if ((MR_tag(r1) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i108);
	r3 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	if ((MR_tag(r3) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i108);
	r4 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	r5 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	if (((Integer) r4 == (Integer) 0))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i108);
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 1, mercury__vn_util__simplify_vnrval_binop_6_0, "vn_type:vnrval/0");
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__vn_util__simplify_vnrval_binop_6_0, "llds:rval_const/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = ((Integer) r5 / (Integer) r4);
	MR_field(MR_mktag(2), r2, (Integer) 0) = r1;
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i108);
	if ((MR_tag(r1) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if ((MR_tag(MR_const_field(MR_mktag(2), r1, (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(2), r1, (Integer) 0), (Integer) 0) != (Integer) 1))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i120);
	if ((MR_tag(MR_stackvar(5)) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i121);
	r2 = MR_const_field(MR_mktag(2), MR_stackvar(5), (Integer) 0);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i121);
	if ((MR_tag(r1) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i121);
	r3 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	if ((MR_tag(r3) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i121);
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 1, mercury__vn_util__simplify_vnrval_binop_6_0, "vn_type:vnrval/0");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__vn_util__simplify_vnrval_binop_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = ((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 0) << (Integer) MR_const_field(MR_mktag(1), r3, (Integer) 0));
	r1 = TRUE;
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
	}
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i121);
	if ((MR_tag(r1) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if ((MR_tag(MR_const_field(MR_mktag(2), r1, (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(2), r1, (Integer) 0), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i130);
	if ((MR_tag(MR_stackvar(5)) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i131);
	r2 = MR_const_field(MR_mktag(2), MR_stackvar(5), (Integer) 0);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i131);
	if ((MR_tag(r1) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i131);
	r3 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	if ((MR_tag(r3) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i131);
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 1, mercury__vn_util__simplify_vnrval_binop_6_0, "vn_type:vnrval/0");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__vn_util__simplify_vnrval_binop_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = ((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 0) >> (Integer) MR_const_field(MR_mktag(1), r3, (Integer) 0));
	r1 = TRUE;
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
	}
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i131);
	if ((MR_tag(r1) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if ((MR_tag(MR_const_field(MR_mktag(2), r1, (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(2), r1, (Integer) 0), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i140);
	if ((MR_tag(MR_stackvar(5)) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i141);
	r2 = MR_const_field(MR_mktag(2), MR_stackvar(5), (Integer) 0);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i141);
	if ((MR_tag(r1) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i141);
	r3 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	if ((MR_tag(r3) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i141);
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 1, mercury__vn_util__simplify_vnrval_binop_6_0, "vn_type:vnrval/0");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__vn_util__simplify_vnrval_binop_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = ((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 0) & (Integer) MR_const_field(MR_mktag(1), r3, (Integer) 0));
	r1 = TRUE;
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
	}
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i141);
	if ((MR_tag(r1) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i146);
	if ((MR_tag(MR_const_field(MR_mktag(2), r1, (Integer) 0)) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i146);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(2), r1, (Integer) 0), (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i146);
	r2 = (Word) MR_mkword(MR_mktag(2), (Word *) &mercury_data_vn_util__common_11);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i146);
	if ((MR_tag(MR_stackvar(5)) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i150);
	r1 = MR_const_field(MR_mktag(2), MR_stackvar(5), (Integer) 0);
	if ((MR_tag(r1) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i150);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i150);
	r2 = (Word) MR_mkword(MR_mktag(2), (Word *) &mercury_data_vn_util__common_11);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i150);
	if ((MR_stackvar(2) != MR_stackvar(3)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i157);
	if ((MR_tag(MR_stackvar(5)) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i158);
	r2 = MR_const_field(MR_mktag(2), MR_stackvar(5), (Integer) 0);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i158);
	if ((MR_tag(r1) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i158);
	r3 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	if ((MR_tag(r3) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i158);
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 1, mercury__vn_util__simplify_vnrval_binop_6_0, "vn_type:vnrval/0");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(1), (Integer) 1, mercury__vn_util__simplify_vnrval_binop_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(1), MR_tempr1, (Integer) 0) = ((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 0) | (Integer) MR_const_field(MR_mktag(1), r3, (Integer) 0));
	r1 = TRUE;
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
	}
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i158);
	if ((MR_tag(r1) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i163);
	r2 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i163);
	if (((Integer) MR_const_field(MR_mktag(1), r2, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i163);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i163);
	if ((MR_tag(MR_stackvar(5)) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i167);
	r2 = MR_const_field(MR_mktag(2), MR_stackvar(5), (Integer) 0);
	if ((MR_tag(r2) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i167);
	if (((Integer) MR_const_field(MR_mktag(1), r2, (Integer) 0) != (Integer) 0))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i167);
	r2 = r1;
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i167);
	if ((MR_stackvar(2) != MR_stackvar(3)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i175);
	if ((MR_tag(MR_stackvar(5)) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i176);
	r2 = MR_const_field(MR_mktag(2), MR_stackvar(5), (Integer) 0);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i176);
	r2 = r1;
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i176);
	if ((MR_tag(r1) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i179);
	r2 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i179);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i179);
	if ((MR_tag(MR_stackvar(5)) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i182);
	r2 = MR_const_field(MR_mktag(2), MR_stackvar(5), (Integer) 0);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i182);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i182);
	if ((MR_tag(r1) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	r2 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	r2 = r1;
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i190);
	if ((MR_tag(MR_stackvar(5)) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i191);
	r2 = MR_const_field(MR_mktag(2), MR_stackvar(5), (Integer) 0);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i191);
	r2 = r1;
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i191);
	if ((MR_tag(r1) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i194);
	r2 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i194);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i194);
	if ((MR_tag(MR_stackvar(5)) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i197);
	r2 = MR_const_field(MR_mktag(2), MR_stackvar(5), (Integer) 0);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i197);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i197);
	if ((MR_tag(r1) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	r2 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	r2 = r1;
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i205);
	if ((MR_stackvar(2) != MR_stackvar(3)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i206);
	r2 = (Word) MR_mkword(MR_mktag(2), (Word *) &mercury_data_vn_util__common_0);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i206);
	if ((MR_tag(MR_stackvar(5)) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i207);
	if ((MR_tag(r1) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i207);
	r2 = (Word) MR_mkword(MR_mktag(2), (Word *) &mercury_data_vn_util__common_1);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i207);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(5);
	if ((MR_tag(MR_tempr1) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if (((Integer) MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 0) != (Integer) 1))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if (((Integer) MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 1) != (Integer) 1))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if ((MR_tag(r1) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if (((Integer) MR_const_field(MR_mktag(3), r1, (Integer) 0) != (Integer) 1))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if (((Integer) MR_const_field(MR_mktag(3), r1, (Integer) 1) != (Integer) 0))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 2);
	r2 = (Word) MR_string_const("vn_util__simplify_vnrval_binop", 30);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i214,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
	}
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i214);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if ((MR_stackvar(1) != MR_const_field(MR_mktag(1), r1, (Integer) 0)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	r2 = (Word) MR_mkword(MR_mktag(2), (Word *) &mercury_data_vn_util__common_0);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i218);
	if ((MR_stackvar(2) != MR_stackvar(3)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i219);
	r2 = (Word) MR_mkword(MR_mktag(2), (Word *) &mercury_data_vn_util__common_1);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i219);
	if ((MR_tag(MR_stackvar(5)) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i220);
	if ((MR_tag(r1) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i220);
	r2 = (Word) MR_mkword(MR_mktag(2), (Word *) &mercury_data_vn_util__common_0);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i220);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(5);
	if ((MR_tag(MR_tempr1) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if (((Integer) MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 0) != (Integer) 1))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if (((Integer) MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 1) != (Integer) 1))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if ((MR_tag(r1) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if (((Integer) MR_const_field(MR_mktag(3), r1, (Integer) 0) != (Integer) 1))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if (((Integer) MR_const_field(MR_mktag(3), r1, (Integer) 1) != (Integer) 0))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 2);
	r2 = (Word) MR_string_const("vn_util__simplify_vnrval_binop", 30);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i227,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
	}
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i227);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if ((MR_stackvar(1) != MR_const_field(MR_mktag(1), r1, (Integer) 0)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	r2 = (Word) MR_mkword(MR_mktag(2), (Word *) &mercury_data_vn_util__common_1);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i232);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(3);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(STATIC(mercury__vn_util__const_if_equal_vns_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i233,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i233);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i235);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(3);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1));
	call_localret(STATIC(mercury__vn_util__const_if_equal_vns_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i236,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i236);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i238);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(3);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1));
	call_localret(STATIC(mercury__vn_util__const_if_equal_vns_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i239,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i239);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i241);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(3);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1));
	call_localret(STATIC(mercury__vn_util__const_if_equal_vns_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i242,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i242);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i244);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(3);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(STATIC(mercury__vn_util__const_if_equal_vns_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i245,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i245);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i247);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(3);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(STATIC(mercury__vn_util__const_if_equal_vns_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i248,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i248);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i250);
	r4 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(3);
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1));
	call_localret(STATIC(mercury__vn_util__simplify_int_compare_op__ho8__ua0_7_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i251,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i251);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i253);
	r4 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(3);
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1));
	call_localret(STATIC(mercury__vn_util__simplify_int_compare_op__ho7__ua0_7_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i254,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i254);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i256);
	r4 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(3);
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(STATIC(mercury__vn_util__simplify_int_compare_op__ho6__ua0_7_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i257,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i257);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i259);
	r4 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(3);
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(STATIC(mercury__vn_util__simplify_int_compare_op__ho5__ua0_7_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i260,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i260);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i262);
	if ((MR_tag(MR_stackvar(5)) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i263);
	r2 = MR_const_field(MR_mktag(2), MR_stackvar(5), (Integer) 0);
	if ((MR_tag(r2) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i263);
	if ((MR_tag(r1) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i263);
	r3 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	if ((MR_tag(r3) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i263);
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 1, mercury__vn_util__simplify_vnrval_binop_6_0, "vn_type:vnrval/0");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__vn_util__simplify_vnrval_binop_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = float_to_word((word_to_float(MR_const_field(MR_mktag(2), r1, (Integer) 0)) + word_to_float(MR_const_field(MR_mktag(2), r3, (Integer) 0))));
	r1 = TRUE;
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
	}
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i263);
	if ((MR_tag(MR_stackvar(5)) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i269);
	r2 = MR_const_field(MR_mktag(2), MR_stackvar(5), (Integer) 0);
	if ((MR_tag(r2) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i269);
	if ((MR_tag(r1) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i269);
	if (((Integer) MR_const_field(MR_mktag(3), r1, (Integer) 0) != (Integer) 2))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i269);
	r3 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	if (((Integer) r3 != (Integer) 25))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i269);
	MR_stackvar(1) = r1;
	MR_stackvar(6) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(7) = MR_const_field(MR_mktag(2), r2, (Integer) 0);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	r2 = (Word) MR_string_const("vn_util__simplify_vnrval", 24);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i274,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i274);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i268);
	if ((MR_tag(MR_const_field(MR_mktag(2), r1, (Integer) 0)) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i268);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 1, mercury__vn_util__simplify_vnrval_binop_6_0, "vn_type:vnrval/0");
	tag_incr_hp_msg(r3, MR_mktag(2), (Integer) 1, mercury__vn_util__simplify_vnrval_binop_6_0, "llds:rval_const/0");
	MR_field(MR_mktag(2), r3, (Integer) 0) = float_to_word((word_to_float(MR_stackvar(7)) + word_to_float(MR_const_field(MR_mktag(2), MR_const_field(MR_mktag(2), r2, (Integer) 0), (Integer) 0))));
	MR_field(MR_mktag(2), r1, (Integer) 0) = r3;
	r2 = MR_stackvar(4);
	call_localret(STATIC(mercury__vn_util__vnrval_to_vn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i277,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i277);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 4, mercury__vn_util__simplify_vnrval_binop_6_0, "vn_type:vnrval/0");
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r2, (Integer) 1) = (Integer) 25;
	MR_field(MR_mktag(3), r2, (Integer) 2) = MR_stackvar(6);
	MR_field(MR_mktag(3), r2, (Integer) 3) = r1;
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i268);
	r1 = MR_stackvar(1);
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i269);
	r2 = MR_stackvar(5);
	if ((MR_tag(r2) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i278);
	r3 = MR_const_field(MR_mktag(2), r2, (Integer) 0);
	if ((MR_tag(r3) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i278);
	if ((MR_tag(r1) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i278);
	if (((Integer) MR_const_field(MR_mktag(3), r1, (Integer) 0) != (Integer) 2))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i278);
	if (((Integer) MR_const_field(MR_mktag(3), r1, (Integer) 1) != (Integer) 25))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i278);
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 4, mercury__vn_util__simplify_vnrval_binop_6_0, "vn_type:vnrval/0");
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r2, (Integer) 1) = (Integer) 25;
	MR_field(MR_mktag(3), r2, (Integer) 2) = MR_stackvar(3);
	MR_field(MR_mktag(3), r2, (Integer) 3) = MR_stackvar(2);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i278);
	if ((MR_tag(MR_stackvar(5)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i284);
	if (((Integer) MR_const_field(MR_mktag(3), MR_stackvar(5), (Integer) 0) != (Integer) 2))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i284);
	r2 = MR_const_field(MR_mktag(3), MR_stackvar(5), (Integer) 1);
	if (((Integer) r2 != (Integer) 25))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i284);
	MR_stackvar(1) = r1;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(5);
	r1 = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 3);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 2);
	r2 = (Word) MR_string_const("vn_util__simplify_vnrval", 24);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i287,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
	}
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i287);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i283);
	if ((MR_tag(MR_const_field(MR_mktag(2), r1, (Integer) 0)) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i283);
	if ((MR_tag(MR_stackvar(1)) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i283);
	r2 = MR_const_field(MR_mktag(2), MR_stackvar(1), (Integer) 0);
	if ((MR_tag(r2) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i283);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 1, mercury__vn_util__simplify_vnrval_binop_6_0, "vn_type:vnrval/0");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__vn_util__simplify_vnrval_binop_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), r1, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = float_to_word((word_to_float(MR_const_field(MR_mktag(2), MR_const_field(MR_mktag(2), r3, (Integer) 0), (Integer) 0)) + word_to_float(MR_const_field(MR_mktag(2), r2, (Integer) 0))));
	r2 = MR_stackvar(4);
	call_localret(STATIC(mercury__vn_util__vnrval_to_vn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i306,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
	}
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i283);
	r1 = MR_stackvar(1);
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i284);
	if ((MR_tag(MR_stackvar(5)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i294);
	if (((Integer) MR_const_field(MR_mktag(3), MR_stackvar(5), (Integer) 0) != (Integer) 2))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i294);
	r2 = MR_const_field(MR_mktag(3), MR_stackvar(5), (Integer) 1);
	if (((Integer) r2 != (Integer) 25))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i294);
	MR_stackvar(1) = r1;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(5);
	r1 = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 3);
	MR_stackvar(6) = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 2);
	r2 = (Word) MR_string_const("vn_util__simplify_vnrval", 24);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i297,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
	}
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i297);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i293);
	{
	Word MR_tempr1, MR_tempr2;
	MR_tempr1 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	if ((MR_tag(MR_tempr1) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i293);
	MR_tempr2 = MR_stackvar(1);
	if ((MR_tag(MR_tempr2) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i293);
	if (((Integer) MR_const_field(MR_mktag(3), MR_tempr2, (Integer) 0) != (Integer) 2))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i293);
	if (((Integer) MR_const_field(MR_mktag(3), MR_tempr2, (Integer) 1) != (Integer) 25))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i293);
	r1 = MR_const_field(MR_mktag(3), MR_tempr2, (Integer) 3);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), MR_tempr2, (Integer) 2);
	MR_stackvar(7) = MR_const_field(MR_mktag(2), MR_tempr1, (Integer) 0);
	r2 = (Word) MR_string_const("vn_util__simplify_vnrval", 24);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i302,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
	}
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i302);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i293);
	r3 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	if ((MR_tag(r3) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i293);
	r2 = MR_stackvar(2);
	MR_stackvar(2) = float_to_word((word_to_float(MR_stackvar(7)) + word_to_float(MR_const_field(MR_mktag(2), r3, (Integer) 0))));
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__vn_util__simplify_vnrval_binop_6_0, "vn_type:vnrval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Integer) 25;
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_stackvar(6);
	MR_field(MR_mktag(3), r1, (Integer) 3) = r2;
	r2 = MR_stackvar(4);
	call_localret(STATIC(mercury__vn_util__vnrval_to_vn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i305,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i305);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	r3 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 1, mercury__vn_util__simplify_vnrval_binop_6_0, "vn_type:vnrval/0");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__vn_util__simplify_vnrval_binop_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), r1, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = r3;
	call_localret(STATIC(mercury__vn_util__vnrval_to_vn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i306,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
	}
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i306);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 4, mercury__vn_util__simplify_vnrval_binop_6_0, "vn_type:vnrval/0");
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r2, (Integer) 1) = (Integer) 25;
	MR_field(MR_mktag(3), r2, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(3), r2, (Integer) 3) = r1;
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i293);
	r1 = MR_stackvar(1);
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i294);
	if ((MR_tag(MR_stackvar(5)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i308);
	if (((Integer) MR_const_field(MR_mktag(3), MR_stackvar(5), (Integer) 0) != (Integer) 2))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i308);
	r2 = MR_const_field(MR_mktag(3), MR_stackvar(5), (Integer) 1);
	if (((Integer) r2 != (Integer) 25))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i308);
	MR_stackvar(1) = r1;
	{
	Word MR_tempr1;
	MR_tempr1 = MR_stackvar(5);
	r1 = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 3);
	MR_stackvar(6) = r1;
	MR_stackvar(2) = MR_const_field(MR_mktag(3), MR_tempr1, (Integer) 2);
	r2 = (Word) MR_string_const("vn_util__simplify_vnrval", 24);
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i311,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
	}
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i311);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	if ((MR_tag(r1) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i307);
	if ((MR_tag(MR_const_field(MR_mktag(2), r1, (Integer) 0)) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i307);
	if ((MR_tag(MR_stackvar(1)) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i307);
	if (((Integer) MR_const_field(MR_mktag(3), MR_stackvar(1), (Integer) 0) != (Integer) 2))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i307);
	r1 = MR_const_field(MR_mktag(3), MR_stackvar(1), (Integer) 1);
	if (((Integer) r1 != (Integer) 25))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i307);
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__vn_util__simplify_vnrval_binop_6_0, "vn_type:vnrval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Integer) 25;
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(3), r1, (Integer) 3) = MR_stackvar(3);
	r2 = MR_stackvar(4);
	call_localret(STATIC(mercury__vn_util__vnrval_to_vn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i316,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i316);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 4, mercury__vn_util__simplify_vnrval_binop_6_0, "vn_type:vnrval/0");
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r2, (Integer) 1) = (Integer) 25;
	MR_field(MR_mktag(3), r2, (Integer) 2) = r1;
	MR_field(MR_mktag(3), r2, (Integer) 3) = MR_stackvar(6);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i307);
	r1 = MR_stackvar(1);
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i308);
	if ((MR_tag(r1) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if ((MR_tag(MR_const_field(MR_mktag(2), r1, (Integer) 0)) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if ((word_to_float(MR_const_field(MR_mktag(2), MR_const_field(MR_mktag(2), r1, (Integer) 0), (Integer) 0)) != (Float) 0.00000000000000))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i326);
	if ((MR_tag(r1) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i327);
	r2 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	if ((MR_tag(r2) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i327);
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 1, mercury__vn_util__simplify_vnrval_binop_6_0, "vn_type:vnrval/0");
	tag_incr_hp_msg(r3, MR_mktag(2), (Integer) 1, mercury__vn_util__simplify_vnrval_binop_6_0, "llds:rval_const/0");
	MR_field(MR_mktag(2), r3, (Integer) 0) = float_to_word(((Float) 0.00000000000000 - word_to_float(MR_const_field(MR_mktag(2), r2, (Integer) 0))));
	MR_field(MR_mktag(2), r1, (Integer) 0) = r3;
	r2 = MR_stackvar(4);
	call_localret(STATIC(mercury__vn_util__vnrval_to_vn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i330,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i330);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__vn_util__simplify_vnrval_binop_6_0, "vn_type:vnrval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Integer) 25;
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_stackvar(2);
	MR_field(MR_mktag(3), r1, (Integer) 3) = r3;
	call_localret(STATIC(mercury__vn_util__simplify_vnrval_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i340,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i327);
	if ((MR_tag(MR_stackvar(5)) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i333);
	r2 = MR_const_field(MR_mktag(2), MR_stackvar(5), (Integer) 0);
	if ((MR_tag(r2) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i333);
	if ((word_to_float(MR_const_field(MR_mktag(2), r2, (Integer) 0)) == (Float) 0.00000000000000))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i333);
	r1 = (Word) MR_mkword(MR_mktag(2), (Word *) &mercury_data_vn_util__common_13);
	r2 = MR_stackvar(4);
	call_localret(STATIC(mercury__vn_util__vnrval_to_vn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i338,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i338);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__vn_util__simplify_vnrval_binop_6_0, "vn_type:vnrval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Integer) 26;
	MR_field(MR_mktag(3), r1, (Integer) 2) = r3;
	MR_field(MR_mktag(3), r1, (Integer) 3) = MR_stackvar(3);
	call_localret(STATIC(mercury__vn_util__vnrval_to_vn_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i339,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i339);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__vn_util__simplify_vnrval_binop_6_0, "vn_type:vnrval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r1, (Integer) 1) = (Integer) 25;
	MR_field(MR_mktag(3), r1, (Integer) 2) = r3;
	MR_field(MR_mktag(3), r1, (Integer) 3) = MR_stackvar(2);
	call_localret(STATIC(mercury__vn_util__simplify_vnrval_4_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i340,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i340);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	r3 = r2;
	r2 = r1;
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i333);
	if ((MR_stackvar(2) != MR_stackvar(3)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i341);
	r2 = (Word) MR_mkword(MR_mktag(2), (Word *) &mercury_data_vn_util__common_11);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i341);
	if ((MR_tag(r1) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if ((MR_tag(MR_const_field(MR_mktag(2), r1, (Integer) 0)) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if ((word_to_float(MR_const_field(MR_mktag(2), MR_const_field(MR_mktag(2), r1, (Integer) 0), (Integer) 0)) != (Float) 0.00000000000000))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i348);
	if ((MR_tag(MR_stackvar(5)) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i349);
	r2 = MR_const_field(MR_mktag(2), MR_stackvar(5), (Integer) 0);
	if ((MR_tag(r2) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i349);
	if ((MR_tag(r1) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i349);
	r3 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	if ((MR_tag(r3) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i349);
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 1, mercury__vn_util__simplify_vnrval_binop_6_0, "vn_type:vnrval/0");
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(2), (Integer) 1, mercury__vn_util__simplify_vnrval_binop_6_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_tempr1;
	MR_field(MR_mktag(2), MR_tempr1, (Integer) 0) = float_to_word((word_to_float(MR_const_field(MR_mktag(2), r1, (Integer) 0)) * word_to_float(MR_const_field(MR_mktag(2), r3, (Integer) 0))));
	r1 = TRUE;
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	proceed();
	}
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i349);
	if ((MR_tag(r1) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i354);
	r2 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	if ((MR_tag(r2) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i354);
	if ((word_to_float(MR_const_field(MR_mktag(2), r2, (Integer) 0)) != (Float) 1.00000000000000))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i354);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i354);
	if ((MR_tag(MR_stackvar(5)) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if ((MR_tag(MR_const_field(MR_mktag(2), MR_stackvar(5), (Integer) 0)) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if ((word_to_float(MR_const_field(MR_mktag(2), MR_const_field(MR_mktag(2), MR_stackvar(5), (Integer) 0), (Integer) 0)) != (Float) 1.00000000000000))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	r2 = r1;
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i363);
	if ((MR_tag(MR_stackvar(5)) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i365);
	r2 = MR_const_field(MR_mktag(2), MR_stackvar(5), (Integer) 0);
	if ((MR_tag(r2) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i365);
	if ((MR_tag(r1) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i365);
	r3 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	if ((MR_tag(r3) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i365);
	r4 = MR_const_field(MR_mktag(2), r3, (Integer) 0);
	r5 = MR_const_field(MR_mktag(2), r2, (Integer) 0);
	if ((word_to_float(r4) == (Float) 0.00000000000000))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i365);
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 1, mercury__vn_util__simplify_vnrval_binop_6_0, "vn_type:vnrval/0");
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 1, mercury__vn_util__simplify_vnrval_binop_6_0, "llds:rval_const/0");
	MR_field(MR_mktag(2), r1, (Integer) 0) = float_to_word((word_to_float(r5) / word_to_float(r4)));
	MR_field(MR_mktag(2), r2, (Integer) 0) = r1;
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i365);
	if ((MR_tag(r1) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if ((MR_tag(MR_const_field(MR_mktag(2), r1, (Integer) 0)) != MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	if ((word_to_float(MR_const_field(MR_mktag(2), MR_const_field(MR_mktag(2), r1, (Integer) 0), (Integer) 0)) != (Float) 1.00000000000000))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i376);
	r4 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(3);
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(STATIC(mercury__vn_util__simplify_float_compare_op__ho1__ua0_7_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i377,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i377);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i379);
	r4 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(3);
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1));
	call_localret(STATIC(mercury__vn_util__simplify_float_compare_op__ho4__ua0_7_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i380,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i380);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i382);
	r4 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(3);
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1));
	call_localret(STATIC(mercury__vn_util__simplify_float_compare_op__ho3__ua0_7_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i383,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i383);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i385);
	r4 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(3);
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1));
	call_localret(STATIC(mercury__vn_util__simplify_float_compare_op__ho2__ua0_7_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i386,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i386);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i388);
	r4 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(3);
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(STATIC(mercury__vn_util__simplify_float_compare_op__ho3__ua0_7_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i389,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i389);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i391);
	r4 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(3);
	r5 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	call_localret(STATIC(mercury__vn_util__simplify_float_compare_op__ho2__ua0_7_0),
		mercury__vn_util__simplify_vnrval_binop_6_0_i392,
		STATIC(mercury__vn_util__simplify_vnrval_binop_6_0));
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i392);
	update_prof_current_proc(LABEL(mercury__vn_util__simplify_vnrval_binop_6_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	r3 = MR_stackvar(4);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__simplify_vnrval_binop_6_0_i1);
	MR_succip = (Code *) MR_stackvar(8);
	MR_decr_sp_pop_msg(8);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(vn_util_module30)
	init_entry(mercury__vn_util__const_if_equal_vns_4_0);
	init_label(mercury__vn_util__const_if_equal_vns_4_0_i1);
BEGIN_CODE

/* code for predicate 'const_if_equal_vns'/4 in mode 0 */
Define_static(mercury__vn_util__const_if_equal_vns_4_0);
	if ((r1 != r2))
		GOTO_LABEL(mercury__vn_util__const_if_equal_vns_4_0_i1);
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 1, mercury__vn_util__const_if_equal_vns_4_0, "vn_type:vnrval/0");
	MR_field(MR_mktag(2), r2, (Integer) 0) = r3;
	r1 = TRUE;
	proceed();
Define_label(mercury__vn_util__const_if_equal_vns_4_0_i1);
	r1 = FALSE;
	proceed();
END_MODULE


BEGIN_MODULE(vn_util_module31)
	init_entry(mercury__vn_util__find_lvals_in_mem_ref_2_0);
	init_label(mercury__vn_util__find_lvals_in_mem_ref_2_0_i1001);
	init_label(mercury__vn_util__find_lvals_in_mem_ref_2_0_i5);
BEGIN_CODE

/* code for predicate 'find_lvals_in_mem_ref'/2 in mode 0 */
Define_static(mercury__vn_util__find_lvals_in_mem_ref_2_0);
	r2 = MR_tag(r1);
	if ((r2 == MR_mktag((Integer) 1)))
		GOTO_LABEL(mercury__vn_util__find_lvals_in_mem_ref_2_0_i1001);
	if ((r2 == MR_mktag((Integer) 2)))
		GOTO_LABEL(mercury__vn_util__find_lvals_in_mem_ref_2_0_i5);
Define_label(mercury__vn_util__find_lvals_in_mem_ref_2_0_i1001);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
Define_label(mercury__vn_util__find_lvals_in_mem_ref_2_0_i5);
	r1 = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	tailcall(STATIC(mercury__vn_util__find_lvals_in_rval_2_0),
		STATIC(mercury__vn_util__find_lvals_in_mem_ref_2_0));
END_MODULE


BEGIN_MODULE(vn_util_module32)
	init_entry(mercury__vn_util__choose_cheapest_loc_2_4_0);
	init_label(mercury__vn_util__choose_cheapest_loc_2_4_0_i1005);
	init_label(mercury__vn_util__choose_cheapest_loc_2_4_0_i4);
	init_label(mercury__vn_util__choose_cheapest_loc_2_4_0_i3);
	init_label(mercury__vn_util__choose_cheapest_loc_2_4_0_i8);
	init_label(mercury__vn_util__choose_cheapest_loc_2_4_0_i9);
	init_label(mercury__vn_util__choose_cheapest_loc_2_4_0_i11);
	init_label(mercury__vn_util__choose_cheapest_loc_2_4_0_i1);
BEGIN_CODE

/* code for predicate 'choose_cheapest_loc_2'/4 in mode 0 */
Define_static(mercury__vn_util__choose_cheapest_loc_2_4_0);
	MR_incr_sp_push_msg(5, "vn_util:choose_cheapest_loc_2/4");
	MR_stackvar(5) = (Word) MR_succip;
Define_label(mercury__vn_util__choose_cheapest_loc_2_4_0_i1005);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_util__choose_cheapest_loc_2_4_0_i3);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_util__choose_cheapest_loc_2_4_0_i4);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_util__choose_cheapest_loc_2_4_0_i4);
	if (((Integer) r3 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_util__choose_cheapest_loc_2_4_0_i1);
	r2 = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_util__choose_cheapest_loc_2_4_0_i3);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(3) = r1;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	call_localret(STATIC(mercury__vn_util__classify_loc_cost_2_0),
		mercury__vn_util__choose_cheapest_loc_2_4_0_i8,
		STATIC(mercury__vn_util__choose_cheapest_loc_2_4_0));
Define_label(mercury__vn_util__choose_cheapest_loc_2_4_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_util__choose_cheapest_loc_2_4_0));
	if (((Integer) r1 != (Integer) 0))
		GOTO_LABEL(mercury__vn_util__choose_cheapest_loc_2_4_0_i9);
	r2 = MR_stackvar(3);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
Define_label(mercury__vn_util__choose_cheapest_loc_2_4_0_i9);
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__vn_util__choose_cheapest_loc_2_4_0_i11);
	r1 = MR_stackvar(4);
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__vn_util__choose_cheapest_loc_2_4_0, "std_util:maybe/1");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(3);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(5);
	GOTO_LABEL(mercury__vn_util__choose_cheapest_loc_2_4_0_i1005);
Define_label(mercury__vn_util__choose_cheapest_loc_2_4_0_i11);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 1, mercury__vn_util__choose_cheapest_loc_2_4_0, "std_util:maybe/1");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(5);
	GOTO_LABEL(mercury__vn_util__choose_cheapest_loc_2_4_0_i1005);
Define_label(mercury__vn_util__choose_cheapest_loc_2_4_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(5);
	MR_decr_sp_pop_msg(5);
	proceed();
END_MODULE

Declare_entry(mercury__set__to_sorted_list_2_0);

BEGIN_MODULE(vn_util_module33)
	init_entry(mercury__vn_util__build_uses_4_0);
	init_label(mercury__vn_util__build_uses_4_0_i2);
	init_label(mercury__vn_util__build_uses_4_0_i3);
BEGIN_CODE

/* code for predicate 'build_uses'/4 in mode 0 */
Define_entry(mercury__vn_util__build_uses_4_0);
	MR_incr_sp_push_msg(2, "vn_util:build_uses/4");
	MR_stackvar(2) = (Word) MR_succip;
	MR_stackvar(1) = r1;
	r1 = (Integer) 0;
	call_localret(STATIC(mercury__vn_util__build_uses_from_ctrl_4_0),
		mercury__vn_util__build_uses_4_0_i2,
		ENTRY(mercury__vn_util__build_uses_4_0));
Define_label(mercury__vn_util__build_uses_4_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_util__build_uses_4_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0;
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__vn_util__build_uses_4_0_i3,
		ENTRY(mercury__vn_util__build_uses_4_0));
Define_label(mercury__vn_util__build_uses_4_0_i3);
	update_prof_current_proc(LABEL(mercury__vn_util__build_uses_4_0));
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(2);
	MR_decr_sp_pop_msg(2);
	tailcall(STATIC(mercury__vn_util__build_uses_from_livevals_3_0),
		ENTRY(mercury__vn_util__build_uses_4_0));
END_MODULE

extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_int_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_vn_type__type_ctor_info_vn_instr_0;
Declare_entry(mercury__map__search_3_1);

BEGIN_MODULE(vn_util_module34)
	init_entry(mercury__vn_util__build_uses_from_ctrl_4_0);
	init_label(mercury__vn_util__build_uses_from_ctrl_4_0_i1001);
	init_label(mercury__vn_util__build_uses_from_ctrl_4_0_i3);
	init_label(mercury__vn_util__build_uses_from_ctrl_4_0_i10);
	init_label(mercury__vn_util__build_uses_from_ctrl_4_0_i14);
	init_label(mercury__vn_util__build_uses_from_ctrl_4_0_i16);
	init_label(mercury__vn_util__build_uses_from_ctrl_4_0_i18);
	init_label(mercury__vn_util__build_uses_from_ctrl_4_0_i20);
	init_label(mercury__vn_util__build_uses_from_ctrl_4_0_i24);
	init_label(mercury__vn_util__build_uses_from_ctrl_4_0_i26);
	init_label(mercury__vn_util__build_uses_from_ctrl_4_0_i28);
	init_label(mercury__vn_util__build_uses_from_ctrl_4_0_i29);
	init_label(mercury__vn_util__build_uses_from_ctrl_4_0_i31);
	init_label(mercury__vn_util__build_uses_from_ctrl_4_0_i2);
BEGIN_CODE

/* code for predicate 'build_uses_from_ctrl'/4 in mode 0 */
Define_static(mercury__vn_util__build_uses_from_ctrl_4_0);
	MR_incr_sp_push_msg(4, "vn_util:build_uses_from_ctrl/4");
	MR_stackvar(4) = (Word) MR_succip;
Define_label(mercury__vn_util__build_uses_from_ctrl_4_0_i1001);
	MR_stackvar(3) = r3;
	r3 = r2;
	r4 = r1;
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Word) (Word *) &mercury_data___type_ctor_info_int_0;
	r2 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vn_instr_0;
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__vn_util__build_uses_from_ctrl_4_0_i3,
		STATIC(mercury__vn_util__build_uses_from_ctrl_4_0));
Define_label(mercury__vn_util__build_uses_from_ctrl_4_0_i3);
	update_prof_current_proc(LABEL(mercury__vn_util__build_uses_from_ctrl_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_util__build_uses_from_ctrl_4_0_i2);
	COMPUTED_GOTO((Unsigned) MR_tag(r2),
		LABEL(mercury__vn_util__build_uses_from_ctrl_4_0_i31) AND
		LABEL(mercury__vn_util__build_uses_from_ctrl_4_0_i31) AND
		LABEL(mercury__vn_util__build_uses_from_ctrl_4_0_i31) AND
		LABEL(mercury__vn_util__build_uses_from_ctrl_4_0_i10));
Define_label(mercury__vn_util__build_uses_from_ctrl_4_0_i10);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r2, (Integer) 0),
		LABEL(mercury__vn_util__build_uses_from_ctrl_4_0_i31) AND
		LABEL(mercury__vn_util__build_uses_from_ctrl_4_0_i31) AND
		LABEL(mercury__vn_util__build_uses_from_ctrl_4_0_i31) AND
		LABEL(mercury__vn_util__build_uses_from_ctrl_4_0_i14) AND
		LABEL(mercury__vn_util__build_uses_from_ctrl_4_0_i16) AND
		LABEL(mercury__vn_util__build_uses_from_ctrl_4_0_i18) AND
		LABEL(mercury__vn_util__build_uses_from_ctrl_4_0_i20) AND
		LABEL(mercury__vn_util__build_uses_from_ctrl_4_0_i26) AND
		LABEL(mercury__vn_util__build_uses_from_ctrl_4_0_i24) AND
		LABEL(mercury__vn_util__build_uses_from_ctrl_4_0_i26) AND
		LABEL(mercury__vn_util__build_uses_from_ctrl_4_0_i28) AND
		LABEL(mercury__vn_util__build_uses_from_ctrl_4_0_i31) AND
		LABEL(mercury__vn_util__build_uses_from_ctrl_4_0_i31));
Define_label(mercury__vn_util__build_uses_from_ctrl_4_0_i14);
	r1 = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 1, mercury__vn_util__build_uses_from_ctrl_4_0, "vn_type:vn_src/0");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(1);
	r3 = MR_stackvar(3);
	call_localret(STATIC(mercury__vn_util__record_use_4_0),
		mercury__vn_util__build_uses_from_ctrl_4_0_i29,
		STATIC(mercury__vn_util__build_uses_from_ctrl_4_0));
Define_label(mercury__vn_util__build_uses_from_ctrl_4_0_i16);
	r1 = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 1, mercury__vn_util__build_uses_from_ctrl_4_0, "vn_type:vn_src/0");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(1);
	r3 = MR_stackvar(3);
	call_localret(STATIC(mercury__vn_util__record_use_4_0),
		mercury__vn_util__build_uses_from_ctrl_4_0_i29,
		STATIC(mercury__vn_util__build_uses_from_ctrl_4_0));
Define_label(mercury__vn_util__build_uses_from_ctrl_4_0_i18);
	r2 = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	r1 = MR_stackvar(3);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 1, mercury__vn_util__build_uses_from_ctrl_4_0, "vn_type:vn_src/0");
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(1);
	call_localret(STATIC(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0),
		mercury__vn_util__build_uses_from_ctrl_4_0_i29,
		STATIC(mercury__vn_util__build_uses_from_ctrl_4_0));
Define_label(mercury__vn_util__build_uses_from_ctrl_4_0_i20);
	r1 = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 1, mercury__vn_util__build_uses_from_ctrl_4_0, "vn_type:vn_src/0");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(1);
	r3 = MR_stackvar(3);
	call_localret(STATIC(mercury__vn_util__record_use_4_0),
		mercury__vn_util__build_uses_from_ctrl_4_0_i29,
		STATIC(mercury__vn_util__build_uses_from_ctrl_4_0));
Define_label(mercury__vn_util__build_uses_from_ctrl_4_0_i24);
	r1 = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 1, mercury__vn_util__build_uses_from_ctrl_4_0, "vn_type:vn_src/0");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(1);
	r3 = MR_stackvar(3);
	call_localret(STATIC(mercury__vn_util__record_use_4_0),
		mercury__vn_util__build_uses_from_ctrl_4_0_i29,
		STATIC(mercury__vn_util__build_uses_from_ctrl_4_0));
Define_label(mercury__vn_util__build_uses_from_ctrl_4_0_i26);
	r2 = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	r1 = MR_stackvar(3);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 1, mercury__vn_util__build_uses_from_ctrl_4_0, "vn_type:vn_src/0");
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(1);
	call_localret(STATIC(mercury__vn_util__DeforestationIn__pred__build_uses_from_ctrl__1008__1_4_0),
		mercury__vn_util__build_uses_from_ctrl_4_0_i29,
		STATIC(mercury__vn_util__build_uses_from_ctrl_4_0));
Define_label(mercury__vn_util__build_uses_from_ctrl_4_0_i28);
	r1 = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 1, mercury__vn_util__build_uses_from_ctrl_4_0, "vn_type:vn_src/0");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(1);
	r3 = MR_stackvar(3);
	call_localret(STATIC(mercury__vn_util__record_use_4_0),
		mercury__vn_util__build_uses_from_ctrl_4_0_i29,
		STATIC(mercury__vn_util__build_uses_from_ctrl_4_0));
Define_label(mercury__vn_util__build_uses_from_ctrl_4_0_i29);
	update_prof_current_proc(LABEL(mercury__vn_util__build_uses_from_ctrl_4_0));
	r3 = r1;
	r1 = ((Integer) MR_stackvar(1) + (Integer) 1);
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	GOTO_LABEL(mercury__vn_util__build_uses_from_ctrl_4_0_i1001);
Define_label(mercury__vn_util__build_uses_from_ctrl_4_0_i31);
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	r1 = ((Integer) MR_stackvar(1) + (Integer) 1);
	MR_succip = (Code *) MR_stackvar(4);
	GOTO_LABEL(mercury__vn_util__build_uses_from_ctrl_4_0_i1001);
Define_label(mercury__vn_util__build_uses_from_ctrl_4_0_i2);
	r1 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE


BEGIN_MODULE(vn_util_module35)
	init_entry(mercury__vn_util__build_uses_from_livevals_3_0);
	init_label(mercury__vn_util__build_uses_from_livevals_3_0_i1002);
	init_label(mercury__vn_util__build_uses_from_livevals_3_0_i6);
	init_label(mercury__vn_util__build_uses_from_livevals_3_0_i4);
	init_label(mercury__vn_util__build_uses_from_livevals_3_0_i8);
	init_label(mercury__vn_util__build_uses_from_livevals_3_0_i10);
	init_label(mercury__vn_util__build_uses_from_livevals_3_0_i11);
	init_label(mercury__vn_util__build_uses_from_livevals_3_0_i3);
BEGIN_CODE

/* code for predicate 'build_uses_from_livevals'/3 in mode 0 */
Define_static(mercury__vn_util__build_uses_from_livevals_3_0);
	MR_incr_sp_push_msg(4, "vn_util:build_uses_from_livevals/3");
	MR_stackvar(4) = (Word) MR_succip;
Define_label(mercury__vn_util__build_uses_from_livevals_3_0_i1002);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_util__build_uses_from_livevals_3_0_i3);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(2) = r1;
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__vn_table__search_desired_value_3_0),
		mercury__vn_util__build_uses_from_livevals_3_0_i6,
		STATIC(mercury__vn_util__build_uses_from_livevals_3_0));
Define_label(mercury__vn_util__build_uses_from_livevals_3_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_util__build_uses_from_livevals_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_util__build_uses_from_livevals_3_0_i4);
	r1 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__vn_util__build_uses_from_livevals_3_0, "origin_lost_in_value_number");
	r3 = MR_stackvar(1);
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(2);
	call_localret(STATIC(mercury__vn_util__record_use_4_0),
		mercury__vn_util__build_uses_from_livevals_3_0_i10,
		STATIC(mercury__vn_util__build_uses_from_livevals_3_0));
Define_label(mercury__vn_util__build_uses_from_livevals_3_0_i4);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__vn_table__record_first_vnlval_4_0),
		mercury__vn_util__build_uses_from_livevals_3_0_i8,
		STATIC(mercury__vn_util__build_uses_from_livevals_3_0));
Define_label(mercury__vn_util__build_uses_from_livevals_3_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_util__build_uses_from_livevals_3_0));
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(1), (Integer) 1, mercury__vn_util__build_uses_from_livevals_3_0, "vn_type:vn_src/0");
	MR_field(MR_mktag(1), r2, (Integer) 0) = MR_stackvar(2);
	call_localret(STATIC(mercury__vn_util__record_use_4_0),
		mercury__vn_util__build_uses_from_livevals_3_0_i10,
		STATIC(mercury__vn_util__build_uses_from_livevals_3_0));
Define_label(mercury__vn_util__build_uses_from_livevals_3_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_util__build_uses_from_livevals_3_0));
	r2 = MR_stackvar(2);
	tag_incr_hp_msg(r3, MR_mktag(2), (Integer) 1, mercury__vn_util__build_uses_from_livevals_3_0, "vn_type:vn_src/0");
	MR_field(MR_mktag(2), r3, (Integer) 0) = r2;
	call_localret(STATIC(mercury__vn_util__DeforestationIn__pred__record_access__1008__0_4_0),
		mercury__vn_util__build_uses_from_livevals_3_0_i11,
		STATIC(mercury__vn_util__build_uses_from_livevals_3_0));
Define_label(mercury__vn_util__build_uses_from_livevals_3_0_i11);
	update_prof_current_proc(LABEL(mercury__vn_util__build_uses_from_livevals_3_0));
	r2 = r1;
	r1 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(4);
	GOTO_LABEL(mercury__vn_util__build_uses_from_livevals_3_0_i1002);
Define_label(mercury__vn_util__build_uses_from_livevals_3_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE

Declare_entry(mercury__vn_table__lookup_uses_4_0);
Declare_entry(mercury__vn_table__add_new_use_4_0);

BEGIN_MODULE(vn_util_module36)
	init_entry(mercury__vn_util__record_use_4_0);
	init_label(mercury__vn_util__record_use_4_0_i1001);
	init_label(mercury__vn_util__record_use_4_0_i2);
	init_label(mercury__vn_util__record_use_4_0_i3);
	init_label(mercury__vn_util__record_use_4_0_i6);
	init_label(mercury__vn_util__record_use_4_0_i9);
	init_label(mercury__vn_util__record_use_4_0_i14);
	init_label(mercury__vn_util__record_use_4_0_i16);
	init_label(mercury__vn_util__record_use_4_0_i18);
	init_label(mercury__vn_util__record_use_4_0_i19);
	init_label(mercury__vn_util__record_use_4_0_i22);
	init_label(mercury__vn_util__record_use_4_0_i23);
	init_label(mercury__vn_util__record_use_4_0_i25);
BEGIN_CODE

/* code for predicate 'record_use'/4 in mode 0 */
Define_static(mercury__vn_util__record_use_4_0);
	MR_incr_sp_push_msg(4, "vn_util:record_use/4");
	MR_stackvar(4) = (Word) MR_succip;
Define_label(mercury__vn_util__record_use_4_0_i1001);
	MR_stackvar(2) = r2;
	r2 = (Word) MR_string_const("vn_util__record_use", 19);
	MR_stackvar(1) = r1;
	MR_stackvar(3) = r3;
	call_localret(ENTRY(mercury__vn_table__lookup_uses_4_0),
		mercury__vn_util__record_use_4_0_i2,
		STATIC(mercury__vn_util__record_use_4_0));
Define_label(mercury__vn_util__record_use_4_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_util__record_use_4_0));
	r2 = MR_stackvar(2);
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(1);
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury__vn_table__add_new_use_4_0),
		mercury__vn_util__record_use_4_0_i3,
		STATIC(mercury__vn_util__record_use_4_0));
Define_label(mercury__vn_util__record_use_4_0_i3);
	update_prof_current_proc(LABEL(mercury__vn_util__record_use_4_0));
	if (((Integer) MR_stackvar(2) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_util__record_use_4_0_i25);
	r3 = r1;
	MR_stackvar(2) = r1;
	r1 = MR_stackvar(1);
	r2 = (Word) MR_string_const("vn_util__record_use", 19);
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_util__record_use_4_0_i6,
		STATIC(mercury__vn_util__record_use_4_0));
Define_label(mercury__vn_util__record_use_4_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_util__record_use_4_0));
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__vn_util__record_use_4_0_i9) AND
		LABEL(mercury__vn_util__record_use_4_0_i23) AND
		LABEL(mercury__vn_util__record_use_4_0_i22) AND
		LABEL(mercury__vn_util__record_use_4_0_i14));
Define_label(mercury__vn_util__record_use_4_0_i9);
	tag_incr_hp_msg(r3, MR_mktag(2), (Integer) 1, mercury__vn_util__record_use_4_0, "origin_lost_in_value_number");
	r2 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_field(MR_mktag(2), r3, (Integer) 0) = r2;
	r1 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__vn_util__DeforestationIn__pred__record_access__1008__0_4_0),
		STATIC(mercury__vn_util__record_use_4_0));
Define_label(mercury__vn_util__record_use_4_0_i14);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__vn_util__record_use_4_0_i22) AND
		LABEL(mercury__vn_util__record_use_4_0_i16) AND
		LABEL(mercury__vn_util__record_use_4_0_i18) AND
		LABEL(mercury__vn_util__record_use_4_0_i22) AND
		LABEL(mercury__vn_util__record_use_4_0_i22) AND
		LABEL(mercury__vn_util__record_use_4_0_i23));
Define_label(mercury__vn_util__record_use_4_0_i16);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 1, mercury__vn_util__record_use_4_0, "vn_type:vn_src/0");
	MR_field(MR_mktag(3), r2, (Integer) 0) = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	GOTO_LABEL(mercury__vn_util__record_use_4_0_i1001);
Define_label(mercury__vn_util__record_use_4_0_i18);
	r2 = MR_stackvar(1);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	r3 = MR_stackvar(2);
	{
	Word MR_tempr1;
	tag_incr_hp_msg(MR_tempr1, MR_mktag(3), (Integer) 1, mercury__vn_util__record_use_4_0, "origin_lost_in_value_number");
	MR_field(MR_mktag(3), MR_tempr1, (Integer) 0) = r2;
	r2 = MR_tempr1;
	MR_stackvar(2) = MR_tempr1;
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	localcall(mercury__vn_util__record_use_4_0,
		LABEL(mercury__vn_util__record_use_4_0_i19),
		STATIC(mercury__vn_util__record_use_4_0));
	}
Define_label(mercury__vn_util__record_use_4_0_i19);
	update_prof_current_proc(LABEL(mercury__vn_util__record_use_4_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	GOTO_LABEL(mercury__vn_util__record_use_4_0_i1001);
Define_label(mercury__vn_util__record_use_4_0_i22);
	r1 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__vn_util__record_use_4_0_i23);
	r1 = MR_const_mask_field(r1, (Integer) 1);
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 1, mercury__vn_util__record_use_4_0, "vn_type:vn_src/0");
	MR_field(MR_mktag(3), r2, (Integer) 0) = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(4);
	GOTO_LABEL(mercury__vn_util__record_use_4_0_i1001);
Define_label(mercury__vn_util__record_use_4_0_i25);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE


BEGIN_MODULE(vn_util_module37)
	init_entry(mercury__vn_util__record_use_list_4_0);
	init_label(mercury__vn_util__record_use_list_4_0_i1001);
	init_label(mercury__vn_util__record_use_list_4_0_i4);
	init_label(mercury__vn_util__record_use_list_4_0_i3);
BEGIN_CODE

/* code for predicate 'record_use_list'/4 in mode 0 */
Define_static(mercury__vn_util__record_use_list_4_0);
	MR_incr_sp_push_msg(3, "vn_util:record_use_list/4");
	MR_stackvar(3) = (Word) MR_succip;
Define_label(mercury__vn_util__record_use_list_4_0_i1001);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_util__record_use_list_4_0_i3);
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__vn_util__record_use_4_0),
		mercury__vn_util__record_use_list_4_0_i4,
		STATIC(mercury__vn_util__record_use_list_4_0));
Define_label(mercury__vn_util__record_use_list_4_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_util__record_use_list_4_0));
	r3 = r1;
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	GOTO_LABEL(mercury__vn_util__record_use_list_4_0_i1001);
Define_label(mercury__vn_util__record_use_list_4_0_i3);
	r1 = r3;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__vn_util_maybe_bunch_0(void)
{
	vn_util_module0();
	vn_util_module1();
	vn_util_module2();
	vn_util_module3();
	vn_util_module4();
	vn_util_module5();
	vn_util_module6();
	vn_util_module7();
	vn_util_module8();
	vn_util_module9();
	vn_util_module10();
	vn_util_module11();
	vn_util_module12();
	vn_util_module13();
	vn_util_module14();
	vn_util_module15();
	vn_util_module16();
	vn_util_module17();
	vn_util_module18();
	vn_util_module19();
	vn_util_module20();
	vn_util_module21();
	vn_util_module22();
	vn_util_module23();
	vn_util_module24();
	vn_util_module25();
	vn_util_module26();
	vn_util_module27();
	vn_util_module28();
	vn_util_module29();
	vn_util_module30();
	vn_util_module31();
	vn_util_module32();
	vn_util_module33();
	vn_util_module34();
	vn_util_module35();
	vn_util_module36();
	vn_util_module37();
}

#endif

void mercury__vn_util__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__vn_util__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__vn_util_maybe_bunch_0();
#endif

	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
