/*
** Automatically generated from `vn_verify.m' by the Mercury compiler,
** version 0.9.1, configured for alpha-dec-osf3.2.
** Do not edit.
**
** The autoconfigured grade settings governing
** the generation of this C file were
**
** TAG_BITS=2
** UNBOXED_FLOAT=no
**
** END_OF_C_GRADE_INFO
*/
/*
INIT mercury__vn_verify__init
ENDINIT
*/

#include "mercury_imp.h"

Define_extern_entry(mercury__vn_verify__ok_11_0);
Declare_label(mercury__vn_verify__ok_11_0_i3);
Declare_label(mercury__vn_verify__ok_11_0_i6);
Declare_label(mercury__vn_verify__ok_11_0_i7);
Declare_label(mercury__vn_verify__ok_11_0_i8);
Declare_label(mercury__vn_verify__ok_11_0_i9);
Declare_label(mercury__vn_verify__ok_11_0_i10);
Declare_label(mercury__vn_verify__ok_11_0_i11);
Declare_label(mercury__vn_verify__ok_11_0_i12);
Declare_label(mercury__vn_verify__ok_11_0_i13);
Declare_label(mercury__vn_verify__ok_11_0_i14);
Declare_label(mercury__vn_verify__ok_11_0_i15);
Declare_label(mercury__vn_verify__ok_11_0_i16);
Declare_label(mercury__vn_verify__ok_11_0_i18);
Declare_label(mercury__vn_verify__ok_11_0_i20);
Declare_label(mercury__vn_verify__ok_11_0_i21);
Declare_label(mercury__vn_verify__ok_11_0_i22);
Declare_label(mercury__vn_verify__ok_11_0_i23);
Declare_label(mercury__vn_verify__ok_11_0_i24);
Declare_label(mercury__vn_verify__ok_11_0_i26);
Declare_label(mercury__vn_verify__ok_11_0_i27);
Declare_label(mercury__vn_verify__ok_11_0_i5);
Declare_label(mercury__vn_verify__ok_11_0_i30);
Declare_label(mercury__vn_verify__ok_11_0_i31);
Declare_label(mercury__vn_verify__ok_11_0_i32);
Declare_label(mercury__vn_verify__ok_11_0_i33);
Declare_label(mercury__vn_verify__ok_11_0_i29);
Declare_label(mercury__vn_verify__ok_11_0_i35);
Declare_static(mercury__vn_verify__correspondence_4_0);
Declare_label(mercury__vn_verify__correspondence_4_0_i1005);
Declare_label(mercury__vn_verify__correspondence_4_0_i3);
Declare_label(mercury__vn_verify__correspondence_4_0_i5);
Declare_label(mercury__vn_verify__correspondence_4_0_i7);
Declare_label(mercury__vn_verify__correspondence_4_0_i11);
Declare_label(mercury__vn_verify__correspondence_4_0_i10);
Declare_label(mercury__vn_verify__correspondence_4_0_i14);
Declare_label(mercury__vn_verify__correspondence_4_0_i4);
Declare_label(mercury__vn_verify__correspondence_4_0_i20);
Declare_label(mercury__vn_verify__correspondence_4_0_i18);
Declare_label(mercury__vn_verify__correspondence_4_0_i23);
Declare_label(mercury__vn_verify__correspondence_4_0_i24);
Declare_static(mercury__vn_verify__make_verify_map_2_5_0);
Declare_label(mercury__vn_verify__make_verify_map_2_5_0_i1025);
Declare_label(mercury__vn_verify__make_verify_map_2_5_0_i4);
Declare_label(mercury__vn_verify__make_verify_map_2_5_0_i5);
Declare_label(mercury__vn_verify__make_verify_map_2_5_0_i9);
Declare_label(mercury__vn_verify__make_verify_map_2_5_0_i10);
Declare_label(mercury__vn_verify__make_verify_map_2_5_0_i12);
Declare_label(mercury__vn_verify__make_verify_map_2_5_0_i14);
Declare_label(mercury__vn_verify__make_verify_map_2_5_0_i16);
Declare_label(mercury__vn_verify__make_verify_map_2_5_0_i18);
Declare_label(mercury__vn_verify__make_verify_map_2_5_0_i20);
Declare_label(mercury__vn_verify__make_verify_map_2_5_0_i22);
Declare_label(mercury__vn_verify__make_verify_map_2_5_0_i24);
Declare_label(mercury__vn_verify__make_verify_map_2_5_0_i25);
Declare_label(mercury__vn_verify__make_verify_map_2_5_0_i27);
Declare_label(mercury__vn_verify__make_verify_map_2_5_0_i29);
Declare_label(mercury__vn_verify__make_verify_map_2_5_0_i32);
Declare_label(mercury__vn_verify__make_verify_map_2_5_0_i35);
Declare_label(mercury__vn_verify__make_verify_map_2_5_0_i38);
Declare_label(mercury__vn_verify__make_verify_map_2_5_0_i41);
Declare_label(mercury__vn_verify__make_verify_map_2_5_0_i44);
Declare_label(mercury__vn_verify__make_verify_map_2_5_0_i7);
Declare_label(mercury__vn_verify__make_verify_map_2_5_0_i6);
Declare_label(mercury__vn_verify__make_verify_map_2_5_0_i48);
Declare_label(mercury__vn_verify__make_verify_map_2_5_0_i49);
Declare_label(mercury__vn_verify__make_verify_map_2_5_0_i52);
Declare_label(mercury__vn_verify__make_verify_map_2_5_0_i54);
Declare_label(mercury__vn_verify__make_verify_map_2_5_0_i55);
Declare_label(mercury__vn_verify__make_verify_map_2_5_0_i56);
Declare_label(mercury__vn_verify__make_verify_map_2_5_0_i59);
Declare_label(mercury__vn_verify__make_verify_map_2_5_0_i58);
Declare_label(mercury__vn_verify__make_verify_map_2_5_0_i61);
Declare_label(mercury__vn_verify__make_verify_map_2_5_0_i63);
Declare_label(mercury__vn_verify__make_verify_map_2_5_0_i50);
Declare_label(mercury__vn_verify__make_verify_map_2_5_0_i3);
Declare_static(mercury__vn_verify__make_verify_map_specials_3_0);
Declare_label(mercury__vn_verify__make_verify_map_specials_3_0_i1002);
Declare_label(mercury__vn_verify__make_verify_map_specials_3_0_i7);
Declare_label(mercury__vn_verify__make_verify_map_specials_3_0_i8);
Declare_label(mercury__vn_verify__make_verify_map_specials_3_0_i5);
Declare_label(mercury__vn_verify__make_verify_map_specials_3_0_i3);
Declare_static(mercury__vn_verify__values_3_0);
Declare_label(mercury__vn_verify__values_3_0_i4);
Declare_label(mercury__vn_verify__values_3_0_i5);
Declare_label(mercury__vn_verify__values_3_0_i3);
Declare_static(mercury__vn_verify__value_3_0);
Declare_label(mercury__vn_verify__value_3_0_i2);
Declare_label(mercury__vn_verify__value_3_0_i3);
Declare_label(mercury__vn_verify__value_3_0_i4);
Declare_label(mercury__vn_verify__value_3_0_i7);
Declare_label(mercury__vn_verify__value_3_0_i6);
Declare_static(mercury__vn_verify__subst_sub_vns_4_0);
Declare_label(mercury__vn_verify__subst_sub_vns_4_0_i4);
Declare_label(mercury__vn_verify__subst_sub_vns_4_0_i5);
Declare_label(mercury__vn_verify__subst_sub_vns_4_0_i6);
Declare_label(mercury__vn_verify__subst_sub_vns_4_0_i10);
Declare_label(mercury__vn_verify__subst_sub_vns_4_0_i11);
Declare_label(mercury__vn_verify__subst_sub_vns_4_0_i13);
Declare_label(mercury__vn_verify__subst_sub_vns_4_0_i15);
Declare_label(mercury__vn_verify__subst_sub_vns_4_0_i17);
Declare_label(mercury__vn_verify__subst_sub_vns_4_0_i19);
Declare_label(mercury__vn_verify__subst_sub_vns_4_0_i21);
Declare_label(mercury__vn_verify__subst_sub_vns_4_0_i23);
Declare_label(mercury__vn_verify__subst_sub_vns_4_0_i25);
Declare_label(mercury__vn_verify__subst_sub_vns_4_0_i26);
Declare_label(mercury__vn_verify__subst_sub_vns_4_0_i28);
Declare_label(mercury__vn_verify__subst_sub_vns_4_0_i30);
Declare_label(mercury__vn_verify__subst_sub_vns_4_0_i33);
Declare_label(mercury__vn_verify__subst_sub_vns_4_0_i36);
Declare_label(mercury__vn_verify__subst_sub_vns_4_0_i39);
Declare_label(mercury__vn_verify__subst_sub_vns_4_0_i42);
Declare_label(mercury__vn_verify__subst_sub_vns_4_0_i45);
Declare_label(mercury__vn_verify__subst_sub_vns_4_0_i1063);
Declare_label(mercury__vn_verify__subst_sub_vns_4_0_i7);
Declare_label(mercury__vn_verify__subst_sub_vns_4_0_i49);
Declare_label(mercury__vn_verify__subst_sub_vns_4_0_i51);
Declare_label(mercury__vn_verify__subst_sub_vns_4_0_i54);
Declare_label(mercury__vn_verify__subst_sub_vns_4_0_i56);
Declare_label(mercury__vn_verify__subst_sub_vns_4_0_i57);
Declare_label(mercury__vn_verify__subst_sub_vns_4_0_i59);
Declare_label(mercury__vn_verify__subst_sub_vns_4_0_i62);
Declare_label(mercury__vn_verify__subst_sub_vns_4_0_i1);
Declare_static(mercury__vn_verify__tags_2_3_0);
Declare_label(mercury__vn_verify__tags_2_3_0_i1026);
Declare_label(mercury__vn_verify__tags_2_3_0_i9);
Declare_label(mercury__vn_verify__tags_2_3_0_i10);
Declare_label(mercury__vn_verify__tags_2_3_0_i12);
Declare_label(mercury__vn_verify__tags_2_3_0_i13);
Declare_label(mercury__vn_verify__tags_2_3_0_i16);
Declare_label(mercury__vn_verify__tags_2_3_0_i19);
Declare_label(mercury__vn_verify__tags_2_3_0_i18);
Declare_label(mercury__vn_verify__tags_2_3_0_i22);
Declare_label(mercury__vn_verify__tags_2_3_0_i15);
Declare_label(mercury__vn_verify__tags_2_3_0_i23);
Declare_label(mercury__vn_verify__tags_2_3_0_i25);
Declare_label(mercury__vn_verify__tags_2_3_0_i27);
Declare_label(mercury__vn_verify__tags_2_3_0_i24);
Declare_label(mercury__vn_verify__tags_2_3_0_i30);
Declare_label(mercury__vn_verify__tags_2_3_0_i31);
Declare_label(mercury__vn_verify__tags_2_3_0_i1008);
Declare_label(mercury__vn_verify__tags_2_3_0_i38);
Declare_label(mercury__vn_verify__tags_2_3_0_i40);
Declare_label(mercury__vn_verify__tags_2_3_0_i41);
Declare_label(mercury__vn_verify__tags_2_3_0_i43);
Declare_label(mercury__vn_verify__tags_2_3_0_i44);
Declare_label(mercury__vn_verify__tags_2_3_0_i46);
Declare_label(mercury__vn_verify__tags_2_3_0_i48);
Declare_label(mercury__vn_verify__tags_2_3_0_i49);
Declare_label(mercury__vn_verify__tags_2_3_0_i51);
Declare_label(mercury__vn_verify__tags_2_3_0_i52);
Declare_label(mercury__vn_verify__tags_2_3_0_i54);
Declare_label(mercury__vn_verify__tags_2_3_0_i55);
Declare_label(mercury__vn_verify__tags_2_3_0_i57);
Declare_label(mercury__vn_verify__tags_2_3_0_i58);
Declare_label(mercury__vn_verify__tags_2_3_0_i60);
Declare_label(mercury__vn_verify__tags_2_3_0_i61);
Declare_label(mercury__vn_verify__tags_2_3_0_i63);
Declare_label(mercury__vn_verify__tags_2_3_0_i64);
Declare_label(mercury__vn_verify__tags_2_3_0_i67);
Declare_label(mercury__vn_verify__tags_2_3_0_i68);
Declare_label(mercury__vn_verify__tags_2_3_0_i2);
Declare_label(mercury__vn_verify__tags_2_3_0_i1);
Declare_static(mercury__vn_verify__tags_lval_2_0);
Declare_label(mercury__vn_verify__tags_lval_2_0_i12);
Declare_label(mercury__vn_verify__tags_lval_2_0_i27);
Declare_label(mercury__vn_verify__tags_lval_2_0_i30);
Declare_label(mercury__vn_verify__tags_lval_2_0_i32);
Declare_label(mercury__vn_verify__tags_lval_2_0_i34);
Declare_label(mercury__vn_verify__tags_lval_2_0_i1007);
Declare_label(mercury__vn_verify__tags_lval_2_0_i38);
Declare_label(mercury__vn_verify__tags_lval_2_0_i1);
Declare_static(mercury__vn_verify__tags_rval_2_0);
Declare_label(mercury__vn_verify__tags_rval_2_0_i4);
Declare_label(mercury__vn_verify__tags_rval_2_0_i7);
Declare_label(mercury__vn_verify__tags_rval_2_0_i10);
Declare_label(mercury__vn_verify__tags_rval_2_0_i15);
Declare_label(mercury__vn_verify__tags_rval_2_0_i18);
Declare_label(mercury__vn_verify__tags_rval_2_0_i19);
Declare_label(mercury__vn_verify__tags_rval_2_0_i1004);
Declare_label(mercury__vn_verify__tags_rval_2_0_i1);
Declare_static(mercury__vn_verify__tags_cond_5_0);
Declare_label(mercury__vn_verify__tags_cond_5_0_i1020);
Declare_label(mercury__vn_verify__tags_cond_5_0_i6);
Declare_label(mercury__vn_verify__tags_cond_5_0_i10);
Declare_label(mercury__vn_verify__tags_cond_5_0_i5);
Declare_label(mercury__vn_verify__tags_cond_5_0_i11);
Declare_label(mercury__vn_verify__tags_cond_5_0_i13);
Declare_label(mercury__vn_verify__tags_cond_5_0_i16);
Declare_label(mercury__vn_verify__tags_cond_5_0_i15);
Declare_label(mercury__vn_verify__tags_cond_5_0_i19);
Declare_label(mercury__vn_verify__tags_cond_5_0_i14);
Declare_label(mercury__vn_verify__tags_cond_5_0_i20);
Declare_label(mercury__vn_verify__tags_cond_5_0_i2);
Declare_label(mercury__vn_verify__tags_cond_5_0_i26);
Declare_label(mercury__vn_verify__tags_cond_5_0_i28);
Declare_label(mercury__vn_verify__tags_cond_5_0_i23);
Declare_label(mercury__vn_verify__tags_cond_5_0_i32);
Declare_label(mercury__vn_verify__tags_cond_5_0_i39);
Declare_label(mercury__vn_verify__tags_cond_5_0_i41);
Declare_label(mercury__vn_verify__tags_cond_5_0_i37);
Declare_label(mercury__vn_verify__tags_cond_5_0_i42);
Declare_label(mercury__vn_verify__tags_cond_5_0_i1);

static const struct mercury_data_vn_verify__common_0_struct {
	Word * f1;
	Word * f2;
	Word * f3;
}  mercury_data_vn_verify__common_0;

extern const struct MR_TypeCtorInfo_struct
	mercury_data_std_util__type_ctor_info_pair_2;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_llds__type_ctor_info_instr_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data___type_ctor_info_string_0;
static const struct mercury_data_vn_verify__common_0_struct mercury_data_vn_verify__common_0 = {
	(Word *) &mercury_data_std_util__type_ctor_info_pair_2,
	(Word *) &mercury_data_llds__type_ctor_info_instr_0,
	(Word *) &mercury_data___type_ctor_info_string_0
};

Declare_entry(mercury__vn_debug__failure_msg_4_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_vn_type__type_ctor_info_vnlval_0;
Declare_entry(mercury__set__to_sorted_list_2_0);
extern const struct MR_TypeCtorInfo_struct
	mercury_data_llds__type_ctor_info_lval_0;
extern const struct MR_TypeCtorInfo_struct
	mercury_data_llds__type_ctor_info_rval_0;
Declare_entry(mercury__map__init_1_0);
Declare_entry(mercury__vn_table__get_all_vnrvals_2_0);
Declare_entry(mercury__map__keys_2_0);
Declare_entry(mercury__list__append_3_1);
Declare_entry(mercury__list__remove_dups_2_0);
Declare_entry(mercury__list__reverse_2_0);
Declare_entry(mercury__set__init_1_0);

BEGIN_MODULE(vn_verify_module0)
	init_entry(mercury__vn_verify__ok_11_0);
	init_label(mercury__vn_verify__ok_11_0_i3);
	init_label(mercury__vn_verify__ok_11_0_i6);
	init_label(mercury__vn_verify__ok_11_0_i7);
	init_label(mercury__vn_verify__ok_11_0_i8);
	init_label(mercury__vn_verify__ok_11_0_i9);
	init_label(mercury__vn_verify__ok_11_0_i10);
	init_label(mercury__vn_verify__ok_11_0_i11);
	init_label(mercury__vn_verify__ok_11_0_i12);
	init_label(mercury__vn_verify__ok_11_0_i13);
	init_label(mercury__vn_verify__ok_11_0_i14);
	init_label(mercury__vn_verify__ok_11_0_i15);
	init_label(mercury__vn_verify__ok_11_0_i16);
	init_label(mercury__vn_verify__ok_11_0_i18);
	init_label(mercury__vn_verify__ok_11_0_i20);
	init_label(mercury__vn_verify__ok_11_0_i21);
	init_label(mercury__vn_verify__ok_11_0_i22);
	init_label(mercury__vn_verify__ok_11_0_i23);
	init_label(mercury__vn_verify__ok_11_0_i24);
	init_label(mercury__vn_verify__ok_11_0_i26);
	init_label(mercury__vn_verify__ok_11_0_i27);
	init_label(mercury__vn_verify__ok_11_0_i5);
	init_label(mercury__vn_verify__ok_11_0_i30);
	init_label(mercury__vn_verify__ok_11_0_i31);
	init_label(mercury__vn_verify__ok_11_0_i32);
	init_label(mercury__vn_verify__ok_11_0_i33);
	init_label(mercury__vn_verify__ok_11_0_i29);
	init_label(mercury__vn_verify__ok_11_0_i35);
BEGIN_CODE

/* code for predicate 'ok'/11 in mode 0 */
Define_entry(mercury__vn_verify__ok_11_0);
	MR_incr_sp_push_msg(9, "vn_verify:ok/11");
	MR_stackvar(9) = (Word) MR_succip;
	if ((r3 == r4))
		GOTO_LABEL(mercury__vn_verify__ok_11_0_i3);
	r1 = r2;
	r2 = (Word) MR_string_const("disagreement on SeenIncr", 24);
	r3 = r9;
	call_localret(ENTRY(mercury__vn_debug__failure_msg_4_0),
		mercury__vn_verify__ok_11_0_i35,
		ENTRY(mercury__vn_verify__ok_11_0));
Define_label(mercury__vn_verify__ok_11_0_i3);
	MR_stackvar(1) = r1;
	MR_stackvar(2) = r2;
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0;
	r2 = r5;
	MR_stackvar(4) = r6;
	MR_stackvar(5) = r7;
	MR_stackvar(6) = r8;
	MR_stackvar(7) = r9;
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__vn_verify__ok_11_0_i6,
		ENTRY(mercury__vn_verify__ok_11_0));
Define_label(mercury__vn_verify__ok_11_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_verify__ok_11_0));
	MR_stackvar(3) = r1;
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0;
	r2 = MR_stackvar(4);
	call_localret(ENTRY(mercury__set__to_sorted_list_2_0),
		mercury__vn_verify__ok_11_0_i7,
		ENTRY(mercury__vn_verify__ok_11_0));
Define_label(mercury__vn_verify__ok_11_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_verify__ok_11_0));
	MR_stackvar(4) = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_lval_0;
	r2 = (Word) (Word *) &mercury_data_llds__type_ctor_info_rval_0;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__vn_verify__ok_11_0_i8,
		ENTRY(mercury__vn_verify__ok_11_0));
Define_label(mercury__vn_verify__ok_11_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_verify__ok_11_0));
	MR_stackvar(8) = r1;
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury__vn_table__get_all_vnrvals_2_0),
		mercury__vn_verify__ok_11_0_i9,
		ENTRY(mercury__vn_verify__ok_11_0));
Define_label(mercury__vn_verify__ok_11_0_i9);
	update_prof_current_proc(LABEL(mercury__vn_verify__ok_11_0));
	r2 = MR_stackvar(3);
	call_localret(STATIC(mercury__vn_verify__make_verify_map_specials_3_0),
		mercury__vn_verify__ok_11_0_i10,
		ENTRY(mercury__vn_verify__ok_11_0));
Define_label(mercury__vn_verify__ok_11_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_verify__ok_11_0));
	r2 = MR_stackvar(5);
	r3 = MR_stackvar(8);
	call_localret(STATIC(mercury__vn_verify__make_verify_map_2_5_0),
		mercury__vn_verify__ok_11_0_i11,
		ENTRY(mercury__vn_verify__ok_11_0));
Define_label(mercury__vn_verify__ok_11_0_i11);
	update_prof_current_proc(LABEL(mercury__vn_verify__ok_11_0));
	MR_stackvar(3) = r1;
	MR_stackvar(5) = r2;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_lval_0;
	r2 = (Word) (Word *) &mercury_data_llds__type_ctor_info_rval_0;
	call_localret(ENTRY(mercury__map__init_1_0),
		mercury__vn_verify__ok_11_0_i12,
		ENTRY(mercury__vn_verify__ok_11_0));
Define_label(mercury__vn_verify__ok_11_0_i12);
	update_prof_current_proc(LABEL(mercury__vn_verify__ok_11_0));
	MR_stackvar(8) = r1;
	r1 = MR_stackvar(6);
	call_localret(ENTRY(mercury__vn_table__get_all_vnrvals_2_0),
		mercury__vn_verify__ok_11_0_i13,
		ENTRY(mercury__vn_verify__ok_11_0));
Define_label(mercury__vn_verify__ok_11_0_i13);
	update_prof_current_proc(LABEL(mercury__vn_verify__ok_11_0));
	r2 = MR_stackvar(4);
	call_localret(STATIC(mercury__vn_verify__make_verify_map_specials_3_0),
		mercury__vn_verify__ok_11_0_i14,
		ENTRY(mercury__vn_verify__ok_11_0));
Define_label(mercury__vn_verify__ok_11_0_i14);
	update_prof_current_proc(LABEL(mercury__vn_verify__ok_11_0));
	r2 = MR_stackvar(6);
	r3 = MR_stackvar(8);
	call_localret(STATIC(mercury__vn_verify__make_verify_map_2_5_0),
		mercury__vn_verify__ok_11_0_i15,
		ENTRY(mercury__vn_verify__ok_11_0));
Define_label(mercury__vn_verify__ok_11_0_i15);
	update_prof_current_proc(LABEL(mercury__vn_verify__ok_11_0));
	if (((Integer) MR_stackvar(5) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__ok_11_0_i16);
	r1 = MR_stackvar(2);
	r3 = MR_stackvar(7);
	r2 = MR_stackvar(5);
	GOTO_LABEL(mercury__vn_verify__ok_11_0_i26);
Define_label(mercury__vn_verify__ok_11_0_i16);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__ok_11_0_i18);
	r1 = MR_stackvar(2);
	r3 = MR_stackvar(7);
	GOTO_LABEL(mercury__vn_verify__ok_11_0_i26);
Define_label(mercury__vn_verify__ok_11_0_i18);
	MR_stackvar(4) = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_lval_0;
	r2 = (Word) (Word *) &mercury_data_llds__type_ctor_info_rval_0;
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury__map__keys_2_0),
		mercury__vn_verify__ok_11_0_i20,
		ENTRY(mercury__vn_verify__ok_11_0));
Define_label(mercury__vn_verify__ok_11_0_i20);
	update_prof_current_proc(LABEL(mercury__vn_verify__ok_11_0));
	MR_stackvar(5) = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_lval_0;
	r2 = (Word) (Word *) &mercury_data_llds__type_ctor_info_rval_0;
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__map__keys_2_0),
		mercury__vn_verify__ok_11_0_i21,
		ENTRY(mercury__vn_verify__ok_11_0));
Define_label(mercury__vn_verify__ok_11_0_i21);
	update_prof_current_proc(LABEL(mercury__vn_verify__ok_11_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_lval_0;
	r2 = MR_stackvar(5);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__vn_verify__ok_11_0_i22,
		ENTRY(mercury__vn_verify__ok_11_0));
Define_label(mercury__vn_verify__ok_11_0_i22);
	update_prof_current_proc(LABEL(mercury__vn_verify__ok_11_0));
	r2 = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_lval_0;
	call_localret(ENTRY(mercury__list__remove_dups_2_0),
		mercury__vn_verify__ok_11_0_i23,
		ENTRY(mercury__vn_verify__ok_11_0));
Define_label(mercury__vn_verify__ok_11_0_i23);
	update_prof_current_proc(LABEL(mercury__vn_verify__ok_11_0));
	r2 = MR_stackvar(3);
	r3 = MR_stackvar(4);
	call_localret(STATIC(mercury__vn_verify__correspondence_4_0),
		mercury__vn_verify__ok_11_0_i24,
		ENTRY(mercury__vn_verify__ok_11_0));
Define_label(mercury__vn_verify__ok_11_0_i24);
	update_prof_current_proc(LABEL(mercury__vn_verify__ok_11_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	r3 = MR_stackvar(7);
Define_label(mercury__vn_verify__ok_11_0_i26);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__ok_11_0_i27);
	MR_stackvar(2) = r1;
	MR_stackvar(7) = r3;
	GOTO_LABEL(mercury__vn_verify__ok_11_0_i5);
Define_label(mercury__vn_verify__ok_11_0_i27);
	r2 = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	call_localret(ENTRY(mercury__vn_debug__failure_msg_4_0),
		mercury__vn_verify__ok_11_0_i35,
		ENTRY(mercury__vn_verify__ok_11_0));
Define_label(mercury__vn_verify__ok_11_0_i5);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) &mercury_data_vn_verify__common_0);
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__list__reverse_2_0),
		mercury__vn_verify__ok_11_0_i30,
		ENTRY(mercury__vn_verify__ok_11_0));
Define_label(mercury__vn_verify__ok_11_0_i30);
	update_prof_current_proc(LABEL(mercury__vn_verify__ok_11_0));
	MR_stackvar(1) = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_rval_0;
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__vn_verify__ok_11_0_i31,
		ENTRY(mercury__vn_verify__ok_11_0));
Define_label(mercury__vn_verify__ok_11_0_i31);
	update_prof_current_proc(LABEL(mercury__vn_verify__ok_11_0));
	MR_stackvar(3) = r1;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_lval_0;
	call_localret(ENTRY(mercury__set__init_1_0),
		mercury__vn_verify__ok_11_0_i32,
		ENTRY(mercury__vn_verify__ok_11_0));
Define_label(mercury__vn_verify__ok_11_0_i32);
	update_prof_current_proc(LABEL(mercury__vn_verify__ok_11_0));
	r3 = r1;
	r1 = MR_stackvar(1);
	r2 = MR_stackvar(3);
	call_localret(STATIC(mercury__vn_verify__tags_2_3_0),
		mercury__vn_verify__ok_11_0_i33,
		ENTRY(mercury__vn_verify__ok_11_0));
Define_label(mercury__vn_verify__ok_11_0_i33);
	update_prof_current_proc(LABEL(mercury__vn_verify__ok_11_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_verify__ok_11_0_i29);
	r1 = (Integer) 1;
	r2 = MR_stackvar(7);
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__vn_verify__ok_11_0_i29);
	r1 = MR_stackvar(2);
	r2 = (Word) MR_string_const("failure of tag check", 20);
	r3 = MR_stackvar(7);
	call_localret(ENTRY(mercury__vn_debug__failure_msg_4_0),
		mercury__vn_verify__ok_11_0_i35,
		ENTRY(mercury__vn_verify__ok_11_0));
Define_label(mercury__vn_verify__ok_11_0_i35);
	update_prof_current_proc(LABEL(mercury__vn_verify__ok_11_0));
	r2 = r1;
	r1 = (Integer) 0;
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE

Declare_entry(mercury__map__search_3_1);
Declare_entry(mercury____Unify___llds__rval_0_0);
Declare_entry(mercury__opt_debug__dump_lval_2_0);
Declare_entry(mercury__string__append_3_2);

BEGIN_MODULE(vn_verify_module1)
	init_entry(mercury__vn_verify__correspondence_4_0);
	init_label(mercury__vn_verify__correspondence_4_0_i1005);
	init_label(mercury__vn_verify__correspondence_4_0_i3);
	init_label(mercury__vn_verify__correspondence_4_0_i5);
	init_label(mercury__vn_verify__correspondence_4_0_i7);
	init_label(mercury__vn_verify__correspondence_4_0_i11);
	init_label(mercury__vn_verify__correspondence_4_0_i10);
	init_label(mercury__vn_verify__correspondence_4_0_i14);
	init_label(mercury__vn_verify__correspondence_4_0_i4);
	init_label(mercury__vn_verify__correspondence_4_0_i20);
	init_label(mercury__vn_verify__correspondence_4_0_i18);
	init_label(mercury__vn_verify__correspondence_4_0_i23);
	init_label(mercury__vn_verify__correspondence_4_0_i24);
BEGIN_CODE

/* code for predicate 'correspondence'/4 in mode 0 */
Define_static(mercury__vn_verify__correspondence_4_0);
	MR_incr_sp_push_msg(6, "vn_verify:correspondence/4");
	MR_stackvar(6) = (Word) MR_succip;
Define_label(mercury__vn_verify__correspondence_4_0_i1005);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__correspondence_4_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
Define_label(mercury__vn_verify__correspondence_4_0_i3);
	MR_stackvar(2) = r3;
	r4 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(3) = r4;
	r3 = r2;
	MR_stackvar(1) = r2;
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_lval_0;
	r2 = (Word) (Word *) &mercury_data_llds__type_ctor_info_rval_0;
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__vn_verify__correspondence_4_0_i5,
		STATIC(mercury__vn_verify__correspondence_4_0));
Define_label(mercury__vn_verify__correspondence_4_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_verify__correspondence_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_verify__correspondence_4_0_i4);
	MR_stackvar(5) = r2;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_lval_0;
	r2 = (Word) (Word *) &mercury_data_llds__type_ctor_info_rval_0;
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__vn_verify__correspondence_4_0_i7,
		STATIC(mercury__vn_verify__correspondence_4_0));
Define_label(mercury__vn_verify__correspondence_4_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_verify__correspondence_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_verify__correspondence_4_0_i4);
	r1 = MR_stackvar(5);
	call_localret(ENTRY(mercury____Unify___llds__rval_0_0),
		mercury__vn_verify__correspondence_4_0_i11,
		STATIC(mercury__vn_verify__correspondence_4_0));
Define_label(mercury__vn_verify__correspondence_4_0_i11);
	update_prof_current_proc(LABEL(mercury__vn_verify__correspondence_4_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_verify__correspondence_4_0_i10);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(6);
	GOTO_LABEL(mercury__vn_verify__correspondence_4_0_i1005);
Define_label(mercury__vn_verify__correspondence_4_0_i10);
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__opt_debug__dump_lval_2_0),
		mercury__vn_verify__correspondence_4_0_i14,
		STATIC(mercury__vn_verify__correspondence_4_0));
Define_label(mercury__vn_verify__correspondence_4_0_i14);
	update_prof_current_proc(LABEL(mercury__vn_verify__correspondence_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const("disagreement on value of ", 25);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__vn_verify__correspondence_4_0_i24,
		STATIC(mercury__vn_verify__correspondence_4_0));
Define_label(mercury__vn_verify__correspondence_4_0_i4);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_lval_0;
	r2 = (Word) (Word *) &mercury_data_llds__type_ctor_info_rval_0;
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	call_localret(ENTRY(mercury__map__search_3_1),
		mercury__vn_verify__correspondence_4_0_i20,
		STATIC(mercury__vn_verify__correspondence_4_0));
Define_label(mercury__vn_verify__correspondence_4_0_i20);
	update_prof_current_proc(LABEL(mercury__vn_verify__correspondence_4_0));
	if (r1)
		GOTO_LABEL(mercury__vn_verify__correspondence_4_0_i18);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(6);
	GOTO_LABEL(mercury__vn_verify__correspondence_4_0_i1005);
Define_label(mercury__vn_verify__correspondence_4_0_i18);
	r1 = MR_stackvar(3);
	call_localret(ENTRY(mercury__opt_debug__dump_lval_2_0),
		mercury__vn_verify__correspondence_4_0_i23,
		STATIC(mercury__vn_verify__correspondence_4_0));
Define_label(mercury__vn_verify__correspondence_4_0_i23);
	update_prof_current_proc(LABEL(mercury__vn_verify__correspondence_4_0));
	r2 = r1;
	r1 = (Word) MR_string_const("cannot find value of ", 21);
	call_localret(ENTRY(mercury__string__append_3_2),
		mercury__vn_verify__correspondence_4_0_i24,
		STATIC(mercury__vn_verify__correspondence_4_0));
Define_label(mercury__vn_verify__correspondence_4_0_i24);
	update_prof_current_proc(LABEL(mercury__vn_verify__correspondence_4_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 1, mercury__vn_verify__correspondence_4_0, "std_util:maybe/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = r2;
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE

Declare_entry(mercury__vn_util__vnlval_access_vns_2_0);
Declare_entry(mercury__require__error_1_0);
Declare_entry(mercury__vn_table__search_desired_value_3_0);
Declare_entry(mercury__vn_table__lookup_defn_4_0);
Declare_entry(mercury__vn_util__find_sub_vns_2_0);
Declare_entry(mercury__map__set_4_1);

BEGIN_MODULE(vn_verify_module2)
	init_entry(mercury__vn_verify__make_verify_map_2_5_0);
	init_label(mercury__vn_verify__make_verify_map_2_5_0_i1025);
	init_label(mercury__vn_verify__make_verify_map_2_5_0_i4);
	init_label(mercury__vn_verify__make_verify_map_2_5_0_i5);
	init_label(mercury__vn_verify__make_verify_map_2_5_0_i9);
	init_label(mercury__vn_verify__make_verify_map_2_5_0_i10);
	init_label(mercury__vn_verify__make_verify_map_2_5_0_i12);
	init_label(mercury__vn_verify__make_verify_map_2_5_0_i14);
	init_label(mercury__vn_verify__make_verify_map_2_5_0_i16);
	init_label(mercury__vn_verify__make_verify_map_2_5_0_i18);
	init_label(mercury__vn_verify__make_verify_map_2_5_0_i20);
	init_label(mercury__vn_verify__make_verify_map_2_5_0_i22);
	init_label(mercury__vn_verify__make_verify_map_2_5_0_i24);
	init_label(mercury__vn_verify__make_verify_map_2_5_0_i25);
	init_label(mercury__vn_verify__make_verify_map_2_5_0_i27);
	init_label(mercury__vn_verify__make_verify_map_2_5_0_i29);
	init_label(mercury__vn_verify__make_verify_map_2_5_0_i32);
	init_label(mercury__vn_verify__make_verify_map_2_5_0_i35);
	init_label(mercury__vn_verify__make_verify_map_2_5_0_i38);
	init_label(mercury__vn_verify__make_verify_map_2_5_0_i41);
	init_label(mercury__vn_verify__make_verify_map_2_5_0_i44);
	init_label(mercury__vn_verify__make_verify_map_2_5_0_i7);
	init_label(mercury__vn_verify__make_verify_map_2_5_0_i6);
	init_label(mercury__vn_verify__make_verify_map_2_5_0_i48);
	init_label(mercury__vn_verify__make_verify_map_2_5_0_i49);
	init_label(mercury__vn_verify__make_verify_map_2_5_0_i52);
	init_label(mercury__vn_verify__make_verify_map_2_5_0_i54);
	init_label(mercury__vn_verify__make_verify_map_2_5_0_i55);
	init_label(mercury__vn_verify__make_verify_map_2_5_0_i56);
	init_label(mercury__vn_verify__make_verify_map_2_5_0_i59);
	init_label(mercury__vn_verify__make_verify_map_2_5_0_i58);
	init_label(mercury__vn_verify__make_verify_map_2_5_0_i61);
	init_label(mercury__vn_verify__make_verify_map_2_5_0_i63);
	init_label(mercury__vn_verify__make_verify_map_2_5_0_i50);
	init_label(mercury__vn_verify__make_verify_map_2_5_0_i3);
BEGIN_CODE

/* code for predicate 'make_verify_map_2'/5 in mode 0 */
Define_static(mercury__vn_verify__make_verify_map_2_5_0);
	MR_incr_sp_push_msg(6, "vn_verify:make_verify_map_2/5");
	MR_stackvar(6) = (Word) MR_succip;
Define_label(mercury__vn_verify__make_verify_map_2_5_0_i1025);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__make_verify_map_2_5_0_i3);
	MR_stackvar(4) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(3) = r1;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	call_localret(ENTRY(mercury__vn_util__vnlval_access_vns_2_0),
		mercury__vn_verify__make_verify_map_2_5_0_i4,
		STATIC(mercury__vn_verify__make_verify_map_2_5_0));
Define_label(mercury__vn_verify__make_verify_map_2_5_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_verify__make_verify_map_2_5_0));
	r2 = MR_stackvar(1);
	call_localret(STATIC(mercury__vn_verify__values_3_0),
		mercury__vn_verify__make_verify_map_2_5_0_i5,
		STATIC(mercury__vn_verify__make_verify_map_2_5_0));
Define_label(mercury__vn_verify__make_verify_map_2_5_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_verify__make_verify_map_2_5_0));
	r2 = MR_stackvar(3);
	COMPUTED_GOTO((Unsigned) MR_tag(r2),
		LABEL(mercury__vn_verify__make_verify_map_2_5_0_i9) AND
		LABEL(mercury__vn_verify__make_verify_map_2_5_0_i20) AND
		LABEL(mercury__vn_verify__make_verify_map_2_5_0_i22) AND
		LABEL(mercury__vn_verify__make_verify_map_2_5_0_i24));
Define_label(mercury__vn_verify__make_verify_map_2_5_0_i9);
	COMPUTED_GOTO((Unsigned) MR_unmkbody(r2),
		LABEL(mercury__vn_verify__make_verify_map_2_5_0_i10) AND
		LABEL(mercury__vn_verify__make_verify_map_2_5_0_i12) AND
		LABEL(mercury__vn_verify__make_verify_map_2_5_0_i14) AND
		LABEL(mercury__vn_verify__make_verify_map_2_5_0_i16) AND
		LABEL(mercury__vn_verify__make_verify_map_2_5_0_i18));
Define_label(mercury__vn_verify__make_verify_map_2_5_0_i10);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__make_verify_map_2_5_0_i6);
	r1 = r2;
	r2 = MR_stackvar(1);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	GOTO_LABEL(mercury__vn_verify__make_verify_map_2_5_0_i7);
Define_label(mercury__vn_verify__make_verify_map_2_5_0_i12);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__make_verify_map_2_5_0_i6);
	r1 = r2;
	r2 = MR_stackvar(1);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1));
	GOTO_LABEL(mercury__vn_verify__make_verify_map_2_5_0_i7);
Define_label(mercury__vn_verify__make_verify_map_2_5_0_i14);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__make_verify_map_2_5_0_i6);
	r1 = r2;
	r2 = MR_stackvar(1);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 2));
	GOTO_LABEL(mercury__vn_verify__make_verify_map_2_5_0_i7);
Define_label(mercury__vn_verify__make_verify_map_2_5_0_i16);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__make_verify_map_2_5_0_i6);
	r1 = r2;
	r2 = MR_stackvar(1);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 3));
	GOTO_LABEL(mercury__vn_verify__make_verify_map_2_5_0_i7);
Define_label(mercury__vn_verify__make_verify_map_2_5_0_i18);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__make_verify_map_2_5_0_i6);
	r1 = r2;
	r2 = MR_stackvar(1);
	r3 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 4));
	GOTO_LABEL(mercury__vn_verify__make_verify_map_2_5_0_i7);
Define_label(mercury__vn_verify__make_verify_map_2_5_0_i20);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__make_verify_map_2_5_0_i6);
	r1 = r2;
	r2 = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(1), (Integer) 2, mercury__vn_verify__make_verify_map_2_5_0, "llds:lval/0");
	MR_field(MR_mktag(1), r3, (Integer) 0) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_field(MR_mktag(1), r3, (Integer) 1) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	GOTO_LABEL(mercury__vn_verify__make_verify_map_2_5_0_i7);
Define_label(mercury__vn_verify__make_verify_map_2_5_0_i22);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__make_verify_map_2_5_0_i6);
	r1 = r2;
	r2 = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(2), (Integer) 2, mercury__vn_verify__make_verify_map_2_5_0, "llds:lval/0");
	MR_field(MR_mktag(2), r3, (Integer) 0) = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	MR_field(MR_mktag(2), r3, (Integer) 1) = MR_const_field(MR_mktag(2), r1, (Integer) 1);
	GOTO_LABEL(mercury__vn_verify__make_verify_map_2_5_0_i7);
Define_label(mercury__vn_verify__make_verify_map_2_5_0_i24);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r2, (Integer) 0),
		LABEL(mercury__vn_verify__make_verify_map_2_5_0_i25) AND
		LABEL(mercury__vn_verify__make_verify_map_2_5_0_i27) AND
		LABEL(mercury__vn_verify__make_verify_map_2_5_0_i29) AND
		LABEL(mercury__vn_verify__make_verify_map_2_5_0_i32) AND
		LABEL(mercury__vn_verify__make_verify_map_2_5_0_i35) AND
		LABEL(mercury__vn_verify__make_verify_map_2_5_0_i38) AND
		LABEL(mercury__vn_verify__make_verify_map_2_5_0_i41) AND
		LABEL(mercury__vn_verify__make_verify_map_2_5_0_i44) AND
		LABEL(mercury__vn_verify__make_verify_map_2_5_0_i6));
Define_label(mercury__vn_verify__make_verify_map_2_5_0_i25);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__make_verify_map_2_5_0_i6);
	r1 = r2;
	r2 = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 2, mercury__vn_verify__make_verify_map_2_5_0, "llds:lval/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(3), r3, (Integer) 1) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	GOTO_LABEL(mercury__vn_verify__make_verify_map_2_5_0_i7);
Define_label(mercury__vn_verify__make_verify_map_2_5_0_i27);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__make_verify_map_2_5_0_i6);
	r1 = r2;
	r2 = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 2, mercury__vn_verify__make_verify_map_2_5_0, "llds:lval/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r3, (Integer) 1) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	GOTO_LABEL(mercury__vn_verify__make_verify_map_2_5_0_i7);
Define_label(mercury__vn_verify__make_verify_map_2_5_0_i29);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__make_verify_map_2_5_0_i6);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__make_verify_map_2_5_0_i6);
	r4 = r1;
	r1 = r2;
	r2 = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 2, mercury__vn_verify__make_verify_map_2_5_0, "llds:lval/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 5;
	MR_field(MR_mktag(3), r3, (Integer) 1) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	GOTO_LABEL(mercury__vn_verify__make_verify_map_2_5_0_i7);
Define_label(mercury__vn_verify__make_verify_map_2_5_0_i32);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__make_verify_map_2_5_0_i6);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__make_verify_map_2_5_0_i6);
	r4 = r1;
	r1 = r2;
	r2 = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 2, mercury__vn_verify__make_verify_map_2_5_0, "llds:lval/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 6;
	MR_field(MR_mktag(3), r3, (Integer) 1) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	GOTO_LABEL(mercury__vn_verify__make_verify_map_2_5_0_i7);
Define_label(mercury__vn_verify__make_verify_map_2_5_0_i35);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__make_verify_map_2_5_0_i6);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__make_verify_map_2_5_0_i6);
	r4 = r1;
	r1 = r2;
	r2 = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 2, mercury__vn_verify__make_verify_map_2_5_0, "llds:lval/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(3), r3, (Integer) 1) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	GOTO_LABEL(mercury__vn_verify__make_verify_map_2_5_0_i7);
Define_label(mercury__vn_verify__make_verify_map_2_5_0_i38);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__make_verify_map_2_5_0_i6);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__make_verify_map_2_5_0_i6);
	r4 = r1;
	r1 = r2;
	r2 = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 2, mercury__vn_verify__make_verify_map_2_5_0, "llds:lval/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r3, (Integer) 1) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	GOTO_LABEL(mercury__vn_verify__make_verify_map_2_5_0_i7);
Define_label(mercury__vn_verify__make_verify_map_2_5_0_i41);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__make_verify_map_2_5_0_i6);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	if (((Integer) r3 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__make_verify_map_2_5_0_i6);
	r4 = r1;
	r1 = r2;
	r2 = MR_stackvar(1);
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 2, mercury__vn_verify__make_verify_map_2_5_0, "llds:lval/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r3, (Integer) 1) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	GOTO_LABEL(mercury__vn_verify__make_verify_map_2_5_0_i7);
Define_label(mercury__vn_verify__make_verify_map_2_5_0_i44);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__make_verify_map_2_5_0_i6);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__make_verify_map_2_5_0_i6);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r1, (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__make_verify_map_2_5_0_i6);
	r3 = r2;
	r2 = MR_stackvar(1);
	r4 = r1;
	r1 = r3;
	r5 = r3;
	tag_incr_hp_msg(r3, MR_mktag(3), (Integer) 4, mercury__vn_verify__make_verify_map_2_5_0, "llds:lval/0");
	MR_field(MR_mktag(3), r3, (Integer) 0) = (Integer) 7;
	MR_field(MR_mktag(3), r3, (Integer) 1) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_field(MR_mktag(3), r3, (Integer) 2) = MR_const_field(MR_mktag(1), r4, (Integer) 0);
	MR_field(MR_mktag(3), r3, (Integer) 3) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r4, (Integer) 1), (Integer) 0);
Define_label(mercury__vn_verify__make_verify_map_2_5_0_i7);
	MR_stackvar(3) = r3;
	GOTO_LABEL(mercury__vn_verify__make_verify_map_2_5_0_i49);
Define_label(mercury__vn_verify__make_verify_map_2_5_0_i6);
	r1 = (Word) MR_string_const("cannot substitute access vns in vn_verify__lval", 47);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_verify__make_verify_map_2_5_0_i48,
		STATIC(mercury__vn_verify__make_verify_map_2_5_0));
Define_label(mercury__vn_verify__make_verify_map_2_5_0_i48);
	update_prof_current_proc(LABEL(mercury__vn_verify__make_verify_map_2_5_0));
	r2 = MR_stackvar(1);
	r1 = MR_stackvar(3);
Define_label(mercury__vn_verify__make_verify_map_2_5_0_i49);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__vn_table__search_desired_value_3_0),
		mercury__vn_verify__make_verify_map_2_5_0_i52,
		STATIC(mercury__vn_verify__make_verify_map_2_5_0));
Define_label(mercury__vn_verify__make_verify_map_2_5_0_i52);
	update_prof_current_proc(LABEL(mercury__vn_verify__make_verify_map_2_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_verify__make_verify_map_2_5_0_i50);
	r1 = r2;
	r2 = (Word) MR_string_const("vn_verify__value", 16);
	r3 = MR_stackvar(1);
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_verify__make_verify_map_2_5_0_i54,
		STATIC(mercury__vn_verify__make_verify_map_2_5_0));
Define_label(mercury__vn_verify__make_verify_map_2_5_0_i54);
	update_prof_current_proc(LABEL(mercury__vn_verify__make_verify_map_2_5_0));
	MR_stackvar(5) = r1;
	call_localret(ENTRY(mercury__vn_util__find_sub_vns_2_0),
		mercury__vn_verify__make_verify_map_2_5_0_i55,
		STATIC(mercury__vn_verify__make_verify_map_2_5_0));
Define_label(mercury__vn_verify__make_verify_map_2_5_0_i55);
	update_prof_current_proc(LABEL(mercury__vn_verify__make_verify_map_2_5_0));
	r2 = MR_stackvar(1);
	call_localret(STATIC(mercury__vn_verify__values_3_0),
		mercury__vn_verify__make_verify_map_2_5_0_i56,
		STATIC(mercury__vn_verify__make_verify_map_2_5_0));
Define_label(mercury__vn_verify__make_verify_map_2_5_0_i56);
	update_prof_current_proc(LABEL(mercury__vn_verify__make_verify_map_2_5_0));
	r2 = r1;
	r1 = MR_stackvar(5);
	r3 = MR_stackvar(1);
	call_localret(STATIC(mercury__vn_verify__subst_sub_vns_4_0),
		mercury__vn_verify__make_verify_map_2_5_0_i59,
		STATIC(mercury__vn_verify__make_verify_map_2_5_0));
Define_label(mercury__vn_verify__make_verify_map_2_5_0_i59);
	update_prof_current_proc(LABEL(mercury__vn_verify__make_verify_map_2_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_verify__make_verify_map_2_5_0_i58);
	r5 = r2;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_lval_0;
	r2 = (Word) (Word *) &mercury_data_llds__type_ctor_info_rval_0;
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__vn_verify__make_verify_map_2_5_0_i63,
		STATIC(mercury__vn_verify__make_verify_map_2_5_0));
Define_label(mercury__vn_verify__make_verify_map_2_5_0_i58);
	r1 = (Word) MR_string_const("cannot substitute sub vns in vn_verify__value", 45);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_verify__make_verify_map_2_5_0_i61,
		STATIC(mercury__vn_verify__make_verify_map_2_5_0));
Define_label(mercury__vn_verify__make_verify_map_2_5_0_i61);
	update_prof_current_proc(LABEL(mercury__vn_verify__make_verify_map_2_5_0));
	r5 = r1;
	r1 = r2;
	r2 = r3;
	r3 = MR_stackvar(2);
	r4 = MR_stackvar(3);
	call_localret(ENTRY(mercury__map__set_4_1),
		mercury__vn_verify__make_verify_map_2_5_0_i63,
		STATIC(mercury__vn_verify__make_verify_map_2_5_0));
Define_label(mercury__vn_verify__make_verify_map_2_5_0_i63);
	update_prof_current_proc(LABEL(mercury__vn_verify__make_verify_map_2_5_0));
	r3 = r1;
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(6);
	GOTO_LABEL(mercury__vn_verify__make_verify_map_2_5_0_i1025);
Define_label(mercury__vn_verify__make_verify_map_2_5_0_i50);
	r2 = MR_stackvar(1);
	r1 = MR_stackvar(4);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(6);
	GOTO_LABEL(mercury__vn_verify__make_verify_map_2_5_0_i1025);
Define_label(mercury__vn_verify__make_verify_map_2_5_0_i3);
	r1 = r3;
	r2 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	MR_succip = (Code *) MR_stackvar(6);
	MR_decr_sp_pop_msg(6);
	proceed();
END_MODULE

Declare_entry(mercury__vn_util__find_specials_2_0);

BEGIN_MODULE(vn_verify_module3)
	init_entry(mercury__vn_verify__make_verify_map_specials_3_0);
	init_label(mercury__vn_verify__make_verify_map_specials_3_0_i1002);
	init_label(mercury__vn_verify__make_verify_map_specials_3_0_i7);
	init_label(mercury__vn_verify__make_verify_map_specials_3_0_i8);
	init_label(mercury__vn_verify__make_verify_map_specials_3_0_i5);
	init_label(mercury__vn_verify__make_verify_map_specials_3_0_i3);
BEGIN_CODE

/* code for predicate 'make_verify_map_specials'/3 in mode 0 */
Define_static(mercury__vn_verify__make_verify_map_specials_3_0);
	MR_incr_sp_push_msg(3, "vn_verify:make_verify_map_specials/3");
	MR_stackvar(3) = (Word) MR_succip;
Define_label(mercury__vn_verify__make_verify_map_specials_3_0_i1002);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__make_verify_map_specials_3_0_i3);
	r3 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	if ((MR_tag(MR_tempr1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__vn_verify__make_verify_map_specials_3_0_i5);
	MR_stackvar(2) = r3;
	r1 = MR_const_field(MR_mktag(0), MR_tempr1, (Integer) 0);
	MR_stackvar(1) = r2;
	call_localret(ENTRY(mercury__vn_util__find_specials_2_0),
		mercury__vn_verify__make_verify_map_specials_3_0_i7,
		STATIC(mercury__vn_verify__make_verify_map_specials_3_0));
	}
Define_label(mercury__vn_verify__make_verify_map_specials_3_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_verify__make_verify_map_specials_3_0));
	r3 = r1;
	r1 = (Word) (Word *) &mercury_data_vn_type__type_ctor_info_vnlval_0;
	r2 = MR_stackvar(1);
	call_localret(ENTRY(mercury__list__append_3_1),
		mercury__vn_verify__make_verify_map_specials_3_0_i8,
		STATIC(mercury__vn_verify__make_verify_map_specials_3_0));
Define_label(mercury__vn_verify__make_verify_map_specials_3_0_i8);
	update_prof_current_proc(LABEL(mercury__vn_verify__make_verify_map_specials_3_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(3);
	GOTO_LABEL(mercury__vn_verify__make_verify_map_specials_3_0_i1002);
Define_label(mercury__vn_verify__make_verify_map_specials_3_0_i5);
	r1 = r3;
	MR_succip = (Code *) MR_stackvar(3);
	GOTO_LABEL(mercury__vn_verify__make_verify_map_specials_3_0_i1002);
Define_label(mercury__vn_verify__make_verify_map_specials_3_0_i3);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(vn_verify_module4)
	init_entry(mercury__vn_verify__values_3_0);
	init_label(mercury__vn_verify__values_3_0_i4);
	init_label(mercury__vn_verify__values_3_0_i5);
	init_label(mercury__vn_verify__values_3_0_i3);
BEGIN_CODE

/* code for predicate 'values'/3 in mode 0 */
Define_static(mercury__vn_verify__values_3_0);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__values_3_0_i3);
	MR_incr_sp_push_msg(3, "vn_verify:values/3");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(2) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_stackvar(1) = r2;
	call_localret(STATIC(mercury__vn_verify__value_3_0),
		mercury__vn_verify__values_3_0_i4,
		STATIC(mercury__vn_verify__values_3_0));
Define_label(mercury__vn_verify__values_3_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_verify__values_3_0));
	r2 = MR_stackvar(1);
	MR_stackvar(1) = r1;
	r1 = MR_stackvar(2);
	localcall(mercury__vn_verify__values_3_0,
		LABEL(mercury__vn_verify__values_3_0_i5),
		STATIC(mercury__vn_verify__values_3_0));
Define_label(mercury__vn_verify__values_3_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_verify__values_3_0));
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__vn_verify__values_3_0, "list:list/1");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_stackvar(1);
	MR_field(MR_mktag(1), r1, (Integer) 1) = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_verify__values_3_0_i3);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	proceed();
END_MODULE


BEGIN_MODULE(vn_verify_module5)
	init_entry(mercury__vn_verify__value_3_0);
	init_label(mercury__vn_verify__value_3_0_i2);
	init_label(mercury__vn_verify__value_3_0_i3);
	init_label(mercury__vn_verify__value_3_0_i4);
	init_label(mercury__vn_verify__value_3_0_i7);
	init_label(mercury__vn_verify__value_3_0_i6);
BEGIN_CODE

/* code for predicate 'value'/3 in mode 0 */
Define_static(mercury__vn_verify__value_3_0);
	MR_incr_sp_push_msg(3, "vn_verify:value/3");
	MR_stackvar(3) = (Word) MR_succip;
	MR_stackvar(1) = r2;
	r3 = r2;
	r2 = (Word) MR_string_const("vn_verify__value", 16);
	call_localret(ENTRY(mercury__vn_table__lookup_defn_4_0),
		mercury__vn_verify__value_3_0_i2,
		STATIC(mercury__vn_verify__value_3_0));
Define_label(mercury__vn_verify__value_3_0_i2);
	update_prof_current_proc(LABEL(mercury__vn_verify__value_3_0));
	MR_stackvar(2) = r1;
	call_localret(ENTRY(mercury__vn_util__find_sub_vns_2_0),
		mercury__vn_verify__value_3_0_i3,
		STATIC(mercury__vn_verify__value_3_0));
Define_label(mercury__vn_verify__value_3_0_i3);
	update_prof_current_proc(LABEL(mercury__vn_verify__value_3_0));
	r2 = MR_stackvar(1);
	call_localret(STATIC(mercury__vn_verify__values_3_0),
		mercury__vn_verify__value_3_0_i4,
		STATIC(mercury__vn_verify__value_3_0));
Define_label(mercury__vn_verify__value_3_0_i4);
	update_prof_current_proc(LABEL(mercury__vn_verify__value_3_0));
	r2 = r1;
	r1 = MR_stackvar(2);
	r3 = MR_stackvar(1);
	call_localret(STATIC(mercury__vn_verify__subst_sub_vns_4_0),
		mercury__vn_verify__value_3_0_i7,
		STATIC(mercury__vn_verify__value_3_0));
Define_label(mercury__vn_verify__value_3_0_i7);
	update_prof_current_proc(LABEL(mercury__vn_verify__value_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_verify__value_3_0_i6);
	r1 = r2;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_verify__value_3_0_i6);
	r1 = (Word) MR_string_const("cannot substitute sub vns in vn_verify__value", 45);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(ENTRY(mercury__require__error_1_0),
		STATIC(mercury__vn_verify__value_3_0));
END_MODULE


BEGIN_MODULE(vn_verify_module6)
	init_entry(mercury__vn_verify__subst_sub_vns_4_0);
	init_label(mercury__vn_verify__subst_sub_vns_4_0_i4);
	init_label(mercury__vn_verify__subst_sub_vns_4_0_i5);
	init_label(mercury__vn_verify__subst_sub_vns_4_0_i6);
	init_label(mercury__vn_verify__subst_sub_vns_4_0_i10);
	init_label(mercury__vn_verify__subst_sub_vns_4_0_i11);
	init_label(mercury__vn_verify__subst_sub_vns_4_0_i13);
	init_label(mercury__vn_verify__subst_sub_vns_4_0_i15);
	init_label(mercury__vn_verify__subst_sub_vns_4_0_i17);
	init_label(mercury__vn_verify__subst_sub_vns_4_0_i19);
	init_label(mercury__vn_verify__subst_sub_vns_4_0_i21);
	init_label(mercury__vn_verify__subst_sub_vns_4_0_i23);
	init_label(mercury__vn_verify__subst_sub_vns_4_0_i25);
	init_label(mercury__vn_verify__subst_sub_vns_4_0_i26);
	init_label(mercury__vn_verify__subst_sub_vns_4_0_i28);
	init_label(mercury__vn_verify__subst_sub_vns_4_0_i30);
	init_label(mercury__vn_verify__subst_sub_vns_4_0_i33);
	init_label(mercury__vn_verify__subst_sub_vns_4_0_i36);
	init_label(mercury__vn_verify__subst_sub_vns_4_0_i39);
	init_label(mercury__vn_verify__subst_sub_vns_4_0_i42);
	init_label(mercury__vn_verify__subst_sub_vns_4_0_i45);
	init_label(mercury__vn_verify__subst_sub_vns_4_0_i1063);
	init_label(mercury__vn_verify__subst_sub_vns_4_0_i7);
	init_label(mercury__vn_verify__subst_sub_vns_4_0_i49);
	init_label(mercury__vn_verify__subst_sub_vns_4_0_i51);
	init_label(mercury__vn_verify__subst_sub_vns_4_0_i54);
	init_label(mercury__vn_verify__subst_sub_vns_4_0_i56);
	init_label(mercury__vn_verify__subst_sub_vns_4_0_i57);
	init_label(mercury__vn_verify__subst_sub_vns_4_0_i59);
	init_label(mercury__vn_verify__subst_sub_vns_4_0_i62);
	init_label(mercury__vn_verify__subst_sub_vns_4_0_i1);
BEGIN_CODE

/* code for predicate 'subst_sub_vns'/4 in mode 0 */
Define_static(mercury__vn_verify__subst_sub_vns_4_0);
	MR_incr_sp_push_msg(3, "vn_verify:subst_sub_vns/4");
	MR_stackvar(3) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__vn_verify__subst_sub_vns_4_0_i4) AND
		LABEL(mercury__vn_verify__subst_sub_vns_4_0_i51) AND
		LABEL(mercury__vn_verify__subst_sub_vns_4_0_i54) AND
		LABEL(mercury__vn_verify__subst_sub_vns_4_0_i56));
Define_label(mercury__vn_verify__subst_sub_vns_4_0_i4);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(2) = r1;
	MR_stackvar(1) = r3;
	call_localret(ENTRY(mercury__vn_util__vnlval_access_vns_2_0),
		mercury__vn_verify__subst_sub_vns_4_0_i5,
		STATIC(mercury__vn_verify__subst_sub_vns_4_0));
Define_label(mercury__vn_verify__subst_sub_vns_4_0_i5);
	update_prof_current_proc(LABEL(mercury__vn_verify__subst_sub_vns_4_0));
	r2 = MR_stackvar(1);
	call_localret(STATIC(mercury__vn_verify__values_3_0),
		mercury__vn_verify__subst_sub_vns_4_0_i6,
		STATIC(mercury__vn_verify__subst_sub_vns_4_0));
Define_label(mercury__vn_verify__subst_sub_vns_4_0_i6);
	update_prof_current_proc(LABEL(mercury__vn_verify__subst_sub_vns_4_0));
	r2 = MR_stackvar(2);
	COMPUTED_GOTO((Unsigned) MR_tag(r2),
		LABEL(mercury__vn_verify__subst_sub_vns_4_0_i10) AND
		LABEL(mercury__vn_verify__subst_sub_vns_4_0_i21) AND
		LABEL(mercury__vn_verify__subst_sub_vns_4_0_i23) AND
		LABEL(mercury__vn_verify__subst_sub_vns_4_0_i25));
Define_label(mercury__vn_verify__subst_sub_vns_4_0_i10);
	COMPUTED_GOTO((Unsigned) MR_unmkbody(r2),
		LABEL(mercury__vn_verify__subst_sub_vns_4_0_i11) AND
		LABEL(mercury__vn_verify__subst_sub_vns_4_0_i13) AND
		LABEL(mercury__vn_verify__subst_sub_vns_4_0_i15) AND
		LABEL(mercury__vn_verify__subst_sub_vns_4_0_i17) AND
		LABEL(mercury__vn_verify__subst_sub_vns_4_0_i19));
Define_label(mercury__vn_verify__subst_sub_vns_4_0_i11);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__subst_sub_vns_4_0_i7);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0));
	GOTO_LABEL(mercury__vn_verify__subst_sub_vns_4_0_i1063);
Define_label(mercury__vn_verify__subst_sub_vns_4_0_i13);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__subst_sub_vns_4_0_i7);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 1));
	GOTO_LABEL(mercury__vn_verify__subst_sub_vns_4_0_i1063);
Define_label(mercury__vn_verify__subst_sub_vns_4_0_i15);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__subst_sub_vns_4_0_i7);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 2));
	GOTO_LABEL(mercury__vn_verify__subst_sub_vns_4_0_i1063);
Define_label(mercury__vn_verify__subst_sub_vns_4_0_i17);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__subst_sub_vns_4_0_i7);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 3));
	GOTO_LABEL(mercury__vn_verify__subst_sub_vns_4_0_i1063);
Define_label(mercury__vn_verify__subst_sub_vns_4_0_i19);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__subst_sub_vns_4_0_i7);
	r1 = (Word) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 4));
	GOTO_LABEL(mercury__vn_verify__subst_sub_vns_4_0_i1063);
Define_label(mercury__vn_verify__subst_sub_vns_4_0_i21);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__subst_sub_vns_4_0_i7);
	tag_incr_hp_msg(r1, MR_mktag(1), (Integer) 2, mercury__vn_verify__subst_sub_vns_4_0, "llds:lval/0");
	MR_field(MR_mktag(1), r1, (Integer) 0) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	MR_field(MR_mktag(1), r1, (Integer) 1) = MR_const_field(MR_mktag(1), r2, (Integer) 1);
	GOTO_LABEL(mercury__vn_verify__subst_sub_vns_4_0_i1063);
Define_label(mercury__vn_verify__subst_sub_vns_4_0_i23);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__subst_sub_vns_4_0_i7);
	tag_incr_hp_msg(r1, MR_mktag(2), (Integer) 2, mercury__vn_verify__subst_sub_vns_4_0, "llds:lval/0");
	MR_field(MR_mktag(2), r1, (Integer) 0) = MR_const_field(MR_mktag(2), r2, (Integer) 0);
	MR_field(MR_mktag(2), r1, (Integer) 1) = MR_const_field(MR_mktag(2), r2, (Integer) 1);
	GOTO_LABEL(mercury__vn_verify__subst_sub_vns_4_0_i1063);
Define_label(mercury__vn_verify__subst_sub_vns_4_0_i25);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r2, (Integer) 0),
		LABEL(mercury__vn_verify__subst_sub_vns_4_0_i26) AND
		LABEL(mercury__vn_verify__subst_sub_vns_4_0_i28) AND
		LABEL(mercury__vn_verify__subst_sub_vns_4_0_i30) AND
		LABEL(mercury__vn_verify__subst_sub_vns_4_0_i33) AND
		LABEL(mercury__vn_verify__subst_sub_vns_4_0_i36) AND
		LABEL(mercury__vn_verify__subst_sub_vns_4_0_i39) AND
		LABEL(mercury__vn_verify__subst_sub_vns_4_0_i42) AND
		LABEL(mercury__vn_verify__subst_sub_vns_4_0_i45) AND
		LABEL(mercury__vn_verify__subst_sub_vns_4_0_i7));
Define_label(mercury__vn_verify__subst_sub_vns_4_0_i26);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__subst_sub_vns_4_0_i7);
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__vn_verify__subst_sub_vns_4_0, "llds:lval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	GOTO_LABEL(mercury__vn_verify__subst_sub_vns_4_0_i1063);
Define_label(mercury__vn_verify__subst_sub_vns_4_0_i28);
	if (((Integer) r1 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__subst_sub_vns_4_0_i7);
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__vn_verify__subst_sub_vns_4_0, "llds:lval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	GOTO_LABEL(mercury__vn_verify__subst_sub_vns_4_0_i1063);
Define_label(mercury__vn_verify__subst_sub_vns_4_0_i30);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__subst_sub_vns_4_0_i7);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__subst_sub_vns_4_0_i7);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__vn_verify__subst_sub_vns_4_0, "llds:lval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 5;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	GOTO_LABEL(mercury__vn_verify__subst_sub_vns_4_0_i1063);
Define_label(mercury__vn_verify__subst_sub_vns_4_0_i33);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__subst_sub_vns_4_0_i7);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__subst_sub_vns_4_0_i7);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__vn_verify__subst_sub_vns_4_0, "llds:lval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 6;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	GOTO_LABEL(mercury__vn_verify__subst_sub_vns_4_0_i1063);
Define_label(mercury__vn_verify__subst_sub_vns_4_0_i36);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__subst_sub_vns_4_0_i7);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__subst_sub_vns_4_0_i7);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__vn_verify__subst_sub_vns_4_0, "llds:lval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 4;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	GOTO_LABEL(mercury__vn_verify__subst_sub_vns_4_0_i1063);
Define_label(mercury__vn_verify__subst_sub_vns_4_0_i39);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__subst_sub_vns_4_0_i7);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__subst_sub_vns_4_0_i7);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__vn_verify__subst_sub_vns_4_0, "llds:lval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	GOTO_LABEL(mercury__vn_verify__subst_sub_vns_4_0_i1063);
Define_label(mercury__vn_verify__subst_sub_vns_4_0_i42);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__subst_sub_vns_4_0_i7);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__subst_sub_vns_4_0_i7);
	r2 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 2, mercury__vn_verify__subst_sub_vns_4_0, "llds:lval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_const_field(MR_mktag(1), r2, (Integer) 0);
	GOTO_LABEL(mercury__vn_verify__subst_sub_vns_4_0_i1063);
Define_label(mercury__vn_verify__subst_sub_vns_4_0_i45);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__subst_sub_vns_4_0_i7);
	if (((Integer) MR_const_field(MR_mktag(1), r1, (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__subst_sub_vns_4_0_i7);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r1, (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__subst_sub_vns_4_0_i7);
	r3 = r1;
	tag_incr_hp_msg(r1, MR_mktag(3), (Integer) 4, mercury__vn_verify__subst_sub_vns_4_0, "llds:lval/0");
	MR_field(MR_mktag(3), r1, (Integer) 0) = (Integer) 7;
	MR_field(MR_mktag(3), r1, (Integer) 1) = MR_const_field(MR_mktag(3), r2, (Integer) 1);
	MR_field(MR_mktag(3), r1, (Integer) 2) = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_field(MR_mktag(3), r1, (Integer) 3) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r3, (Integer) 1), (Integer) 0);
Define_label(mercury__vn_verify__subst_sub_vns_4_0_i1063);
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 1, mercury__vn_verify__subst_sub_vns_4_0, "llds:rval/0");
	MR_field(MR_mktag(0), r2, (Integer) 0) = r1;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_verify__subst_sub_vns_4_0_i7);
	r1 = (Word) MR_string_const("cannot substitute access vns in vn_verify__lval", 47);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_verify__subst_sub_vns_4_0_i49,
		STATIC(mercury__vn_verify__subst_sub_vns_4_0));
Define_label(mercury__vn_verify__subst_sub_vns_4_0_i49);
	update_prof_current_proc(LABEL(mercury__vn_verify__subst_sub_vns_4_0));
	r2 = r1;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_verify__subst_sub_vns_4_0_i51);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__subst_sub_vns_4_0_i1);
	if (((Integer) MR_const_field(MR_mktag(1), r2, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__subst_sub_vns_4_0_i1);
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 3, mercury__vn_verify__subst_sub_vns_4_0, "llds:rval/0");
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 0;
	MR_field(MR_mktag(3), r2, (Integer) 1) = MR_const_field(MR_mktag(1), r1, (Integer) 0);
	MR_field(MR_mktag(3), r2, (Integer) 2) = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_verify__subst_sub_vns_4_0_i54);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__subst_sub_vns_4_0_i1);
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 2, mercury__vn_verify__subst_sub_vns_4_0, "llds:rval/0");
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 1;
	MR_field(MR_mktag(3), r2, (Integer) 1) = MR_const_field(MR_mktag(2), r1, (Integer) 0);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_verify__subst_sub_vns_4_0_i56);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__vn_verify__subst_sub_vns_4_0_i57) AND
		LABEL(mercury__vn_verify__subst_sub_vns_4_0_i59) AND
		LABEL(mercury__vn_verify__subst_sub_vns_4_0_i62) AND
		LABEL(mercury__vn_verify__subst_sub_vns_4_0_i1) AND
		LABEL(mercury__vn_verify__subst_sub_vns_4_0_i1) AND
		LABEL(mercury__vn_verify__subst_sub_vns_4_0_i1));
Define_label(mercury__vn_verify__subst_sub_vns_4_0_i57);
	if (((Integer) r2 != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__subst_sub_vns_4_0_i1);
	tag_incr_hp_msg(r2, MR_mktag(2), (Integer) 6, mercury__vn_verify__subst_sub_vns_4_0, "llds:rval/0");
	MR_field(MR_mktag(2), r2, (Integer) 0) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_field(MR_mktag(2), r2, (Integer) 1) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_field(MR_mktag(2), r2, (Integer) 2) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	MR_field(MR_mktag(2), r2, (Integer) 3) = MR_const_field(MR_mktag(3), r1, (Integer) 4);
	MR_field(MR_mktag(2), r2, (Integer) 4) = MR_const_field(MR_mktag(3), r1, (Integer) 5);
	MR_field(MR_mktag(2), r2, (Integer) 5) = MR_const_field(MR_mktag(3), r1, (Integer) 6);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_verify__subst_sub_vns_4_0_i59);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__subst_sub_vns_4_0_i1);
	if (((Integer) MR_const_field(MR_mktag(1), r2, (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__subst_sub_vns_4_0_i1);
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 3, mercury__vn_verify__subst_sub_vns_4_0, "llds:rval/0");
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 2;
	MR_field(MR_mktag(3), r2, (Integer) 1) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_field(MR_mktag(3), r2, (Integer) 2) = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_verify__subst_sub_vns_4_0_i62);
	if (((Integer) r2 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__subst_sub_vns_4_0_i1);
	if (((Integer) MR_const_field(MR_mktag(1), r2, (Integer) 1) == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__subst_sub_vns_4_0_i1);
	if (((Integer) MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r2, (Integer) 1), (Integer) 1) != (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__subst_sub_vns_4_0_i1);
	r3 = r2;
	tag_incr_hp_msg(r2, MR_mktag(3), (Integer) 4, mercury__vn_verify__subst_sub_vns_4_0, "llds:rval/0");
	MR_field(MR_mktag(3), r2, (Integer) 0) = (Integer) 3;
	MR_field(MR_mktag(3), r2, (Integer) 1) = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_field(MR_mktag(3), r2, (Integer) 2) = MR_const_field(MR_mktag(1), r3, (Integer) 0);
	MR_field(MR_mktag(3), r2, (Integer) 3) = MR_const_field(MR_mktag(1), MR_const_field(MR_mktag(1), r3, (Integer) 1), (Integer) 0);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_verify__subst_sub_vns_4_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE

Declare_entry(mercury__set__member_2_0);
Declare_entry(mercury__set__insert_3_1);
Declare_entry(mercury__set__delete_3_0);

BEGIN_MODULE(vn_verify_module7)
	init_entry(mercury__vn_verify__tags_2_3_0);
	init_label(mercury__vn_verify__tags_2_3_0_i1026);
	init_label(mercury__vn_verify__tags_2_3_0_i9);
	init_label(mercury__vn_verify__tags_2_3_0_i10);
	init_label(mercury__vn_verify__tags_2_3_0_i12);
	init_label(mercury__vn_verify__tags_2_3_0_i13);
	init_label(mercury__vn_verify__tags_2_3_0_i16);
	init_label(mercury__vn_verify__tags_2_3_0_i19);
	init_label(mercury__vn_verify__tags_2_3_0_i18);
	init_label(mercury__vn_verify__tags_2_3_0_i22);
	init_label(mercury__vn_verify__tags_2_3_0_i15);
	init_label(mercury__vn_verify__tags_2_3_0_i23);
	init_label(mercury__vn_verify__tags_2_3_0_i25);
	init_label(mercury__vn_verify__tags_2_3_0_i27);
	init_label(mercury__vn_verify__tags_2_3_0_i24);
	init_label(mercury__vn_verify__tags_2_3_0_i30);
	init_label(mercury__vn_verify__tags_2_3_0_i31);
	init_label(mercury__vn_verify__tags_2_3_0_i1008);
	init_label(mercury__vn_verify__tags_2_3_0_i38);
	init_label(mercury__vn_verify__tags_2_3_0_i40);
	init_label(mercury__vn_verify__tags_2_3_0_i41);
	init_label(mercury__vn_verify__tags_2_3_0_i43);
	init_label(mercury__vn_verify__tags_2_3_0_i44);
	init_label(mercury__vn_verify__tags_2_3_0_i46);
	init_label(mercury__vn_verify__tags_2_3_0_i48);
	init_label(mercury__vn_verify__tags_2_3_0_i49);
	init_label(mercury__vn_verify__tags_2_3_0_i51);
	init_label(mercury__vn_verify__tags_2_3_0_i52);
	init_label(mercury__vn_verify__tags_2_3_0_i54);
	init_label(mercury__vn_verify__tags_2_3_0_i55);
	init_label(mercury__vn_verify__tags_2_3_0_i57);
	init_label(mercury__vn_verify__tags_2_3_0_i58);
	init_label(mercury__vn_verify__tags_2_3_0_i60);
	init_label(mercury__vn_verify__tags_2_3_0_i61);
	init_label(mercury__vn_verify__tags_2_3_0_i63);
	init_label(mercury__vn_verify__tags_2_3_0_i64);
	init_label(mercury__vn_verify__tags_2_3_0_i67);
	init_label(mercury__vn_verify__tags_2_3_0_i68);
	init_label(mercury__vn_verify__tags_2_3_0_i2);
	init_label(mercury__vn_verify__tags_2_3_0_i1);
BEGIN_CODE

/* code for predicate 'tags_2'/3 in mode 0 */
Define_static(mercury__vn_verify__tags_2_3_0);
	MR_incr_sp_push_msg(9, "vn_verify:tags_2/3");
	MR_stackvar(9) = (Word) MR_succip;
Define_label(mercury__vn_verify__tags_2_3_0_i1026);
	if (((Integer) r1 == (Integer) MR_mkword(MR_mktag(0), (Word *) MR_mkbody((Integer) 0))))
		GOTO_LABEL(mercury__vn_verify__tags_2_3_0_i2);
	r4 = MR_const_field(MR_mktag(0), MR_const_field(MR_mktag(1), r1, (Integer) 0), (Integer) 0);
	COMPUTED_GOTO((Unsigned) MR_tag(r4),
		LABEL(mercury__vn_verify__tags_2_3_0_i67) AND
		LABEL(mercury__vn_verify__tags_2_3_0_i67) AND
		LABEL(mercury__vn_verify__tags_2_3_0_i67) AND
		LABEL(mercury__vn_verify__tags_2_3_0_i9));
Define_label(mercury__vn_verify__tags_2_3_0_i9);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r4, (Integer) 0),
		LABEL(mercury__vn_verify__tags_2_3_0_i10) AND
		LABEL(mercury__vn_verify__tags_2_3_0_i12) AND
		LABEL(mercury__vn_verify__tags_2_3_0_i67) AND
		LABEL(mercury__vn_verify__tags_2_3_0_i67) AND
		LABEL(mercury__vn_verify__tags_2_3_0_i67) AND
		LABEL(mercury__vn_verify__tags_2_3_0_i67) AND
		LABEL(mercury__vn_verify__tags_2_3_0_i67) AND
		LABEL(mercury__vn_verify__tags_2_3_0_i38) AND
		LABEL(mercury__vn_verify__tags_2_3_0_i40) AND
		LABEL(mercury__vn_verify__tags_2_3_0_i43) AND
		LABEL(mercury__vn_verify__tags_2_3_0_i48) AND
		LABEL(mercury__vn_verify__tags_2_3_0_i51) AND
		LABEL(mercury__vn_verify__tags_2_3_0_i54) AND
		LABEL(mercury__vn_verify__tags_2_3_0_i57) AND
		LABEL(mercury__vn_verify__tags_2_3_0_i60) AND
		LABEL(mercury__vn_verify__tags_2_3_0_i63) AND
		LABEL(mercury__vn_verify__tags_2_3_0_i67) AND
		LABEL(mercury__vn_verify__tags_2_3_0_i67) AND
		LABEL(mercury__vn_verify__tags_2_3_0_i68) AND
		LABEL(mercury__vn_verify__tags_2_3_0_i1) AND
		LABEL(mercury__vn_verify__tags_2_3_0_i1) AND
		LABEL(mercury__vn_verify__tags_2_3_0_i1) AND
		LABEL(mercury__vn_verify__tags_2_3_0_i1));
Define_label(mercury__vn_verify__tags_2_3_0_i10);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Word) MR_string_const("found block in vn_verify__tags_instr", 36);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_verify__tags_2_3_0_i1008,
		STATIC(mercury__vn_verify__tags_2_3_0));
Define_label(mercury__vn_verify__tags_2_3_0_i12);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(3), r4, (Integer) 1);
	MR_stackvar(7) = MR_const_field(MR_mktag(3), r4, (Integer) 2);
	MR_stackvar(6) = r1;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	call_localret(STATIC(mercury__vn_verify__tags_lval_2_0),
		mercury__vn_verify__tags_2_3_0_i13,
		STATIC(mercury__vn_verify__tags_2_3_0));
Define_label(mercury__vn_verify__tags_2_3_0_i13);
	update_prof_current_proc(LABEL(mercury__vn_verify__tags_2_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_verify__tags_2_3_0_i1);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_rval_0;
	tag_incr_hp_msg(r2, MR_mktag(0), (Integer) 1, mercury__vn_verify__tags_2_3_0, "llds:rval/0");
	MR_field(MR_mktag(0), r2, (Integer) 0) = MR_stackvar(6);
	r3 = MR_stackvar(1);
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__vn_verify__tags_2_3_0_i16,
		STATIC(mercury__vn_verify__tags_2_3_0));
Define_label(mercury__vn_verify__tags_2_3_0_i16);
	update_prof_current_proc(LABEL(mercury__vn_verify__tags_2_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_verify__tags_2_3_0_i15);
	if ((MR_tag(MR_stackvar(7)) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__vn_verify__tags_2_3_0_i19);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(7);
	GOTO_LABEL(mercury__vn_verify__tags_2_3_0_i18);
Define_label(mercury__vn_verify__tags_2_3_0_i19);
	r1 = MR_stackvar(7);
	if ((MR_tag(r1) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__vn_verify__tags_2_3_0_i15);
	if (((Integer) MR_const_field(MR_mktag(3), r1, (Integer) 0) != (Integer) 2))
		GOTO_LABEL(mercury__vn_verify__tags_2_3_0_i15);
	if (((Integer) MR_const_field(MR_mktag(3), r1, (Integer) 1) != (Integer) 1))
		GOTO_LABEL(mercury__vn_verify__tags_2_3_0_i15);
	r3 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r2 = MR_stackvar(1);
Define_label(mercury__vn_verify__tags_2_3_0_i18);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_rval_0;
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__vn_verify__tags_2_3_0_i22,
		STATIC(mercury__vn_verify__tags_2_3_0));
Define_label(mercury__vn_verify__tags_2_3_0_i22);
	update_prof_current_proc(LABEL(mercury__vn_verify__tags_2_3_0));
	r3 = MR_stackvar(2);
	r2 = MR_stackvar(6);
	MR_stackvar(8) = r1;
	GOTO_LABEL(mercury__vn_verify__tags_2_3_0_i23);
Define_label(mercury__vn_verify__tags_2_3_0_i15);
	r3 = MR_stackvar(2);
	r2 = MR_stackvar(6);
	MR_stackvar(8) = MR_stackvar(1);
Define_label(mercury__vn_verify__tags_2_3_0_i23);
	MR_stackvar(2) = r3;
	MR_stackvar(6) = r2;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_lval_0;
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__vn_verify__tags_2_3_0_i25,
		STATIC(mercury__vn_verify__tags_2_3_0));
Define_label(mercury__vn_verify__tags_2_3_0_i25);
	update_prof_current_proc(LABEL(mercury__vn_verify__tags_2_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_verify__tags_2_3_0_i24);
	tag_incr_hp_msg(r1, MR_mktag(0), (Integer) 1, mercury__vn_verify__tags_2_3_0, "origin_lost_in_value_number");
	MR_stackvar(4) = r1;
	r2 = MR_stackvar(8);
	r3 = MR_stackvar(2);
	MR_field(MR_mktag(0), r1, (Integer) 0) = MR_stackvar(6);
	call_localret(STATIC(mercury__vn_verify__tags_cond_5_0),
		mercury__vn_verify__tags_2_3_0_i27,
		STATIC(mercury__vn_verify__tags_2_3_0));
Define_label(mercury__vn_verify__tags_2_3_0_i27);
	update_prof_current_proc(LABEL(mercury__vn_verify__tags_2_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_verify__tags_2_3_0_i1);
	MR_stackvar(5) = r3;
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_rval_0;
	r3 = MR_stackvar(4);
	call_localret(ENTRY(mercury__set__delete_3_0),
		mercury__vn_verify__tags_2_3_0_i30,
		STATIC(mercury__vn_verify__tags_2_3_0));
Define_label(mercury__vn_verify__tags_2_3_0_i24);
	MR_stackvar(5) = MR_stackvar(2);
	r2 = MR_stackvar(8);
	tag_incr_hp_msg(r3, MR_mktag(0), (Integer) 1, mercury__vn_verify__tags_2_3_0, "llds:rval/0");
	MR_field(MR_mktag(0), r3, (Integer) 0) = MR_stackvar(6);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_rval_0;
	call_localret(ENTRY(mercury__set__delete_3_0),
		mercury__vn_verify__tags_2_3_0_i30,
		STATIC(mercury__vn_verify__tags_2_3_0));
Define_label(mercury__vn_verify__tags_2_3_0_i30);
	update_prof_current_proc(LABEL(mercury__vn_verify__tags_2_3_0));
	MR_stackvar(4) = r1;
	r2 = r1;
	r1 = MR_stackvar(7);
	call_localret(STATIC(mercury__vn_verify__tags_rval_2_0),
		mercury__vn_verify__tags_2_3_0_i31,
		STATIC(mercury__vn_verify__tags_2_3_0));
Define_label(mercury__vn_verify__tags_2_3_0_i31);
	update_prof_current_proc(LABEL(mercury__vn_verify__tags_2_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_verify__tags_2_3_0_i1);
Define_label(mercury__vn_verify__tags_2_3_0_i1008);
	update_prof_current_proc(LABEL(mercury__vn_verify__tags_2_3_0));
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(4);
	r3 = MR_stackvar(5);
	MR_succip = (Code *) MR_stackvar(9);
	GOTO_LABEL(mercury__vn_verify__tags_2_3_0_i1026);
Define_label(mercury__vn_verify__tags_2_3_0_i38);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Word) MR_string_const("found c_code in vn_verify__tags_instr", 37);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_verify__tags_2_3_0_i1008,
		STATIC(mercury__vn_verify__tags_2_3_0));
Define_label(mercury__vn_verify__tags_2_3_0_i40);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(3), r4, (Integer) 1);
	call_localret(STATIC(mercury__vn_verify__tags_cond_5_0),
		mercury__vn_verify__tags_2_3_0_i41,
		STATIC(mercury__vn_verify__tags_2_3_0));
Define_label(mercury__vn_verify__tags_2_3_0_i41);
	update_prof_current_proc(LABEL(mercury__vn_verify__tags_2_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_verify__tags_2_3_0_i1);
	r1 = MR_stackvar(3);
	MR_succip = (Code *) MR_stackvar(9);
	GOTO_LABEL(mercury__vn_verify__tags_2_3_0_i1026);
Define_label(mercury__vn_verify__tags_2_3_0_i43);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_stackvar(4) = MR_const_field(MR_mktag(3), r4, (Integer) 3);
	r1 = MR_const_field(MR_mktag(3), r4, (Integer) 1);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	call_localret(STATIC(mercury__vn_verify__tags_lval_2_0),
		mercury__vn_verify__tags_2_3_0_i44,
		STATIC(mercury__vn_verify__tags_2_3_0));
Define_label(mercury__vn_verify__tags_2_3_0_i44);
	update_prof_current_proc(LABEL(mercury__vn_verify__tags_2_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_verify__tags_2_3_0_i1);
	r1 = MR_stackvar(4);
	r2 = MR_stackvar(1);
	call_localret(STATIC(mercury__vn_verify__tags_rval_2_0),
		mercury__vn_verify__tags_2_3_0_i46,
		STATIC(mercury__vn_verify__tags_2_3_0));
Define_label(mercury__vn_verify__tags_2_3_0_i46);
	update_prof_current_proc(LABEL(mercury__vn_verify__tags_2_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_verify__tags_2_3_0_i1);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(9);
	GOTO_LABEL(mercury__vn_verify__tags_2_3_0_i1026);
Define_label(mercury__vn_verify__tags_2_3_0_i48);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(3), r4, (Integer) 1);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	call_localret(STATIC(mercury__vn_verify__tags_lval_2_0),
		mercury__vn_verify__tags_2_3_0_i49,
		STATIC(mercury__vn_verify__tags_2_3_0));
Define_label(mercury__vn_verify__tags_2_3_0_i49);
	update_prof_current_proc(LABEL(mercury__vn_verify__tags_2_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_verify__tags_2_3_0_i1);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(9);
	GOTO_LABEL(mercury__vn_verify__tags_2_3_0_i1026);
Define_label(mercury__vn_verify__tags_2_3_0_i51);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(3), r4, (Integer) 1);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	call_localret(STATIC(mercury__vn_verify__tags_rval_2_0),
		mercury__vn_verify__tags_2_3_0_i52,
		STATIC(mercury__vn_verify__tags_2_3_0));
Define_label(mercury__vn_verify__tags_2_3_0_i52);
	update_prof_current_proc(LABEL(mercury__vn_verify__tags_2_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_verify__tags_2_3_0_i1);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(9);
	GOTO_LABEL(mercury__vn_verify__tags_2_3_0_i1026);
Define_label(mercury__vn_verify__tags_2_3_0_i54);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(3), r4, (Integer) 1);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	call_localret(STATIC(mercury__vn_verify__tags_lval_2_0),
		mercury__vn_verify__tags_2_3_0_i55,
		STATIC(mercury__vn_verify__tags_2_3_0));
Define_label(mercury__vn_verify__tags_2_3_0_i55);
	update_prof_current_proc(LABEL(mercury__vn_verify__tags_2_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_verify__tags_2_3_0_i1);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(9);
	GOTO_LABEL(mercury__vn_verify__tags_2_3_0_i1026);
Define_label(mercury__vn_verify__tags_2_3_0_i57);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(3), r4, (Integer) 1);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	call_localret(STATIC(mercury__vn_verify__tags_rval_2_0),
		mercury__vn_verify__tags_2_3_0_i58,
		STATIC(mercury__vn_verify__tags_2_3_0));
Define_label(mercury__vn_verify__tags_2_3_0_i58);
	update_prof_current_proc(LABEL(mercury__vn_verify__tags_2_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_verify__tags_2_3_0_i1);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(9);
	GOTO_LABEL(mercury__vn_verify__tags_2_3_0_i1026);
Define_label(mercury__vn_verify__tags_2_3_0_i60);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(3), r4, (Integer) 1);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	call_localret(STATIC(mercury__vn_verify__tags_lval_2_0),
		mercury__vn_verify__tags_2_3_0_i61,
		STATIC(mercury__vn_verify__tags_2_3_0));
Define_label(mercury__vn_verify__tags_2_3_0_i61);
	update_prof_current_proc(LABEL(mercury__vn_verify__tags_2_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_verify__tags_2_3_0_i1);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(9);
	GOTO_LABEL(mercury__vn_verify__tags_2_3_0_i1026);
Define_label(mercury__vn_verify__tags_2_3_0_i63);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = MR_const_field(MR_mktag(3), r4, (Integer) 1);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	call_localret(STATIC(mercury__vn_verify__tags_rval_2_0),
		mercury__vn_verify__tags_2_3_0_i64,
		STATIC(mercury__vn_verify__tags_2_3_0));
Define_label(mercury__vn_verify__tags_2_3_0_i64);
	update_prof_current_proc(LABEL(mercury__vn_verify__tags_2_3_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_verify__tags_2_3_0_i1);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	MR_succip = (Code *) MR_stackvar(9);
	GOTO_LABEL(mercury__vn_verify__tags_2_3_0_i1026);
Define_label(mercury__vn_verify__tags_2_3_0_i67);
	r1 = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(9);
	GOTO_LABEL(mercury__vn_verify__tags_2_3_0_i1026);
Define_label(mercury__vn_verify__tags_2_3_0_i68);
	MR_stackvar(3) = MR_const_field(MR_mktag(1), r1, (Integer) 1);
	r1 = (Word) MR_string_const("found c_code in vn_verify__tags_instr", 37);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_verify__tags_2_3_0_i1008,
		STATIC(mercury__vn_verify__tags_2_3_0));
Define_label(mercury__vn_verify__tags_2_3_0_i2);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
Define_label(mercury__vn_verify__tags_2_3_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(9);
	MR_decr_sp_pop_msg(9);
	proceed();
END_MODULE


BEGIN_MODULE(vn_verify_module8)
	init_entry(mercury__vn_verify__tags_lval_2_0);
	init_label(mercury__vn_verify__tags_lval_2_0_i12);
	init_label(mercury__vn_verify__tags_lval_2_0_i27);
	init_label(mercury__vn_verify__tags_lval_2_0_i30);
	init_label(mercury__vn_verify__tags_lval_2_0_i32);
	init_label(mercury__vn_verify__tags_lval_2_0_i34);
	init_label(mercury__vn_verify__tags_lval_2_0_i1007);
	init_label(mercury__vn_verify__tags_lval_2_0_i38);
	init_label(mercury__vn_verify__tags_lval_2_0_i1);
BEGIN_CODE

/* code for predicate 'tags_lval'/2 in mode 0 */
Define_static(mercury__vn_verify__tags_lval_2_0);
	MR_incr_sp_push_msg(4, "vn_verify:tags_lval/2");
	MR_stackvar(4) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__vn_verify__tags_lval_2_0_i1007) AND
		LABEL(mercury__vn_verify__tags_lval_2_0_i1007) AND
		LABEL(mercury__vn_verify__tags_lval_2_0_i1007) AND
		LABEL(mercury__vn_verify__tags_lval_2_0_i12));
Define_label(mercury__vn_verify__tags_lval_2_0_i12);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__vn_verify__tags_lval_2_0_i1007) AND
		LABEL(mercury__vn_verify__tags_lval_2_0_i1007) AND
		LABEL(mercury__vn_verify__tags_lval_2_0_i27) AND
		LABEL(mercury__vn_verify__tags_lval_2_0_i27) AND
		LABEL(mercury__vn_verify__tags_lval_2_0_i27) AND
		LABEL(mercury__vn_verify__tags_lval_2_0_i27) AND
		LABEL(mercury__vn_verify__tags_lval_2_0_i27) AND
		LABEL(mercury__vn_verify__tags_lval_2_0_i30) AND
		LABEL(mercury__vn_verify__tags_lval_2_0_i1) AND
		LABEL(mercury__vn_verify__tags_lval_2_0_i38));
Define_label(mercury__vn_verify__tags_lval_2_0_i27);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__vn_verify__tags_rval_2_0),
		STATIC(mercury__vn_verify__tags_lval_2_0));
Define_label(mercury__vn_verify__tags_lval_2_0_i30);
	r3 = r2;
	MR_stackvar(1) = r2;
	r2 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(2) = r2;
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_rval_0;
	call_localret(ENTRY(mercury__set__member_2_0),
		mercury__vn_verify__tags_lval_2_0_i32,
		STATIC(mercury__vn_verify__tags_lval_2_0));
Define_label(mercury__vn_verify__tags_lval_2_0_i32);
	update_prof_current_proc(LABEL(mercury__vn_verify__tags_lval_2_0));
	if (r1)
		GOTO_LABEL(mercury__vn_verify__tags_lval_2_0_i1);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(1);
	call_localret(STATIC(mercury__vn_verify__tags_rval_2_0),
		mercury__vn_verify__tags_lval_2_0_i34,
		STATIC(mercury__vn_verify__tags_lval_2_0));
Define_label(mercury__vn_verify__tags_lval_2_0_i34);
	update_prof_current_proc(LABEL(mercury__vn_verify__tags_lval_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_verify__tags_lval_2_0_i1);
	r1 = MR_stackvar(3);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	tailcall(STATIC(mercury__vn_verify__tags_rval_2_0),
		STATIC(mercury__vn_verify__tags_lval_2_0));
Define_label(mercury__vn_verify__tags_lval_2_0_i1007);
	update_prof_current_proc(LABEL(mercury__vn_verify__tags_lval_2_0));
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__vn_verify__tags_lval_2_0_i38);
	r1 = (Word) MR_string_const("found lvar in vn_verify__tags_lval", 34);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_verify__tags_lval_2_0_i1007,
		STATIC(mercury__vn_verify__tags_lval_2_0));
Define_label(mercury__vn_verify__tags_lval_2_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE


BEGIN_MODULE(vn_verify_module9)
	init_entry(mercury__vn_verify__tags_rval_2_0);
	init_label(mercury__vn_verify__tags_rval_2_0_i4);
	init_label(mercury__vn_verify__tags_rval_2_0_i7);
	init_label(mercury__vn_verify__tags_rval_2_0_i10);
	init_label(mercury__vn_verify__tags_rval_2_0_i15);
	init_label(mercury__vn_verify__tags_rval_2_0_i18);
	init_label(mercury__vn_verify__tags_rval_2_0_i19);
	init_label(mercury__vn_verify__tags_rval_2_0_i1004);
	init_label(mercury__vn_verify__tags_rval_2_0_i1);
BEGIN_CODE

/* code for predicate 'tags_rval'/2 in mode 0 */
Define_static(mercury__vn_verify__tags_rval_2_0);
	MR_incr_sp_push_msg(3, "vn_verify:tags_rval/2");
	MR_stackvar(3) = (Word) MR_succip;
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__vn_verify__tags_rval_2_0_i4) AND
		LABEL(mercury__vn_verify__tags_rval_2_0_i7) AND
		LABEL(mercury__vn_verify__tags_rval_2_0_i1004) AND
		LABEL(mercury__vn_verify__tags_rval_2_0_i10));
Define_label(mercury__vn_verify__tags_rval_2_0_i4);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	tailcall(STATIC(mercury__vn_verify__tags_lval_2_0),
		STATIC(mercury__vn_verify__tags_rval_2_0));
Define_label(mercury__vn_verify__tags_rval_2_0_i7);
	r1 = (Word) MR_string_const("found var in vn_verify__tags_rval", 33);
	call_localret(ENTRY(mercury__require__error_1_0),
		mercury__vn_verify__tags_rval_2_0_i1004,
		STATIC(mercury__vn_verify__tags_rval_2_0));
Define_label(mercury__vn_verify__tags_rval_2_0_i10);
	COMPUTED_GOTO((Unsigned) MR_const_field(MR_mktag(3), r1, (Integer) 0),
		LABEL(mercury__vn_verify__tags_rval_2_0_i15) AND
		LABEL(mercury__vn_verify__tags_rval_2_0_i1004) AND
		LABEL(mercury__vn_verify__tags_rval_2_0_i15) AND
		LABEL(mercury__vn_verify__tags_rval_2_0_i18) AND
		LABEL(mercury__vn_verify__tags_rval_2_0_i1));
Define_label(mercury__vn_verify__tags_rval_2_0_i15);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_succip = (Code *) MR_stackvar(3);
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__vn_verify__tags_rval_2_0_i4) AND
		LABEL(mercury__vn_verify__tags_rval_2_0_i7) AND
		LABEL(mercury__vn_verify__tags_rval_2_0_i1004) AND
		LABEL(mercury__vn_verify__tags_rval_2_0_i10));
Define_label(mercury__vn_verify__tags_rval_2_0_i18);
	MR_stackvar(2) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(1) = r2;
	localcall(mercury__vn_verify__tags_rval_2_0,
		LABEL(mercury__vn_verify__tags_rval_2_0_i19),
		STATIC(mercury__vn_verify__tags_rval_2_0));
Define_label(mercury__vn_verify__tags_rval_2_0_i19);
	update_prof_current_proc(LABEL(mercury__vn_verify__tags_rval_2_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_verify__tags_rval_2_0_i1);
	r1 = MR_stackvar(2);
	r2 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(3);
	COMPUTED_GOTO((Unsigned) MR_tag(r1),
		LABEL(mercury__vn_verify__tags_rval_2_0_i4) AND
		LABEL(mercury__vn_verify__tags_rval_2_0_i7) AND
		LABEL(mercury__vn_verify__tags_rval_2_0_i1004) AND
		LABEL(mercury__vn_verify__tags_rval_2_0_i10));
Define_label(mercury__vn_verify__tags_rval_2_0_i1004);
	update_prof_current_proc(LABEL(mercury__vn_verify__tags_rval_2_0));
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
Define_label(mercury__vn_verify__tags_rval_2_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(3);
	MR_decr_sp_pop_msg(3);
	proceed();
END_MODULE


BEGIN_MODULE(vn_verify_module10)
	init_entry(mercury__vn_verify__tags_cond_5_0);
	init_label(mercury__vn_verify__tags_cond_5_0_i1020);
	init_label(mercury__vn_verify__tags_cond_5_0_i6);
	init_label(mercury__vn_verify__tags_cond_5_0_i10);
	init_label(mercury__vn_verify__tags_cond_5_0_i5);
	init_label(mercury__vn_verify__tags_cond_5_0_i11);
	init_label(mercury__vn_verify__tags_cond_5_0_i13);
	init_label(mercury__vn_verify__tags_cond_5_0_i16);
	init_label(mercury__vn_verify__tags_cond_5_0_i15);
	init_label(mercury__vn_verify__tags_cond_5_0_i19);
	init_label(mercury__vn_verify__tags_cond_5_0_i14);
	init_label(mercury__vn_verify__tags_cond_5_0_i20);
	init_label(mercury__vn_verify__tags_cond_5_0_i2);
	init_label(mercury__vn_verify__tags_cond_5_0_i26);
	init_label(mercury__vn_verify__tags_cond_5_0_i28);
	init_label(mercury__vn_verify__tags_cond_5_0_i23);
	init_label(mercury__vn_verify__tags_cond_5_0_i32);
	init_label(mercury__vn_verify__tags_cond_5_0_i39);
	init_label(mercury__vn_verify__tags_cond_5_0_i41);
	init_label(mercury__vn_verify__tags_cond_5_0_i37);
	init_label(mercury__vn_verify__tags_cond_5_0_i42);
	init_label(mercury__vn_verify__tags_cond_5_0_i1);
BEGIN_CODE

/* code for predicate 'tags_cond'/5 in mode 0 */
Define_static(mercury__vn_verify__tags_cond_5_0);
	MR_incr_sp_push_msg(4, "vn_verify:tags_cond/5");
	MR_stackvar(4) = (Word) MR_succip;
Define_label(mercury__vn_verify__tags_cond_5_0_i1020);
	if ((MR_tag(r1) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__vn_verify__tags_cond_5_0_i2);
	if (((Integer) MR_const_field(MR_mktag(3), r1, (Integer) 0) != (Integer) 3))
		GOTO_LABEL(mercury__vn_verify__tags_cond_5_0_i2);
	r4 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	if (((Unsigned)(((Integer) r4 - (Integer) 12)) > (Integer) 12))
		GOTO_LABEL(mercury__vn_verify__tags_cond_5_0_i2);
	if (!((((Integer) 1 << (Unsigned)(((Integer) r4 - (Integer) 12))) & (Integer) 7683)))
		GOTO_LABEL(mercury__vn_verify__tags_cond_5_0_i2);
	MR_stackvar(3) = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	{
	Word MR_tempr1;
	MR_tempr1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_stackvar(2) = r3;
	r3 = MR_tempr1;
	if ((MR_tag(MR_tempr1) == MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__vn_verify__tags_cond_5_0_i6);
	if ((MR_tag(r3) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__vn_verify__tags_cond_5_0_i5);
	if (((Integer) MR_const_field(MR_mktag(3), r3, (Integer) 0) != (Integer) 2))
		GOTO_LABEL(mercury__vn_verify__tags_cond_5_0_i5);
	r1 = MR_const_field(MR_mktag(3), r3, (Integer) 1);
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__vn_verify__tags_cond_5_0_i5);
	r3 = MR_const_field(MR_mktag(3), r3, (Integer) 2);
	}
Define_label(mercury__vn_verify__tags_cond_5_0_i6);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_rval_0;
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__vn_verify__tags_cond_5_0_i10,
		STATIC(mercury__vn_verify__tags_cond_5_0));
Define_label(mercury__vn_verify__tags_cond_5_0_i10);
	update_prof_current_proc(LABEL(mercury__vn_verify__tags_cond_5_0));
	r3 = MR_stackvar(3);
	r2 = r1;
	GOTO_LABEL(mercury__vn_verify__tags_cond_5_0_i13);
Define_label(mercury__vn_verify__tags_cond_5_0_i5);
	MR_stackvar(1) = r2;
	r1 = r3;
	call_localret(STATIC(mercury__vn_verify__tags_rval_2_0),
		mercury__vn_verify__tags_cond_5_0_i11,
		STATIC(mercury__vn_verify__tags_cond_5_0));
Define_label(mercury__vn_verify__tags_cond_5_0_i11);
	update_prof_current_proc(LABEL(mercury__vn_verify__tags_cond_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_verify__tags_cond_5_0_i1);
	r3 = MR_stackvar(3);
	r2 = MR_stackvar(1);
Define_label(mercury__vn_verify__tags_cond_5_0_i13);
	if ((MR_tag(r3) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__vn_verify__tags_cond_5_0_i16);
	MR_stackvar(3) = r3;
	GOTO_LABEL(mercury__vn_verify__tags_cond_5_0_i15);
Define_label(mercury__vn_verify__tags_cond_5_0_i16);
	if ((MR_tag(r3) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__vn_verify__tags_cond_5_0_i14);
	if (((Integer) MR_const_field(MR_mktag(3), r3, (Integer) 0) != (Integer) 2))
		GOTO_LABEL(mercury__vn_verify__tags_cond_5_0_i14);
	r1 = MR_const_field(MR_mktag(3), r3, (Integer) 1);
	if (((Integer) r1 != (Integer) 1))
		GOTO_LABEL(mercury__vn_verify__tags_cond_5_0_i14);
	MR_stackvar(3) = r3;
	r3 = MR_const_field(MR_mktag(3), r3, (Integer) 2);
Define_label(mercury__vn_verify__tags_cond_5_0_i15);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_rval_0;
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__vn_verify__tags_cond_5_0_i19,
		STATIC(mercury__vn_verify__tags_cond_5_0));
Define_label(mercury__vn_verify__tags_cond_5_0_i19);
	update_prof_current_proc(LABEL(mercury__vn_verify__tags_cond_5_0));
	r2 = r1;
	r3 = MR_stackvar(2);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__vn_verify__tags_cond_5_0_i14);
	MR_stackvar(1) = r2;
	r1 = r3;
	call_localret(STATIC(mercury__vn_verify__tags_rval_2_0),
		mercury__vn_verify__tags_cond_5_0_i20,
		STATIC(mercury__vn_verify__tags_cond_5_0));
Define_label(mercury__vn_verify__tags_cond_5_0_i20);
	update_prof_current_proc(LABEL(mercury__vn_verify__tags_cond_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_verify__tags_cond_5_0_i1);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__vn_verify__tags_cond_5_0_i2);
	if ((MR_tag(r1) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__vn_verify__tags_cond_5_0_i23);
	if (((Integer) MR_const_field(MR_mktag(3), r1, (Integer) 0) != (Integer) 3))
		GOTO_LABEL(mercury__vn_verify__tags_cond_5_0_i23);
	r4 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	if (((Integer) r4 != (Integer) 10))
		GOTO_LABEL(mercury__vn_verify__tags_cond_5_0_i26);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	localcall(mercury__vn_verify__tags_cond_5_0,
		LABEL(mercury__vn_verify__tags_cond_5_0_i28),
		STATIC(mercury__vn_verify__tags_cond_5_0));
Define_label(mercury__vn_verify__tags_cond_5_0_i26);
	if (((Integer) r4 != (Integer) 11))
		GOTO_LABEL(mercury__vn_verify__tags_cond_5_0_i23);
	MR_stackvar(1) = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 3);
	localcall(mercury__vn_verify__tags_cond_5_0,
		LABEL(mercury__vn_verify__tags_cond_5_0_i28),
		STATIC(mercury__vn_verify__tags_cond_5_0));
Define_label(mercury__vn_verify__tags_cond_5_0_i28);
	update_prof_current_proc(LABEL(mercury__vn_verify__tags_cond_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_verify__tags_cond_5_0_i1);
	r1 = MR_stackvar(1);
	MR_succip = (Code *) MR_stackvar(4);
	GOTO_LABEL(mercury__vn_verify__tags_cond_5_0_i1020);
Define_label(mercury__vn_verify__tags_cond_5_0_i23);
	if ((MR_tag(r1) != MR_mktag((Integer) 3)))
		GOTO_LABEL(mercury__vn_verify__tags_cond_5_0_i32);
	if (((Integer) MR_const_field(MR_mktag(3), r1, (Integer) 0) != (Integer) 2))
		GOTO_LABEL(mercury__vn_verify__tags_cond_5_0_i32);
	r4 = MR_const_field(MR_mktag(3), r1, (Integer) 1);
	if (((Integer) r4 != (Integer) 9))
		GOTO_LABEL(mercury__vn_verify__tags_cond_5_0_i32);
	r1 = MR_const_field(MR_mktag(3), r1, (Integer) 2);
	MR_succip = (Code *) MR_stackvar(4);
	GOTO_LABEL(mercury__vn_verify__tags_cond_5_0_i1020);
Define_label(mercury__vn_verify__tags_cond_5_0_i32);
	if ((MR_tag(r1) != MR_mktag((Integer) 0)))
		GOTO_LABEL(mercury__vn_verify__tags_cond_5_0_i37);
	r1 = MR_const_field(MR_mktag(0), r1, (Integer) 0);
	MR_stackvar(3) = r1;
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	call_localret(STATIC(mercury__vn_verify__tags_lval_2_0),
		mercury__vn_verify__tags_cond_5_0_i39,
		STATIC(mercury__vn_verify__tags_cond_5_0));
Define_label(mercury__vn_verify__tags_cond_5_0_i39);
	update_prof_current_proc(LABEL(mercury__vn_verify__tags_cond_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_verify__tags_cond_5_0_i1);
	r1 = (Word) (Word *) &mercury_data_llds__type_ctor_info_lval_0;
	r2 = MR_stackvar(2);
	r3 = MR_stackvar(3);
	call_localret(ENTRY(mercury__set__insert_3_1),
		mercury__vn_verify__tags_cond_5_0_i41,
		STATIC(mercury__vn_verify__tags_cond_5_0));
Define_label(mercury__vn_verify__tags_cond_5_0_i41);
	update_prof_current_proc(LABEL(mercury__vn_verify__tags_cond_5_0));
	r2 = MR_stackvar(1);
	r3 = r1;
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__vn_verify__tags_cond_5_0_i37);
	MR_stackvar(1) = r2;
	MR_stackvar(2) = r3;
	call_localret(STATIC(mercury__vn_verify__tags_rval_2_0),
		mercury__vn_verify__tags_cond_5_0_i42,
		STATIC(mercury__vn_verify__tags_cond_5_0));
Define_label(mercury__vn_verify__tags_cond_5_0_i42);
	update_prof_current_proc(LABEL(mercury__vn_verify__tags_cond_5_0));
	if (!(r1))
		GOTO_LABEL(mercury__vn_verify__tags_cond_5_0_i1);
	r2 = MR_stackvar(1);
	r3 = MR_stackvar(2);
	r1 = TRUE;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
Define_label(mercury__vn_verify__tags_cond_5_0_i1);
	r1 = FALSE;
	MR_succip = (Code *) MR_stackvar(4);
	MR_decr_sp_pop_msg(4);
	proceed();
END_MODULE

#ifdef MR_MAY_NEED_INITIALIZATION

static void mercury__vn_verify_maybe_bunch_0(void)
{
	vn_verify_module0();
	vn_verify_module1();
	vn_verify_module2();
	vn_verify_module3();
	vn_verify_module4();
	vn_verify_module5();
	vn_verify_module6();
	vn_verify_module7();
	vn_verify_module8();
	vn_verify_module9();
	vn_verify_module10();
}

#endif

void mercury__vn_verify__init(void);/* suppress gcc -Wmissing-decls warning */
void mercury__vn_verify__init(void)
{
	static bool done = FALSE;
	if (!done) {
		done = TRUE;

#ifdef MR_MAY_NEED_INITIALIZATION
		mercury__vn_verify_maybe_bunch_0();
#endif

	}
}

/* ensure everything is compiled with the same grade */
static const void *const MR_grade = &MR_GRADE_VAR;
