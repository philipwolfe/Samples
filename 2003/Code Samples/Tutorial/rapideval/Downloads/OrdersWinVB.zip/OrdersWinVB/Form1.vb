Public Class Form1
    Inherits System.Windows.Forms.Form

    ' TODO: Change this to the location of the downloaded XML data file on your machine
    Private Const XmlFileName As String = "C:\VSRapidEval\CustOrder.xml"

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents ErrorProvider1 As System.Windows.Forms.ErrorProvider
    Friend WithEvents dgOrders As System.Windows.Forms.DataGrid
    Friend WithEvents cboCustomers As System.Windows.Forms.ComboBox
    Friend WithEvents dtpStartDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtpEndDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents btnShow As System.Windows.Forms.Button
    Friend WithEvents btnUpdate As System.Windows.Forms.Button
    Friend WithEvents DsCustOrder1 As OrdersWinVB.dsCustOrder
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.dgOrders = New System.Windows.Forms.DataGrid
        Me.cboCustomers = New System.Windows.Forms.ComboBox
        Me.DsCustOrder1 = New OrdersWinVB.dsCustOrder
        Me.dtpStartDate = New System.Windows.Forms.DateTimePicker
        Me.dtpEndDate = New System.Windows.Forms.DateTimePicker
        Me.btnShow = New System.Windows.Forms.Button
        Me.ErrorProvider1 = New System.Windows.Forms.ErrorProvider
        Me.btnUpdate = New System.Windows.Forms.Button
        CType(Me.dgOrders, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DsCustOrder1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(16, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(100, 16)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Choose Customer"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(312, 16)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(100, 16)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Choose Start Date"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(456, 16)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(100, 16)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Choose End Date"
        '
        'dgOrders
        '
        Me.dgOrders.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.dgOrders.DataMember = ""
        Me.dgOrders.HeaderForeColor = System.Drawing.SystemColors.ControlText
        Me.dgOrders.Location = New System.Drawing.Point(16, 112)
        Me.dgOrders.Name = "dgOrders"
        Me.dgOrders.Size = New System.Drawing.Size(680, 280)
        Me.dgOrders.TabIndex = 8
        '
        'cboCustomers
        '
        Me.cboCustomers.DataSource = Me.DsCustOrder1.Customers
        Me.cboCustomers.DisplayMember = "CompanyName"
        Me.cboCustomers.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboCustomers.Location = New System.Drawing.Point(16, 32)
        Me.cboCustomers.Name = "cboCustomers"
        Me.cboCustomers.Size = New System.Drawing.Size(264, 21)
        Me.cboCustomers.TabIndex = 1
        Me.cboCustomers.ValueMember = "CustomerID"
        '
        'DsCustOrder1
        '
        Me.DsCustOrder1.DataSetName = "dsCustOrder"
        Me.DsCustOrder1.Locale = New System.Globalization.CultureInfo("en-US")
        '
        'dtpStartDate
        '
        Me.dtpStartDate.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtpStartDate.Location = New System.Drawing.Point(312, 32)
        Me.dtpStartDate.Name = "dtpStartDate"
        Me.dtpStartDate.Size = New System.Drawing.Size(112, 20)
        Me.dtpStartDate.TabIndex = 3
        Me.dtpStartDate.Value = New Date(2000, 1, 1, 0, 0, 0, 0)
        '
        'dtpEndDate
        '
        Me.dtpEndDate.Format = System.Windows.Forms.DateTimePickerFormat.Short
        Me.dtpEndDate.Location = New System.Drawing.Point(456, 32)
        Me.dtpEndDate.Name = "dtpEndDate"
        Me.dtpEndDate.Size = New System.Drawing.Size(112, 20)
        Me.dtpEndDate.TabIndex = 5
        Me.dtpEndDate.Value = New Date(2002, 12, 31, 0, 0, 0, 0)
        '
        'btnShow
        '
        Me.btnShow.Location = New System.Drawing.Point(600, 29)
        Me.btnShow.Name = "btnShow"
        Me.btnShow.Size = New System.Drawing.Size(96, 23)
        Me.btnShow.TabIndex = 6
        Me.btnShow.Text = "Show Orders"
        '
        'ErrorProvider1
        '
        Me.ErrorProvider1.ContainerControl = Me
        '
        'btnUpdate
        '
        Me.btnUpdate.Location = New System.Drawing.Point(600, 72)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(96, 23)
        Me.btnUpdate.TabIndex = 7
        Me.btnUpdate.Text = "Update Orders"
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(712, 405)
        Me.Controls.Add(Me.btnUpdate)
        Me.Controls.Add(Me.btnShow)
        Me.Controls.Add(Me.dtpEndDate)
        Me.Controls.Add(Me.dtpStartDate)
        Me.Controls.Add(Me.cboCustomers)
        Me.Controls.Add(Me.dgOrders)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Customer Orders"
        CType(Me.dgOrders, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DsCustOrder1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        ' Load XML data file into DataSet
        DsCustOrder1.ReadXml(XmlFileName)

    End Sub

    Private Sub btnShow_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnShow.Click

        Dim tableFilter As New System.Text.StringBuilder()

        ' Configure row filter to show orders for the selected Customer during the specified date range 
        tableFilter.Append("CustomerID='")
	tableFilter.Append(cboCustomers.SelectedValue.ToString)
	tableFilter.Append("' AND OrderDate >='")
	tableFilter.Append(dtpStartDate.Value.ToShortDateString)
	tableFilter.Append("' AND OrderDate <='")
	tableFilter.Append(dtpEndDate.Value.ToShortDateString)
	tableFilter.Append("'")

        ' Set filter and display filtered view of data in the datagrid
        Dim dvOrders As DataView = DsCustOrder1.Orders.DefaultView
        dvOrders.RowFilter = tableFilter.ToString
        dgOrders.DataSource = dvOrders

    End Sub

    Private Sub DateTimePicker1_Validating(ByVal sender As System.Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles dtpStartDate.Validating

        ' Ensure Start Date is less than 1/1/2001
        If dtpStartDate.Value.CompareTo(New System.DateTime(2001, 1, 1)) < 0 Then
            ' Date is valid
            ErrorProvider1.SetError(dtpStartDate, "")
        Else
            ' Date not valid, inform the user
            ErrorProvider1.SetError(dtpStartDate, "Start Date must be prior to 1/1/2001")
            e.Cancel = True
        End If

    End Sub

    Private Sub btnUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdate.Click

        ' Persist changes made in the datagrid by writing out the results back into the XML data file
        DsCustOrder1.AcceptChanges()
        DsCustOrder1.WriteXml(XmlFileName)

    End Sub
End Class
