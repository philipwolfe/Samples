//==============================================================================
// MyGeneration.dOOdads
//
// DynamicQuery.cs
// Version 3.5
// Updated - 08/29/2004
//------------------------------------------------------------------------------
// Copyright 2004 by MyGeneration Software
// All Rights Reserved 
//
// Permission to use, copy, modify, and distribute this software and its 
// documentation for any purpose and without fee is hereby granted, 
// provided that the above copyright notice appear in all copies and that 
// both that copyright notice and this permission notice appear in 
// supporting documentation. 
//
// MYGENERATION SOFTWARE DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS 
// SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY 
// AND FITNESS, IN NO EVENT SHALL MYGENERATION SOFTWARE BE LIABLE FOR ANY 
// SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES 
// WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, 
// WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER 
// TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE 
// OR PERFORMANCE OF THIS SOFTWARE. 
//==============================================================================

using System;
using System.Configuration;
using System.Data;
using System.Data.Common;
using System.Collections;
using System.Globalization;
using Microsoft.Practices.EnterpriseLibrary.Common;
using Microsoft.Practices.EnterpriseLibrary.Configuration;
using Microsoft.Practices.EnterpriseLibrary.Data;

using NCI.EasyObjects.Configuration;
using NCI.EasyObjects.DynamicQueryProvider;

namespace NCI.EasyObjects
{
	/// <summary>
	/// DynamicQuery allows you to (without writing any stored procedures) query your database on the fly. All selection criteria are passed in
	/// via Parameters (SqlParameter, OleDbParameter) in order to prevent sql injection tecniques often attempted by hackers.  
	/// </summary>
	public abstract class DynamicQuery : ConfigurationProvider
	{
		private DynamicQueryConfigurationView dynamicQueryConfigurationView;
		
		/// <summary>
		/// Used by derived classes
		/// </summary>
		protected bool _distinct = false;
		/// <summary>
		/// Used by derived classes
		/// </summary>
		protected int _topN = -1;
		/// <summary>
		/// Used by derived classes
		/// </summary>
		protected ArrayList _whereParameters = null;
		/// <summary>
		/// Used by derived classes
		/// </summary>
		protected string _resultColumns = string.Empty;
		/// <summary>
		/// Used by derived classes
		/// </summary>
		protected string _orderBy = string.Empty;

		/// <summary>
		/// Used by derived classes
		/// </summary>
		protected EasyObject _entity;
		protected int inc = 0;

		private string _lastQuery = string.Empty;

		public DynamicQuery()
		{}

		public DynamicQuery(EasyObject entity)
		{
			this._entity = entity;
		}

		/// <summary>
		/// <para>Initializes a new instance of the <see cref="Database"/> class with the specified <see cref="DatabaseProviderData"/> and <see cref="ConfigurationContext"/>.</para>
		/// </summary>
		/// <param name="configurationView">A <see cref="ConfigurationView"/> that should be of type <see cref="DatabaseConfigurationView"/>.</param>
		public override void Initialize(ConfigurationView configurationView)
		{
			ArgumentValidation.CheckForNullReference(configurationView, "configurationView");
			ArgumentValidation.CheckExpectedType(configurationView, typeof(DynamicQueryConfigurationView));

			this.dynamicQueryConfigurationView = (DynamicQueryConfigurationView)configurationView;
			//instrumentation = new DataInstrumentationFacade();
		}

		/// <summary>
		/// <para>When implemented by a class, gets the parameter token used to delimit parameters for the database.</para>
		/// </summary>
		/// <value>
		/// <para>the parameter token used to delimit parameters for the database.</para>
		/// </value>
		protected abstract char ParameterToken { get; }

		/// <summary>
		/// <para>When implemented by a class, gets the string format used to delimit fieldnames for the database.</para>
		/// </summary>
		/// <value>
		/// <para>the string format used to delimit fieldnames for the database.</para>
		/// </value>
		/// <example>
		/// <code>
		/// // SQL Server delimits fieldnames with square brackets []
		/// protected override char ParameterToken
		/// {
		///		get { return "[{0}]"; }
		/// }
		/// </code>
		/// </example>
		protected virtual string FieldFormat { get { return "{0}"; } }

		/// <summary>
		/// Gets the <see cref="DatabaseTypeData"/> from which
		/// this object was initialized.
		/// </summary>
		/// <value>A <see cref="DatabaseProviderData"/>.</value>
		protected DatabaseTypeData DynamicQueryProviderData
		{
			get { return dynamicQueryConfigurationView.GetDatabaseTypeData(ConfigurationName); }
		}

		protected abstract void BuildQuery(DBCommandWrapper dbCommandWrapper, string conjuction);

		public EasyObject Entity
		{
			get { return _entity; }
			set { _entity = value; }
		}

		public bool Distinct
		{
			get { return _distinct; }
			set { _distinct = value; }
		}

		public int TopN
		{
			get { return _topN; }
			set { _topN = value; }
		}

		protected string ResultColumns
		{
			get { return _resultColumns; }
			set { _resultColumns = value; }
		}

		protected string OrderBy
		{
			get { return _orderBy; }
			set { _orderBy = value; }
		}

		/// <summary>
		/// Execute the Query and loads your BusinessEntity. The default conjuction between the WHERE parameters is "AND"
		/// </summary>
		/// <returns>True if at least one record was loaded</returns>
		public bool Load()
		{
			return Load("AND");
		}

		/// <summary>
		/// Execute the Query and loads your BusinessEntity. 
		/// You can pass in the conjustion that will be used between the WHERE parameters, either, "AND" or "OR". "AND" is the default.
		/// </summary>
		/// <returns>True if at least one record was loaded</returns>
		public bool Load(string conjuction)
		{
			bool loaded  = false;
			DataSet ds = null;

			ArgumentValidation.CheckForNullReference(_entity, "EasyObject");

			// Create the Database object, using the default database service. The
			// default database service is determined through configuration.
			Database db = _entity.GetDatabase();

			DBCommandWrapper dbCommandWrapper = db.GetSqlStringCommandWrapper("NULL");

			try
			{
				BuildQuery(dbCommandWrapper, conjuction);
				_lastQuery = dbCommandWrapper.Command.CommandText;

				TransactionManager txMgr = TransactionManager.ThreadTransactionMgr();

				ds = new DataSet(_entity.TableName + "DataSet");

				IDbTransaction tx = txMgr.GetTransaction(db);
				if (tx == null)
				{
					ds = db.ExecuteDataSet(dbCommandWrapper);
				}
				else 
				{
					ds = db.ExecuteDataSet(dbCommandWrapper, tx);
				}

			}
			catch(Exception ex)
			{
				throw ex;
			}
			finally
			{
				this._entity.Load(ds);
				loaded = (this._entity.RowCount > 0);
			}

			return loaded;
		}

		/// <summary>
		/// The default result set for Query.Load is all of the columns in your Table or View. Once you call AddResultColumn this changes to only
		/// the columns you have added via this method. For instance, if you call AddResultColumn twice then only two columns will be returned
		/// in your result set. 
		/// </summary>
		/// <param name="columnName">This should be an entry from your ColumnNames class.</param>
		public virtual void AddResultColumn(SchemaItem item)
		{
			if(_resultColumns.Length > 0)
			{
				_resultColumns += ",";
			}

			_resultColumns += item.FieldName;
		}

		/// <summary>
		/// Calling this will set the result columns back to "all".
		/// </summary>
		public void ResultColumnsClear()
		{
			_resultColumns = string.Empty;
		}
	
		/// <summary>
		/// NOTE: This is called by the dOOdad framework and you should never call it. We reserve the right to remove or change this method.
		/// </summary>
		/// <param name="wItem">The WhereParameter</param>
		public void AddWhereParameter(WhereParameter param)
		{
			if(_whereParameters == null)
			{
				_whereParameters = new ArrayList();
			}

			_whereParameters.Add(param);
		}
	
		/// <summary>
		/// NOTE: This is called by the dOOdad framework and you should never call it. We reserve the right to remove or change this method.
		/// </summary>
		public void FlushWhereParameters()
		{
			if( _whereParameters != null)
			{
				_whereParameters.Clear();
			}

			_orderBy = string.Empty;
		}

		/// <summary>
		/// Use this to have your Query order the data. If you want to order the data by two columns you will need to call this method twice.
		/// </summary>
		/// <param name="column">This should be an entry from your ColumnNames class</param>
		/// <param name="direction">Either Descending or Ascending</param>
		/// <example>
		/// <code>
		/// emps.Query.AddOrderBy(EmployeesSchema.LastName, WhereParameter.Dir.ASC)</code>
		/// </example>
		public virtual void AddOrderBy(SchemaItem item, WhereParameter.Dir direction)
		{
			if( _orderBy.Length > 0)
			{
				_orderBy += ", ";
			}

			_orderBy += item.FieldName;

			if(direction == WhereParameter.Dir.ASC)
				_orderBy += " ASC";
			else
				_orderBy += " DESC";
		}

		/// <summary>
		/// Use this to have your Query order the data. If you want to order the data by two columns you will need to call this method twice.
		/// </summary>
		/// <param name="column">This should be an entry from your ColumnNames class</param>
		/// <example>
		/// <code>
		/// emps.Query.AddOrderBy(EmployeesSchema.LastName)</code>
		/// </example>
		public virtual void AddOrderBy(SchemaItem item)
		{
			AddOrderBy(item, WhereParameter.Dir.ASC);
		}
	
		/// <summary>
		/// A Query has a default conjuction between WHERE parameters, this method lets you intermix those and alternate between AND/OR.
		/// </summary>
		/// <param name="conjuction"></param>
		public void AddConjunction(WhereParameter.Conj conjuction)
		{
			if(_whereParameters == null) 
			{
				_whereParameters = new ArrayList();
			}

			if(conjuction != WhereParameter.Conj.UseDefault)
			{
				if(conjuction == WhereParameter.Conj.And)
					_whereParameters.Add(" AND ");
				else
					_whereParameters.Add(" OR ");
			}
		}
	
		/// <summary>
		/// Used for advanced queries
		/// </summary>
		public void OpenParenthesis()
		{
			if(_whereParameters == null)
			{
				_whereParameters = new ArrayList();
			}

			_whereParameters.Add("(");
		}

		/// <summary>
		/// Used for advanced queries
		/// </summary>
		public void CloseParenthesis()
		{
			if(_whereParameters == null)
			{
				_whereParameters = new ArrayList();
			}

			_whereParameters.Add(")");
		}
	}
}

