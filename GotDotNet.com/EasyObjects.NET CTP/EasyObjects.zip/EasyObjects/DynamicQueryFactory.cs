using System;
using Microsoft.Practices.EnterpriseLibrary.Configuration;

namespace NCI.EasyObjects
{
	/// <summary>
	/// Contains factory methods for creating DynamicQuery objects
	/// </summary>
	public class DynamicQueryFactory
	{
		public DynamicQueryFactory()
		{
		}

		/// <summary>
		/// Method for invoking a default Database object.  Reads default settings
		/// from the ConnectionSettings.config file.
		/// </summary>
		/// <example>
		/// <code>
		/// Database dbSvc = DatabaseFactory.CreateDatabase();
		/// </code>
		/// </example>
		/// <returns>Database</returns>
		/// <exception cref="System.Configuration.ConfigurationException">
		/// <para>A error occured while reading the configuration.</para>
		/// </exception>
		public static DynamicQuery CreateDynamicQuery(EasyObject entity)
		{
			ConfigurationContext context = ConfigurationManager.GetCurrentContext();
			DynamicQueryProviderFactory factory = new DynamicQueryProviderFactory(context);
			
			DynamicQuery query = factory.CreateDefaultDynamicQuery();
			query.Entity = entity;

			return query;
		}

		/// <summary>
		/// Method for invoking a specified Database service object.  Reads service settings
		/// from the ConnectionSettings.config file.
		/// </summary>
		/// <example>
		/// <code>
		/// Database dbSvc = DatabaseFactory.CreateDatabase("SQL_Customers");
		/// </code>
		/// </example>
		/// <param name="instanceName">configuration key for database service</param>
		/// <returns>Database</returns>
		/// <exception cref="System.Configuration.ConfigurationException">
		/// <para><paramref name="instanceName"/> is not defined in configuration.</para>
		/// <para>- or -</para>
		/// <para>An error exists in the configuration.</para>
		/// <para>- or -</para>
		/// <para>A error occured while reading the configuration.</para>        
		/// </exception>
		/// <exception cref="System.Reflection.TargetInvocationException">
		/// <para>The constructor being called throws an exception.</para>
		/// </exception>
		public static DynamicQuery CreateDynamicQuery(EasyObject entity, string instanceName)
		{
			ConfigurationContext context = ConfigurationManager.GetCurrentContext();
			DynamicQueryProviderFactory factory = new DynamicQueryProviderFactory(context);
			
			DynamicQuery query = factory.CreateDynamicQuery(instanceName);
			query.Entity = entity;

			return query;
		}
	}
}
