using System;
using System.Text;
using Microsoft.Practices.EnterpriseLibrary.Data;

namespace NCI.EasyObjects.DynamicQueryProvider
{
	/// <summary>
	/// Summary description for Oracle.
	/// </summary>
	public class OracleDynamicQuery : DynamicQuery
	{
		public OracleDynamicQuery() : base()
		{}

		public OracleDynamicQuery(EasyObject entity) : base(entity)
		{}
	
		/// <summary>
		/// <para>Gets the parameter token used to delimit parameters for the Oracle database.</para>
		/// </summary>
		/// <value>
		/// <para>The ':' symbol.</para>
		/// </value>
		protected override char ParameterToken
		{
			get { return ':'; }
		}
	
		/// <summary>
		/// <para>Gets the string format used to delimit fieldnames for the Sql Database.</para>
		/// </summary>
		/// <value>
		/// <para>'{0}' is the field format string for Oracle.</para>
		/// </value>
		protected override string FieldFormat { get { return "{0}"; } }

		protected override void BuildQuery(DBCommandWrapper dbCommandWrapper, string conjuction)
		{
			StringBuilder query = new StringBuilder("SELECT ");

			if( this.Distinct) query.Append("DISTINCT ");
			if( this.TopN >= 0) query.AppendFormat("TOP {0} ", this.TopN.ToString());

			if(this.ResultColumns.Length > 0)
				query.Append(this.ResultColumns);
			else
				query.Append("*");
	 
			query.Append(" FROM ");
			query.AppendFormat(FieldFormat, this._entity.TableName);

			if(_whereParameters != null && _whereParameters.Count > 0)
			{
				query.Append(" WHERE ");

				bool first = true;

				bool requiresParam;

				WhereParameter wItem;
				bool skipConjuction = false;

				string paramName;
				string columnName;

				foreach(object obj in _whereParameters)
				{
					// Maybe we injected text or a WhereParameter
					if(obj.GetType().ToString() == "System.String")
					{
						string text = obj as string;
						query.Append(text);

						if(text == "(")
						{
							skipConjuction = true;
						}
					}
					else
					{
						wItem = obj as WhereParameter;

						if(wItem.IsDirty)
						{
							if(!first && !skipConjuction)
							{
								if(wItem.Conjuction != WhereParameter.Conj.UseDefault)
								{
									if(wItem.Conjuction == WhereParameter.Conj.And)
										query.Append(" AND ");
									else
										query.Append(" OR ");
								}
								else
								{
									query.Append(" " + conjuction + " ");
								}
							}

							requiresParam = true;

							columnName = string.Format(FieldFormat, wItem.SchemaItem.FieldName);
							paramName = ParameterToken + wItem.SchemaItem.FieldName;

							switch(wItem.Operator)
							{
								case WhereParameter.Operand.Equal:
									query.AppendFormat("{0} = {1} ", columnName, paramName);
									break;
								case WhereParameter.Operand.NotEqual:
									query.AppendFormat("{0} <> {1} ", columnName, paramName);
									break;
								case WhereParameter.Operand.GreaterThan:
									query.AppendFormat("{0} > {1} ", columnName, paramName);
									break;
								case WhereParameter.Operand.LessThan:
									query.AppendFormat("{0} < {1} ", columnName, paramName);
									break;
								case WhereParameter.Operand.LessThanOrEqual:
									query.AppendFormat("{0} <= {1} ", columnName, paramName);
									break;
								case WhereParameter.Operand.GreaterThanOrEqual:
									query.AppendFormat("{0} >= {1} ", columnName, paramName);
									break;
								case WhereParameter.Operand.Like:
									query.AppendFormat("{0} LIKE {1} ", columnName, paramName);
									break;
								case WhereParameter.Operand.NotLike:
									query.AppendFormat("{0} NOT LIKE {1} ", columnName, paramName);
									break;
								case WhereParameter.Operand.IsNull:
									query.AppendFormat("{0} IS NULL ", columnName);
									requiresParam = false;
									break;
								case WhereParameter.Operand.IsNotNull:
									query.AppendFormat("{0} IS NOT NULL ", columnName);
									requiresParam = false;
									break;
								case WhereParameter.Operand.In:
									query.AppendFormat("{0} IN ({1}) ", columnName, wItem.Value);
									requiresParam = false;
									break;
								case WhereParameter.Operand.NotIn:
									query.AppendFormat("{0} NOT IN ({1}) ", columnName, wItem.Value);
									requiresParam = false;
									break;
								case WhereParameter.Operand.Between:
									query.AppendFormat("{0} BETWEEN {1} AND {2}", columnName, paramName + "Begin", paramName + "End");
									dbCommandWrapper.AddInParameter(paramName + "Begin", wItem.SchemaItem.DBType, wItem.BetweenBeginValue.ToString());
									dbCommandWrapper.AddInParameter(paramName + "End", wItem.SchemaItem.DBType, wItem.BetweenEndValue.ToString());
									requiresParam = false;
									break;
							}

							if(requiresParam)
							{
								dbCommandWrapper.AddInParameter(paramName, wItem.SchemaItem.DBType, wItem.Value);
							}

							first = false;
							skipConjuction = false;
						}
					}
				}
			}

			if(this.OrderBy.Length > 0) 
			{
				query.AppendFormat(" ORDER BY {0}", this.OrderBy);
			}

			dbCommandWrapper.Command.CommandText = query.ToString();
		}
	}
}
