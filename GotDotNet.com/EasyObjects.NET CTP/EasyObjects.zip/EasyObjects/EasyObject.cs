using System;
using System.IO;
using System.Data;
using System.Text;
using System.Collections;
using System.Collections.Specialized;
using Microsoft.Practices.EnterpriseLibrary.Data;

namespace NCI.EasyObjects
{
	/// <summary>
	/// Summary description for EasyObject.
	/// </summary>
	public abstract class EasyObject
	{
		static object _dbNull = null;
		bool _isNew = true;
		Int32 _errorCode = 0;
		string _errorMessage = String.Empty;
		DataTable _dataTable = null;
		DataRow _dataRow = null;
		ArrayList _schemaEntries;
		string _databaseInstanceName = string.Empty;
		string _dynamicQueryInstanceName = string.Empty;
		Hashtable _databases = new Hashtable();
		IEnumerator _enumerator = null;
		IDbTransaction _tx = null;
		DynamicQuery _query;
		
		public EasyObject() {}
	    
		public virtual void Load(IDataParameterCollection ps) 
		{
			foreach (IDataParameter param in ps) 
			{
				if (((param.Direction == ParameterDirection.InputOutput) 
					|| (param.Direction == ParameterDirection.Output))) 
				{
					_dataRow[param.ParameterName] = param.Value;
				}
			}
			_dataRow.AcceptChanges();
		}

		public virtual void Load(DataSet ds) 
		{
			DataTable dt = ds.Tables[0];

			//  Remove the table from the dataset
			ds.Tables.Remove(dt);
			
			//  Set internal table and row pointers
			this.DataTable = dt;
			if (dt.Rows.Count > 0) _dataRow = dt.Rows[0];

			_isNew = false;
		}

		private void LoadSchema() 
		{
			DataColumn col;

			_dataTable = new DataTable(this.TableName);

			foreach (SchemaItem item in this.SchemaEntries) 
			{
				col = _dataTable.Columns.Add(item.FieldName);
				col.AutoIncrement = item.AutoIncrement;
				
				//  Set the column datatype
				switch (item.DBType) 
				{
					case DbType.Guid:
						col.DataType = typeof(System.Guid);
						break;
					case DbType.AnsiString:
					case DbType.AnsiStringFixedLength:
					case DbType.String:
					case DbType.StringFixedLength:
						col.DataType = typeof(string);
						break;
					case DbType.Binary:
					case DbType.Byte:
					case DbType.Object:
					case DbType.SByte:
						col.DataType = typeof(byte);
						break;
					case DbType.Boolean:
						col.DataType = typeof(bool);
						break;
					case DbType.Currency:
					case DbType.Decimal:
						col.DataType = typeof(Decimal);
						break;
					case DbType.Date:
					case DbType.DateTime:
					case DbType.Time:
						// TODO: Fix this... 
						// col.DataType = GetType(Date)
						break;
					case DbType.Double:
					case DbType.VarNumeric:
						col.DataType = typeof(double);
						break;
					case DbType.Int16:
						col.DataType = typeof(short);
						break;
					case DbType.Int32:
						col.DataType = typeof(int);
						break;
					case DbType.Int64:
						col.DataType = typeof(long);
						break;
					case DbType.Single:
						col.DataType = typeof(float);
						break;
				}
			}
		}
    
		public virtual void AddNew() 
		{
			if ((_dataTable == null)) 
			{
				LoadSchema();
			}
			DataRow newRow = _dataTable.NewRow();
			_dataTable.Rows.Add(newRow);
			_dataRow = newRow;
		}
    
		public virtual void MarkAsDeleted() 
		{
			if (!(_dataRow == null)) 
			{
				_dataRow.Delete();
			}
		}
    
		public virtual void DeleteAll() 
		{
			if (!(_dataTable == null)) 
			{
				foreach (DataRow row in _dataTable.Rows) 
				{
					row.Delete();
				}
			}
		}
    
		public virtual void RejectChanges() 
		{
			if (!(_dataTable == null)) 
			{
				_dataTable.RejectChanges();
			}
		}
    
		void AcceptChanges() 
		{
			if (!(_dataTable == null)) 
			{
				_dataTable.AcceptChanges();
			}
		}
		
		public DataRowState RowState()
		{
			if(_dataTable != null && _dataRow != null)
				return _dataRow.RowState;
			else
				return DataRowState.Detached;
		}

		public virtual void GetChanges() 
		{
			if (!(_dataTable == null)) 
			{
				_dataTable = _dataTable.GetChanges();
			}
		}
    
		public virtual void GetChanges(DataRowState states) 
		{
			if (!(_dataTable == null)) 
			{
				_dataTable = _dataTable.GetChanges(states);
			}
		}
    
		public void Rewind() 
		{
			_dataRow = null;
			_enumerator = null;
			if (!(_dataTable == null)) 
			{
				if ((_dataTable.DefaultView.Count > 0)) 
				{
					_enumerator = _dataTable.DefaultView.GetEnumerator();
					_enumerator.MoveNext();
					DataRowView rowView = ((DataRowView)(_enumerator.Current));
					_dataRow = rowView.Row;
				}
			}
		}
    
		public bool MoveNext() 
		{
			bool moved = false;
			if ((!(_enumerator == null) 
				&& _enumerator.MoveNext())) 
			{
				DataRowView rowView = ((DataRowView)(_enumerator.Current));
				_dataRow = rowView.Row;
				moved = true;
			}
			return moved;
		}	

    
		public virtual void FlushData() 
		{
			_dataRow = null;
			_dataTable = null;
			_enumerator = null;
		}
    
		public virtual void Save() 
		{
			if ((_dataTable == null)) 
			{
				return;
			}
			TransactionManager txMgr = TransactionManager.ThreadTransactionMgr();
			try 
			{
				bool needToInsert = false;
				bool needToUpdate = false;
				bool needToDelete = false;
				foreach (DataRow row in _dataTable.Rows) 
				{
					switch (row.RowState) 
					{
						case DataRowState.Added:
							needToInsert = true;
							break;
						case DataRowState.Modified:
							needToUpdate = true;
							break;
						case DataRowState.Deleted:
							needToDelete = true;
							break;
					}
				}
				if ((needToInsert 
					|| (needToUpdate || needToDelete))) 
				{
					DBCommandWrapper insertCommand = null;
					DBCommandWrapper updateCommand = null;
					DBCommandWrapper deleteCommand = null;
					if (needToInsert) 
					{
						insertCommand = GetInsertCommand();
					}
					if (needToUpdate) 
					{
						updateCommand = GetUpdateCommand();
					}
					if (needToDelete) 
					{
						deleteCommand = GetDeleteCommand();
					}
					Database db = GetDatabase();
					//  Add the current DataTable to a DataSet
					DataSet ds = new DataSet();
					ds.Tables.Add(this.DataTable);
					txMgr.BeginTransaction();
					// Dim rowsAffected As Integer = db.UpdateDataSet(ds, Me.TableName, insertCommand, updateCommand, deleteCommand, UpdateBehavior.Continue)
					int rowsAffected = db.UpdateDataSet(ds, this.TableName, insertCommand, updateCommand, deleteCommand, txMgr.GetTransaction(db));
					txMgr.CommitTransaction();
					ds.Tables.Remove(this.DataTable);
					this.AcceptChanges();
				}
			}
			catch (Exception ex) 
			{
				if (!(txMgr == null)) 
				{
					txMgr.RollbackTransaction();
				}
				throw ex;
			}
		}
	
		protected bool LoadFromSql(string sp) 
		{
			return LoadFromSql(sp, null, CommandType.StoredProcedure);
		}

		protected bool LoadFromSql(string sp, ListDictionary parameters) 
		{
			return LoadFromSql(sp, parameters, CommandType.StoredProcedure);
		}
    
		protected bool LoadFromSql(string sp, ListDictionary parameters, CommandType commandType) 
		{
			bool loaded = false;

			TransactionManager txMgr = TransactionManager.ThreadTransactionMgr();

			try 
			{
				//  Create the Database object, using the default database service. The
				//  default database service is determined through configuration.
				Database db = GetDatabase();
				string sqlCommand = sp;
				DBCommandWrapper dbCommandWrapper;
				if ((commandType == CommandType.StoredProcedure)) 
				{
					dbCommandWrapper = db.GetStoredProcCommandWrapper(sqlCommand);
				}
				else 
				{
					dbCommandWrapper = db.GetSqlStringCommandWrapper(sqlCommand);
				}
				if (!(parameters == null)) 
				{
					foreach (DictionaryEntry param in parameters) 
					{
						dbCommandWrapper.AddInParameter(param.Key.ToString(), GetDbType(param.Value.GetType()), param.Value);
					}
				}
				IDbTransaction tx = txMgr.GetTransaction(db);
				DataSet ds;
				if ((tx == null)) 
				{
					ds = db.ExecuteDataSet(dbCommandWrapper);
				}
				else 
				{
					ds = db.ExecuteDataSet(dbCommandWrapper, tx);
				}
				Load(ds);
			}
			catch (Exception ex) 
			{
				this.ErrorMessage = ex.Message;
				return false;
			}
			finally 
			{
				loaded = (this.RowCount > 0);
			}
			return loaded;
		}

		protected void LoadFromSqlNoExec(string sp)
		{
			LoadFromSqlNoExec(sp, null, CommandType.StoredProcedure, -1);
		}

		protected void LoadFromSqlNoExec(string sp, ListDictionary parameters)
		{
			LoadFromSqlNoExec(sp, parameters, CommandType.StoredProcedure, -1);
		}

		protected void LoadFromSqlNoExec(string sp, ListDictionary parameters, CommandType commandType)
		{
			LoadFromSqlNoExec(sp, parameters, commandType, -1);
		}

		protected void LoadFromSqlNoExec(string sp, ListDictionary parameters, CommandType commandType, int commandTimeout)
		{

			TransactionManager txMgr = TransactionManager.ThreadTransactionMgr();

			try 
			{
				//  Create the Database object, using the default database service. The
				//  default database service is determined through configuration.
				Database db = GetDatabase();
				string sqlCommand = sp;
				DBCommandWrapper dbCommandWrapper;
				if ((commandType == CommandType.StoredProcedure)) 
				{
					dbCommandWrapper = db.GetStoredProcCommandWrapper(sqlCommand);
				}
				else 
				{
					dbCommandWrapper = db.GetSqlStringCommandWrapper(sqlCommand);
				}
				if ((commandTimeout > 0)) 
				{
					dbCommandWrapper.CommandTimeout = commandTimeout;
				}
				if (!(parameters == null)) 
				{
					foreach (DictionaryEntry param in parameters) 
					{
						dbCommandWrapper.AddInParameter(param.Key.ToString(), GetDbType(param.Value.GetType()), param.Value);
					}
				}
				IDbTransaction tx = txMgr.GetTransaction(db);
				if ((tx == null)) 
				{
					db.ExecuteNonQuery(dbCommandWrapper);
				}
				else 
				{
					db.ExecuteNonQuery(dbCommandWrapper, tx);
				}
			}
			catch (Exception ex) 
			{
				throw ex;
			}
		}
    
		protected void LoadFromSqlScalar(string sp)
		{
			LoadFromSqlScalar(sp, null, CommandType.StoredProcedure, -1);
		}

		protected void LoadFromSqlScalar(string sp, ListDictionary parameters)
		{
			LoadFromSqlScalar(sp, parameters, CommandType.StoredProcedure, -1);
		}

		protected void LoadFromSqlScalar(string sp, ListDictionary parameters, CommandType commandType)
		{
			LoadFromSqlScalar(sp, parameters, commandType, -1);
		}

		protected object LoadFromSqlScalar(string sp, ListDictionary parameters, CommandType commandType, int commandTimeout)
		{
			object rc = 0;

			TransactionManager txMgr = TransactionManager.ThreadTransactionMgr();
			
			try 
			{
				//  Create the Database object, using the default database service. The
				//  default database service is determined through configuration.
				Database db = GetDatabase();
				string sqlCommand = sp;
				DBCommandWrapper dbCommandWrapper;
				if ((commandType == CommandType.StoredProcedure)) 
				{
					dbCommandWrapper = db.GetStoredProcCommandWrapper(sqlCommand);
				}
				else 
				{
					dbCommandWrapper = db.GetSqlStringCommandWrapper(sqlCommand);
				}
				if ((commandTimeout > 0)) 
				{
					dbCommandWrapper.CommandTimeout = commandTimeout;
				}
				if (!(parameters == null)) 
				{
					foreach (DictionaryEntry param in parameters) 
					{
						dbCommandWrapper.AddInParameter(param.Key.ToString(), GetDbType(param.Value.GetType()), param.Value);
					}
				}
				IDbTransaction tx = txMgr.GetTransaction(db);
				if ((tx == null)) 
				{
					rc = db.ExecuteScalar(dbCommandWrapper);
				}
				else 
				{
					rc = db.ExecuteScalar(dbCommandWrapper, tx);
				}
			}
			catch (Exception ex) 
			{
				throw ex;
			}
			return rc;
		}

    
		private DbType GetDbType(System.Type sysType) 
		{
			switch (sysType.Name) 
			{
				case "Guid":
					return DbType.Guid;
				case "String":
					return DbType.String;
				case "Integer":
				case "Int32":
					return DbType.Int32;
				default:
					return DbType.Object;
			}
		}
    
		protected virtual void PreSave() 
		{
			foreach (SchemaItem item in this.SchemaEntries) 
			{
				if ((item.Justify != SchemaItemJustify.None)) 
				{
					SetString(item.FieldName, GetString(item.FieldName), item.Justify, item.Length);
				}
			}
		}
    
		protected virtual void PostSave(IDataParameterCollection ps) 
		{
		}
    
		public Database GetDatabase() 
		{
			Database db;

			if ((this.DatabaseInstanceName == String.Empty)) 
			{
				db = ((Database)(_databases["__default"]));
			}
			else 
			{
				db = ((Database)(_databases[this.DatabaseInstanceName]));
			}

			if (db == null)
			{
				//  If the object was given the name of a database instance, then create
				//  that instance. Otherwise, use the default instance.
				if ((this.DatabaseInstanceName == String.Empty)) 
				{
					db = DatabaseFactory.CreateDatabase();
					_databases["__default"] = db;
				}
				else 
				{
					db = DatabaseFactory.CreateDatabase(this.DatabaseInstanceName);
					_databases[this.DatabaseInstanceName] = db;
				}
			}

			return db;
		}
    
		public virtual bool IsColumnNull(string fieldName) 
		{
			return _dataRow.IsNull(fieldName);
		}	

		/// <summary>
		/// Use this method to set a column to DBNull.Value which will translate to NULL in your DBMS system.
		/// </summary>
		/// <param name="columnName">The name of the column. Use your ColumnNames like this, Employees.ColumnNames.Photo</param>
		public virtual void SetColumnNull(string fieldName)
		{
			_dataRow[fieldName] = Convert.DBNull;
		}

		/// <summary>
		/// Serializes the current instance data to an Xml string.
		/// </summary>
		/// <returns>A string containing the Xml representation of the datatable.</returns>
		public string ToXml() 
		{
			//  DataSet that will hold the returned results        
			DataSet ds = new DataSet((this.TableName + "DataSet"));
			//  Add the current instance to the dataset
			// Me.DataTable.TableName = Me.TableName
			ds.Tables.Add(this.DataTable);
			//  Build the XML string
			StringWriter writer = new StringWriter();
			ds.WriteXml(writer);
			//  Remove the table from the dataset
			ds.Tables.Remove(this.DataTable);
			return writer.ToString();
		}
    
		/// <summary>
		/// Deserializes the Xml string and loads the object with the data.
		/// </summary>
		public virtual void FromXml(string xml) 
		{
			DataSet ds = new DataSet();
			StringReader reader = new StringReader(xml);
			ds.ReadXml(reader);
			Load(ds);
		}
	
		protected virtual DBCommandWrapper GetInsertCommand() 
		{
			return null;
		}
    
		protected virtual DBCommandWrapper GetUpdateCommand() 
		{
			return null;
		}
    
		protected virtual DBCommandWrapper GetDeleteCommand() 
		{
			return null;
		}	
		
		#region Get/Set datatype functions

		protected string LSet(string field, int length)
		{
			if (field.Length >= length)
				return field;
			else
				return field.PadRight(length, ' ');
		}

		protected string RSet(string field, int length)
		{
			if (field.Length >= length)
				return field;
			else
				return field.PadLeft(length, ' ');
		}

		/// <summary>
		/// Used by the Properties in your generated class. 
		/// </summary>
		/// <param name="columnName">One of the named for your ColumnNames class</param>
		/// <returns>The value</returns>
		protected string GetString(string columnName)
		{
			if(_dataRow.IsNull(columnName))
				return String.Empty;
			else
				return (string)_dataRow[columnName];
		}
    
		protected void SetString(string fieldName, string value) 
		{
			SetString(fieldName, value, SchemaItemJustify.None, 0);
		}
    
		protected void SetString(string fieldName, string value, SchemaItemJustify justify, Int32 length) 
		{
			if ((value.Trim() == String.Empty)) 
			{
				_dataRow[fieldName] = EasyObject.DBNull;
				return;
			}
			switch (justify) 
			{
				case SchemaItemJustify.None:
					_dataRow[fieldName] = value.Trim();
					break;
				case SchemaItemJustify.Left:
					_dataRow[fieldName] = LSet(value.Trim(), length);
					break;
				case SchemaItemJustify.Right:
					_dataRow[fieldName] = RSet(value.Trim(), length);
					break;
			}
		}
    
		protected bool GetBoolean(string fieldName) 
		{
			return (bool)_dataRow[fieldName];
		}
    
		protected void SetBoolean(string fieldName, bool value) 
		{
			_dataRow[fieldName] = value;
		}
    
		protected short GetShort(string fieldName) 
		{
			return (short)_dataRow[fieldName];
		}
    
		protected void SetShort(string fieldName, short value) 
		{
			_dataRow[fieldName] = value;
		}
    
		protected Int32 GetInt32(string fieldName) 
		{
			return (Int32)_dataRow[fieldName];
		}
    
		protected void SetInt32(string fieldName, Int32 value) 
		{
			_dataRow[fieldName] = value;
		}
    
		protected Int32 GetInteger(string fieldName) 
		{
			return GetInt32(fieldName);
		}
    
		protected void SetInteger(string fieldName, Int32 value) 
		{
			SetInt32(fieldName, value);
		}
    
		protected byte[] GetByteArray(string fieldName) 
		{
			return ((byte[])(_dataRow[fieldName]));
		}
    
		protected void SetByteArray(string fieldName, byte[] value) 
		{
			_dataRow[fieldName] = value;
		}
    
		protected byte GetByte(string fieldName) 
		{
			return (byte)_dataRow[fieldName];
		}
    
		protected void SetByte(string fieldName, byte value) 
		{
			_dataRow[fieldName] = value;
		}
    
		protected float GetFloat(string fieldName) 
		{
			return (float)_dataRow[fieldName];
		}
    
		protected void SetFloat(string fieldName, float value) 
		{
			_dataRow[fieldName] = value;
		}
    
		protected double GetDouble(string fieldName) 
		{
			return (double)_dataRow[fieldName];
		}
    
		protected void SetDouble(string fieldName, double value) 
		{
			_dataRow[fieldName] = value;
		}
    
		protected Decimal GetDecimal(string fieldName) 
		{
			return (Decimal)_dataRow[fieldName];
		}
    
		protected void SetDecimal(string fieldName, Decimal value) 
		{
			_dataRow[fieldName] = value;
		}
    
		protected DateTime GetDateTime(string fieldName) 
		{
			return (DateTime)_dataRow[fieldName];
		}
    
		protected void SetGuid(string fieldName, Guid value) 
		{
			_dataRow[fieldName] = value;
		}
    
		protected Guid GetGuid(string fieldName) 
		{
			return (Guid)_dataRow[fieldName];
		}
    
		protected void SetDateTime(string fieldName, DateTime value) 
		{
			_dataRow[fieldName] = value;
		}
    
		public string GetItemString(SchemaItem item) 
		{
			return GetItemString(item, String.Empty);
		}
    
		public string GetItemString(SchemaItem item, string defaultValue) 
		{
			if (IsColumnNull(item.FieldName)) 
			{
				return String.Empty;
			}
			else 
			{
				switch (item.DBType) 
				{
					case DbType.DateTime:
						return GetDateTime(item.FieldName).ToString("MM/dd/yyyy");
					case DbType.Byte:
						return GetByte(item.FieldName) == 0 ? defaultValue : GetString(item.FieldName);
					case DbType.Decimal:
					case DbType.Double:
						return GetDouble(item.FieldName) == 0 ? defaultValue : GetString(item.FieldName);
					case DbType.Int32:
						return GetInt32(item.FieldName) == 0 ? defaultValue : GetString(item.FieldName);
					default:
						return GetString(item.FieldName);
				}
			}
		}
    
		public void SetItem(SchemaItem item, string value) 
		{
			if ((value.Trim().Length > 0)) 
			{
				switch (item.DBType) 
				{
					case DbType.DateTime:
						SetDateTime(item.FieldName, DateTime.Parse(value));
						break;
					case DbType.Int32:
						SetInt32(item.FieldName, int.Parse(value));
						break;
					case DbType.Decimal:
					case DbType.Double:
						SetDouble(item.FieldName, double.Parse(value));
						break;
					default:
						SetString(item.FieldName, value);
						break;
				}
			}
		}
		#endregion

		#region String Row Accessors
		/// <summary>
		/// Used by the String Properties in your generated class. 
		/// </summary>
		/// <param name="fieldName">One of the named for your ColumnNames class</param>
		/// <returns>The value</returns>
		protected string GetGuidAsString(string fieldName)
		{
			return _dataRow[fieldName].ToString();
		}

		/// <summary>
		/// Used by the String Properties in your generated class. 
		/// </summary>
		/// <param name="fieldName">One of the named for your ColumnNames class</param>
		/// <param name="data">The Value</param>
		/// <returns>The Strong Type</returns>
		protected Guid SetGuidAsString(string fieldName, string data)
		{
			return new Guid(data);
		}

		/// <summary>
		/// Used by the String Properties in your generated class. 
		/// </summary>
		/// <param name="fieldName">One of the named for your ColumnNames class</param>
		/// <returns>The value</returns>
		protected string GetBoolAsString(string fieldName)
		{
			return _dataRow[fieldName].ToString();
		}
		
		protected string GetBooleanAsString(string fieldName)
		{
			return GetBoolAsString(fieldName);
		}

		/// <summary>
		/// Used by the String Properties in your generated class. 
		/// </summary>
		/// <param name="fieldName">One of the named for your ColumnNames class</param>
		/// <param name="data">The Value</param>
		/// <returns>The Strong Type</returns>
		protected bool SetBoolAsString(string fieldName, string data)
		{
			return Convert.ToBoolean(data);
		}

		protected bool SetBooleanAsString(string fieldName, string data)
		{
			return Convert.ToBoolean(data);
		}

		/// <summary>
		/// Used by the String Properties in your generated class. 
		/// </summary>
		/// <param name="fieldName">One of the named for your ColumnNames class</param>
		/// <returns>The value</returns>
		protected string GetStringAsString(string fieldName)
		{
			return (string)_dataRow[fieldName];
		}

		/// <summary>
		/// Used by the String Properties in your generated class. 
		/// </summary>
		/// <param name="fieldName">One of the named for your ColumnNames class</param>
		/// <param name="data">The Value</param>
		/// <returns>The Strong Type</returns>
		protected string SetStringAsString(string fieldName, string data)
		{
			return data;
		}

		/// <summary>
		/// Used by the String Properties in your generated class. 
		/// </summary>
		/// <param name="fieldName">One of the named for your ColumnNames class</param>
		/// <returns>The value</returns>
		protected string GetIntAsString(string fieldName)
		{
			return _dataRow[fieldName].ToString();
		}

		protected string GetIntegerAsString(string fieldName)
		{
			return GetIntAsString(fieldName);
		}

		/// <summary>
		/// Used by the String Properties in your generated class. 
		/// </summary>
		/// <param name="fieldName">One of the named for your ColumnNames class</param>
		/// <param name="data">The Value</param>
		/// <returns>The Strong Type</returns>
		protected int SetIntAsString(string fieldName, string data)
		{
			return Convert.ToInt32(data);
		}

		protected int SetIntegerAsString(string fieldName, string data)
		{
			return Convert.ToInt32(data);
		}

		/// <summary>
		/// Used by the String Properties in your generated class. 
		/// </summary>
		/// <param name="fieldName">One of the named for your ColumnNames class</param>
		/// <returns>The value</returns>
		protected string GetLongAsString(string fieldName)
		{
			return _dataRow[fieldName].ToString();
		}

		/// <summary>
		/// Used by the String Properties in your generated class. 
		/// </summary>
		/// <param name="fieldName">One of the named for your ColumnNames class</param>
		/// <param name="data">The Value</param>
		/// <returns>The Strong Type</returns>
		protected long SetLongAsString(string fieldName, string data)
		{
			return Convert.ToInt64(data);
		}

		/// <summary>
		/// Used by the String Properties in your generated class. 
		/// </summary>
		/// <param name="fieldName">One of the named for your ColumnNames class</param>
		/// <returns>The value</returns>
		protected string GetShortAsString(string fieldName)
		{
			return _dataRow[fieldName].ToString();
		}

		/// <summary>
		/// Used by the String Properties in your generated class. 
		/// </summary>
		/// <param name="fieldName">One of the named for your ColumnNames class</param>
		/// <param name="data">The Value</param>
		/// <returns>The Strong Type</returns>
		protected short SetShortAsString(string fieldName, string data)
		{
			return Convert.ToInt16(data);
		}

		/// <summary>
		/// Used by the String Properties in your generated class. 
		/// </summary>
		/// <param name="fieldName">One of the named for your ColumnNames class</param>
		/// <returns>The value</returns>
		protected string GetDateTimeAsString(string fieldName)
		{
			return ((DateTime)_dataRow[fieldName]).ToString(this.StringFormat);
		}

		/// <summary>
		/// Used by the String Properties in your generated class. 
		/// </summary>
		/// <param name="fieldName">One of the named for your ColumnNames class</param>
		/// <param name="data">The Value</param>
		/// <returns>The Strong Type</returns>
		protected DateTime SetDateTimeAsString(string fieldName, string data)
		{
			return Convert.ToDateTime(data);
		}

		/// <summary>
		/// Used by the String Properties in your generated class. 
		/// </summary>
		/// <param name="fieldName">One of the named for your ColumnNames class</param>
		/// <returns>The value</returns>
		protected string GetDecimalAsString(string fieldName)
		{
			return _dataRow[fieldName].ToString();
		}

		/// <summary>
		/// Used by the String Properties in your generated class. 
		/// </summary>
		/// <param name="fieldName">One of the named for your ColumnNames class</param>
		/// <param name="data">The Value</param>
		/// <returns>The Strong Type</returns>
		protected decimal SetDecimalAsString(string fieldName, string data)
		{
			return Convert.ToDecimal(data);
		}

		/// <summary>
		/// Used by the String Properties in your generated class. 
		/// </summary>
		/// <param name="fieldName">One of the named for your ColumnNames class</param>
		/// <returns>The value</returns>
		protected string GetFloatAsString(string fieldName)
		{
			return _dataRow[fieldName].ToString();
		}

		/// <summary>
		/// Used by the String Properties in your generated class. 
		/// </summary>
		/// <param name="fieldName">One of the named for your ColumnNames class</param>
		/// <param name="data">The Value</param>
		/// <returns>The Strong Type</returns>
		protected Single SetFloatAsString(string fieldName, string data)
		{
			return Convert.ToSingle(data);
		}


		/// <summary>
		/// Used by the String Properties in your generated class. 
		/// </summary>
		/// <param name="fieldName">One of the named for your ColumnNames class</param>
		/// <returns>The value</returns>
		protected string GetDoubleAsString(string fieldName)
		{
			return _dataRow[fieldName].ToString();
		}

		/// <summary>
		/// Used by the String Properties in your generated class. 
		/// </summary>
		/// <param name="fieldName">One of the named for your ColumnNames class</param>
		/// <param name="data">The Value</param>
		/// <returns>The Strong Type</returns>
		protected double SetDoubleAsString(string fieldName, string data)
		{
			return Convert.ToDouble(data);
		}

		/// <summary>
		/// Used by the String Properties in your generated class. 
		/// </summary>
		/// <param name="fieldName">One of the named for your ColumnNames class</param>
		/// <returns>The value</returns>
		protected string GetByteAsString(string fieldName)
		{
			return _dataRow[fieldName].ToString();
		}

		/// <summary>
		/// Used by the String Properties in your generated class. 
		/// </summary>
		/// <param name="fieldName">One of the named for your ColumnNames class</param>
		/// <param name="data">The Value</param>
		/// <returns>The Strong Type</returns>
		protected byte SetByteAsString(string fieldName, string data)
		{
			return Convert.ToByte(data);
		}
		#endregion

		#region Serialization functions
    
		public override string ToString() 
		{
			StringBuilder sb = new StringBuilder();
			bool first = true;

			foreach (SchemaItem item in this.SchemaEntries) 
			{
				if (!first) 
				{
					sb.Append("|");
				}
				sb.Append(GetString(item.FieldName));
				first = false;
			}
			return sb.ToString();
		}
    
		protected string Serialize() 
		{
			return this.ToString();
		}
    
		protected bool Deserialize(string values) 
		{
			int i = 0;
			AddNew();
			string[] list = values.Split('|');
			foreach (SchemaItem item in this.SchemaEntries) 
			{
				switch (item.DBType) 
				{
					case DbType.DateTime:
						SetDateTime(item.FieldName, DateTime.Parse(list[i]));
						break;
					case DbType.Int32:
						SetInt32(item.FieldName, int.Parse(list[i]));
						break;
					case DbType.Double:
					case DbType.Decimal:
						SetDouble(item.FieldName, double.Parse(list[i]));
						break;
					default:
						SetString(item.FieldName, list[i], item.Justify, item.Length);
						break;
				}
				i = (i + 1);
			}
			return true;
		}
		#endregion

		#region Properties

		public string StringFormat = "MM/dd/yyyy";

		public int RowCount 
		{
			get 
			{
				int count = 0;
				if (!(_dataTable == null)) 
				{
					count = _dataTable.DefaultView.Count;
				}
				return count;
			}
		}
    
		public string DatabaseInstanceName 
		{
			get 
			{
				return _databaseInstanceName;
			}
			set 
			{
				_databaseInstanceName = value;
			}
		}
    
		public string DynamicQueryInstanceName 
		{
			get 
			{
				return _dynamicQueryInstanceName;
			}
			set 
			{
				_dynamicQueryInstanceName = value;
			}
		}
    
		protected virtual string Source 
		{
			get 
			{
				return String.Empty;
			}
		}
    
		protected static object DBNull 
		{
			get 
			{
				if ((_dbNull == null)) 
				{
					_dbNull = Convert.DBNull;
				}
				return _dbNull;
			}
		}
    
		public bool IsNew 
		{
			get 
			{
				return _isNew;
			}
			set 
			{
				_isNew = value;
			}
		}
    
		public Int32 ErrorCode 
		{
			get 
			{
				return _errorCode;
			}
			set 
			{
				_errorCode = value;
			}
		}
    
		public string ErrorMessage 
		{
			get 
			{
				return _errorMessage;
			}
			set 
			{
				_errorMessage = value;
			}
		}
    
		protected DataRow DataRow 
		{
			get 
			{
				return _dataRow;
			}
		}
    
		protected internal DataTable DataTable 
		{
			get 
			{
				return _dataTable;
			}
			set 
			{
				_dataTable = value;
				_dataTable.TableName = this.TableName;
				_dataRow = null;
				if (!(_dataTable == null)) 
				{
					Rewind();
				}
			}
		}
    
		public DataView DefaultView 
		{
			get 
			{
				if (!(_dataTable == null)) 
				{
					return _dataTable.DefaultView;
				}
				else 
				{
					return null;
				}
			}
		}
    
		protected ArrayList SchemaEntries 
		{
			get 
			{
				return _schemaEntries;
			}
			set 
			{
				_schemaEntries = value;
			}
		}
    
		public virtual string TableName 
		{
			get 
			{
				return String.Empty;
			}
		}
    
		protected IDbTransaction Transaction 
		{
			get 
			{
				return _tx;
			}
			set 
			{
				_tx = value;
			}
		}
    
		public DynamicQuery Query 
		{
			get 
			{
				if (_query == null)
				{
					//  If the object was given the name of a dynamic query instance, then create
					//  that instance. Otherwise, use the default instance.
					if (this.DynamicQueryInstanceName == string.Empty)
					{
						_query = DynamicQueryFactory.CreateDynamicQuery(this);
					}
					else 
					{
						_query = DynamicQueryFactory.CreateDynamicQuery(this, this.DynamicQueryInstanceName);
					}
				}

				return _query;
			}
		}
		public string Sort
		{
			get
			{
				string _sort = "";

				if(_dataTable != null)
				{
					_sort = _dataTable.DefaultView.Sort;
				}

				return _sort;
			}

			set
			{
				if(_dataTable != null)
				{
					_dataTable.DefaultView.Sort = value;
					Rewind();
				}
			}	
		}
		#endregion
	}
}
