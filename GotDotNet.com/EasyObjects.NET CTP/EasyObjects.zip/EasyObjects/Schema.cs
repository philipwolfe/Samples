using System;
using System.Collections;

namespace NCI.EasyObjects
{
	/// <summary>
	/// Summary description for Schema.
	/// </summary>
	public abstract class Schema
	{
		public Schema()
		{
			//
			// TODO: Add constructor logic here
			//
		}

		public virtual ArrayList SchemaEntries 
		{
			get 
			{
				return null;
			}
		}
	}
}
