using System;
using System.Data;

namespace NCI.EasyObjects
{
	public enum SchemaItemJustify : int 
	{
		None = 0,
		Left,
		Right
	}

	/// <summary>
	/// Summary description for SchemaItem.
	/// </summary>
	public class SchemaItem
	{
		string _fieldName;
		SchemaItemJustify _justify;
		Int32 _len;
		DbType _dbType;
		bool _autoIncrement = false;

		public SchemaItem(string fieldName, DbType dbType) 
		{
			_fieldName = fieldName;
			_justify = SchemaItemJustify.None;
			_len = 0;
			_dbType = dbType;
		}
    
		public SchemaItem(string fieldName, DbType dbType, bool autoIncrement) 
		{
			_fieldName = fieldName;
			_justify = SchemaItemJustify.None;
			_len = 0;
			_dbType = dbType;
			_autoIncrement = autoIncrement;
		}
    
		public SchemaItem(string fieldName, DbType dbType, SchemaItemJustify justify, int len) 
		{
			_fieldName = fieldName;
			_justify = justify;
			_len = len;
			_dbType = dbType;
		}
    
		public virtual DbType DBType 
		{
			get 
			{
				return _dbType;
			}
		}
    
		public virtual SchemaItemJustify Justify 
		{
			get 
			{
				return _justify;
			}
		}
    
		public virtual Int32 Length 
		{
			get 
			{
				return _len;
			}
		}
    
		public virtual string FieldName 
		{
			get 
			{
				return _fieldName;
			}
		}
    
		public virtual bool AutoIncrement 
		{
			get 
			{
				return _autoIncrement;
			}
		}	
	}
}
