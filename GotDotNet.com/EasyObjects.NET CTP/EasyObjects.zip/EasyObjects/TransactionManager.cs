using System;
using System.Data;
using System.Threading;
using System.Collections;
using Microsoft.Practices.EnterpriseLibrary.Data;

namespace NCI.EasyObjects
{
	/// <summary>
	/// Summary description for TransactionManager.
	/// </summary>
	public class TransactionManager
	{
		public TransactionManager()
		{
			//
			// TODO: Add constructor logic here
			//
		}
    
		public void BeginTransaction() 
		{
			if (hasRolledBack) 
			{
				throw new Exception("Transaction rolled back");
			}
			txCount = (txCount + 1);
		}
    
		public void CommitTransaction() 
		{
			if (hasRolledBack) 
			{
				throw new Exception("Transaction rolled back");
			}
			txCount = (txCount - 1);
			if ((txCount == 0)) 
			{
				foreach (IDbTransaction tx in this.transactions.Values) 
				{
					tx.Commit();
					tx.Dispose();
				}
				this.transactions.Clear();
			}
		}
    
		public void RollbackTransaction() 
		{
			if ((!hasRolledBack && (txCount > 0))) 
			{
				foreach (IDbTransaction tx in this.transactions.Values) 
				{
					tx.Rollback();
					tx.Dispose();
				}

				this.transactions.Clear();
				this.txCount = 0;
			}
		}	
    
		public IDbTransaction GetTransaction(Database db) 
		{
			IDbTransaction tx = null;

			if ((txCount == 0)) 
			{
				//  TODO: Figure out what to do here
			}
			else 
			{
				string connectionString = db.ConfigurationName;
				if ((connectionString == String.Empty)) 
				{
					connectionString = "__Default";
				}
				tx = ((IDbTransaction)(this.transactions[connectionString]));
				if ((tx == null)) 
				{
					IDbConnection sqlConn = db.GetConnection();
					sqlConn.Open();
					if (!(_isolationLevel == IsolationLevel.Unspecified)) 
					{
						tx = sqlConn.BeginTransaction(_isolationLevel);
					}
					else 
					{
						tx = sqlConn.BeginTransaction();
					}
					this.transactions[connectionString] = tx;
				}
			}

			return tx;
		}

		Hashtable transactions = new Hashtable();
		int txCount = 0;
		bool hasRolledBack = false;

		#region Static properties & methods

		private static IsolationLevel _isolationLevel = IsolationLevel.Unspecified;
		private static LocalDataStoreSlot txMgrSlot = Thread.AllocateDataSlot();
    
		public static IsolationLevel IsolationLevel 
		{
			get 
			{
				return _isolationLevel;
			}
			set 
			{
				_isolationLevel = value;
			}
		}
    
		public static TransactionManager ThreadTransactionMgr() 
		{
			TransactionManager txMgr = null;
			object obj = Thread.GetData(txMgrSlot);
			if (!(obj == null)) 
			{
				txMgr = ((TransactionManager)(obj));
			}
			else 
			{
				txMgr = new TransactionManager();
				Thread.SetData(txMgrSlot, txMgr);
			}
			return txMgr;
		}
    
		public static void ThreadTransactionMgrReset() 
		{
			TransactionManager txMgr = TransactionManager.ThreadTransactionMgr();
			try 
			{
				if (((txMgr.txCount > 0) 
					&& (txMgr.hasRolledBack == false))) 
				{
					txMgr.RollbackTransaction();
				}
			}
			catch
			{
				//  At this point we're not worried about a failure
			}

			Thread.SetData(txMgrSlot, null);
		}	
		#endregion
	}
}
