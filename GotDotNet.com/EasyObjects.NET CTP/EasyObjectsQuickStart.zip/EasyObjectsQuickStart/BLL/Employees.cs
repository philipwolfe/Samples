using System;

namespace EasyObjectsQuickStart.BLL
{
	/// <summary>
	/// Summary description for Employees.
	/// </summary>
	public class Employees : _Employees
	{
		public Employees() 
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
