using System;

namespace EasyObjectsQuickStart.BLL
{
	/// <summary>
	/// Summary description for Products.
	/// </summary>
	public class Products : _Products
	{
		public Products()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
