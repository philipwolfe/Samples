/******************************************************************************
**        File: Create 50,000 Ineventory.sql
**        Name: Benchmark Data Load
**        Desc: Adds 50,000 items to the inventory table. Sample Output:
**
**        itemid     qty
**        ---------- -----------
**        EST-1      10000
**
**        Date: 11/6/2001
**
*******************************************************************************/

-- SET NOCOUNT to ON and no longer display the count message
SET NOCOUNT ON

DECLARE @itemid char(10)
DECLARE @qty int

DECLARE @i int
SELECT @i = 1

PRINT 'Inserting into the Inventory table: ' + convert(varchar(255), getdate());

WHILE (@i <= 50000)
BEGIN    
    -- unique item id
    select @itemid = rtrim('EST-' + convert(varchar(10), @i))
   
    select @qty = 10000

	-- insert the new product
    EXEC upInventoryAdd @itemid, @qty
	
    -- output a progress message    
    IF @i % 1000 = 0 PRINT @i

    SELECT @i = @i + 1
END

-- Reset SET NOCOUNT to OFF
SET NOCOUNT OFF

PRINT 'Completed: ' + convert(varchar(255), getdate());
