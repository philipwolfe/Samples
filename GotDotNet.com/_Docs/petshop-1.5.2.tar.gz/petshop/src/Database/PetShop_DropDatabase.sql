/******************************************************************************
**        File: PetShop_DropDatabase.sql
**        Name: PetShop_DropDatabase
**        Desc: Database uninstall script.
**
**        Date: 11/6/2001
**
*******************************************************************************/

USE master;

-- drop the database
IF EXISTS 
(
    SELECT dbid FROM sysdatabases WHERE name = 'petshop'
)
DROP DATABASE petshop;

