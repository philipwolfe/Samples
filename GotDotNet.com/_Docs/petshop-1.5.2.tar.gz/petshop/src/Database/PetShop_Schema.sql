/******************************************************************************
**		File: PetShop_Schema.sql
**		Name: Physical Database Schema SQL Script
**		Desc: This script will create the .NET PetShop database schema
**
**		Date: 11/9/2001
**
*******************************************************************************/

USE master;

-- create the database
IF NOT EXISTS (SELECT dbid FROM sysdatabases WHERE name = 'petshop')
CREATE DATABASE petshop;
GO

-------------------------------------------------------------------------------
--
-- Database Tables
--
-------------------------------------------------------------------------------

-- switch to the .NET PetShop database
USE petshop;
GO

-------------------------------------------------------------------------------
-- Supplier Table
-------------------------------------------------------------------------------
CREATE TABLE Supplier
(
    suppid              int                    NOT NULL,
    [name]              varchar(80)            NOT NULL,
    status              char(2)                NOT NULL,
    addr1               varchar(80)            NULL,
    addr2               varchar(80)            NULL,
    city                varchar(80)            NULL,
    state               varchar(80)            NULL,
    zip                 char(5)                NULL,
    phone               varchar(80)            NULL
);

-- add the primary key constraints
ALTER TABLE Supplier ADD
    CONSTRAINT PK_Supplier
    PRIMARY KEY  CLUSTERED (suppid);

-- grant access
GRANT ALL ON Supplier TO PUBLIC;
GO

-------------------------------------------------------------------------------
-- Orders Table
-------------------------------------------------------------------------------
CREATE TABLE Orders
(
    orderid             int         IDENTITY   NOT NULL,
    userid              varchar(80)            NOT NULL,
    orderdate           datetime               NOT NULL,
    shipaddr1           varchar(80)            NOT NULL,
    shipaddr2           varchar(80)            NULL,
    shipcity            varchar(80)            NOT NULL,
    shipstate           varchar(80)            NOT NULL,
    shipzip             varchar(20)            NOT NULL,
    shipcountry         varchar(20)            NOT NULL,
    billaddr1           varchar(80)            NOT NULL,
    billaddr2           varchar(80)            NULL,
    billcity            varchar(80)            NOT NULL,
    billstate           varchar(80)            NOT NULL,
    billzip             varchar(20)            NOT NULL,
    billcountry         varchar(20)            NOT NULL,
    courier             varchar(80)            NOT NULL,
    totalprice          numeric(10, 2)         NOT NULL,
    billtofirstname     varchar(80)            NOT NULL, 
    billtolastname      varchar(80)            NOT NULL,
    shiptofirstname     varchar(80)            NOT NULL,
    shiptolastname      varchar(80)            NOT NULL,
    creditcard          varchar(80)            NOT NULL,
    exprdate            char(7)                NOT NULL,
    cardtype            varchar(80)            NOT NULL,
    locale              varchar(20)            NOT NULL
);

-- add the primary key constraints
ALTER TABLE Orders ADD
    CONSTRAINT PK_Orders
    PRIMARY KEY  CLUSTERED (orderid);

-- grant access
GRANT ALL ON Orders TO PUBLIC;
GO

-------------------------------------------------------------------------------
-- OrderStatus Table
-------------------------------------------------------------------------------
CREATE TABLE OrderStatus
(
    orderid             int                    NOT NULL,
    linenum             int                    NOT NULL,
    [timestamp]         datetime               NOT NULL,
    status              char(2)                NOT NULL
);

-- add the primary key constraints
ALTER TABLE OrderStatus ADD
    CONSTRAINT PK_OrderStatus
    PRIMARY KEY  CLUSTERED (orderid);

-- add the foreign key constraints
ALTER TABLE OrderStatus ADD 
    CONSTRAINT FK_OrderStatus_Orders FOREIGN KEY (orderid)
    REFERENCES Orders (orderid);

-- grant access
GRANT ALL ON OrderStatus TO PUBLIC;
GO

-------------------------------------------------------------------------------
-- Category Table
-------------------------------------------------------------------------------
CREATE TABLE Category
(
    catid               char(10)               NOT NULL,
    [name]              varchar(80)            NULL,  
    descn               varchar(255)           NULL
);

-- add the primary key
ALTER TABLE Category ADD 
    CONSTRAINT PK_Category
    PRIMARY KEY  CLUSTERED (catid);

-- grant access
GRANT ALL ON Category TO PUBLIC;
GO

-------------------------------------------------------------------------------
-- Product Table
-------------------------------------------------------------------------------
CREATE TABLE Product
(
    productid           char(10)               NOT NULL,
    category            char(10)               NOT NULL,
    [name]              varchar(80)            NULL,
    descn               varchar(255)           NULL
);

-- add the primary key constraints
ALTER TABLE Product ADD 
    CONSTRAINT PK_Product
    PRIMARY KEY  CLUSTERED (productid);

-- add the foreign key constraints
ALTER TABLE Product ADD 
    CONSTRAINT FK_Product_Category FOREIGN KEY (category)
    REFERENCES category (catid);

-- grant access
GRANT ALL ON Product TO PUBLIC;
GO

-------------------------------------------------------------------------------
-- Signon Table
-------------------------------------------------------------------------------
CREATE TABLE Signon
(
    username            varchar(80)            NOT NULL,
    password            varchar(25)            NOT NULL,
);

-- add the primary key constraints
ALTER TABLE Signon ADD
    CONSTRAINT PK_Signon
    PRIMARY KEY CLUSTERED (username);

-- grant access
GRANT ALL ON Signon TO PUBLIC;
GO

-------------------------------------------------------------------------------
-- BannerData Table
-------------------------------------------------------------------------------
CREATE TABLE BannerData
(
    favcategory         varchar(80)            NOT NULL,
    bannername          varchar(80)            NULL  
);

-- add the primary key
ALTER TABLE BannerData ADD
    CONSTRAINT PK_BannerData
    PRIMARY KEY CLUSTERED (favcategory);

-- grant access
GRANT ALL ON BannerData TO PUBLIC;
GO

-------------------------------------------------------------------------------
-- Profile Table
-------------------------------------------------------------------------------
CREATE TABLE Profile
(
    userid              varchar(80)            NOT NULL,
    langpref            varchar(80)            NOT NULL,
    favcategory         varchar(80)            NULL,
    mylistopt           int                    NULL,
    banneropt           int                    NULL
);

-- add the primary key constraints
ALTER TABLE Profile ADD
    CONSTRAINT PK_Profile
    PRIMARY KEY  CLUSTERED (userid);

-- add the foreign key constraints
ALTER TABLE Profile ADD 
    CONSTRAINT FK_Profile_BannerData FOREIGN KEY (favcategory)
    REFERENCES BannerData (favcategory);
    
-- grant access
GRANT ALL ON Profile TO PUBLIC;
GO

-------------------------------------------------------------------------------
-- Account Table
-------------------------------------------------------------------------------
CREATE TABLE Account
(
    userid              varchar(80)            NOT NULL,
    email               varchar(80)            NOT NULL,
    firstname           varchar(80)            NOT NULL,
    lastname            varchar(80)            NOT NULL,
    status              char(2)                NULL,
    addr1               varchar(80)            NOT NULL,
    addr2               varchar(40)            NULL,
    city                varchar(80)            NOT NULL,
    state               varchar(80)            NOT NULL,
    zip                 varchar(20)            NOT NULL,
    country             varchar(20)            NOT NULL,
    phone               varchar(80)            NOT NULL
);

-- add the primary key
ALTER TABLE Account ADD 
    CONSTRAINT PK_Account
    PRIMARY KEY  CLUSTERED (userid);
    
-- add the foreign key constraints
ALTER TABLE Account ADD 
    CONSTRAINT FK_Account_Signon FOREIGN KEY (userid)
    REFERENCES Signon (username),
    CONSTRAINT FK_Account_Profile FOREIGN KEY (userid)
    REFERENCES Profile (userid);

-- grant access
GRANT ALL ON Account TO PUBLIC;
GO

-------------------------------------------------------------------------------
-- ItemTable Table
-------------------------------------------------------------------------------
CREATE TABLE Item
(
    itemid              char(10)               NOT NULL,
    productid           char(10)               NOT NULL,
    listprice           decimal(10, 2)         NULL,
    unitcost            decimal(10, 2)         NULL,
    supplier            int                    NULL,
    status              char(2)                NULL,
    attr1               varchar(80)            NULL,
    attr2               varchar(80)            NULL,
    attr3               varchar(80)            NULL,    
    attr4               varchar(80)            NULL,
    attr5               varchar(80)            NULL
);

-- add the primary key constraints
ALTER TABLE Item ADD
    CONSTRAINT PK_Item
    PRIMARY KEY  CLUSTERED (itemid);

-- add the foreign key constraints
ALTER TABLE Item ADD 
    CONSTRAINT FK_Item_Product FOREIGN KEY (productid)
    REFERENCES Product (productid),
    CONSTRAINT FK_Item_Supplier FOREIGN KEY (supplier)
    REFERENCES Supplier (suppid);

-- grant access
GRANT ALL ON Item TO PUBLIC;
GO

-------------------------------------------------------------------------------
-- Inventory Table
-------------------------------------------------------------------------------
CREATE TABLE Inventory
(
    itemid              char(10)               NOT NULL,
    qty                 int                    NOT NULL
);

-- grant access
GRANT ALL ON Inventory TO PUBLIC;
GO

-------------------------------------------------------------------------------
-- LineItem Table
-------------------------------------------------------------------------------
CREATE TABLE LineItem
(
    orderid             int                    NOT NULL,
    linenum             int                    NOT NULL,
    itemid              char(10)               NOT NULL,
    quantity            int                    NOT NULL,
    unitprice           numeric(10, 2)         NOT NULL
);

-- add the primary key constraints
ALTER TABLE LineItem ADD
    CONSTRAINT PK_LineItem
    PRIMARY KEY  CLUSTERED (orderid, linenum);

-- add the foreign key constraints
ALTER TABLE LineItem ADD 
    CONSTRAINT FK_LineItem_Orders FOREIGN KEY (orderid)
    REFERENCES Orders (orderid);

-- grant access
GRANT ALL ON LineItem TO PUBLIC;
GO

-------------------------------------------------------------------------------
--
-- Indexes
--
-------------------------------------------------------------------------------
CREATE  INDEX [IX_Item] ON [dbo].[Item]([productid], [itemid], [listprice], [attr1]) ON [PRIMARY];
GO

CREATE  INDEX [IX_Product_1] ON [dbo].[Product]([name]) ON [PRIMARY];
GO

CREATE  INDEX [IX_Product_2] ON [dbo].[Product]([category]) ON [PRIMARY];
GO

CREATE  INDEX [IX_Product_3] ON [dbo].[Product]([category], [name]) ON [PRIMARY];
GO

CREATE  INDEX [IX_Product_4] ON [dbo].[Product]([category], [productid], [name]) ON [PRIMARY];
GO

-------------------------------------------------------------------------------
--
-- Stored Procedures
--
-------------------------------------------------------------------------------

-------------------------------------------------------------------------------
-- upAccountAdd
-------------------------------------------------------------------------------
CREATE PROCEDURE upAccountAdd
(
    @userid              varchar(80),
    @password            varchar(80),
    @email               varchar(80),
    @firstname           varchar(80),
    @lastname            varchar(80),
    @addr1               varchar(80),
    @addr2               varchar(40),
    @city                varchar(80),
    @state               varchar(80),
    @zip                 varchar(20),
    @country             varchar(20),
    @phone               varchar(80),
    @langpref            varchar(80),
    @favcategory         varchar(80),
    @mylistopt           int,
    @banneropt           int
)
AS

    -- SET NOCOUNT to ON and no longer display the count message
    SET NOCOUNT ON

    DECLARE @CurrentError int

    -- start transaction, inserting into three tables
    BEGIN TRANSACTION

    -- create a login
    INSERT INTO Signon (username, [password])
    VALUES (@userid, @password)

    select @CurrentError = @@Error

    IF @CurrentError != 0
        BEGIN
   	        GOTO ERROR_HANDLER
        END

    -- create a new profile for the user
    INSERT INTO Profile (userid, langpref, favcategory, mylistopt, banneropt)
    VALUES (@userid, @langpref, @favcategory, @mylistopt, @banneropt)

    select @CurrentError = @@Error

    IF @CurrentError != 0
        BEGIN
   	        GOTO ERROR_HANDLER
        END

    -- upadte the account record
    INSERT INTO Account (userid, email, firstname, lastname, status, addr1, addr2, city, state, zip, country, phone)
    VALUES (@userid, @email, @firstname, @lastname, 'OK', @addr1, @addr2, @city, @state, @zip, @country, @phone)

    select @CurrentError = @@Error

    IF @CurrentError != 0
        BEGIN
   	        GOTO ERROR_HANDLER
        END

    -- end of transaction
    COMMIT TRANSACTION

    -- Reset SET NOCOUNT to OFF
    SET NOCOUNT OFF

    -- return 0 to indicate success, otherwise the raised error will be returned
    RETURN 0

    ERROR_HANDLER:
        ROLLBACK TRANSACTION
        SET NOCOUNT OFF
        RETURN @CurrentError
    GO

-------------------------------------------------------------------------------
-- upAccountGetAddress
-------------------------------------------------------------------------------
CREATE PROCEDURE upAccountGetAddress
(
    @userID              varchar(80)
)
AS

    SELECT email, firstname, lastname, status, addr1, addr2, city, state, zip, country, phone
    FROM Account
    WHERE userid = @userID
    GO

-------------------------------------------------------------------------------
-- upAccountGetDetails
-------------------------------------------------------------------------------
CREATE PROCEDURE upAccountGetDetails
(
    @userID              varchar(80)
)
AS

    SELECT Account.userid, Account.email, Account.firstname, Account.lastname, 
           Account.status, Account.addr1, Account.addr2, Account.city, 
           Account.state, Account.zip, Account.country, Account.phone, 
           Profile.langpref, Profile.favcategory, Profile.mylistopt, Profile.banneropt
    FROM Account INNER JOIN Profile ON Account.userid = Profile.userid
    WHERE Account.userid = @userID
    GO

-------------------------------------------------------------------------------
-- upAccountLogin
-------------------------------------------------------------------------------
CREATE PROCEDURE upAccountLogin
(
    @username            varchar(25),
    @password            varchar(25),
    @CustomerID          varchar(25) OUTPUT
)
AS

    SELECT @CustomerID = username
    FROM signon
    WHERE username = @username AND password = @Password

    -- if the select didn't return any rows in the result,
    -- then set the customer id to an empty string to indicate a login 
    -- failure, otherwise the username will be returned to indicate
    -- a successful login	
    IF @@Rowcount < 1 
        SELECT @CustomerID = ''    
    GO

-------------------------------------------------------------------------------
-- upAccountUpdate
-------------------------------------------------------------------------------
CREATE PROCEDURE upAccountUpdate
(
    @userid              varchar(80),
    @email               varchar(80),
    @firstname           varchar(80),
    @lastname            varchar(80),    
    @addr1               varchar(80),
    @addr2               varchar(40),
    @city                varchar(80),
    @state               varchar(80),
    @zip                 varchar(20),
    @country             varchar(20),
    @phone               varchar(80),   
    @langpref            varchar(80),
    @favcategory         varchar(80),
    @mylistopt           int,
    @banneropt           int
)
AS

    -- SET NOCOUNT to ON and no longer display the count message.
    SET NOCOUNT ON

    DECLARE @CurrentError int

    -- start transaction, updating two tables
    BEGIN TRANSACTION

    UPDATE Account SET email = @email, firstname = @firstname, lastname = @lastname, addr1 = @addr1, addr2 = @addr2, city = @city,  
                       state = @state, zip = @zip, country = @country, phone = @phone
    WHERE userid = @userid

    select @CurrentError = @@Error

    IF @CurrentError != 0
        BEGIN
   	        GOTO ERROR_HANDLER
         END

    UPDATE Profile SET langpref = @langpref, favcategory = @favcategory, mylistopt = @mylistopt, banneropt = @banneropt
    WHERE userid = @userid

    select @CurrentError = @@Error

    IF @CurrentError != 0
        BEGIN
   	        GOTO ERROR_HANDLER
        END

    -- end of transaction
    COMMIT TRANSACTION

    -- Reset SET NOCOUNT to OFF
    SET NOCOUNT OFF

    -- return 0 to indicate success, otherwise the raised error will be returned
    RETURN 0

    ERROR_HANDLER:
        ROLLBACK TRANSACTION
        SET NOCOUNT OFF
        RETURN @CurrentError
    GO

-------------------------------------------------------------------------------
-- upCategoryGetList
-------------------------------------------------------------------------------
CREATE PROCEDURE upCategoryGetList

AS

    SELECT catid, [name]
    FROM Category
    ORDER BY catid
    GO

-------------------------------------------------------------------------------
-- upInventoryAdd
-------------------------------------------------------------------------------
CREATE PROCEDURE upInventoryAdd
( 
    @itemid              char(10),
    @qty                 int
)
AS

    -- insert into the item table
    INSERT INTO Inventory (itemid, qty)
    VALUES (@itemid, @qty)
    GO

-------------------------------------------------------------------------------
-- upInventoryGetList
-------------------------------------------------------------------------------
/******************************************************************************   
	Get the qty for the items in the xml document.

	Sample usage:
		
	declare @xml varchar(8000)
	set @xml = 
		'
		<Inventory>
		  <LineItem itemid="EST-1" />
		  <LineItem itemid="EST-2" />
		  <LineItem itemid="EST-3" />
		</Inventory>
		'

	exec upInventoryGetList @xml	
*******************************************************************************/
CREATE PROCEDURE upInventoryGetList
(
    @xml                 varchar(8000)
)
AS

    DECLARE @idoc int		-- xml doc
    DECLARE @orderid int	-- new order

    -- parse xml doc
    EXEC sp_xml_preparedocument @idoc output, @xml

    -- return qty for items specified in xml
    SELECT i.itemid, i.qty 
    FROM OPENXML(@idoc, '/Inventory/LineItem') 
    WITH (itemid char(10)) AS x
    INNER JOIN Inventory AS i
    ON x.itemid = i.itemid

    -- done with xml doc, remove it from memory
    EXEC sp_xml_removedocument @idoc
    GO

-------------------------------------------------------------------------------
-- upItemAdd
-------------------------------------------------------------------------------
CREATE PROCEDURE upItemAdd
( 
    @itemid              char(10),
    @productid           char(10),
    @listprice           decimal(10, 2),
    @unitcost            decimal(10, 2),
    @supplier            int,
    @status              char(2),
    @attr1               varchar(80),
    @attr2               varchar(80),
    @attr3               varchar(80),
    @attr4               varchar(80),
    @attr5               varchar(80)
)
AS

    -- insert into the item table
    INSERT INTO Item (itemid, productid, listprice, unitcost, supplier, status, attr1, attr2, attr3, attr4, attr5)
    VALUES (@itemid, @productid, @listprice, @unitcost, @supplier, @status, @attr1, @attr2, @attr3, @attr4, @attr5)
    GO

-------------------------------------------------------------------------------
-- upItemGetDetails
-------------------------------------------------------------------------------
CREATE PROCEDURE upItemGetDetails
(
    @itemID              char(10),
    @price               smallmoney output,
    @qty                 int output,
    @itemName            varchar(80) output,
    @itemAttr            varchar(80) output,
    @desc                varchar(255) output   
) 
AS

    SELECT @price = Item.listprice, @qty = Inventory.qty, 
           @itemName = Product.name, @itemAttr = Item.attr1, @desc = Product.descn
    FROM Item INNER JOIN
             Inventory ON Item.itemid = Inventory.itemid INNER JOIN
                 Product ON Item.productid = Product.productid
    WHERE (Item.itemid = @itemID)
    GO

-------------------------------------------------------------------------------
-- upItemGetList
-------------------------------------------------------------------------------
CREATE PROCEDURE upItemGetList
(
    @prodid              varchar(10)
)
AS

    SELECT itemid, listprice, attr1
    FROM Item
    WHERE productid = @prodid 
    GO  

-------------------------------------------------------------------------------
-- upItemGetList_ListByPage
-------------------------------------------------------------------------------
CREATE PROCEDURE upItemGetList_ListByPage
(
    @prodid              varchar(10),
    @nCurrentPage        int,
    @nPageSize           int,
    @totalNumResults     int output
)
AS

    -- we are creating a temporary table to store the currently
    -- selected page of data. a rowid field has been added to allow
    -- us to track which page we are on (the itemid didn't work
    -- in this case because it is a character data type and it is
    -- much easier to calculate the paging with an int)
    CREATE TABLE #SearchResultsTempTable
    (
        rowid               int           IDENTITY PRIMARY KEY,
        itemid              char(10)               NOT NULL,   
        listprice           decimal(10, 2)         NULL, 
        attr1               varchar(80)            NULL,
    )

    -- copy the search results into the temporary table
    INSERT INTO #SearchResultsTempTable (itemid, listprice, attr1)
    SELECT itemid, listprice, attr1
    FROM Item
    WHERE productid = @prodid 

    -- always return the total number of items found in the search
    SELECT @totalNumResults = @@ROWCOUNT

    -- calculate the current page
    DECLARE @nFirstPageRecord int
    DECLARE @nLastPageRecord int
    SELECT @nFirstPageRecord = (@nCurrentPage - 1) * @nPageSize
    SELECT @nLastPageRecord = ((@nCurrentPage * @nPageSize) + 1)

    -- select the correct page of data with the given page size
    SELECT itemid, listprice, attr1
    FROM #SearchResultsTempTable
    WHERE (rowid > @nFirstPageRecord) AND (rowid < @nLastPageRecord)
    GO

-------------------------------------------------------------------------------
-- upOrdersAdd
-------------------------------------------------------------------------------
/******************************************************************************
	Add order to database. Example of using this stored proc is shown below.
	
	declare @xml varchar(8000)
	set @xml = 
		'
		<Orders
		userid="j2ee" orderdate="1/1/2001" 
		shipaddr1="1234 West Branch" shipaddr2=""
		shipcity="Liveoak" shipstate="Texas"
		shipzip="12345" shipcountry="USA"
		billaddr1="5678 East Branch" billaddr2="Building C"
		billcity="Madrone" billstate="Utah"
		billzip="99999" billcountry="USA"
		courier="UPS" totalprice="57.50"
		billtofirstname="Fred" billtolastname="Derfy"
		shiptofirstname="Bob" shiptolastname="Black"
		creditcard="111-222-333" exprdate="9/2002"
		cardtype="Visa" locale="US_en">
		  <LineItem itemid="EST-1" linenum="1" quantity="4" unitprice="5.00" />
		  <LineItem itemid="EST-2" linenum="2" quantity="5" unitprice="7.00" />
		  <LineItem itemid="EST-3" linenum="3" quantity="2" unitprice="1.25" />
		</Orders>
		'

	exec upOrderAdd @xml
	
*******************************************************************************/
CREATE PROCEDURE upOrdersAdd
(
    @xml                 varchar(8000)
)
AS

    DECLARE @idoc int		-- xml doc
    DECLARE @orderid int	-- new order

    -- parse xml doc
    EXEC sp_xml_preparedocument @idoc output, @xml


    SET NOCOUNT ON
    DECLARE @CurrentError int

    -- start transaction, updating three tables
    BEGIN TRANSACTION

    -- add new order to Orders table
    INSERT INTO Orders
    SELECT userid, orderdate, shipaddr1, shipaddr2, shipcity, shipstate, 
           shipzip, shipcountry, billaddr1, billaddr2, billcity, billstate, billzip,
           billcountry, courier, totalprice, billtofirstname, billtolastname,
           shiptofirstname, shiptolastname, creditcard, exprdate, cardtype, locale
    FROM OpenXML(@idoc, '/Orders')
    WITH Orders

    -- check for error
    SELECT @CurrentError = @@Error

    IF @CurrentError != 0
        BEGIN
   	        GOTO ERROR_HANDLER
        END

    -- get new order id
    SELECT @orderid = @@IDENTITY

    -- add line items to LineItem table
    INSERT INTO LineItem
    SELECT @orderid, linenum, itemid, quantity, unitprice
    FROM OpenXML(@idoc, '/Orders/LineItem')
    WITH LineItem

    -- check for error
    SELECT @CurrentError = @@Error

    IF @CurrentError != 0
        BEGIN
   	        GOTO ERROR_HANDLER
        END

    -- add status to OrderStatus table
    INSERT INTO OrderStatus
    SELECT @orderid, @orderid, getdate(), 'P'

    -- check for error
    SELECT @CurrentError = @@Error

    IF @CurrentError != 0
        BEGIN
   	        GOTO ERROR_HANDLER
        END

    -- update inventory
    UPDATE Inventory
    SET Inventory.qty = Inventory.qty - LineItem.quantity
    FROM OpenXML(@idoc, '/Orders/LineItem')
    WITH LineItem
    WHERE Inventory.itemid=LineItem.itemid

    -- check for error
    select @CurrentError = @@Error

    IF @CurrentError != 0
        BEGIN
   	        GOTO ERROR_HANDLER
        END

    -- end of transaction
    COMMIT TRANSACTION

    SET NOCOUNT OFF

    -- done with xml doc
    EXEC sp_xml_removedocument @idoc

    -- return the new order
    RETURN @orderid

    ERROR_HANDLER:
        ROLLBACK TRANSACTION
        SET NOCOUNT OFF    
        RETURN 0    
    GO

-------------------------------------------------------------------------------
-- upOrdersGet
-------------------------------------------------------------------------------
CREATE PROCEDURE upOrdersGet
(
    @userid              varchar(80)
) 
AS

    SELECT orderid, orderdate 
    FROM orders 
    WHERE userid = @userid 
    GO

-------------------------------------------------------------------------------
-- upOrdersGetDetails
-------------------------------------------------------------------------------
CREATE PROCEDURE upOrdersGetDetails 
(
    @OrderNumber         integer,
    @OrderStatus         varchar(30) output,
    @OrderDate           datetime output,
    @ShipToAddress       varchar(80) output,
    @ShipToCity          varchar(80) output,
    @ShipToState         varchar(80) output,
    @ShipToZip           varchar(20) output,
    @BillToAddress       varchar(80) output,
    @BillToCity          varchar(80) output,
    @BillToState         varchar(80) output,
    @BillToZip           varchar(20) output,
    @TotalPrice          numeric output
) 
AS

    BEGIN TRANSACTION

    SELECT @OrderStatus = orderstatus.status, @OrderDate = orders.orderdate, @ShipToAddress =  orders.shipaddr1,
           @ShipToCity  = orders.shipcity, @ShipToState = orders.shipstate, @ShipToZip = orders.shipzip,
           @BillToAddress = orders.billaddr1, @BillToCity = orders.billcity, @BillToState = orders.billstate,
           @BillToZip = orders.billzip, @TotalPrice = orders.totalprice
    FROM ORDERS INNER JOIN
             ORDERSTATUS ON ORDERS.orderid = ORDERSTATUS.orderid
    WHERE (ORDERS.orderid = @OrderNumber);


    SELECT lineitem.linenum,
         lineitem.itemid,
         lineitem.quantity,
         lineitem.unitprice
    FROM LINEITEM
    WHERE (LINEITEM.orderid = @OrderNumber);

    COMMIT TRANSACTION;
    GO

 -------------------------------------------------------------------------------
-- upOrdersGetStatus
-------------------------------------------------------------------------------
CREATE PROCEDURE upOrderStatusGet
(
    @orderid             integer,
    @OrderStatus         char(2) OUTPUT
) 
AS

    SELECT @OrderStatus = status
    FROM OrderStatus
    WHERE (orderid = @orderid);
    GO

-------------------------------------------------------------------------------
-- upProductAdd
-------------------------------------------------------------------------------
CREATE PROCEDURE upProductAdd
( 
    @productid           char(10),
    @category            char(10),
    @name                varchar(80),
    @descn               varchar(255)
)
AS

    -- insert into the product table
    INSERT INTO Product (productid, category, [name],descn)
    VALUES(@productid, @category, @name, @descn)
    GO

-------------------------------------------------------------------------------
-- upProductGetList
-------------------------------------------------------------------------------
CREATE PROCEDURE upProductGetList
(
	    @cat_id              char(10)
)
AS

    SELECT productid, name
    FROM Product
    WHERE category = @cat_id
    ORDER BY name
    GO

-------------------------------------------------------------------------------
-- upProductGetList_ListByPage
-------------------------------------------------------------------------------
CREATE PROCEDURE upProductGetList_ListByPage
(
    @cat_id              char(10),
    @nCurrentPage        int,
    @nPageSize           int,
    @totalNumResults     int output
)
AS

    -- we are creating a temporary table to store the currently
    -- selected page of data. a rowid field has been added to allow
    -- us to track which page we are on (the productid didn't work
    -- in this case because it is a character data type and it is
    -- much easier to calculate the paging with an int)
    CREATE TABLE #ProductCategoryTempTable
    (
        rowid               int           IDENTITY PRIMARY KEY,
        productid           char(10)               NOT NULL,
        name                varchar(80)            NULL
    )

    -- copy the search results into the temporary table
    INSERT INTO #ProductCategoryTempTable (productid, name)
    SELECT productid, name
    FROM Product
    WHERE category = @cat_id
    ORDER BY name

    -- always return the total number of items found in the search
    SELECT @totalNumResults = @@ROWCOUNT

    -- calculate the current page
    DECLARE @nFirstPageRecord int
    DECLARE @nLastPageRecord int
    SELECT @nFirstPageRecord = (@nCurrentPage - 1) * @nPageSize
    SELECT @nLastPageRecord = ((@nCurrentPage * @nPageSize) + 1)

    -- select the correct page of data with the given page size
    SELECT productid, name
    FROM #ProductCategoryTempTable
    WHERE (rowid > @nFirstPageRecord) AND (rowid < @nLastPageRecord)
    GO

-------------------------------------------------------------------------------
-- upProductSearch
-------------------------------------------------------------------------------
CREATE PROCEDURE upProductSearch
(
	    @Search              nvarchar(255)
)
AS
    DECLARE @_name varchar(50) 
    SET @_name = '%' + @Search + '%'

    SELECT productid, [name], descn
    FROM Product
    WHERE 
    (
        --search the product name field
        [name] like (@_name)
       OR
       
       -- search the products category field
       category like  (@_name)
    )
    GO

-------------------------------------------------------------------------------
-- upProductSearch_ListByPage
-------------------------------------------------------------------------------
CREATE PROCEDURE upProductSearch_ListByPage
(
    @searchText          varchar(255),
    @nCurrentPage        int,
    @nPageSize           int,
    @nSearchResults      int output
)
AS

    -- we are creating a temporary table to store the currently
    -- selected page of data. a rowid field has been added to allow
    -- us to track which page we are on (the productid didn't work
    -- in this case because it is a character data type and it is
    -- much easier to calculate the paging with an int
    CREATE TABLE #SearchResultsTempTable
    (
        rowid               int           IDENTITY PRIMARY KEY,
        productid           char(10)               NOT NULL,
        [name]              varchar(80)            NULL,
        descn               varchar(255)           NULL
    )

    -- copy the search results into the temporary table    
    DECLARE @_name varchar(50) 
    SET @_name = '%' + @searchText + '%'	
    INSERT INTO #SearchResultsTempTable (productid, [name], descn)
    SELECT productid, [name], descn
    FROM Product
    WHERE 
    (
        --search the product name field
        [name] like (@_name)
       OR
       
       -- search the products category field
       category like  (@_name)
    )
        
    -- always return the total number of items found in the search
    SELECT @nSearchResults = @@ROWCOUNT

    -- calculate the current page
    DECLARE @nFirstPageRecord int
    DECLARE @nLastPageRecord int
    SELECT @nFirstPageRecord = (@nCurrentPage - 1) * @nPageSize
    SELECT @nLastPageRecord = ((@nCurrentPage * @nPageSize) + 1)

    -- select the correct page of data with the given page size
    SELECT productid, [name], descn
    FROM #SearchResultsTempTable
    WHERE (rowid > @nFirstPageRecord) AND (rowid < @nLastPageRecord)
    GO

-------------------------------------------------------------------------------
-- upProfileGetBannerOption
-------------------------------------------------------------------------------
CREATE PROCEDURE upProfileGetBannerOption
(
        @userID              varchar(80),
        @showBanner          int output,
        @bannerPath          varchar(80) output
)
AS

    SELECT @showBanner = Profile.banneropt, @bannerPath = BannerData.bannername
    FROM Profile INNER JOIN
            BannerData ON Profile.favcategory = BannerData.favcategory
    WHERE Profile.userid = @userID
    GO

-------------------------------------------------------------------------------
-- upProfileGetListOption
-------------------------------------------------------------------------------
CREATE PROCEDURE upProfileGetListOption
(
        @userID              varchar(80),
        @showList            int output,
        @cat                 varchar(80) output
)
AS

    SELECT @showList = Profile.mylistopt, @cat = favcategory
    FROM Profile
    WHERE Profile.userid = @userID 
    GO