using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using PetShop.Components;

namespace PetShop.Web {

	/// <summary>
	/// Display shopping cart and perform actions on cart (add and remove items).
	/// </summary>
	public class Cart : System.Web.UI.Page {
		protected System.Web.UI.HtmlControls.HtmlForm form;
		protected System.Web.UI.HtmlControls.HtmlGenericControl areaEmpty;
		protected System.Web.UI.HtmlControls.HtmlGenericControl areaCart;

		private void Page_Load(object sender, System.EventArgs e) {

			if (Page.IsPostBack == false) {
				// make sure user has a shopping cart
				if (Session["ShoppingCartSession"] == null)
					Session["ShoppingCartSession"] = new ShoppingCart();
				
				// determine what action to perform
				switch (Request.QueryString["action"]) {
					case "purchaseItem":
						AddItem(Request.QueryString["itemId"]);
						break;
						
					case "removeItem":
						RemoveItem(Request.QueryString["itemId"]);
						break;
						
					default:
						ShowCart();
						break;
				}
			}
		}

		// add specified item to cart
		private void AddItem(string itemID) {
			// hold info about item to add to cart
			double price;
			int qty;
			string itemName;
			string itemAttr;
			string itemDesc;
			bool inStock;

			// get details about item			
			Item item = new Item();
			item.GetDetails(itemID, out price, out qty, out itemName, out itemAttr, out itemDesc);
			inStock = qty > 0 ? true : false;

			// add new item to cart
			ShoppingCart cart = (ShoppingCart)Session["ShoppingCartSession"];
			cart.Add(new BasketItem(itemID, itemName, inStock, 1, price));
			
			// display the udpated cart
			ShowCart();
		}
		
		// remove specified item form cart
		private void RemoveItem(string itemID) {
			// remove the item from the cart
			ShoppingCart cart = (ShoppingCart)Session["ShoppingCartSession"];
			cart.Remove(itemID);

			// display the udpated cart
			ShowCart();
		}

		// display the cart
		private void ShowCart() {
			// see if we have any items in the cart
			ShoppingCart cart = (ShoppingCart)Session["ShoppingCartSession"];
			if ((cart != null) && (cart.Count > 0)) {
				// display the cart, hide the empty message
				areaCart.Visible = true;
				areaEmpty.Visible = false;
			}
			else {
				// the cart is empty, display empty message
				areaCart.Visible = false;
				areaEmpty.Visible = true;
			}
		}

		// capture event from cart user control, we need to be notified
		// when items are removed from the cart (handled in the user control)
		// so we can update show our 'cart is empty' message if all items
		// are removed		
		protected override bool OnBubbleEvent(object source, EventArgs e) {
			ShowCart();
			return false;
		}

		#region Web Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {    
			this.Load += new System.EventHandler(this.Page_Load);

		}

		private void Page_Init(object sender, EventArgs e) {
			InitializeComponent();
		}

		public Cart() {
			Page.Init += new System.EventHandler(Page_Init);
		}
		#endregion
	}
}
