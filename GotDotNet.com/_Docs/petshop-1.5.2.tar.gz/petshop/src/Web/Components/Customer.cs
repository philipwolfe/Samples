using System;
using System.Data;
using System.Data.SqlClient;

namespace PetShop.Components {
	/// <summary>
	/// Account management and login verification.
	/// </summary>
	public class Customer {
		/// <summary>
		/// The Login method validates a username/password pair against 
		/// credentials stored in the customers database. If the 
		/// username/password pair is valid, the method returns the 
		/// "CustomerId" number of the customer. Otherwise it will throw 
		/// an exception.
		/// </summary>
		/// <param name="userName">User name of the customer</param>
		/// <param name="password">Customer's password</param>
		/// <returns>If the login was sucessful the user name is returned, 
		/// otherwise null will be returned to the caller.</returns>		
		public string Login(string userName, string password) {
			string customerID;

			// params to stored proc
			Database data = new Database();
			SqlParameter[] prams = {
				data.MakeInParam("@username",    SqlDbType.VarChar, 25, userName),
				data.MakeInParam("@password",    SqlDbType.VarChar, 25, password),
				data.MakeOutParam("@CustomerID", SqlDbType.VarChar, 25)
			};

			// create data object and params
			data.RunProc("upAccountLogin", prams);    // run the stored procedure
			customerID = (string) prams[2].Value;     // get the output param value

			// if the customer id is an empty string, then the login failed
			if (customerID == string.Empty)
				return null;
			else
				return customerID;
		}

		/// <summary>
		/// Creates a new customer account in the database.
		/// </summary>
		/// <param name="userid">Customer ID.</param>
		/// <param name="password">User's password.</param>
		/// <param name="email">Email address.</param>
		/// <param name="firstName">First name.</param>
		/// <param name="lastName">Last name.</param>
		/// <param name="address1">Address line.</param>
		/// <param name="address2">Additional Address line.</param>
		/// <param name="city">City.</param>
		/// <param name="state">Sate.</param>
		/// <param name="zip">Postal code.</param>
		/// <param name="country">Country name.</param>
		/// <param name="phone">Telephone number.</param>
		/// <param name="languagePref">Language perference.</param>
		/// <param name="favoriteCategory">The user's favorite pet category.</param>
		/// <param name="mylistOption">User preference for displaying the pet favorites list.</param>
		/// <param name="bannerOptions">User preference for displaying an ad banner.</param>
		/// <returns>If the account creation was sucessful the user name is 
		/// returned, otherwise null is returned to the caller.</returns>
		public string Add(string userid, string password, string email, string firstName, 
			string lastName, string address1, string address2, 
			string city, string state, string zip, string country, 
			string phone, string languagePref, string favoriteCategory, 
			int mylistOption, int bannerOptions) {		
			// create data object and params
			Database data = new Database();
						
			SqlParameter[] prams = {
				data.MakeInParam("@userid",      SqlDbType.VarChar, 80, userid),
				data.MakeInParam("@password",    SqlDbType.VarChar, 25, password),
				data.MakeInParam("@email",       SqlDbType.VarChar, 80, email),
				data.MakeInParam("@firstname",   SqlDbType.VarChar, 80, firstName),
				data.MakeInParam("@lastname",    SqlDbType.VarChar, 80, lastName),
				data.MakeInParam("@addr1",       SqlDbType.VarChar, 80, address1),
				data.MakeInParam("@addr2",       SqlDbType.VarChar, 80, address2),
				data.MakeInParam("@city",        SqlDbType.VarChar, 80, city),
				data.MakeInParam("@state",       SqlDbType.VarChar, 20, state),
				data.MakeInParam("@zip",         SqlDbType.VarChar, 20, zip),
				data.MakeInParam("@country",     SqlDbType.VarChar, 80, country),
				data.MakeInParam("@phone",       SqlDbType.VarChar, 80, phone),
				data.MakeInParam("@langpref",    SqlDbType.VarChar, 25, languagePref),
				data.MakeInParam("@favcategory", SqlDbType.VarChar, 25, favoriteCategory),
				data.MakeInParam("@mylistopt",   SqlDbType.Int,      4, mylistOption),
				data.MakeInParam("@banneropt",   SqlDbType.Int,      4, bannerOptions)
			};

			try {
				// run the stored procedure and return an ADO.NET DataReader
				int retval = data.RunProc("upAccountAdd", prams);

				// if the customer id is an empty string, then the create failed
				if (retval == 0 ) 
					return userid;
				else 
					return null;
			}
			catch (Exception ex) {
				Error.Log(ex.ToString());
				return null;
			}
		}

		/// <summary>
		/// Updates a customer account in the database.
		/// </summary>
		/// <param name="email">Email address.</param>
		/// <param name="firstName">First name.</param>
		/// <param name="lastName">Last name.</param>
		/// <param name="address1">Address line.</param>
		/// <param name="address2">Additional Address line.</param>
		/// <param name="city">City.</param>
		/// <param name="state">Sate.</param>
		/// <param name="zip">Postal code.</param>
		/// <param name="country">Country name.</param>
		/// <param name="phone">Telephone number.</param>
		/// <param name="languagePref">Language perference.</param>
		/// <param name="favoriteCategory">The user's favorite pet category.</param>
		/// <param name="mylistOption">User preference for displaying the pet favorites list.</param>
		/// <param name="bannerOptions">User preference for displaying an ad banner.</param>
		public void UpdateAccount(string userid, string email, string firstName, 
			string lastName, string address1, string address2, 
			string city, string state, string zip, string country, 
			string phone, string languagePref, string favoriteCategory, 
			int mylistOption, int bannerOptions) {		
			// create data object and params
			Database data = new Database();
			SqlParameter[] prams = {
				data.MakeInParam("@userid",      SqlDbType.VarChar, 80, userid),
				data.MakeInParam("@email",       SqlDbType.VarChar, 80, email),
				data.MakeInParam("@firstname",   SqlDbType.VarChar, 80, firstName),
				data.MakeInParam("@lastname",    SqlDbType.VarChar, 80, lastName),
				data.MakeInParam("@addr1",       SqlDbType.VarChar, 80, address1),
				data.MakeInParam("@addr2",       SqlDbType.VarChar, 80, address2),
				data.MakeInParam("@city",        SqlDbType.VarChar, 80, city),
				data.MakeInParam("@state",       SqlDbType.VarChar, 20, state),
				data.MakeInParam("@zip",         SqlDbType.VarChar, 20, zip),
				data.MakeInParam("@country",     SqlDbType.VarChar, 80, country),
				data.MakeInParam("@phone",       SqlDbType.VarChar, 80, phone),
				data.MakeInParam("@langpref",    SqlDbType.VarChar, 25, languagePref),
				data.MakeInParam("@favcategory", SqlDbType.VarChar, 25, favoriteCategory),
				data.MakeInParam("@mylistopt",   SqlDbType.Int,      4, mylistOption),
				data.MakeInParam("@banneropt",   SqlDbType.Int,      4, bannerOptions)
			};

			// run the stored proc
			try {
				data.RunProc("upAccountUpdate", prams);
			}
			catch (Exception ex) {
				Error.Log(ex.ToString());
			}
		}

		/// <summary>
		/// Gets the customer's account details.
		/// </summary>
		/// <param name="userID">Customer's user id</param>
		/// <returns>CustomerDetails object</returns>
		public CustomerDetails GetDetails(string userID) {
			// create data object and params
			SqlDataReader dataReader = null;
			Database data = new Database();
			SqlParameter[] prams = { data.MakeInParam("@userID", SqlDbType.Char, 80, userID) };
   		
			try {
				// run the stored procedure and return an ADO.NET DataReader
				data.RunProc("upAccountGetDetails", prams, out dataReader);

				CustomerDetails customerDetails = new CustomerDetails();
				
				// populate the customer detail object from the SQL Server Data Reader
				if (dataReader.Read()) {
					customerDetails.userid      = dataReader.GetString(0);
					customerDetails.email       = dataReader.GetString(1);
					customerDetails.firstname   = dataReader.GetString(2);
					customerDetails.lastname    = dataReader.GetString(3);
					customerDetails.status      = dataReader.GetString(4);
					customerDetails.addr1       = dataReader.GetString(5);
					customerDetails.addr2       = dataReader.GetString(6);
					customerDetails.city        = dataReader.GetString(7);
					customerDetails.state       = dataReader.GetString(8);
					customerDetails.zip         = dataReader.GetString(9);
					customerDetails.country     = dataReader.GetString(10);
					customerDetails.phone       = dataReader.GetString(11);
					customerDetails.langpref    = dataReader.GetString(12);
					customerDetails.favcategory = dataReader.GetString(13);
					customerDetails.mylistopt   = dataReader.GetInt32(14);
					customerDetails.banneropt   = dataReader.GetInt32(15);

					dataReader.Close();

					return customerDetails;
				}
				else
					return null;				
			}
			catch (Exception ex) {
				Error.Log(ex.ToString());
				return null;
			}
			finally	{
				dataReader.Close();
			}
		}

		/// <summary>
		/// Gets the customer's address.
		/// </summary>
		/// <param name="userID">Customer's user id.</param>
		/// <returns>ADO.NET SQL Server Data reader.</returns>
		public CustomerAddress GetAddress(string userID) {
			// create data object and params
			SqlDataReader dataReader = null;
			Database data = new Database();
			SqlParameter[] prams = { data.MakeInParam("@userID", SqlDbType.Char, 80, userID) };

			try {
				// run the stored procedure and return an ADO.NET DataReader
				data.RunProc("upAccountGetAddress", prams, out dataReader);

				CustomerAddress customerAddress = new CustomerAddress();
				
				// populate the customer detail object from the SQL Server Data Reader
				if (dataReader.Read()) {
					customerAddress.userid      = userID;
					customerAddress.email       = dataReader.GetString(0);
					customerAddress.firstname   = dataReader.GetString(1);
					customerAddress.lastname    = dataReader.GetString(2);
					customerAddress.status      = dataReader.GetString(3);
					customerAddress.addr1       = dataReader.GetString(4);
					customerAddress.addr2       = dataReader.GetString(5);
					customerAddress.city        = dataReader.GetString(6);
					customerAddress.state       = dataReader.GetString(7);
					customerAddress.zip         = dataReader.GetString(8);					
					customerAddress.country     = dataReader.GetString(9);
					customerAddress.phone       = dataReader.GetString(10);

					dataReader.Close();

					return customerAddress;
				}
				else
					return null;				
			}
			catch (Exception ex) {
				Error.Log(ex.ToString());
				return null;
			}
			finally	{
				dataReader.Close();
			}

		}
		
		/// <summary>
		/// Represents a customer account and profile infromation. The class 
		/// is implemented using public properties to allow for easy Data 
		/// Binding in the presentation tier (in the ASP.NET WebForms).
		/// </summary>
		public class CustomerDetails 
		{
			// private member variables
			private string m_userid;
			private string m_email;
			private string m_firstname;
			private string m_lastname;
			private string m_status;
			private string m_addr1;
			private string m_addr2;
			private string m_city;
			private string m_state;
			private string m_zip;
			private string m_country;
			private string m_phone;
			private string m_langpref;
			private string m_favcategory;
			private int m_mylistopt;
			private int m_banneropt;

			// user name
			public string userid {
				get { return m_userid; }
				set { m_userid = value; }
			}

			public string email {
				get { return m_email; }
				set { m_email = value; }
			}

			// address infromation
			public string firstname {
				get { return m_firstname; }
				set { m_firstname = value; }
			}

			public string lastname {
				get { return m_lastname; }
				set { m_lastname = value; }
			}

			public string status {
				get { return m_status; }
				set { m_status = value; }
			}

			public string addr1 {
				get { return m_addr1; }
				set { m_addr1 = value; }
			}

			public string addr2 {
				get { return m_addr2; }
				set { m_addr2 = value; }
			}

			public string city {
				get { return m_city; }
				set { m_city = value; }
			}

			public string state {
				get { return m_state; }
				set { m_state = value; }
			}

			public string zip {
				get { return m_zip; }
				set { m_zip = value; }
			}

			public string country {
				get { return m_country; }
				set { m_country = value; }
			}

			public string phone {
				get { return m_phone; }
				set { m_phone = value; }
			}

			// profile values
			public string langpref {
				get { return m_langpref; }
				set { m_langpref = value; }
			}

			public string favcategory {
				get { return m_favcategory; }
				set { m_favcategory = value; }
			}

			public int mylistopt {
				get { return m_mylistopt; }
				set { m_mylistopt = value; }
			}

			public int banneropt {
				get { return m_banneropt; }
				set { m_banneropt = value; }
			}
		}

		/// <summary>
		/// Represents a customer address. The class is implemented 
		/// using public properties to allow for easy Data Binding 
		/// in the presentation tier (in the ASP.NET WebForms).
		/// </summary>
		public class CustomerAddress {
			// private member variables
			private string m_userid;
			private string m_email;
			private string m_firstname;
			private string m_lastname;
			private string m_status;
			private string m_addr1;
			private string m_addr2;
			private string m_city;
			private string m_state;
			private string m_zip;
			private string m_country;
			private string m_phone;

			// user name
			public string userid {
				get { return m_userid; }
				set { m_userid = value; }
			}

			public string email {
				get { return m_email; }
				set { m_email = value; }
			}

			// address infromation
			public string firstname {
				get { return m_firstname; }
				set { m_firstname = value; }
			}

			public string lastname {
				get { return m_lastname; }
				set { m_lastname = value; }
			}

			public string status {
				get { return m_status; }
				set { m_status = value; }
			}

			public string addr1 {
				get { return m_addr1; }
				set { m_addr1 = value; }
			}

			public string addr2 {
				get { return m_addr2; }
				set { m_addr2 = value; }
			}

			public string city {
				get { return m_city; }
				set { m_city = value; }
			}

			public string state {
				get { return m_state; }
				set { m_state = value; }
			}

			public string zip {
				get { return m_zip; }
				set { m_zip = value; }
			}

			public string country {
				get { return m_country; }
				set { m_country = value; }
			}

			public string phone {
				get { return m_phone; }
				set { m_phone = value; }
			}
		}
	}
}
