using System;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;

namespace PetShop.Components {
	/// <summary>
	/// Online orders transactions.
	/// </summary>
	public class Order {
		/// <summary>
		/// Adds a new order to the database.
		/// </summary>
		/// <param name="xml">The order xml doc.</param>
		/// <returns>The new order id.</returns>
		public int Add(string xml) {
			try {
				// create data object and params
				Database data = new Database();
				SqlParameter[] prams = { data.MakeInParam("@xml", SqlDbType.VarChar, 8000, xml) };
				
				// run the stored procedure
				return data.RunProc("upOrdersAdd", prams);
			}
			catch (Exception ex) {
				Error.Log(ex.ToString());
				return 0;
			}
		}

		/// <summary>
		/// Gets the list of orders for a specified user.
		/// </summary>
		/// <param name="userid">The customer's user id.</param>
		/// <returns>A SQL Data Reader containing the list of orders.</returns>
		public SqlDataReader GetOrder(string userid) {
			// create data object and params
			SqlDataReader dataReader = null;
			Database data = new Database();

			SqlParameter[] prams = { data.MakeInParam("@userid", SqlDbType.VarChar, 80, userid) };
   
			try {
				// run the stored procedure
				data.RunProc("upOrdersGet", prams, out dataReader);
				return dataReader;
			}
			catch (Exception ex) {
				Error.Log(ex.ToString());
				return null;
			}
		}

		/// <summary>
		/// Returns the order status for the given order number.
		/// </summary>
		/// <param name="orderid">The customer's order number.</param>
		/// <returns>If the order status is valid a string with the order
		/// status is returned, otherwise null is returned.</returns>
		public string GetOrderStatus(string orderid) {
			string orderStatus;

			// create data object and params
			Database data = new Database();

			SqlParameter[] prams = {
				data.MakeInParam("@orderid", SqlDbType.VarChar, 80, orderid),
				data.MakeOutParam("@OrderStatus", SqlDbType.Char, 2)
			};

			try {
				data.RunProc("upOrderStatusGet", prams);    // run the stored procedure
				orderStatus = (string) prams[1].Value;      // get the output param value

				// if the order status is an empty string, then the lookup failed
				if (orderStatus == string.Empty)
					return null;
				else
					return orderStatus;
			}
			catch (Exception ex) {
				Error.Log(ex.ToString());
				return null;
			}
		}
	}
}
