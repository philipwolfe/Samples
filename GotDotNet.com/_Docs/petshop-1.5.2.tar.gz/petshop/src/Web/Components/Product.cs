using System;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;

namespace PetShop.Components {
	/// <summary>
	/// A product in the catalog.
	/// </summary>
	public class Product {
		/// <summary>
		///  List all the products. If the amount of data coming back is 
		///  large, consider using GetList_ListByPage().
		/// </summary>
		/// <param name="catid">Product category.</param>
		/// <returns>Data reader.</returns>
		public SqlDataReader GetList(string catid) {
			SqlDataReader dataReader = null;

			try {
				// make database call
				Database data = new Database();
				SqlParameter[] prams = { data.MakeInParam("@cat_id", SqlDbType.Char, 10, catid) };
				data.RunProc("upProductGetList", prams, out dataReader);
			}
			catch (Exception ex) {
				Error.Log(ex.ToString());
			}

			return dataReader;
		}

		/// <summary>
		/// Get list of products.
		/// </summary>
		/// <param name="catid">Product category</param>
		/// <param name="currentPage">Page result set to return</param>
		/// <param name="pageSize">Size of result set to return</param>
		/// <param name="numResults">Total number of items in list</param>
		/// <returns>Result set</returns>
		public ProductResults[] GetList(string catid, int currentPage, int pageSize, ref int numResults) 
		{
			numResults = 0;
			int index=0;
			SqlDataReader reader = GetList(catid);
			ProductResults[] results = new ProductResults[pageSize];
			
			// now loop through the list and pull out items of the specified page
			int start = (int)((currentPage - 1) * pageSize);
			if (start <= 0) start = 1;

			// skip 
			for (int i = 0; i < start - 1; i++) {
				if (reader.Read()) numResults++;
			}
			if (start > 1) reader.Read();

			// read the data we are interested in
			while (reader.Read()) {
				if (index < pageSize) {
					results[index] = new ProductResults();
					results[index].productid = reader.GetString(0);
					results[index].name =  reader.GetString(1);
					index++;
				}
				numResults++;   
			}

			reader.Close();

			// see if need to redim array
			if (index == pageSize)
				return results;
			else {
				// not a full page, redim array
				ProductResults[] results2 = new ProductResults[index];
				Array.Copy(results, results2, index);
				return results2;
			}				
		}

		/// <summary>
		/// Searches the product catalog for the specified keyword provided 
		/// by the user.
		/// </summary>
		/// <param name="searchText">Search criteria</param>
		/// <returns>A SqlDtaReader that contains the search results</returns>
		public SqlDataReader Search(string searchText) {
			// create data object and params
			SqlDataReader dataReader = null;

			try {
				// setup to call stored procedure
				Database data = new Database();
				SqlParameter[] prams = {data.MakeInParam("@Search", SqlDbType.VarChar, 255, searchText)};
	   
				// run the stored procedure
				data.RunProc("upProductSearch", prams, out dataReader);
			}
			catch (Exception ex) {
				Error.Log(ex.ToString());
			}

			return dataReader;
		}

		/// <summary>
		/// Searches the product catalog for the specified keyword provided 
		/// by the user.
		/// </summary>
		/// <param name="searchText">Search criteria</param>
		/// <param name="currentPage">Result set that is returned</param>
		/// <param name="pageSize">Size of result set</param>
		/// <param name="numResults">Total number of items returned for search</param>
		/// <returns>Result set</returns>
		public SearchResults[] Search(string searchText, int currentPage, int pageSize, ref int numResults) {
			numResults = 0;
			int index = 0;
			SearchResults[] results = new SearchResults[pageSize];
			SqlDataReader reader = Search(searchText);			

			int start = (int)((currentPage - 1) * pageSize);
			if (start <= 0) start = 1;

			// skip 
			for (int i = 0; i < start - 1; i++) {
				if (reader.Read()) numResults++;				
			}
			if (start > 1) {
				reader.Read();
				numResults++;
			}

			// read the data we are interested in
			while (reader.Read()) {
				if (index < pageSize) {
					results[index] = new SearchResults();
					results[index].productid = reader.GetString(0);
					results[index].name =  reader.GetString(1);
					results[index].descn = reader.GetString(2);
					index++;
				}
				numResults++;   
			}
			reader.Close();

			// see if need to redim array
			if (index == pageSize)
				return results;
			else {
				// not a full page, redim array
				SearchResults[] results2 = new SearchResults[index];
				Array.Copy(results, results2, index);
				return results2;
			}				
		}
	}

	/// <summary>
	/// Contains the result of a catalog search.
	/// </summary>
	public class SearchResults {
		private string m_productid;
		private string m_name;
		private string m_descn;

		// search props	
		public string productid {
			get { return m_productid; }
			set { m_productid = value; }  
		}

		public string name {
			get { return m_name; }
			set { m_name = value; }  
		}

		public string descn {
			get { return m_descn; }
			set { m_descn = value; }  
		}
	}

	/// <summary>
	/// Represents the products in the catalog.
	/// </summary>
	public class ProductResults 
	{
		private string m_productid;
		private string m_name;

		// product props
		public string productid {
			get { return m_productid; }
			set { m_productid = value; }  
		}

		public string name {
			get { return m_name; }
			set { m_name = value; }  
		}
	}

	/// <summary>
	/// Represents the product variants in the catalog.
	/// </summary>
	public class ItemResults {
		private string m_itemid;
		private decimal m_listprice;
		private string m_attr1;

		// item props
		public string itemid {
			get { return m_itemid; }
			set { m_itemid = value; }
		}

		public decimal listprice {
			get { return m_listprice; }
			set { m_listprice = value; }
		}

		public string attr1 {
			get { return m_attr1; }
			set { m_attr1 = value; }
		}
	}
}
