using System;
using System.Collections;
using System.Diagnostics;
using System.Data;
using System.Data.SqlClient;

namespace PetShop.Components {
	/// <summary>
	/// Shopping cart functions.
	/// </summary>
	public class ShoppingCart { 
		// private members
		private ArrayList alShoppingCart = new ArrayList();

		/// <summary>
		/// Total number of items in the cart.
		/// </summary>
		public int Count {
			get	{ return alShoppingCart.Count; }						
		}

		/// <summary>
		/// Total price of all items.
		/// </summary>
		public double Total {
			get { 
				if (alShoppingCart.Count == 0)
					return 0.0;

				double total = 0;

				foreach (BasketItem i in alShoppingCart)
					total += i.Price * i.Qty;
            
				return total;
			}
		}

		/// <summary>
		/// Return collection of items, can be bound to list.
		/// </summary>
		/// <returns>Collection of items in cart.</returns>
		public ICollection GetItems() {
			return alShoppingCart;
		}

		/// <summary>
		/// Return item at specified index.
		/// </summary>
		public BasketItem this[int index] {
			get {
				return (BasketItem)alShoppingCart[index];
			}
		}

		/// <summary>
		/// Remove all items from cart.
		/// </summary>
		public void ClearCart() {
			alShoppingCart.Clear();
		}

		/// <summary>
		/// Add item to cart.
		/// </summary>
		/// <param name="value">New item to add.</param>
		public void Add(BasketItem value) {
			// see if this product is already in the cart
			foreach (BasketItem i in alShoppingCart) {
				if (i.ItemID == value.ItemID) {
					// item is already in cart, bump qty up by one
					// and recalculate in stock value
					i.Qty++;
					UpdateInStock();
					return;
				}
			}
      
			// if we've fallen through to here, add to cart
			alShoppingCart.Add(value);
		}

		/// <summary>
		/// Remove item from cart.
		/// </summary>
		/// <param name="index">Index of item to remove.</param>
		public void RemoveAt(int index) {
			alShoppingCart.RemoveAt(index);
		}

		/// <summary>
		/// Remove item from cart.
		/// </summary>
		/// <param name="itemID">Item to remove.</param>
		public void Remove(string itemID) {
			// loop through list and look for item
			foreach (BasketItem item in alShoppingCart) {
				if (item.ItemID == itemID) {	
					// found item, remove it from list
					alShoppingCart.Remove(item);
					return;
				}
			}
		}

		/// <summary>
		/// Return XML string for all items in cart.
		/// </summary>
		/// <returns>XML string of items in cart.</returns>
		public string GetLineItemsXML() {
			string xml="";
			int itemNum = 1;

			// go through each item in cart and build up xml string
			foreach (BasketItem item in alShoppingCart) {
				xml += "<LineItem itemid='" + item.ItemID + 
					"' linenum='" + itemNum++ + 
					"' quantity='" + item.Qty + 
					"' unitprice='" + item.Price + 
					"' />";
			}
			
			return xml;
		}

		/// <summary>
		/// Updates the InStock property for each item in the basket.
		/// This requires a call to the database to get the inventory.
		/// </summary>
		public void UpdateInStock() {
			try {
				// create xml string to pass to stored proc
				string xml = "<Inventory>";
				foreach (BasketItem i in alShoppingCart)
					xml += "<LineItem itemid='" + i.ItemID + "' />";
				xml += "</Inventory>";
			
				// get inventory info for items
				SqlDataReader dataReader=null;
				Database data = new Database();
				SqlParameter[] prams = { data.MakeInParam("@xml", SqlDbType.VarChar, 8000, xml) };
				data.RunProc("upInventoryGetList", prams, out dataReader);

				// go through and update the InStock prop of each item
				int index=0;
				BasketItem item;
				while (dataReader.Read()) {
					item = (BasketItem)alShoppingCart[index++];
					item.InStock = ((int)dataReader["qty"] - item.Qty) >= 0 ? true : false;
				}
				
				dataReader.Close();
			}
			catch (Exception ex) {
				Error.Log(ex.ToString());
			}
		}
	}
}


