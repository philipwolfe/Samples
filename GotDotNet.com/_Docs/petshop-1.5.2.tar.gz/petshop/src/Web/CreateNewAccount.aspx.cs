using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.Security;
using PetShop.Components;

namespace PetShop.Web {
	/// <summary>
	/// Create a new user account.
	/// </summary>
	public class CreateNewAccount : System.Web.UI.Page {
		protected System.Web.UI.WebControls.TextBox txtEmail;
		protected System.Web.UI.WebControls.TextBox txtFirstName;
		protected System.Web.UI.WebControls.RequiredFieldValidator valFirstName;
		protected System.Web.UI.WebControls.TextBox txtLastName;
		protected System.Web.UI.WebControls.RequiredFieldValidator valLastName;
		protected System.Web.UI.WebControls.TextBox txtAddress1;
		protected System.Web.UI.WebControls.RequiredFieldValidator valAddress1;
		protected System.Web.UI.WebControls.TextBox txtAddress2;
		protected System.Web.UI.WebControls.TextBox txtCity;
		protected System.Web.UI.WebControls.RequiredFieldValidator valCity;
		protected System.Web.UI.WebControls.DropDownList listState;
		protected System.Web.UI.WebControls.TextBox txtPostalCode;
		protected System.Web.UI.WebControls.RequiredFieldValidator valPostalCode;
		protected System.Web.UI.WebControls.DropDownList listCountry;
		protected System.Web.UI.WebControls.TextBox txtTelephoneNumber;
		protected System.Web.UI.WebControls.RequiredFieldValidator valTelephoneNumber;
		protected System.Web.UI.WebControls.DropDownList listLanguagePref;
		protected System.Web.UI.WebControls.DropDownList listFavoriteCategory;
		protected System.Web.UI.WebControls.CheckBox cbShowMyList;
		protected System.Web.UI.WebControls.TextBox txtUserName;
		protected System.Web.UI.WebControls.TextBox txtPassword;
		protected System.Web.UI.WebControls.RequiredFieldValidator valUserName1;
		protected System.Web.UI.WebControls.RequiredFieldValidator valPassword;
		protected System.Web.UI.WebControls.RequiredFieldValidator valEmail;
		protected System.Web.UI.WebControls.ImageButton btnSubmit;
		protected System.Web.UI.WebControls.CheckBox cbShowBanners;

		#region Web Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {    
			this.btnSubmit.Click += new System.Web.UI.ImageClickEventHandler(this.btnSubmit_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		public CreateNewAccount() {
			Page.Init += new System.EventHandler(Page_Init);
		}

		private void Page_Load(object sender, System.EventArgs e) {
			if (!IsPostBack)
				PopulateListView();
		}

		private void Page_Init(object sender, EventArgs e) {
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
		}

		// create the account
		private string CreateAccount() {
			Customer customer = new Customer();
			string retval = customer.Add(txtUserName.Text, txtPassword.Text, txtEmail.Text, txtFirstName.Text, 
				txtLastName.Text, txtAddress1.Text, txtAddress2.Text, 
				txtCity.Text, listState.SelectedItem.Text, txtPostalCode.Text,
				listCountry.SelectedItem.Text, txtTelephoneNumber.Text, 
				listLanguagePref.SelectedItem.Text, 
				listFavoriteCategory.SelectedItem.Value, 
				(cbShowMyList.Checked==true) ? 1 : 0, 
				(cbShowBanners.Checked==true) ? 1 : 0);	

			return(retval);
		}
       
		// init list items
		private void PopulateListView() {
			listState.Items.Clear();
			listState.Items.Add(new ListItem("California", "California"));
			listState.Items.Add(new ListItem("New York", "New York"));
			listState.Items.Add(new ListItem("Texas", "Texas"));

			listCountry.Items.Clear();
			listCountry.Items.Add(new ListItem("USA", "USA"));
			listCountry.Items.Add(new ListItem("Canada", "Canada"));
			listCountry.Items.Add(new ListItem("Japan", "Japan"));

			listLanguagePref.Items.Clear();
			listLanguagePref.Items.Add(new ListItem("English", "English"));
			listLanguagePref.Items.Add(new ListItem("Japanese", "Japanese"));

			listFavoriteCategory.Items.Clear();
			listFavoriteCategory.Items.Add(new ListItem("Birds", "Birds"));
			listFavoriteCategory.Items.Add(new ListItem("Cats", "Cats"));
			listFavoriteCategory.Items.Add(new ListItem("Dogs", "Dogs"));
			listFavoriteCategory.Items.Add(new ListItem("Fish", "Fish"));
			listFavoriteCategory.Items.Add(new ListItem("Reptiles", "Reptiles"));

			SelectListItem(listState, "California");
			SelectListItem(listCountry, "USA");
			SelectListItem(listLanguagePref, "English");
			SelectListItem(listFavoriteCategory, "birds");
		}

		// select specified dropdown list item
		private void SelectListItem(DropDownList list, string text) {
			try {
				list.Items.FindByText(text).Selected = true;
			}
			catch {
			}
		}

		// submit button clicked
		private void ProcessNewAccount() {
			// make sure all fields are valid
			if (Page.IsValid == true) {
				// create the new account
				string retval = CreateAccount();
				if (retval != null) {
					// store our customer session id in a cookie
					HttpCookie customerCookie = new HttpCookie("CustomerID", txtUserName.Text);
					Response.Cookies.Add(customerCookie);

					// set the user's authentication name to the user id
					FormsAuthentication.SetAuthCookie(txtUserName.Text, false);

					Response.Redirect("ValidateAccount.aspx?action=createAccount");
				}
				else
					Response.Redirect("ValidateAccount.aspx?action=duplicateAccount");
			}
		}

		private void btnSubmit_Click(object sender, System.Web.UI.ImageClickEventArgs e) {
			ProcessNewAccount();
		}

		

	}
}
