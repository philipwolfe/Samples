using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace PetShop.Web {
	/// <summary>
	/// Display a simple error message page. The full error stack will
	/// be written to the event log from the Application_Error() method
	/// in Global.asax.
	/// </summary>
	public class Error : System.Web.UI.Page {	

	}
}
