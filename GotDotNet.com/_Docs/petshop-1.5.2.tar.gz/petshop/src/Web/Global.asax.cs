using System;
using System.Collections;
using System.ComponentModel;
using System.Web;
using System.Web.SessionState;

namespace PetShop.Web {

	public class Global : System.Web.HttpApplication {

		/// <summary>
		/// Custom caching using the VaryByCustom attribute in the 
		/// OuputCache directive.
		/// </summary>
		/// <param name="context">The current HTTP request</param>
		/// <param name="arg">Custom cahce argument</param>
		/// <returns>Cache key</returns>
		public override string GetVaryByCustomString(HttpContext context, String arg) {

			// cache key that is returned
			string cacheKey = "";
			
			switch(arg) {

				// Custom caching for header control. We want to create two views
				// of the header... one if the user is logged in and another if
				// they are logged out.

				case "CategoryPageKey":

					if (Request.IsAuthenticated == true) {
						cacheKey = "QQQ" + context.Request.QueryString["category_id"] + context.Request.QueryString["requestedPage"];
					}
					else {
						cacheKey = "AAA" + context.Request.QueryString["category_id"] + context.Request.QueryString["requestedPage"];
					}

					break;

				case "SearchPageKey" : 

					if (Request.IsAuthenticated == true) {
						cacheKey = "QQQ" + context.Request.QueryString["search_text"] + context.Request.QueryString["requestedPage"];
					}
					else {
						cacheKey = "AAA" + context.Request.QueryString["search_text"] + context.Request.QueryString["requestedPage"];
					}

					break;

				case "ProductPageKey" :

					if (Request.IsAuthenticated == true) {
						cacheKey = "QQQ" + context.Request.QueryString["name"] + context.Request.QueryString["product_id"] + context.Request.QueryString["requestedPage"];
					}
					else {
							cacheKey = "AAA" + context.Request.QueryString["name"] + context.Request.QueryString["product_id"] + context.Request.QueryString["requestedPage"];
					}

					break;

				case "ProductDetailsPageKey" :

					if (Request.IsAuthenticated == true) {
						cacheKey = "QQQ" + context.Request.QueryString["item_id"] + context.Request.QueryString["requestedPage"];
					}
					else {
						cacheKey = "AAA" + context.Request.QueryString["item_id"] + context.Request.QueryString["requestedPage"];
					}

					break;

				case "UserID" : 

					if (Request.IsAuthenticated == true) {
						cacheKey = "UserID_In";
					}
					else {
						cacheKey = "UserID_Out";
					}

					break;
			}

			return cacheKey;
		}

		/// <summary>
		/// Global application level error handling. This method is invoked 
		/// anytime an exception is thrown. 
		/// </summary>
		/// <param name="sender">Sender</param>
		/// <param name="e">Event arguments</param>
		private void Application_Error(object sender, System.EventArgs e) {
			string err = "Microsoft .NET PetShop Application Error\n\n";
			err += "Request: " + Request.Url.ToString() + "\n\n";
			err += "Strack Trace: \n" + Server.GetLastError().ToString();

			// write the error message to the NT Event Log
			Components.Error.Log(err);
		}
	}
}

