namespace PetShop.Web.Inc {
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using System.Collections;
	using System.Diagnostics;
	using System.Data.SqlClient;
	using PetShop.Components;
	
	/// <summary>
	///	Displays editable address information for current user. 
	///	Props:
	///	 UserDefaultValues - If fields should be initialized with values from database.
	/// </summary>
	public abstract class ControlAddress : System.Web.UI.UserControl {
		protected System.Web.UI.WebControls.TextBox txtFirstName;
		protected System.Web.UI.WebControls.RequiredFieldValidator valFirstName;
		protected System.Web.UI.WebControls.TextBox txtLastName;
		protected System.Web.UI.WebControls.RequiredFieldValidator valLastName;
		protected System.Web.UI.WebControls.TextBox txtAddress1;
		protected System.Web.UI.WebControls.RequiredFieldValidator valAddress1;
		protected System.Web.UI.WebControls.TextBox txtAddress2;
		protected System.Web.UI.WebControls.TextBox txtCity;
		protected System.Web.UI.WebControls.RequiredFieldValidator valCity;
		protected System.Web.UI.WebControls.DropDownList listState;
		protected System.Web.UI.WebControls.TextBox txtPostalCode;
		protected System.Web.UI.WebControls.RequiredFieldValidator valPostalCode;
		protected System.Web.UI.WebControls.DropDownList listCountry;
		protected System.Web.UI.WebControls.TextBox txtTelephoneNumber;
		protected System.Web.UI.WebControls.RequiredFieldValidator valTelephoneNumber;

		// public props
		public bool UseDefaultValues=false;
		
		/// <summary>
		public ControlAddress() {
			this.Init += new System.EventHandler(Page_Init);
		}

		private void Page_Load(object sender, System.EventArgs e) {
			if (!IsPostBack) {
				// init dropdowns
				listState.Items.Add(new ListItem("California"));
				listState.Items.Add(new ListItem("New York"));
				listState.Items.Add(new ListItem("Texas"));

				listCountry.Items.Add(new ListItem("USA"));
				listCountry.Items.Add(new ListItem("Canada"));
				listCountry.Items.Add(new ListItem("Japan"));
				
				// initialize the values if using default values
				if (UseDefaultValues) {
					// determine who is logged in
					Debug.Assert(Request.Cookies["CustomerID"] != null);
					string userID = (string)Request.Cookies["CustomerID"].Value;

					// get user info
					Customer cust = new Customer();
					//SqlDataReader data = cust.GetAddress(userID);

					Customer.CustomerAddress customerAddress = cust.GetAddress(userID);

					//data.Read();
					
					// init values					
					txtFirstName.Text = customerAddress.firstname;
					txtLastName.Text = customerAddress.lastname;
					txtAddress1.Text = customerAddress.addr1;
					txtAddress2.Text = customerAddress.addr2;
					txtCity.Text = customerAddress.city;
					txtPostalCode.Text = customerAddress.zip;
					txtTelephoneNumber.Text = customerAddress.phone;
					SelectListItem(listState, customerAddress.state);
					SelectListItem(listCountry, customerAddress.country);

					/*					 
						txtFirstName.Text = (string)data["firstname"];
						txtLastName.Text = (string)data["lastname"];
						txtAddress1.Text = (string)data["addr1"];
						txtAddress2.Text = (string)data["addr2"];
						txtCity.Text = (string)data["city"];
						txtPostalCode.Text = (string)data["zip"];
						txtTelephoneNumber.Text = (string)data["phone"];
						SelectListItem(listState, (string)data["state"]);
						SelectListItem(listCountry, (string)data["country"]);
						
						// done with datareader
						//data.Close();
					*/
				}
			}
		}

		private void Page_Init(object sender, EventArgs e) {
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
		}

		/// <summary>
		/// Saves or updates address information for current
		///	user (session).
		/// </summary>
		/// <param name="adr">Hashtable to save info into.</param>
		/// <param name="prefix">Prefix of key that is used when saving info.</param>
		public void SaveInfo(Hashtable adr, string prefix) {
			adr[prefix + "_FirstName"] = txtFirstName.Text.Trim();
			adr[prefix + "_LastName"] = txtLastName.Text.Trim();
			adr[prefix + "_Address1"] = txtAddress1.Text.Trim();
			adr[prefix + "_Address2"] = txtAddress2.Text.Trim();
			adr[prefix + "_City"] = txtCity.Text.Trim();
			adr[prefix + "_State"] = listState.SelectedItem.Text.Trim();
			adr[prefix + "_PostalCode"] = txtPostalCode.Text.Trim();
			adr[prefix + "_Country"] =  listCountry.SelectedItem.Text.Trim();
			adr[prefix + "_Number"] = txtTelephoneNumber.Text.Trim();
		}

		// select specified item in dropdown list		
		private void SelectListItem(DropDownList list, string text) {
			try {
				list.Items.FindByText(text).Selected = true;
			}
			catch {
			}
		}

		#region Web Form Designer generated code
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
