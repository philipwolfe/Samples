namespace PetShop.Web.Inc {
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using PetShop.Components;

	/// <summary>
	///	Hide or show the banner depending on user preference.
	/// </summary>
	public abstract class ControlBanner : System.Web.UI.UserControl {

		protected System.Web.UI.HtmlControls.HtmlGenericControl areaBanner;
		protected System.Web.UI.HtmlControls.HtmlGenericControl areaImage;

		private void Page_Load(object sender, System.EventArgs e) {

			if (Page.IsPostBack == false)
				ShowBanner();
		}

		/// <summary>
		/// Hide or show the banner depending on user preference.
		/// </summary>
		private void ShowBanner() {

			if (Request.IsAuthenticated == true) {

				// determine who is logged in
				HttpCookie customerCookie = Request.Cookies["CustomerID"];
				
				if ((customerCookie != null) && (customerCookie.Value.Length > 0)) {

					bool showBanner;
					string bannerPath;

					// get banner option info
					Profile profile = new Profile();
					profile.GetBannerOptions( (string)customerCookie.Value, out showBanner, out bannerPath);

					// update banner display
					areaBanner.Visible = showBanner;
					areaImage.InnerHtml = bannerPath;
				}
			}
			else {
				// no one is logged in
				areaBanner.Visible = false;
			}
		}

		#region Web Form Designer generated code
		private void InitializeComponent() {
			this.Load += new System.EventHandler(this.Page_Load);
		}

		public ControlBanner() {
			this.Init += new System.EventHandler(Page_Init);
		}

		private void Page_Init(object sender, EventArgs e) {
			InitializeComponent();
		}
		#endregion
	}
}
