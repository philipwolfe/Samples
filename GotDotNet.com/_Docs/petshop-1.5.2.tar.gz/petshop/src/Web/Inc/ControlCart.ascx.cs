namespace PetShop.Web.Inc {
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using PetShop.Components;

	public abstract class ControlCart : System.Web.UI.UserControl {

		// Public properties
		public bool AllowEdit = true;
		public bool ShowInStock = true;
		public bool AllowPaging = true;

		protected System.Web.UI.WebControls.DataGrid dataGrid;
		protected System.Web.UI.WebControls.ImageButton btnUpdate;
		protected System.Web.UI.WebControls.ImageButton btnMore;
		protected System.Web.UI.WebControls.ImageButton btnPrev;

		private void Page_Load(object sender, System.EventArgs e) {

			if (Page.IsPostBack == false) {

				// See if we should setup the grid for paging
				if (AllowPaging) {		
					dataGrid.AllowPaging = true;
					dataGrid.PageSize = 4;		
					dataGrid.CurrentPageIndex = 0;
				}

				ShowCart();
			}				
		}

		// Display the cart		
		public void ShowCart() {

			// See if should allow qty to be edited
			if (AllowEdit)
				dataGrid.Columns[5].Visible = false;
			else {
				dataGrid.Columns[0].Visible = false;				
				dataGrid.Columns[6].Visible = false;
				btnUpdate.Visible = false;
			}

			// Display InStock or not
			if (ShowInStock == false)
				dataGrid.Columns[3].Visible = false;
					
			// Get cart
			ShoppingCart cart = (ShoppingCart)Session["ShoppingCartSession"];

			// Calculate total
			dataGrid.Columns[7].FooterText = cart.Total.ToString("c");

			// Bind cart to grid
			dataGrid.DataSource = cart.GetItems();
			dataGrid.DataBind();
						
			ShowNavButtons();
		}

		// The qty was updated, go through the grid and update the cart object
		private void UpdateCart() {
			int qty;
			bool removedItem = false;
			ShoppingCart cart = (ShoppingCart)Session["ShoppingCartSession"];
			
			// loop backwards since we might delete a row on the way (if qty is 0)
			for (int i=dataGrid.Items.Count-1; i>=0; i--) {
				// get the qty field
				DataGridItem _item = dataGrid.Items[i];
				TextBox qtyTextBox = (TextBox)_item.FindControl("txtQty");

				try {
					// convert to number, the qty is restored to the old
					// value if entered something invalid (not a number)
					qty = Convert.ToInt32(qtyTextBox.Text);

					// remove if entered qty 0
					if (qty <= 0) {
						cart.RemoveAt((dataGrid.CurrentPageIndex * dataGrid.PageSize) + i);
						removedItem = true;
					}						
					else					
						cart[(dataGrid.CurrentPageIndex * dataGrid.PageSize) + i].Qty = qty;
				}
				catch {
					// don't do anything, the qty will not be
					// updated and will retain the old value
				}
			}

			// now we have a problem since we are handling custom paging, we need 
			// to make sure we don't think we are on a page that does not exist
			// if one or more items were removed
			if (removedItem)
				dataGrid.CurrentPageIndex = 0;

			// the new qty for an item might make it out of stock
			// update the 'in stock' property for all items in the cart
			cart.UpdateInStock();

			// display the udpated cart
			ShowCart();
		}

		// prev button clicked
		private void btnPrev_Click(object sender, System.Web.UI.ImageClickEventArgs e) {
			// move to previous page, this button will be hidden
			// if necessary in the ShowNavButtons function
			if (btnPrev.Visible) {
				dataGrid.CurrentPageIndex--;
				ShowCart();
			}
		}

		// next / more button clicked
		private void btnMore_Click(object sender, System.Web.UI.ImageClickEventArgs e) {
			// move to next page, this button will be hidden
			// if necessary in the ShowNavButtons function
			if (btnMore.Visible) {
				dataGrid.CurrentPageIndex++;
				ShowCart();
			}
		}

		// update button clicked
		private void btnUpdate_Click(object sender, System.Web.UI.ImageClickEventArgs e) {
			UpdateCart();
		}
		
		// hide or show navigation buttons
		private void ShowNavButtons() {
			// hide or show navigation buttons
			// always hide if not supporting paging or there is only one page
			if (AllowPaging && (dataGrid.PageCount > 0)) {
				// hide and show buttons
				btnPrev.Visible = dataGrid.CurrentPageIndex > 0;
				btnMore.Visible = dataGrid.CurrentPageIndex < (dataGrid.PageCount-1);
			}
			else {
				// both buttons should be hidden
				btnPrev.Visible = btnMore.Visible = false;
			}
		}

		#region Web Form Designer generated code
		public ControlCart() {
			this.Init += new System.EventHandler(Page_Init);
		}

		private void Page_Init(object sender, EventArgs e) {
			InitializeComponent();
		}


		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
			this.btnPrev.Click += new System.Web.UI.ImageClickEventHandler(this.btnPrev_Click);
			this.btnMore.Click += new System.Web.UI.ImageClickEventHandler(this.btnMore_Click);
			this.btnUpdate.Click += new System.Web.UI.ImageClickEventHandler(this.btnUpdate_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

	}
}
