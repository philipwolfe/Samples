namespace PetShop.Web.Inc {

	using System;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;

	/// <summary>
	///	Displays the top portion of the page. Displays correct 
	///	images, logged in menus and navigation menu items.
	///	Props:
	///	 ShowMenu - true if menu should be shown, otherwise false.
	/// </summary>
	public abstract class ControlHeader : System.Web.UI.UserControl {
		protected System.Web.UI.HtmlControls.HtmlImage lizard1;
		protected System.Web.UI.HtmlControls.HtmlImage lizard5;
		protected System.Web.UI.HtmlControls.HtmlImage lizard4;
		protected System.Web.UI.HtmlControls.HtmlGenericControl areaMenu;
		protected System.Web.UI.HtmlControls.HtmlGenericControl areaNoMenu;
		protected System.Web.UI.HtmlControls.HtmlGenericControl areaLoggedIn;
		protected System.Web.UI.HtmlControls.HtmlGenericControl areaLoggedOut;

		// properties
		public bool ShowMenu = true;

		private void Page_Load(object sender, System.EventArgs e) {
			ShowMenuArea();
			ShowLoggedInArea();
		}

		// display different items if person is logged in or not
		private void ShowLoggedInArea() {

			if (Request.IsAuthenticated == true) {
				areaLoggedIn.Visible = true;
				areaLoggedOut.Visible = false;
			}
			else {
				areaLoggedIn.Visible = false;
				areaLoggedOut.Visible = true;
			}
		}

		// hide or show menu items
		private void ShowMenuArea() {
			if (ShowMenu) {
				// show menu items
				areaMenu.Visible = true;
				lizard1.Visible = true;
				lizard4.Visible = true;
				lizard5.Visible = false;
				
				areaNoMenu.Visible = false;
			}
			else {
				// hide menu items
				areaMenu.Visible = false;
				lizard1.Visible = false;
				lizard4.Visible = false;				
				lizard5.Visible = true;

				areaNoMenu.Visible = true;
			}
		}

		#region Web Form Designer generated code
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
			this.Load += new System.EventHandler(this.Page_Load);

		}

		private void Page_Init(object sender, EventArgs e) {
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
		}

		public ControlHeader() {
			this.Init += new System.EventHandler(Page_Init);
		}
		#endregion
	}
}
