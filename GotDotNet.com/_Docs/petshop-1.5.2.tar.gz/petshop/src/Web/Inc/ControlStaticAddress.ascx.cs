namespace PetShop.Web.Inc {
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using System.Diagnostics;
	using System.Collections;


	/// <summary>
	///	Display static (can't edit) address information.
	///	Props:
	///	 UseBilling - true to display billing address, otherwise display shipping address.
	///	 ShowName - true to display the address name, otherwise name is not displayed.
	/// </summary>
	public abstract class ControlStaticAddress : System.Web.UI.UserControl {
		protected System.Web.UI.WebControls.Label lblFirstName;
		protected System.Web.UI.WebControls.Label lblLastName;
		protected System.Web.UI.WebControls.Label lblAdr1;
		protected System.Web.UI.WebControls.Label lblAdr2;
		protected System.Web.UI.WebControls.Label lblCity;
		protected System.Web.UI.WebControls.Label lblState;
		protected System.Web.UI.WebControls.Label lblPostalCode;

		// use billing if true, otherwise use shipping
		public bool UseBilling = true;
		public bool ShowName = true;


		/// <summary>
		public ControlStaticAddress() {
			this.Init += new System.EventHandler(Page_Init);
		}

		private void Page_Load(object sender, System.EventArgs e) {
			if (!IsPostBack) {
				// get address info
				Hashtable adr = (Hashtable)Session["ShoppingAddressSession"];
				Debug.Assert(adr != null);			

				// decide what type of address to display, either billing or shipping
				string prefix = UseBilling ? "Bill" : "Ship";				

				// update fields with info
				lblFirstName.Text = (string)adr[prefix + "_FirstName"];
				lblLastName.Text = (string)adr[prefix + "_LastName"];
				lblAdr1.Text = (string)adr[prefix + "_Address1"];
				lblAdr2.Text = (string)adr[prefix + "_Address2"];
				lblCity.Text = (string)adr[prefix + "_City"];
				lblState.Text = (string)adr[prefix + "_State"];
				lblPostalCode.Text = (string)adr[prefix + "_PostalCode"];
			}
		}

		private void Page_Init(object sender, EventArgs e) {
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
		}

		#region Web Form Designer generated code
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
