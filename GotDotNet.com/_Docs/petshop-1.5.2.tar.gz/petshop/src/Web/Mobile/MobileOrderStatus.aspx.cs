using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.Mobile;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.MobileControls;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using PetShop.Components;

namespace PetShop.Web.Mobile {
	/// <summary>
	/// Summary description for PetStore.Web.Mobile.
	/// </summary>
	public class MobileOrderStatus : System.Web.UI.MobileControls.MobilePage {
		#region ASP.NET WebForm Designer variables
		protected System.Web.UI.MobileControls.Label lblUsername;
		protected System.Web.UI.MobileControls.Command btnGo;
		protected System.Web.UI.MobileControls.Form WelcomeForm;
		protected System.Web.UI.MobileControls.Label lblResults;
		protected System.Web.UI.MobileControls.Label lblOrderStatus;
		protected System.Web.UI.MobileControls.Form RecentOrdersForm;
		protected System.Web.UI.MobileControls.Command btnCheckStatus;
		protected System.Web.UI.MobileControls.SelectionList lstRecentOrder;
		protected System.Web.UI.MobileControls.TextBox txtUsername;
		protected System.Web.UI.MobileControls.Label lblPassword;
		protected System.Web.UI.MobileControls.TextBox txtPassword;
		protected System.Web.UI.MobileControls.Label lblRecentOrders;
		protected System.Web.UI.MobileControls.Image imgLogoWelcome;
		protected System.Web.UI.MobileControls.Image imgLogoRecentOrders;
		protected System.Web.UI.MobileControls.Image imgLogoResults;
		protected System.Web.UI.MobileControls.Form ResultsForm;
		#endregion 

		#region ASP.NET WebForms
		public MobileOrderStatus()
		{
			Page.Init += new System.EventHandler(Page_Init);
		}

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}

		private void Page_Init(object sender, EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Windows Form Designer.
			//
			InitializeComponent();
		}
		#endregion

		#region Web Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnGo.Click += new System.EventHandler(this.btnGo_Click);
			this.btnCheckStatus.Click += new System.EventHandler(this.btnCheckStatus_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		// go command event handler 
		private void btnGo_Click(object sender, System.EventArgs e) {
			// verify login
			Customer customer = new Customer();
			if (customer.Login(txtUsername.Text, txtPassword.Text) != null) {
				// get the list of orders for the specified customer
				Order order = new Order();
				lstRecentOrder.DataValueField = "orderid";							
				lstRecentOrder.DataSource = order.GetOrder(txtUsername.Text);
				lstRecentOrder.DataBind();				
				lstRecentOrder.SelectedIndex = 0;
			
				// advance to the next card
				ActiveForm = RecentOrdersForm;
			}
		}

		// order status command event handler
		private void btnCheckStatus_Click(object sender, System.EventArgs e) {
			// get the order status
			Order order = new Order();
			lblOrderStatus.Text = order.GetOrderStatus(lstRecentOrder.Selection.Text);

			// advance to the results card
			ActiveForm = ResultsForm;
		}
	}
}
