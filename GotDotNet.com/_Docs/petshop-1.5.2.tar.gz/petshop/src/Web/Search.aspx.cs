using System;
using System.Configuration;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using PetShop.Components;

namespace PetShop.Web {

	public class Search : System.Web.UI.Page {
		protected System.Web.UI.WebControls.Repeater list;
		protected System.Web.UI.WebControls.ImageButton btnPrevious;
		protected System.Web.UI.WebControls.ImageButton btnNext;
		protected System.Web.UI.HtmlControls.HtmlForm form;
		protected System.Web.UI.WebControls.HyperLink lnkPrevious;
		protected System.Web.UI.WebControls.HyperLink lnkNext;
		protected System.Web.UI.HtmlControls.HtmlGenericControl areaResult;

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e) {
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {    
			this.Load += new System.EventHandler(this.Page_Load);
		}
		#endregion

		// constants
		const int pageSize = 4;	

		// page variables
		private int currentPage = 0;
		private int pageCount = 0; 
		private int numResults = 0;

		private void Page_Load(object sender, System.EventArgs e) {
			if (Page.IsPostBack == false) {
				// see what searching for
				string searchText = Request.QueryString["search_text"];
				if ((searchText != string.Empty) && (searchText != null)) {
					// First time here we want to fetch the first page. All of the
					// other page requests will be handled through the page 
					// navigation button event handlers.
					currentPage = 1;
					BindPagedData();
				}
				else {
					// user did not enter a search string
					areaResult.InnerHtml = "No products were found.";
					list.Visible = false;
				}
			}
		}

		// custom paging
		private void BindPagedData() {
			// pull the values off the query string
			if (Request.QueryString["requestedPage"] != null) {
				currentPage = System.Int32.Parse(Request.QueryString["requestedPage"]);
				pageCount = System.Int32.Parse(Request.QueryString["pageCount"]);
			}
			else
				currentPage = 1;

			// get page of data and bind to list			
			string searchText = Request.QueryString["search_text"];
			Components.Product product = new Components.Product();						
			SearchResults[] results = product.Search(searchText, currentPage, pageSize, ref numResults);

			list.DataSource = results;
			list.DataBind();

			// if this is the first time, calculate the total number of pages
			if ((Page.IsPostBack == false) || (pageCount == 0))
				pageCount = (int)System.Math.Ceiling((double)numResults / pageSize);

			areaResult.InnerHtml = "Searching for <b>" + searchText + "</b> returned <b>" + numResults + "</b> items.";
			if (numResults == 0) list.Visible = false;
						
			// hide or show navigation buttons
			if (pageCount > 1) {
				// there are multiple pages
				lnkPrevious.Visible = currentPage > 1;
				lnkNext.Visible = currentPage < pageCount;
				lnkPrevious.NavigateUrl = "Search.aspx?search_text=" + searchText + "&requestedPage=" + (currentPage - 1) + "&pageCount=" + pageCount;
				lnkNext.NavigateUrl = "Search.aspx?search_text=" + searchText + "&requestedPage=" + (currentPage + 1) + "&pageCount=" + pageCount;
			}
			else {
				// there is only one page, hide both buttons
				lnkPrevious.Visible = lnkNext.Visible = false;
				lnkPrevious.NavigateUrl = "Search.aspx?search_text=" + searchText + "&requestedPage=" + (currentPage - 1) + "&pageCount=" + pageCount;
				lnkNext.NavigateUrl = "Search.aspx?search_text=" + searchText + "&requestedPage=" + (currentPage + 1) + "&pageCount=" + pageCount;
			}
		}
	}
}
