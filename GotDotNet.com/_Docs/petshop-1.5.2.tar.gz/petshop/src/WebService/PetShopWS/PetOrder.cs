using System;

namespace PetShopWS
{
	/// <summary>
	/// Definition of a Pet Store Order
	/// </summary>
	public class PetOrder
	{
		public int OrderId;
		public String OrderStatus;
		public String OrderDate;
		public String ShipToAddress;
		public String ShipToCity;
		public String ShipToState;
		public String ShipToPostalCode;
		public String BillToAddress;
		public String BillToCity;
		public String BillToState;
		public String BillToPostalCode;
		public double TotalPrice;
		public PetOrderLineItem[] LineItems;

		public PetOrder()
		{
		}
	}
}
