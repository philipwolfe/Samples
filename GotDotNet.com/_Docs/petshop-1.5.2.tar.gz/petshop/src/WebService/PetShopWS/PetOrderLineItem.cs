using System;

namespace PetShopWS
{
	/// <summary>
	/// Definition of a Pet Store Order LineItem.
	/// </summary>
	public class PetOrderLineItem
	{
		public int LineNum;
		public String Name;
		public int Qty;
		public float Price;
	}	
}
