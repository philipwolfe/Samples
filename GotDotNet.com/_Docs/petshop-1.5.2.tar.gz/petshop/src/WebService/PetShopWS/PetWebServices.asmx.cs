using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Web;
using System.Web.Services;
using System.Data.SqlClient;

namespace PetShopWS
{
	/// <summary>
	/// Summary description for PetWebServices.
	/// </summary>
	public class PetWebServices : System.Web.Services.WebService
	{
		private System.Data.SqlClient.SqlConnection sqlConnection1;
		private System.Diagnostics.EventLog eventLog1;
		private System.Data.SqlClient.SqlCommand sqlCommand1;
	
		public PetWebServices()
		{
			//CODEGEN: This call is required by the ASP.NET Web Services Designer
			InitializeComponent();
		}

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Configuration.AppSettingsReader configurationAppSettings = new System.Configuration.AppSettingsReader();
			this.sqlConnection1 = new System.Data.SqlClient.SqlConnection();
			this.sqlCommand1 = new System.Data.SqlClient.SqlCommand();
			this.eventLog1 = new System.Diagnostics.EventLog();
			((System.ComponentModel.ISupportInitialize)(this.eventLog1)).BeginInit();
			// 
			// sqlConnection1
			// 
			this.sqlConnection1.ConnectionString = ((string)(configurationAppSettings.GetValue("sqlConnection1.ConnectionString", typeof(string))));
			// 
			// sqlCommand1
			// 
			this.sqlCommand1.CommandText = "[upOrdersGetDetails]";
			this.sqlCommand1.CommandType = System.Data.CommandType.StoredProcedure;
			this.sqlCommand1.Connection = this.sqlConnection1;
			this.sqlCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@RETURN_VALUE", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.ReturnValue, false, ((System.Byte)(10)), ((System.Byte)(0)), "", System.Data.DataRowVersion.Current, null));
			this.sqlCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@OrderNumber", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, false, ((System.Byte)(10)), ((System.Byte)(0)), "", System.Data.DataRowVersion.Current, null));
			this.sqlCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@OrderStatus", System.Data.SqlDbType.VarChar, 30, System.Data.ParameterDirection.Output, false, ((System.Byte)(0)), ((System.Byte)(0)), "", System.Data.DataRowVersion.Current, null));
			this.sqlCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@OrderDate", System.Data.SqlDbType.DateTime, 8, System.Data.ParameterDirection.Output, false, ((System.Byte)(0)), ((System.Byte)(0)), "", System.Data.DataRowVersion.Current, null));
			this.sqlCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ShipToAddress", System.Data.SqlDbType.VarChar, 80, System.Data.ParameterDirection.Output, false, ((System.Byte)(0)), ((System.Byte)(0)), "", System.Data.DataRowVersion.Current, null));
			this.sqlCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ShipToCity", System.Data.SqlDbType.VarChar, 80, System.Data.ParameterDirection.Output, false, ((System.Byte)(0)), ((System.Byte)(0)), "", System.Data.DataRowVersion.Current, null));
			this.sqlCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ShipToState", System.Data.SqlDbType.VarChar, 80, System.Data.ParameterDirection.Output, false, ((System.Byte)(0)), ((System.Byte)(0)), "", System.Data.DataRowVersion.Current, null));
			this.sqlCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@ShipToZip", System.Data.SqlDbType.VarChar, 20, System.Data.ParameterDirection.Output, false, ((System.Byte)(0)), ((System.Byte)(0)), "", System.Data.DataRowVersion.Current, null));
			this.sqlCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@BillToAddress", System.Data.SqlDbType.VarChar, 80, System.Data.ParameterDirection.Output, false, ((System.Byte)(0)), ((System.Byte)(0)), "", System.Data.DataRowVersion.Current, null));
			this.sqlCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@BillToCity", System.Data.SqlDbType.VarChar, 80, System.Data.ParameterDirection.Output, false, ((System.Byte)(0)), ((System.Byte)(0)), "", System.Data.DataRowVersion.Current, null));
			this.sqlCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@BillToState", System.Data.SqlDbType.VarChar, 80, System.Data.ParameterDirection.Output, false, ((System.Byte)(0)), ((System.Byte)(0)), "", System.Data.DataRowVersion.Current, null));
			this.sqlCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@BillToZip", System.Data.SqlDbType.VarChar, 20, System.Data.ParameterDirection.Output, false, ((System.Byte)(0)), ((System.Byte)(0)), "", System.Data.DataRowVersion.Current, null));
			this.sqlCommand1.Parameters.Add(new System.Data.SqlClient.SqlParameter("@TotalPrice", System.Data.SqlDbType.Decimal, 9, System.Data.ParameterDirection.Output, false, ((System.Byte)(18)), ((System.Byte)(0)), "", System.Data.DataRowVersion.Current, null));
			// 
			// eventLog1
			// 
			this.eventLog1.Log = "Application";
			this.eventLog1.Source = ".NET PetShop";
			((System.ComponentModel.ISupportInitialize)(this.eventLog1)).EndInit();

		}
		#endregion

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
		}

		[WebMethod]
		public PetOrder GetOrderDetails(int OrderNum)
		{
			PetOrder orderinformation = new PetOrder();

			try 
			{
				sqlConnection1.Open();                
				SqlParameterCollection ps = sqlCommand1.Parameters;

				ps["@OrderNumber"].Value = OrderNum;
  
				// run the command and obtain a datareader
				// NOTE: DataReader is more performant than DataSet
				SqlDataReader results = sqlCommand1.ExecuteReader();
				if (results != null)
				{
					ArrayList dbdata = new ArrayList();
					while (results.Read())
					{
						PetOrderLineItem datarecord = new PetOrderLineItem();
						datarecord.LineNum = results.GetInt32(0);
						datarecord.Name = results.GetString(1);
						datarecord.Qty = results.GetInt32(2);
						datarecord.Price = (float)results.GetDecimal(3);
						dbdata.Add(datarecord);
					}
					// You must close the result set to be able to access the stored procedure parameters
					results.Close();
					orderinformation.LineItems = (PetOrderLineItem[])dbdata.ToArray(typeof(PetOrderLineItem));
				}
				results = null;					
				orderinformation.OrderId = (int)ps["@OrderNumber"].Value;
				orderinformation.OrderStatus = (String)ps["@OrderStatus"].Value;
				orderinformation.OrderDate = (String)ps["@OrderDate"].Value.ToString();
				orderinformation.ShipToAddress = (String)ps["@ShipToAddress"].Value;	
				orderinformation.ShipToCity = (String)ps["@ShipToCity"].Value;	
				orderinformation.ShipToState = (String)ps["@ShipToState"].Value;	
				orderinformation.ShipToPostalCode = (String)ps["@ShipToZip"].Value;	
				orderinformation.BillToAddress = (String)ps["@BillToAddress"].Value;	
				orderinformation.BillToCity = (String)ps["@BillToCity"].Value;	
				orderinformation.BillToState = (String)ps["@BillToState"].Value;	
				orderinformation.BillToPostalCode = (String)ps["@BillToZip"].Value;	
				orderinformation.TotalPrice = Double.Parse(ps["@TotalPrice"].Value.ToString());	
			}
			catch (Exception ex)
			{
				eventLog1.WriteEntry(ex.Message, System.Diagnostics.EventLogEntryType.Error);
				orderinformation = null;
			}
			finally
			{
				try
				{	
					sqlCommand1.Dispose();
				}
				catch(Exception)
				{
				}
				try
				{
					sqlConnection1.Close();
				}
				catch(Exception)
				{
				}
				
			}
			return orderinformation;
		}
	}
}
