Public Class WebForm1
    Inherits System.Web.UI.Page
    Protected WithEvents LblOrderStatus As System.Web.UI.WebControls.Label
    Protected WithEvents LblOrderBillAddress As System.Web.UI.WebControls.Label
    Protected WithEvents LblOrderDate As System.Web.UI.WebControls.Label
    Protected WithEvents LblOrderTotal As System.Web.UI.WebControls.Label
    Protected WithEvents LblOrderShipAddress As System.Web.UI.WebControls.Label
    Protected WithEvents LblOrderNum As System.Web.UI.WebControls.Label
    Protected WithEvents LblOrderNumOUT As System.Web.UI.WebControls.Label
    Protected WithEvents LblOrderStatusOUT As System.Web.UI.WebControls.Label
    Protected WithEvents LblShipAddrOUT As System.Web.UI.WebControls.Label
    Protected WithEvents LblShipStateOUT As System.Web.UI.WebControls.Label
    Protected WithEvents LblBillStateOUT As System.Web.UI.WebControls.Label
    Protected WithEvents LblBillAddrOUT As System.Web.UI.WebControls.Label
    Protected WithEvents LblOrderDateOUT As System.Web.UI.WebControls.Label
    Protected WithEvents LblOrderTotalOUT As System.Web.UI.WebControls.Label
    Protected WithEvents LblShipCityOUT As System.Web.UI.WebControls.Label
    Protected WithEvents LblLineItems As System.Web.UI.WebControls.Label
    Protected WithEvents DataGridLineItems As System.Web.UI.WebControls.DataGrid
    Protected WithEvents LblBillCityOUT As System.Web.UI.WebControls.Label

    Protected orderdetails As New localhost.PetOrder()

#Region " Web Form Designer Generated Code "

    'This call is required by the Web Form Designer.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: This method call is required by the Web Form Designer
        'Do not modify it using the code editor.
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'Put user code to initialize the page here
        Dim psws As New localhost.PetWebServices()
        Dim ordernumber As Integer

        ordernumber = 1

        orderdetails = psws.GetOrderDetails(ordernumber)

        Dim dt As New DataTable("LineItemData")
        Dim dr As DataRow

        dt.Columns.Add("Line #")
        dt.Columns.Add("Item Id")
        dt.Columns.Add("Qty")
        dt.Columns.Add("Price")

        Dim item As localhost.PetOrderLineItem

        For Each item In orderdetails.LineItems
            dr = dt.NewRow()
            dr("Line #") = item.LineNum
            dr("Item Id") = item.Name
            dr("Qty") = item.Qty
            dr("Price") = item.Price

            dt.Rows.Add(dr)
        Next

        Me.DataGridLineItems.DataSource = dt.DefaultView

        Me.DataGridLineItems.DataBind()

        Page.DataBind()

    End Sub
End Class
