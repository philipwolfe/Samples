/******************************************************************************
**        File: TruncateTables.sql
**        Name: Benchmark Data Load
**        Desc: Remove the current data from the database in preparation
**              for the benchmark data load. If you want to restore the
**              original data, please see the DataPopulation.sql SQL script
**              (located in the Create Scripts folder).
**
**        Date: 11/6/2001
**
*******************************************************************************/

-- delete the contents of the Product table
PRINT 'Deleting Data: Product Table';
ALTER TABLE Item NOCHECK CONSTRAINT FK_Item_Product;
ALTER TABLE Product NOCHECK CONSTRAINT FK_Product_Category;
DELETE FROM Product
ALTER TABLE Product CHECK CONSTRAINT FK_Product_Category;
ALTER TABLE Item CHECK CONSTRAINT FK_Item_Product; 

-- delete the contents of the Item table
PRINT 'Deleting Data: Item Table';
ALTER TABLE Item NOCHECK CONSTRAINT FK_Item_Product;
ALTER TABLE Item NOCHECK CONSTRAINT FK_Item_Supplier;
DELETE FROM Item
ALTER TABLE Item CHECK CONSTRAINT FK_Item_Supplier;
ALTER TABLE Item CHECK CONSTRAINT FK_Item_Product;

-- delete the contents of the Inventory table
TRUNCATE TABLE Inventory