/******************************************************************************
**        File: upItemGetList_Benchmark.sql
**        Name: upItemGetList Stored Procedure
**        Desc: Gets the list of items for a specific product type. 
**              This was modified to return the TOP 25 results for the 
**              benchmarking.
**
**        Date: 11/6/2001
**
*******************************************************************************/

ALTER PROCEDURE upItemGetList
(
    @prodid              varchar(10)
)
AS

    SELECT TOP 25 itemid, listprice, attr1
    FROM Item
    WHERE productid = @prodid