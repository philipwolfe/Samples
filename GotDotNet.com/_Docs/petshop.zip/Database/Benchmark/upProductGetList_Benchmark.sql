/******************************************************************************
**        File: upProductGetList_Benchmark.sql
**        Name: upProductGetList Stored Procedure
**        Desc: Gets the list of products via the selected category.
**              This was modified to return the TOP 50 results for 
**              the benchmarking.
**
**        Date: 11/6/2001
**
*******************************************************************************/

ALTER PROCEDURE upProductGetList
(
	    @cat_id              char(10)
)
AS

    SELECT TOP 50 productid, name
    FROM Product
    WHERE category = @cat_id
    ORDER BY name
