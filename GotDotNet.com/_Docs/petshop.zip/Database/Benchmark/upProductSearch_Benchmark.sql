/******************************************************************************
**        File: upProductSearch_Benchmark.sql
**        Name: upProductSearch Stored Procedure
**        Desc: Basic catalog search. This was modified to 
**              return the TOP 25 results for the benchmarking.
**
**        Date: 11/9/2001
**
*******************************************************************************/

ALTER PROCEDURE upProductSearch
(
	    @Search              nvarchar(255)
)
AS
    DECLARE @_name varchar(50) 
    SET @_name = '%' + @Search + '%'

    SELECT TOP 25 productid, [name], descn
    FROM Product
    WHERE 
    (
        --search the product name field
       [name] like (@_name)
       OR
       
       -- search the products category field
       category like  (@_name)
    )
    GO