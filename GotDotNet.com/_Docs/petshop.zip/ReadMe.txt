Microsoft.NET PetShop Blueprint Application v1.5.1 - ReadMe.txt
===============================================================

Setup
=====

* Verify that you have IIS installed and SQL Server
  before proceeding.

* WARNING: You may need to adjust the Database\CreateDatabase.cmd
  setup script to use the correct sa password. The script
  was written with sa and blank password as default.

* Run "setup.cmd"

* Optional: After running setup.cmd, you will be able to open
  the PetShop project in Visual Studio.NET by opening ".NET PetShop.sln",
  which is located in the web folder.

  If you want to build the application in Visual Studio .NET, 
  you may need to adjust the HTML formatting options
  to turn off the automatic formatting:

    1. Go to Tools -> Options

    2. Navigate to "Text Editor | HTML\XML | Format"

    3. Uncheck the "Apply Automatic Formatting" checkboxes


Web Services Setup
==================

Run CreateWebService.vbs and CreateWebServiceClient.vbs in the WebService
folder to create the IIS virtual directories for the .NET PetShop Order
Web Service.

* To recompile the Web Service, open "PetShopWS.csproj" and rebuild the 
  project.

* To recompile the Web Service test client, open "PetShopWSClient.vbproj"and
  rebuild the project


Build
=====
Before view the application, you will need to recompile the application.
Please run make.bat (or make with Mobile Support.bat if you have installed
the Microsoft Mobile Internet Toolkit) to build the application.


Running the application
=======================

* There are 4 applications that can be run:

	Main Site: 	     http://localhost/PetShop
	Web Service:	     http://localhost/PetShopWS/PetWebServices.asmx
	Web Service Client:  http://localhost/PetShopWSClient/PetShopWSClientForm.aspx
	Mobile:	 	     http://localhost/PetShop/mobile
	





