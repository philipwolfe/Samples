using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace PetShop.Web {
	/// <summary>
	/// First step in checkout process. Just display contents of 
	/// shopping cart and allow user to continue checking out.
	/// </summary>
	public class CheckOut : System.Web.UI.Page {
		private void InitializeComponent() {
		}
	}
}
