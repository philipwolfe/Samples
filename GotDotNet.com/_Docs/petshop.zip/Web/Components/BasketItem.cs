using System;
using System.Collections;
using System.Diagnostics;

namespace PetShop.Components {
	/// <summary>
	/// A line item in the shopping cart.
	/// </summary>
	public class BasketItem {
		// private properties
		private string itemID;
		private string name;
		private int qty;
		private double price;
		private double total;
		private bool inStock;

		/// <summary>
		/// Init item with values.
		/// </summary>
		/// <param name="itemID">Product item.</param>
		/// <param name="name">Item name.</param>
		/// <param name="inStock">True if in stock, otherwise false.</param>
		/// <param name="qty">Quantity.</param>
		/// <param name="price">Item price.</param>
		public BasketItem(string itemID, string name, bool inStock, int qty, double price) {
			// save to class members
			this.itemID = itemID;
			this.name = name;
			this.qty = qty;
			this.price = price;
			this.total = Total;
			this.inStock = inStock;
		} 

		// access to item props		
		public string ItemID {
			get { return itemID; }
			set { itemID = value; }  
		}

		public string Name {
			get { return name; }
			set { name = value; }  
		}

		public int Qty {
			get { return qty; }
			set { qty = value; }
		}

		public double Price {
			get { return price; }
			set { price = value; }
		}
    
		public double Total {
			get { return qty * price; }
			set { total = value; }
		}

		public bool InStock {
			get { return inStock; }
			set { inStock = value; }
		}
	}
}
