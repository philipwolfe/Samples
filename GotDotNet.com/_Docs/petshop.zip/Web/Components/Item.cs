using System;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;

namespace PetShop.Components {
	/// <summary>
	/// Represents a product variant.
	/// </summary>
	public class Item {
		/// <summary>
		/// Get items for specified product.
		/// </summary>
		/// <param name="prodid">Product to get items for.</param>
		/// <returns>Data reader.</returns>
		public SqlDataReader GetList(string prodid) {
			SqlDataReader dataReader = null;

			try {
				// create data object and params
				Database data = new Database();
				SqlParameter[] prams = { data.MakeInParam("@prodid", SqlDbType.VarChar, 10, prodid) };
				
				// run the stored procedure
				data.RunProc("upItemGetList", prams, out dataReader);
			}
			catch (Exception ex) {
				Error.Log(ex.ToString());
			}

			return dataReader;
		}

		/// <summary>
		/// Get items for specified product.
		/// </summary>
		/// <param name="prodid">Return list for this product</param>
		/// <param name="currentPage">Page result set to return</param>
		/// <param name="pageSize">Size of result set to return</param>
		/// <param name="numResults">Total number of items in list</param>
		/// <returns>Result set</returns>
		public ItemResults[] GetList(string prodid, int currentPage, int pageSize, ref int numResults) {
			numResults = 0;
			int index = 0;
			ItemResults[] results = new ItemResults[pageSize];

			// get all items in list
			SqlDataReader reader = GetList(prodid);

			// now go through and pull out the items we want
			int start = (int)((currentPage - 1) * pageSize);
			if (start <= 0) start = 1;

			// skip 
			for (int i = 0; i < start - 1; i++) {
				if (reader.Read()) numResults++;
			}
			if (start > 1) reader.Read();

			// read the data we are interested in
			while (reader.Read()) {
				if (index < pageSize) {
					results[index] = new ItemResults();
					results[index].itemid = reader.GetString(0);
					results[index].listprice = reader.GetDecimal(1);
					results[index].attr1 = reader.GetString(2);
					index++;
				}
				numResults++;   
			}
			reader.Close();

			// see if need to redim array
			if (index == pageSize)
				return results;
			else {
				// not a full page, redim array
				ItemResults[] results2 = new ItemResults[index];
				Array.Copy(results, results2, index);
				return results2;
			}				
		}

		/// <summary>
		/// Get details on the specified item.
		/// </summary>
		/// <param name="itemID">Item to get details for.</param>
		/// <param name="price">Item price (out).</param>
		/// <param name="qty">Item qty (out).</param>
		/// <param name="itemName">Item name (out).</param>
		/// <param name="itemAttr">Item attributes (out).</param>
		/// <param name="desc">Item description (out).</param>
		public void GetDetails(string itemID, out double price, out int qty, 
			out string itemName, out string itemAttr, out string desc) {
			try {
				// create data object and params
				Database data = new Database();
				
				SqlParameter[] prams = {
					data.MakeInParam("@itemID",    SqlDbType.VarChar,   10, itemID),
					data.MakeOutParam("@price",    SqlDbType.SmallMoney, 4),
					data.MakeOutParam("@qty",      SqlDbType.Int,        4),
					data.MakeOutParam("@itemName", SqlDbType.VarChar,   80),
					data.MakeOutParam("@itemAttr", SqlDbType.VarChar,   80),
					data.MakeOutParam("@desc",     SqlDbType.VarChar,   255)
				};

				// run stored procedure, sets param values			
				data.RunProc("upItemGetDetails", prams);
		
				// return values
				price = Convert.ToDouble(prams[1].Value);
				qty = (int)prams[2].Value;
				itemName = (string)prams[3].Value;
				itemAttr = (string)prams[4].Value;
				desc = (string)prams[5].Value;
			}
			catch (Exception ex) {
				Error.Log(ex.ToString());
	
				// set return values
				price = 0;
				qty = 0;
				itemName = "";
				itemAttr = "";
				desc = "";
			}
		}
	}
}
