using System;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;

namespace PetShop.Components {
	/// <summary>
	/// User profile settings.
	/// </summary>
	public class Profile {
		/// <summary>
		/// Return banner display options for the specified user.
		/// </summary>
		/// <param name="userID">User to retrieve banner options.</param>
		/// <param name="showBanner">Returns true or false.</param>
		/// <param name="bannerPath">Returns banner image path.</param>
		public void GetBannerOptions(string userID, out bool showBanner, out string bannerPath) {
			// init return values
			showBanner = false;
			bannerPath = "";
			
			try {
				// create data object and params
				Database data = new Database();
				
				SqlParameter[] prams = {
					data.MakeInParam("@userID", SqlDbType.VarChar, 80, userID),
					data.MakeOutParam("@showBanner", SqlDbType.Int, 4),
					data.MakeOutParam("@bannerPath", SqlDbType.VarChar, 80)
				};

				// run stored procedure, sets param values			
				data.RunProc("upProfileGetBannerOption", prams);
		
				// return values
				showBanner = Convert.ToBoolean(prams[1].Value);
				bannerPath = (string)prams[2].Value;
			}
			catch {
				// init return values at top of function
				// return values to not show banner
			}
		}

		/// <summary>
		/// Return favorite list options for the specified user.
		/// </summary>
		/// <param name="userID">User to retrieve banner options.</param>
		/// <param name="showList">Returns true or false.</param>
		/// <param name="cat">Returns fav category.</param>
		public void GetListOptions(string userID, out bool showList, out string cat) {
			// init return values
			showList = false;
			cat = "";
			
			try {
				// create data object and params
				Database data = new Database();
				
				SqlParameter[] prams =
				{
					data.MakeInParam("@userID", SqlDbType.VarChar, 80, userID),
					data.MakeOutParam("@showList", SqlDbType.Int, 4),
					data.MakeOutParam("@cat", SqlDbType.VarChar, 80)
				};

				// run stored procedure, sets param values			
				data.RunProc("upProfileGetListOption", prams);
		
				// return values
				showList = Convert.ToBoolean(prams[1].Value);
				cat = (string)prams[2].Value;
			}
			catch {
				// init values at top of function
				// return values to not show favorite list
			}
		}
	}
}
