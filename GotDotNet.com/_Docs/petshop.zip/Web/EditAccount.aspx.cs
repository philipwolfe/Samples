using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using PetShop.Components;

namespace PetShop.Web {
	/// <summary>
	/// Edit an existing user account.
	/// </summary>
	public class EditAccount : System.Web.UI.Page {
		protected System.Web.UI.WebControls.Label lblUserName;
		protected System.Web.UI.WebControls.TextBox txtEmail;
		protected System.Web.UI.WebControls.DropDownList lstLanguagePref;
		protected System.Web.UI.WebControls.DropDownList lstFavor;
		protected System.Web.UI.WebControls.CheckBox cbShowMyList;
		protected System.Web.UI.WebControls.ImageButton btnSubmit;
		protected System.Web.UI.WebControls.TextBox txtFirstName;
		protected System.Web.UI.WebControls.RequiredFieldValidator valFirstName;
		protected System.Web.UI.WebControls.TextBox txtLastName;
		protected System.Web.UI.WebControls.RequiredFieldValidator valLastName;
		protected System.Web.UI.WebControls.TextBox txtAddress1;
		protected System.Web.UI.WebControls.RequiredFieldValidator valAddress1;
		protected System.Web.UI.WebControls.TextBox txtAddress2;
		protected System.Web.UI.WebControls.TextBox txtCity;
		protected System.Web.UI.WebControls.RequiredFieldValidator valCity;
		protected System.Web.UI.WebControls.DropDownList listState;
		protected System.Web.UI.WebControls.TextBox txtPostalCode;
		protected System.Web.UI.WebControls.RequiredFieldValidator valPostalCode;
		protected System.Web.UI.WebControls.DropDownList listCountry;
		protected System.Web.UI.WebControls.TextBox txtTelephoneNumber;
		protected System.Web.UI.WebControls.RequiredFieldValidator valTelephoneNumber;
		protected System.Web.UI.WebControls.DropDownList listLanguagePref;
		protected System.Web.UI.WebControls.DropDownList listFavoriteCategory;
		protected System.Web.UI.WebControls.RequiredFieldValidator valEmail;
		protected System.Web.UI.WebControls.CheckBox cbShowBanners;
	
		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnSubmit.Click += new System.Web.UI.ImageClickEventHandler(this.btnSubmit_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void Page_Load(object sender, System.EventArgs e) {
			if (!IsPostBack)				
				GetAccount();
		}

		// submit button clicked
		private void btnSubmit_Click(object sender, System.Web.UI.ImageClickEventArgs e) {
			UpdateAccount();
			Response.Redirect("ValidateAccount.aspx?action=updateAccount");
		}

		// init fields with info about user
		private void GetAccount() {
			if (Request.IsAuthenticated == true) {
				// determiene who is logged in
				Customer customer = new Customer();
				HttpCookie customerCookie = Request.Cookies["CustomerID"];

				// get account info
				Customer.CustomerDetails customerDetails = customer.GetDetails(customerCookie.Value);

				// init list controls
				listState.Items.Clear();
				listState.Items.Add(new ListItem("California", "California"));
				listState.Items.Add(new ListItem("New York", "New York"));
				listState.Items.Add(new ListItem("Texas", "Texas"));

				listCountry.Items.Clear();
				listCountry.Items.Add(new ListItem("USA", "USA"));
				listCountry.Items.Add(new ListItem("Canada", "Canada"));
				listCountry.Items.Add(new ListItem("Japan", "Japan"));

				listLanguagePref.Items.Clear();
				listLanguagePref.Items.Add(new ListItem("English", "English"));
				listLanguagePref.Items.Add(new ListItem("Japanese", "Japanese"));

				listFavoriteCategory.Items.Clear();
				listFavoriteCategory.Items.Add(new ListItem("Birds", "Birds"));
				listFavoriteCategory.Items.Add(new ListItem("Cats", "Cats"));
				listFavoriteCategory.Items.Add(new ListItem("Dogs", "Dogs"));
				listFavoriteCategory.Items.Add(new ListItem("Fish", "Fish"));
				listFavoriteCategory.Items.Add(new ListItem("Reptiles", "Reptiles"));

				// init the user name/password values
				lblUserName.Text = customerDetails.userid;
				txtEmail.Text = customerDetails.email;

				// init the address values
				txtFirstName.Text = customerDetails.firstname;
				txtLastName.Text = customerDetails.lastname;
				txtAddress1.Text = customerDetails.addr1;
				txtAddress2.Text = customerDetails.addr2;
				txtCity.Text = customerDetails.city;
				txtPostalCode.Text = customerDetails.zip;
				txtTelephoneNumber.Text = customerDetails.phone;
				SelectListItem(listState, customerDetails.state);
				SelectListItem(listCountry, customerDetails.country);

				// init the profile values
				SelectListItem(listLanguagePref, customerDetails.langpref);
				SelectListItem(listFavoriteCategory, customerDetails.favcategory);
				if ((customerDetails.mylistopt) == 1) cbShowMyList.Checked = true;
				if ((customerDetails.banneropt) == 1) cbShowBanners.Checked = true;
			}
		}

		// update database with new info about user
		public void UpdateAccount() {
			Customer customer = new Customer();			
			HttpCookie customerCookie = Request.Cookies["CustomerID"];
			 
			customer.UpdateAccount(customerCookie.Value, txtEmail.Text, txtFirstName.Text, 
				txtLastName.Text, txtAddress1.Text, txtAddress2.Text, 
				txtCity.Text, listState.SelectedItem.Text, txtPostalCode.Text,
				listCountry.SelectedItem.Text, txtTelephoneNumber.Text, 
				listLanguagePref.SelectedItem.Text, 
				listFavoriteCategory.SelectedItem.Value, 
				(cbShowMyList.Checked==true) ? 1 : 0, 
				(cbShowBanners.Checked==true) ? 1 : 0);
		}

		// select item in dropdown list       
		private void SelectListItem(DropDownList list, string text)	{
			try	{
				list.Items.FindByText(text).Selected = true;
			}
			catch {
			}
		}		
	}
}
