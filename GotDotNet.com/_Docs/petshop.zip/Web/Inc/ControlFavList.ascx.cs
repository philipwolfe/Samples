namespace PetShop.Web.Inc {
	using System;
	using System.Data;
	using System.Data.SqlClient;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;
	using PetShop.Components;

	/// <summary>
	///	Display favorite list based on user preference.
	/// </summary>
	public abstract class ControlFavList : System.Web.UI.UserControl {
		protected System.Web.UI.HtmlControls.HtmlGenericControl areaFavList;
		protected System.Web.UI.WebControls.Repeater list;
		protected System.Web.UI.WebControls.ImageButton btnPrevious;
		protected System.Web.UI.WebControls.ImageButton btnNext;
		protected System.Web.UI.WebControls.HyperLink lnkPrevious;
		protected System.Web.UI.WebControls.HyperLink lnkNext;
		
		#region Web Form Designer generated code
		/// <summary>
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
			this.Load += new System.EventHandler(this.Page_Load);
		}

		public ControlFavList() {
			this.Init += new System.EventHandler(Page_Init);
		}

		private void Page_Init(object sender, EventArgs e) {
			InitializeComponent();
		}
		#endregion

		// constants
		const int pageSize = 4;
		const int numSeachResults = 0;

		// page variables
		private int currentPage = 0;
		private int pageCount = 0;
		private int numResults;

		private void Page_Load(object sender, System.EventArgs e) {
			if ((Request.IsAuthenticated == true) && (Page.IsPostBack == false)) {
				// First time here we want to fetch the first page. All of the
				// other page requests will be handled through the page 
				// navigation button event handlers.
				currentPage = 1;

				BindPagedData();
			}
		}

		private void BindList(string cat) {
			// pull the values off the query string
			if (Request.QueryString["requestedPage"] != null) {
				currentPage = System.Int32.Parse(Request.QueryString["requestedPage"]);
				pageCount = System.Int32.Parse(Request.QueryString["pageCount"]);
			}
			else
				currentPage = 1;

			Components.Product product = new Components.Product();
			ProductResults[] results = product.GetList(cat, currentPage, pageSize, ref numResults);

			list.DataSource = results;
			list.DataBind();

			// if this is the first time, calculate the total number of pages
			if (!Page.IsPostBack) 
				pageCount = (int)System.Math.Ceiling((double)numResults / pageSize);
			
			// hide or show navigation buttons
			if (pageCount > 1) {
				// there are multiple pages
				lnkPrevious.Visible = currentPage > 1;
				lnkNext.Visible = currentPage < pageCount;
				lnkPrevious.NavigateUrl = "../Cart.aspx?category_id=" + cat + "&requestedPage=" + (currentPage - 1) + "&pageCount=" + pageCount;
				lnkNext.NavigateUrl = "../Cart.aspx?category_id=" + cat + "&requestedPage=" + (currentPage + 1) + "&pageCount=" + pageCount;
			}
			else {
				// there is only one page, hide both buttons
				lnkPrevious.Visible = lnkNext.Visible = false;
				lnkPrevious.NavigateUrl = "../Cart.aspx?category_id=" + cat + "&requestedPage=" + (currentPage - 1) + "&pageCount=" + pageCount;
				lnkNext.NavigateUrl = "../Cart.aspx?category_id=" + cat + "&requestedPage=" + (currentPage + 1) + "&pageCount=" + pageCount;
			}
		}

		// custom paging
		private void BindPagedData() {
			// determine who is logged in
			HttpCookie customerCookie = Request.Cookies["CustomerID"];
			if ((customerCookie != null) && (customerCookie.Value.Length > 0)) 
			{
				bool showList;
				string cat;

				// get favorite list setting
				Profile profile = new Profile();
				profile.GetListOptions((string) customerCookie.Value, out showList, out cat);

				// hide or show list
				list.Visible = showList;
				areaFavList.Visible = showList;

				// update favorite list if visible				
				if (showList) {
					BindList(cat);
				}
				else {
					// no one is logged in, hide the list
					list.Visible = false;
					areaFavList.Visible = false;
				}
			}
		}		
	}
}
