using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using PetShop.Components;

namespace PetShop.Web {
	/// <summary>
	/// Specify credit card and shipping info.
	/// </summary>
	public class OrderBilling : System.Web.UI.Page {
		protected System.Web.UI.WebControls.DropDownList listCardType;
		protected System.Web.UI.WebControls.TextBox txtCardNumber;
		protected System.Web.UI.WebControls.RequiredFieldValidator valCardNumber;
		protected System.Web.UI.WebControls.DropDownList listMonth;
		protected System.Web.UI.WebControls.DropDownList listYear;
		protected System.Web.UI.WebControls.CheckBox chkUseBillingAddress;
		protected System.Web.UI.WebControls.Label lblPage;
		protected System.Web.UI.WebControls.ImageButton btnContinue;

		public OrderBilling() {
			Page.Init += new System.EventHandler(Page_Init);
		}

		private void Page_Load(object sender, System.EventArgs e) {
			if (!IsPostBack) {
				// default credit card value
				txtCardNumber.Text = "9999 9999 9999 9999";
			}
		}

		private void Page_Init(object sender, EventArgs e) {
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
		}

		// continue button click
		private void btnContinue_Click(object sender, System.Web.UI.ImageClickEventArgs e) {
			// get address holder
			Hashtable adr = (Hashtable)Session["ShoppingAddressSession"];
			if (adr == null) {
				// don't have one yet, go ahead and create it
				adr = new Hashtable();
				Session["ShoppingAddressSession"] = adr;
			}				

			// save credit card info
			adr["CardType"] = listCardType.SelectedItem.Text.Trim();
			adr["CardNumber"] = txtCardNumber.Text.Trim();
			adr["CardExpireMonth"] = listMonth.SelectedItem.Text.Trim();
			adr["CardExpireYear"] = listYear.SelectedItem.Text.Trim();

			// save billing address info
			Inc.ControlAddress ctlAddress;
			ctlAddress = (Inc.ControlAddress)FindControl("ctlAddress");
			ctlAddress.SaveInfo(adr, "Bill");

			// save shipping info if selected to use same address
			if (chkUseBillingAddress.Checked)
				ctlAddress.SaveInfo(adr, "Ship");
			
			// go to next page
			Response.Redirect(chkUseBillingAddress.Checked ?
				"OrderAddressConfirm.aspx" : "OrderShipping.aspx");
		}


		#region Web Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnContinue.Click += new System.Web.UI.ImageClickEventHandler(this.btnContinue_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
