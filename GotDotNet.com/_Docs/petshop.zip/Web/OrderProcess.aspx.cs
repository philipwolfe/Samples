using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Diagnostics;
using PetShop.Components;

namespace PetShop.Web {
	/// <summary>
	/// Process the order and display summary.
	/// </summary>
	public class OrderProcess : System.Web.UI.Page {
		protected System.Web.UI.WebControls.Label lblOrderID;
		protected System.Web.UI.WebControls.Label lblDate;
		protected System.Web.UI.WebControls.Label lblStatus;
		protected System.Web.UI.WebControls.Label lblShipAdr1;
		protected System.Web.UI.WebControls.Label lblShipAdr2;
		protected System.Web.UI.WebControls.Label lblShipCity;
		protected System.Web.UI.WebControls.Label lblShipState;
		protected System.Web.UI.WebControls.Label lblShipPostalCode;
		protected System.Web.UI.WebControls.Label lblCardType;
		protected System.Web.UI.WebControls.Label lblCardNumber;
		protected System.Web.UI.WebControls.Label lblCardDate;
		protected System.Web.UI.WebControls.DataGrid dataGrid;
		protected System.Web.UI.WebControls.Label lblAccount;

		public OrderProcess() {
			Page.Init += new System.EventHandler(Page_Init);
		}

		private void Page_Load(object sender, System.EventArgs e) {
			// make sure we really have items in the cart
			ShoppingCart cart = (ShoppingCart)Session["ShoppingCartSession"];
			if (cart.Count == 0)
				Response.Redirect("Cart.aspx");
				
			// We have to use a manual datagrid instead of the cart user control
			// since the usercontrol displays the content of the shoppingcart 
			// session object... but its Load event is called after all of the 
			// Page events are called. By the time the usercontrol's Load event
			// is called, the shoppingcart session object is empty.
			dataGrid.Columns[4].FooterText = cart.Total.ToString("c");
			dataGrid.DataSource = cart.GetItems();
			dataGrid.DataBind();

			// determine who is logged in
			Debug.Assert(Request.Cookies["CustomerID"] != null);
			string userID = (string)Request.Cookies["CustomerID"].Value;

			// add order to database
			DateTime orderDate = DateTime.Now;
			int orderID = AddOrder(userID, orderDate.ToString());
			
			// hook up results
			lblDate.Text = orderDate.ToLongDateString();
			lblAccount.Text = userID;
			lblOrderID.Text = orderID.ToString();
			lblStatus.Text = "P";
			
			// credit card
			Hashtable adr = (Hashtable)Session["ShoppingAddressSession"];
			Debug.Assert(adr != null);			
			lblCardType.Text = (string)adr["CardType"];
			lblCardNumber.Text = (string)adr["CardNumber"];
			lblCardDate.Text = (string)adr["CardExpireMonth"] + "/" + (string)adr["CardExpireYear"];

			// clear shopping cart
			cart.ClearCart();				
		}

		// add order to database
		private int AddOrder(string userID, string orderDate) {
			// get shopping cart
			ShoppingCart cart = (ShoppingCart)Session["ShoppingCartSession"];
			Debug.Assert(cart != null);

			// create xml doc to pass down to stored proc, this xml doc contains
			// one main <Orders> section and multiple <LineItems> sections
			string xml = "<Orders " + GetOrdersXML(userID, orderDate) + ">" + 
				cart.GetLineItemsXML() + "</Orders>";

			// add this order to the database, get the new order id back			
			Order order = new Order();
			int id = order.Add(xml);
			return id;
		}

		// returns the attriubutes for the Orders xml section		
		private string GetOrdersXML(string userID, string orderDate) {
			// use session objects to create xml string
			Hashtable adr = (Hashtable)Session["ShoppingAddressSession"];
			Debug.Assert(adr != null);			

			ShoppingCart cart = (ShoppingCart)Session["ShoppingCartSession"];
			Debug.Assert(cart != null);

			// total price
			string totalPrice = cart.Total.ToString();

			// create attribute string
			string xml = "userid='" + userID + 
				"' orderdate='" + orderDate +
				"' shiptofirstname='" + adr["Ship_FirstName"] +
				"' shiptolastname='" +adr["Ship_LastName"] +
				"' shipaddr1='" + adr["Ship_Address1"] + 
				"' shipaddr2='" + adr["Ship_Address2"] +
				"' shipcity='" + adr["Ship_City"] +
				"' shipstate='" + adr["Ship_State"] +
				"' shipzip='" + adr["Ship_PostalCode"] +
				"' shipcountry='" + adr["Ship_Country"] +
				"' billtofirstname='" + adr["Bill_FirstName"] +
				"' billtolastname='" +adr["Bill_LastName"] +
				"' billaddr1='" + adr["Bill_Address1"] +
				"' billaddr2='" + adr["Bill_Address2"] +
				"' billcity='" + adr["Bill_City"] +
				"' billstate='" + adr["Bill_State"] +
				"' billzip='" + adr["Bill_PostalCode"] +
				"' billcountry='" + adr["Bill_Country"] +
				"' creditcard='" + adr["CardNumber"] + 
				"' exprdate='" + adr["CardExpireMonth"] + "/" + adr["CardExpireYear"] +
				"' cardtype='" + adr["CardType"] +
				"' courier='UPS" +
				"' totalprice='" + totalPrice + 
				"' locale='US_en'";

			return xml;
		}

		private void Page_Init(object sender, EventArgs e) {
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
		}

		#region Web Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
