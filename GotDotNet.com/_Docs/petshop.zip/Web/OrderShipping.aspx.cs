using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Diagnostics;


namespace PetShop.Web {
	/// <summary>
	/// Allow user to specify different shipping info than billing address.
	/// </summary>
	public class OrderShipping : System.Web.UI.Page {
		protected System.Web.UI.WebControls.ImageButton btnContinue;

		public OrderShipping() {
			Page.Init += new System.EventHandler(Page_Init);
		}

		private void Page_Load(object sender, System.EventArgs e) {
			// Put user code to initialize the page here
		}

		private void Page_Init(object sender, EventArgs e) {
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
		}

		// continue button click
		private void btnContinue_Click(object sender, System.Web.UI.ImageClickEventArgs e) {
			// get address holder
			Hashtable adr = (Hashtable)Session["ShoppingAddressSession"];
			Debug.Assert(adr!=null);
			
			// save shipping address info
			Inc.ControlAddress ctlAddress;
			ctlAddress = (Inc.ControlAddress)FindControl("ctlAddress");
			ctlAddress.SaveInfo(adr, "Ship");

			// go to next page
			Response.Redirect("OrderAddressConfirm.aspx");
		}

		#region Web Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnContinue.Click += new System.Web.UI.ImageClickEventHandler(this.btnContinue_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
