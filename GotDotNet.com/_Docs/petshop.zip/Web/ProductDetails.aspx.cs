using System;
using System.ComponentModel;
using System.Web;
using System.Drawing;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using PetShop.Components;

namespace PetShop.Web {

	public class ProductDetails : System.Web.UI.Page {
		protected System.Web.UI.WebControls.Label lblPage;
		protected System.Web.UI.WebControls.Label lblPrice;
		protected System.Web.UI.WebControls.Label lblQty;
		protected System.Web.UI.HtmlControls.HtmlGenericControl areaDesc;
		protected System.Web.UI.WebControls.HyperLink linkCart;

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void Page_Load(object sender, System.EventArgs e) {
			// item id passed on url
			string itemid = Request.QueryString["item_id"];

			// hold info about item
			double price;
			int qty;
			string desc;
			string itemName;
			string itemAttr;

			// get info about item				
			Item item = new Item();
			item.GetDetails(itemid, out price, out qty, out itemName, out itemAttr, out desc);

			// update page controls
			lblPage.Text = itemAttr + " " + itemName;
			lblPrice.Text = price.ToString("c");
			areaDesc.InnerHtml = desc;
			linkCart.NavigateUrl = "Cart.aspx?action=purchaseItem&itemId=" + itemid;

			// qty can either be the number in stock, or 'back ordered' message
			if (qty > 0) {
				lblQty.Text = qty.ToString();
			}
			else {
				lblQty.Text = "Back Ordered";
				lblQty.ForeColor = Color.DarkRed;
			}				
		}
	}
}
