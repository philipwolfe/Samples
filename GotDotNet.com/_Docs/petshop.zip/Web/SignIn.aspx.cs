using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Web.Security;
using PetShop.Components;

namespace PetShop.Web {
	/// <summary>
	/// Allow user to log in.
	/// </summary>
	public class SignIn : System.Web.UI.Page {
		protected System.Web.UI.WebControls.TextBox txtUsername;
		protected System.Web.UI.WebControls.TextBox txtPassword;
		protected System.Web.UI.WebControls.Label lblErrorMessage;
		protected System.Web.UI.WebControls.RequiredFieldValidator valUsername;
		protected System.Web.UI.WebControls.RequiredFieldValidator valPassword;
		protected System.Web.UI.WebControls.ImageButton btnSubmit;

		public SignIn() {
			Page.Init += new System.EventHandler(Page_Init);
		}

		private void Page_Load(object sender, System.EventArgs e) {
		}

		private void Page_Init(object sender, EventArgs e) {
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
		}

		// submit button click
		private void btnSubmit_Click(object sender, System.Web.UI.ImageClickEventArgs e) {
			// only attempt a login if all form fields on the page are valid
			if (Page.IsValid == true) {
				// attempt to validate user credentials
				Customer customer = new Customer();
				string customerID = customer.Login(txtUsername.Text, txtPassword.Text);
				
				// if the call to login() returns null, then the credentials 
				// failed authentication
				if (customerID != null) {
					// store our customer session id in a cookie
					//HttpCookie customerCookie = new HttpCookie("CustomerID", customerID);					
					//Response.Cookies.Add(customerCookie);

					Response.Cookies["CustomerID"].Value = customerID;

					// see if user clicked on the signin link
					if (FormsAuthentication.GetRedirectUrl(customerID, false).ToLower().EndsWith("default.aspx")) {
						// creates authentication ticket for user then display confirmation
						FormsAuthentication.SetAuthCookie(customerID, false);
						Response.Redirect("VerifySignIn.aspx");
					}						
					else {
						// user came here by accessing a secure page, continue
						// on to the page they were trying to access
						FormsAuthentication.RedirectFromLoginPage(customerID, false);
					}						
				}
				else {				
					lblErrorMessage.Visible = true;
				}
			}
		}

		#region Web Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.btnSubmit.Click += new System.Web.UI.ImageClickEventHandler(this.btnSubmit_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
