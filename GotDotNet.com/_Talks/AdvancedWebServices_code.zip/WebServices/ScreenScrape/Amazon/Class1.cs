using System.Diagnostics;
using System.Xml.Serialization;
using System;
using System.Web.Services.Protocols;
using System.Web.Services;


public class Amazon : System.Web.Services.Protocols.HttpGetClientProtocol {
    
	[System.Diagnostics.DebuggerStepThroughAttribute()]
	public Amazon() {
		this.Url = "http://www.amazon.com/exec/obidos/ASIN/";
	}
    
	[System.Diagnostics.DebuggerStepThroughAttribute()]
	[System.Web.Services.Protocols.HttpMethodAttribute(typeof(System.Web.Services.Protocols.TextReturnReader), typeof(System.Web.Services.Protocols.UrlParameterWriter))]
	public GetBookDetailsMatches GetBookDetails(string isbn) {
		return ((GetBookDetailsMatches)(this.Invoke("GetBookDetails", (this.Url + isbn), new object[] {0})));
	}
}

public class GetBookDetailsMatches {
    
	[System.Web.Services.Protocols.MatchAttribute("TITLE>Amazon.com..buying.info..(.*?)<", IgnoreCase=true)]
	public string Title;
    
	[System.Web.Services.Protocols.MatchAttribute("Amazon.com Sales Rank.</B>(.*?)<", IgnoreCase=true)]
	public string Rank;
}
