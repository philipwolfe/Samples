namespace Microsoft.WebServices.Security {
	using System;

	public delegate void WebServiceAuthenticationEventHandler(Object sender,  WebServiceAuthenticationEvent e);
}
